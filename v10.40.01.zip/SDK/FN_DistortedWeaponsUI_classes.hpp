#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Classes
//---------------------------------------------------------------------------

// Class DistortedWeaponsUI.ChromeWeaponInfoWidget
// 0x0020 (0x02F0 - 0x02D0)
class ChromeWeaponInfoWidget : public FortHUDElementWidget
{
public:
	class FortHUDContext*                              HUDContext_69;                                            // 0x02D0(0x0008) (ZeroConstructor, Transient)
	class FortWorldMultiItemXPComponent*               CurrentXpComponent_69;                                    // 0x02D8(0x0008) (ExportObject, ZeroConstructor, Transient, InstancedReference)
	class AthenaItemTierWidget*                        ItemTierWidget_69;                                        // 0x02E0(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)
	class FortKeybindWidget*                           KeybindWidget_69;                                         // 0x02E8(0x0008) (ExportObject, ZeroConstructor, InstancedReference)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class DistortedWeaponsUI.ChromeWeaponInfoWidget"));
		
		return ptr;
	}


	void OnWeaponUpgraded();
	void OnWeaponStartUpgrading();
	void OnWeaponRemoved();
	void OnWeaponEquipped();
	void OnReadyToUpgradeWeapon(EFortRarity NextRarity_69);
	void OnGainedXp(float CurrentXPPercentage_69);
	void HandleXpChanged(float XPDelta_69, float CurrentXPPercentage_69);
	void HandleWeaponUpgraded();
	void HandleWeaponUnEquipped();
	void HandleWeaponEquipped(class FortWeapon* NewWeapon_69, class FortWeapon* PrevWeapon_69);
	void HandleUpgradeTriggered(float ReloadTime_69, EFortWeaponReloadType ReloadType_69);
	void HandlePowerUpPending();
	EFortRarity GetCurrentWeaponRarity();
};


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

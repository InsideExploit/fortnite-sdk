// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Functions
//---------------------------------------------------------------------------

// Function CommonConversationRuntime.ConversationParticipantComponent.ServerAdvanceConversation
// (Net, NetReliable, Native, Event, Protected, NetServer)
// Parameters:
// struct FAdvanceConversationRequest InChoicePicked_69              (ConstParm, Parm, ReferenceParm)

void ConversationParticipantComponent::ServerAdvanceConversation(const struct FAdvanceConversationRequest& InChoicePicked_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonConversationRuntime.ConversationParticipantComponent.ServerAdvanceConversation"));

	ConversationParticipantComponent_ServerAdvanceConversation_Params params;
	params.InChoicePicked_69 = InChoicePicked_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonConversationRuntime.ConversationParticipantComponent.RequestServerAdvanceConversation
// (Final, Native, Public, HasOutParms, BlueprintCallable)
// Parameters:
// struct FAdvanceConversationRequest InChoicePicked_69              (ConstParm, Parm, OutParm, ReferenceParm)

void ConversationParticipantComponent::RequestServerAdvanceConversation(const struct FAdvanceConversationRequest& InChoicePicked_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonConversationRuntime.ConversationParticipantComponent.RequestServerAdvanceConversation"));

	ConversationParticipantComponent_RequestServerAdvanceConversation_Params params;
	params.InChoicePicked_69 = InChoicePicked_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonConversationRuntime.ConversationParticipantComponent.OnRep_ConversationsActive
// (Final, Native, Protected)
// Parameters:
// int                            OldConversationsActive_69      (Parm, ZeroConstructor, IsPlainOldData)

void ConversationParticipantComponent::OnRep_ConversationsActive(int OldConversationsActive_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonConversationRuntime.ConversationParticipantComponent.OnRep_ConversationsActive"));

	ConversationParticipantComponent_OnRep_ConversationsActive_Params params;
	params.OldConversationsActive_69 = OldConversationsActive_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonConversationRuntime.ConversationParticipantComponent.IsInActiveConversation
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool ConversationParticipantComponent::IsInActiveConversation()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonConversationRuntime.ConversationParticipantComponent.IsInActiveConversation"));

	ConversationParticipantComponent_IsInActiveConversation_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CommonConversationRuntime.ConversationParticipantComponent.GetParticipantDisplayName
// (Native, Public, BlueprintCallable)
// Parameters:
// struct FText                   ReturnValue_69                 (Parm, OutParm, ReturnParm)

struct FText ConversationParticipantComponent::GetParticipantDisplayName()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonConversationRuntime.ConversationParticipantComponent.GetParticipantDisplayName"));

	ConversationParticipantComponent_GetParticipantDisplayName_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CommonConversationRuntime.ConversationParticipantComponent.ClientUpdateParticipants
// (Net, NetReliable, Native, Event, Protected, NetClient)
// Parameters:
// struct FConversationParticipants InParticipants_69              (ConstParm, Parm, ReferenceParm)

void ConversationParticipantComponent::ClientUpdateParticipants(const struct FConversationParticipants& InParticipants_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonConversationRuntime.ConversationParticipantComponent.ClientUpdateParticipants"));

	ConversationParticipantComponent_ClientUpdateParticipants_Params params;
	params.InParticipants_69 = InParticipants_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonConversationRuntime.ConversationParticipantComponent.ClientUpdateConversationTaskChoiceData
// (Net, NetReliable, Native, Event, Protected, NetClient)
// Parameters:
// struct FConversationNodeHandle Handle_69                      (Parm)
// struct FClientConversationOptionEntry OptionEntry_69                 (ConstParm, Parm, ReferenceParm)

void ConversationParticipantComponent::ClientUpdateConversationTaskChoiceData(const struct FConversationNodeHandle& Handle_69, const struct FClientConversationOptionEntry& OptionEntry_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonConversationRuntime.ConversationParticipantComponent.ClientUpdateConversationTaskChoiceData"));

	ConversationParticipantComponent_ClientUpdateConversationTaskChoiceData_Params params;
	params.Handle_69 = Handle_69;
	params.OptionEntry_69 = OptionEntry_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonConversationRuntime.ConversationParticipantComponent.ClientUpdateConversations
// (Net, NetReliable, Native, Event, Protected, NetClient)
// Parameters:
// int                            InConversationsActive_69       (Parm, ZeroConstructor, IsPlainOldData)

void ConversationParticipantComponent::ClientUpdateConversations(int InConversationsActive_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonConversationRuntime.ConversationParticipantComponent.ClientUpdateConversations"));

	ConversationParticipantComponent_ClientUpdateConversations_Params params;
	params.InConversationsActive_69 = InConversationsActive_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonConversationRuntime.ConversationParticipantComponent.ClientUpdateConversation
// (Net, NetReliable, Native, Event, Protected, NetClient)
// Parameters:
// struct FClientConversationMessagePayload message_69                     (ConstParm, Parm, ReferenceParm)

void ConversationParticipantComponent::ClientUpdateConversation(const struct FClientConversationMessagePayload& message_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonConversationRuntime.ConversationParticipantComponent.ClientUpdateConversation"));

	ConversationParticipantComponent_ClientUpdateConversation_Params params;
	params.message_69 = message_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonConversationRuntime.ConversationParticipantComponent.ClientStartConversation
// (Net, NetReliable, Native, Event, Protected, NetClient)
// Parameters:
// struct FGameplayTag            AsParticipant_69               (ConstParm, Parm)

void ConversationParticipantComponent::ClientStartConversation(const struct FGameplayTag& AsParticipant_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonConversationRuntime.ConversationParticipantComponent.ClientStartConversation"));

	ConversationParticipantComponent_ClientStartConversation_Params params;
	params.AsParticipant_69 = AsParticipant_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonConversationRuntime.ConversationParticipantComponent.ClientExecuteTaskAndSideEffects
// (Net, NetReliable, Native, Event, Protected, NetClient)
// Parameters:
// struct FConversationNodeHandle Handle_69                      (Parm)

void ConversationParticipantComponent::ClientExecuteTaskAndSideEffects(const struct FConversationNodeHandle& Handle_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonConversationRuntime.ConversationParticipantComponent.ClientExecuteTaskAndSideEffects"));

	ConversationParticipantComponent_ClientExecuteTaskAndSideEffects_Params params;
	params.Handle_69 = Handle_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonConversationRuntime.ConversationNode.GetDebugParticipantColor
// (Final, Native, Protected, HasDefaults, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FGameplayTag            ParticipantID_69               (Parm)
// struct FLinearColor            ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

struct FLinearColor ConversationNode::GetDebugParticipantColor(const struct FGameplayTag& ParticipantID_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonConversationRuntime.ConversationNode.GetDebugParticipantColor"));

	ConversationNode_GetDebugParticipantColor_Params params;
	params.ParticipantID_69 = ParticipantID_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CommonConversationRuntime.ConversationChoiceNode.FillChoice
// (Native, Event, Protected, HasOutParms, BlueprintEvent, Const)
// Parameters:
// struct FConversationContext    Context_69                     (ConstParm, Parm, OutParm, ReferenceParm)
// struct FClientConversationOptionEntry ChoiceEntry_69                 (Parm, OutParm)

void ConversationChoiceNode::FillChoice(const struct FConversationContext& Context_69, struct FClientConversationOptionEntry* ChoiceEntry_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonConversationRuntime.ConversationChoiceNode.FillChoice"));

	ConversationChoiceNode_FillChoice_Params params;
	params.Context_69 = Context_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (ChoiceEntry_69 != nullptr)
		*ChoiceEntry_69 = params.ChoiceEntry_69;
}


// Function CommonConversationRuntime.ConversationContextHelpers.ReturnToLastClientChoice
// (Final, BlueprintAuthorityOnly, Native, Static, Public, HasOutParms, BlueprintCallable)
// Parameters:
// struct FConversationContext    Context_69                     (ConstParm, Parm, OutParm, ReferenceParm)
// struct FConversationTaskResult ReturnValue_69                 (Parm, OutParm, ReturnParm)

struct FConversationTaskResult ConversationContextHelpers::STATIC_ReturnToLastClientChoice(const struct FConversationContext& Context_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonConversationRuntime.ConversationContextHelpers.ReturnToLastClientChoice"));

	ConversationContextHelpers_ReturnToLastClientChoice_Params params;
	params.Context_69 = Context_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CommonConversationRuntime.ConversationContextHelpers.ReturnToCurrentClientChoice
// (Final, BlueprintAuthorityOnly, Native, Static, Public, HasOutParms, BlueprintCallable)
// Parameters:
// struct FConversationContext    Context_69                     (ConstParm, Parm, OutParm, ReferenceParm)
// struct FConversationTaskResult ReturnValue_69                 (Parm, OutParm, ReturnParm)

struct FConversationTaskResult ConversationContextHelpers::STATIC_ReturnToCurrentClientChoice(const struct FConversationContext& Context_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonConversationRuntime.ConversationContextHelpers.ReturnToCurrentClientChoice"));

	ConversationContextHelpers_ReturnToCurrentClientChoice_Params params;
	params.Context_69 = Context_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CommonConversationRuntime.ConversationContextHelpers.ReturnToConversationStart
// (Final, BlueprintAuthorityOnly, Native, Static, Public, HasOutParms, BlueprintCallable)
// Parameters:
// struct FConversationContext    Context_69                     (ConstParm, Parm, OutParm, ReferenceParm)
// struct FConversationTaskResult ReturnValue_69                 (Parm, OutParm, ReturnParm)

struct FConversationTaskResult ConversationContextHelpers::STATIC_ReturnToConversationStart(const struct FConversationContext& Context_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonConversationRuntime.ConversationContextHelpers.ReturnToConversationStart"));

	ConversationContextHelpers_ReturnToConversationStart_Params params;
	params.Context_69 = Context_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CommonConversationRuntime.ConversationContextHelpers.PauseConversationAndSendClientChoices
// (Final, BlueprintAuthorityOnly, Native, Static, Public, HasOutParms, BlueprintCallable)
// Parameters:
// struct FConversationContext    Context_69                     (ConstParm, Parm, OutParm, ReferenceParm)
// struct FClientConversationMessage message_69                     (ConstParm, Parm, OutParm, ReferenceParm)
// struct FConversationTaskResult ReturnValue_69                 (Parm, OutParm, ReturnParm)

struct FConversationTaskResult ConversationContextHelpers::STATIC_PauseConversationAndSendClientChoices(const struct FConversationContext& Context_69, const struct FClientConversationMessage& message_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonConversationRuntime.ConversationContextHelpers.PauseConversationAndSendClientChoices"));

	ConversationContextHelpers_PauseConversationAndSendClientChoices_Params params;
	params.Context_69 = Context_69;
	params.message_69 = message_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CommonConversationRuntime.ConversationContextHelpers.MakeConversationParticipant
// (Final, BlueprintAuthorityOnly, Native, Static, Public, HasOutParms, BlueprintCallable)
// Parameters:
// struct FConversationContext    Context_69                     (ConstParm, Parm, OutParm, ReferenceParm)
// class Actor_32759*             ParticipantActor_69            (Parm, ZeroConstructor)
// struct FGameplayTag            ParticipantTag_69              (Parm)

void ConversationContextHelpers::STATIC_MakeConversationParticipant(const struct FConversationContext& Context_69, class Actor_32759* ParticipantActor_69, const struct FGameplayTag& ParticipantTag_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonConversationRuntime.ConversationContextHelpers.MakeConversationParticipant"));

	ConversationContextHelpers_MakeConversationParticipant_Params params;
	params.Context_69 = Context_69;
	params.ParticipantActor_69 = ParticipantActor_69;
	params.ParticipantTag_69 = ParticipantTag_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonConversationRuntime.ConversationContextHelpers.GetCurrentConversationNodeHandle
// (Final, BlueprintAuthorityOnly, Native, Static, Public, HasOutParms, BlueprintCallable, BlueprintPure)
// Parameters:
// struct FConversationContext    Context_69                     (ConstParm, Parm, OutParm, ReferenceParm)
// struct FConversationNodeHandle ReturnValue_69                 (Parm, OutParm, ReturnParm)

struct FConversationNodeHandle ConversationContextHelpers::STATIC_GetCurrentConversationNodeHandle(const struct FConversationContext& Context_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonConversationRuntime.ConversationContextHelpers.GetCurrentConversationNodeHandle"));

	ConversationContextHelpers_GetCurrentConversationNodeHandle_Params params;
	params.Context_69 = Context_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CommonConversationRuntime.ConversationContextHelpers.GetConversationParticipantActor
// (Final, Native, Static, Public, HasOutParms, BlueprintCallable)
// Parameters:
// struct FConversationContext    Context_69                     (ConstParm, Parm, OutParm, ReferenceParm)
// struct FGameplayTag            ParticipantTag_69              (Parm)
// class Actor_32759*             ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

class Actor_32759* ConversationContextHelpers::STATIC_GetConversationParticipantActor(const struct FConversationContext& Context_69, const struct FGameplayTag& ParticipantTag_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonConversationRuntime.ConversationContextHelpers.GetConversationParticipantActor"));

	ConversationContextHelpers_GetConversationParticipantActor_Params params;
	params.Context_69 = Context_69;
	params.ParticipantTag_69 = ParticipantTag_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CommonConversationRuntime.ConversationContextHelpers.GetConversationParticipant
// (Final, Native, Static, Public, HasOutParms, BlueprintCallable)
// Parameters:
// struct FConversationContext    Context_69                     (ConstParm, Parm, OutParm, ReferenceParm)
// struct FGameplayTag            ParticipantTag_69              (Parm)
// class ConversationParticipantComponent* ReturnValue_69                 (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)

class ConversationParticipantComponent* ConversationContextHelpers::STATIC_GetConversationParticipant(const struct FConversationContext& Context_69, const struct FGameplayTag& ParticipantTag_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonConversationRuntime.ConversationContextHelpers.GetConversationParticipant"));

	ConversationContextHelpers_GetConversationParticipant_Params params;
	params.Context_69 = Context_69;
	params.ParticipantTag_69 = ParticipantTag_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CommonConversationRuntime.ConversationContextHelpers.GetConversationInstance
// (Final, BlueprintAuthorityOnly, Native, Static, Public, HasOutParms, BlueprintCallable, BlueprintPure)
// Parameters:
// struct FConversationContext    Context_69                     (ConstParm, Parm, OutParm, ReferenceParm)
// class ConversationInstance*    ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

class ConversationInstance* ConversationContextHelpers::STATIC_GetConversationInstance(const struct FConversationContext& Context_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonConversationRuntime.ConversationContextHelpers.GetConversationInstance"));

	ConversationContextHelpers_GetConversationInstance_Params params;
	params.Context_69 = Context_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CommonConversationRuntime.ConversationContextHelpers.FindConversationComponent
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// class Actor_32759*             Actor_69                       (Parm, ZeroConstructor)
// class ConversationParticipantComponent* ReturnValue_69                 (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)

class ConversationParticipantComponent* ConversationContextHelpers::STATIC_FindConversationComponent(class Actor_32759* Actor_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonConversationRuntime.ConversationContextHelpers.FindConversationComponent"));

	ConversationContextHelpers_FindConversationComponent_Params params;
	params.Actor_69 = Actor_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CommonConversationRuntime.ConversationContextHelpers.CanConversationContinue
// (Final, BlueprintAuthorityOnly, Native, Static, Public, HasOutParms, BlueprintCallable)
// Parameters:
// struct FConversationTaskResult ConversationTasResult_69       (ConstParm, Parm, OutParm, ReferenceParm)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool ConversationContextHelpers::STATIC_CanConversationContinue(const struct FConversationTaskResult& ConversationTasResult_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonConversationRuntime.ConversationContextHelpers.CanConversationContinue"));

	ConversationContextHelpers_CanConversationContinue_Params params;
	params.ConversationTasResult_69 = ConversationTasResult_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CommonConversationRuntime.ConversationContextHelpers.AdvanceConversationWithChoice
// (Final, BlueprintAuthorityOnly, Native, Static, Public, HasOutParms, BlueprintCallable)
// Parameters:
// struct FConversationContext    Context_69                     (ConstParm, Parm, OutParm, ReferenceParm)
// struct FAdvanceConversationRequest Choice_69                      (ConstParm, Parm, OutParm, ReferenceParm)
// struct FConversationTaskResult ReturnValue_69                 (Parm, OutParm, ReturnParm)

struct FConversationTaskResult ConversationContextHelpers::STATIC_AdvanceConversationWithChoice(const struct FConversationContext& Context_69, const struct FAdvanceConversationRequest& Choice_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonConversationRuntime.ConversationContextHelpers.AdvanceConversationWithChoice"));

	ConversationContextHelpers_AdvanceConversationWithChoice_Params params;
	params.Context_69 = Context_69;
	params.Choice_69 = Choice_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CommonConversationRuntime.ConversationContextHelpers.AdvanceConversation
// (Final, BlueprintAuthorityOnly, Native, Static, Public, HasOutParms, BlueprintCallable)
// Parameters:
// struct FConversationContext    Context_69                     (ConstParm, Parm, OutParm, ReferenceParm)
// struct FConversationTaskResult ReturnValue_69                 (Parm, OutParm, ReturnParm)

struct FConversationTaskResult ConversationContextHelpers::STATIC_AdvanceConversation(const struct FConversationContext& Context_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonConversationRuntime.ConversationContextHelpers.AdvanceConversation"));

	ConversationContextHelpers_AdvanceConversation_Params params;
	params.Context_69 = Context_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CommonConversationRuntime.ConversationContextHelpers.AbortConversation
// (Final, BlueprintAuthorityOnly, Native, Static, Public, HasOutParms, BlueprintCallable)
// Parameters:
// struct FConversationContext    Context_69                     (ConstParm, Parm, OutParm, ReferenceParm)
// struct FConversationTaskResult ReturnValue_69                 (Parm, OutParm, ReturnParm)

struct FConversationTaskResult ConversationContextHelpers::STATIC_AbortConversation(const struct FConversationContext& Context_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonConversationRuntime.ConversationContextHelpers.AbortConversation"));

	ConversationContextHelpers_AbortConversation_Params params;
	params.Context_69 = Context_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CommonConversationRuntime.ConversationLibrary.StartConversation
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// struct FGameplayTag            ConversationEntryTag_69        (Parm)
// class Actor_32759*             Instigator_69                  (Parm, ZeroConstructor)
// struct FGameplayTag            InstigatorTag_69               (Parm)
// class Actor_32759*             Target_69                      (Parm, ZeroConstructor)
// struct FGameplayTag            TargetTag_69                   (Parm)
// class ConversationInstance*    ConversationInstanceClass_69   (ConstParm, Parm, ZeroConstructor)
// class ConversationInstance*    ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

class ConversationInstance* ConversationLibrary::STATIC_StartConversation(const struct FGameplayTag& ConversationEntryTag_69, class Actor_32759* Instigator_69, const struct FGameplayTag& InstigatorTag_69, class Actor_32759* Target_69, const struct FGameplayTag& TargetTag_69, class ConversationInstance* ConversationInstanceClass_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonConversationRuntime.ConversationLibrary.StartConversation"));

	ConversationLibrary_StartConversation_Params params;
	params.ConversationEntryTag_69 = ConversationEntryTag_69;
	params.Instigator_69 = Instigator_69;
	params.InstigatorTag_69 = InstigatorTag_69;
	params.Target_69 = Target_69;
	params.TargetTag_69 = TargetTag_69;
	params.ConversationInstanceClass_69 = ConversationInstanceClass_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CommonConversationRuntime.ConversationTaskNode.IsRequirementSatisfied
// (BlueprintAuthorityOnly, Native, Event, Protected, HasOutParms, BlueprintEvent, Const)
// Parameters:
// struct FConversationContext    Context_69                     (ConstParm, Parm, OutParm, ReferenceParm)
// EConversationRequirementResult ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

EConversationRequirementResult ConversationTaskNode::IsRequirementSatisfied(const struct FConversationContext& Context_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonConversationRuntime.ConversationTaskNode.IsRequirementSatisfied"));

	ConversationTaskNode_IsRequirementSatisfied_Params params;
	params.Context_69 = Context_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CommonConversationRuntime.ConversationTaskNode.GetNodeBodyColor
// (Native, Event, Public, HasOutParms, HasDefaults, BlueprintEvent, Const)
// Parameters:
// struct FLinearColor            BodyColor_69                   (Parm, OutParm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool ConversationTaskNode::GetNodeBodyColor(struct FLinearColor* BodyColor_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonConversationRuntime.ConversationTaskNode.GetNodeBodyColor"));

	ConversationTaskNode_GetNodeBodyColor_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (BodyColor_69 != nullptr)
		*BodyColor_69 = params.BodyColor_69;

	return params.ReturnValue_69;
}


// Function CommonConversationRuntime.ConversationTaskNode.GatherStaticExtraData
// (BlueprintAuthorityOnly, Native, Event, Protected, HasOutParms, BlueprintEvent, Const)
// Parameters:
// struct FConversationContext    Context_69                     (ConstParm, Parm, OutParm, ReferenceParm)
// TArray<struct FConversationNodeParameterPair> InOutExtraData_69              (Parm, OutParm, ZeroConstructor)

void ConversationTaskNode::GatherStaticExtraData(const struct FConversationContext& Context_69, TArray<struct FConversationNodeParameterPair>* InOutExtraData_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonConversationRuntime.ConversationTaskNode.GatherStaticExtraData"));

	ConversationTaskNode_GatherStaticExtraData_Params params;
	params.Context_69 = Context_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (InOutExtraData_69 != nullptr)
		*InOutExtraData_69 = params.InOutExtraData_69;
}


// Function CommonConversationRuntime.ConversationTaskNode.ExecuteTaskNode
// (BlueprintAuthorityOnly, Native, Event, Protected, HasOutParms, BlueprintEvent, Const)
// Parameters:
// struct FConversationContext    Context_69                     (ConstParm, Parm, OutParm, ReferenceParm)
// struct FConversationTaskResult ReturnValue_69                 (Parm, OutParm, ReturnParm)

struct FConversationTaskResult ConversationTaskNode::ExecuteTaskNode(const struct FConversationContext& Context_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonConversationRuntime.ConversationTaskNode.ExecuteTaskNode"));

	ConversationTaskNode_ExecuteTaskNode_Params params;
	params.Context_69 = Context_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CommonConversationRuntime.ConversationTaskNode.ExecuteClientEffects
// (BlueprintCosmetic, Native, Event, Protected, HasOutParms, BlueprintEvent, Const)
// Parameters:
// struct FConversationContext    Context_69                     (ConstParm, Parm, OutParm, ReferenceParm)

void ConversationTaskNode::ExecuteClientEffects(const struct FConversationContext& Context_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonConversationRuntime.ConversationTaskNode.ExecuteClientEffects"));

	ConversationTaskNode_ExecuteClientEffects_Params params;
	params.Context_69 = Context_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonConversationRuntime.ConversationRequirementNode.IsRequirementSatisfied
// (Native, Event, Public, HasOutParms, BlueprintEvent, Const)
// Parameters:
// struct FConversationContext    Context_69                     (ConstParm, Parm, OutParm, ReferenceParm)
// EConversationRequirementResult ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

EConversationRequirementResult ConversationRequirementNode::IsRequirementSatisfied(const struct FConversationContext& Context_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonConversationRuntime.ConversationRequirementNode.IsRequirementSatisfied"));

	ConversationRequirementNode_IsRequirementSatisfied_Params params;
	params.Context_69 = Context_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CommonConversationRuntime.ConversationSideEffectNode.ServerCauseSideEffect
// (BlueprintAuthorityOnly, Native, Event, Protected, HasOutParms, BlueprintEvent, Const)
// Parameters:
// struct FConversationContext    Context_69                     (ConstParm, Parm, OutParm, ReferenceParm)

void ConversationSideEffectNode::ServerCauseSideEffect(const struct FConversationContext& Context_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonConversationRuntime.ConversationSideEffectNode.ServerCauseSideEffect"));

	ConversationSideEffectNode_ServerCauseSideEffect_Params params;
	params.Context_69 = Context_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonConversationRuntime.ConversationSideEffectNode.ClientCauseSideEffect
// (BlueprintCosmetic, Native, Event, Protected, HasOutParms, BlueprintEvent, Const)
// Parameters:
// struct FConversationContext    Context_69                     (ConstParm, Parm, OutParm, ReferenceParm)

void ConversationSideEffectNode::ClientCauseSideEffect(const struct FConversationContext& Context_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonConversationRuntime.ConversationSideEffectNode.ClientCauseSideEffect"));

	ConversationSideEffectNode_ClientCauseSideEffect_Params params;
	params.Context_69 = Context_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

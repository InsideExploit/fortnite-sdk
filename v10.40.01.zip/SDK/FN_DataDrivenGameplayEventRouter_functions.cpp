// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Functions
//---------------------------------------------------------------------------

// Function DataDrivenGameplayEventRouter.GameplayEventDescriptorLibrary.BroadcastEvent
// (Final, Native, Static, Private, HasOutParms, BlueprintCallable)
// Parameters:
// struct FGameplayEventDescriptor EventDescriptor_69             (ConstParm, Parm, OutParm, ReferenceParm)
// class Object_32759*            EventContext_69                (Parm, ZeroConstructor)
// int                            Event_69                       (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
// class Object_32759*            EventRouterScope_69            (Parm, ZeroConstructor)
// class Actor_32759*             RouterContextActor_69          (Parm, ZeroConstructor)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool GameplayEventDescriptorLibrary::STATIC_BroadcastEvent(const struct FGameplayEventDescriptor& EventDescriptor_69, class Object_32759* EventContext_69, int Event_69, class Object_32759* EventRouterScope_69, class Actor_32759* RouterContextActor_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DataDrivenGameplayEventRouter.GameplayEventDescriptorLibrary.BroadcastEvent"));

	GameplayEventDescriptorLibrary_BroadcastEvent_Params params;
	params.EventDescriptor_69 = EventDescriptor_69;
	params.EventContext_69 = EventContext_69;
	params.Event_69 = Event_69;
	params.EventRouterScope_69 = EventRouterScope_69;
	params.RouterContextActor_69 = RouterContextActor_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Classes
//---------------------------------------------------------------------------

// Class CreativeEditCameraModeRuntime.FortPawnComponent_CreativeEditCameraMode
// 0x0050 (0x00F0 - 0x00A0)
class FortPawnComponent_CreativeEditCameraMode : public FortPawnComponent
{
public:
	float                                              CameraBlendSwitchMeshTime_69;                             // 0x00A0(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x00A4(0x0004) MISSED OFFSET
	class FortCameraMode*                              ImmersiveCameraModeClass_69;                              // 0x00A8(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance)
	struct FCreativeOptionVariableBase                 WantsToImmersiveEdit_69;                                  // 0x00B0(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, DisableEditOnInstance)
	bool                                               bIsImmersiveModeEnabled_69;                               // 0x00B8(0x0001) (Net, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x37];                                      // 0x00B9(0x0037) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CreativeEditCameraModeRuntime.FortPawnComponent_CreativeEditCameraMode"));
		
		return ptr;
	}


	void ServerSetImmersiveEdit(bool bWantsToImmersiveEdit_69, bool bIsCreativeEditModeEnabled_69);
	void RestrictImmersiveMode();
	void OnWantsToImmersiveEditChanged(class FortCreativeOption* CreativeOption_69, unsigned char IndexValue_69);
	void OnRep_IsImmersiveModeEnabled();
	void OnCreativeEditModeChanged(bool bIsCreativeEditModeEnabled_69);
	void HandleWeaponEquipped(class FortWeapon* NewWeapon_69, class FortWeapon* PrevWeapon_69);
	void BindVehicleEvents(class Pawn* Pawn_69, class Controller* OldController_69, class Controller* NewController_69);
	void AllowImmersiveMode();
};


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

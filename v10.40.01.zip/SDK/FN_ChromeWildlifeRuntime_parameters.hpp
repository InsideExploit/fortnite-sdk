#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function ChromeWildlifeRuntime.FortAthenaChromeWildlifeTelemetryData.SetIsChromed
struct FortAthenaChromeWildlifeTelemetryData_SetIsChromed_Params
{
	bool                                               bInIsChromed_69;                                          // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Functions
//---------------------------------------------------------------------------

// Function AnnualRefundTokenUI.FortAnnualRefundTicket.OnUpdatePendingState
// (Event, Public, BlueprintEvent)
// Parameters:
// bool                           bIsPending_69                  (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void FortAnnualRefundTicket::OnUpdatePendingState(bool bIsPending_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AnnualRefundTokenUI.FortAnnualRefundTicket.OnUpdatePendingState"));

	FortAnnualRefundTicket_OnUpdatePendingState_Params params;
	params.bIsPending_69 = bIsPending_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AnnualRefundTokenUI.FortAnnualRefundTicket.OnUpdateAvailableState
// (Event, Public, BlueprintEvent)
// Parameters:
// bool                           bIsAvailable_69                (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void FortAnnualRefundTicket::OnUpdateAvailableState(bool bIsAvailable_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AnnualRefundTokenUI.FortAnnualRefundTicket.OnUpdateAvailableState"));

	FortAnnualRefundTicket_OnUpdateAvailableState_Params params;
	params.bIsAvailable_69 = bIsAvailable_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AnnualRefundTokenUI.FortAnnualRefundTicket.OnPlayLockingAnimation
// (Event, Public, BlueprintEvent)

void FortAnnualRefundTicket::OnPlayLockingAnimation()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AnnualRefundTokenUI.FortAnnualRefundTicket.OnPlayLockingAnimation"));

	FortAnnualRefundTicket_OnPlayLockingAnimation_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AnnualRefundTokenUI.FortPurchaseHistoryEntry.UpdateItemList
// (Event, Protected, HasOutParms, BlueprintEvent)
// Parameters:
// TArray<class FortCosmeticItemCard*> ItemCards_69                   (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)

void FortPurchaseHistoryEntry::UpdateItemList(TArray<class FortCosmeticItemCard*> ItemCards_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AnnualRefundTokenUI.FortPurchaseHistoryEntry.UpdateItemList"));

	FortPurchaseHistoryEntry_UpdateItemList_Params params;
	params.ItemCards_69 = ItemCards_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AnnualRefundTokenUI.FortPurchaseHistoryEntry.SetupItemCard
// (Event, Protected, BlueprintEvent)
// Parameters:
// class FortCosmeticItemCard*    ItemCard_69                    (ConstParm, Parm, ZeroConstructor, InstancedReference)
// class FortItem*                Item_69                        (ConstParm, Parm, ZeroConstructor)

void FortPurchaseHistoryEntry::SetupItemCard(class FortCosmeticItemCard* ItemCard_69, class FortItem* Item_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AnnualRefundTokenUI.FortPurchaseHistoryEntry.SetupItemCard"));

	FortPurchaseHistoryEntry_SetupItemCard_Params params;
	params.ItemCard_69 = ItemCard_69;
	params.Item_69 = Item_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AnnualRefundTokenUI.FortPurchaseHistoryEntry.SetPurchaseText
// (Event, Protected, HasOutParms, BlueprintEvent)
// Parameters:
// struct FText                   PurchaseDateText_69            (ConstParm, Parm, OutParm, ReferenceParm)
// struct FText                   RefundDateText_69              (ConstParm, Parm, OutParm, ReferenceParm)
// bool                           bHasBeenRefunded_69            (Parm, ZeroConstructor, IsPlainOldData)
// EFortPurchaseHistoryRefundType RefundType_69                  (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void FortPurchaseHistoryEntry::SetPurchaseText(const struct FText& PurchaseDateText_69, const struct FText& RefundDateText_69, bool bHasBeenRefunded_69, EFortPurchaseHistoryRefundType RefundType_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AnnualRefundTokenUI.FortPurchaseHistoryEntry.SetPurchaseText"));

	FortPurchaseHistoryEntry_SetPurchaseText_Params params;
	params.PurchaseDateText_69 = PurchaseDateText_69;
	params.RefundDateText_69 = RefundDateText_69;
	params.bHasBeenRefunded_69 = bHasBeenRefunded_69;
	params.RefundType_69 = RefundType_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AnnualRefundTokenUI.FortPurchaseHistoryEntry.OnSetHistory
// (Event, Protected, BlueprintEvent)
// Parameters:
// bool                           bHasBeenRefunded_69            (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bIsTokenlessRefund_69          (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bPlayerHasTokens_69            (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bNonRefundable_69              (Parm, ZeroConstructor, IsPlainOldData)

void FortPurchaseHistoryEntry::OnSetHistory(bool bHasBeenRefunded_69, bool bIsTokenlessRefund_69, bool bPlayerHasTokens_69, bool bNonRefundable_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AnnualRefundTokenUI.FortPurchaseHistoryEntry.OnSetHistory"));

	FortPurchaseHistoryEntry_OnSetHistory_Params params;
	params.bHasBeenRefunded_69 = bHasBeenRefunded_69;
	params.bIsTokenlessRefund_69 = bIsTokenlessRefund_69;
	params.bPlayerHasTokens_69 = bPlayerHasTokens_69;
	params.bNonRefundable_69 = bNonRefundable_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AnnualRefundTokenUI.FortPurchaseHistoryScreen.OnPopulateView
// (Event, Protected, BlueprintEvent)

void FortPurchaseHistoryScreen::OnPopulateView()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AnnualRefundTokenUI.FortPurchaseHistoryScreen.OnPopulateView"));

	FortPurchaseHistoryScreen_OnPopulateView_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AnnualRefundTokenUI.FortPurchaseHistoryScreen.OnNoPurchasesAvailable
// (Event, Protected, BlueprintEvent)

void FortPurchaseHistoryScreen::OnNoPurchasesAvailable()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AnnualRefundTokenUI.FortPurchaseHistoryScreen.OnNoPurchasesAvailable"));

	FortPurchaseHistoryScreen_OnNoPurchasesAvailable_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AnnualRefundTokenUI.FortPurchaseHistoryScreen.OnEndRefundSubmission
// (Event, Protected, BlueprintEvent)

void FortPurchaseHistoryScreen::OnEndRefundSubmission()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AnnualRefundTokenUI.FortPurchaseHistoryScreen.OnEndRefundSubmission"));

	FortPurchaseHistoryScreen_OnEndRefundSubmission_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AnnualRefundTokenUI.FortPurchaseHistoryScreen.OnBeginRefundSubmission
// (Event, Protected, BlueprintEvent)

void FortPurchaseHistoryScreen::OnBeginRefundSubmission()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AnnualRefundTokenUI.FortPurchaseHistoryScreen.OnBeginRefundSubmission"));

	FortPurchaseHistoryScreen_OnBeginRefundSubmission_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AnnualRefundTokenUI.FortPurchaseHistoryScreen.BP_IsShowingPurchases
// (Event, Protected, BlueprintEvent)
// Parameters:
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool FortPurchaseHistoryScreen::BP_IsShowingPurchases()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AnnualRefundTokenUI.FortPurchaseHistoryScreen.BP_IsShowingPurchases"));

	FortPurchaseHistoryScreen_BP_IsShowingPurchases_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AnnualRefundTokenUI.FortRefundConfirmation.BP_UpdateRefundType
// (Event, Protected, BlueprintEvent)
// Parameters:
// EFortPurchaseHistoryRefundType RefundType_69                  (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void FortRefundConfirmation::BP_UpdateRefundType(EFortPurchaseHistoryRefundType RefundType_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AnnualRefundTokenUI.FortRefundConfirmation.BP_UpdateRefundType"));

	FortRefundConfirmation_BP_UpdateRefundType_Params params;
	params.RefundType_69 = RefundType_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AnnualRefundTokenUI.FortRefundConfirmation.BP_UpdateItemsList
// (Event, Protected, HasOutParms, BlueprintEvent)
// Parameters:
// TArray<class FortItemDefinition*> SelectedItemDefs_69            (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
// int                            TotalMtxPaid_69                (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void FortRefundConfirmation::BP_UpdateItemsList(TArray<class FortItemDefinition*> SelectedItemDefs_69, int TotalMtxPaid_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AnnualRefundTokenUI.FortRefundConfirmation.BP_UpdateItemsList"));

	FortRefundConfirmation_BP_UpdateItemsList_Params params;
	params.SelectedItemDefs_69 = SelectedItemDefs_69;
	params.TotalMtxPaid_69 = TotalMtxPaid_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

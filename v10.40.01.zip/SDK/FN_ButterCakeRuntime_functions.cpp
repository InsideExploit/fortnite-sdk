// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Functions
//---------------------------------------------------------------------------

// Function ButterCakeRuntime.ButterCakeUnstuckComponent.ResetUnstuckLocationSamples
// (Final, BlueprintAuthorityOnly, Native, Public, BlueprintCallable)

void ButterCakeUnstuckComponent::ResetUnstuckLocationSamples()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ButterCakeRuntime.ButterCakeUnstuckComponent.ResetUnstuckLocationSamples"));

	ButterCakeUnstuckComponent_ResetUnstuckLocationSamples_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ButterCakeRuntime.ButterCakeUnstuckComponent.HandleAthenaGamePhaseChanged
// (Final, Native, Private)
// Parameters:
// EAthenaGamePhase               GamePhase_69                   (Parm, ZeroConstructor, IsPlainOldData)

void ButterCakeUnstuckComponent::HandleAthenaGamePhaseChanged(EAthenaGamePhase GamePhase_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ButterCakeRuntime.ButterCakeUnstuckComponent.HandleAthenaGamePhaseChanged"));

	ButterCakeUnstuckComponent_HandleAthenaGamePhaseChanged_Params params;
	params.GamePhase_69 = GamePhase_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ButterCakeRuntime.FortAIAnimInstance_ButterCake.SetFootPhaseMembers
// (Final, Native, Public, BlueprintCallable)

void FortAIAnimInstance_ButterCake::SetFootPhaseMembers()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ButterCakeRuntime.FortAIAnimInstance_ButterCake.SetFootPhaseMembers"));

	FortAIAnimInstance_ButterCake_SetFootPhaseMembers_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ButterCakeRuntime.FortAIAnimInstance_ButterCake.ComputeLeanAngleByVelocity
// (Final, Native, Public, BlueprintCallable, BlueprintPure)
// Parameters:
// float                          ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

float FortAIAnimInstance_ButterCake::ComputeLeanAngleByVelocity()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ButterCakeRuntime.FortAIAnimInstance_ButterCake.ComputeLeanAngleByVelocity"));

	FortAIAnimInstance_ButterCake_ComputeLeanAngleByVelocity_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ButterCakeRuntime.FortAIAnimInstance_ButterCake.ComputeFootPhase
// (Final, Native, Public, BlueprintCallable, BlueprintPure)
// Parameters:
// EFortButterCakeFootPhase       ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

EFortButterCakeFootPhase FortAIAnimInstance_ButterCake::ComputeFootPhase()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ButterCakeRuntime.FortAIAnimInstance_ButterCake.ComputeFootPhase"));

	FortAIAnimInstance_ButterCake_ComputeFootPhase_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ButterCakeRuntime.FortButterCakeComponent_Telemetry.OnLured
// (Final, Native, Public, BlueprintCallable)

void FortButterCakeComponent_Telemetry::OnLured()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ButterCakeRuntime.FortButterCakeComponent_Telemetry.OnLured"));

	FortButterCakeComponent_Telemetry_OnLured_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ButterCakeRuntime.FortButterCakeComponent_Telemetry.OnItemsSneezed
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// int                            ItemsCount_69                  (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void FortButterCakeComponent_Telemetry::OnItemsSneezed(int ItemsCount_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ButterCakeRuntime.FortButterCakeComponent_Telemetry.OnItemsSneezed"));

	FortButterCakeComponent_Telemetry_OnItemsSneezed_Params params;
	params.ItemsCount_69 = ItemsCount_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ButterCakeRuntime.FortButterCakeComponent_Telemetry.OnItemsEaten
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// int                            ItemsCount_69                  (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void FortButterCakeComponent_Telemetry::OnItemsEaten(int ItemsCount_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ButterCakeRuntime.FortButterCakeComponent_Telemetry.OnItemsEaten"));

	FortButterCakeComponent_Telemetry_OnItemsEaten_Params params;
	params.ItemsCount_69 = ItemsCount_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ButterCakeRuntime.FortButterCakeComponent_Telemetry.OnEnterBerserk
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// class Controller*              Instigator_69                  (ConstParm, Parm, ZeroConstructor)

void FortButterCakeComponent_Telemetry::OnEnterBerserk(class Controller* Instigator_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ButterCakeRuntime.FortButterCakeComponent_Telemetry.OnEnterBerserk"));

	FortButterCakeComponent_Telemetry_OnEnterBerserk_Params params;
	params.Instigator_69 = Instigator_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ButterCakeRuntime.FortButterCakeComponent_Telemetry.OnBlowHoleUsed
// (Final, Native, Public, BlueprintCallable)

void FortButterCakeComponent_Telemetry::OnBlowHoleUsed()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ButterCakeRuntime.FortButterCakeComponent_Telemetry.OnBlowHoleUsed"));

	FortButterCakeComponent_Telemetry_OnBlowHoleUsed_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ButterCakeRuntime.FortButterCakeControlRig.GetGroundHitNormalAt
// (Final, Native, Public, HasDefaults, BlueprintCallable)
// Parameters:
// int                            Index_69                       (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// struct FVector                 ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

struct FVector FortButterCakeControlRig::GetGroundHitNormalAt(int Index_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ButterCakeRuntime.FortButterCakeControlRig.GetGroundHitNormalAt"));

	FortButterCakeControlRig_GetGroundHitNormalAt_Params params;
	params.Index_69 = Index_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ButterCakeRuntime.FortButterCakeControlRig.GetGroundHitLocationAt
// (Final, Native, Public, HasDefaults, BlueprintCallable)
// Parameters:
// int                            Index_69                       (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// struct FVector                 ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

struct FVector FortButterCakeControlRig::GetGroundHitLocationAt(int Index_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ButterCakeRuntime.FortButterCakeControlRig.GetGroundHitLocationAt"));

	FortButterCakeControlRig_GetGroundHitLocationAt_Params params;
	params.Index_69 = Index_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Classes
//---------------------------------------------------------------------------

// Class AudioMixer.SynthComponent
// 0x04E0 (0x0780 - 0x02A0)
class SynthComponent : public SceneComponent
{
public:
	unsigned char                                      bAutoDestroy_69 : 1;                                      // 0x02A0(0x0001)
	unsigned char                                      bStopWhenOwnerDestroyed_69 : 1;                           // 0x02A0(0x0001)
	unsigned char                                      bAllowSpatialization_69 : 1;                              // 0x02A0(0x0001) (Edit, BlueprintVisible)
	unsigned char                                      bOverrideAttenuation_69 : 1;                              // 0x02A0(0x0001) (Edit, BlueprintVisible)
	unsigned char                                      UnknownData00[0x3];                                       // 0x02A1(0x0003) MISSED OFFSET
	unsigned char                                      bEnableBusSends_69 : 1;                                   // 0x02A4(0x0001) (Edit, BlueprintVisible)
	unsigned char                                      bEnableBaseSubmix_69 : 1;                                 // 0x02A4(0x0001) (Edit)
	unsigned char                                      bEnableSubmixSends_69 : 1;                                // 0x02A4(0x0001) (Edit)
	unsigned char                                      UnknownData01[0x3];                                       // 0x02A5(0x0003) MISSED OFFSET
	class SoundAttenuation*                            AttenuationSettings_69;                                   // 0x02A8(0x0008) (Edit, BlueprintVisible, ZeroConstructor)
	struct FSoundAttenuationSettings                   AttenuationOverrides_69;                                  // 0x02B0(0x03B8) (Edit, BlueprintVisible)
	class SoundConcurrency*                            ConcurrencySettings_69;                                   // 0x0668(0x0008) (ZeroConstructor, Deprecated)
	unsigned char                                      UnknownData02[0x50];                                      // 0x0670(0x0050) UNKNOWN PROPERTY: SetProperty AudioMixer.SynthComponent.ConcurrencySet_69
	class SoundClass*                                  SoundClass_69;                                            // 0x06C0(0x0008) (Edit, ZeroConstructor)
	class SoundEffectSourcePresetChain*                SourceEffectChain_69;                                     // 0x06C8(0x0008) (Edit, ZeroConstructor)
	class SoundSubmixBase*                             SoundSubmix_69;                                           // 0x06D0(0x0008) (Edit, ZeroConstructor)
	TArray<struct FSoundSubmixSendInfo>                SoundSubmixSends_69;                                      // 0x06D8(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	TArray<struct FSoundSourceBusSendInfo>             BusSends_69;                                              // 0x06E8(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	TArray<struct FSoundSourceBusSendInfo>             PreEffectBusSends_69;                                     // 0x06F8(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	unsigned char                                      bIsUISound_69 : 1;                                        // 0x0708(0x0001) (Edit, BlueprintVisible)
	unsigned char                                      bIsPreviewSound_69 : 1;                                   // 0x0708(0x0001)
	unsigned char                                      UnknownData03[0x3];                                       // 0x0709(0x0003) MISSED OFFSET
	int                                                EnvelopeFollowerAttackTime_69;                            // 0x070C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                EnvelopeFollowerReleaseTime_69;                           // 0x0710(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData04[0x4];                                       // 0x0714(0x0004) MISSED OFFSET
	unsigned char                                      UnknownData05[0x10];                                      // 0x0714(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty AudioMixer.SynthComponent.OnAudioEnvelopeValue_69
	unsigned char                                      UnknownData06[0x20];                                      // 0x0728(0x0020) MISSED OFFSET
	class SynthSound_32759*                            Synth_69;                                                 // 0x0748(0x0008) (ZeroConstructor, Transient)
	class AudioComponent*                              AudioComponent_69;                                        // 0x0750(0x0008) (ExportObject, ZeroConstructor, Transient, InstancedReference)
	unsigned char                                      UnknownData07[0x28];                                      // 0x0758(0x0028) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AudioMixer.SynthComponent"));
		
		return ptr;
	}


	void Stop();
	void Start();
	void SetVolumeMultiplier(float VolumeMultiplier_69);
	void SetSubmixSend(class SoundSubmixBase* Submix_69, float SendLevel_69);
	void SetOutputToBusOnly(bool bInOutputToBusOnly_69);
	void SetLowPassFilterFrequency(float InLowPassFilterFrequency_69);
	void SetLowPassFilterEnabled(bool InLowPassFilterEnabled_69);
	bool IsPlaying();
	void FadeOut(float FadeOutDuration_69, float FadeVolumeLevel_69, EAudioFaderCurve FadeCurve_69);
	void FadeIn(float FadeInDuration_69, float FadeVolumeLevel_69, float StartTime_69, EAudioFaderCurve FadeCurve_69);
	void AdjustVolume(float AdjustVolumeDuration_69, float AdjustVolumeLevel_69, EAudioFaderCurve FadeCurve_69);
};


// Class AudioMixer.AudioDeviceNotificationSubsystem
// 0x00F8 (0x0128 - 0x0030)
class AudioDeviceNotificationSubsystem : public EngineSubsystem
{
public:
	unsigned char                                      UnknownData00[0x8];                                       // 0x0030(0x0008) MISSED OFFSET
	unsigned char                                      UnknownData01[0x10];                                      // 0x0030(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty AudioMixer.AudioDeviceNotificationSubsystem.DefaultCaptureDeviceChanged_69
	unsigned char                                      UnknownData02[0x18];                                      // 0x0048(0x0018) MISSED OFFSET
	unsigned char                                      UnknownData03[0x10];                                      // 0x0048(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty AudioMixer.AudioDeviceNotificationSubsystem.DefaultRenderDeviceChanged_69
	unsigned char                                      UnknownData04[0x18];                                      // 0x0070(0x0018) MISSED OFFSET
	unsigned char                                      UnknownData05[0x10];                                      // 0x0070(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty AudioMixer.AudioDeviceNotificationSubsystem.DeviceAdded_69
	unsigned char                                      UnknownData06[0x18];                                      // 0x0098(0x0018) MISSED OFFSET
	unsigned char                                      UnknownData07[0x10];                                      // 0x0098(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty AudioMixer.AudioDeviceNotificationSubsystem.DeviceRemoved_69
	unsigned char                                      UnknownData08[0x18];                                      // 0x00C0(0x0018) MISSED OFFSET
	unsigned char                                      UnknownData09[0x10];                                      // 0x00C0(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty AudioMixer.AudioDeviceNotificationSubsystem.DeviceStateChanged_69
	unsigned char                                      UnknownData10[0x18];                                      // 0x00E8(0x0018) MISSED OFFSET
	unsigned char                                      UnknownData11[0x10];                                      // 0x00E8(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty AudioMixer.AudioDeviceNotificationSubsystem.DeviceSwitched_69
	unsigned char                                      UnknownData12[0x18];                                      // 0x0110(0x0018) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AudioMixer.AudioDeviceNotificationSubsystem"));
		
		return ptr;
	}

};


// Class AudioMixer.AudioMixerBlueprintLibrary
// 0x0000 (0x0028 - 0x0028)
class AudioMixerBlueprintLibrary : public BlueprintFunctionLibrary
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AudioMixer.AudioMixerBlueprintLibrary"));
		
		return ptr;
	}


	float STATIC_TrimAudioCache(float InMegabytesToFree_69);
	void STATIC_SwapAudioOutputDevice(class Object_32759* WorldContextObject_69, const struct FString& NewDeviceId_69, const struct FScriptDelegate& OnCompletedDeviceSwap_69);
	class SoundWave* STATIC_StopRecordingOutput(class Object_32759* WorldContextObject_69, EAudioRecordingExportType ExportType_69, const struct FString& Name_69, const struct FString& Path_69, class SoundSubmix* SubmixToRecord_69, class SoundWave* ExistingSoundWaveToOverwrite_69);
	void STATIC_StopAudioBus(class Object_32759* WorldContextObject_69, class AudioBus* AudioBus_69);
	void STATIC_StopAnalyzingOutput(class Object_32759* WorldContextObject_69, class SoundSubmix* SubmixToStopAnalyzing_69);
	void STATIC_StartRecordingOutput(class Object_32759* WorldContextObject_69, float ExpectedDuration_69, class SoundSubmix* SubmixToRecord_69);
	void STATIC_StartAudioBus(class Object_32759* WorldContextObject_69, class AudioBus* AudioBus_69);
	void STATIC_StartAnalyzingOutput(class Object_32759* WorldContextObject_69, class SoundSubmix* SubmixToAnalyze_69, EFFTSize FFTSize_69, EFFTPeakInterpolationMethod InterpolationMethod_69, EFFTWindowType WindowType_69, float HopSize_69, EAudioSpectrumType SpectrumType_69);
	void STATIC_SetSubmixEffectChainOverride(class Object_32759* WorldContextObject_69, class SoundSubmix* SoundSubmix_69, TArray<class SoundEffectSubmixPreset*> SubmixEffectPresetChain_69, float FadeTimeSec_69);
	void STATIC_SetBypassSourceEffectChainEntry(class Object_32759* WorldContextObject_69, class SoundEffectSourcePresetChain* PresetChain_69, int EntryIndex_69, bool bBypassed_69);
	void STATIC_ResumeRecordingOutput(class Object_32759* WorldContextObject_69, class SoundSubmix* SubmixToPause_69);
	void STATIC_ReplaceSubmixEffect(class Object_32759* WorldContextObject_69, class SoundSubmix* InSoundSubmix_69, int SubmixChainIndex_69, class SoundEffectSubmixPreset* SubmixEffectPreset_69);
	void STATIC_ReplaceSoundEffectSubmix(class Object_32759* WorldContextObject_69, class SoundSubmix* InSoundSubmix_69, int SubmixChainIndex_69, class SoundEffectSubmixPreset* SubmixEffectPreset_69);
	void STATIC_RemoveSubmixEffectPresetAtIndex(class Object_32759* WorldContextObject_69, class SoundSubmix* SoundSubmix_69, int SubmixChainIndex_69);
	void STATIC_RemoveSubmixEffectPreset(class Object_32759* WorldContextObject_69, class SoundSubmix* SoundSubmix_69, class SoundEffectSubmixPreset* SubmixEffectPreset_69);
	void STATIC_RemoveSubmixEffectAtIndex(class Object_32759* WorldContextObject_69, class SoundSubmix* SoundSubmix_69, int SubmixChainIndex_69);
	void STATIC_RemoveSubmixEffect(class Object_32759* WorldContextObject_69, class SoundSubmix* SoundSubmix_69, class SoundEffectSubmixPreset* SubmixEffectPreset_69);
	void STATIC_RemoveSourceEffectFromPresetChain(class Object_32759* WorldContextObject_69, class SoundEffectSourcePresetChain* PresetChain_69, int EntryIndex_69);
	void STATIC_RemoveMasterSubmixEffect(class Object_32759* WorldContextObject_69, class SoundEffectSubmixPreset* SubmixEffectPreset_69);
	void STATIC_PrimeSoundForPlayback(class SoundWave* SoundWave_69, const struct FScriptDelegate& OnLoadCompletion_69);
	void STATIC_PrimeSoundCueForPlayback(class SoundCue* SoundCue_69);
	void STATIC_PauseRecordingOutput(class Object_32759* WorldContextObject_69, class SoundSubmix* SubmixToPause_69);
	TArray<struct FSoundSubmixSpectralAnalysisBandSettings> STATIC_MakePresetSpectralAnalysisBandSettings(EAudioSpectrumBandPresetType InBandPresetType_69, int InNumBands_69, int InAttackTimeMsec_69, int InReleaseTimeMsec_69);
	TArray<struct FSoundSubmixSpectralAnalysisBandSettings> STATIC_MakeMusicalSpectralAnalysisBandSettings(int InNumSemitones_69, EMusicalNoteName InStartingMusicalNote_69, int InStartingOctave_69, int InAttackTimeMsec_69, int InReleaseTimeMsec_69);
	TArray<struct FSoundSubmixSpectralAnalysisBandSettings> STATIC_MakeFullSpectrumSpectralAnalysisBandSettings(int InNumBands_69, float InMinimumFrequency_69, float InMaximumFrequency_69, int InAttackTimeMsec_69, int InReleaseTimeMsec_69);
	bool STATIC_IsAudioBusActive(class Object_32759* WorldContextObject_69, class AudioBus* AudioBus_69);
	void STATIC_GetPhaseForFrequencies(class Object_32759* WorldContextObject_69, TArray<float> Frequencies_69, class SoundSubmix* SubmixToAnalyze_69, TArray<float>* Phases_69);
	int STATIC_GetNumberOfEntriesInSourceEffectChain(class Object_32759* WorldContextObject_69, class SoundEffectSourcePresetChain* PresetChain_69);
	void STATIC_GetMagnitudeForFrequencies(class Object_32759* WorldContextObject_69, TArray<float> Frequencies_69, class SoundSubmix* SubmixToAnalyze_69, TArray<float>* Magnitudes_69);
	void STATIC_GetCurrentAudioOutputDeviceName(class Object_32759* WorldContextObject_69, const struct FScriptDelegate& OnObtainCurrentDeviceEvent_69);
	void STATIC_GetAvailableAudioOutputDevices(class Object_32759* WorldContextObject_69, const struct FScriptDelegate& OnObtainDevicesEvent_69);
	struct FString STATIC_Conv_AudioOutputDeviceInfoToString(const struct FAudioOutputDeviceInfo& Info_69);
	void STATIC_ClearSubmixEffects(class Object_32759* WorldContextObject_69, class SoundSubmix* SoundSubmix_69);
	void STATIC_ClearSubmixEffectChainOverride(class Object_32759* WorldContextObject_69, class SoundSubmix* SoundSubmix_69, float FadeTimeSec_69);
	void STATIC_ClearMasterSubmixEffects(class Object_32759* WorldContextObject_69);
	int STATIC_AddSubmixEffect(class Object_32759* WorldContextObject_69, class SoundSubmix* SoundSubmix_69, class SoundEffectSubmixPreset* SubmixEffectPreset_69);
	void STATIC_AddSourceEffectToPresetChain(class Object_32759* WorldContextObject_69, class SoundEffectSourcePresetChain* PresetChain_69, const struct FSourceEffectChainEntry& Entry_69);
	void STATIC_AddMasterSubmixEffect(class Object_32759* WorldContextObject_69, class SoundEffectSubmixPreset* SubmixEffectPreset_69);
};


// Class AudioMixer.SynthSound_32759
// 0x0020 (0x0380 - 0x0360)
class SynthSound_32759 : public SoundWaveProcedural
{
public:
	TWeakObjectPtr<class SynthComponent>               OwningSynthComponent_69;                                  // 0x0360(0x0008) (ExportObject, ZeroConstructor, InstancedReference, IsPlainOldData)
	unsigned char                                      UnknownData00[0x18];                                      // 0x0368(0x0018) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AudioMixer.SynthSound_32759"));
		
		return ptr;
	}

};


// Class AudioMixer.SubmixEffectDynamicsProcessorPreset
// 0x00E8 (0x0150 - 0x0068)
class SubmixEffectDynamicsProcessorPreset : public SoundEffectSubmixPreset
{
public:
	unsigned char                                      UnknownData00[0x88];                                      // 0x0068(0x0088) MISSED OFFSET
	struct FSubmixEffectDynamicsProcessorSettings      Settings_69;                                              // 0x00F0(0x0060) (Edit, BlueprintVisible)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AudioMixer.SubmixEffectDynamicsProcessorPreset"));
		
		return ptr;
	}


	void SetSettings(const struct FSubmixEffectDynamicsProcessorSettings& Settings_69);
	void SetExternalSubmix(class SoundSubmix* Submix_69);
	void SetAudioBus(class AudioBus* AudioBus_69);
	void ResetKey();
};


// Class AudioMixer.SubmixEffectSubmixEQPreset
// 0x0048 (0x00B0 - 0x0068)
class SubmixEffectSubmixEQPreset : public SoundEffectSubmixPreset
{
public:
	unsigned char                                      UnknownData00[0x38];                                      // 0x0068(0x0038) MISSED OFFSET
	struct FSubmixEffectSubmixEQSettings               Settings_69;                                              // 0x00A0(0x0010) (Edit, BlueprintVisible)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AudioMixer.SubmixEffectSubmixEQPreset"));
		
		return ptr;
	}


	void SetSettings(const struct FSubmixEffectSubmixEQSettings& InSettings_69);
};


// Class AudioMixer.SubmixEffectReverbPreset
// 0x00A8 (0x0110 - 0x0068)
class SubmixEffectReverbPreset : public SoundEffectSubmixPreset
{
public:
	unsigned char                                      UnknownData00[0x68];                                      // 0x0068(0x0068) MISSED OFFSET
	struct FSubmixEffectReverbSettings                 Settings_69;                                              // 0x00D0(0x0040) (Edit, BlueprintVisible)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AudioMixer.SubmixEffectReverbPreset"));
		
		return ptr;
	}


	void SetSettingsWithReverbEffect(class ReverbEffect* InReverbEffect_69, float WetLevel_69, float DryLevel_69);
	void SetSettings(const struct FSubmixEffectReverbSettings& InSettings_69);
};


// Class AudioMixer.AudioGenerator
// 0x0080 (0x00A8 - 0x0028)
class AudioGenerator : public Object_32759
{
public:
	unsigned char                                      UnknownData00[0x80];                                      // 0x0028(0x0080) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AudioMixer.AudioGenerator"));
		
		return ptr;
	}

};


// Class AudioMixer.QuartzClockHandle
// 0x01C0 (0x01E8 - 0x0028)
class QuartzClockHandle : public Object_32759
{
public:
	unsigned char                                      UnknownData00[0x1C0];                                     // 0x0028(0x01C0) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AudioMixer.QuartzClockHandle"));
		
		return ptr;
	}


	void UnsubscribeFromTimeDivision(class Object_32759* WorldContextObject_69, EQuartzCommandQuantization InQuantizationBoundary_69, class QuartzClockHandle** ClockHandle_69);
	void UnsubscribeFromAllTimeDivisions(class Object_32759* WorldContextObject_69, class QuartzClockHandle** ClockHandle_69);
	void SubscribeToQuantizationEvent(class Object_32759* WorldContextObject_69, EQuartzCommandQuantization InQuantizationBoundary_69, const struct FScriptDelegate& OnQuantizationEvent_69, class QuartzClockHandle** ClockHandle_69);
	void SubscribeToAllQuantizationEvents(class Object_32759* WorldContextObject_69, const struct FScriptDelegate& OnQuantizationEvent_69, class QuartzClockHandle** ClockHandle_69);
	void StopClock(class Object_32759* WorldContextObject_69, bool CancelPendingEvents_69, class QuartzClockHandle** ClockHandle_69);
	void StartOtherClock(class Object_32759* WorldContextObject_69, const struct FName& OtherClockName_69, const struct FQuartzQuantizationBoundary& InQuantizationBoundary_69, const struct FScriptDelegate& InDelegate_69);
	void StartClock(class Object_32759* WorldContextObject_69, class QuartzClockHandle** ClockHandle_69);
	void SetTicksPerSecond(class Object_32759* WorldContextObject_69, const struct FQuartzQuantizationBoundary& QuantizationBoundary_69, const struct FScriptDelegate& Delegate_69, float TicksPerSecond_69, class QuartzClockHandle** ClockHandle_69);
	void SetThirtySecondNotesPerMinute(class Object_32759* WorldContextObject_69, const struct FQuartzQuantizationBoundary& QuantizationBoundary_69, const struct FScriptDelegate& Delegate_69, float ThirtySecondsNotesPerMinute_69, class QuartzClockHandle** ClockHandle_69);
	void SetSecondsPerTick(class Object_32759* WorldContextObject_69, const struct FQuartzQuantizationBoundary& QuantizationBoundary_69, const struct FScriptDelegate& Delegate_69, float SecondsPerTick_69, class QuartzClockHandle** ClockHandle_69);
	void SetMillisecondsPerTick(class Object_32759* WorldContextObject_69, const struct FQuartzQuantizationBoundary& QuantizationBoundary_69, const struct FScriptDelegate& Delegate_69, float MillisecondsPerTick_69, class QuartzClockHandle** ClockHandle_69);
	void SetBeatsPerMinute(class Object_32759* WorldContextObject_69, const struct FQuartzQuantizationBoundary& QuantizationBoundary_69, const struct FScriptDelegate& Delegate_69, float BeatsPerMinute_69, class QuartzClockHandle** ClockHandle_69);
	void ResumeClock(class Object_32759* WorldContextObject_69, class QuartzClockHandle** ClockHandle_69);
	void ResetTransportQuantized(class Object_32759* WorldContextObject_69, const struct FQuartzQuantizationBoundary& InQuantizationBoundary_69, const struct FScriptDelegate& InDelegate_69, class QuartzClockHandle** ClockHandle_69);
	void ResetTransport(class Object_32759* WorldContextObject_69, const struct FScriptDelegate& InDelegate_69);
	void PauseClock(class Object_32759* WorldContextObject_69, class QuartzClockHandle** ClockHandle_69);
	bool IsClockRunning(class Object_32759* WorldContextObject_69);
	float GetTicksPerSecond(class Object_32759* WorldContextObject_69);
	float GetThirtySecondNotesPerMinute(class Object_32759* WorldContextObject_69);
	float GetSecondsPerTick(class Object_32759* WorldContextObject_69);
	float GetMillisecondsPerTick(class Object_32759* WorldContextObject_69);
	float GetEstimatedRunTime(class Object_32759* WorldContextObject_69);
	float GetDurationOfQuantizationTypeInSeconds(class Object_32759* WorldContextObject_69, EQuartzCommandQuantization QuantizationType_69, float Multiplier_69);
	struct FQuartzTransportTimeStamp GetCurrentTimestamp(class Object_32759* WorldContextObject_69);
	float GetBeatsPerMinute(class Object_32759* WorldContextObject_69);
};


// Class AudioMixer.QuartzSubsystem
// 0x00A0 (0x00E0 - 0x0040)
class QuartzSubsystem : public TickableWorldSubsystem
{
public:
	unsigned char                                      UnknownData00[0xA0];                                      // 0x0040(0x00A0) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AudioMixer.QuartzSubsystem"));
		
		return ptr;
	}


	bool IsQuartzEnabled();
	bool IsClockRunning(class Object_32759* WorldContextObject_69, const struct FName& ClockName_69);
	float GetRoundTripMinLatency(class Object_32759* WorldContextObject_69);
	float GetRoundTripMaxLatency(class Object_32759* WorldContextObject_69);
	float GetRoundTripAverageLatency(class Object_32759* WorldContextObject_69);
	class QuartzClockHandle* GetHandleForClock(class Object_32759* WorldContextObject_69, const struct FName& ClockName_69);
	float GetGameThreadToAudioRenderThreadMinLatency(class Object_32759* WorldContextObject_69);
	float GetGameThreadToAudioRenderThreadMaxLatency(class Object_32759* WorldContextObject_69);
	float GetGameThreadToAudioRenderThreadAverageLatency(class Object_32759* WorldContextObject_69);
	float GetEstimatedClockRunTime(class Object_32759* WorldContextObject_69, const struct FName& InClockName_69);
	float GetDurationOfQuantizationTypeInSeconds(class Object_32759* WorldContextObject_69, const struct FName& ClockName_69, EQuartzCommandQuantization QuantizationType_69, float Multiplier_69);
	struct FQuartzTransportTimeStamp GetCurrentClockTimestamp(class Object_32759* WorldContextObject_69, const struct FName& InClockName_69);
	float GetAudioRenderThreadToGameThreadMinLatency();
	float GetAudioRenderThreadToGameThreadMaxLatency();
	float GetAudioRenderThreadToGameThreadAverageLatency();
	bool DoesClockExist(class Object_32759* WorldContextObject_69, const struct FName& ClockName_69);
	void DeleteClockByName(class Object_32759* WorldContextObject_69, const struct FName& ClockName_69);
	void DeleteClockByHandle(class Object_32759* WorldContextObject_69, class QuartzClockHandle** InClockHandle_69);
	class QuartzClockHandle* CreateNewClock(class Object_32759* WorldContextObject_69, const struct FName& ClockName_69, const struct FQuartzClockSettings& InSettings_69, bool bOverrideSettingsIfClockExists_69, bool bUseAudioEngineClockManager_69);
};


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Enums
//---------------------------------------------------------------------------

// Enum DataDrivenGameplayEventRouter.EGameplayEventNetPolicy
enum class EGameplayEventNetPolicy : uint8_t
{
	ServerOnly                     = 0,
	ClientOrServer                 = 1,
	EGameplayEventNetPolicy_MAX    = 2
};



//---------------------------------------------------------------------------
//Script Structs
//---------------------------------------------------------------------------

// ScriptStruct DataDrivenGameplayEventRouter.GameplayEventDescriptor
// 0x0008
struct FGameplayEventDescriptor
{
	unsigned char                                      UnknownData00[0x8];                                       // 0x0000(0x0008) MISSED OFFSET
};

// ScriptStruct DataDrivenGameplayEventRouter.GameplayEventDefinition
// 0x0010
struct FGameplayEventDefinition
{
	class ScriptStruct*                                EventType_69;                                             // 0x0000(0x0008) (Edit, ZeroConstructor, DisableEditOnInstance)
	bool                                               bIsStateful_69;                                           // 0x0008(0x0001) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	EGameplayEventNetPolicy                            NetPolicy_69;                                             // 0x0009(0x0001) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData00[0x6];                                       // 0x000A(0x0006) MISSED OFFSET
};

// ScriptStruct DataDrivenGameplayEventRouter.GameplayEventSubscription
// 0x0078
struct FGameplayEventSubscription
{
	unsigned char                                      UnknownData00[0x28];                                      // 0x0000(0x0028) UNKNOWN PROPERTY: SoftObjectProperty DataDrivenGameplayEventRouter.GameplayEventSubscription.Object_69
	struct FMemberReference                            EventDescriptor_69;                                       // 0x0028(0x0030) (Edit, SaveGame)
	struct FGameplayEventListenerHandle                EventHandle_69;                                           // 0x0058(0x001C) (Transient)
	unsigned char                                      UnknownData01[0x4];                                       // 0x0074(0x0004) MISSED OFFSET
};

// ScriptStruct DataDrivenGameplayEventRouter.GameplayEventHandlerFunction
// 0x0080
struct FGameplayEventHandlerFunction
{
	struct FMemberReference                            EventHandlerFunction_69;                                  // 0x0000(0x0030) (Edit)
	TMap<struct FName, struct FString>                 EventHandlerFunctionDefaultValues_69;                     // 0x0030(0x0050)
};

// ScriptStruct DataDrivenGameplayEventRouter.GameplayEventHandlerFunctions
// 0x0180
struct FGameplayEventHandlerFunctions
{
	struct FGameplayEventHandlerFunction               OnEventReceived_69;                                       // 0x0000(0x0080) (Edit)
	struct FGameplayEventHandlerFunction               OnStatefulEventApplied_69;                                // 0x0080(0x0080) (Edit)
	struct FGameplayEventHandlerFunction               OnStatefulEventCleared_69;                                // 0x0100(0x0080) (Edit)
};

// ScriptStruct DataDrivenGameplayEventRouter.GameplayEventFunction
// 0x0018
struct FGameplayEventFunction
{
	unsigned char                                      UnknownData00[0x8];                                       // 0x0000(0x0008) MISSED OFFSET
	TArray<struct FGameplayEventSubscription>          EventSubscriptions_69;                                    // 0x0008(0x0010) (Edit, ZeroConstructor, DisableEditOnTemplate, SaveGame)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

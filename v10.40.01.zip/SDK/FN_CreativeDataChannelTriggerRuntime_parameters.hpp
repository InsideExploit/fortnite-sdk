#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function CreativeDataChannelTriggerRuntime.CreativeDataChannelTarget.TestCreativeDataChannelTarget
struct CreativeDataChannelTarget_TestCreativeDataChannelTarget_Params
{
	struct FCreativeDataChannelEvents                  TestEvents_69;                                            // (Parm)
};

// Function CreativeDataChannelTriggerRuntime.CreativeDataChannelTarget.OnRep_Events
struct CreativeDataChannelTarget_OnRep_Events_Params
{
};

// Function CreativeDataChannelTriggerRuntime.CreativeDataChannelTarget.FireEvent
struct CreativeDataChannelTarget_FireEvent_Params
{
	struct FName                                       EventName_69;                                             // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function CreativeDataChannelTriggerRuntime.CreativeDataChannelTargetRL.ReportServerStateStreamError
struct CreativeDataChannelTargetRL_ReportServerStateStreamError_Params
{
	struct FString                                     Error_69;                                                 // (Parm, ZeroConstructor)
	struct FString                                     UID_69;                                                   // (Parm, ZeroConstructor)
	struct FString                                     URL_69;                                                   // (Parm, ZeroConstructor)
};

// Function CreativeDataChannelTriggerRuntime.CreativeDataChannelTargetRL.OnRep_VersionByte
struct CreativeDataChannelTargetRL_OnRep_VersionByte_Params
{
};

// Function CreativeDataChannelTriggerRuntime.CreativeDataChannelTargetRL.OnRep_TeamNames
struct CreativeDataChannelTargetRL_OnRep_TeamNames_Params
{
};

// Function CreativeDataChannelTriggerRuntime.CreativeDataChannelTargetRL.OnRep_SeriesState
struct CreativeDataChannelTargetRL_OnRep_SeriesState_Params
{
};

// Function CreativeDataChannelTriggerRuntime.CreativeDataChannelTargetRL.OnRep_ScoreTotal
struct CreativeDataChannelTargetRL_OnRep_ScoreTotal_Params
{
};

// Function CreativeDataChannelTriggerRuntime.CreativeDataChannelTargetRL.OnRep_ScoreTeam
struct CreativeDataChannelTargetRL_OnRep_ScoreTeam_Params
{
};

// Function CreativeDataChannelTriggerRuntime.CreativeDataChannelTargetRL.OnRep_ScoreboardTimeLeft
struct CreativeDataChannelTargetRL_OnRep_ScoreboardTimeLeft_Params
{
};

// Function CreativeDataChannelTriggerRuntime.CreativeDataChannelTargetRL.OnRep_ScoreboardBestOf
struct CreativeDataChannelTargetRL_OnRep_ScoreboardBestOf_Params
{
};

// Function CreativeDataChannelTriggerRuntime.CreativeDataChannelTargetRL.OnRep_PlayerNames
struct CreativeDataChannelTargetRL_OnRep_PlayerNames_Params
{
};

// Function CreativeDataChannelTriggerRuntime.CreativeDataChannelTargetRL.OnRep_PlayerCoords
struct CreativeDataChannelTargetRL_OnRep_PlayerCoords_Params
{
};

// Function CreativeDataChannelTriggerRuntime.CreativeDataChannelTargetRL.OnRep_PlayerBoostCollected
struct CreativeDataChannelTargetRL_OnRep_PlayerBoostCollected_Params
{
};

// Function CreativeDataChannelTriggerRuntime.CreativeDataChannelTargetRL.OnRep_PlayerBoost
struct CreativeDataChannelTargetRL_OnRep_PlayerBoost_Params
{
};

// Function CreativeDataChannelTriggerRuntime.CreativeDataChannelTargetRL.OnRep_Overtime
struct CreativeDataChannelTargetRL_OnRep_Overtime_Params
{
};

// Function CreativeDataChannelTriggerRuntime.CreativeDataChannelTargetRL.OnRep_MediaStop
struct CreativeDataChannelTargetRL_OnRep_MediaStop_Params
{
};

// Function CreativeDataChannelTriggerRuntime.CreativeDataChannelTargetRL.OnRep_MediaStart
struct CreativeDataChannelTargetRL_OnRep_MediaStart_Params
{
};

// Function CreativeDataChannelTriggerRuntime.CreativeDataChannelTargetRL.OnRep_MatchState
struct CreativeDataChannelTargetRL_OnRep_MatchState_Params
{
};

// Function CreativeDataChannelTriggerRuntime.CreativeDataChannelTargetRL.OnRep_FinaleState
struct CreativeDataChannelTargetRL_OnRep_FinaleState_Params
{
};

// Function CreativeDataChannelTriggerRuntime.CreativeDataChannelTargetRL.OnRep_BallCoords
struct CreativeDataChannelTargetRL_OnRep_BallCoords_Params
{
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

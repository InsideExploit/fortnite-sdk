#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Enums
//---------------------------------------------------------------------------

// Enum ChaosCloth.EChaosWeightMapTarget
enum class EChaosWeightMapTarget : uint8_t
{
	None                           = 0,
	MaxDistance                    = 1,
	BackstopDistance               = 2,
	BackstopRadius                 = 3,
	AnimDriveStiffness             = 4,
	AnimDriveDamping               = 5,
	TetherStiffness                = 6,
	TetherScale                    = 7,
	Drag                           = 8,
	Lift                           = 9,
	EdgeStiffness                  = 10,
	BendingStiffness               = 11,
	AreaStiffness                  = 12,
	BucklingStiffness              = 13,
	Pressure                       = 14,
	EChaosWeightMapTarget_MAX      = 15
};


// Enum ChaosCloth.EChaosClothTetherMode
enum class EChaosClothTetherMode : uint8_t
{
	FastTetherFastLength           = 0,
	AccurateTetherFastLength       = 1,
	AccurateTetherAccurateLength   = 2,
	MaxChaosClothTetherMode        = 3,
	EChaosClothTetherMode_MAX      = 4
};



//---------------------------------------------------------------------------
//Script Structs
//---------------------------------------------------------------------------

// ScriptStruct ChaosCloth.ChaosClothWeightedValue
// 0x0008
struct FChaosClothWeightedValue
{
	float                                              Low_69;                                                   // 0x0000(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	float                                              High_69;                                                  // 0x0004(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

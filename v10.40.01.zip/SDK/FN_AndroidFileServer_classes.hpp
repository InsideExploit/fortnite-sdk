#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Classes
//---------------------------------------------------------------------------

// Class AndroidFileServer.AndroidFileServerBPLibrary
// 0x0000 (0x0028 - 0x0028)
class AndroidFileServerBPLibrary : public BlueprintFunctionLibrary
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AndroidFileServer.AndroidFileServerBPLibrary"));
		
		return ptr;
	}


	bool STATIC_StopFileServer(bool bUSB_69, bool bNetwork_69);
	bool STATIC_StartFileServer(bool bUSB_69, bool bNetwork_69, int Port_69);
	TEnumAsByte<EAFSActiveType> STATIC_IsFileServerRunning();
};


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Functions
//---------------------------------------------------------------------------

// Function DLSSBlueprint.DLSSLibrary.SetDLSSSharpness
// (Final, RequiredAPI, Native, Static, Public, BlueprintCallable)
// Parameters:
// float                          Sharpness_69                   (Parm, ZeroConstructor, IsPlainOldData)

void DLSSLibrary::STATIC_SetDLSSSharpness(float Sharpness_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DLSSBlueprint.DLSSLibrary.SetDLSSSharpness"));

	DLSSLibrary_SetDLSSSharpness_Params params;
	params.Sharpness_69 = Sharpness_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function DLSSBlueprint.DLSSLibrary.SetDLSSMode
// (Final, RequiredAPI, Native, Static, Public, BlueprintCallable)
// Parameters:
// EUDLSSMode                     DLSSMode_69                    (Parm, ZeroConstructor, IsPlainOldData)

void DLSSLibrary::STATIC_SetDLSSMode(EUDLSSMode DLSSMode_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DLSSBlueprint.DLSSLibrary.SetDLSSMode"));

	DLSSLibrary_SetDLSSMode_Params params;
	params.DLSSMode_69 = DLSSMode_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function DLSSBlueprint.DLSSLibrary.QueryDLSSSupport
// (Final, RequiredAPI, Native, Static, Public, BlueprintCallable, BlueprintPure)
// Parameters:
// EUDLSSSupport                  ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

EUDLSSSupport DLSSLibrary::STATIC_QueryDLSSSupport()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DLSSBlueprint.DLSSLibrary.QueryDLSSSupport"));

	DLSSLibrary_QueryDLSSSupport_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function DLSSBlueprint.DLSSLibrary.IsDLSSSupported
// (Final, RequiredAPI, Native, Static, Public, BlueprintCallable, BlueprintPure)
// Parameters:
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool DLSSLibrary::STATIC_IsDLSSSupported()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DLSSBlueprint.DLSSLibrary.IsDLSSSupported"));

	DLSSLibrary_IsDLSSSupported_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function DLSSBlueprint.DLSSLibrary.IsDLSSModeSupported
// (Final, RequiredAPI, Native, Static, Public, BlueprintCallable, BlueprintPure)
// Parameters:
// EUDLSSMode                     DLSSMode_69                    (Parm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool DLSSLibrary::STATIC_IsDLSSModeSupported(EUDLSSMode DLSSMode_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DLSSBlueprint.DLSSLibrary.IsDLSSModeSupported"));

	DLSSLibrary_IsDLSSModeSupported_Params params;
	params.DLSSMode_69 = DLSSMode_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function DLSSBlueprint.DLSSLibrary.GetSupportedDLSSModes
// (Final, RequiredAPI, Native, Static, Public, BlueprintCallable, BlueprintPure)
// Parameters:
// TArray<EUDLSSMode>             ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

TArray<EUDLSSMode> DLSSLibrary::STATIC_GetSupportedDLSSModes()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DLSSBlueprint.DLSSLibrary.GetSupportedDLSSModes"));

	DLSSLibrary_GetSupportedDLSSModes_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function DLSSBlueprint.DLSSLibrary.GetDLSSSharpness
// (Final, RequiredAPI, Native, Static, Public, BlueprintCallable, BlueprintPure)
// Parameters:
// float                          ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

float DLSSLibrary::STATIC_GetDLSSSharpness()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DLSSBlueprint.DLSSLibrary.GetDLSSSharpness"));

	DLSSLibrary_GetDLSSSharpness_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function DLSSBlueprint.DLSSLibrary.GetDLSSScreenPercentageRange
// (Final, RequiredAPI, Native, Static, Public, HasOutParms, BlueprintCallable, BlueprintPure)
// Parameters:
// float                          MinScreenPercentage_69         (Parm, OutParm, ZeroConstructor, IsPlainOldData)
// float                          MaxScreenPercentage_69         (Parm, OutParm, ZeroConstructor, IsPlainOldData)

void DLSSLibrary::STATIC_GetDLSSScreenPercentageRange(float* MinScreenPercentage_69, float* MaxScreenPercentage_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DLSSBlueprint.DLSSLibrary.GetDLSSScreenPercentageRange"));

	DLSSLibrary_GetDLSSScreenPercentageRange_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (MinScreenPercentage_69 != nullptr)
		*MinScreenPercentage_69 = params.MinScreenPercentage_69;
	if (MaxScreenPercentage_69 != nullptr)
		*MaxScreenPercentage_69 = params.MaxScreenPercentage_69;
}


// Function DLSSBlueprint.DLSSLibrary.GetDLSSModeInformation
// (Final, RequiredAPI, Native, Static, Public, HasOutParms, HasDefaults, BlueprintCallable, BlueprintPure)
// Parameters:
// EUDLSSMode                     DLSSMode_69                    (Parm, ZeroConstructor, IsPlainOldData)
// struct FVector2D               ScreenResolution_69            (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bIsSupported_69                (Parm, OutParm, ZeroConstructor, IsPlainOldData)
// float                          OptimalScreenPercentage_69     (Parm, OutParm, ZeroConstructor, IsPlainOldData)
// bool                           bIsFixedScreenPercentage_69    (Parm, OutParm, ZeroConstructor, IsPlainOldData)
// float                          MinScreenPercentage_69         (Parm, OutParm, ZeroConstructor, IsPlainOldData)
// float                          MaxScreenPercentage_69         (Parm, OutParm, ZeroConstructor, IsPlainOldData)
// float                          OptimalSharpness_69            (Parm, OutParm, ZeroConstructor, IsPlainOldData)

void DLSSLibrary::STATIC_GetDLSSModeInformation(EUDLSSMode DLSSMode_69, const struct FVector2D& ScreenResolution_69, bool* bIsSupported_69, float* OptimalScreenPercentage_69, bool* bIsFixedScreenPercentage_69, float* MinScreenPercentage_69, float* MaxScreenPercentage_69, float* OptimalSharpness_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DLSSBlueprint.DLSSLibrary.GetDLSSModeInformation"));

	DLSSLibrary_GetDLSSModeInformation_Params params;
	params.DLSSMode_69 = DLSSMode_69;
	params.ScreenResolution_69 = ScreenResolution_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (bIsSupported_69 != nullptr)
		*bIsSupported_69 = params.bIsSupported_69;
	if (OptimalScreenPercentage_69 != nullptr)
		*OptimalScreenPercentage_69 = params.OptimalScreenPercentage_69;
	if (bIsFixedScreenPercentage_69 != nullptr)
		*bIsFixedScreenPercentage_69 = params.bIsFixedScreenPercentage_69;
	if (MinScreenPercentage_69 != nullptr)
		*MinScreenPercentage_69 = params.MinScreenPercentage_69;
	if (MaxScreenPercentage_69 != nullptr)
		*MaxScreenPercentage_69 = params.MaxScreenPercentage_69;
	if (OptimalSharpness_69 != nullptr)
		*OptimalSharpness_69 = params.OptimalSharpness_69;
}


// Function DLSSBlueprint.DLSSLibrary.GetDLSSMode
// (Final, RequiredAPI, Native, Static, Public, BlueprintCallable, BlueprintPure)
// Parameters:
// EUDLSSMode                     ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

EUDLSSMode DLSSLibrary::STATIC_GetDLSSMode()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DLSSBlueprint.DLSSLibrary.GetDLSSMode"));

	DLSSLibrary_GetDLSSMode_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function DLSSBlueprint.DLSSLibrary.GetDLSSMinimumDriverVersion
// (Final, RequiredAPI, Native, Static, Public, HasOutParms, BlueprintCallable, BlueprintPure)
// Parameters:
// int                            MinDriverVersionMajor_69       (Parm, OutParm, ZeroConstructor, IsPlainOldData)
// int                            MinDriverVersionMinor_69       (Parm, OutParm, ZeroConstructor, IsPlainOldData)

void DLSSLibrary::STATIC_GetDLSSMinimumDriverVersion(int* MinDriverVersionMajor_69, int* MinDriverVersionMinor_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DLSSBlueprint.DLSSLibrary.GetDLSSMinimumDriverVersion"));

	DLSSLibrary_GetDLSSMinimumDriverVersion_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (MinDriverVersionMajor_69 != nullptr)
		*MinDriverVersionMajor_69 = params.MinDriverVersionMajor_69;
	if (MinDriverVersionMinor_69 != nullptr)
		*MinDriverVersionMinor_69 = params.MinDriverVersionMinor_69;
}


// Function DLSSBlueprint.DLSSLibrary.GetDefaultDLSSMode
// (Final, RequiredAPI, Native, Static, Public, BlueprintCallable, BlueprintPure)
// Parameters:
// EUDLSSMode                     ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

EUDLSSMode DLSSLibrary::STATIC_GetDefaultDLSSMode()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DLSSBlueprint.DLSSLibrary.GetDefaultDLSSMode"));

	DLSSLibrary_GetDefaultDLSSMode_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

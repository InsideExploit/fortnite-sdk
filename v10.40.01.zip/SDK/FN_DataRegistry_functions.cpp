// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Functions
//---------------------------------------------------------------------------

// Function DataRegistry.DataRegistrySubsystem.NotEqual_DataRegistryType
// (Final, Native, Static, Public, BlueprintCallable, BlueprintPure)
// Parameters:
// struct FDataRegistryType       A_69                           (Parm, ZeroConstructor)
// struct FDataRegistryType       B_69                           (Parm, ZeroConstructor)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool DataRegistrySubsystem::STATIC_NotEqual_DataRegistryType(const struct FDataRegistryType& A_69, const struct FDataRegistryType& B_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DataRegistry.DataRegistrySubsystem.NotEqual_DataRegistryType"));

	DataRegistrySubsystem_NotEqual_DataRegistryType_Params params;
	params.A_69 = A_69;
	params.B_69 = B_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function DataRegistry.DataRegistrySubsystem.NotEqual_DataRegistryId
// (Final, Native, Static, Public, BlueprintCallable, BlueprintPure)
// Parameters:
// struct FDataRegistryId         A_69                           (Parm, ZeroConstructor)
// struct FDataRegistryId         B_69                           (Parm, ZeroConstructor)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool DataRegistrySubsystem::STATIC_NotEqual_DataRegistryId(const struct FDataRegistryId& A_69, const struct FDataRegistryId& B_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DataRegistry.DataRegistrySubsystem.NotEqual_DataRegistryId"));

	DataRegistrySubsystem_NotEqual_DataRegistryId_Params params;
	params.A_69 = A_69;
	params.B_69 = B_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function DataRegistry.DataRegistrySubsystem.IsValidDataRegistryType
// (Final, Native, Static, Public, BlueprintCallable, BlueprintPure)
// Parameters:
// struct FDataRegistryType       DataRegistryType_69            (Parm, ZeroConstructor)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool DataRegistrySubsystem::STATIC_IsValidDataRegistryType(const struct FDataRegistryType& DataRegistryType_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DataRegistry.DataRegistrySubsystem.IsValidDataRegistryType"));

	DataRegistrySubsystem_IsValidDataRegistryType_Params params;
	params.DataRegistryType_69 = DataRegistryType_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function DataRegistry.DataRegistrySubsystem.IsValidDataRegistryId
// (Final, Native, Static, Public, BlueprintCallable, BlueprintPure)
// Parameters:
// struct FDataRegistryId         DataRegistryId_69              (Parm, ZeroConstructor)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool DataRegistrySubsystem::STATIC_IsValidDataRegistryId(const struct FDataRegistryId& DataRegistryId_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DataRegistry.DataRegistrySubsystem.IsValidDataRegistryId"));

	DataRegistrySubsystem_IsValidDataRegistryId_Params params;
	params.DataRegistryId_69 = DataRegistryId_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function DataRegistry.DataRegistrySubsystem.GetCachedItemFromLookupBP
// (Final, Native, Static, Public, HasOutParms, BlueprintCallable)
// Parameters:
// struct FDataRegistryId         ItemId_69                      (Parm, ZeroConstructor)
// struct FDataRegistryLookup     ResolvedLookup_69              (ConstParm, Parm, OutParm, ReferenceParm)
// struct FTableRowBase           OutItem_69                     (Parm, OutParm)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool DataRegistrySubsystem::STATIC_GetCachedItemFromLookupBP(const struct FDataRegistryId& ItemId_69, const struct FDataRegistryLookup& ResolvedLookup_69, struct FTableRowBase* OutItem_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DataRegistry.DataRegistrySubsystem.GetCachedItemFromLookupBP"));

	DataRegistrySubsystem_GetCachedItemFromLookupBP_Params params;
	params.ItemId_69 = ItemId_69;
	params.ResolvedLookup_69 = ResolvedLookup_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (OutItem_69 != nullptr)
		*OutItem_69 = params.OutItem_69;

	return params.ReturnValue_69;
}


// Function DataRegistry.DataRegistrySubsystem.GetCachedItemBP
// (Final, Native, Static, Public, HasOutParms, BlueprintCallable)
// Parameters:
// struct FDataRegistryId         ItemId_69                      (Parm, ZeroConstructor)
// struct FTableRowBase           OutItem_69                     (Parm, OutParm, ReferenceParm)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool DataRegistrySubsystem::STATIC_GetCachedItemBP(const struct FDataRegistryId& ItemId_69, struct FTableRowBase* OutItem_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DataRegistry.DataRegistrySubsystem.GetCachedItemBP"));

	DataRegistrySubsystem_GetCachedItemBP_Params params;
	params.ItemId_69 = ItemId_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (OutItem_69 != nullptr)
		*OutItem_69 = params.OutItem_69;

	return params.ReturnValue_69;
}


// Function DataRegistry.DataRegistrySubsystem.FindCachedItemBP
// (Final, Native, Static, Public, HasOutParms, BlueprintCallable)
// Parameters:
// struct FDataRegistryId         ItemId_69                      (Parm, ZeroConstructor)
// EDataRegistrySubsystemGetItemResult OutResult_69                   (Parm, OutParm, ZeroConstructor, IsPlainOldData)
// struct FTableRowBase           OutItem_69                     (Parm, OutParm)

void DataRegistrySubsystem::STATIC_FindCachedItemBP(const struct FDataRegistryId& ItemId_69, EDataRegistrySubsystemGetItemResult* OutResult_69, struct FTableRowBase* OutItem_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DataRegistry.DataRegistrySubsystem.FindCachedItemBP"));

	DataRegistrySubsystem_FindCachedItemBP_Params params;
	params.ItemId_69 = ItemId_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (OutResult_69 != nullptr)
		*OutResult_69 = params.OutResult_69;
	if (OutItem_69 != nullptr)
		*OutItem_69 = params.OutItem_69;
}


// Function DataRegistry.DataRegistrySubsystem.EvaluateDataRegistryCurve
// (Final, Native, Static, Public, HasOutParms, BlueprintCallable)
// Parameters:
// struct FDataRegistryId         ItemId_69                      (Parm, ZeroConstructor)
// float                          InputValue_69                  (Parm, ZeroConstructor, IsPlainOldData)
// float                          DefaultValue_69                (Parm, ZeroConstructor, IsPlainOldData)
// EDataRegistrySubsystemGetItemResult OutResult_69                   (Parm, OutParm, ZeroConstructor, IsPlainOldData)
// float                          OutValue_69                    (Parm, OutParm, ZeroConstructor, IsPlainOldData)

void DataRegistrySubsystem::STATIC_EvaluateDataRegistryCurve(const struct FDataRegistryId& ItemId_69, float InputValue_69, float DefaultValue_69, EDataRegistrySubsystemGetItemResult* OutResult_69, float* OutValue_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DataRegistry.DataRegistrySubsystem.EvaluateDataRegistryCurve"));

	DataRegistrySubsystem_EvaluateDataRegistryCurve_Params params;
	params.ItemId_69 = ItemId_69;
	params.InputValue_69 = InputValue_69;
	params.DefaultValue_69 = DefaultValue_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (OutResult_69 != nullptr)
		*OutResult_69 = params.OutResult_69;
	if (OutValue_69 != nullptr)
		*OutValue_69 = params.OutValue_69;
}


// Function DataRegistry.DataRegistrySubsystem.EqualEqual_DataRegistryType
// (Final, Native, Static, Public, BlueprintCallable, BlueprintPure)
// Parameters:
// struct FDataRegistryType       A_69                           (Parm, ZeroConstructor)
// struct FDataRegistryType       B_69                           (Parm, ZeroConstructor)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool DataRegistrySubsystem::STATIC_EqualEqual_DataRegistryType(const struct FDataRegistryType& A_69, const struct FDataRegistryType& B_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DataRegistry.DataRegistrySubsystem.EqualEqual_DataRegistryType"));

	DataRegistrySubsystem_EqualEqual_DataRegistryType_Params params;
	params.A_69 = A_69;
	params.B_69 = B_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function DataRegistry.DataRegistrySubsystem.EqualEqual_DataRegistryId
// (Final, Native, Static, Public, BlueprintCallable, BlueprintPure)
// Parameters:
// struct FDataRegistryId         A_69                           (Parm, ZeroConstructor)
// struct FDataRegistryId         B_69                           (Parm, ZeroConstructor)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool DataRegistrySubsystem::STATIC_EqualEqual_DataRegistryId(const struct FDataRegistryId& A_69, const struct FDataRegistryId& B_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DataRegistry.DataRegistrySubsystem.EqualEqual_DataRegistryId"));

	DataRegistrySubsystem_EqualEqual_DataRegistryId_Params params;
	params.A_69 = A_69;
	params.B_69 = B_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function DataRegistry.DataRegistrySubsystem.Conv_DataRegistryTypeToString
// (Final, Native, Static, Public, BlueprintCallable, BlueprintPure)
// Parameters:
// struct FDataRegistryType       DataRegistryType_69            (Parm, ZeroConstructor)
// struct FString                 ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString DataRegistrySubsystem::STATIC_Conv_DataRegistryTypeToString(const struct FDataRegistryType& DataRegistryType_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DataRegistry.DataRegistrySubsystem.Conv_DataRegistryTypeToString"));

	DataRegistrySubsystem_Conv_DataRegistryTypeToString_Params params;
	params.DataRegistryType_69 = DataRegistryType_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function DataRegistry.DataRegistrySubsystem.Conv_DataRegistryIdToString
// (Final, Native, Static, Public, BlueprintCallable, BlueprintPure)
// Parameters:
// struct FDataRegistryId         DataRegistryId_69              (Parm, ZeroConstructor)
// struct FString                 ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString DataRegistrySubsystem::STATIC_Conv_DataRegistryIdToString(const struct FDataRegistryId& DataRegistryId_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DataRegistry.DataRegistrySubsystem.Conv_DataRegistryIdToString"));

	DataRegistrySubsystem_Conv_DataRegistryIdToString_Params params;
	params.DataRegistryId_69 = DataRegistryId_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function DataRegistry.DataRegistrySubsystem.AcquireItemBP
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// struct FDataRegistryId         ItemId_69                      (Parm, ZeroConstructor)
// struct FScriptDelegate         AcquireCallback_69             (Parm, ZeroConstructor)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool DataRegistrySubsystem::STATIC_AcquireItemBP(const struct FDataRegistryId& ItemId_69, const struct FScriptDelegate& AcquireCallback_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DataRegistry.DataRegistrySubsystem.AcquireItemBP"));

	DataRegistrySubsystem_AcquireItemBP_Params params;
	params.ItemId_69 = ItemId_69;
	params.AcquireCallback_69 = AcquireCallback_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

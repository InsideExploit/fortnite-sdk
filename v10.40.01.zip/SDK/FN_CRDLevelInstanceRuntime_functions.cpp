// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Functions
//---------------------------------------------------------------------------

// Function CRDLevelInstanceRuntime.LevelInstanceGameplayVolume.SetWantsLevelLoaded
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// bool                           bInWantsLevelLoaded_69         (Parm, ZeroConstructor, IsPlainOldData)

void LevelInstanceGameplayVolume::SetWantsLevelLoaded(bool bInWantsLevelLoaded_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CRDLevelInstanceRuntime.LevelInstanceGameplayVolume.SetWantsLevelLoaded"));

	LevelInstanceGameplayVolume_SetWantsLevelLoaded_Params params;
	params.bInWantsLevelLoaded_69 = bInWantsLevelLoaded_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CRDLevelInstanceRuntime.LevelInstanceGameplayVolume.SetReadyForInstantiation
// (Final, Native, Protected, BlueprintCallable)
// Parameters:
// bool                           bReady_69                      (Parm, ZeroConstructor, IsPlainOldData)

void LevelInstanceGameplayVolume::SetReadyForInstantiation(bool bReady_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CRDLevelInstanceRuntime.LevelInstanceGameplayVolume.SetReadyForInstantiation"));

	LevelInstanceGameplayVolume_SetReadyForInstantiation_Params params;
	params.bReady_69 = bReady_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CRDLevelInstanceRuntime.LevelInstanceGameplayVolume.SetLevelInstanceName
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// struct FString                 InName_69                      (Parm, ZeroConstructor)

void LevelInstanceGameplayVolume::SetLevelInstanceName(const struct FString& InName_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CRDLevelInstanceRuntime.LevelInstanceGameplayVolume.SetLevelInstanceName"));

	LevelInstanceGameplayVolume_SetLevelInstanceName_Params params;
	params.InName_69 = InName_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CRDLevelInstanceRuntime.LevelInstanceGameplayVolume.SetLevelInstanceContentCollection
// (Final, Native, Public, BlueprintCallable)

void LevelInstanceGameplayVolume::SetLevelInstanceContentCollection()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CRDLevelInstanceRuntime.LevelInstanceGameplayVolume.SetLevelInstanceContentCollection"));

	LevelInstanceGameplayVolume_SetLevelInstanceContentCollection_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CRDLevelInstanceRuntime.LevelInstanceGameplayVolume.SetLevelInstanceActorGuid
// (Final, Native, Public, HasDefaults, BlueprintCallable)
// Parameters:
// struct FGuid                   InLevelInstanceActorGuid_69    (Parm, ZeroConstructor, IsPlainOldData)

void LevelInstanceGameplayVolume::SetLevelInstanceActorGuid(const struct FGuid& InLevelInstanceActorGuid_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CRDLevelInstanceRuntime.LevelInstanceGameplayVolume.SetLevelInstanceActorGuid"));

	LevelInstanceGameplayVolume_SetLevelInstanceActorGuid_Params params;
	params.InLevelInstanceActorGuid_69 = InLevelInstanceActorGuid_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CRDLevelInstanceRuntime.LevelInstanceGameplayVolume.SetEditMode
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// bool                           bInEditMode_69                 (Parm, ZeroConstructor, IsPlainOldData)

void LevelInstanceGameplayVolume::SetEditMode(bool bInEditMode_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CRDLevelInstanceRuntime.LevelInstanceGameplayVolume.SetEditMode"));

	LevelInstanceGameplayVolume_SetEditMode_Params params;
	params.bInEditMode_69 = bInEditMode_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CRDLevelInstanceRuntime.LevelInstanceGameplayVolume.RemoveActorWhenEndPlay
// (Final, Native, Protected)
// Parameters:
// class Actor_32759*             Actor_69                       (Parm, ZeroConstructor)
// TEnumAsByte<EEndPlayReason>    EndPlayReason_69               (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void LevelInstanceGameplayVolume::RemoveActorWhenEndPlay(class Actor_32759* Actor_69, TEnumAsByte<EEndPlayReason> EndPlayReason_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CRDLevelInstanceRuntime.LevelInstanceGameplayVolume.RemoveActorWhenEndPlay"));

	LevelInstanceGameplayVolume_RemoveActorWhenEndPlay_Params params;
	params.Actor_69 = Actor_69;
	params.EndPlayReason_69 = EndPlayReason_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CRDLevelInstanceRuntime.LevelInstanceGameplayVolume.RemoveActorWhenDied
// (Final, Native, Protected, HasDefaults)
// Parameters:
// class Actor_32759*             DamagedActor_69                (Parm, ZeroConstructor)
// float                          Damage_69                      (Parm, ZeroConstructor, IsPlainOldData)
// class Controller*              InstigatedBy_69                (Parm, ZeroConstructor)
// class Actor_32759*             DamageCauser_69                (Parm, ZeroConstructor)
// struct FVector                 HitLocation_69                 (Parm, ZeroConstructor, IsPlainOldData)
// class PrimitiveComponent*      FHitComponent_69               (Parm, ZeroConstructor, InstancedReference)
// struct FName                   BoneName_69                    (Parm, ZeroConstructor, IsPlainOldData)
// struct FVector                 Momentum_69                    (Parm, ZeroConstructor, IsPlainOldData)

void LevelInstanceGameplayVolume::RemoveActorWhenDied(class Actor_32759* DamagedActor_69, float Damage_69, class Controller* InstigatedBy_69, class Actor_32759* DamageCauser_69, const struct FVector& HitLocation_69, class PrimitiveComponent* FHitComponent_69, const struct FName& BoneName_69, const struct FVector& Momentum_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CRDLevelInstanceRuntime.LevelInstanceGameplayVolume.RemoveActorWhenDied"));

	LevelInstanceGameplayVolume_RemoveActorWhenDied_Params params;
	params.DamagedActor_69 = DamagedActor_69;
	params.Damage_69 = Damage_69;
	params.InstigatedBy_69 = InstigatedBy_69;
	params.DamageCauser_69 = DamageCauser_69;
	params.HitLocation_69 = HitLocation_69;
	params.FHitComponent_69 = FHitComponent_69;
	params.BoneName_69 = BoneName_69;
	params.Momentum_69 = Momentum_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CRDLevelInstanceRuntime.LevelInstanceGameplayVolume.OnVolumeChanged
// (Event, Protected, BlueprintEvent)

void LevelInstanceGameplayVolume::OnVolumeChanged()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CRDLevelInstanceRuntime.LevelInstanceGameplayVolume.OnVolumeChanged"));

	LevelInstanceGameplayVolume_OnVolumeChanged_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CRDLevelInstanceRuntime.LevelInstanceGameplayVolume.OnRep_IsDisabled
// (Final, Native, Protected)

void LevelInstanceGameplayVolume::OnRep_IsDisabled()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CRDLevelInstanceRuntime.LevelInstanceGameplayVolume.OnRep_IsDisabled"));

	LevelInstanceGameplayVolume_OnRep_IsDisabled_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CRDLevelInstanceRuntime.LevelInstanceGameplayVolume.OnRep_InstanceLoaded
// (Final, Native, Protected)

void LevelInstanceGameplayVolume::OnRep_InstanceLoaded()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CRDLevelInstanceRuntime.LevelInstanceGameplayVolume.OnRep_InstanceLoaded"));

	LevelInstanceGameplayVolume_OnRep_InstanceLoaded_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CRDLevelInstanceRuntime.LevelInstanceGameplayVolume.OnRep_EditMode
// (Final, Native, Protected)

void LevelInstanceGameplayVolume::OnRep_EditMode()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CRDLevelInstanceRuntime.LevelInstanceGameplayVolume.OnRep_EditMode"));

	LevelInstanceGameplayVolume_OnRep_EditMode_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CRDLevelInstanceRuntime.LevelInstanceGameplayVolume.OnMinigameStateChanged
// (Final, Native, Protected)
// Parameters:
// class FortMinigame*            Minigame_69                    (Parm, ZeroConstructor)
// EFortMinigameState             MinigameState_69               (Parm, ZeroConstructor, IsPlainOldData)

void LevelInstanceGameplayVolume::OnMinigameStateChanged(class FortMinigame* Minigame_69, EFortMinigameState MinigameState_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CRDLevelInstanceRuntime.LevelInstanceGameplayVolume.OnMinigameStateChanged"));

	LevelInstanceGameplayVolume_OnMinigameStateChanged_Params params;
	params.Minigame_69 = Minigame_69;
	params.MinigameState_69 = MinigameState_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CRDLevelInstanceRuntime.LevelInstanceGameplayVolume.LevelInstanceSizeChanged
// (Final, Native, Protected)
// Parameters:
// class Actor_32759*             InstigatorActor_69             (ConstParm, Parm, ZeroConstructor)

void LevelInstanceGameplayVolume::LevelInstanceSizeChanged(class Actor_32759* InstigatorActor_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CRDLevelInstanceRuntime.LevelInstanceGameplayVolume.LevelInstanceSizeChanged"));

	LevelInstanceGameplayVolume_LevelInstanceSizeChanged_Params params;
	params.InstigatorActor_69 = InstigatorActor_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CRDLevelInstanceRuntime.LevelInstanceGameplayVolume.LevelInstanceNameChanged
// (Final, Native, Protected)
// Parameters:
// struct FString                 Name_69                        (Parm, ZeroConstructor)

void LevelInstanceGameplayVolume::LevelInstanceNameChanged(const struct FString& Name_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CRDLevelInstanceRuntime.LevelInstanceGameplayVolume.LevelInstanceNameChanged"));

	LevelInstanceGameplayVolume_LevelInstanceNameChanged_Params params;
	params.Name_69 = Name_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CRDLevelInstanceRuntime.LevelInstanceGameplayVolume.LevelInstanceContentCollectionChanged
// (Final, Native, Protected)
// Parameters:
// class Actor_32759*             InstigatorActor_69             (ConstParm, Parm, ZeroConstructor)

void LevelInstanceGameplayVolume::LevelInstanceContentCollectionChanged(class Actor_32759* InstigatorActor_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CRDLevelInstanceRuntime.LevelInstanceGameplayVolume.LevelInstanceContentCollectionChanged"));

	LevelInstanceGameplayVolume_LevelInstanceContentCollectionChanged_Params params;
	params.InstigatorActor_69 = InstigatorActor_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CRDLevelInstanceRuntime.LevelInstanceGameplayVolume.LevelInstanceContentChanged
// (Final, Native, Protected)
// Parameters:
// class Actor_32759*             InstigatorActor_69             (ConstParm, Parm, ZeroConstructor)

void LevelInstanceGameplayVolume::LevelInstanceContentChanged(class Actor_32759* InstigatorActor_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CRDLevelInstanceRuntime.LevelInstanceGameplayVolume.LevelInstanceContentChanged"));

	LevelInstanceGameplayVolume_LevelInstanceContentChanged_Params params;
	params.InstigatorActor_69 = InstigatorActor_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CRDLevelInstanceRuntime.LevelInstanceGameplayVolume.LevelInstanceBeingDestroyed
// (Final, Native, Protected)

void LevelInstanceGameplayVolume::LevelInstanceBeingDestroyed()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CRDLevelInstanceRuntime.LevelInstanceGameplayVolume.LevelInstanceBeingDestroyed"));

	LevelInstanceGameplayVolume_LevelInstanceBeingDestroyed_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CRDLevelInstanceRuntime.LevelInstanceGameplayVolume.IsPreviewActor
// (Final, Native, Protected, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool LevelInstanceGameplayVolume::IsPreviewActor()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CRDLevelInstanceRuntime.LevelInstanceGameplayVolume.IsPreviewActor"));

	LevelInstanceGameplayVolume_IsPreviewActor_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CRDLevelInstanceRuntime.LevelInstanceGameplayVolume.IsInEditMode
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool LevelInstanceGameplayVolume::IsInEditMode()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CRDLevelInstanceRuntime.LevelInstanceGameplayVolume.IsInEditMode"));

	LevelInstanceGameplayVolume_IsInEditMode_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CRDLevelInstanceRuntime.LevelInstanceGameplayVolume.IsDisabled
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool LevelInstanceGameplayVolume::IsDisabled()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CRDLevelInstanceRuntime.LevelInstanceGameplayVolume.IsDisabled"));

	LevelInstanceGameplayVolume_IsDisabled_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CRDLevelInstanceRuntime.LevelInstanceGameplayVolume.InstantiateFromLevelInstanceSaveActor
// (Final, Native, Protected, BlueprintCallable)

void LevelInstanceGameplayVolume::InstantiateFromLevelInstanceSaveActor()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CRDLevelInstanceRuntime.LevelInstanceGameplayVolume.InstantiateFromLevelInstanceSaveActor"));

	LevelInstanceGameplayVolume_InstantiateFromLevelInstanceSaveActor_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CRDLevelInstanceRuntime.LevelInstanceGameplayVolume.HandleActorHealthChanged
// (Final, Native, Protected)
// Parameters:
// class Actor_32759*             Actor_69                       (Parm, ZeroConstructor)
// float                          NewHealth_69                   (Parm, ZeroConstructor, IsPlainOldData)

void LevelInstanceGameplayVolume::HandleActorHealthChanged(class Actor_32759* Actor_69, float NewHealth_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CRDLevelInstanceRuntime.LevelInstanceGameplayVolume.HandleActorHealthChanged"));

	LevelInstanceGameplayVolume_HandleActorHealthChanged_Params params;
	params.Actor_69 = Actor_69;
	params.NewHealth_69 = NewHealth_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CRDLevelInstanceRuntime.LevelInstanceGameplayVolume.GetLevelInstanceName
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FString                 ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString LevelInstanceGameplayVolume::GetLevelInstanceName()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CRDLevelInstanceRuntime.LevelInstanceGameplayVolume.GetLevelInstanceName"));

	LevelInstanceGameplayVolume_GetLevelInstanceName_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CRDLevelInstanceRuntime.LevelInstanceGameplayVolume.CreateLevelInstanceSaveActor
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// class FortLevelInstanceSaveActor* ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

class FortLevelInstanceSaveActor* LevelInstanceGameplayVolume::CreateLevelInstanceSaveActor()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CRDLevelInstanceRuntime.LevelInstanceGameplayVolume.CreateLevelInstanceSaveActor"));

	LevelInstanceGameplayVolume_CreateLevelInstanceSaveActor_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CRDLevelInstanceRuntime.LevelInstanceGameplayVolume.CheckForOverlappingVolumes
// (Final, Native, Protected, BlueprintCallable)

void LevelInstanceGameplayVolume::CheckForOverlappingVolumes()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CRDLevelInstanceRuntime.LevelInstanceGameplayVolume.CheckForOverlappingVolumes"));

	LevelInstanceGameplayVolume_CheckForOverlappingVolumes_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

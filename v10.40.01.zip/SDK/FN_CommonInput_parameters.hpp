#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function CommonInput.CommonInputBaseControllerData.GetRegisteredGamepads
struct CommonInputBaseControllerData_GetRegisteredGamepads_Params
{
	TArray<struct FName>                               ReturnValue_69;                                           // (ConstParm, Parm, OutParm, ZeroConstructor, ReturnParm, ReferenceParm)
};

// Function CommonInput.CommonInputSubsystem.ShouldShowInputKeys
struct CommonInputSubsystem_ShouldShowInputKeys_Params
{
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CommonInput.CommonInputSubsystem.SetGamepadInputType
struct CommonInputSubsystem_SetGamepadInputType_Params
{
	struct FName                                       InGamepadInputType_69;                                    // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function CommonInput.CommonInputSubsystem.SetCurrentInputType
struct CommonInputSubsystem_SetCurrentInputType_Params
{
	ECommonInputType                                   NewInputType_69;                                          // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function CommonInput.CommonInputSubsystem.IsUsingPointerInput
struct CommonInputSubsystem_IsUsingPointerInput_Params
{
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CommonInput.CommonInputSubsystem.IsInputMethodActive
struct CommonInputSubsystem_IsInputMethodActive_Params
{
	ECommonInputType                                   InputMethod_69;                                           // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CommonInput.CommonInputSubsystem.GetDefaultInputType
struct CommonInputSubsystem_GetDefaultInputType_Params
{
	ECommonInputType                                   ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CommonInput.CommonInputSubsystem.GetCurrentInputType
struct CommonInputSubsystem_GetCurrentInputType_Params
{
	ECommonInputType                                   ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CommonInput.CommonInputSubsystem.GetCurrentGamepadName
struct CommonInputSubsystem_GetCurrentGamepadName_Params
{
	struct FName                                       ReturnValue_69;                                           // (ConstParm, Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Functions
//---------------------------------------------------------------------------

// Function Curie.CurieInterface.OnCurieStateDetached_BP
// (Event, Public, BlueprintEvent)
// Parameters:
// struct FCurieContainerHandle   CurieContainerHandle_69        (ConstParm, Parm)
// struct FGameplayTag            StateTag_69                    (ConstParm, Parm)

void CurieInterface::OnCurieStateDetached_BP(const struct FCurieContainerHandle& CurieContainerHandle_69, const struct FGameplayTag& StateTag_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function Curie.CurieInterface.OnCurieStateDetached_BP"));

	CurieInterface_OnCurieStateDetached_BP_Params params;
	params.CurieContainerHandle_69 = CurieContainerHandle_69;
	params.StateTag_69 = StateTag_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function Curie.CurieInterface.OnCurieStateAttached_BP
// (Event, Public, BlueprintEvent)
// Parameters:
// struct FCurieContainerHandle   CurieContainerHandle_69        (ConstParm, Parm)
// struct FGameplayTag            StateTag_69                    (ConstParm, Parm)

void CurieInterface::OnCurieStateAttached_BP(const struct FCurieContainerHandle& CurieContainerHandle_69, const struct FGameplayTag& StateTag_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function Curie.CurieInterface.OnCurieStateAttached_BP"));

	CurieInterface_OnCurieStateAttached_BP_Params params;
	params.CurieContainerHandle_69 = CurieContainerHandle_69;
	params.StateTag_69 = StateTag_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function Curie.CurieInterface.OnCurieElementInteractEnded_BP
// (Event, Public, HasOutParms, BlueprintEvent)
// Parameters:
// struct FCurieContainerHandle   CurieContainerHandle_69        (ConstParm, Parm)
// struct FGameplayTag            ElementTag_69                  (ConstParm, Parm)
// struct FCurieInteractParamsHandle InteractParamsHandle_69        (ConstParm, Parm, OutParm, ReferenceParm)

void CurieInterface::OnCurieElementInteractEnded_BP(const struct FCurieContainerHandle& CurieContainerHandle_69, const struct FGameplayTag& ElementTag_69, const struct FCurieInteractParamsHandle& InteractParamsHandle_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function Curie.CurieInterface.OnCurieElementInteractEnded_BP"));

	CurieInterface_OnCurieElementInteractEnded_BP_Params params;
	params.CurieContainerHandle_69 = CurieContainerHandle_69;
	params.ElementTag_69 = ElementTag_69;
	params.InteractParamsHandle_69 = InteractParamsHandle_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function Curie.CurieInterface.OnCurieElementInteractBegun_BP
// (Event, Public, HasOutParms, BlueprintEvent)
// Parameters:
// struct FCurieContainerHandle   CurieContainerHandle_69        (ConstParm, Parm)
// struct FGameplayTag            ElementTag_69                  (ConstParm, Parm)
// struct FCurieInteractParamsHandle InteractParamsHandle_69        (ConstParm, Parm, OutParm, ReferenceParm)

void CurieInterface::OnCurieElementInteractBegun_BP(const struct FCurieContainerHandle& CurieContainerHandle_69, const struct FGameplayTag& ElementTag_69, const struct FCurieInteractParamsHandle& InteractParamsHandle_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function Curie.CurieInterface.OnCurieElementInteractBegun_BP"));

	CurieInterface_OnCurieElementInteractBegun_BP_Params params;
	params.CurieContainerHandle_69 = CurieContainerHandle_69;
	params.ElementTag_69 = ElementTag_69;
	params.InteractParamsHandle_69 = InteractParamsHandle_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function Curie.CurieInterface.OnCurieElementInteract_BP
// (Event, Public, HasOutParms, BlueprintEvent)
// Parameters:
// struct FCurieContainerHandle   CurieContainerHandle_69        (ConstParm, Parm)
// struct FGameplayTag            ElementTag_69                  (ConstParm, Parm)
// struct FCurieInteractParamsHandle InteractParamsHandle_69        (ConstParm, Parm, OutParm, ReferenceParm)

void CurieInterface::OnCurieElementInteract_BP(const struct FCurieContainerHandle& CurieContainerHandle_69, const struct FGameplayTag& ElementTag_69, const struct FCurieInteractParamsHandle& InteractParamsHandle_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function Curie.CurieInterface.OnCurieElementInteract_BP"));

	CurieInterface_OnCurieElementInteract_BP_Params params;
	params.CurieContainerHandle_69 = CurieContainerHandle_69;
	params.ElementTag_69 = ElementTag_69;
	params.InteractParamsHandle_69 = InteractParamsHandle_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function Curie.CurieInterface.OnCurieElementDetached_BP
// (Event, Public, BlueprintEvent)
// Parameters:
// struct FCurieContainerHandle   CurieContainerHandle_69        (ConstParm, Parm)
// struct FGameplayTag            ElementTag_69                  (ConstParm, Parm)

void CurieInterface::OnCurieElementDetached_BP(const struct FCurieContainerHandle& CurieContainerHandle_69, const struct FGameplayTag& ElementTag_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function Curie.CurieInterface.OnCurieElementDetached_BP"));

	CurieInterface_OnCurieElementDetached_BP_Params params;
	params.CurieContainerHandle_69 = CurieContainerHandle_69;
	params.ElementTag_69 = ElementTag_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function Curie.CurieInterface.OnCurieElementAttached_BP
// (Event, Public, BlueprintEvent)
// Parameters:
// struct FCurieContainerHandle   CurieContainerHandle_69        (ConstParm, Parm)
// struct FGameplayTag            ElementTag_69                  (ConstParm, Parm)

void CurieInterface::OnCurieElementAttached_BP(const struct FCurieContainerHandle& CurieContainerHandle_69, const struct FGameplayTag& ElementTag_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function Curie.CurieInterface.OnCurieElementAttached_BP"));

	CurieInterface_OnCurieElementAttached_BP_Params params;
	params.CurieContainerHandle_69 = CurieContainerHandle_69;
	params.ElementTag_69 = ElementTag_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function Curie.CurieInterface.OnCurieContainerReparented_BP
// (Event, Public, BlueprintEvent)
// Parameters:
// struct FCurieContainerHandle   CurieContainerHandle_69        (ConstParm, Parm)

void CurieInterface::OnCurieContainerReparented_BP(const struct FCurieContainerHandle& CurieContainerHandle_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function Curie.CurieInterface.OnCurieContainerReparented_BP"));

	CurieInterface_OnCurieContainerReparented_BP_Params params;
	params.CurieContainerHandle_69 = CurieContainerHandle_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function Curie.CurieInterface.OnCurieContainerReleased_BP
// (Event, Public, BlueprintEvent)
// Parameters:
// struct FCurieContainerHandle   CurieContainerHandle_69        (ConstParm, Parm)

void CurieInterface::OnCurieContainerReleased_BP(const struct FCurieContainerHandle& CurieContainerHandle_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function Curie.CurieInterface.OnCurieContainerReleased_BP"));

	CurieInterface_OnCurieContainerReleased_BP_Params params;
	params.CurieContainerHandle_69 = CurieContainerHandle_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function Curie.CurieInterface.OnCurieContainerAcquired_BP
// (Event, Public, BlueprintEvent)
// Parameters:
// struct FCurieContainerHandle   CurieContainerHandle_69        (ConstParm, Parm)

void CurieInterface::OnCurieContainerAcquired_BP(const struct FCurieContainerHandle& CurieContainerHandle_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function Curie.CurieInterface.OnCurieContainerAcquired_BP"));

	CurieInterface_OnCurieContainerAcquired_BP_Params params;
	params.CurieContainerHandle_69 = CurieContainerHandle_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function Curie.CurieManager.UnbindDelegateForCurieStateDetached
// (Final, Native, Public, HasOutParms, BlueprintCallable)
// Parameters:
// class Object_32759*            CurieOwner_69                  (Parm, ZeroConstructor)
// struct FScriptDelegate         Delegate_69                    (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)

void CurieManager::UnbindDelegateForCurieStateDetached(class Object_32759* CurieOwner_69, const struct FScriptDelegate& Delegate_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function Curie.CurieManager.UnbindDelegateForCurieStateDetached"));

	CurieManager_UnbindDelegateForCurieStateDetached_Params params;
	params.CurieOwner_69 = CurieOwner_69;
	params.Delegate_69 = Delegate_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function Curie.CurieManager.UnbindDelegateForCurieStateAttached
// (Final, Native, Public, HasOutParms, BlueprintCallable)
// Parameters:
// class Object_32759*            CurieOwner_69                  (Parm, ZeroConstructor)
// struct FScriptDelegate         Delegate_69                    (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)

void CurieManager::UnbindDelegateForCurieStateAttached(class Object_32759* CurieOwner_69, const struct FScriptDelegate& Delegate_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function Curie.CurieManager.UnbindDelegateForCurieStateAttached"));

	CurieManager_UnbindDelegateForCurieStateAttached_Params params;
	params.CurieOwner_69 = CurieOwner_69;
	params.Delegate_69 = Delegate_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function Curie.CurieManager.UnbindDelegateForCurieElementInteract
// (Final, Native, Public, HasOutParms, BlueprintCallable)
// Parameters:
// class Object_32759*            CurieOwner_69                  (Parm, ZeroConstructor)
// struct FScriptDelegate         Delegate_69                    (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)

void CurieManager::UnbindDelegateForCurieElementInteract(class Object_32759* CurieOwner_69, const struct FScriptDelegate& Delegate_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function Curie.CurieManager.UnbindDelegateForCurieElementInteract"));

	CurieManager_UnbindDelegateForCurieElementInteract_Params params;
	params.CurieOwner_69 = CurieOwner_69;
	params.Delegate_69 = Delegate_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function Curie.CurieManager.UnbindDelegateForCurieElementEndInteract
// (Final, Native, Public, HasOutParms, BlueprintCallable)
// Parameters:
// class Object_32759*            CurieOwner_69                  (Parm, ZeroConstructor)
// struct FScriptDelegate         Delegate_69                    (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)

void CurieManager::UnbindDelegateForCurieElementEndInteract(class Object_32759* CurieOwner_69, const struct FScriptDelegate& Delegate_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function Curie.CurieManager.UnbindDelegateForCurieElementEndInteract"));

	CurieManager_UnbindDelegateForCurieElementEndInteract_Params params;
	params.CurieOwner_69 = CurieOwner_69;
	params.Delegate_69 = Delegate_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function Curie.CurieManager.UnbindDelegateForCurieElementDetached
// (Final, Native, Public, HasOutParms, BlueprintCallable)
// Parameters:
// class Object_32759*            CurieOwner_69                  (Parm, ZeroConstructor)
// struct FScriptDelegate         Delegate_69                    (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)

void CurieManager::UnbindDelegateForCurieElementDetached(class Object_32759* CurieOwner_69, const struct FScriptDelegate& Delegate_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function Curie.CurieManager.UnbindDelegateForCurieElementDetached"));

	CurieManager_UnbindDelegateForCurieElementDetached_Params params;
	params.CurieOwner_69 = CurieOwner_69;
	params.Delegate_69 = Delegate_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function Curie.CurieManager.UnbindDelegateForCurieElementBeginInteract
// (Final, Native, Public, HasOutParms, BlueprintCallable)
// Parameters:
// class Object_32759*            CurieOwner_69                  (Parm, ZeroConstructor)
// struct FScriptDelegate         Delegate_69                    (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)

void CurieManager::UnbindDelegateForCurieElementBeginInteract(class Object_32759* CurieOwner_69, const struct FScriptDelegate& Delegate_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function Curie.CurieManager.UnbindDelegateForCurieElementBeginInteract"));

	CurieManager_UnbindDelegateForCurieElementBeginInteract_Params params;
	params.CurieOwner_69 = CurieOwner_69;
	params.Delegate_69 = Delegate_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function Curie.CurieManager.UnbindDelegateForCurieElementAttached
// (Final, Native, Public, HasOutParms, BlueprintCallable)
// Parameters:
// class Object_32759*            CurieOwner_69                  (Parm, ZeroConstructor)
// struct FScriptDelegate         Delegate_69                    (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)

void CurieManager::UnbindDelegateForCurieElementAttached(class Object_32759* CurieOwner_69, const struct FScriptDelegate& Delegate_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function Curie.CurieManager.UnbindDelegateForCurieElementAttached"));

	CurieManager_UnbindDelegateForCurieElementAttached_Params params;
	params.CurieOwner_69 = CurieOwner_69;
	params.Delegate_69 = Delegate_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function Curie.CurieManager.HandleContainerOwnerDestroyed
// (Final, Native, Private)
// Parameters:
// class Actor_32759*             OwnerActor_69                  (Parm, ZeroConstructor)

void CurieManager::HandleContainerOwnerDestroyed(class Actor_32759* OwnerActor_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function Curie.CurieManager.HandleContainerOwnerDestroyed"));

	CurieManager_HandleContainerOwnerDestroyed_Params params;
	params.OwnerActor_69 = OwnerActor_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function Curie.CurieManager.BindDelegateForCurieStateDetached
// (Final, Native, Public, HasOutParms, BlueprintCallable)
// Parameters:
// class Object_32759*            CurieOwner_69                  (Parm, ZeroConstructor)
// struct FScriptDelegate         Delegate_69                    (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)

void CurieManager::BindDelegateForCurieStateDetached(class Object_32759* CurieOwner_69, const struct FScriptDelegate& Delegate_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function Curie.CurieManager.BindDelegateForCurieStateDetached"));

	CurieManager_BindDelegateForCurieStateDetached_Params params;
	params.CurieOwner_69 = CurieOwner_69;
	params.Delegate_69 = Delegate_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function Curie.CurieManager.BindDelegateForCurieStateAttached
// (Final, Native, Public, HasOutParms, BlueprintCallable)
// Parameters:
// class Object_32759*            CurieOwner_69                  (Parm, ZeroConstructor)
// struct FScriptDelegate         Delegate_69                    (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)

void CurieManager::BindDelegateForCurieStateAttached(class Object_32759* CurieOwner_69, const struct FScriptDelegate& Delegate_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function Curie.CurieManager.BindDelegateForCurieStateAttached"));

	CurieManager_BindDelegateForCurieStateAttached_Params params;
	params.CurieOwner_69 = CurieOwner_69;
	params.Delegate_69 = Delegate_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function Curie.CurieManager.BindDelegateForCurieElementInteract
// (Final, Native, Public, HasOutParms, BlueprintCallable)
// Parameters:
// class Object_32759*            CurieOwner_69                  (Parm, ZeroConstructor)
// struct FScriptDelegate         Delegate_69                    (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)

void CurieManager::BindDelegateForCurieElementInteract(class Object_32759* CurieOwner_69, const struct FScriptDelegate& Delegate_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function Curie.CurieManager.BindDelegateForCurieElementInteract"));

	CurieManager_BindDelegateForCurieElementInteract_Params params;
	params.CurieOwner_69 = CurieOwner_69;
	params.Delegate_69 = Delegate_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function Curie.CurieManager.BindDelegateForCurieElementEndInteract
// (Final, Native, Public, HasOutParms, BlueprintCallable)
// Parameters:
// class Object_32759*            CurieOwner_69                  (Parm, ZeroConstructor)
// struct FScriptDelegate         Delegate_69                    (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)

void CurieManager::BindDelegateForCurieElementEndInteract(class Object_32759* CurieOwner_69, const struct FScriptDelegate& Delegate_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function Curie.CurieManager.BindDelegateForCurieElementEndInteract"));

	CurieManager_BindDelegateForCurieElementEndInteract_Params params;
	params.CurieOwner_69 = CurieOwner_69;
	params.Delegate_69 = Delegate_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function Curie.CurieManager.BindDelegateForCurieElementDetached
// (Final, Native, Public, HasOutParms, BlueprintCallable)
// Parameters:
// class Object_32759*            CurieOwner_69                  (Parm, ZeroConstructor)
// struct FScriptDelegate         Delegate_69                    (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)

void CurieManager::BindDelegateForCurieElementDetached(class Object_32759* CurieOwner_69, const struct FScriptDelegate& Delegate_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function Curie.CurieManager.BindDelegateForCurieElementDetached"));

	CurieManager_BindDelegateForCurieElementDetached_Params params;
	params.CurieOwner_69 = CurieOwner_69;
	params.Delegate_69 = Delegate_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function Curie.CurieManager.BindDelegateForCurieElementBeginInteract
// (Final, Native, Public, HasOutParms, BlueprintCallable)
// Parameters:
// class Object_32759*            CurieOwner_69                  (Parm, ZeroConstructor)
// struct FScriptDelegate         Delegate_69                    (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)

void CurieManager::BindDelegateForCurieElementBeginInteract(class Object_32759* CurieOwner_69, const struct FScriptDelegate& Delegate_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function Curie.CurieManager.BindDelegateForCurieElementBeginInteract"));

	CurieManager_BindDelegateForCurieElementBeginInteract_Params params;
	params.CurieOwner_69 = CurieOwner_69;
	params.Delegate_69 = Delegate_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function Curie.CurieManager.BindDelegateForCurieElementAttached
// (Final, Native, Public, HasOutParms, BlueprintCallable)
// Parameters:
// class Object_32759*            CurieOwner_69                  (Parm, ZeroConstructor)
// struct FScriptDelegate         Delegate_69                    (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)

void CurieManager::BindDelegateForCurieElementAttached(class Object_32759* CurieOwner_69, const struct FScriptDelegate& Delegate_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function Curie.CurieManager.BindDelegateForCurieElementAttached"));

	CurieManager_BindDelegateForCurieElementAttached_Params params;
	params.CurieOwner_69 = CurieOwner_69;
	params.Delegate_69 = Delegate_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function AudioLinkEngine.AudioLinkBlueprintInterface.StopLink
struct AudioLinkBlueprintInterface_StopLink_Params
{
};

// Function AudioLinkEngine.AudioLinkBlueprintInterface.SetLinkSound
struct AudioLinkBlueprintInterface_SetLinkSound_Params
{
	class SoundBase*                                   NewSound_69;                                              // (Parm, ZeroConstructor)
};

// Function AudioLinkEngine.AudioLinkBlueprintInterface.PlayLink
struct AudioLinkBlueprintInterface_PlayLink_Params
{
	float                                              StartTime_69;                                             // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function AudioLinkEngine.AudioLinkBlueprintInterface.IsLinkPlaying
struct AudioLinkBlueprintInterface_IsLinkPlaying_Params
{
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

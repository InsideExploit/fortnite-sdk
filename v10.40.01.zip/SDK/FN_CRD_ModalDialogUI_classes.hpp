#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Classes
//---------------------------------------------------------------------------

// Class CRD_ModalDialogUI.CreativeModalDialogWidget
// 0x0010 (0x03B8 - 0x03A8)
class CreativeModalDialogWidget : public CommonActivatableWidget
{
public:
	struct FDataTableRowHandle                         MainMenuInputRowHandle_69;                                // 0x03A8(0x0010) (Edit, DisableEditOnInstance)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CRD_ModalDialogUI.CreativeModalDialogWidget"));
		
		return ptr;
	}

};


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

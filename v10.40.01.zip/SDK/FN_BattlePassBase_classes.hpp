#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Classes
//---------------------------------------------------------------------------

// Class BattlePassBase.BattlePassSubPageInterface
// 0x0000 (0x0028 - 0x0028)
class BattlePassSubPageInterface : public Interface
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class BattlePassBase.BattlePassSubPageInterface"));
		
		return ptr;
	}


	void OnEnterSubPage();
};


// Class BattlePassBase.BattlePassLandingPageBase
// 0x0128 (0x04D0 - 0x03A8)
class BattlePassLandingPageBase : public CommonActivatableWidget
{
public:
	unsigned char                                      UnknownData00[0x100];                                     // 0x03A8(0x0100) MISSED OFFSET
	class BattlePassLandingPageButton*                 LastHoveredPageButton_69;                                 // 0x04A8(0x0008) (ExportObject, ZeroConstructor, Transient, InstancedReference)
	unsigned char                                      UnknownData01[0x20];                                      // 0x04B0(0x0020) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class BattlePassBase.BattlePassLandingPageBase"));
		
		return ptr;
	}

};


// Class BattlePassBase.BattlePassLandingPageButton
// 0x0200 (0x15E0 - 0x13E0)
class BattlePassLandingPageButton : public CommonButtonBase
{
public:
	EBattlePassView                                    SubPageType_69;                                           // 0x13E0(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	EBattlePassFeatures                                FeatureType_69;                                           // 0x13E1(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x6];                                       // 0x13E2(0x0006) MISSED OFFSET
	struct FBattlePassLandingPageEntryPreviewInfo      PreviewInfo_69;                                           // 0x13E8(0x0038) (Edit, BlueprintVisible, BlueprintReadOnly)
	bool                                               bNeedsBattlePass_69;                                      // 0x1420(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x7];                                       // 0x1421(0x0007) MISSED OFFSET
	class FortChallengeBundleScheduleDefinition*       DelayQuestSchedule_69;                                    // 0x1428(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
	int                                                DelayDaysSinceSeasonStart_69;                             // 0x1430(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData02[0x4];                                       // 0x1434(0x0004) MISSED OFFSET
	class FortItemDefinition*                          RequiredItem_69;                                          // 0x1438(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
	class FortBangWrapper_NUI*                         BangWrapper_69;                                           // 0x1440(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)
	bool                                               bUsesTelemetry_69;                                        // 0x1448(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData03[0x3];                                       // 0x1449(0x0003) MISSED OFFSET
	struct FIntPoint                                   Telemetry_Size_69;                                        // 0x144C(0x0008) (Edit, ZeroConstructor, IsPlainOldData)
	struct FIntPoint                                   Telemetry_Position_69;                                    // 0x1454(0x0008) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData04[0x4];                                       // 0x145C(0x0004) MISSED OFFSET
	struct FBattlePassLandingPageButtonTexts           DefaultTexts_69;                                          // 0x1460(0x0048) (Edit, BlueprintVisible, BlueprintReadOnly)
	struct FBattlePassLandingPageButtonTexts           DelayedTexts_69;                                          // 0x14A8(0x0048) (Edit, BlueprintVisible, BlueprintReadOnly)
	struct FBattlePassLandingPageButtonTexts           SubscribedTexts_69;                                       // 0x14F0(0x0048) (Edit, BlueprintVisible, BlueprintReadOnly)
	unsigned char                                      UnknownData05[0xA8];                                      // 0x1538(0x00A8) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class BattlePassBase.BattlePassLandingPageButton"));
		
		return ptr;
	}


	void OnSubscriptionTextureLoaded(class Texture2D* Texture_69);
	void OnSubscriptionOwnershipUpdated(bool bOwnsSubsciption_69);
	void OnDisplayDetailsUpdated(const struct FBattlePassLandingPageButtonDisplayDetails& NewDisplayDetails_69);
	struct FBattlePassLandingPageButtonDisplayDetails GetBattlePassDisplayDetails();
};


// Class BattlePassBase.BattlePassRewardPageBase
// 0x00F8 (0x04A0 - 0x03A8)
class BattlePassRewardPageBase : public CommonActivatableWidget
{
public:
	unsigned char                                      UnknownData00[0xF8];                                      // 0x03A8(0x00F8) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class BattlePassBase.BattlePassRewardPageBase"));
		
		return ptr;
	}

};


// Class BattlePassBase.BattlePassUIGameFeatureAction
// 0x0078 (0x00A0 - 0x0028)
class BattlePassUIGameFeatureAction : public FortUIGameFeatureAction
{
public:
	unsigned char                                      UnknownData00[0x28];                                      // 0x0028(0x0028) UNKNOWN PROPERTY: SoftClassProperty BattlePassBase.BattlePassUIGameFeatureAction.BattlePassScreenClass_69
	unsigned char                                      UnknownData01[0x28];                                      // 0x0050(0x0028) UNKNOWN PROPERTY: SoftClassProperty BattlePassBase.BattlePassUIGameFeatureAction.BattlePassResourceWidgetClass_69
	unsigned char                                      UnknownData02[0x28];                                      // 0x0078(0x0028) UNKNOWN PROPERTY: SoftClassProperty BattlePassBase.BattlePassUIGameFeatureAction.BattlePassInfoModalClass_69

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class BattlePassBase.BattlePassUIGameFeatureAction"));
		
		return ptr;
	}

};


// Class BattlePassBase.FortBattlePassCustomSkinCategoryTile
// 0x00B8 (0x0320 - 0x0268)
class FortBattlePassCustomSkinCategoryTile : public UserWidget
{
public:
	unsigned char                                      UnknownData00[0x20];                                      // 0x0268(0x0020) MISSED OFFSET
	class ProgressBar*                                 ProgressBar_69;                                           // 0x0288(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	class FortDynamicEntryBox*                         FortDynamicEntryBox_Items_69;                             // 0x0290(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	class RichTextBlock*                               Text_CategoryTitle_69;                                    // 0x0298(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	class FortBattlePassTile*                          PreviewedTile_69;                                         // 0x02A0(0x0008) (ExportObject, ZeroConstructor, Transient, InstancedReference)
	int                                                OwnedRewards_69;                                          // 0x02A8(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x74];                                      // 0x02AC(0x0074) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class BattlePassBase.FortBattlePassCustomSkinCategoryTile"));
		
		return ptr;
	}


	void SetPreviewedTile(int Index_69);
	void OnOwnedTilesUpdated(int CurrentlyOwnedRewards_69, int TotalRewards_69, float CategoryProgress_69);
	void OnLockedStateChanged(bool bCategoryLocked_69);
	void OnLockedProgressUpdated(int CurrentlyOwnedBeforeCategory_69, int TotalRewardsBeforeCategory_69, float LockedProgress_69);
	void FocusTile(int Index_69);
};


// Class BattlePassBase.FortBattlePassCustomSkinPageBase
// 0x01A0 (0x0548 - 0x03A8)
class FortBattlePassCustomSkinPageBase : public CommonActivatableWidget
{
public:
	unsigned char                                      UnknownData00[0x178];                                     // 0x03A8(0x0178) MISSED OFFSET
	class ScrollBox*                                   ScrollBox_Categories_69;                                  // 0x0520(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	class FortDynamicEntryBox*                         FortDynamicEntryBox_Categories_69;                        // 0x0528(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	unsigned char                                      UnknownData01[0x8];                                       // 0x0530(0x0008) MISSED OFFSET
	class BattlePassEnabledInputData*                  EquipEnabledData_69;                                      // 0x0538(0x0008) (ZeroConstructor, Transient)
	unsigned char                                      UnknownData02[0x8];                                       // 0x0540(0x0008) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class BattlePassBase.FortBattlePassCustomSkinPageBase"));
		
		return ptr;
	}

};


// Class BattlePassBase.FortBattlePassBulkBuyPageBase
// 0x0178 (0x0520 - 0x03A8)
class FortBattlePassBulkBuyPageBase : public CommonActivatableWidget
{
public:
	unsigned char                                      UnknownData00[0xF8];                                      // 0x03A8(0x00F8) MISSED OFFSET
	class CommonButtonBase*                            Button_Addition_69;                                       // 0x04A0(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)
	class CommonButtonBase*                            Button_Subtraction_69;                                    // 0x04A8(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)
	class DynamicEntryBox*                             DynamicEntryBox_TilesEntries_69;                          // 0x04B0(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)
	class CommonVisibilitySwitcher*                    Switcher_BottomButtons_69;                                // 0x04B8(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)
	class FortHoldableButton*                          Button_BuyLevels_69;                                      // 0x04C0(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)
	class FortHoldableButton*                          Button_ClaimReward_69;                                    // 0x04C8(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)
	class AthenaSeasonItemData_BattleStar*             SeasonData_BattleStar_69;                                 // 0x04D0(0x0008) (ExportObject, ZeroConstructor, Transient, InstancedReference)
	class AthenaSeasonItemDefinition*                  SeasonItemDefinition_69;                                  // 0x04D8(0x0008) (ZeroConstructor, Transient)
	class FortBattlePassTile*                          FocusedReward_69;                                         // 0x04E0(0x0008) (ExportObject, ZeroConstructor, Transient, InstancedReference)
	unsigned char                                      UnknownData01[0x30];                                      // 0x04E8(0x0030) MISSED OFFSET
	class ScrollBox*                                   ScrollBox_Pages_69;                                       // 0x0518(0x0008) (ExportObject, ZeroConstructor, InstancedReference)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class BattlePassBase.FortBattlePassBulkBuyPageBase"));
		
		return ptr;
	}


	void OnRewardCountChanged(int Count_69);
	void OnPageRangeChanged(int FromPage_69, int ToPage_69);
	void OnCostChanged(int Cost_69);
	void HandleUserScrolled(float ScrollAmount_69);
};


// Class BattlePassBase.FortBattlePassCheckBoxButton
// 0x0010 (0x13F0 - 0x13E0)
class FortBattlePassCheckBoxButton : public CommonButtonBase
{
public:
	unsigned char                                      UnknownData00[0x10];                                      // 0x13E0(0x0010) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class BattlePassBase.FortBattlePassCheckBoxButton"));
		
		return ptr;
	}


	void OnStateChanged(bool bNewIsChecked_69);
};


// Class BattlePassBase.FortBattlePassContext
// 0x0078 (0x00A8 - 0x0030)
class FortBattlePassContext : public BlueprintContextBase
{
public:
	unsigned char                                      UnknownData00[0x8];                                       // 0x0030(0x0008) MISSED OFFSET
	TArray<class FortPersistentResourceItemDefinition*> CustomizationPageSeasonalResources_69;                    // 0x0038(0x0010) (ZeroConstructor)
	TArray<class FortPersistentResourceItemDefinition*> AllSeasonalResources_69;                                  // 0x0048(0x0010) (ZeroConstructor)
	TMap<ERewardPageType, struct FSeasonalResourceList> RewardPageSeasonalResources_69;                           // 0x0058(0x0050)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class BattlePassBase.FortBattlePassContext"));
		
		return ptr;
	}


	TArray<struct FSeasonCurrencyMcpData> GetSeasonalCurrencies();
	struct FText GetLevelPurchaseDisclaimerText();
	struct FText GetDefaultDisclaimerText();
	struct FText GetCurrentSeasonNumberAsText(bool bFullText_69);
	struct FText GetCurrentChapterAsText(bool bFullText_69);
	bool CanPurchaseBattlePassLevel();
};


// Class BattlePassBase.FortBattlePassResourcesWidgetBase
// 0x0010 (0x02A0 - 0x0290)
class FortBattlePassResourcesWidgetBase : public FortGlobalSeasonResourceWidget
{
public:
	class FortBattlePassResourceCounter*               ResourceCounterClass_69;                                  // 0x0290(0x0008) (Edit, ZeroConstructor, DisableEditOnInstance)
	class DynamicEntryBox*                             EntryBox_ResourceCounters_69;                             // 0x0298(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class BattlePassBase.FortBattlePassResourcesWidgetBase"));
		
		return ptr;
	}


	void ShowResourcesInfoModal();
	void OnShowMoreInfo(bool bShouldShowMoreInfo_69);
};


// Class BattlePassBase.FortBattlePassCurrencyPanel
// 0x0040 (0x02E0 - 0x02A0)
class FortBattlePassCurrencyPanel : public FortBattlePassResourcesWidgetBase
{
public:
	class HorizontalBox*                               HBox_BattleStarContainer_69;                              // 0x02A0(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	class CommonTextBlock*                             Text_BattleStar_69;                                       // 0x02A8(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	class HorizontalBox*                               HBox_CustomSkinContainer_69;                              // 0x02B0(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	class CommonTextBlock*                             Text_CustomSkin_69;                                       // 0x02B8(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	unsigned char                                      UnknownData00[0x20];                                      // 0x02C0(0x0020) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class BattlePassBase.FortBattlePassCurrencyPanel"));
		
		return ptr;
	}

};


// Class BattlePassBase.FortBattlePassPrerequisiteHeader
// 0x0008 (0x0270 - 0x0268)
class FortBattlePassPrerequisiteHeader : public UserWidget
{
public:
	class TextBlock*                                   Text_Prerequisite_69;                                     // 0x0268(0x0008) (ExportObject, ZeroConstructor, InstancedReference)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class BattlePassBase.FortBattlePassPrerequisiteHeader"));
		
		return ptr;
	}

};


// Class BattlePassBase.FortBattlePassPurchaseResourcesWidget
// 0x00C0 (0x0468 - 0x03A8)
class FortBattlePassPurchaseResourcesWidget : public CommonActivatableWidget
{
public:
	unsigned char                                      UnknownData00[0x8];                                       // 0x03A8(0x0008) MISSED OFFSET
	class CommonButtonBase*                            Button_Addition_69;                                       // 0x03B0(0x0008) (BlueprintVisible, ExportObject, ZeroConstructor, InstancedReference)
	class CommonButtonBase*                            Button_BatchAddition_69;                                  // 0x03B8(0x0008) (BlueprintVisible, ExportObject, ZeroConstructor, InstancedReference)
	class CommonButtonBase*                            Button_Subtraction_69;                                    // 0x03C0(0x0008) (BlueprintVisible, ExportObject, ZeroConstructor, InstancedReference)
	class CommonButtonBase*                            Button_BatchSubtraction_69;                               // 0x03C8(0x0008) (BlueprintVisible, ExportObject, ZeroConstructor, InstancedReference)
	class CommonVisibilitySwitcher*                    Switcher_PurchaseButtons_69;                              // 0x03D0(0x0008) (BlueprintVisible, ExportObject, ZeroConstructor, InstancedReference)
	class FortHoldableButton*                          Button_Purchase_69;                                       // 0x03D8(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	class CommonButtonBase*                            Button_GetVBucks_69;                                      // 0x03E0(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	class CommonButtonBase*                            Button_ReloadMtx_69;                                      // 0x03E8(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	class CommonButtonBase*                            Button_Back_69;                                           // 0x03F0(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	class FortBattlePassCheckBoxButton*                CheckBox_Bundle_69;                                       // 0x03F8(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	class CommonButtonBase*                            Button_CloseMobile_69;                                    // 0x0400(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	int                                                CurrentLevel_69;                                          // 0x0408(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	bool                                               bIsOfferActive_69;                                        // 0x040C(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x3];                                       // 0x040D(0x0003) MISSED OFFSET
	int                                                CurrentVBucks_69;                                         // 0x0410(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                CurrentBattleStars_69;                                    // 0x0414(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                BatchNum_69;                                              // 0x0418(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	int                                                CurrentPage_69;                                           // 0x041C(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	bool                                               bOfferUnavailable_69;                                     // 0x0420(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData02[0x3];                                       // 0x0421(0x0003) MISSED OFFSET
	int                                                MaxBundleLevel_69;                                        // 0x0424(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                MaxLevel_69;                                              // 0x0428(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                MaxLevelPurchases_69;                                     // 0x042C(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                BundleAmount_69;                                          // 0x0430(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData03[0x4];                                       // 0x0434(0x0004) MISSED OFFSET
	class FortItemDefinition*                          LevelPreviewItem_69;                                      // 0x0438(0x0008) (Edit, ZeroConstructor)
	unsigned char                                      UnknownData04[0x28];                                      // 0x0440(0x0028) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class BattlePassBase.FortBattlePassPurchaseResourcesWidget"));
		
		return ptr;
	}


	void OnTotalPriceChanged(int NewPrice_69);
	void OnPurchaseAmountChanged(int NewAmount_69, int LevelsLeft_69);
	void OnOfferUnavailable();
	void OnAmountChangeButtonClicked();
	bool IsReloadMtxEnabled();
	void HandlePurchaseMultiComplete(bool bSuccess_69, TArray<struct FPurchasedItemInfo> PurchasedItems_69, TArray<struct FString> OfferIdList_69);
	void HandlePurchaseComplete(bool bSuccess_69, TArray<struct FPurchasedItemInfo> PurchasedItems_69, const struct FString& OfferId_69);
};


// Class BattlePassBase.FortBattlePassResourceCounter
// 0x0020 (0x02B0 - 0x0290)
class FortBattlePassResourceCounter : public CommonUserWidget
{
public:
	class CommonTextBlock*                             Text_ResourceName_69;                                     // 0x0290(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)
	class FortLazyImage*                               LazyImage_ResourceIcon_69;                                // 0x0298(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)
	class CommonTextBlock*                             Text_ResourceCount_69;                                    // 0x02A0(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)
	class FortPersistentResourceItemDefinition*        CurrentResource_69;                                       // 0x02A8(0x0008) (ZeroConstructor, Transient)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class BattlePassBase.FortBattlePassResourceCounter"));
		
		return ptr;
	}

};


// Class BattlePassBase.FortBattlePassRewardGrid
// 0x00D0 (0x0478 - 0x03A8)
class FortBattlePassRewardGrid : public CommonActivatableWidget
{
public:
	unsigned char                                      UnknownData00[0x68];                                      // 0x03A8(0x0068) MISSED OFFSET
	class FortBattlePassTileBase*                      GridTileClass_69;                                         // 0x0410(0x0008) (Edit, ZeroConstructor)
	class FortBattlePassTileBase*                      GridEmptyTileClass_69;                                    // 0x0418(0x0008) (Edit, ZeroConstructor)
	struct FVector2D                                   GridCellPadding_69;                                       // 0x0420(0x0010) (Edit, ZeroConstructor, IsPlainOldData)
	class FortBattlePassRewardGridHeader*              PageHeader_69;                                            // 0x0430(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)
	class GridPanel*                                   GridPanel_Rewards_69;                                     // 0x0438(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	class FortBattlePassTileBase*                      DefaultFocusTile_69;                                      // 0x0440(0x0008) (ExportObject, ZeroConstructor, Transient, InstancedReference)
	TWeakObjectPtr<class CommonButtonBase>             LastFocusedTile_69;                                       // 0x0448(0x0008) (ExportObject, ZeroConstructor, Transient, InstancedReference, IsPlainOldData)
	unsigned char                                      UnknownData01[0x28];                                      // 0x0450(0x0028) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class BattlePassBase.FortBattlePassRewardGrid"));
		
		return ptr;
	}


	void OnPageUnselected();
	void OnPageSelected();
};


// Class BattlePassBase.FortBattlePassRewardGridHeader
// 0x0008 (0x0270 - 0x0268)
class FortBattlePassRewardGridHeader : public UserWidget
{
public:
	unsigned char                                      UnknownData00[0x8];                                       // 0x0268(0x0008) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class BattlePassBase.FortBattlePassRewardGridHeader"));
		
		return ptr;
	}


	void OnSetPageType(ERewardPageType PageType_69);
	void OnSetPageCustomName(const struct FText& CustomName_69);
	void OnPageUnlocked(int PurchasedRewards_69, int TotalRewards_69);
	void OnPageNumberSet(int InPageNumber_69);
	void OnPageLocked(int RequiredLevel_69, int RequiredRewards_69, bool IsTimeLocked_69, const struct FTimespan& TimeRemaining_69);
	void OnBattlePassLevelSet(int BattlePassLevel_69);
	int GetPageNumber();
};


// Class BattlePassBase.FortBattlePassRewardTrack
// 0x0090 (0x0438 - 0x03A8)
class FortBattlePassRewardTrack : public CommonActivatableWidget
{
public:
	unsigned char                                      UnknownData00[0x40];                                      // 0x03A8(0x0040) MISSED OFFSET
	class FortBattlePassTileBase*                      RewardTileClass_69;                                       // 0x03E8(0x0008) (Edit, ZeroConstructor, DisableEditOnInstance)
	class FortBattlePassTileBase*                      RewardEmptyTileClass_69;                                  // 0x03F0(0x0008) (Edit, ZeroConstructor, DisableEditOnInstance)
	class FortBattlePassPrerequisiteHeader*            PrerequisiteHeaderClass_69;                               // 0x03F8(0x0008) (Edit, ZeroConstructor, DisableEditOnInstance)
	struct FVector2D                                   GridCellPadding_69;                                       // 0x0400(0x0010) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	class GridPanel*                                   GridPanel_Rewards_69;                                     // 0x0410(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	class FortBattlePassTileBase*                      DefaultFocusTile_69;                                      // 0x0418(0x0008) (ExportObject, ZeroConstructor, Transient, InstancedReference)
	TWeakObjectPtr<class CommonButtonBase>             LastFocusedTile_69;                                       // 0x0420(0x0008) (ExportObject, ZeroConstructor, Transient, InstancedReference, IsPlainOldData)
	unsigned char                                      UnknownData01[0x10];                                      // 0x0428(0x0010) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class BattlePassBase.FortBattlePassRewardTrack"));
		
		return ptr;
	}


	void OnPageUnselected();
	void OnPageSelected();
};


// Class BattlePassBase.FortBattlePassTileBase
// 0x00A0 (0x1520 - 0x1480)
class FortBattlePassTileBase : public FortHoldableButton
{
public:
	class SizeBox*                                     SizeBox_Content_69;                                       // 0x1480(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	TMap<struct FName, struct FLinearColor>            TileColors_69;                                            // 0x1488(0x0050) (BlueprintVisible, BlueprintReadOnly)
	float                                              UnitHeight_69;                                            // 0x14D8(0x0004) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	float                                              UnitWidth_69;                                             // 0x14DC(0x0004) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData00[0x40];                                      // 0x14E0(0x0040) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class BattlePassBase.FortBattlePassTileBase"));
		
		return ptr;
	}


	void SetState(EBattlePassTileAvailabilityStates NewState_69);
	void SetSize(EPageItemTileSize TileSize_69, const struct FVector2D& CellSpacing_69);
	void OnStateChanged(EBattlePassTileAvailabilityStates NewState_69);
	void OnSizeChanged(const struct FVector2D& NewSize_69);
	void OnSetTileColors();
	void OnSetRequiresBattlePass(bool bRequiresBP_69);
	void OnRevealed();
	void OnPeeked();
	bool IsOwned();
	bool IsLocked();
	bool IsAvailable();
	EBattlePassTileAvailabilityStates GetState();
};


// Class BattlePassBase.FortBattlePassTile
// 0x0070 (0x1590 - 0x1520)
class FortBattlePassTile : public FortBattlePassTileBase
{
public:
	unsigned char                                      UnknownData00[0x10];                                      // 0x1520(0x0010) MISSED OFFSET
	class FortLazyImage*                               Image_RewardItem_69;                                      // 0x1530(0x0008) (BlueprintVisible, ExportObject, ZeroConstructor, InstancedReference)
	class Image*                                       Image_Currency_69;                                        // 0x1538(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)
	unsigned char                                      UnknownData01[0x50];                                      // 0x1540(0x0050) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class BattlePassBase.FortBattlePassTile"));
		
		return ptr;
	}


	void OnUnpreviewed();
	void OnUnhighlighted();
	void OnTilePreviewCycled();
	void OnSetTrack(bool bIsFreeTrack_69, bool bOwnsBattlePass_69);
	void OnSetCurrencyAndPrice(EBattlePassCurrencyType Currency_69, int Price_69);
	void OnPreviewed();
	void OnLockedStateUpdated(bool OwnsBattlePass_69, bool ParentUnlocked_69, bool HasRemainingPrerequisites_69, bool bIsDelayed_69);
	void OnLockedProgressUpdated(float Progress_69, int CurrentlyOwnedRewards_69, int NeededRewards_69);
	void OnHighlighted();
	void OnAffordabilityChanged(bool bHasEnougCurrency_69);
	bool IsAffordable();
	bool HasPrerequisites();
};


// Class BattlePassBase.FortBattlePassTutorialTooltip
// 0x0010 (0x02A0 - 0x0290)
class FortBattlePassTutorialTooltip : public CommonUserWidget
{
public:
	class CommonRichTextBlock*                         Text_Tooltip_69;                                          // 0x0290(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)
	unsigned char                                      UnknownData00[0x8];                                       // 0x0298(0x0008) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class BattlePassBase.FortBattlePassTutorialTooltip"));
		
		return ptr;
	}


	void ShowTooltip();
	void SetTooltipEnabled(bool bEnable_69);
	void SetText(const struct FText& Text_69);
	void HideTooltip();
};


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

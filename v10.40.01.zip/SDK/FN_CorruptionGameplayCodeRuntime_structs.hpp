#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Enums
//---------------------------------------------------------------------------

// Enum CorruptionGameplayCodeRuntime.EWarEffortFundingStationType
enum class EWarEffortFundingStationType : uint8_t
{
	Final                          = 0,
	Tower                          = 1,
	Choice                         = 2,
	EWarEffortFundingStationType_MAX = 3
};



//---------------------------------------------------------------------------
//Script Structs
//---------------------------------------------------------------------------

// ScriptStruct CorruptionGameplayCodeRuntime.WarEffortIndexedFundingData
// 0x0020
struct FWarEffortIndexedFundingData
{
	TArray<int64_t>                                    CurrentFundingArray_69;                                   // 0x0000(0x0010) (BlueprintVisible, ZeroConstructor)
	int64_t                                            FinalFundingAmount_69;                                    // 0x0010(0x0008) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int64_t                                            TowerFundingAmount_69;                                    // 0x0018(0x0008) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct CorruptionGameplayCodeRuntime.WarEffortFundingOptionData
// 0x0010
struct FWarEffortFundingOptionData
{
	struct FGameplayTag                                OptionTag_69;                                             // 0x0000(0x0004) (BlueprintVisible)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0004(0x0004) MISSED OFFSET
	int64_t                                            CurrentFundingAmount_69;                                  // 0x0008(0x0008) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct CorruptionGameplayCodeRuntime.WarEffortFundingChoiceData
// 0x0028
struct FWarEffortFundingChoiceData
{
	struct FWarEffortFundingOptionData                 Option1_69;                                               // 0x0000(0x0010) (BlueprintVisible)
	struct FWarEffortFundingOptionData                 Option2_69;                                               // 0x0010(0x0010) (BlueprintVisible)
	int64_t                                            TargetFundingAmount_69;                                   // 0x0020(0x0008) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct CorruptionGameplayCodeRuntime.WarEffortFundingMetadata
// 0x002F (0x0030 - 0x0001)
struct FWarEffortFundingMetadata : public FMeshMetaDataStruct
{
	struct FWarEffortIndexedFundingData                IndexedFundingData_69;                                    // 0x0000(0x0020) (BlueprintVisible)
	TArray<struct FWarEffortFundingChoiceData>         FundingChoices_69;                                        // 0x0020(0x0010) (BlueprintVisible, ZeroConstructor)
};

// ScriptStruct CorruptionGameplayCodeRuntime.CorruptionCalendarEventData
// 0x0018
struct FCorruptionCalendarEventData
{
	struct FString                                     EventName_69;                                             // 0x0000(0x0010) (Edit, ZeroConstructor, DisableEditOnInstance)
	float                                              StartPercent_69;                                          // 0x0010(0x0004) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0014(0x0004) MISSED OFFSET
};

// ScriptStruct CorruptionGameplayCodeRuntime.CorruptionPauseEvent
// 0x0018
struct FCorruptionPauseEvent
{
	struct FString                                     EventName_69;                                             // 0x0000(0x0010) (Edit, ZeroConstructor)
	float                                              PercentDurationToPause_69;                                // 0x0010(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0014(0x0004) MISSED OFFSET
};

// ScriptStruct CorruptionGameplayCodeRuntime.TravelerStepCorruptionOverrideData
// 0x0050
struct FTravelerStepCorruptionOverrideData
{
	TMap<struct FString, float>                        PointGroupStepPercentOverrides_69;                        // 0x0000(0x0050) (Edit, DisableEditOnTemplate)
};

// ScriptStruct CorruptionGameplayCodeRuntime.CubeMovement_CorruptionGenerationSplinePointData
// 0x0070
struct FCubeMovement_CorruptionGenerationSplinePointData
{
	struct FCoreUObject_FTransform                     SplinePointTransform_69;                                  // 0x0000(0x0060) (BlueprintVisible, BlueprintReadOnly, IsPlainOldData)
	float                                              SplinePercentComplete_69;                                 // 0x0060(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0xC];                                       // 0x0064(0x000C) MISSED OFFSET
};

// ScriptStruct CorruptionGameplayCodeRuntime.CubeMovement_CorruptionGenerationTravelerData
// 0x0018
struct FCubeMovement_CorruptionGenerationTravelerData
{
	TArray<struct FCubeMovement_CorruptionGenerationSplinePointData> SplinePointData_69;                                       // 0x0000(0x0010) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
	class FortScriptedObjectMovement_MovableObjectBase* PathTraveler_69;                                          // 0x0010(0x0008) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
};

// ScriptStruct CorruptionGameplayCodeRuntime.CubeMovement_CorruptionGenerationData
// 0x0010
struct FCubeMovement_CorruptionGenerationData
{
	TArray<struct FCubeMovement_CorruptionGenerationTravelerData> TravelerData_69;                                          // 0x0000(0x0010) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
};

// ScriptStruct CorruptionGameplayCodeRuntime.WarEffortMutatorMetadata
// 0x001F (0x0020 - 0x0001)
struct FWarEffortMutatorMetadata : public FMeshMetaDataStruct
{
	TArray<struct FGameplayTag>                        ActiveFundedItems_69;                                     // 0x0000(0x0010) (BlueprintVisible, ZeroConstructor)
	TArray<struct FGameplayTag>                        ActiveTryBeforeYouBuyItems_69;                            // 0x0010(0x0010) (BlueprintVisible, ZeroConstructor)
};

// ScriptStruct CorruptionGameplayCodeRuntime.WarEffortMutatorChoiceData
// 0x0068
struct FWarEffortMutatorChoiceData
{
	struct FGameplayTag                                FundingTag_69;                                            // 0x0000(0x0004) (Edit)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0004(0x0004) MISSED OFFSET
	unsigned char                                      UnknownData01[0x10];                                      // 0x0004(0x0010) UNKNOWN PROPERTY: ArrayProperty CorruptionGameplayCodeRuntime.WarEffortMutatorChoiceData.SoftRefsToLoad_69
	TMap<struct FName, struct FScalableFloat>          LootTableMods_69;                                         // 0x0018(0x0050) (Edit)
};

// ScriptStruct CorruptionGameplayCodeRuntime.WarEffortFundingData
// 0x0008
struct FWarEffortFundingData
{
	struct FGameplayTag                                FundingTag_69;                                            // 0x0000(0x0004)
	float                                              FundedPercent_69;                                         // 0x0004(0x0004) (ZeroConstructor, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

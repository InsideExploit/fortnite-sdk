#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Classes
//---------------------------------------------------------------------------

// Class CampsiteRuntime.AbandonedCampsiteManager
// 0x0180 (0x0408 - 0x0288)
class AbandonedCampsiteManager : public Actor_32759
{
public:
	struct FScalableFloat                              MinNumAbandonedCampsites_69;                              // 0x0288(0x0028) (Edit, BlueprintVisible, BlueprintReadOnly)
	struct FScalableFloat                              MaxNumAbandonedCampsites_69;                              // 0x02B0(0x0028) (Edit, BlueprintVisible, BlueprintReadOnly)
	struct FScalableFloat                              AbandonedCampsitesEnabled_69;                             // 0x02D8(0x0028) (Edit, BlueprintVisible, BlueprintReadOnly)
	TMap<EAbandonedCampsiteSpawnType, struct FScalableFloat> SpawnTypeWeights_69;                                      // 0x0300(0x0050) (Edit, BlueprintVisible, BlueprintReadOnly)
	unsigned char                                      UnknownData00[0x28];                                      // 0x0350(0x0028) UNKNOWN PROPERTY: SoftObjectProperty CampsiteRuntime.AbandonedCampsiteManager.Spawn_EnvironmentalQuery_69
	unsigned char                                      UnknownData01[0x28];                                      // 0x0378(0x0028) UNKNOWN PROPERTY: SoftClassProperty CampsiteRuntime.AbandonedCampsiteManager.AbandonedCampsiteAsset_69
	TArray<class AbandonedCampsitePlacedSpawner*>      PreplacedCampsiteSpawnPoints_69;                          // 0x03A0(0x0010) (ZeroConstructor, Transient)
	TArray<class AbandonedCampsitePlacedSpawner*>      DeferredPreplacedCampsiteSpawns_69;                       // 0x03B0(0x0010) (ZeroConstructor, Transient)
	unsigned char                                      UnknownData02[0x10];                                      // 0x03C0(0x0010) MISSED OFFSET
	class CampsiteAnalytics*                           Analytics_69;                                             // 0x03D0(0x0008) (ZeroConstructor, Transient)
	unsigned char                                      UnknownData03[0x30];                                      // 0x03D8(0x0030) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CampsiteRuntime.AbandonedCampsiteManager"));
		
		return ptr;
	}


	void OnGamePhaseStepChanged(const TScriptInterface<class FortSafeZoneInterface>& SafeZoneInterface_69, EAthenaGamePhaseStep GamePhaseStep_69);
};


// Class CampsiteRuntime.AbandonedCampsitePlacedSpawner
// 0x0028 (0x02B0 - 0x0288)
class AbandonedCampsitePlacedSpawner : public Actor_32759
{
public:
	unsigned char                                      UnknownData00[0x28];                                      // 0x0288(0x0028) UNKNOWN PROPERTY: SoftClassProperty CampsiteRuntime.AbandonedCampsitePlacedSpawner.AbandonedTentAsset_69

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CampsiteRuntime.AbandonedCampsitePlacedSpawner"));
		
		return ptr;
	}


	void SpawnCampsite();
};


// Class CampsiteRuntime.AbandonedTentSpawnPointComponent
// 0x0020 (0x0610 - 0x05F0)
class AbandonedTentSpawnPointComponent : public StaticMeshComponent
{
public:
	unsigned char                                      UnknownData00[0x20];                                      // 0x05F0(0x0020) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CampsiteRuntime.AbandonedTentSpawnPointComponent"));
		
		return ptr;
	}

};


// Class CampsiteRuntime.CampsiteAnalytics
// 0x0010 (0x0038 - 0x0028)
class CampsiteAnalytics : public Object_32759
{
public:
	unsigned char                                      UnknownData00[0x10];                                      // 0x0028(0x0010) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CampsiteRuntime.CampsiteAnalytics"));
		
		return ptr;
	}

};


// Class CampsiteRuntime.CampsiteConversationComponent
// 0x0000 (0x00A0 - 0x00A0)
class CampsiteConversationComponent : public ActorComponent
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CampsiteRuntime.CampsiteConversationComponent"));
		
		return ptr;
	}


	void StartConversation(class FortPlayerController* InstigatingController_69);
};


// Class CampsiteRuntime.CampsiteFunctionLibraryNative
// 0x0000 (0x0028 - 0x0028)
class CampsiteFunctionLibraryNative : public BlueprintFunctionLibrary
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CampsiteRuntime.CampsiteFunctionLibraryNative"));
		
		return ptr;
	}


	void STATIC_StoreHealthOnPickupFromProp(class BuildingProp* BuildingProp_69, class FortPickup* PickUp_69);
	void STATIC_SetHealthOnPropFromItemEntry(const struct FFortItemEntry& FortItem_69, class BuildingProp* BuildingProp_69);
	bool STATIC_IsItemEntryAvailable(class Object_32759* WorldContextObject_69, const struct FFortItemEntry& FortItem_69);
	bool STATIC_IsItemDefinitionAvailable(class Object_32759* WorldContextObject_69, class FortItemDefinition* FortItem_69);
	bool STATIC_IsItemAvailable(class Object_32759* WorldContextObject_69, class FortItem* FortItem_69);
	struct FFortItemEntry STATIC_GetItemEntryCopyFromWeapon(class FortWeapon* Weapon_69);
};


// Class CampsiteRuntime.CampsiteImprovementComponent
// 0x00D0 (0x0170 - 0x00A0)
class CampsiteImprovementComponent : public ActorComponent
{
public:
	struct FSlateBrush                                 MiniMapIconBrush_69;                                      // 0x00A0(0x00C0) (Edit, BlueprintVisible)
	int                                                ImprovementOwnerSquadId_69;                               // 0x0160(0x0004) (BlueprintVisible, BlueprintReadOnly, Net, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0164(0x0004) MISSED OFFSET
	class FortSimpleMiniMapIndicator*                  MinimapIndicator_69;                                      // 0x0168(0x0008) (ZeroConstructor, Transient)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CampsiteRuntime.CampsiteImprovementComponent"));
		
		return ptr;
	}


	void SetImprovementOwnerSquadId(int SquadId_69);
	void RemoveIndicator();
	void OnRep_ImprovementOwnerSquadId();
	void CreateIndicator();
};


// Class CampsiteRuntime.FortControllerComponent_CampsiteAccountItem
// 0x0040 (0x00E0 - 0x00A0)
class FortControllerComponent_CampsiteAccountItem : public ActorComponent
{
public:
	class FortCampsiteAccountItemDefinition*           CampsiteAccountItemDefinition_69;                         // 0x00A0(0x0008) (Edit, ZeroConstructor, DisableEditOnInstance)
	struct FCampsiteAccountData                        CampsiteAccountData_69;                                   // 0x00A8(0x0028) (Transient)
	TArray<struct FFortItemEntry>                      CurrentlyStashedItemEntries_69;                           // 0x00D0(0x0010) (ZeroConstructor, Transient)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CampsiteRuntime.FortControllerComponent_CampsiteAccountItem"));
		
		return ptr;
	}


	void WriteStashedItemFromEntry(class FortPlayerControllerAthena* PlayerController_69, const struct FFortItemEntry& ItemEntry_69, int StashedItemIndex_69);
	void WriteStashedItem(class FortPlayerControllerAthena* PlayerController_69, class FortWorldItem* Item_69, int StashedItemIndex_69);
	bool SwapStashedItem(class Actor_32759* SourceActor_69, int StashedItemIndex_69);
	bool StashCurrentlyHeldItemAndRemoveFromInventory(int StashedItemIndex_69);
	void OnAthenaProfileInitialized();
	bool HasCurrentlyStashedItem(int StashedItemIndex_69);
	struct FFortItemEntry GetCurrentlyStashedItemAsItemEntry(int StashedItemIndex_69);
	void ClearStoredCampsiteLocations();
	bool ClearStashedItemAndGiveToPlayer(class Actor_32759* SourceActor_69, int StashedItemIndex_69);
	void ClearStashedItem(int StashedItemIndex_69);
	void CacheAccountItemData();
};


// Class CampsiteRuntime.FortGameStateComponent_Campsite
// 0x0118 (0x01B8 - 0x00A0)
class FortGameStateComponent_Campsite : public FortGameStateComponent
{
public:
	unsigned char                                      UnknownData00[0x50];                                      // 0x00A0(0x0050) UNKNOWN PROPERTY: SetProperty CampsiteRuntime.FortGameStateComponent_Campsite.AllowedItemDefinitions_69
	unsigned char                                      UnknownData01[0x10];                                      // 0x00F0(0x0010) UNKNOWN PROPERTY: ArrayProperty CampsiteRuntime.FortGameStateComponent_Campsite.BlacklistedItemDefinitions_69
	TArray<struct FString>                             BlacklistedItemPaths_69;                                  // 0x0100(0x0010) (Edit, ZeroConstructor, Config, DisableEditOnInstance, EditConst)
	TArray<class AbandonedCampsitePlacedSpawner*>      PlacedCampsiteSpawnPoints_69;                             // 0x0110(0x0010) (ZeroConstructor, Transient)
	unsigned char                                      UnknownData02[0x18];                                      // 0x0120(0x0018) MISSED OFFSET
	unsigned char                                      UnknownData03[0x28];                                      // 0x0120(0x0028) UNKNOWN PROPERTY: SoftObjectProperty CampsiteRuntime.FortGameStateComponent_Campsite.BotNameDataAsset_69
	unsigned char                                      UnknownData04[0x50];                                      // 0x0160(0x0050) MISSED OFFSET
	class DataTable*                                   BotNameDataTable_69;                                      // 0x01B0(0x0008) (ZeroConstructor, Transient)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CampsiteRuntime.FortGameStateComponent_Campsite"));
		
		return ptr;
	}


	void RegisterPreplacedCampsite(class AbandonedCampsitePlacedSpawner* PreplacedCampsiteSpawnPoint_69);
	void RegisterCampsiteLocation(const struct FVector& NewCampsiteLocation_69);
	void ClaimUnusedBotName(struct FString* OutBotName_69);
};


// Class CampsiteRuntime.FortQueryTest_AbandonedCampsite
// 0x0068 (0x0260 - 0x01F8)
class FortQueryTest_AbandonedCampsite : public EnvQueryTest
{
public:
	float                                              TraceRadius_69;                                           // 0x01F8(0x0004) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x01FC(0x0004) MISSED OFFSET
	struct FVector                                     TraceStartOffset_69;                                      // 0x0200(0x0018) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	struct FVector                                     TraceEndOffset_69;                                        // 0x0218(0x0018) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	TEnumAsByte<ECollisionChannel>                     BlockingChannel_69;                                       // 0x0230(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData01[0x7];                                       // 0x0231(0x0007) MISSED OFFSET
	unsigned char                                      UnknownData02[0x28];                                      // 0x0231(0x0028) UNKNOWN PROPERTY: SoftObjectProperty CampsiteRuntime.FortQueryTest_AbandonedCampsite.BlockingMaterial_69

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CampsiteRuntime.FortQueryTest_AbandonedCampsite"));
		
		return ptr;
	}

};


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

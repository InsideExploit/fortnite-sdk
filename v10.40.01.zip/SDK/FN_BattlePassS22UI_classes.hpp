#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Classes
//---------------------------------------------------------------------------

// Class BattlePassS22UI.BattlePassLandingPageS22
// 0x0050 (0x0520 - 0x04D0)
class BattlePassLandingPageS22 : public BattlePassLandingPageBase
{
public:
	class BattlePassLandingPageButton*                 Button_Rewards_69;                                        // 0x04D0(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)
	class BattlePassLandingPageButton*                 Button_CharacterCustomizer_69;                            // 0x04D8(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)
	class BattlePassLandingPageButton*                 Button_BonusRewards_69;                                   // 0x04E0(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)
	class BattlePassLandingPageButton*                 Button_Quests_69;                                         // 0x04E8(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)
	class BattlePassLandingPageButton*                 Button_BuyBattlePass_69;                                  // 0x04F0(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)
	class BattlePassLandingPageButton*                 Button_JoinSubscription_69;                               // 0x04F8(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)
	class BattlePassLandingPageButton*                 Button_BuyResources_69;                                   // 0x0500(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)
	class BattlePassLandingPageButton*                 Button_GiftBattlePass_69;                                 // 0x0508(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)
	unsigned char                                      UnknownData00[0x8];                                       // 0x0510(0x0008) MISSED OFFSET
	class AthenaSeasonItemData_BattleStar*             SeasonData_BattleStar_69;                                 // 0x0518(0x0008) (ExportObject, ZeroConstructor, InstancedReference)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class BattlePassS22UI.BattlePassLandingPageS22"));
		
		return ptr;
	}


	void OnBattlePassSubscriptionAllowed(bool bSubscriptionAllowed_69);
	void OnBattlePassOwned();
	void OnBattlePassGiftingAllowed(bool bGiftingAllowed_69);
};


// Class BattlePassS22UI.BattlePassRewardPageS22
// 0x00A0 (0x0540 - 0x04A0)
class BattlePassRewardPageS22 : public BattlePassRewardPageBase
{
public:
	class FortBattlePassRewardGrid*                    RewardsGridClass_69;                                      // 0x04A0(0x0008) (Edit, ZeroConstructor)
	class FortPageNavigator*                           PageNavigator_69;                                         // 0x04A8(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	class FortBattlePassTile*                          FocusedReward_69;                                         // 0x04B0(0x0008) (ExportObject, ZeroConstructor, Transient, InstancedReference)
	TArray<class FortBattlePassRewardGrid*>            GridPages_69;                                             // 0x04B8(0x0010) (ExportObject, ZeroConstructor, Transient)
	unsigned char                                      UnknownData00[0x4];                                       // 0x04C8(0x0004) MISSED OFFSET
	ERewardPageType                                    RewardPageType_69;                                        // 0x04CC(0x0001) (Edit, ZeroConstructor, DisableEditOnTemplate, IsPlainOldData)
	unsigned char                                      UnknownData01[0x3];                                       // 0x04CD(0x0003) MISSED OFFSET
	int                                                HoldTileTooltip_ClaimedRewardsToHide_69;                  // 0x04D0(0x0004) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	int                                                HoldTileTooltip_RequiredBattleStarsToShow_69;             // 0x04D4(0x0004) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	struct FString                                     ClaimToonAFishTooltip_ClaimCheckTemplateId_69;            // 0x04D8(0x0010) (Edit, ZeroConstructor, DisableEditOnInstance)
	class FortBattlePassTutorialTooltipS22*            TutorialTooltip_SecondPageUnlock_69;                      // 0x04E8(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	class FortBattlePassTutorialTooltipS22*            TutorialTooltip_ClaimAllRewards_69;                       // 0x04F0(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	class FortBattlePassTutorialTooltipS22*            TutorialTooltip_HoldTile_69;                              // 0x04F8(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)
	class FortBattlePassTutorialTooltipS22*            TutorialTooltip_Fishtoon_ClaimToonAFish_69;               // 0x0500(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	class FortBattlePassTutorialTooltipS22*            TutorialTooltip_Fishtoon_ExploreToCollectInk_69;          // 0x0508(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	class FortBattlePassTutorialTooltipS22*            TutorialTooltip_Fishtoon_MustUnlockInkColor_69;           // 0x0510(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	class FortBattlePassTutorialTooltipS22*            TutorialTooltip_Fishtoon_MustCompleteObjective_69;        // 0x0518(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	class AthenaSeasonItemData_BattleStar*             SeasonData_BattleStar_69;                                 // 0x0520(0x0008) (ExportObject, ZeroConstructor, Transient, InstancedReference)
	class BattlePassBulkBuyInputData*                  BulkBuyInputData_69;                                      // 0x0528(0x0008) (ZeroConstructor, Transient)
	unsigned char                                      UnknownData02[0x10];                                      // 0x0530(0x0010) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class BattlePassS22UI.BattlePassRewardPageS22"));
		
		return ptr;
	}


	void OnPageChanged(int PageNumber_69);
	void OnInputMethodChanged(ECommonInputType InputType_69);
	void OnInitForPageType(ERewardPageType InRewardPageType_69);
};


// Class BattlePassS22UI.BattlePassScreenS22
// 0x03C0 (0x0BF8 - 0x0838)
class BattlePassScreenS22 : public BattlePassScreenBase
{
public:
	class FortBattlePassPurchaseResourcesWidget*       ResourcePurchaseScreenClass_69;                           // 0x0838(0x0008) (Edit, ZeroConstructor)
	unsigned char                                      UnknownData00[0x8];                                       // 0x0840(0x0008) MISSED OFFSET
	class CommonButtonLegacy*                          Button_Close_69;                                          // 0x0848(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)
	class CommonButtonLegacy*                          Button_CloseMobile_69;                                    // 0x0850(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)
	class CommonButtonBase*                            Button_BulkBuyRewards_69;                                 // 0x0858(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)
	class CommonButtonLegacy*                          Button_ToggleViewDetails_69;                              // 0x0860(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)
	class CommonButtonBase*                            Button_ToggleViewDetails_Mobile_69;                       // 0x0868(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)
	class CommonButtonLegacy*                          Button_ReplayTrailer_69;                                  // 0x0870(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)
	class CommonButtonBase*                            Button_ReplayTrailer_Mobile_69;                           // 0x0878(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)
	class CommonButtonLegacy*                          Button_ShowAbout_69;                                      // 0x0880(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)
	class CommonButtonBase*                            Button_ShowAbout_Mobile_69;                               // 0x0888(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)
	class CommonButtonLegacy*                          Button_ShowAboutCustomization_69;                         // 0x0890(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)
	class CommonButtonBase*                            Button_ShowAboutCustomization_Mobile_69;                  // 0x0898(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)
	class CommonVisibilitySwitcher*                    MobileVisibilitySwitcher_69;                              // 0x08A0(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)
	class FortBattlePassResourcesWidgetBase*           BattlePassCurrencyPanel_69;                               // 0x08A8(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	class AthenaExclusiveRewardBanner*                 AthenaExclusiveRewardBanner_69;                           // 0x08B0(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	class CommonTextBlock*                             Text_Description_69;                                      // 0x08B8(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)
	class CommonTextBlock*                             Text_ItemName_69;                                         // 0x08C0(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)
	class AthenaRewardItemTypeRarityTag*               ItemRewardTag_69;                                         // 0x08C8(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)
	class CommonTextBlock*                             Text_SetDetails_69;                                       // 0x08D0(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)
	class CommonVisibilitySwitcher*                    Switcher_ContextualButtons_69;                            // 0x08D8(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)
	class FortHoldableButton*                          Button_BuyLevels_69;                                      // 0x08E0(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)
	class FortHoldableButton*                          Button_BuyBattlePass_69;                                  // 0x08E8(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)
	class FortHoldableButton*                          Button_ClaimReward_69;                                    // 0x08F0(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)
	class Border*                                      Tag_RequiresBP_69;                                        // 0x08F8(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	class Border*                                      Tag_PageLocked_69;                                        // 0x0900(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	class Border*                                      Tag_BaseItem_69;                                          // 0x0908(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	class Border*                                      Tag_Prerequisite_69;                                      // 0x0910(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	class Border*                                      Tag_CompletePage_69;                                      // 0x0918(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	class Border*                                      Tag_NotEnough_Currency_69;                                // 0x0920(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	class Border*                                      Tag_Cost_69;                                              // 0x0928(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	class Border*                                      Tag_Owned_69;                                             // 0x0930(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	class Border*                                      Tag_Delayed_69;                                           // 0x0938(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	unsigned char                                      UnknownData01[0x58];                                      // 0x0940(0x0058) MISSED OFFSET
	class AthenaSeasonItemData_BattleStar*             SeasonData_BattleStar_69;                                 // 0x0998(0x0008) (ExportObject, ZeroConstructor, Transient, InstancedReference)
	class AthenaSeasonItemEntryBase*                   CurrentSelectedEntry_69;                                  // 0x09A0(0x0008) (ExportObject, ZeroConstructor, Transient, InstancedReference)
	TArray<EBattlePassView>                            SwitcherSubPageTypes_69;                                  // 0x09A8(0x0010) (Edit, ZeroConstructor)
	class CommonVisibilitySwitcher*                    SubPageSwitcher_69;                                       // 0x09B8(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	unsigned char                                      UnknownData02[0xC0];                                      // 0x09C0(0x00C0) MISSED OFFSET
	class FortItemDefinition*                          SeasonalBaseCustomizationItem_69;                         // 0x0A80(0x0008) (Edit, ZeroConstructor, DisableEditOnInstance)
	bool                                               bHasSubscription_69;                                      // 0x0A88(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData03[0x3];                                       // 0x0A89(0x0003) MISSED OFFSET
	int                                                BattleStarsTooltipHideLevel_69;                           // 0x0A8C(0x0004) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData04[0x8];                                       // 0x0A90(0x0008) MISSED OFFSET
	class FortBattlePassTutorialTooltipS22*            TutorialTooltip_BattleStars_69;                           // 0x0A98(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	class FortBattlePassTutorialTooltipS22*            TutorialTooltip_StylePoints_69;                           // 0x0AA0(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	unsigned char                                      UnknownData05[0x150];                                     // 0x0AA8(0x0150) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class BattlePassS22UI.BattlePassScreenS22"));
		
		return ptr;
	}


	void OverviewShowAnimationFinished();
	void OnTransitionItemDetails(bool bTransitionForward_69);
	void OnSetResourcePrice(int Cost_69, class FortPersistentResourceItemDefinition* PersistentResource_69);
	void OnSetPrerequisiteInfo(const struct FText& Description_69, int OwnedRewards_69, int NeededRewards_69, bool bShowPrerequisiteLock_69);
	void OnSetItemPrice(int Cost_69, EBattlePassCurrencyType CurrencyType_69);
	void OnSetDynamicInput(EBattlePassInputs InputType_69, class BattlePassInputData* InputData_69);
	void OnSetClaimedRewardInfo(int OwnedRewards_69, int TotalRewards_69);
	void OnLevelChanged(int Level_69);
	void OnItemDelayed(const struct FTimespan& Delay_69);
	void OnInsufficientResource(class FortPersistentResourceItemDefinition* PersistentResource_69);
	void OnInsufficientFunds(EBattlePassCurrencyType CurrencyType_69);
	void OnBattlePassOwned();
	bool IsSeasonalCustomizationItemOwned();
	void HandleSwitcherVisibilityShown();
	void HandleClaimRewardComplete(bool bSuccess_69, TArray<struct FString> OfferTemplateIdList_69);
	struct FTimespan GetQuestPageDelay();
};


// Class BattlePassS22UI.FortBattlePassCustomSkinPageS22
// 0x0018 (0x0560 - 0x0548)
class FortBattlePassCustomSkinPageS22 : public FortBattlePassCustomSkinPageBase
{
public:
	struct FString                                     ClaimBaseItemTooltip_ClaimCheckTemplateId_69;             // 0x0548(0x0010) (Edit, ZeroConstructor, DisableEditOnInstance)
	class FortBattlePassTutorialTooltip*               TutorialTooltip_ClaimBaseItem_69;                         // 0x0558(0x0008) (ExportObject, ZeroConstructor, InstancedReference)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class BattlePassS22UI.FortBattlePassCustomSkinPageS22"));
		
		return ptr;
	}

};


// Class BattlePassS22UI.FortBattlePassResourcesWidgetS22
// 0x0020 (0x02C0 - 0x02A0)
class FortBattlePassResourcesWidgetS22 : public FortBattlePassResourcesWidgetBase
{
public:
	class CommonTextBlock*                             Text_BattleStarsAmount_69;                                // 0x02A0(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)
	class CommonTextBlock*                             Text_StylePointsAmount_69;                                // 0x02A8(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)
	class Border*                                      Border_StylePointsRewardsTag_69;                          // 0x02B0(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)
	class Border*                                      Border_BattleStarsRewardsTag_69;                          // 0x02B8(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class BattlePassS22UI.FortBattlePassResourcesWidgetS22"));
		
		return ptr;
	}


	void OnStylePointsRewardsSet(int Rewards_69);
	void OnBattleStarRewardsSet(int Rewards_69);
};


// Class BattlePassS22UI.FortBattlePassTutorialTooltipS22
// 0x0010 (0x02A0 - 0x0290)
class FortBattlePassTutorialTooltipS22 : public CommonUserWidget
{
public:
	class CommonRichTextBlock*                         Text_Tooltip_69;                                          // 0x0290(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)
	unsigned char                                      UnknownData00[0x8];                                       // 0x0298(0x0008) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class BattlePassS22UI.FortBattlePassTutorialTooltipS22"));
		
		return ptr;
	}


	void ShowTooltip();
	void SetText(const struct FText& Text_69);
	void HideTooltip();
};


// Class BattlePassS22UI.RebootRallyQuestPanel
// 0x0000 (0x0268 - 0x0268)
class RebootRallyQuestPanel : public UserWidget
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class BattlePassS22UI.RebootRallyQuestPanel"));
		
		return ptr;
	}


	void OnRebootRallyEligibilityUpdated(bool bEligible_69);
};


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

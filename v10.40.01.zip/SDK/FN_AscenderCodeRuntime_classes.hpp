#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Classes
//---------------------------------------------------------------------------

// Class AscenderCodeRuntime.FortAscenderZipline
// 0x0338 (0x0F98 - 0x0C60)
class FortAscenderZipline : public FortAthenaSplineZipline
{
public:
	struct FName                                       SplineTopAttachPointName_69;                              // 0x0C60(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	bool                                               bAutoFindSplineEndLocation_69;                            // 0x0C64(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0C65(0x0003) MISSED OFFSET
	float                                              SplineOffsetFromGround_69;                                // 0x0C68(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              CableOffsetFromSplineEnd_69;                              // 0x0C6C(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              SplineLength_69;                                          // 0x0C70(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x4];                                       // 0x0C74(0x0004) MISSED OFFSET
	class StaticMesh*                                  SplineStaticMesh_69;                                      // 0x0C78(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
	TEnumAsByte<ESplineMeshAxis>                       MeshForwardAxis_69;                                       // 0x0C80(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	bool                                               bHandleReturning_69;                                      // 0x0C81(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData02[0x2];                                       // 0x0C82(0x0002) MISSED OFFSET
	float                                              HandleReturnSpeed_69;                                     // 0x0C84(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	bool                                               bCableDropping_69;                                        // 0x0C88(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData03[0x3];                                       // 0x0C89(0x0003) MISSED OFFSET
	float                                              CableDropSpeed_69;                                        // 0x0C8C(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              YawRotationOffsetWhileUsingHandle_69;                     // 0x0C90(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              YawRotationOffsetWhileSlidingDown_69;                     // 0x0C94(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	bool                                               bUseComplexSplineCollision_69;                            // 0x0C98(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData04[0x3];                                       // 0x0C99(0x0003) MISSED OFFSET
	float                                              SimpleSplineCollisionRadius_69;                           // 0x0C9C(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	float                                              SimpleSplineCollisionHeightExtension_69;                  // 0x0CA0(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData05[0x4];                                       // 0x0CA4(0x0004) MISSED OFFSET
	struct FScalableFloat                              DescendMinDistanceFromBottom_69;                          // 0x0CA8(0x0028) (Edit, BlueprintVisible, BlueprintReadOnly, DisableEditOnInstance)
	struct FScalableFloat                              AscendReachedEndHorizontalLaunchSpeed_69;                 // 0x0CD0(0x0028) (Edit, BlueprintVisible, BlueprintReadOnly, DisableEditOnInstance)
	struct FScalableFloat                              AscendReachedEndVerticalLaunchSpeed_69;                   // 0x0CF8(0x0028) (Edit, BlueprintVisible, BlueprintReadOnly, DisableEditOnInstance)
	struct FScalableFloat                              AscendJumpedOffHorizontalLaunchSpeed_69;                  // 0x0D20(0x0028) (Edit, BlueprintVisible, BlueprintReadOnly, DisableEditOnInstance)
	struct FScalableFloat                              AscendJumpedOffVerticalLaunchSpeed_69;                    // 0x0D48(0x0028) (Edit, BlueprintVisible, BlueprintReadOnly, DisableEditOnInstance)
	struct FScalableFloat                              DescendReachedEndHorizontalLaunchSpeed_69;                // 0x0D70(0x0028) (Edit, BlueprintVisible, BlueprintReadOnly, DisableEditOnInstance)
	struct FScalableFloat                              DescendReachedEndVerticalLaunchSpeed_69;                  // 0x0D98(0x0028) (Edit, BlueprintVisible, BlueprintReadOnly, DisableEditOnInstance)
	struct FScalableFloat                              DescendJumpedOffHorizontalLaunchSpeed_69;                 // 0x0DC0(0x0028) (Edit, BlueprintVisible, BlueprintReadOnly, DisableEditOnInstance)
	struct FScalableFloat                              DescendJumpedOffVerticalLaunchSpeed_69;                   // 0x0DE8(0x0028) (Edit, BlueprintVisible, BlueprintReadOnly, DisableEditOnInstance)
	struct FScalableFloat                              HandleActorHitPlayerHorizontalLaunchSpeed_69;             // 0x0E10(0x0028) (Edit, BlueprintVisible, BlueprintReadOnly, DisableEditOnInstance)
	struct FScalableFloat                              HandleActorHitPlayerVerticalLaunchSpeed_69;               // 0x0E38(0x0028) (Edit, BlueprintVisible, BlueprintReadOnly, DisableEditOnInstance)
	struct FVector                                     HandleDestroyBuildingsOverlapExtents_69;                  // 0x0E60(0x0018) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	struct FVector                                     PlayerDestroyBuildingsOverlapExtents_69;                  // 0x0E78(0x0018) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	struct FVector                                     InitialSplineEndLocation_69;                              // 0x0E90(0x0018) (BlueprintVisible, BlueprintReadOnly, Net, ZeroConstructor, IsPlainOldData)
	struct FVector                                     CurrentSplineEndLocation_69;                              // 0x0EA8(0x0018) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	struct FVector                                     TargetSplineEndLocation_69;                               // 0x0EC0(0x0018) (BlueprintVisible, BlueprintReadOnly, Net, ZeroConstructor, IsPlainOldData)
	struct FVector                                     CurrentHandleLocation_69;                                 // 0x0ED8(0x0018) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	TWeakObjectPtr<class PrimitiveComponent>           CurrentInteractComponent_69;                              // 0x0EF0(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, Transient, InstancedReference, IsPlainOldData)
	TWeakObjectPtr<class FortPlayerPawn>               PawnUsingHandle_69;                                       // 0x0EF8(0x0008) (Net, ZeroConstructor, Transient, IsPlainOldData)
	TWeakObjectPtr<class FortPlayerPawn>               PreviousPawnUsingHandle_69;                               // 0x0F00(0x0008) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, Transient, IsPlainOldData)
	class SplineMeshComponent*                         SplineMesh_69;                                            // 0x0F08(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)
	class CapsuleComponent*                            SimpleSplineMeshCollision_69;                             // 0x0F10(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)
	TWeakObjectPtr<class BuildingActor>                FloorActor_69;                                            // 0x0F18(0x0008) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, Transient, IsPlainOldData)
	TArray<TWeakObjectPtr<class FortPlayerPawn>>       RotationLockedPawns_69;                                   // 0x0F20(0x0010) (ZeroConstructor, Transient)
	unsigned char                                      UnknownData06[0x68];                                      // 0x0F30(0x0068) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AscenderCodeRuntime.FortAscenderZipline"));
		
		return ptr;
	}


	void OnRep_TargetSplineEndLocation();
	void OnRep_PawnUsingHandle();
	void OnRep_InitialSplineEndLocation();
	void HandlePawnUsingHandleDied(class FortPawn* DeadPawn_69);
	void HandleFloorActorHealthChanged();
	void HandleFloorActorDestroyed(class Actor_32759* Actor_69);
	class PrimitiveComponent* GetTopComponent();
	class FortPlayerPawn* GetPawnUsingHandle();
	class PrimitiveComponent* GetInteractComponentOverride(class FortPlayerPawn* InteractingPawn_69, class PrimitiveComponent* InteractComponent_69);
	class PrimitiveComponent* GetHandleComponent();
	void BP_HandleUpdatedLoweringHandle();
	void BP_HandleUpdatedLoweringCable();
	void BP_HandleStoppedLoweringHandle();
	void BP_HandleStoppedLoweringCable();
	void BP_HandleStartedLoweringHandle();
	void BP_HandleStartedLoweringCable();
	void BP_HandlePlayerStoppedUsingHandle(class FortPlayerPawn* Player_69);
	void BP_HandlePlayerStartedUsingHandle(class FortPlayerPawn* Player_69);
	void ApplyStructureDamage(class BuildingSMActor* BuildingActor_69, class Actor_32759* DamageSource_69);
};


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

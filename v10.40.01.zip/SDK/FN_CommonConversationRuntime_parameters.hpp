#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function CommonConversationRuntime.ConversationParticipantComponent.ServerAdvanceConversation
struct ConversationParticipantComponent_ServerAdvanceConversation_Params
{
	struct FAdvanceConversationRequest                 InChoicePicked_69;                                        // (ConstParm, Parm, ReferenceParm)
};

// Function CommonConversationRuntime.ConversationParticipantComponent.RequestServerAdvanceConversation
struct ConversationParticipantComponent_RequestServerAdvanceConversation_Params
{
	struct FAdvanceConversationRequest                 InChoicePicked_69;                                        // (ConstParm, Parm, OutParm, ReferenceParm)
};

// Function CommonConversationRuntime.ConversationParticipantComponent.OnRep_ConversationsActive
struct ConversationParticipantComponent_OnRep_ConversationsActive_Params
{
	int                                                OldConversationsActive_69;                                // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function CommonConversationRuntime.ConversationParticipantComponent.IsInActiveConversation
struct ConversationParticipantComponent_IsInActiveConversation_Params
{
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CommonConversationRuntime.ConversationParticipantComponent.GetParticipantDisplayName
struct ConversationParticipantComponent_GetParticipantDisplayName_Params
{
	struct FText                                       ReturnValue_69;                                           // (Parm, OutParm, ReturnParm)
};

// Function CommonConversationRuntime.ConversationParticipantComponent.ClientUpdateParticipants
struct ConversationParticipantComponent_ClientUpdateParticipants_Params
{
	struct FConversationParticipants                   InParticipants_69;                                        // (ConstParm, Parm, ReferenceParm)
};

// Function CommonConversationRuntime.ConversationParticipantComponent.ClientUpdateConversationTaskChoiceData
struct ConversationParticipantComponent_ClientUpdateConversationTaskChoiceData_Params
{
	struct FConversationNodeHandle                     Handle_69;                                                // (Parm)
	struct FClientConversationOptionEntry              OptionEntry_69;                                           // (ConstParm, Parm, ReferenceParm)
};

// Function CommonConversationRuntime.ConversationParticipantComponent.ClientUpdateConversations
struct ConversationParticipantComponent_ClientUpdateConversations_Params
{
	int                                                InConversationsActive_69;                                 // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function CommonConversationRuntime.ConversationParticipantComponent.ClientUpdateConversation
struct ConversationParticipantComponent_ClientUpdateConversation_Params
{
	struct FClientConversationMessagePayload           message_69;                                               // (ConstParm, Parm, ReferenceParm)
};

// Function CommonConversationRuntime.ConversationParticipantComponent.ClientStartConversation
struct ConversationParticipantComponent_ClientStartConversation_Params
{
	struct FGameplayTag                                AsParticipant_69;                                         // (ConstParm, Parm)
};

// Function CommonConversationRuntime.ConversationParticipantComponent.ClientExecuteTaskAndSideEffects
struct ConversationParticipantComponent_ClientExecuteTaskAndSideEffects_Params
{
	struct FConversationNodeHandle                     Handle_69;                                                // (Parm)
};

// Function CommonConversationRuntime.ConversationNode.GetDebugParticipantColor
struct ConversationNode_GetDebugParticipantColor_Params
{
	struct FGameplayTag                                ParticipantID_69;                                         // (Parm)
	struct FLinearColor                                ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CommonConversationRuntime.ConversationChoiceNode.FillChoice
struct ConversationChoiceNode_FillChoice_Params
{
	struct FConversationContext                        Context_69;                                               // (ConstParm, Parm, OutParm, ReferenceParm)
	struct FClientConversationOptionEntry              ChoiceEntry_69;                                           // (Parm, OutParm)
};

// Function CommonConversationRuntime.ConversationContextHelpers.ReturnToLastClientChoice
struct ConversationContextHelpers_ReturnToLastClientChoice_Params
{
	struct FConversationContext                        Context_69;                                               // (ConstParm, Parm, OutParm, ReferenceParm)
	struct FConversationTaskResult                     ReturnValue_69;                                           // (Parm, OutParm, ReturnParm)
};

// Function CommonConversationRuntime.ConversationContextHelpers.ReturnToCurrentClientChoice
struct ConversationContextHelpers_ReturnToCurrentClientChoice_Params
{
	struct FConversationContext                        Context_69;                                               // (ConstParm, Parm, OutParm, ReferenceParm)
	struct FConversationTaskResult                     ReturnValue_69;                                           // (Parm, OutParm, ReturnParm)
};

// Function CommonConversationRuntime.ConversationContextHelpers.ReturnToConversationStart
struct ConversationContextHelpers_ReturnToConversationStart_Params
{
	struct FConversationContext                        Context_69;                                               // (ConstParm, Parm, OutParm, ReferenceParm)
	struct FConversationTaskResult                     ReturnValue_69;                                           // (Parm, OutParm, ReturnParm)
};

// Function CommonConversationRuntime.ConversationContextHelpers.PauseConversationAndSendClientChoices
struct ConversationContextHelpers_PauseConversationAndSendClientChoices_Params
{
	struct FConversationContext                        Context_69;                                               // (ConstParm, Parm, OutParm, ReferenceParm)
	struct FClientConversationMessage                  message_69;                                               // (ConstParm, Parm, OutParm, ReferenceParm)
	struct FConversationTaskResult                     ReturnValue_69;                                           // (Parm, OutParm, ReturnParm)
};

// Function CommonConversationRuntime.ConversationContextHelpers.MakeConversationParticipant
struct ConversationContextHelpers_MakeConversationParticipant_Params
{
	struct FConversationContext                        Context_69;                                               // (ConstParm, Parm, OutParm, ReferenceParm)
	class Actor_32759*                                 ParticipantActor_69;                                      // (Parm, ZeroConstructor)
	struct FGameplayTag                                ParticipantTag_69;                                        // (Parm)
};

// Function CommonConversationRuntime.ConversationContextHelpers.GetCurrentConversationNodeHandle
struct ConversationContextHelpers_GetCurrentConversationNodeHandle_Params
{
	struct FConversationContext                        Context_69;                                               // (ConstParm, Parm, OutParm, ReferenceParm)
	struct FConversationNodeHandle                     ReturnValue_69;                                           // (Parm, OutParm, ReturnParm)
};

// Function CommonConversationRuntime.ConversationContextHelpers.GetConversationParticipantActor
struct ConversationContextHelpers_GetConversationParticipantActor_Params
{
	struct FConversationContext                        Context_69;                                               // (ConstParm, Parm, OutParm, ReferenceParm)
	struct FGameplayTag                                ParticipantTag_69;                                        // (Parm)
	class Actor_32759*                                 ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function CommonConversationRuntime.ConversationContextHelpers.GetConversationParticipant
struct ConversationContextHelpers_GetConversationParticipant_Params
{
	struct FConversationContext                        Context_69;                                               // (ConstParm, Parm, OutParm, ReferenceParm)
	struct FGameplayTag                                ParticipantTag_69;                                        // (Parm)
	class ConversationParticipantComponent*            ReturnValue_69;                                           // (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)
};

// Function CommonConversationRuntime.ConversationContextHelpers.GetConversationInstance
struct ConversationContextHelpers_GetConversationInstance_Params
{
	struct FConversationContext                        Context_69;                                               // (ConstParm, Parm, OutParm, ReferenceParm)
	class ConversationInstance*                        ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function CommonConversationRuntime.ConversationContextHelpers.FindConversationComponent
struct ConversationContextHelpers_FindConversationComponent_Params
{
	class Actor_32759*                                 Actor_69;                                                 // (Parm, ZeroConstructor)
	class ConversationParticipantComponent*            ReturnValue_69;                                           // (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)
};

// Function CommonConversationRuntime.ConversationContextHelpers.CanConversationContinue
struct ConversationContextHelpers_CanConversationContinue_Params
{
	struct FConversationTaskResult                     ConversationTasResult_69;                                 // (ConstParm, Parm, OutParm, ReferenceParm)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CommonConversationRuntime.ConversationContextHelpers.AdvanceConversationWithChoice
struct ConversationContextHelpers_AdvanceConversationWithChoice_Params
{
	struct FConversationContext                        Context_69;                                               // (ConstParm, Parm, OutParm, ReferenceParm)
	struct FAdvanceConversationRequest                 Choice_69;                                                // (ConstParm, Parm, OutParm, ReferenceParm)
	struct FConversationTaskResult                     ReturnValue_69;                                           // (Parm, OutParm, ReturnParm)
};

// Function CommonConversationRuntime.ConversationContextHelpers.AdvanceConversation
struct ConversationContextHelpers_AdvanceConversation_Params
{
	struct FConversationContext                        Context_69;                                               // (ConstParm, Parm, OutParm, ReferenceParm)
	struct FConversationTaskResult                     ReturnValue_69;                                           // (Parm, OutParm, ReturnParm)
};

// Function CommonConversationRuntime.ConversationContextHelpers.AbortConversation
struct ConversationContextHelpers_AbortConversation_Params
{
	struct FConversationContext                        Context_69;                                               // (ConstParm, Parm, OutParm, ReferenceParm)
	struct FConversationTaskResult                     ReturnValue_69;                                           // (Parm, OutParm, ReturnParm)
};

// Function CommonConversationRuntime.ConversationLibrary.StartConversation
struct ConversationLibrary_StartConversation_Params
{
	struct FGameplayTag                                ConversationEntryTag_69;                                  // (Parm)
	class Actor_32759*                                 Instigator_69;                                            // (Parm, ZeroConstructor)
	struct FGameplayTag                                InstigatorTag_69;                                         // (Parm)
	class Actor_32759*                                 Target_69;                                                // (Parm, ZeroConstructor)
	struct FGameplayTag                                TargetTag_69;                                             // (Parm)
	class ConversationInstance*                        ConversationInstanceClass_69;                             // (ConstParm, Parm, ZeroConstructor)
	class ConversationInstance*                        ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function CommonConversationRuntime.ConversationTaskNode.IsRequirementSatisfied
struct ConversationTaskNode_IsRequirementSatisfied_Params
{
	struct FConversationContext                        Context_69;                                               // (ConstParm, Parm, OutParm, ReferenceParm)
	EConversationRequirementResult                     ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CommonConversationRuntime.ConversationTaskNode.GetNodeBodyColor
struct ConversationTaskNode_GetNodeBodyColor_Params
{
	struct FLinearColor                                BodyColor_69;                                             // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CommonConversationRuntime.ConversationTaskNode.GatherStaticExtraData
struct ConversationTaskNode_GatherStaticExtraData_Params
{
	struct FConversationContext                        Context_69;                                               // (ConstParm, Parm, OutParm, ReferenceParm)
	TArray<struct FConversationNodeParameterPair>      InOutExtraData_69;                                        // (Parm, OutParm, ZeroConstructor)
};

// Function CommonConversationRuntime.ConversationTaskNode.ExecuteTaskNode
struct ConversationTaskNode_ExecuteTaskNode_Params
{
	struct FConversationContext                        Context_69;                                               // (ConstParm, Parm, OutParm, ReferenceParm)
	struct FConversationTaskResult                     ReturnValue_69;                                           // (Parm, OutParm, ReturnParm)
};

// Function CommonConversationRuntime.ConversationTaskNode.ExecuteClientEffects
struct ConversationTaskNode_ExecuteClientEffects_Params
{
	struct FConversationContext                        Context_69;                                               // (ConstParm, Parm, OutParm, ReferenceParm)
};

// Function CommonConversationRuntime.ConversationRequirementNode.IsRequirementSatisfied
struct ConversationRequirementNode_IsRequirementSatisfied_Params
{
	struct FConversationContext                        Context_69;                                               // (ConstParm, Parm, OutParm, ReferenceParm)
	EConversationRequirementResult                     ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CommonConversationRuntime.ConversationSideEffectNode.ServerCauseSideEffect
struct ConversationSideEffectNode_ServerCauseSideEffect_Params
{
	struct FConversationContext                        Context_69;                                               // (ConstParm, Parm, OutParm, ReferenceParm)
};

// Function CommonConversationRuntime.ConversationSideEffectNode.ClientCauseSideEffect
struct ConversationSideEffectNode_ClientCauseSideEffect_Params
{
	struct FConversationContext                        Context_69;                                               // (ConstParm, Parm, OutParm, ReferenceParm)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

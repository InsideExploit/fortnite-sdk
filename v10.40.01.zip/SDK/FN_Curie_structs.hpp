#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Enums
//---------------------------------------------------------------------------

// Enum Curie.ECurieHandlerBehavior
enum class ECurieHandlerBehavior : uint8_t
{
	Handler_Add                    = 0,
	Handler_Replace                = 1,
	Handler_MAX                    = 2
};


// Enum Curie.ECurieHandlerPriority
enum class ECurieHandlerPriority : uint8_t
{
	Priority_1                     = 0,
	Priority_2                     = 1,
	Priority_3                     = 2,
	Priority_4                     = 3,
	Priority_5                     = 4,
	Priority_6                     = 5,
	Priority_7                     = 6,
	Priority_8                     = 7,
	Priority_9                     = 8,
	Priority_10                    = 9,
	Priority_Default               = 10,
	Priority_MAX                   = 11
};


// Enum Curie.ECurieManagerComponentPriority
enum class ECurieManagerComponentPriority : uint8_t
{
	Priority_1                     = 0,
	Priority_2                     = 1,
	Priority_3                     = 2,
	Priority_4                     = 3,
	Priority_5                     = 4,
	Priority_6                     = 5,
	Priority_7                     = 6,
	Priority_8                     = 7,
	Priority_9                     = 8,
	Priority_10                    = 9,
	Priority_Default               = 10,
	Priority_MAX                   = 11
};


// Enum Curie.ECurieEntityType
enum class ECurieEntityType : uint8_t
{
	Invalid                        = 0,
	Material                       = 1,
	Element                        = 2,
	ECurieEntityType_MAX           = 3
};



//---------------------------------------------------------------------------
//Script Structs
//---------------------------------------------------------------------------

// ScriptStruct Curie.CurieEffectContainer
// 0x0050
struct FCurieEffectContainer
{
	struct FGameplayTagQuery                           TargetFilter_69;                                          // 0x0000(0x0048) (Edit, DisableEditOnInstance)
	class GameplayEffect*                              GameplayEffect_69;                                        // 0x0048(0x0008) (Edit, ZeroConstructor, DisableEditOnInstance)
};

// ScriptStruct Curie.CurieContainerHandle
// 0x0004
struct FCurieContainerHandle
{
	unsigned char                                      UnknownData00[0x4];                                       // 0x0000(0x0004) MISSED OFFSET
};

// ScriptStruct Curie.CurieInteractParamsHandle
// 0x0010
struct FCurieInteractParamsHandle
{
	unsigned char                                      UnknownData00[0x10];                                      // 0x0000(0x0010) MISSED OFFSET
};

// ScriptStruct Curie.CurieElementAttachHandlersContainer
// 0x0010
struct FCurieElementAttachHandlersContainer
{
	TArray<class CurieElementAttachHandler*>           Handlers_69;                                              // 0x0000(0x0010) (ZeroConstructor)
};

// ScriptStruct Curie.CurieElementAttachConditionHandlersContainer
// 0x0010
struct FCurieElementAttachConditionHandlersContainer
{
	TArray<class CurieElementAttachConditionHandler*>  Handlers_69;                                              // 0x0000(0x0010) (ZeroConstructor)
};

// ScriptStruct Curie.CurieElementPairKey
// 0x0008
struct FCurieElementPairKey
{
	unsigned char                                      UnknownData00[0x8];                                       // 0x0000(0x0008) MISSED OFFSET
};

// ScriptStruct Curie.CurieElementInteractWithElementHandlersContainer
// 0x0010
struct FCurieElementInteractWithElementHandlersContainer
{
	TArray<class CurieElementInteractWithElementHandler*> Handlers_69;                                              // 0x0000(0x0010) (ZeroConstructor)
};

// ScriptStruct Curie.CurieElementInteractWithMaterialHandlersContainer
// 0x0010
struct FCurieElementInteractWithMaterialHandlersContainer
{
	TArray<class CurieElementInteractWithMaterialHandler*> Handlers_69;                                              // 0x0000(0x0010) (ZeroConstructor)
};

// ScriptStruct Curie.CurieElementInteractWithContainerHandlersContainer
// 0x0010
struct FCurieElementInteractWithContainerHandlersContainer
{
	TArray<class CurieElementInteractWithContainerHandler*> Handlers_69;                                              // 0x0000(0x0010) (ZeroConstructor)
};

// ScriptStruct Curie.CurieMaterialDefinitionBase
// 0x0080 (0x0088 - 0x0008)
struct FCurieMaterialDefinitionBase : public FTableRowBase
{
	struct FGameplayTagContainer                       ElementalImmunities_69;                                   // 0x0008(0x0020) (Edit, DisableEditOnInstance)
	struct FGameplayTagContainer                       ElementAttachmentImmunities_69;                           // 0x0028(0x0020) (Edit, DisableEditOnInstance)
	struct FGameplayTagContainer                       ElementsAllowedWhenCannotBeDamaged_69;                    // 0x0048(0x0020) (Edit, DisableEditOnInstance)
	struct FGameplayTagContainer                       MaterialProperties_69;                                    // 0x0068(0x0020) (Edit, DisableEditOnInstance)
};

// ScriptStruct Curie.CurieElementDefinitionBase
// 0x0078 (0x0080 - 0x0008)
struct FCurieElementDefinitionBase : public FTableRowBase
{
	class CurieElementAllocationHandler*               ElementAllocationHandler_69;                              // 0x0008(0x0008) (Edit, ZeroConstructor, DisableEditOnInstance, NoClear)
	TArray<class CurieElementAttachHandler*>           ElementAttachHandlers_69;                                 // 0x0010(0x0010) (Edit, ZeroConstructor, DisableEditOnInstance)
	class CurieElementAttachConditionHandler*          ElementAttachConditionHandler_69;                         // 0x0020(0x0008) (Edit, ZeroConstructor, DisableEditOnInstance)
	TArray<class CurieElementInteractWithElementHandler*> ElementInteractHandlers_69;                               // 0x0028(0x0010) (Edit, ZeroConstructor, DisableEditOnInstance)
	TArray<class CurieElementInteractWithMaterialHandler*> ElementMaterialInteractHandlers_69;                       // 0x0038(0x0010) (Edit, ZeroConstructor, DisableEditOnInstance)
	TArray<class CurieElementInteractWithContainerHandler*> ElementContainerInteractHandlers_69;                      // 0x0048(0x0010) (Edit, ZeroConstructor, DisableEditOnInstance)
	struct FGameplayTagContainer                       ElementalImmunities_69;                                   // 0x0058(0x0020) (Edit, DisableEditOnInstance)
	unsigned char                                      bIsEnabled_69 : 1;                                        // 0x0078(0x0001) (Edit, DisableEditOnInstance)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0079(0x0007) MISSED OFFSET
};

// ScriptStruct Curie.CurieEntityStateDefinitionBase
// 0x0010 (0x0018 - 0x0008)
struct FCurieEntityStateDefinitionBase : public FTableRowBase
{
	class CurieEntityStateBehavior*                    StateBehaviorClass_69;                                    // 0x0008(0x0008) (Edit, ZeroConstructor, DisableEditOnInstance)
	unsigned char                                      bIsEnabled_69 : 1;                                        // 0x0010(0x0001) (Edit, DisableEditOnInstance)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0011(0x0007) MISSED OFFSET
};

// ScriptStruct Curie.CurieManagerComponentEntry
// 0x0018 (0x0020 - 0x0008)
struct FCurieManagerComponentEntry : public FTableRowBase
{
	bool                                               bIsActive_69;                                             // 0x0008(0x0001) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	ECurieManagerComponentPriority                     Priority_69;                                              // 0x0009(0x0001) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData00[0x6];                                       // 0x000A(0x0006) MISSED OFFSET
	class CurieManagerComponent*                       ManagerType_69;                                           // 0x0010(0x0008) (Edit, ZeroConstructor, DisableEditOnInstance)
	class CurieManagerComponentConfig*                 Config_69;                                                // 0x0018(0x0008) (Edit, ZeroConstructor, DisableEditOnInstance)
};

// ScriptStruct Curie.CurieInteractHandle
// 0x0004
struct FCurieInteractHandle
{
	unsigned char                                      UnknownData00[0x4];                                       // 0x0000(0x0004) MISSED OFFSET
};

// ScriptStruct Curie.CurieStateHandle
// 0x0004
struct FCurieStateHandle
{
	unsigned char                                      UnknownData00[0x4];                                       // 0x0000(0x0004) MISSED OFFSET
};

// ScriptStruct Curie.CurieElementHandle
// 0x0004
struct FCurieElementHandle
{
	unsigned char                                      UnknownData00[0x4];                                       // 0x0000(0x0004) MISSED OFFSET
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

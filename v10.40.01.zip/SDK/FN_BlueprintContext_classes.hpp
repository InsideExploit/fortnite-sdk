#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Classes
//---------------------------------------------------------------------------

// Class BlueprintContext.BlueprintContextBase
// 0x0000 (0x0030 - 0x0030)
class BlueprintContextBase : public Subsystem
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class BlueprintContext.BlueprintContextBase"));
		
		return ptr;
	}

};


// Class BlueprintContext.BlueprintContextLibrary
// 0x0000 (0x0028 - 0x0028)
class BlueprintContextLibrary : public BlueprintFunctionLibrary
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class BlueprintContext.BlueprintContextLibrary"));
		
		return ptr;
	}


	class Subsystem* STATIC_GetContext(class Object_32759* ContextObject_69, class Subsystem* Class_69);
};


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

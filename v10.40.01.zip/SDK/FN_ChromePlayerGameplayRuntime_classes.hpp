#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Classes
//---------------------------------------------------------------------------

// Class ChromePlayerGameplayRuntime.FortAthenaAIBotEvaluator_ChromedBlob
// 0x0098 (0x0120 - 0x0088)
class FortAthenaAIBotEvaluator_ChromedBlob : public FortAthenaAIBotEvaluator
{
public:
	struct FName                                       TacticalSprintExecutionStatusName_69;                     // 0x0088(0x0008) (Edit, ZeroConstructor, IsPlainOldData)
	struct FName                                       TacticalSprintOverridenName_69;                           // 0x008C(0x0008) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0090(0x0004) MISSED OFFSET
	struct FGameplayTag                                ChromedTag_69;                                            // 0x0094(0x0004) (Edit)
	struct FGameplayTag                                ChromeBlobAbilityTag_69;                                  // 0x0098(0x0004) (Edit)
	struct FGameplayTag                                ChromeBlobbedTag_69;                                      // 0x009C(0x0004) (Edit)
	struct FScalableFloat                              BlobDuration_69;                                          // 0x00A0(0x0028) (Edit)
	struct FScalableFloat                              BlobDurationRandomDeviation_69;                           // 0x00C8(0x0028) (Edit)
	unsigned char                                      UnknownData01[0x30];                                      // 0x00F0(0x0030) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class ChromePlayerGameplayRuntime.FortAthenaAIBotEvaluator_ChromedBlob"));
		
		return ptr;
	}

};


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

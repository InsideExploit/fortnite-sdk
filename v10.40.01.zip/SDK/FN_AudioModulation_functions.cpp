// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Functions
//---------------------------------------------------------------------------

// Function AudioModulation.AudioModulationStyle.GetPatchColor
// (Final, Native, Static, Public, HasDefaults, BlueprintCallable)
// Parameters:
// struct FCoreUObject_FColor     ReturnValue_69                 (ConstParm, Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

struct FCoreUObject_FColor AudioModulationStyle::STATIC_GetPatchColor()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioModulation.AudioModulationStyle.GetPatchColor"));

	AudioModulationStyle_GetPatchColor_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AudioModulation.AudioModulationStyle.GetParameterColor
// (Final, Native, Static, Public, HasDefaults, BlueprintCallable)
// Parameters:
// struct FCoreUObject_FColor     ReturnValue_69                 (ConstParm, Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

struct FCoreUObject_FColor AudioModulationStyle::STATIC_GetParameterColor()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioModulation.AudioModulationStyle.GetParameterColor"));

	AudioModulationStyle_GetParameterColor_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AudioModulation.AudioModulationStyle.GetModulationGeneratorColor
// (Final, Native, Static, Public, HasDefaults, BlueprintCallable)
// Parameters:
// struct FCoreUObject_FColor     ReturnValue_69                 (ConstParm, Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

struct FCoreUObject_FColor AudioModulationStyle::STATIC_GetModulationGeneratorColor()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioModulation.AudioModulationStyle.GetModulationGeneratorColor"));

	AudioModulationStyle_GetModulationGeneratorColor_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AudioModulation.AudioModulationStyle.GetControlBusMixColor
// (Final, Native, Static, Public, HasDefaults, BlueprintCallable)
// Parameters:
// struct FCoreUObject_FColor     ReturnValue_69                 (ConstParm, Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

struct FCoreUObject_FColor AudioModulationStyle::STATIC_GetControlBusMixColor()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioModulation.AudioModulationStyle.GetControlBusMixColor"));

	AudioModulationStyle_GetControlBusMixColor_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AudioModulation.AudioModulationStyle.GetControlBusColor
// (Final, Native, Static, Public, HasDefaults, BlueprintCallable)
// Parameters:
// struct FCoreUObject_FColor     ReturnValue_69                 (ConstParm, Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

struct FCoreUObject_FColor AudioModulationStyle::STATIC_GetControlBusColor()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioModulation.AudioModulationStyle.GetControlBusColor"));

	AudioModulationStyle_GetControlBusColor_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AudioModulation.AudioModulationStatics.UpdateModulator
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// class Object_32759*            WorldContextObject_69          (ConstParm, Parm, ZeroConstructor)
// class SoundModulatorBase*      Modulator_69                   (Parm, ZeroConstructor)

void AudioModulationStatics::STATIC_UpdateModulator(class Object_32759* WorldContextObject_69, class SoundModulatorBase* Modulator_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioModulation.AudioModulationStatics.UpdateModulator"));

	AudioModulationStatics_UpdateModulator_Params params;
	params.WorldContextObject_69 = WorldContextObject_69;
	params.Modulator_69 = Modulator_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AudioModulation.AudioModulationStatics.UpdateMixFromObject
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// class Object_32759*            WorldContextObject_69          (ConstParm, Parm, ZeroConstructor)
// class SoundControlBusMix*      Mix_69                         (Parm, ZeroConstructor)
// float                          FadeTime_69                    (Parm, ZeroConstructor, IsPlainOldData)

void AudioModulationStatics::STATIC_UpdateMixFromObject(class Object_32759* WorldContextObject_69, class SoundControlBusMix* Mix_69, float FadeTime_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioModulation.AudioModulationStatics.UpdateMixFromObject"));

	AudioModulationStatics_UpdateMixFromObject_Params params;
	params.WorldContextObject_69 = WorldContextObject_69;
	params.Mix_69 = Mix_69;
	params.FadeTime_69 = FadeTime_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AudioModulation.AudioModulationStatics.UpdateMixByFilter
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// class Object_32759*            WorldContextObject_69          (ConstParm, Parm, ZeroConstructor)
// class SoundControlBusMix*      Mix_69                         (Parm, ZeroConstructor)
// struct FString                 AddressFilter_69               (Parm, ZeroConstructor)
// class SoundModulationParameter* ParamClassFilter_69            (Parm, ZeroConstructor)
// class SoundModulationParameter* ParamFilter_69                 (Parm, ZeroConstructor)
// float                          Value_69                       (Parm, ZeroConstructor, IsPlainOldData)
// float                          FadeTime_69                    (Parm, ZeroConstructor, IsPlainOldData)

void AudioModulationStatics::STATIC_UpdateMixByFilter(class Object_32759* WorldContextObject_69, class SoundControlBusMix* Mix_69, const struct FString& AddressFilter_69, class SoundModulationParameter* ParamClassFilter_69, class SoundModulationParameter* ParamFilter_69, float Value_69, float FadeTime_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioModulation.AudioModulationStatics.UpdateMixByFilter"));

	AudioModulationStatics_UpdateMixByFilter_Params params;
	params.WorldContextObject_69 = WorldContextObject_69;
	params.Mix_69 = Mix_69;
	params.AddressFilter_69 = AddressFilter_69;
	params.ParamClassFilter_69 = ParamClassFilter_69;
	params.ParamFilter_69 = ParamFilter_69;
	params.Value_69 = Value_69;
	params.FadeTime_69 = FadeTime_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AudioModulation.AudioModulationStatics.UpdateMix
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// class Object_32759*            WorldContextObject_69          (ConstParm, Parm, ZeroConstructor)
// class SoundControlBusMix*      Mix_69                         (Parm, ZeroConstructor)
// TArray<struct FSoundControlBusMixStage> Stages_69                      (Parm, ZeroConstructor)
// float                          FadeTime_69                    (Parm, ZeroConstructor, IsPlainOldData)

void AudioModulationStatics::STATIC_UpdateMix(class Object_32759* WorldContextObject_69, class SoundControlBusMix* Mix_69, TArray<struct FSoundControlBusMixStage> Stages_69, float FadeTime_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioModulation.AudioModulationStatics.UpdateMix"));

	AudioModulationStatics_UpdateMix_Params params;
	params.WorldContextObject_69 = WorldContextObject_69;
	params.Mix_69 = Mix_69;
	params.Stages_69 = Stages_69;
	params.FadeTime_69 = FadeTime_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AudioModulation.AudioModulationStatics.SetGlobalBusMixValue
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// class Object_32759*            WorldContextObject_69          (ConstParm, Parm, ZeroConstructor)
// class SoundControlBus*         Bus_69                         (Parm, ZeroConstructor)
// float                          Value_69                       (Parm, ZeroConstructor, IsPlainOldData)
// float                          FadeTime_69                    (Parm, ZeroConstructor, IsPlainOldData)

void AudioModulationStatics::STATIC_SetGlobalBusMixValue(class Object_32759* WorldContextObject_69, class SoundControlBus* Bus_69, float Value_69, float FadeTime_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioModulation.AudioModulationStatics.SetGlobalBusMixValue"));

	AudioModulationStatics_SetGlobalBusMixValue_Params params;
	params.WorldContextObject_69 = WorldContextObject_69;
	params.Bus_69 = Bus_69;
	params.Value_69 = Value_69;
	params.FadeTime_69 = FadeTime_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AudioModulation.AudioModulationStatics.SaveMixToProfile
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// class Object_32759*            WorldContextObject_69          (ConstParm, Parm, ZeroConstructor)
// class SoundControlBusMix*      Mix_69                         (Parm, ZeroConstructor)
// int                            ProfileIndex_69                (Parm, ZeroConstructor, IsPlainOldData)

void AudioModulationStatics::STATIC_SaveMixToProfile(class Object_32759* WorldContextObject_69, class SoundControlBusMix* Mix_69, int ProfileIndex_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioModulation.AudioModulationStatics.SaveMixToProfile"));

	AudioModulationStatics_SaveMixToProfile_Params params;
	params.WorldContextObject_69 = WorldContextObject_69;
	params.Mix_69 = Mix_69;
	params.ProfileIndex_69 = ProfileIndex_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AudioModulation.AudioModulationStatics.LoadMixFromProfile
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// class Object_32759*            WorldContextObject_69          (ConstParm, Parm, ZeroConstructor)
// class SoundControlBusMix*      Mix_69                         (Parm, ZeroConstructor)
// bool                           bActivate_69                   (Parm, ZeroConstructor, IsPlainOldData)
// int                            ProfileIndex_69                (Parm, ZeroConstructor, IsPlainOldData)
// TArray<struct FSoundControlBusMixStage> ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

TArray<struct FSoundControlBusMixStage> AudioModulationStatics::STATIC_LoadMixFromProfile(class Object_32759* WorldContextObject_69, class SoundControlBusMix* Mix_69, bool bActivate_69, int ProfileIndex_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioModulation.AudioModulationStatics.LoadMixFromProfile"));

	AudioModulationStatics_LoadMixFromProfile_Params params;
	params.WorldContextObject_69 = WorldContextObject_69;
	params.Mix_69 = Mix_69;
	params.bActivate_69 = bActivate_69;
	params.ProfileIndex_69 = ProfileIndex_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AudioModulation.AudioModulationStatics.DeactivateGenerator
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// class Object_32759*            WorldContextObject_69          (ConstParm, Parm, ZeroConstructor)
// class SoundModulationGenerator* Generator_69                   (Parm, ZeroConstructor)

void AudioModulationStatics::STATIC_DeactivateGenerator(class Object_32759* WorldContextObject_69, class SoundModulationGenerator* Generator_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioModulation.AudioModulationStatics.DeactivateGenerator"));

	AudioModulationStatics_DeactivateGenerator_Params params;
	params.WorldContextObject_69 = WorldContextObject_69;
	params.Generator_69 = Generator_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AudioModulation.AudioModulationStatics.DeactivateBusMix
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// class Object_32759*            WorldContextObject_69          (ConstParm, Parm, ZeroConstructor)
// class SoundControlBusMix*      Mix_69                         (Parm, ZeroConstructor)

void AudioModulationStatics::STATIC_DeactivateBusMix(class Object_32759* WorldContextObject_69, class SoundControlBusMix* Mix_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioModulation.AudioModulationStatics.DeactivateBusMix"));

	AudioModulationStatics_DeactivateBusMix_Params params;
	params.WorldContextObject_69 = WorldContextObject_69;
	params.Mix_69 = Mix_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AudioModulation.AudioModulationStatics.DeactivateBus
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// class Object_32759*            WorldContextObject_69          (ConstParm, Parm, ZeroConstructor)
// class SoundControlBus*         Bus_69                         (Parm, ZeroConstructor)

void AudioModulationStatics::STATIC_DeactivateBus(class Object_32759* WorldContextObject_69, class SoundControlBus* Bus_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioModulation.AudioModulationStatics.DeactivateBus"));

	AudioModulationStatics_DeactivateBus_Params params;
	params.WorldContextObject_69 = WorldContextObject_69;
	params.Bus_69 = Bus_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AudioModulation.AudioModulationStatics.CreateBusMixStage
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// class Object_32759*            WorldContextObject_69          (ConstParm, Parm, ZeroConstructor)
// class SoundControlBus*         Bus_69                         (Parm, ZeroConstructor)
// float                          Value_69                       (Parm, ZeroConstructor, IsPlainOldData)
// float                          AttackTime_69                  (Parm, ZeroConstructor, IsPlainOldData)
// float                          ReleaseTime_69                 (Parm, ZeroConstructor, IsPlainOldData)
// struct FSoundControlBusMixStage ReturnValue_69                 (Parm, OutParm, ReturnParm)

struct FSoundControlBusMixStage AudioModulationStatics::STATIC_CreateBusMixStage(class Object_32759* WorldContextObject_69, class SoundControlBus* Bus_69, float Value_69, float AttackTime_69, float ReleaseTime_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioModulation.AudioModulationStatics.CreateBusMixStage"));

	AudioModulationStatics_CreateBusMixStage_Params params;
	params.WorldContextObject_69 = WorldContextObject_69;
	params.Bus_69 = Bus_69;
	params.Value_69 = Value_69;
	params.AttackTime_69 = AttackTime_69;
	params.ReleaseTime_69 = ReleaseTime_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AudioModulation.AudioModulationStatics.CreateBusMix
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// class Object_32759*            WorldContextObject_69          (Parm, ZeroConstructor)
// struct FName                   Name_69                        (Parm, ZeroConstructor, IsPlainOldData)
// TArray<struct FSoundControlBusMixStage> Stages_69                      (Parm, ZeroConstructor)
// bool                           Activate_69                    (Parm, ZeroConstructor, IsPlainOldData)
// class SoundControlBusMix*      ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

class SoundControlBusMix* AudioModulationStatics::STATIC_CreateBusMix(class Object_32759* WorldContextObject_69, const struct FName& Name_69, TArray<struct FSoundControlBusMixStage> Stages_69, bool Activate_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioModulation.AudioModulationStatics.CreateBusMix"));

	AudioModulationStatics_CreateBusMix_Params params;
	params.WorldContextObject_69 = WorldContextObject_69;
	params.Name_69 = Name_69;
	params.Stages_69 = Stages_69;
	params.Activate_69 = Activate_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AudioModulation.AudioModulationStatics.CreateBus
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// class Object_32759*            WorldContextObject_69          (Parm, ZeroConstructor)
// struct FName                   Name_69                        (Parm, ZeroConstructor, IsPlainOldData)
// class SoundModulationParameter* Parameter_69                   (Parm, ZeroConstructor)
// bool                           Activate_69                    (Parm, ZeroConstructor, IsPlainOldData)
// class SoundControlBus*         ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

class SoundControlBus* AudioModulationStatics::STATIC_CreateBus(class Object_32759* WorldContextObject_69, const struct FName& Name_69, class SoundModulationParameter* Parameter_69, bool Activate_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioModulation.AudioModulationStatics.CreateBus"));

	AudioModulationStatics_CreateBus_Params params;
	params.WorldContextObject_69 = WorldContextObject_69;
	params.Name_69 = Name_69;
	params.Parameter_69 = Parameter_69;
	params.Activate_69 = Activate_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AudioModulation.AudioModulationStatics.ClearGlobalBusMixValue
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// class Object_32759*            WorldContextObject_69          (ConstParm, Parm, ZeroConstructor)
// class SoundControlBus*         Bus_69                         (Parm, ZeroConstructor)
// float                          FadeTime_69                    (Parm, ZeroConstructor, IsPlainOldData)

void AudioModulationStatics::STATIC_ClearGlobalBusMixValue(class Object_32759* WorldContextObject_69, class SoundControlBus* Bus_69, float FadeTime_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioModulation.AudioModulationStatics.ClearGlobalBusMixValue"));

	AudioModulationStatics_ClearGlobalBusMixValue_Params params;
	params.WorldContextObject_69 = WorldContextObject_69;
	params.Bus_69 = Bus_69;
	params.FadeTime_69 = FadeTime_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AudioModulation.AudioModulationStatics.ClearAllGlobalBusMixValues
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// class Object_32759*            WorldContextObject_69          (ConstParm, Parm, ZeroConstructor)
// float                          FadeTime_69                    (Parm, ZeroConstructor, IsPlainOldData)

void AudioModulationStatics::STATIC_ClearAllGlobalBusMixValues(class Object_32759* WorldContextObject_69, float FadeTime_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioModulation.AudioModulationStatics.ClearAllGlobalBusMixValues"));

	AudioModulationStatics_ClearAllGlobalBusMixValues_Params params;
	params.WorldContextObject_69 = WorldContextObject_69;
	params.FadeTime_69 = FadeTime_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AudioModulation.AudioModulationStatics.ActivateGenerator
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// class Object_32759*            WorldContextObject_69          (ConstParm, Parm, ZeroConstructor)
// class SoundModulationGenerator* Generator_69                   (Parm, ZeroConstructor)

void AudioModulationStatics::STATIC_ActivateGenerator(class Object_32759* WorldContextObject_69, class SoundModulationGenerator* Generator_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioModulation.AudioModulationStatics.ActivateGenerator"));

	AudioModulationStatics_ActivateGenerator_Params params;
	params.WorldContextObject_69 = WorldContextObject_69;
	params.Generator_69 = Generator_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AudioModulation.AudioModulationStatics.ActivateBusMix
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// class Object_32759*            WorldContextObject_69          (ConstParm, Parm, ZeroConstructor)
// class SoundControlBusMix*      Mix_69                         (Parm, ZeroConstructor)

void AudioModulationStatics::STATIC_ActivateBusMix(class Object_32759* WorldContextObject_69, class SoundControlBusMix* Mix_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioModulation.AudioModulationStatics.ActivateBusMix"));

	AudioModulationStatics_ActivateBusMix_Params params;
	params.WorldContextObject_69 = WorldContextObject_69;
	params.Mix_69 = Mix_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AudioModulation.AudioModulationStatics.ActivateBus
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// class Object_32759*            WorldContextObject_69          (ConstParm, Parm, ZeroConstructor)
// class SoundControlBus*         Bus_69                         (Parm, ZeroConstructor)

void AudioModulationStatics::STATIC_ActivateBus(class Object_32759* WorldContextObject_69, class SoundControlBus* Bus_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioModulation.AudioModulationStatics.ActivateBus"));

	AudioModulationStatics_ActivateBus_Params params;
	params.WorldContextObject_69 = WorldContextObject_69;
	params.Bus_69 = Bus_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AudioModulation.SoundControlBusMix.SoloMix
// (Final, Native, Protected)

void SoundControlBusMix::SoloMix()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioModulation.SoundControlBusMix.SoloMix"));

	SoundControlBusMix_SoloMix_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AudioModulation.SoundControlBusMix.SaveMixToProfile
// (Final, Native, Protected)

void SoundControlBusMix::SaveMixToProfile()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioModulation.SoundControlBusMix.SaveMixToProfile"));

	SoundControlBusMix_SaveMixToProfile_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AudioModulation.SoundControlBusMix.LoadMixFromProfile
// (Final, Native, Protected)

void SoundControlBusMix::LoadMixFromProfile()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioModulation.SoundControlBusMix.LoadMixFromProfile"));

	SoundControlBusMix_LoadMixFromProfile_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AudioModulation.SoundControlBusMix.DeactivateMix
// (Final, Native, Protected)

void SoundControlBusMix::DeactivateMix()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioModulation.SoundControlBusMix.DeactivateMix"));

	SoundControlBusMix_DeactivateMix_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AudioModulation.SoundControlBusMix.DeactivateAllMixes
// (Final, Native, Protected)

void SoundControlBusMix::DeactivateAllMixes()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioModulation.SoundControlBusMix.DeactivateAllMixes"));

	SoundControlBusMix_DeactivateAllMixes_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AudioModulation.SoundControlBusMix.ActivateMix
// (Final, Native, Protected)

void SoundControlBusMix::ActivateMix()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioModulation.SoundControlBusMix.ActivateMix"));

	SoundControlBusMix_ActivateMix_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

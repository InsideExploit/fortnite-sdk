// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Functions
//---------------------------------------------------------------------------

// Function AnimGraphRuntime.AnimationStateMachineLibrary.SetState
// (Final, Native, Static, Public, HasOutParms, BlueprintCallable)
// Parameters:
// struct FAnimUpdateContext      UpdateContext_69               (ConstParm, Parm, OutParm, ReferenceParm)
// struct FAnimationStateMachineReference Node_69                        (ConstParm, Parm, OutParm, ReferenceParm)
// struct FName                   TargetState_69                 (Parm, ZeroConstructor, IsPlainOldData)
// float                          Duration_69                    (Parm, ZeroConstructor, IsPlainOldData)
// TEnumAsByte<ETransitionLogicType> BlendType_69                   (Parm, ZeroConstructor, IsPlainOldData)
// class BlendProfile*            BlendProfile_69                (Parm, ZeroConstructor)
// EAlphaBlendOption              AlphaBlendOption_69            (Parm, ZeroConstructor, IsPlainOldData)
// class CurveFloat*              CustomBlendCurve_69            (Parm, ZeroConstructor)

void AnimationStateMachineLibrary::STATIC_SetState(const struct FAnimUpdateContext& UpdateContext_69, const struct FAnimationStateMachineReference& Node_69, const struct FName& TargetState_69, float Duration_69, TEnumAsByte<ETransitionLogicType> BlendType_69, class BlendProfile* BlendProfile_69, EAlphaBlendOption AlphaBlendOption_69, class CurveFloat* CustomBlendCurve_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AnimGraphRuntime.AnimationStateMachineLibrary.SetState"));

	AnimationStateMachineLibrary_SetState_Params params;
	params.UpdateContext_69 = UpdateContext_69;
	params.Node_69 = Node_69;
	params.TargetState_69 = TargetState_69;
	params.Duration_69 = Duration_69;
	params.BlendType_69 = BlendType_69;
	params.BlendProfile_69 = BlendProfile_69;
	params.AlphaBlendOption_69 = AlphaBlendOption_69;
	params.CustomBlendCurve_69 = CustomBlendCurve_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AnimGraphRuntime.AnimationStateMachineLibrary.IsStateBlendingOut
// (Final, Native, Static, Public, HasOutParms, BlueprintCallable, BlueprintPure)
// Parameters:
// struct FAnimUpdateContext      UpdateContext_69               (ConstParm, Parm, OutParm, ReferenceParm)
// struct FAnimationStateResultReference Node_69                        (ConstParm, Parm, OutParm, ReferenceParm)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool AnimationStateMachineLibrary::STATIC_IsStateBlendingOut(const struct FAnimUpdateContext& UpdateContext_69, const struct FAnimationStateResultReference& Node_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AnimGraphRuntime.AnimationStateMachineLibrary.IsStateBlendingOut"));

	AnimationStateMachineLibrary_IsStateBlendingOut_Params params;
	params.UpdateContext_69 = UpdateContext_69;
	params.Node_69 = Node_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AnimGraphRuntime.AnimationStateMachineLibrary.IsStateBlendingIn
// (Final, Native, Static, Public, HasOutParms, BlueprintCallable, BlueprintPure)
// Parameters:
// struct FAnimUpdateContext      UpdateContext_69               (ConstParm, Parm, OutParm, ReferenceParm)
// struct FAnimationStateResultReference Node_69                        (ConstParm, Parm, OutParm, ReferenceParm)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool AnimationStateMachineLibrary::STATIC_IsStateBlendingIn(const struct FAnimUpdateContext& UpdateContext_69, const struct FAnimationStateResultReference& Node_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AnimGraphRuntime.AnimationStateMachineLibrary.IsStateBlendingIn"));

	AnimationStateMachineLibrary_IsStateBlendingIn_Params params;
	params.UpdateContext_69 = UpdateContext_69;
	params.Node_69 = Node_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AnimGraphRuntime.AnimationStateMachineLibrary.GetState
// (Final, Native, Static, Public, HasOutParms, BlueprintCallable, BlueprintPure)
// Parameters:
// struct FAnimUpdateContext      UpdateContext_69               (ConstParm, Parm, OutParm, ReferenceParm)
// struct FAnimationStateMachineReference Node_69                        (ConstParm, Parm, OutParm, ReferenceParm)
// struct FName                   ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

struct FName AnimationStateMachineLibrary::STATIC_GetState(const struct FAnimUpdateContext& UpdateContext_69, const struct FAnimationStateMachineReference& Node_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AnimGraphRuntime.AnimationStateMachineLibrary.GetState"));

	AnimationStateMachineLibrary_GetState_Params params;
	params.UpdateContext_69 = UpdateContext_69;
	params.Node_69 = Node_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AnimGraphRuntime.AnimationStateMachineLibrary.GetRelevantAnimTimeRemainingFraction
// (Final, Native, Static, Public, HasOutParms, BlueprintCallable, BlueprintPure)
// Parameters:
// struct FAnimUpdateContext      UpdateContext_69               (ConstParm, Parm, OutParm, ReferenceParm)
// struct FAnimationStateResultReference Node_69                        (ConstParm, Parm, OutParm, ReferenceParm)
// float                          ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

float AnimationStateMachineLibrary::STATIC_GetRelevantAnimTimeRemainingFraction(const struct FAnimUpdateContext& UpdateContext_69, const struct FAnimationStateResultReference& Node_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AnimGraphRuntime.AnimationStateMachineLibrary.GetRelevantAnimTimeRemainingFraction"));

	AnimationStateMachineLibrary_GetRelevantAnimTimeRemainingFraction_Params params;
	params.UpdateContext_69 = UpdateContext_69;
	params.Node_69 = Node_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AnimGraphRuntime.AnimationStateMachineLibrary.GetRelevantAnimTimeRemaining
// (Final, Native, Static, Public, HasOutParms, BlueprintCallable, BlueprintPure)
// Parameters:
// struct FAnimUpdateContext      UpdateContext_69               (ConstParm, Parm, OutParm, ReferenceParm)
// struct FAnimationStateResultReference Node_69                        (ConstParm, Parm, OutParm, ReferenceParm)
// float                          ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

float AnimationStateMachineLibrary::STATIC_GetRelevantAnimTimeRemaining(const struct FAnimUpdateContext& UpdateContext_69, const struct FAnimationStateResultReference& Node_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AnimGraphRuntime.AnimationStateMachineLibrary.GetRelevantAnimTimeRemaining"));

	AnimationStateMachineLibrary_GetRelevantAnimTimeRemaining_Params params;
	params.UpdateContext_69 = UpdateContext_69;
	params.Node_69 = Node_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AnimGraphRuntime.AnimationStateMachineLibrary.ConvertToAnimationStateResultPure
// (Final, Native, Static, Public, HasOutParms, BlueprintCallable, BlueprintPure)
// Parameters:
// struct FAnimNodeReference      Node_69                        (ConstParm, Parm, OutParm, ReferenceParm)
// struct FAnimationStateResultReference AnimationState_69              (Parm, OutParm)
// bool                           Result_69                      (Parm, OutParm, ZeroConstructor, IsPlainOldData)

void AnimationStateMachineLibrary::STATIC_ConvertToAnimationStateResultPure(const struct FAnimNodeReference& Node_69, struct FAnimationStateResultReference* AnimationState_69, bool* Result_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AnimGraphRuntime.AnimationStateMachineLibrary.ConvertToAnimationStateResultPure"));

	AnimationStateMachineLibrary_ConvertToAnimationStateResultPure_Params params;
	params.Node_69 = Node_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (AnimationState_69 != nullptr)
		*AnimationState_69 = params.AnimationState_69;
	if (Result_69 != nullptr)
		*Result_69 = params.Result_69;
}


// Function AnimGraphRuntime.AnimationStateMachineLibrary.ConvertToAnimationStateResult
// (Final, Native, Static, Public, HasOutParms, BlueprintCallable)
// Parameters:
// struct FAnimNodeReference      Node_69                        (ConstParm, Parm, OutParm, ReferenceParm)
// struct FAnimationStateResultReference AnimationState_69              (Parm, OutParm)
// EAnimNodeReferenceConversionResult Result_69                      (Parm, OutParm, ZeroConstructor, IsPlainOldData)

void AnimationStateMachineLibrary::STATIC_ConvertToAnimationStateResult(const struct FAnimNodeReference& Node_69, struct FAnimationStateResultReference* AnimationState_69, EAnimNodeReferenceConversionResult* Result_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AnimGraphRuntime.AnimationStateMachineLibrary.ConvertToAnimationStateResult"));

	AnimationStateMachineLibrary_ConvertToAnimationStateResult_Params params;
	params.Node_69 = Node_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (AnimationState_69 != nullptr)
		*AnimationState_69 = params.AnimationState_69;
	if (Result_69 != nullptr)
		*Result_69 = params.Result_69;
}


// Function AnimGraphRuntime.AnimationStateMachineLibrary.ConvertToAnimationStateMachinePure
// (Final, Native, Static, Public, HasOutParms, BlueprintCallable, BlueprintPure)
// Parameters:
// struct FAnimNodeReference      Node_69                        (ConstParm, Parm, OutParm, ReferenceParm)
// struct FAnimationStateMachineReference AnimationState_69              (Parm, OutParm)
// bool                           Result_69                      (Parm, OutParm, ZeroConstructor, IsPlainOldData)

void AnimationStateMachineLibrary::STATIC_ConvertToAnimationStateMachinePure(const struct FAnimNodeReference& Node_69, struct FAnimationStateMachineReference* AnimationState_69, bool* Result_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AnimGraphRuntime.AnimationStateMachineLibrary.ConvertToAnimationStateMachinePure"));

	AnimationStateMachineLibrary_ConvertToAnimationStateMachinePure_Params params;
	params.Node_69 = Node_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (AnimationState_69 != nullptr)
		*AnimationState_69 = params.AnimationState_69;
	if (Result_69 != nullptr)
		*Result_69 = params.Result_69;
}


// Function AnimGraphRuntime.AnimationStateMachineLibrary.ConvertToAnimationStateMachine
// (Final, Native, Static, Public, HasOutParms, BlueprintCallable)
// Parameters:
// struct FAnimNodeReference      Node_69                        (ConstParm, Parm, OutParm, ReferenceParm)
// struct FAnimationStateMachineReference AnimationState_69              (Parm, OutParm)
// EAnimNodeReferenceConversionResult Result_69                      (Parm, OutParm, ZeroConstructor, IsPlainOldData)

void AnimationStateMachineLibrary::STATIC_ConvertToAnimationStateMachine(const struct FAnimNodeReference& Node_69, struct FAnimationStateMachineReference* AnimationState_69, EAnimNodeReferenceConversionResult* Result_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AnimGraphRuntime.AnimationStateMachineLibrary.ConvertToAnimationStateMachine"));

	AnimationStateMachineLibrary_ConvertToAnimationStateMachine_Params params;
	params.Node_69 = Node_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (AnimationState_69 != nullptr)
		*AnimationState_69 = params.AnimationState_69;
	if (Result_69 != nullptr)
		*Result_69 = params.Result_69;
}


// Function AnimGraphRuntime.AnimExecutionContextLibrary.GetDeltaTime
// (Final, Native, Static, Public, HasOutParms, BlueprintCallable, BlueprintPure)
// Parameters:
// struct FAnimUpdateContext      Context_69                     (ConstParm, Parm, OutParm, ReferenceParm)
// float                          ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

float AnimExecutionContextLibrary::STATIC_GetDeltaTime(const struct FAnimUpdateContext& Context_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AnimGraphRuntime.AnimExecutionContextLibrary.GetDeltaTime"));

	AnimExecutionContextLibrary_GetDeltaTime_Params params;
	params.Context_69 = Context_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AnimGraphRuntime.AnimExecutionContextLibrary.GetCurrentWeight
// (Final, Native, Static, Public, HasOutParms, BlueprintCallable, BlueprintPure)
// Parameters:
// struct FAnimUpdateContext      Context_69                     (ConstParm, Parm, OutParm, ReferenceParm)
// float                          ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

float AnimExecutionContextLibrary::STATIC_GetCurrentWeight(const struct FAnimUpdateContext& Context_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AnimGraphRuntime.AnimExecutionContextLibrary.GetCurrentWeight"));

	AnimExecutionContextLibrary_GetCurrentWeight_Params params;
	params.Context_69 = Context_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AnimGraphRuntime.AnimExecutionContextLibrary.GetAnimNodeReference
// (Final, Native, Static, Public, BlueprintCallable, BlueprintPure)
// Parameters:
// class AnimInstance*            Instance_69                    (Parm, ZeroConstructor)
// int                            Index_69                       (Parm, ZeroConstructor, IsPlainOldData)
// struct FAnimNodeReference      ReturnValue_69                 (Parm, OutParm, ReturnParm)

struct FAnimNodeReference AnimExecutionContextLibrary::STATIC_GetAnimNodeReference(class AnimInstance* Instance_69, int Index_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AnimGraphRuntime.AnimExecutionContextLibrary.GetAnimNodeReference"));

	AnimExecutionContextLibrary_GetAnimNodeReference_Params params;
	params.Instance_69 = Instance_69;
	params.Index_69 = Index_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AnimGraphRuntime.AnimExecutionContextLibrary.GetAnimInstance
// (Final, Native, Static, Public, HasOutParms, BlueprintCallable, BlueprintPure)
// Parameters:
// struct FAnimExecutionContext   Context_69                     (ConstParm, Parm, OutParm, ReferenceParm)
// class AnimInstance*            ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

class AnimInstance* AnimExecutionContextLibrary::STATIC_GetAnimInstance(const struct FAnimExecutionContext& Context_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AnimGraphRuntime.AnimExecutionContextLibrary.GetAnimInstance"));

	AnimExecutionContextLibrary_GetAnimInstance_Params params;
	params.Context_69 = Context_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AnimGraphRuntime.AnimExecutionContextLibrary.ConvertToUpdateContext
// (Final, Native, Static, Public, HasOutParms, BlueprintCallable)
// Parameters:
// struct FAnimExecutionContext   Context_69                     (ConstParm, Parm, OutParm, ReferenceParm)
// EAnimExecutionContextConversionResult Result_69                      (Parm, OutParm, ZeroConstructor, IsPlainOldData)
// struct FAnimUpdateContext      ReturnValue_69                 (Parm, OutParm, ReturnParm)

struct FAnimUpdateContext AnimExecutionContextLibrary::STATIC_ConvertToUpdateContext(const struct FAnimExecutionContext& Context_69, EAnimExecutionContextConversionResult* Result_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AnimGraphRuntime.AnimExecutionContextLibrary.ConvertToUpdateContext"));

	AnimExecutionContextLibrary_ConvertToUpdateContext_Params params;
	params.Context_69 = Context_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (Result_69 != nullptr)
		*Result_69 = params.Result_69;

	return params.ReturnValue_69;
}


// Function AnimGraphRuntime.AnimExecutionContextLibrary.ConvertToPoseContext
// (Final, Native, Static, Public, HasOutParms, BlueprintCallable)
// Parameters:
// struct FAnimExecutionContext   Context_69                     (ConstParm, Parm, OutParm, ReferenceParm)
// EAnimExecutionContextConversionResult Result_69                      (Parm, OutParm, ZeroConstructor, IsPlainOldData)
// struct FAnimPoseContext        ReturnValue_69                 (Parm, OutParm, ReturnParm)

struct FAnimPoseContext AnimExecutionContextLibrary::STATIC_ConvertToPoseContext(const struct FAnimExecutionContext& Context_69, EAnimExecutionContextConversionResult* Result_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AnimGraphRuntime.AnimExecutionContextLibrary.ConvertToPoseContext"));

	AnimExecutionContextLibrary_ConvertToPoseContext_Params params;
	params.Context_69 = Context_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (Result_69 != nullptr)
		*Result_69 = params.Result_69;

	return params.ReturnValue_69;
}


// Function AnimGraphRuntime.AnimExecutionContextLibrary.ConvertToInitializationContext
// (Final, Native, Static, Public, HasOutParms, BlueprintCallable)
// Parameters:
// struct FAnimExecutionContext   Context_69                     (ConstParm, Parm, OutParm, ReferenceParm)
// EAnimExecutionContextConversionResult Result_69                      (Parm, OutParm, ZeroConstructor, IsPlainOldData)
// struct FAnimInitializationContext ReturnValue_69                 (Parm, OutParm, ReturnParm)

struct FAnimInitializationContext AnimExecutionContextLibrary::STATIC_ConvertToInitializationContext(const struct FAnimExecutionContext& Context_69, EAnimExecutionContextConversionResult* Result_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AnimGraphRuntime.AnimExecutionContextLibrary.ConvertToInitializationContext"));

	AnimExecutionContextLibrary_ConvertToInitializationContext_Params params;
	params.Context_69 = Context_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (Result_69 != nullptr)
		*Result_69 = params.Result_69;

	return params.ReturnValue_69;
}


// Function AnimGraphRuntime.AnimExecutionContextLibrary.ConvertToComponentSpacePoseContext
// (Final, Native, Static, Public, HasOutParms, BlueprintCallable)
// Parameters:
// struct FAnimExecutionContext   Context_69                     (ConstParm, Parm, OutParm, ReferenceParm)
// EAnimExecutionContextConversionResult Result_69                      (Parm, OutParm, ZeroConstructor, IsPlainOldData)
// struct FAnimComponentSpacePoseContext ReturnValue_69                 (Parm, OutParm, ReturnParm)

struct FAnimComponentSpacePoseContext AnimExecutionContextLibrary::STATIC_ConvertToComponentSpacePoseContext(const struct FAnimExecutionContext& Context_69, EAnimExecutionContextConversionResult* Result_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AnimGraphRuntime.AnimExecutionContextLibrary.ConvertToComponentSpacePoseContext"));

	AnimExecutionContextLibrary_ConvertToComponentSpacePoseContext_Params params;
	params.Context_69 = Context_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (Result_69 != nullptr)
		*Result_69 = params.Result_69;

	return params.ReturnValue_69;
}


// Function AnimGraphRuntime.KismetAnimationLibrary.K2_TwoBoneIK
// (Final, Native, Static, Public, HasOutParms, HasDefaults, BlueprintCallable, BlueprintPure)
// Parameters:
// struct FVector                 RootPos_69                     (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
// struct FVector                 JointPos_69                    (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
// struct FVector                 EndPos_69                      (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
// struct FVector                 JointTarget_69                 (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
// struct FVector                 Effector_69                    (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
// struct FVector                 OutJointPos_69                 (Parm, OutParm, ZeroConstructor, IsPlainOldData)
// struct FVector                 OutEndPos_69                   (Parm, OutParm, ZeroConstructor, IsPlainOldData)
// bool                           bAllowStretching_69            (Parm, ZeroConstructor, IsPlainOldData)
// float                          StartStretchRatio_69           (Parm, ZeroConstructor, IsPlainOldData)
// float                          MaxStretchScale_69             (Parm, ZeroConstructor, IsPlainOldData)

void KismetAnimationLibrary::STATIC_K2_TwoBoneIK(const struct FVector& RootPos_69, const struct FVector& JointPos_69, const struct FVector& EndPos_69, const struct FVector& JointTarget_69, const struct FVector& Effector_69, bool bAllowStretching_69, float StartStretchRatio_69, float MaxStretchScale_69, struct FVector* OutJointPos_69, struct FVector* OutEndPos_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AnimGraphRuntime.KismetAnimationLibrary.K2_TwoBoneIK"));

	KismetAnimationLibrary_K2_TwoBoneIK_Params params;
	params.RootPos_69 = RootPos_69;
	params.JointPos_69 = JointPos_69;
	params.EndPos_69 = EndPos_69;
	params.JointTarget_69 = JointTarget_69;
	params.Effector_69 = Effector_69;
	params.bAllowStretching_69 = bAllowStretching_69;
	params.StartStretchRatio_69 = StartStretchRatio_69;
	params.MaxStretchScale_69 = MaxStretchScale_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (OutJointPos_69 != nullptr)
		*OutJointPos_69 = params.OutJointPos_69;
	if (OutEndPos_69 != nullptr)
		*OutEndPos_69 = params.OutEndPos_69;
}


// Function AnimGraphRuntime.KismetAnimationLibrary.K2_StartProfilingTimer
// (Final, Native, Static, Public, BlueprintCallable)

void KismetAnimationLibrary::STATIC_K2_StartProfilingTimer()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AnimGraphRuntime.KismetAnimationLibrary.K2_StartProfilingTimer"));

	KismetAnimationLibrary_K2_StartProfilingTimer_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AnimGraphRuntime.KismetAnimationLibrary.K2_MakePerlinNoiseVectorAndRemap
// (Final, Native, Static, Public, HasDefaults, BlueprintCallable, BlueprintPure)
// Parameters:
// float                          X_69                           (Parm, ZeroConstructor, IsPlainOldData)
// float                          Y_69                           (Parm, ZeroConstructor, IsPlainOldData)
// float                          Z_69                           (Parm, ZeroConstructor, IsPlainOldData)
// float                          RangeOutMinX_69                (Parm, ZeroConstructor, IsPlainOldData)
// float                          RangeOutMaxX_69                (Parm, ZeroConstructor, IsPlainOldData)
// float                          RangeOutMinY_69                (Parm, ZeroConstructor, IsPlainOldData)
// float                          RangeOutMaxY_69                (Parm, ZeroConstructor, IsPlainOldData)
// float                          RangeOutMinZ_69                (Parm, ZeroConstructor, IsPlainOldData)
// float                          RangeOutMaxZ_69                (Parm, ZeroConstructor, IsPlainOldData)
// struct FVector                 ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

struct FVector KismetAnimationLibrary::STATIC_K2_MakePerlinNoiseVectorAndRemap(float X_69, float Y_69, float Z_69, float RangeOutMinX_69, float RangeOutMaxX_69, float RangeOutMinY_69, float RangeOutMaxY_69, float RangeOutMinZ_69, float RangeOutMaxZ_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AnimGraphRuntime.KismetAnimationLibrary.K2_MakePerlinNoiseVectorAndRemap"));

	KismetAnimationLibrary_K2_MakePerlinNoiseVectorAndRemap_Params params;
	params.X_69 = X_69;
	params.Y_69 = Y_69;
	params.Z_69 = Z_69;
	params.RangeOutMinX_69 = RangeOutMinX_69;
	params.RangeOutMaxX_69 = RangeOutMaxX_69;
	params.RangeOutMinY_69 = RangeOutMinY_69;
	params.RangeOutMaxY_69 = RangeOutMaxY_69;
	params.RangeOutMinZ_69 = RangeOutMinZ_69;
	params.RangeOutMaxZ_69 = RangeOutMaxZ_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AnimGraphRuntime.KismetAnimationLibrary.K2_MakePerlinNoiseAndRemap
// (Final, Native, Static, Public, BlueprintCallable, BlueprintPure)
// Parameters:
// float                          Value_69                       (Parm, ZeroConstructor, IsPlainOldData)
// float                          RangeOutMin_69                 (Parm, ZeroConstructor, IsPlainOldData)
// float                          RangeOutMax_69                 (Parm, ZeroConstructor, IsPlainOldData)
// float                          ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

float KismetAnimationLibrary::STATIC_K2_MakePerlinNoiseAndRemap(float Value_69, float RangeOutMin_69, float RangeOutMax_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AnimGraphRuntime.KismetAnimationLibrary.K2_MakePerlinNoiseAndRemap"));

	KismetAnimationLibrary_K2_MakePerlinNoiseAndRemap_Params params;
	params.Value_69 = Value_69;
	params.RangeOutMin_69 = RangeOutMin_69;
	params.RangeOutMax_69 = RangeOutMax_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AnimGraphRuntime.KismetAnimationLibrary.K2_LookAt
// (Final, Native, Static, Public, HasOutParms, HasDefaults, BlueprintCallable, BlueprintPure)
// Parameters:
// struct FCoreUObject_FTransform CurrentTransform_69            (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
// struct FVector                 TargetPosition_69              (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
// struct FVector                 LookAtVector_69                (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bUseUpVector_69                (Parm, ZeroConstructor, IsPlainOldData)
// struct FVector                 UpVector_69                    (Parm, ZeroConstructor, IsPlainOldData)
// float                          ClampConeInDegree_69           (Parm, ZeroConstructor, IsPlainOldData)
// struct FCoreUObject_FTransform ReturnValue_69                 (Parm, OutParm, ReturnParm, IsPlainOldData)

struct FCoreUObject_FTransform KismetAnimationLibrary::STATIC_K2_LookAt(const struct FCoreUObject_FTransform& CurrentTransform_69, const struct FVector& TargetPosition_69, const struct FVector& LookAtVector_69, bool bUseUpVector_69, const struct FVector& UpVector_69, float ClampConeInDegree_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AnimGraphRuntime.KismetAnimationLibrary.K2_LookAt"));

	KismetAnimationLibrary_K2_LookAt_Params params;
	params.CurrentTransform_69 = CurrentTransform_69;
	params.TargetPosition_69 = TargetPosition_69;
	params.LookAtVector_69 = LookAtVector_69;
	params.bUseUpVector_69 = bUseUpVector_69;
	params.UpVector_69 = UpVector_69;
	params.ClampConeInDegree_69 = ClampConeInDegree_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AnimGraphRuntime.KismetAnimationLibrary.K2_EndProfilingTimer
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// bool                           bLog_69                        (Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 LogPrefix_69                   (Parm, ZeroConstructor)
// float                          ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

float KismetAnimationLibrary::STATIC_K2_EndProfilingTimer(bool bLog_69, const struct FString& LogPrefix_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AnimGraphRuntime.KismetAnimationLibrary.K2_EndProfilingTimer"));

	KismetAnimationLibrary_K2_EndProfilingTimer_Params params;
	params.bLog_69 = bLog_69;
	params.LogPrefix_69 = LogPrefix_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AnimGraphRuntime.KismetAnimationLibrary.K2_DistanceBetweenTwoSocketsAndMapRange
// (Final, Native, Static, Public, BlueprintCallable, BlueprintPure)
// Parameters:
// class SkeletalMeshComponent*   Component_69                   (ConstParm, Parm, ZeroConstructor, InstancedReference)
// struct FName                   SocketOrBoneNameA_69           (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// TEnumAsByte<ERelativeTransformSpace> SocketSpaceA_69                (Parm, ZeroConstructor, IsPlainOldData)
// struct FName                   SocketOrBoneNameB_69           (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// TEnumAsByte<ERelativeTransformSpace> SocketSpaceB_69                (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bRemapRange_69                 (Parm, ZeroConstructor, IsPlainOldData)
// float                          InRangeMin_69                  (Parm, ZeroConstructor, IsPlainOldData)
// float                          InRangeMax_69                  (Parm, ZeroConstructor, IsPlainOldData)
// float                          OutRangeMin_69                 (Parm, ZeroConstructor, IsPlainOldData)
// float                          OutRangeMax_69                 (Parm, ZeroConstructor, IsPlainOldData)
// float                          ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

float KismetAnimationLibrary::STATIC_K2_DistanceBetweenTwoSocketsAndMapRange(class SkeletalMeshComponent* Component_69, const struct FName& SocketOrBoneNameA_69, TEnumAsByte<ERelativeTransformSpace> SocketSpaceA_69, const struct FName& SocketOrBoneNameB_69, TEnumAsByte<ERelativeTransformSpace> SocketSpaceB_69, bool bRemapRange_69, float InRangeMin_69, float InRangeMax_69, float OutRangeMin_69, float OutRangeMax_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AnimGraphRuntime.KismetAnimationLibrary.K2_DistanceBetweenTwoSocketsAndMapRange"));

	KismetAnimationLibrary_K2_DistanceBetweenTwoSocketsAndMapRange_Params params;
	params.Component_69 = Component_69;
	params.SocketOrBoneNameA_69 = SocketOrBoneNameA_69;
	params.SocketSpaceA_69 = SocketSpaceA_69;
	params.SocketOrBoneNameB_69 = SocketOrBoneNameB_69;
	params.SocketSpaceB_69 = SocketSpaceB_69;
	params.bRemapRange_69 = bRemapRange_69;
	params.InRangeMin_69 = InRangeMin_69;
	params.InRangeMax_69 = InRangeMax_69;
	params.OutRangeMin_69 = OutRangeMin_69;
	params.OutRangeMax_69 = OutRangeMax_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AnimGraphRuntime.KismetAnimationLibrary.K2_DirectionBetweenSockets
// (Final, Native, Static, Public, HasDefaults, BlueprintCallable, BlueprintPure)
// Parameters:
// class SkeletalMeshComponent*   Component_69                   (ConstParm, Parm, ZeroConstructor, InstancedReference)
// struct FName                   SocketOrBoneNameFrom_69        (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// struct FName                   SocketOrBoneNameTo_69          (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// struct FVector                 ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

struct FVector KismetAnimationLibrary::STATIC_K2_DirectionBetweenSockets(class SkeletalMeshComponent* Component_69, const struct FName& SocketOrBoneNameFrom_69, const struct FName& SocketOrBoneNameTo_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AnimGraphRuntime.KismetAnimationLibrary.K2_DirectionBetweenSockets"));

	KismetAnimationLibrary_K2_DirectionBetweenSockets_Params params;
	params.Component_69 = Component_69;
	params.SocketOrBoneNameFrom_69 = SocketOrBoneNameFrom_69;
	params.SocketOrBoneNameTo_69 = SocketOrBoneNameTo_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AnimGraphRuntime.KismetAnimationLibrary.K2_CalculateVelocityFromSockets
// (Final, Native, Static, Public, HasOutParms, HasDefaults, BlueprintCallable)
// Parameters:
// float                          DeltaSeconds_69                (Parm, ZeroConstructor, IsPlainOldData)
// class SkeletalMeshComponent*   Component_69                   (Parm, ZeroConstructor, InstancedReference)
// struct FName                   SocketOrBoneName_69            (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// struct FName                   ReferenceSocketOrBone_69       (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// TEnumAsByte<ERelativeTransformSpace> SocketSpace_69                 (Parm, ZeroConstructor, IsPlainOldData)
// struct FVector                 OffsetInBoneSpace_69           (Parm, ZeroConstructor, IsPlainOldData)
// struct FPositionHistory        History_69                     (Parm, OutParm, ReferenceParm)
// int                            NumberOfSamples_69             (Parm, ZeroConstructor, IsPlainOldData)
// float                          VelocityMin_69                 (Parm, ZeroConstructor, IsPlainOldData)
// float                          VelocityMax_69                 (Parm, ZeroConstructor, IsPlainOldData)
// EEasingFuncType                EasingType_69                  (Parm, ZeroConstructor, IsPlainOldData)
// struct FRuntimeFloatCurve      CustomCurve_69                 (ConstParm, Parm, OutParm, ReferenceParm)
// float                          ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

float KismetAnimationLibrary::STATIC_K2_CalculateVelocityFromSockets(float DeltaSeconds_69, class SkeletalMeshComponent* Component_69, const struct FName& SocketOrBoneName_69, const struct FName& ReferenceSocketOrBone_69, TEnumAsByte<ERelativeTransformSpace> SocketSpace_69, const struct FVector& OffsetInBoneSpace_69, int NumberOfSamples_69, float VelocityMin_69, float VelocityMax_69, EEasingFuncType EasingType_69, const struct FRuntimeFloatCurve& CustomCurve_69, struct FPositionHistory* History_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AnimGraphRuntime.KismetAnimationLibrary.K2_CalculateVelocityFromSockets"));

	KismetAnimationLibrary_K2_CalculateVelocityFromSockets_Params params;
	params.DeltaSeconds_69 = DeltaSeconds_69;
	params.Component_69 = Component_69;
	params.SocketOrBoneName_69 = SocketOrBoneName_69;
	params.ReferenceSocketOrBone_69 = ReferenceSocketOrBone_69;
	params.SocketSpace_69 = SocketSpace_69;
	params.OffsetInBoneSpace_69 = OffsetInBoneSpace_69;
	params.NumberOfSamples_69 = NumberOfSamples_69;
	params.VelocityMin_69 = VelocityMin_69;
	params.VelocityMax_69 = VelocityMax_69;
	params.EasingType_69 = EasingType_69;
	params.CustomCurve_69 = CustomCurve_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (History_69 != nullptr)
		*History_69 = params.History_69;

	return params.ReturnValue_69;
}


// Function AnimGraphRuntime.KismetAnimationLibrary.K2_CalculateVelocityFromPositionHistory
// (Final, Native, Static, Public, HasOutParms, HasDefaults, BlueprintCallable)
// Parameters:
// float                          DeltaSeconds_69                (Parm, ZeroConstructor, IsPlainOldData)
// struct FVector                 Position_69                    (Parm, ZeroConstructor, IsPlainOldData)
// struct FPositionHistory        History_69                     (Parm, OutParm, ReferenceParm)
// int                            NumberOfSamples_69             (Parm, ZeroConstructor, IsPlainOldData)
// float                          VelocityMin_69                 (Parm, ZeroConstructor, IsPlainOldData)
// float                          VelocityMax_69                 (Parm, ZeroConstructor, IsPlainOldData)
// float                          ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

float KismetAnimationLibrary::STATIC_K2_CalculateVelocityFromPositionHistory(float DeltaSeconds_69, const struct FVector& Position_69, int NumberOfSamples_69, float VelocityMin_69, float VelocityMax_69, struct FPositionHistory* History_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AnimGraphRuntime.KismetAnimationLibrary.K2_CalculateVelocityFromPositionHistory"));

	KismetAnimationLibrary_K2_CalculateVelocityFromPositionHistory_Params params;
	params.DeltaSeconds_69 = DeltaSeconds_69;
	params.Position_69 = Position_69;
	params.NumberOfSamples_69 = NumberOfSamples_69;
	params.VelocityMin_69 = VelocityMin_69;
	params.VelocityMax_69 = VelocityMax_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (History_69 != nullptr)
		*History_69 = params.History_69;

	return params.ReturnValue_69;
}


// Function AnimGraphRuntime.KismetAnimationLibrary.CalculateDirection
// (Final, Native, Static, Public, HasOutParms, HasDefaults, BlueprintCallable, BlueprintPure)
// Parameters:
// struct FVector                 Velocity_69                    (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
// struct FRotator                BaseRotation_69                (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
// float                          ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

float KismetAnimationLibrary::STATIC_CalculateDirection(const struct FVector& Velocity_69, const struct FRotator& BaseRotation_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AnimGraphRuntime.KismetAnimationLibrary.CalculateDirection"));

	KismetAnimationLibrary_CalculateDirection_Params params;
	params.Velocity_69 = Velocity_69;
	params.BaseRotation_69 = BaseRotation_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AnimGraphRuntime.LinkedAnimGraphLibrary.HasLinkedAnimInstance
// (Final, Native, Static, Public, HasOutParms, BlueprintCallable, BlueprintPure)
// Parameters:
// struct FLinkedAnimGraphReference Node_69                        (ConstParm, Parm, OutParm, ReferenceParm)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool LinkedAnimGraphLibrary::STATIC_HasLinkedAnimInstance(const struct FLinkedAnimGraphReference& Node_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AnimGraphRuntime.LinkedAnimGraphLibrary.HasLinkedAnimInstance"));

	LinkedAnimGraphLibrary_HasLinkedAnimInstance_Params params;
	params.Node_69 = Node_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AnimGraphRuntime.LinkedAnimGraphLibrary.GetLinkedAnimInstance
// (Final, Native, Static, Public, HasOutParms, BlueprintCallable, BlueprintPure)
// Parameters:
// struct FLinkedAnimGraphReference Node_69                        (ConstParm, Parm, OutParm, ReferenceParm)
// class AnimInstance*            ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

class AnimInstance* LinkedAnimGraphLibrary::STATIC_GetLinkedAnimInstance(const struct FLinkedAnimGraphReference& Node_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AnimGraphRuntime.LinkedAnimGraphLibrary.GetLinkedAnimInstance"));

	LinkedAnimGraphLibrary_GetLinkedAnimInstance_Params params;
	params.Node_69 = Node_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AnimGraphRuntime.LinkedAnimGraphLibrary.ConvertToLinkedAnimGraphPure
// (Final, Native, Static, Public, HasOutParms, BlueprintCallable, BlueprintPure)
// Parameters:
// struct FAnimNodeReference      Node_69                        (ConstParm, Parm, OutParm, ReferenceParm)
// struct FLinkedAnimGraphReference LinkedAnimGraph_69             (Parm, OutParm)
// bool                           Result_69                      (Parm, OutParm, ZeroConstructor, IsPlainOldData)

void LinkedAnimGraphLibrary::STATIC_ConvertToLinkedAnimGraphPure(const struct FAnimNodeReference& Node_69, struct FLinkedAnimGraphReference* LinkedAnimGraph_69, bool* Result_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AnimGraphRuntime.LinkedAnimGraphLibrary.ConvertToLinkedAnimGraphPure"));

	LinkedAnimGraphLibrary_ConvertToLinkedAnimGraphPure_Params params;
	params.Node_69 = Node_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (LinkedAnimGraph_69 != nullptr)
		*LinkedAnimGraph_69 = params.LinkedAnimGraph_69;
	if (Result_69 != nullptr)
		*Result_69 = params.Result_69;
}


// Function AnimGraphRuntime.LinkedAnimGraphLibrary.ConvertToLinkedAnimGraph
// (Final, Native, Static, Public, HasOutParms, BlueprintCallable)
// Parameters:
// struct FAnimNodeReference      Node_69                        (ConstParm, Parm, OutParm, ReferenceParm)
// EAnimNodeReferenceConversionResult Result_69                      (Parm, OutParm, ZeroConstructor, IsPlainOldData)
// struct FLinkedAnimGraphReference ReturnValue_69                 (Parm, OutParm, ReturnParm)

struct FLinkedAnimGraphReference LinkedAnimGraphLibrary::STATIC_ConvertToLinkedAnimGraph(const struct FAnimNodeReference& Node_69, EAnimNodeReferenceConversionResult* Result_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AnimGraphRuntime.LinkedAnimGraphLibrary.ConvertToLinkedAnimGraph"));

	LinkedAnimGraphLibrary_ConvertToLinkedAnimGraph_Params params;
	params.Node_69 = Node_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (Result_69 != nullptr)
		*Result_69 = params.Result_69;

	return params.ReturnValue_69;
}


// Function AnimGraphRuntime.PlayMontageCallbackProxy.OnNotifyEndReceived
// (Final, Native, Protected, HasOutParms)
// Parameters:
// struct FName                   NotifyName_69                  (Parm, ZeroConstructor, IsPlainOldData)
// struct FBranchingPointNotifyPayload BranchingPointNotifyPayload_69 (ConstParm, Parm, OutParm, ReferenceParm)

void PlayMontageCallbackProxy::OnNotifyEndReceived(const struct FName& NotifyName_69, const struct FBranchingPointNotifyPayload& BranchingPointNotifyPayload_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AnimGraphRuntime.PlayMontageCallbackProxy.OnNotifyEndReceived"));

	PlayMontageCallbackProxy_OnNotifyEndReceived_Params params;
	params.NotifyName_69 = NotifyName_69;
	params.BranchingPointNotifyPayload_69 = BranchingPointNotifyPayload_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AnimGraphRuntime.PlayMontageCallbackProxy.OnNotifyBeginReceived
// (Final, Native, Protected, HasOutParms)
// Parameters:
// struct FName                   NotifyName_69                  (Parm, ZeroConstructor, IsPlainOldData)
// struct FBranchingPointNotifyPayload BranchingPointNotifyPayload_69 (ConstParm, Parm, OutParm, ReferenceParm)

void PlayMontageCallbackProxy::OnNotifyBeginReceived(const struct FName& NotifyName_69, const struct FBranchingPointNotifyPayload& BranchingPointNotifyPayload_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AnimGraphRuntime.PlayMontageCallbackProxy.OnNotifyBeginReceived"));

	PlayMontageCallbackProxy_OnNotifyBeginReceived_Params params;
	params.NotifyName_69 = NotifyName_69;
	params.BranchingPointNotifyPayload_69 = BranchingPointNotifyPayload_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AnimGraphRuntime.PlayMontageCallbackProxy.OnMontageEnded
// (Final, Native, Protected)
// Parameters:
// class AnimMontage*             Montage_69                     (Parm, ZeroConstructor)
// bool                           bInterrupted_69                (Parm, ZeroConstructor, IsPlainOldData)

void PlayMontageCallbackProxy::OnMontageEnded(class AnimMontage* Montage_69, bool bInterrupted_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AnimGraphRuntime.PlayMontageCallbackProxy.OnMontageEnded"));

	PlayMontageCallbackProxy_OnMontageEnded_Params params;
	params.Montage_69 = Montage_69;
	params.bInterrupted_69 = bInterrupted_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AnimGraphRuntime.PlayMontageCallbackProxy.OnMontageBlendingOut
// (Final, Native, Protected)
// Parameters:
// class AnimMontage*             Montage_69                     (Parm, ZeroConstructor)
// bool                           bInterrupted_69                (Parm, ZeroConstructor, IsPlainOldData)

void PlayMontageCallbackProxy::OnMontageBlendingOut(class AnimMontage* Montage_69, bool bInterrupted_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AnimGraphRuntime.PlayMontageCallbackProxy.OnMontageBlendingOut"));

	PlayMontageCallbackProxy_OnMontageBlendingOut_Params params;
	params.Montage_69 = Montage_69;
	params.bInterrupted_69 = bInterrupted_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AnimGraphRuntime.PlayMontageCallbackProxy.CreateProxyObjectForPlayMontage
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// class SkeletalMeshComponent*   InSkeletalMeshComponent_69     (Parm, ZeroConstructor, InstancedReference)
// class AnimMontage*             MontageToPlay_69               (Parm, ZeroConstructor)
// float                          PlayRate_69                    (Parm, ZeroConstructor, IsPlainOldData)
// float                          StartingPosition_69            (Parm, ZeroConstructor, IsPlainOldData)
// struct FName                   StartingSection_69             (Parm, ZeroConstructor, IsPlainOldData)
// class PlayMontageCallbackProxy* ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

class PlayMontageCallbackProxy* PlayMontageCallbackProxy::STATIC_CreateProxyObjectForPlayMontage(class SkeletalMeshComponent* InSkeletalMeshComponent_69, class AnimMontage* MontageToPlay_69, float PlayRate_69, float StartingPosition_69, const struct FName& StartingSection_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AnimGraphRuntime.PlayMontageCallbackProxy.CreateProxyObjectForPlayMontage"));

	PlayMontageCallbackProxy_CreateProxyObjectForPlayMontage_Params params;
	params.InSkeletalMeshComponent_69 = InSkeletalMeshComponent_69;
	params.MontageToPlay_69 = MontageToPlay_69;
	params.PlayRate_69 = PlayRate_69;
	params.StartingPosition_69 = StartingPosition_69;
	params.StartingSection_69 = StartingSection_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AnimGraphRuntime.SequenceEvaluatorLibrary.SetSequenceWithInertialBlending
// (Final, Native, Static, Public, HasOutParms, BlueprintCallable)
// Parameters:
// struct FAnimUpdateContext      UpdateContext_69               (ConstParm, Parm, OutParm, ReferenceParm)
// struct FSequenceEvaluatorReference SequenceEvaluator_69           (ConstParm, Parm, OutParm, ReferenceParm)
// class AnimSequenceBase*        Sequence_69                    (Parm, ZeroConstructor)
// float                          BlendTime_69                   (Parm, ZeroConstructor, IsPlainOldData)
// struct FSequenceEvaluatorReference ReturnValue_69                 (Parm, OutParm, ReturnParm)

struct FSequenceEvaluatorReference SequenceEvaluatorLibrary::STATIC_SetSequenceWithInertialBlending(const struct FAnimUpdateContext& UpdateContext_69, const struct FSequenceEvaluatorReference& SequenceEvaluator_69, class AnimSequenceBase* Sequence_69, float BlendTime_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AnimGraphRuntime.SequenceEvaluatorLibrary.SetSequenceWithInertialBlending"));

	SequenceEvaluatorLibrary_SetSequenceWithInertialBlending_Params params;
	params.UpdateContext_69 = UpdateContext_69;
	params.SequenceEvaluator_69 = SequenceEvaluator_69;
	params.Sequence_69 = Sequence_69;
	params.BlendTime_69 = BlendTime_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AnimGraphRuntime.SequenceEvaluatorLibrary.SetSequence
// (Final, Native, Static, Public, HasOutParms, BlueprintCallable)
// Parameters:
// struct FSequenceEvaluatorReference SequenceEvaluator_69           (ConstParm, Parm, OutParm, ReferenceParm)
// class AnimSequenceBase*        Sequence_69                    (Parm, ZeroConstructor)
// struct FSequenceEvaluatorReference ReturnValue_69                 (Parm, OutParm, ReturnParm)

struct FSequenceEvaluatorReference SequenceEvaluatorLibrary::STATIC_SetSequence(const struct FSequenceEvaluatorReference& SequenceEvaluator_69, class AnimSequenceBase* Sequence_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AnimGraphRuntime.SequenceEvaluatorLibrary.SetSequence"));

	SequenceEvaluatorLibrary_SetSequence_Params params;
	params.SequenceEvaluator_69 = SequenceEvaluator_69;
	params.Sequence_69 = Sequence_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AnimGraphRuntime.SequenceEvaluatorLibrary.SetExplicitTime
// (Final, Native, Static, Public, HasOutParms, BlueprintCallable)
// Parameters:
// struct FSequenceEvaluatorReference SequenceEvaluator_69           (ConstParm, Parm, OutParm, ReferenceParm)
// float                          Time_69                        (Parm, ZeroConstructor, IsPlainOldData)
// struct FSequenceEvaluatorReference ReturnValue_69                 (Parm, OutParm, ReturnParm)

struct FSequenceEvaluatorReference SequenceEvaluatorLibrary::STATIC_SetExplicitTime(const struct FSequenceEvaluatorReference& SequenceEvaluator_69, float Time_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AnimGraphRuntime.SequenceEvaluatorLibrary.SetExplicitTime"));

	SequenceEvaluatorLibrary_SetExplicitTime_Params params;
	params.SequenceEvaluator_69 = SequenceEvaluator_69;
	params.Time_69 = Time_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AnimGraphRuntime.SequenceEvaluatorLibrary.GetSequence
// (Final, Native, Static, Public, HasOutParms, BlueprintCallable, BlueprintPure)
// Parameters:
// struct FSequenceEvaluatorReference SequenceEvaluator_69           (ConstParm, Parm, OutParm, ReferenceParm)
// class AnimSequenceBase*        ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

class AnimSequenceBase* SequenceEvaluatorLibrary::STATIC_GetSequence(const struct FSequenceEvaluatorReference& SequenceEvaluator_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AnimGraphRuntime.SequenceEvaluatorLibrary.GetSequence"));

	SequenceEvaluatorLibrary_GetSequence_Params params;
	params.SequenceEvaluator_69 = SequenceEvaluator_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AnimGraphRuntime.SequenceEvaluatorLibrary.GetAccumulatedTime
// (Final, Native, Static, Public, HasOutParms, BlueprintCallable, BlueprintPure)
// Parameters:
// struct FSequenceEvaluatorReference SequenceEvaluator_69           (ConstParm, Parm, OutParm, ReferenceParm)
// float                          ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

float SequenceEvaluatorLibrary::STATIC_GetAccumulatedTime(const struct FSequenceEvaluatorReference& SequenceEvaluator_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AnimGraphRuntime.SequenceEvaluatorLibrary.GetAccumulatedTime"));

	SequenceEvaluatorLibrary_GetAccumulatedTime_Params params;
	params.SequenceEvaluator_69 = SequenceEvaluator_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AnimGraphRuntime.SequenceEvaluatorLibrary.ConvertToSequenceEvaluatorPure
// (Final, Native, Static, Public, HasOutParms, BlueprintCallable, BlueprintPure)
// Parameters:
// struct FAnimNodeReference      Node_69                        (ConstParm, Parm, OutParm, ReferenceParm)
// struct FSequenceEvaluatorReference SequenceEvaluator_69           (Parm, OutParm)
// bool                           Result_69                      (Parm, OutParm, ZeroConstructor, IsPlainOldData)

void SequenceEvaluatorLibrary::STATIC_ConvertToSequenceEvaluatorPure(const struct FAnimNodeReference& Node_69, struct FSequenceEvaluatorReference* SequenceEvaluator_69, bool* Result_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AnimGraphRuntime.SequenceEvaluatorLibrary.ConvertToSequenceEvaluatorPure"));

	SequenceEvaluatorLibrary_ConvertToSequenceEvaluatorPure_Params params;
	params.Node_69 = Node_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (SequenceEvaluator_69 != nullptr)
		*SequenceEvaluator_69 = params.SequenceEvaluator_69;
	if (Result_69 != nullptr)
		*Result_69 = params.Result_69;
}


// Function AnimGraphRuntime.SequenceEvaluatorLibrary.ConvertToSequenceEvaluator
// (Final, Native, Static, Public, HasOutParms, BlueprintCallable)
// Parameters:
// struct FAnimNodeReference      Node_69                        (ConstParm, Parm, OutParm, ReferenceParm)
// EAnimNodeReferenceConversionResult Result_69                      (Parm, OutParm, ZeroConstructor, IsPlainOldData)
// struct FSequenceEvaluatorReference ReturnValue_69                 (Parm, OutParm, ReturnParm)

struct FSequenceEvaluatorReference SequenceEvaluatorLibrary::STATIC_ConvertToSequenceEvaluator(const struct FAnimNodeReference& Node_69, EAnimNodeReferenceConversionResult* Result_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AnimGraphRuntime.SequenceEvaluatorLibrary.ConvertToSequenceEvaluator"));

	SequenceEvaluatorLibrary_ConvertToSequenceEvaluator_Params params;
	params.Node_69 = Node_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (Result_69 != nullptr)
		*Result_69 = params.Result_69;

	return params.ReturnValue_69;
}


// Function AnimGraphRuntime.SequenceEvaluatorLibrary.AdvanceTime
// (Final, Native, Static, Public, HasOutParms, BlueprintCallable)
// Parameters:
// struct FAnimUpdateContext      UpdateContext_69               (ConstParm, Parm, OutParm, ReferenceParm)
// struct FSequenceEvaluatorReference SequenceEvaluator_69           (ConstParm, Parm, OutParm, ReferenceParm)
// float                          PlayRate_69                    (Parm, ZeroConstructor, IsPlainOldData)
// struct FSequenceEvaluatorReference ReturnValue_69                 (Parm, OutParm, ReturnParm)

struct FSequenceEvaluatorReference SequenceEvaluatorLibrary::STATIC_AdvanceTime(const struct FAnimUpdateContext& UpdateContext_69, const struct FSequenceEvaluatorReference& SequenceEvaluator_69, float PlayRate_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AnimGraphRuntime.SequenceEvaluatorLibrary.AdvanceTime"));

	SequenceEvaluatorLibrary_AdvanceTime_Params params;
	params.UpdateContext_69 = UpdateContext_69;
	params.SequenceEvaluator_69 = SequenceEvaluator_69;
	params.PlayRate_69 = PlayRate_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AnimGraphRuntime.SequencePlayerLibrary.SetStartPosition
// (Final, Native, Static, Public, HasOutParms, BlueprintCallable)
// Parameters:
// struct FSequencePlayerReference SequencePlayer_69              (ConstParm, Parm, OutParm, ReferenceParm)
// float                          StartPosition_69               (Parm, ZeroConstructor, IsPlainOldData)
// struct FSequencePlayerReference ReturnValue_69                 (Parm, OutParm, ReturnParm)

struct FSequencePlayerReference SequencePlayerLibrary::STATIC_SetStartPosition(const struct FSequencePlayerReference& SequencePlayer_69, float StartPosition_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AnimGraphRuntime.SequencePlayerLibrary.SetStartPosition"));

	SequencePlayerLibrary_SetStartPosition_Params params;
	params.SequencePlayer_69 = SequencePlayer_69;
	params.StartPosition_69 = StartPosition_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AnimGraphRuntime.SequencePlayerLibrary.SetSequenceWithInertialBlending
// (Final, Native, Static, Public, HasOutParms, BlueprintCallable)
// Parameters:
// struct FAnimUpdateContext      UpdateContext_69               (ConstParm, Parm, OutParm, ReferenceParm)
// struct FSequencePlayerReference SequencePlayer_69              (ConstParm, Parm, OutParm, ReferenceParm)
// class AnimSequenceBase*        Sequence_69                    (Parm, ZeroConstructor)
// float                          BlendTime_69                   (Parm, ZeroConstructor, IsPlainOldData)
// struct FSequencePlayerReference ReturnValue_69                 (Parm, OutParm, ReturnParm)

struct FSequencePlayerReference SequencePlayerLibrary::STATIC_SetSequenceWithInertialBlending(const struct FAnimUpdateContext& UpdateContext_69, const struct FSequencePlayerReference& SequencePlayer_69, class AnimSequenceBase* Sequence_69, float BlendTime_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AnimGraphRuntime.SequencePlayerLibrary.SetSequenceWithInertialBlending"));

	SequencePlayerLibrary_SetSequenceWithInertialBlending_Params params;
	params.UpdateContext_69 = UpdateContext_69;
	params.SequencePlayer_69 = SequencePlayer_69;
	params.Sequence_69 = Sequence_69;
	params.BlendTime_69 = BlendTime_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AnimGraphRuntime.SequencePlayerLibrary.SetSequence
// (Final, Native, Static, Public, HasOutParms, BlueprintCallable)
// Parameters:
// struct FSequencePlayerReference SequencePlayer_69              (ConstParm, Parm, OutParm, ReferenceParm)
// class AnimSequenceBase*        Sequence_69                    (Parm, ZeroConstructor)
// struct FSequencePlayerReference ReturnValue_69                 (Parm, OutParm, ReturnParm)

struct FSequencePlayerReference SequencePlayerLibrary::STATIC_SetSequence(const struct FSequencePlayerReference& SequencePlayer_69, class AnimSequenceBase* Sequence_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AnimGraphRuntime.SequencePlayerLibrary.SetSequence"));

	SequencePlayerLibrary_SetSequence_Params params;
	params.SequencePlayer_69 = SequencePlayer_69;
	params.Sequence_69 = Sequence_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AnimGraphRuntime.SequencePlayerLibrary.SetPlayRate
// (Final, Native, Static, Public, HasOutParms, BlueprintCallable)
// Parameters:
// struct FSequencePlayerReference SequencePlayer_69              (ConstParm, Parm, OutParm, ReferenceParm)
// float                          PlayRate_69                    (Parm, ZeroConstructor, IsPlainOldData)
// struct FSequencePlayerReference ReturnValue_69                 (Parm, OutParm, ReturnParm)

struct FSequencePlayerReference SequencePlayerLibrary::STATIC_SetPlayRate(const struct FSequencePlayerReference& SequencePlayer_69, float PlayRate_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AnimGraphRuntime.SequencePlayerLibrary.SetPlayRate"));

	SequencePlayerLibrary_SetPlayRate_Params params;
	params.SequencePlayer_69 = SequencePlayer_69;
	params.PlayRate_69 = PlayRate_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AnimGraphRuntime.SequencePlayerLibrary.SetAccumulatedTime
// (Final, Native, Static, Public, HasOutParms, BlueprintCallable)
// Parameters:
// struct FSequencePlayerReference SequencePlayer_69              (ConstParm, Parm, OutParm, ReferenceParm)
// float                          Time_69                        (Parm, ZeroConstructor, IsPlainOldData)
// struct FSequencePlayerReference ReturnValue_69                 (Parm, OutParm, ReturnParm)

struct FSequencePlayerReference SequencePlayerLibrary::STATIC_SetAccumulatedTime(const struct FSequencePlayerReference& SequencePlayer_69, float Time_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AnimGraphRuntime.SequencePlayerLibrary.SetAccumulatedTime"));

	SequencePlayerLibrary_SetAccumulatedTime_Params params;
	params.SequencePlayer_69 = SequencePlayer_69;
	params.Time_69 = Time_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AnimGraphRuntime.SequencePlayerLibrary.GetStartPosition
// (Final, Native, Static, Public, HasOutParms, BlueprintCallable, BlueprintPure)
// Parameters:
// struct FSequencePlayerReference SequencePlayer_69              (ConstParm, Parm, OutParm, ReferenceParm)
// float                          ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

float SequencePlayerLibrary::STATIC_GetStartPosition(const struct FSequencePlayerReference& SequencePlayer_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AnimGraphRuntime.SequencePlayerLibrary.GetStartPosition"));

	SequencePlayerLibrary_GetStartPosition_Params params;
	params.SequencePlayer_69 = SequencePlayer_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AnimGraphRuntime.SequencePlayerLibrary.GetSequencePure
// (Final, Native, Static, Public, HasOutParms, BlueprintCallable, BlueprintPure)
// Parameters:
// struct FSequencePlayerReference SequencePlayer_69              (ConstParm, Parm, OutParm, ReferenceParm)
// class AnimSequenceBase*        ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

class AnimSequenceBase* SequencePlayerLibrary::STATIC_GetSequencePure(const struct FSequencePlayerReference& SequencePlayer_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AnimGraphRuntime.SequencePlayerLibrary.GetSequencePure"));

	SequencePlayerLibrary_GetSequencePure_Params params;
	params.SequencePlayer_69 = SequencePlayer_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AnimGraphRuntime.SequencePlayerLibrary.GetSequence
// (Final, Native, Static, Public, HasOutParms, BlueprintCallable)
// Parameters:
// struct FSequencePlayerReference SequencePlayer_69              (ConstParm, Parm, OutParm, ReferenceParm)
// class AnimSequenceBase*        SequenceBase_69                (Parm, OutParm, ZeroConstructor, ReferenceParm)
// struct FSequencePlayerReference ReturnValue_69                 (Parm, OutParm, ReturnParm)

struct FSequencePlayerReference SequencePlayerLibrary::STATIC_GetSequence(const struct FSequencePlayerReference& SequencePlayer_69, class AnimSequenceBase** SequenceBase_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AnimGraphRuntime.SequencePlayerLibrary.GetSequence"));

	SequencePlayerLibrary_GetSequence_Params params;
	params.SequencePlayer_69 = SequencePlayer_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (SequenceBase_69 != nullptr)
		*SequenceBase_69 = params.SequenceBase_69;

	return params.ReturnValue_69;
}


// Function AnimGraphRuntime.SequencePlayerLibrary.GetPlayRate
// (Final, Native, Static, Public, HasOutParms, BlueprintCallable, BlueprintPure)
// Parameters:
// struct FSequencePlayerReference SequencePlayer_69              (ConstParm, Parm, OutParm, ReferenceParm)
// float                          ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

float SequencePlayerLibrary::STATIC_GetPlayRate(const struct FSequencePlayerReference& SequencePlayer_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AnimGraphRuntime.SequencePlayerLibrary.GetPlayRate"));

	SequencePlayerLibrary_GetPlayRate_Params params;
	params.SequencePlayer_69 = SequencePlayer_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AnimGraphRuntime.SequencePlayerLibrary.GetLoopAnimation
// (Final, Native, Static, Public, HasOutParms, BlueprintCallable, BlueprintPure)
// Parameters:
// struct FSequencePlayerReference SequencePlayer_69              (ConstParm, Parm, OutParm, ReferenceParm)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool SequencePlayerLibrary::STATIC_GetLoopAnimation(const struct FSequencePlayerReference& SequencePlayer_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AnimGraphRuntime.SequencePlayerLibrary.GetLoopAnimation"));

	SequencePlayerLibrary_GetLoopAnimation_Params params;
	params.SequencePlayer_69 = SequencePlayer_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AnimGraphRuntime.SequencePlayerLibrary.GetAccumulatedTime
// (Final, Native, Static, Public, HasOutParms, BlueprintCallable, BlueprintPure)
// Parameters:
// struct FSequencePlayerReference SequencePlayer_69              (ConstParm, Parm, OutParm, ReferenceParm)
// float                          ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

float SequencePlayerLibrary::STATIC_GetAccumulatedTime(const struct FSequencePlayerReference& SequencePlayer_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AnimGraphRuntime.SequencePlayerLibrary.GetAccumulatedTime"));

	SequencePlayerLibrary_GetAccumulatedTime_Params params;
	params.SequencePlayer_69 = SequencePlayer_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AnimGraphRuntime.SequencePlayerLibrary.ConvertToSequencePlayerPure
// (Final, Native, Static, Public, HasOutParms, BlueprintCallable, BlueprintPure)
// Parameters:
// struct FAnimNodeReference      Node_69                        (ConstParm, Parm, OutParm, ReferenceParm)
// struct FSequencePlayerReference SequencePlayer_69              (Parm, OutParm)
// bool                           Result_69                      (Parm, OutParm, ZeroConstructor, IsPlainOldData)

void SequencePlayerLibrary::STATIC_ConvertToSequencePlayerPure(const struct FAnimNodeReference& Node_69, struct FSequencePlayerReference* SequencePlayer_69, bool* Result_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AnimGraphRuntime.SequencePlayerLibrary.ConvertToSequencePlayerPure"));

	SequencePlayerLibrary_ConvertToSequencePlayerPure_Params params;
	params.Node_69 = Node_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (SequencePlayer_69 != nullptr)
		*SequencePlayer_69 = params.SequencePlayer_69;
	if (Result_69 != nullptr)
		*Result_69 = params.Result_69;
}


// Function AnimGraphRuntime.SequencePlayerLibrary.ConvertToSequencePlayer
// (Final, Native, Static, Public, HasOutParms, BlueprintCallable)
// Parameters:
// struct FAnimNodeReference      Node_69                        (ConstParm, Parm, OutParm, ReferenceParm)
// EAnimNodeReferenceConversionResult Result_69                      (Parm, OutParm, ZeroConstructor, IsPlainOldData)
// struct FSequencePlayerReference ReturnValue_69                 (Parm, OutParm, ReturnParm)

struct FSequencePlayerReference SequencePlayerLibrary::STATIC_ConvertToSequencePlayer(const struct FAnimNodeReference& Node_69, EAnimNodeReferenceConversionResult* Result_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AnimGraphRuntime.SequencePlayerLibrary.ConvertToSequencePlayer"));

	SequencePlayerLibrary_ConvertToSequencePlayer_Params params;
	params.Node_69 = Node_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (Result_69 != nullptr)
		*Result_69 = params.Result_69;

	return params.ReturnValue_69;
}


// Function AnimGraphRuntime.SkeletalControlLibrary.SetAlpha
// (Final, Native, Static, Public, HasOutParms, BlueprintCallable)
// Parameters:
// struct FSkeletalControlReference SkeletalControl_69             (ConstParm, Parm, OutParm, ReferenceParm)
// float                          Alpha_69                       (Parm, ZeroConstructor, IsPlainOldData)
// struct FSkeletalControlReference ReturnValue_69                 (Parm, OutParm, ReturnParm)

struct FSkeletalControlReference SkeletalControlLibrary::STATIC_SetAlpha(const struct FSkeletalControlReference& SkeletalControl_69, float Alpha_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AnimGraphRuntime.SkeletalControlLibrary.SetAlpha"));

	SkeletalControlLibrary_SetAlpha_Params params;
	params.SkeletalControl_69 = SkeletalControl_69;
	params.Alpha_69 = Alpha_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AnimGraphRuntime.SkeletalControlLibrary.GetAlpha
// (Final, Native, Static, Public, HasOutParms, BlueprintCallable, BlueprintPure)
// Parameters:
// struct FSkeletalControlReference SkeletalControl_69             (ConstParm, Parm, OutParm, ReferenceParm)
// float                          ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

float SkeletalControlLibrary::STATIC_GetAlpha(const struct FSkeletalControlReference& SkeletalControl_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AnimGraphRuntime.SkeletalControlLibrary.GetAlpha"));

	SkeletalControlLibrary_GetAlpha_Params params;
	params.SkeletalControl_69 = SkeletalControl_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AnimGraphRuntime.SkeletalControlLibrary.ConvertToSkeletalControlPure
// (Final, Native, Static, Public, HasOutParms, BlueprintCallable, BlueprintPure)
// Parameters:
// struct FAnimNodeReference      Node_69                        (ConstParm, Parm, OutParm, ReferenceParm)
// struct FSkeletalControlReference SkeletalControl_69             (Parm, OutParm)
// bool                           Result_69                      (Parm, OutParm, ZeroConstructor, IsPlainOldData)

void SkeletalControlLibrary::STATIC_ConvertToSkeletalControlPure(const struct FAnimNodeReference& Node_69, struct FSkeletalControlReference* SkeletalControl_69, bool* Result_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AnimGraphRuntime.SkeletalControlLibrary.ConvertToSkeletalControlPure"));

	SkeletalControlLibrary_ConvertToSkeletalControlPure_Params params;
	params.Node_69 = Node_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (SkeletalControl_69 != nullptr)
		*SkeletalControl_69 = params.SkeletalControl_69;
	if (Result_69 != nullptr)
		*Result_69 = params.Result_69;
}


// Function AnimGraphRuntime.SkeletalControlLibrary.ConvertToSkeletalControl
// (Final, Native, Static, Public, HasOutParms, BlueprintCallable)
// Parameters:
// struct FAnimNodeReference      Node_69                        (ConstParm, Parm, OutParm, ReferenceParm)
// EAnimNodeReferenceConversionResult Result_69                      (Parm, OutParm, ZeroConstructor, IsPlainOldData)
// struct FSkeletalControlReference ReturnValue_69                 (Parm, OutParm, ReturnParm)

struct FSkeletalControlReference SkeletalControlLibrary::STATIC_ConvertToSkeletalControl(const struct FAnimNodeReference& Node_69, EAnimNodeReferenceConversionResult* Result_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AnimGraphRuntime.SkeletalControlLibrary.ConvertToSkeletalControl"));

	SkeletalControlLibrary_ConvertToSkeletalControl_Params params;
	params.Node_69 = Node_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (Result_69 != nullptr)
		*Result_69 = params.Result_69;

	return params.ReturnValue_69;
}


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

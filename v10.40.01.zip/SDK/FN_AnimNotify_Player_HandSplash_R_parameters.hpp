#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function AnimNotify_Player_HandSplash_R.AnimNotify_Player_HandSplash_R_C.Received_Notify
struct AnimNotify_Player_HandSplash_R_C_Received_Notify_Params
{
	class SkeletalMeshComponent*                       MeshComp_1;                                               // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, InstancedReference)
	class AnimSequenceBase*                            Animation_1;                                              // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor)
	struct FAnimNotifyEventReference                   EventReference_1;                                         // (ConstParm, BlueprintVisible, BlueprintReadOnly, Parm, OutParm, ReferenceParm)
	bool                                               ReturnValue_1;                                            // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

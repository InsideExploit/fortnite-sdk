#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Enums
//---------------------------------------------------------------------------

// Enum CommonUILegacy.EOperation
enum class EOperation : uint8_t
{
	Intro                          = 0,
	Outro                          = 1,
	Push                           = 2,
	Pop                            = 3,
	Invalid                        = 4,
	EOperation_MAX                 = 5
};


// Enum CommonUILegacy.ECommonPlatformType
enum class ECommonPlatformType : uint8_t
{
	PC                             = 0,
	Mac                            = 1,
	PS4                            = 2,
	XBox                           = 3,
	IOS                            = 4,
	Android                        = 5,
	Switch                         = 6,
	XSX                            = 7,
	PS5                            = 8,
	Count                          = 9,
	ECommonPlatformType_MAX        = 10
};


// Enum CommonUILegacy.ECommonGamepadType
enum class ECommonGamepadType : uint8_t
{
	XboxOneController              = 0,
	PS4Controller                  = 1,
	SwitchController               = 2,
	GenericController              = 3,
	XboxSeriesXController          = 4,
	PS5Controller                  = 5,
	Count                          = 6,
	ECommonGamepadType_MAX         = 7
};



//---------------------------------------------------------------------------
//Script Structs
//---------------------------------------------------------------------------

// ScriptStruct CommonUILegacy.Operation
// 0x0028
struct FOperation
{
	EOperation                                         Operation_69;                                             // 0x0000(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0001(0x0007) MISSED OFFSET
	class CommonActivatablePanelLegacy*                Panel_69;                                                 // 0x0008(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	bool                                               bIntroPanel_69;                                           // 0x0010(0x0001) (ZeroConstructor, IsPlainOldData)
	bool                                               bActivatePanel_69;                                        // 0x0011(0x0001) (ZeroConstructor, IsPlainOldData)
	bool                                               bOutroPanelBelow_69;                                      // 0x0012(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x15];                                      // 0x0013(0x0015) MISSED OFFSET
};

// ScriptStruct CommonUILegacy.CommonInputActionData
// 0x0590 (0x08C0 - 0x0330)
struct FCommonInputActionData : public FCommonInputActionDataBase
{
	TMap<ECommonGamepadType, struct FCommonInputTypeInfo> GamepadInputTypeInfoOverrides_69;                         // 0x0330(0x0050) (Edit)
	struct FCommonInputTypeInfo                        GamepadInputTypeInfos_69[0x6];                            // 0x0380(0x00E0) (Deprecated)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

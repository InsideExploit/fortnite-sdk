#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Classes
//---------------------------------------------------------------------------

// Class CreativeVideoPlayerRuntime.CreativeVideoPlayerFullscreenGameplayAbility
// 0x0068 (0x0B88 - 0x0B20)
class CreativeVideoPlayerFullscreenGameplayAbility : public FortGameplayAbility
{
public:
	class GameplayEffect*                              NoCollisionGameplayEffectClass_69;                        // 0x0B20(0x0008) (Edit, ZeroConstructor, DisableEditOnInstance)
	class GameplayEffect*                              NoDamageGameplayEffectClass_69;                           // 0x0B28(0x0008) (Edit, ZeroConstructor, DisableEditOnInstance)
	TArray<class GameplayEffect*>                      AnimationStateGameplayEffectClasses_69;                   // 0x0B30(0x0010) (Edit, ZeroConstructor, DisableEditOnInstance)
	class UserWidget*                                  FullscreenWidgetClass_69;                                 // 0x0B40(0x0008) (Edit, ZeroConstructor, DisableEditOnInstance)
	ECreativeVideoPlayerFullscreenEffects              FullscreenEffects_69;                                     // 0x0B48(0x0001) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	bool                                               bPromptToConfirmFullscreen_69;                            // 0x0B49(0x0001) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData00[0x6];                                       // 0x0B4A(0x0006) MISSED OFFSET
	class FortInputComponent*                          OverrideMovementInputComponent_69;                        // 0x0B50(0x0008) (ExportObject, ZeroConstructor, Transient, InstancedReference)
	class FortInputComponent*                          SelectFullscreenModeInputComponent_69;                    // 0x0B58(0x0008) (ExportObject, ZeroConstructor, Transient, InstancedReference)
	TArray<struct FActiveGameplayEffectHandle>         ActiveGameplayEffects_69;                                 // 0x0B60(0x0010) (ZeroConstructor, Transient)
	ECreativeVideoPlayerFullscreenEffects              RequestedFullscreenEffects_69;                            // 0x0B70(0x0001) (ZeroConstructor, Transient, IsPlainOldData)
	unsigned char                                      UnknownData01[0x7];                                       // 0x0B71(0x0007) MISSED OFFSET
	class UserWidget*                                  VideoPlayerWidget_69;                                     // 0x0B78(0x0008) (ExportObject, ZeroConstructor, Transient, InstancedReference)
	bool                                               bActivatedFullscreen_69;                                  // 0x0B80(0x0001) (ZeroConstructor, Transient, IsPlainOldData)
	unsigned char                                      UnknownData02[0x7];                                       // 0x0B81(0x0007) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CreativeVideoPlayerRuntime.CreativeVideoPlayerFullscreenGameplayAbility"));
		
		return ptr;
	}


	void ServerLeaveFullscreenMode();
	void ServerEnterFullscreenMode();
	void OnFullscreenUIEnds();
	void HandleEnterFullscreenActionReleased();
	void HandleEnterFullscreenActionPressed();
	void ExitFullscreenState();
	void EnterFullscreenStateWithOptions(const struct FCreativeVideoPlayerFullscreenOptions& Options_69);
	void EnterFullscreenState();
	void ClientTransitionToFullscreenVideo();
	void ClientLeaveFullscreenVideo();
};


// Class CreativeVideoPlayerRuntime.CreativeVideoPlayerFunctionLibrary
// 0x0000 (0x0028 - 0x0028)
class CreativeVideoPlayerFunctionLibrary : public BlueprintFunctionLibrary
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CreativeVideoPlayerRuntime.CreativeVideoPlayerFunctionLibrary"));
		
		return ptr;
	}


	void STATIC_ShutdownFullscreenVideoMode(class Controller* Controller_69);
};


// Class CreativeVideoPlayerRuntime.CreativeVideoPlayerWorldSubsystem
// 0x0010 (0x0040 - 0x0030)
class CreativeVideoPlayerWorldSubsystem : public WorldSubsystem
{
public:
	unsigned char                                      UnknownData00[0x10];                                      // 0x0030(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty CreativeVideoPlayerRuntime.CreativeVideoPlayerWorldSubsystem.OnNotifyFullscreenChange_69

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CreativeVideoPlayerRuntime.CreativeVideoPlayerWorldSubsystem"));
		
		return ptr;
	}

};


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function DaySequence.DaySequenceActor.SetTimeOfDay
struct DaySequenceActor_SetTimeOfDay_Params
{
	float                                              InHours_69;                                               // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function DaySequence.DaySequenceActor.SetReplicatePlayback
struct DaySequenceActor_SetReplicatePlayback_Params
{
	bool                                               ReplicatePlayback_69;                                     // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function DaySequence.DaySequenceActor.SetDaySequence
struct DaySequenceActor_SetDaySequence_Params
{
	int                                                Index_69;                                                 // (Parm, ZeroConstructor, IsPlainOldData)
	class DaySequence*                                 InSequence_69;                                            // (Parm, ZeroConstructor)
};

// Function DaySequence.DaySequenceActor.SetBias
struct DaySequenceActor_SetBias_Params
{
	struct FString                                     SequenceKey_69;                                           // (Parm, ZeroConstructor)
	int                                                Bias_69;                                                  // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function DaySequence.DaySequenceActor.RemoveDaySequence
struct DaySequenceActor_RemoveDaySequence_Params
{
	int                                                Index_69;                                                 // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function DaySequence.DaySequenceActor.Play
struct DaySequenceActor_Play_Params
{
};

// Function DaySequence.DaySequenceActor.Pause
struct DaySequenceActor_Pause_Params
{
};

// Function DaySequence.DaySequenceActor.NumDaySequences
struct DaySequenceActor_NumDaySequences_Params
{
	int                                                ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function DaySequence.DaySequenceActor.MuteSequence
struct DaySequenceActor_MuteSequence_Params
{
	struct FString                                     SequenceKey_69;                                           // (Parm, ZeroConstructor)
	bool                                               bState_69;                                                // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function DaySequence.DaySequenceActor.IsPlaying
struct DaySequenceActor_IsPlaying_Params
{
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function DaySequence.DaySequenceActor.IsPaused
struct DaySequenceActor_IsPaused_Params
{
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function DaySequence.DaySequenceActor.IsMuteSequence
struct DaySequenceActor_IsMuteSequence_Params
{
	struct FString                                     SequenceKey_69;                                           // (Parm, ZeroConstructor)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function DaySequence.DaySequenceActor.GetTimePerCycle
struct DaySequenceActor_GetTimePerCycle_Params
{
	float                                              ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function DaySequence.DaySequenceActor.GetTimeOfDay
struct DaySequenceActor_GetTimeOfDay_Params
{
	float                                              ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function DaySequence.DaySequenceActor.GetSequencePlayer
struct DaySequenceActor_GetSequencePlayer_Params
{
	class DaySequencePlayer*                           ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function DaySequence.DaySequenceActor.GetInitialTimeOfDay
struct DaySequenceActor_GetInitialTimeOfDay_Params
{
	float                                              ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function DaySequence.DaySequenceActor.GetFirstDaySequence
struct DaySequenceActor_GetFirstDaySequence_Params
{
	class DaySequence*                                 ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function DaySequence.DaySequenceActor.GetDaySequence
struct DaySequenceActor_GetDaySequence_Params
{
	int                                                Index_69;                                                 // (Parm, ZeroConstructor, IsPlainOldData)
	class DaySequence*                                 ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function DaySequence.DaySequenceActor.GetDayLength
struct DaySequenceActor_GetDayLength_Params
{
	float                                              ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function DaySequence.DaySequenceActor.GetBias
struct DaySequenceActor_GetBias_Params
{
	struct FString                                     SequenceKey_69;                                           // (Parm, ZeroConstructor)
	int                                                ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function DaySequence.DaySequenceActor.AddDaySequence
struct DaySequenceActor_AddDaySequence_Params
{
	class DaySequence*                                 InSequence_69;                                            // (Parm, ZeroConstructor)
	int                                                ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function DaySequence.DaySequenceDirector.OnCreated
struct DaySequenceDirector_OnCreated_Params
{
};

// Function DaySequence.DaySequenceDirector.GetSequence
struct DaySequenceDirector_GetSequence_Params
{
	class MovieSceneSequence*                          ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function DaySequence.DaySequenceDirector.GetMasterSequenceTime
struct DaySequenceDirector_GetMasterSequenceTime_Params
{
	struct FQualifiedFrameTime                         ReturnValue_69;                                           // (Parm, OutParm, ReturnParm)
};

// Function DaySequence.DaySequenceDirector.GetCurrentTime
struct DaySequenceDirector_GetCurrentTime_Params
{
	struct FQualifiedFrameTime                         ReturnValue_69;                                           // (Parm, OutParm, ReturnParm)
};

// Function DaySequence.DaySequenceDirector.GetBoundObjects
struct DaySequenceDirector_GetBoundObjects_Params
{
	struct FMovieSceneObjectBindingID                  ObjectBinding_69;                                         // (Parm)
	TArray<class Object_32759*>                        ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function DaySequence.DaySequenceDirector.GetBoundObject
struct DaySequenceDirector_GetBoundObject_Params
{
	struct FMovieSceneObjectBindingID                  ObjectBinding_69;                                         // (Parm)
	class Object_32759*                                ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function DaySequence.DaySequenceDirector.GetBoundActors
struct DaySequenceDirector_GetBoundActors_Params
{
	struct FMovieSceneObjectBindingID                  ObjectBinding_69;                                         // (Parm)
	TArray<class Actor_32759*>                         ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function DaySequence.DaySequenceDirector.GetBoundActor
struct DaySequenceDirector_GetBoundActor_Params
{
	struct FMovieSceneObjectBindingID                  ObjectBinding_69;                                         // (Parm)
	class Actor_32759*                                 ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function DaySequence.DaySequencePlayer.CreateDaySequencePlayer
struct DaySequencePlayer_CreateDaySequencePlayer_Params
{
	class Object_32759*                                WorldContextObject_69;                                    // (Parm, ZeroConstructor)
	class DaySequence*                                 InDaySequence_69;                                         // (Parm, ZeroConstructor)
	struct FMovieSceneSequencePlaybackSettings         Settings_69;                                              // (Parm)
	class DaySequenceActor*                            OutActor_69;                                              // (Parm, OutParm, ZeroConstructor)
	class DaySequencePlayer*                           ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function DaySequence.DaySequenceSubsystem.GetDaySequenceActor
struct DaySequenceSubsystem_GetDaySequenceActor_Params
{
	class DaySequenceActor*                            ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

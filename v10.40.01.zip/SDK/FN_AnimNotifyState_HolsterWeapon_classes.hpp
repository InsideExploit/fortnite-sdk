#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Classes
//---------------------------------------------------------------------------

// BlueprintGeneratedClass AnimNotifyState_HolsterWeapon.AnimNotifyState_HolsterWeapon_C
// 0x0008 (0x0038 - 0x0030)
class AnimNotifyState_HolsterWeapon_C : public AnimNotifyState
{
public:
	bool                                               PlayEquipAnim_2097153;                                    // 0x0030(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               Force_2097153;                                            // 0x0031(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x2];                                       // 0x0032(0x0002) MISSED OFFSET
	struct FName                                       AnimNotifyStateHolster_2097153;                           // 0x0034(0x0008) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("BlueprintGeneratedClass AnimNotifyState_HolsterWeapon.AnimNotifyState_HolsterWeapon_C"));
		
		return ptr;
	}


	bool Received_NotifyEnd(class SkeletalMeshComponent* MeshComp_1, class AnimSequenceBase* Animation_1, const struct FAnimNotifyEventReference& EventReference_1);
	bool Received_NotifyBegin(class SkeletalMeshComponent* MeshComp_1, class AnimSequenceBase* Animation_1, float TotalDuration_1, const struct FAnimNotifyEventReference& EventReference_1);
};


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

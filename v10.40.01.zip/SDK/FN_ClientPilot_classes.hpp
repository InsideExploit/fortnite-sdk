#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Classes
//---------------------------------------------------------------------------

// Class ClientPilot.ClientPilotBlackboard
// 0x0050 (0x0078 - 0x0028)
class ClientPilotBlackboard : public Object_32759
{
public:
	unsigned char                                      UnknownData00[0x50];                                      // 0x0028(0x0050) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class ClientPilot.ClientPilotBlackboard"));
		
		return ptr;
	}

};


// Class ClientPilot.ClientPilotComponent
// 0x0000 (0x0028 - 0x0028)
class ClientPilotComponent : public Object_32759
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class ClientPilot.ClientPilotComponent"));
		
		return ptr;
	}

};


// Class ClientPilot.ClientPilotBlackboardManager
// 0x0008 (0x0030 - 0x0028)
class ClientPilotBlackboardManager : public Object_32759
{
public:
	class ClientPilotBlackboard*                       PilotBlackboard_69;                                       // 0x0028(0x0008) (ZeroConstructor)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class ClientPilot.ClientPilotBlackboardManager"));
		
		return ptr;
	}

};


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

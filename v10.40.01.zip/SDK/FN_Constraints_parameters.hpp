#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function Constraints.ConstraintsScriptingLibrary.RemoveConstraint
struct ConstraintsScriptingLibrary_RemoveConstraint_Params
{
	class World*                                       InWorld_69;                                               // (Parm, ZeroConstructor)
	int                                                InIndex_69;                                               // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Constraints.ConstraintsScriptingLibrary.GetManager
struct ConstraintsScriptingLibrary_GetManager_Params
{
	class World*                                       InWorld_69;                                               // (Parm, ZeroConstructor)
	class ConstraintsManager*                          ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function Constraints.ConstraintsScriptingLibrary.CreateTransformableComponentHandle
struct ConstraintsScriptingLibrary_CreateTransformableComponentHandle_Params
{
	class World*                                       InWorld_69;                                               // (Parm, ZeroConstructor)
	class SceneComponent*                              InSceneComponent_69;                                      // (Parm, ZeroConstructor, InstancedReference)
	struct FName                                       InSocketName_69;                                          // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
	class TransformableComponentHandle*                ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function Constraints.ConstraintsScriptingLibrary.CreateFromType
struct ConstraintsScriptingLibrary_CreateFromType_Params
{
	class World*                                       InWorld_69;                                               // (Parm, ZeroConstructor)
	ETransformConstraintType                           InType_69;                                                // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	class TickableTransformConstraint*                 ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function Constraints.ConstraintsScriptingLibrary.AddConstraint
struct ConstraintsScriptingLibrary_AddConstraint_Params
{
	class World*                                       InWorld_69;                                               // (Parm, ZeroConstructor)
	class TransformableHandle*                         InParentHandle_69;                                        // (Parm, ZeroConstructor)
	class TransformableHandle*                         InChildHandle_69;                                         // (Parm, ZeroConstructor)
	class TickableTransformConstraint*                 InConstraint_69;                                          // (Parm, ZeroConstructor)
	bool                                               bMaintainOffset_69;                                       // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

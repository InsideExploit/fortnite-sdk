#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Classes
//---------------------------------------------------------------------------

// Class CinematicCamera.CineCameraActor
// 0x0080 (0x0A10 - 0x0990)
class CineCameraActor : public CameraActor
{
public:
	struct FCameraLookatTrackingSettings               LookatTrackingSettings_69;                                // 0x0990(0x0068) (Edit, BlueprintVisible)
	unsigned char                                      UnknownData00[0x18];                                      // 0x09F8(0x0018) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CinematicCamera.CineCameraActor"));
		
		return ptr;
	}


	class CineCameraComponent* GetCineCameraComponent();
};


// Class CinematicCamera.CineCameraComponent
// 0x0110 (0x0B40 - 0x0A30)
class CineCameraComponent : public CameraComponent
{
public:
	struct FCameraFilmbackSettings                     FilmbackSettings_69;                                      // 0x0A30(0x000C) (Deprecated)
	struct FCameraFilmbackSettings                     Filmback_69;                                              // 0x0A3C(0x000C) (Edit, BlueprintVisible)
	struct FCameraLensSettings                         LensSettings_69;                                          // 0x0A48(0x0018) (Edit, BlueprintVisible)
	struct FCameraFocusSettings                        FocusSettings_69;                                         // 0x0A60(0x0060) (Edit, BlueprintVisible)
	float                                              CurrentFocalLength_69;                                    // 0x0AC0(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              CurrentAperture_69;                                       // 0x0AC4(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              CurrentFocusDistance_69;                                  // 0x0AC8(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, EditConst, IsPlainOldData)
	unsigned char                                      bOverride_CustomNearClippingPlane_69 : 1;                 // 0x0ACC(0x0001) (Edit)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0ACD(0x0003) MISSED OFFSET
	float                                              CustomNearClippingPlane_69;                               // 0x0AD0(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0xC];                                       // 0x0AD4(0x000C) MISSED OFFSET
	TArray<struct FNamedFilmbackPreset>                FilmbackPresets_69;                                       // 0x0AE0(0x0010) (ZeroConstructor, Config)
	TArray<struct FNamedLensPreset>                    LensPresets_69;                                           // 0x0AF0(0x0010) (ZeroConstructor, Config)
	struct FString                                     DefaultFilmbackPresetName_69;                             // 0x0B00(0x0010) (ZeroConstructor, Config, Deprecated)
	struct FString                                     DefaultFilmbackPreset_69;                                 // 0x0B10(0x0010) (ZeroConstructor, Config)
	struct FString                                     DefaultLensPresetName_69;                                 // 0x0B20(0x0010) (ZeroConstructor, Config)
	float                                              DefaultLensFocalLength_69;                                // 0x0B30(0x0004) (ZeroConstructor, Config, IsPlainOldData)
	float                                              DefaultLensFStop_69;                                      // 0x0B34(0x0004) (ZeroConstructor, Config, IsPlainOldData)
	unsigned char                                      UnknownData02[0x8];                                       // 0x0B38(0x0008) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CinematicCamera.CineCameraComponent"));
		
		return ptr;
	}


	void SetLensPresetByName(const struct FString& InPresetName_69);
	void SetFilmbackPresetByName(const struct FString& InPresetName_69);
	void SetCurrentFocalLength(float InFocalLength_69);
	float GetVerticalFieldOfView();
	TArray<struct FNamedLensPreset> STATIC_GetLensPresetsCopy();
	struct FString GetLensPresetName();
	float GetHorizontalFieldOfView();
	TArray<struct FNamedFilmbackPreset> STATIC_GetFilmbackPresetsCopy();
	struct FString GetFilmbackPresetName();
	struct FString GetDefaultFilmbackPresetName();
};


// Class CinematicCamera.CameraRig_Crane
// 0x0030 (0x02B8 - 0x0288)
class CameraRig_Crane : public Actor_32759
{
public:
	float                                              CranePitch_69;                                            // 0x0288(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              CraneYaw_69;                                              // 0x028C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              CraneArmLength_69;                                        // 0x0290(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bLockMountPitch_69;                                       // 0x0294(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bLockMountYaw_69;                                         // 0x0295(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x2];                                       // 0x0296(0x0002) MISSED OFFSET
	class SceneComponent*                              TransformComponent_69;                                    // 0x0298(0x0008) (Edit, ExportObject, ZeroConstructor, DisableEditOnInstance, InstancedReference)
	class SceneComponent*                              CraneYawControl_69;                                       // 0x02A0(0x0008) (Edit, ExportObject, ZeroConstructor, DisableEditOnInstance, InstancedReference)
	class SceneComponent*                              CranePitchControl_69;                                     // 0x02A8(0x0008) (Edit, ExportObject, ZeroConstructor, DisableEditOnInstance, InstancedReference)
	class SceneComponent*                              CraneCameraMount_69;                                      // 0x02B0(0x0008) (Edit, ExportObject, ZeroConstructor, DisableEditOnInstance, InstancedReference)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CinematicCamera.CameraRig_Crane"));
		
		return ptr;
	}

};


// Class CinematicCamera.CameraRig_Rail
// 0x0020 (0x02A8 - 0x0288)
class CameraRig_Rail : public Actor_32759
{
public:
	float                                              CurrentPositionOnRail_69;                                 // 0x0288(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bLockOrientationToRail_69;                                // 0x028C(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x028D(0x0003) MISSED OFFSET
	class SceneComponent*                              TransformComponent_69;                                    // 0x0290(0x0008) (Edit, ExportObject, ZeroConstructor, DisableEditOnInstance, InstancedReference)
	class SplineComponent*                             RailSplineComponent_69;                                   // 0x0298(0x0008) (Edit, ExportObject, ZeroConstructor, DisableEditOnInstance, InstancedReference)
	class SceneComponent*                              RailCameraMount_69;                                       // 0x02A0(0x0008) (Edit, ExportObject, ZeroConstructor, DisableEditOnInstance, InstancedReference)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CinematicCamera.CameraRig_Rail"));
		
		return ptr;
	}


	class SplineComponent* GetRailSplineComponent();
};


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

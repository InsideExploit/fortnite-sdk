// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Functions
//---------------------------------------------------------------------------

// Function CorruptionGameplayCodeRuntime.WarEffortFundingLibrary.WriteTextToBuffer
// (Final, Native, Static, Public, HasOutParms, BlueprintCallable, BlueprintPure)
// Parameters:
// struct FText                   Text_69                        (ConstParm, Parm, OutParm, ReferenceParm)
// struct FString                 ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString WarEffortFundingLibrary::STATIC_WriteTextToBuffer(const struct FText& Text_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CorruptionGameplayCodeRuntime.WarEffortFundingLibrary.WriteTextToBuffer"));

	WarEffortFundingLibrary_WriteTextToBuffer_Params params;
	params.Text_69 = Text_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CorruptionGameplayCodeRuntime.WarEffortFundingLibrary.IsOption2ChoiceWinner
// (Final, Native, Static, Public, HasOutParms, BlueprintCallable, BlueprintPure)
// Parameters:
// struct FWarEffortFundingMetadata MetaData_69                    (ConstParm, Parm, OutParm, ReferenceParm)
// int                            ChoiceIndex_69                 (Parm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool WarEffortFundingLibrary::STATIC_IsOption2ChoiceWinner(const struct FWarEffortFundingMetadata& MetaData_69, int ChoiceIndex_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CorruptionGameplayCodeRuntime.WarEffortFundingLibrary.IsOption2ChoiceWinner"));

	WarEffortFundingLibrary_IsOption2ChoiceWinner_Params params;
	params.MetaData_69 = MetaData_69;
	params.ChoiceIndex_69 = ChoiceIndex_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CorruptionGameplayCodeRuntime.WarEffortFundingLibrary.IsOption1ChoiceWinner
// (Final, Native, Static, Public, HasOutParms, BlueprintCallable, BlueprintPure)
// Parameters:
// struct FWarEffortFundingMetadata MetaData_69                    (ConstParm, Parm, OutParm, ReferenceParm)
// int                            ChoiceIndex_69                 (Parm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool WarEffortFundingLibrary::STATIC_IsOption1ChoiceWinner(const struct FWarEffortFundingMetadata& MetaData_69, int ChoiceIndex_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CorruptionGameplayCodeRuntime.WarEffortFundingLibrary.IsOption1ChoiceWinner"));

	WarEffortFundingLibrary_IsOption1ChoiceWinner_Params params;
	params.MetaData_69 = MetaData_69;
	params.ChoiceIndex_69 = ChoiceIndex_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CorruptionGameplayCodeRuntime.WarEffortFundingLibrary.IsIndexFunded
// (Final, Native, Static, Public, HasOutParms, BlueprintCallable, BlueprintPure)
// Parameters:
// struct FWarEffortFundingMetadata MetaData_69                    (ConstParm, Parm, OutParm, ReferenceParm)
// int                            Index_69                       (Parm, ZeroConstructor, IsPlainOldData)
// TEnumAsByte<EWarEffortFundingStationType> StationType_69                 (Parm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool WarEffortFundingLibrary::STATIC_IsIndexFunded(const struct FWarEffortFundingMetadata& MetaData_69, int Index_69, TEnumAsByte<EWarEffortFundingStationType> StationType_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CorruptionGameplayCodeRuntime.WarEffortFundingLibrary.IsIndexFunded"));

	WarEffortFundingLibrary_IsIndexFunded_Params params;
	params.MetaData_69 = MetaData_69;
	params.Index_69 = Index_69;
	params.StationType_69 = StationType_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CorruptionGameplayCodeRuntime.WarEffortFundingLibrary.GetIndexFundedPercent
// (Final, Native, Static, Public, HasOutParms, BlueprintCallable, BlueprintPure)
// Parameters:
// struct FWarEffortFundingMetadata MetaData_69                    (ConstParm, Parm, OutParm, ReferenceParm)
// int                            Index_69                       (Parm, ZeroConstructor, IsPlainOldData)
// TEnumAsByte<EWarEffortFundingStationType> StationType_69                 (Parm, ZeroConstructor, IsPlainOldData)
// float                          ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

float WarEffortFundingLibrary::STATIC_GetIndexFundedPercent(const struct FWarEffortFundingMetadata& MetaData_69, int Index_69, TEnumAsByte<EWarEffortFundingStationType> StationType_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CorruptionGameplayCodeRuntime.WarEffortFundingLibrary.GetIndexFundedPercent"));

	WarEffortFundingLibrary_GetIndexFundedPercent_Params params;
	params.MetaData_69 = MetaData_69;
	params.Index_69 = Index_69;
	params.StationType_69 = StationType_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CorruptionGameplayCodeRuntime.WarEffortFundingLibrary.DoesChoiceHaveWinner
// (Final, Native, Static, Public, HasOutParms, BlueprintCallable, BlueprintPure)
// Parameters:
// struct FWarEffortFundingMetadata MetaData_69                    (ConstParm, Parm, OutParm, ReferenceParm)
// int                            ChoiceIndex_69                 (Parm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool WarEffortFundingLibrary::STATIC_DoesChoiceHaveWinner(const struct FWarEffortFundingMetadata& MetaData_69, int ChoiceIndex_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CorruptionGameplayCodeRuntime.WarEffortFundingLibrary.DoesChoiceHaveWinner"));

	WarEffortFundingLibrary_DoesChoiceHaveWinner_Params params;
	params.MetaData_69 = MetaData_69;
	params.ChoiceIndex_69 = ChoiceIndex_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CorruptionGameplayCodeRuntime.WarEffortFundingLibrary.AdjustDonation
// (Final, Native, Static, Public, BlueprintCallable, BlueprintPure)
// Parameters:
// int                            DonationAmount_69              (Parm, ZeroConstructor, IsPlainOldData)
// TEnumAsByte<EWarEffortFundingStationType> StationType_69                 (Parm, ZeroConstructor, IsPlainOldData)
// int                            ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int WarEffortFundingLibrary::STATIC_AdjustDonation(int DonationAmount_69, TEnumAsByte<EWarEffortFundingStationType> StationType_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CorruptionGameplayCodeRuntime.WarEffortFundingLibrary.AdjustDonation"));

	WarEffortFundingLibrary_AdjustDonation_Params params;
	params.DonationAmount_69 = DonationAmount_69;
	params.StationType_69 = StationType_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CorruptionGameplayCodeRuntime.CorruptionCoverageMap.UpdateCorruptionCoverageMap
// (Final, Native, Private, HasOutParms, HasDefaults, BlueprintCallable)
// Parameters:
// class Object_32759*            WorldContextObject_69          (Parm, ZeroConstructor)
// class TextureRenderTarget2D*   CorruptionRenderTarget_69      (Parm, ZeroConstructor)
// struct FVector                 InTopLeftWorldCoordinate_69    (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
// struct FVector                 InBottomRightWorldCoordinate_69 (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
// float                          CoverageThreshold_69           (Parm, ZeroConstructor, IsPlainOldData)
// float                          DebugDrawDuration_69           (Parm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool CorruptionCoverageMap::UpdateCorruptionCoverageMap(class Object_32759* WorldContextObject_69, class TextureRenderTarget2D* CorruptionRenderTarget_69, const struct FVector& InTopLeftWorldCoordinate_69, const struct FVector& InBottomRightWorldCoordinate_69, float CoverageThreshold_69, float DebugDrawDuration_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CorruptionGameplayCodeRuntime.CorruptionCoverageMap.UpdateCorruptionCoverageMap"));

	CorruptionCoverageMap_UpdateCorruptionCoverageMap_Params params;
	params.WorldContextObject_69 = WorldContextObject_69;
	params.CorruptionRenderTarget_69 = CorruptionRenderTarget_69;
	params.InTopLeftWorldCoordinate_69 = InTopLeftWorldCoordinate_69;
	params.InBottomRightWorldCoordinate_69 = InBottomRightWorldCoordinate_69;
	params.CoverageThreshold_69 = CoverageThreshold_69;
	params.DebugDrawDuration_69 = DebugDrawDuration_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CorruptionGameplayCodeRuntime.CorruptionCoverageMap.IsLocationCorrupted
// (Final, Native, Private, HasOutParms, HasDefaults, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FVector                 Location_69                    (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
// float                          Padding_69                     (Parm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool CorruptionCoverageMap::IsLocationCorrupted(const struct FVector& Location_69, float Padding_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CorruptionGameplayCodeRuntime.CorruptionCoverageMap.IsLocationCorrupted"));

	CorruptionCoverageMap_IsLocationCorrupted_Params params;
	params.Location_69 = Location_69;
	params.Padding_69 = Padding_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CorruptionGameplayCodeRuntime.CubeMovementStaticPath.EditorGetCorruptionGenerationData
// (Final, Native, Public, HasOutParms, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FCubeMovement_CorruptionGenerationData OutData_69                     (Parm, OutParm)

void CubeMovementStaticPath::EditorGetCorruptionGenerationData(struct FCubeMovement_CorruptionGenerationData* OutData_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CorruptionGameplayCodeRuntime.CubeMovementStaticPath.EditorGetCorruptionGenerationData"));

	CubeMovementStaticPath_EditorGetCorruptionGenerationData_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (OutData_69 != nullptr)
		*OutData_69 = params.OutData_69;
}


// Function CorruptionGameplayCodeRuntime.CubeMovementStaticPath.ClearAllGeneratedSplinesAndLockedData
// (Final, Native, Protected)

void CubeMovementStaticPath::ClearAllGeneratedSplinesAndLockedData()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CorruptionGameplayCodeRuntime.CubeMovementStaticPath.ClearAllGeneratedSplinesAndLockedData"));

	CubeMovementStaticPath_ClearAllGeneratedSplinesAndLockedData_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CorruptionGameplayCodeRuntime.FortAthenaMutator_WarEffort.SetTryBeforeYouBuyItemState
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// struct FGameplayTag            ItemFundingTag_69              (Parm)
// bool                           bIsActive_69                   (Parm, ZeroConstructor, IsPlainOldData)

void FortAthenaMutator_WarEffort::SetTryBeforeYouBuyItemState(const struct FGameplayTag& ItemFundingTag_69, bool bIsActive_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CorruptionGameplayCodeRuntime.FortAthenaMutator_WarEffort.SetTryBeforeYouBuyItemState"));

	FortAthenaMutator_WarEffort_SetTryBeforeYouBuyItemState_Params params;
	params.ItemFundingTag_69 = ItemFundingTag_69;
	params.bIsActive_69 = bIsActive_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CorruptionGameplayCodeRuntime.FortAthenaMutator_WarEffort.SetItemFundedState
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// struct FGameplayTag            ItemFundingTag_69              (Parm)
// bool                           bIsActive_69                   (Parm, ZeroConstructor, IsPlainOldData)

void FortAthenaMutator_WarEffort::SetItemFundedState(const struct FGameplayTag& ItemFundingTag_69, bool bIsActive_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CorruptionGameplayCodeRuntime.FortAthenaMutator_WarEffort.SetItemFundedState"));

	FortAthenaMutator_WarEffort_SetItemFundedState_Params params;
	params.ItemFundingTag_69 = ItemFundingTag_69;
	params.bIsActive_69 = bIsActive_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CorruptionGameplayCodeRuntime.FortAthenaMutator_WarEffort.SetItemFundedPercent
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// struct FGameplayTag            ItemFundingTag_69              (Parm)
// float                          FundingPercent_69              (Parm, ZeroConstructor, IsPlainOldData)

void FortAthenaMutator_WarEffort::SetItemFundedPercent(const struct FGameplayTag& ItemFundingTag_69, float FundingPercent_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CorruptionGameplayCodeRuntime.FortAthenaMutator_WarEffort.SetItemFundedPercent"));

	FortAthenaMutator_WarEffort_SetItemFundedPercent_Params params;
	params.ItemFundingTag_69 = ItemFundingTag_69;
	params.FundingPercent_69 = FundingPercent_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CorruptionGameplayCodeRuntime.FortAthenaMutator_WarEffort.SetItemFundedAmount
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// struct FGameplayTag            ItemFundingTag_69              (Parm)
// int64_t                        CurrentFundingAmount_69        (Parm, ZeroConstructor, IsPlainOldData)
// int64_t                        TargetFundingAmount_69         (Parm, ZeroConstructor, IsPlainOldData)

void FortAthenaMutator_WarEffort::SetItemFundedAmount(const struct FGameplayTag& ItemFundingTag_69, int64_t CurrentFundingAmount_69, int64_t TargetFundingAmount_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CorruptionGameplayCodeRuntime.FortAthenaMutator_WarEffort.SetItemFundedAmount"));

	FortAthenaMutator_WarEffort_SetItemFundedAmount_Params params;
	params.ItemFundingTag_69 = ItemFundingTag_69;
	params.CurrentFundingAmount_69 = CurrentFundingAmount_69;
	params.TargetFundingAmount_69 = TargetFundingAmount_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CorruptionGameplayCodeRuntime.FortAthenaMutator_WarEffort.SetFundingManagerReady
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// bool                           bIsReady_69                    (Parm, ZeroConstructor, IsPlainOldData)

void FortAthenaMutator_WarEffort::SetFundingManagerReady(bool bIsReady_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CorruptionGameplayCodeRuntime.FortAthenaMutator_WarEffort.SetFundingManagerReady"));

	FortAthenaMutator_WarEffort_SetFundingManagerReady_Params params;
	params.bIsReady_69 = bIsReady_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CorruptionGameplayCodeRuntime.FortAthenaMutator_WarEffort.OnRep_PreloadedItemList
// (Final, Native, Protected)

void FortAthenaMutator_WarEffort::OnRep_PreloadedItemList()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CorruptionGameplayCodeRuntime.FortAthenaMutator_WarEffort.OnRep_PreloadedItemList"));

	FortAthenaMutator_WarEffort_OnRep_PreloadedItemList_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CorruptionGameplayCodeRuntime.WarEffortMeshActor.OnRep_CurrentFundingData
// (Final, Native, Protected)

void WarEffortMeshActor::OnRep_CurrentFundingData()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CorruptionGameplayCodeRuntime.WarEffortMeshActor.OnRep_CurrentFundingData"));

	WarEffortMeshActor_OnRep_CurrentFundingData_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CorruptionGameplayCodeRuntime.WarEffortMeshActor.OnRep_ActiveTryBeforeYouBuyItems
// (Final, Native, Protected)

void WarEffortMeshActor::OnRep_ActiveTryBeforeYouBuyItems()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CorruptionGameplayCodeRuntime.WarEffortMeshActor.OnRep_ActiveTryBeforeYouBuyItems"));

	WarEffortMeshActor_OnRep_ActiveTryBeforeYouBuyItems_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CorruptionGameplayCodeRuntime.WarEffortMeshActor.OnRep_ActiveFundedItems
// (Final, Native, Protected)

void WarEffortMeshActor::OnRep_ActiveFundedItems()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CorruptionGameplayCodeRuntime.WarEffortMeshActor.OnRep_ActiveFundedItems"));

	WarEffortMeshActor_OnRep_ActiveFundedItems_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

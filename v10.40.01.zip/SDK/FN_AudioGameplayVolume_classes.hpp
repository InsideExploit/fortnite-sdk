#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Classes
//---------------------------------------------------------------------------

// Class AudioGameplayVolume.AudioGameplayVolumeMutator
// 0x0008 (0x00B0 - 0x00A8)
class AudioGameplayVolumeMutator : public AudioGameplayComponent
{
public:
	int                                                Priority_69;                                              // 0x00A8(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x00AC(0x0004) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AudioGameplayVolume.AudioGameplayVolumeMutator"));
		
		return ptr;
	}


	void SetPriority(int InPriority_69);
};


// Class AudioGameplayVolume.AttenuationVolumeComponent
// 0x0010 (0x00C0 - 0x00B0)
class AttenuationVolumeComponent : public AudioGameplayVolumeMutator
{
public:
	float                                              ExteriorVolume_69;                                        // 0x00B0(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              ExteriorTime_69;                                          // 0x00B4(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              InteriorVolume_69;                                        // 0x00B8(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              InteriorTime_69;                                          // 0x00BC(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AudioGameplayVolume.AttenuationVolumeComponent"));
		
		return ptr;
	}


	void SetInteriorVolume(float Volume_69, float InterpolateTime_69);
	void SetExteriorVolume(float Volume_69, float InterpolateTime_69);
};


// Class AudioGameplayVolume.AudioGameplayVolume
// 0x0030 (0x02F0 - 0x02C0)
class AudioGameplayVolume : public Volume
{
public:
	class AudioGameplayVolumeComponent*                AGVComponent_69;                                          // 0x02C0(0x0008) (ExportObject, ZeroConstructor, Transient, InstancedReference)
	bool                                               bEnabled_69;                                              // 0x02C8(0x0001) (Edit, BlueprintVisible, Net, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x02C9(0x0007) MISSED OFFSET
	unsigned char                                      UnknownData01[0x10];                                      // 0x02C9(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty AudioGameplayVolume.AudioGameplayVolume.OnListenerEnterEvent_69
	unsigned char                                      UnknownData02[0x10];                                      // 0x02E0(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty AudioGameplayVolume.AudioGameplayVolume.OnListenerExitEvent_69

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AudioGameplayVolume.AudioGameplayVolume"));
		
		return ptr;
	}


	void SetEnabled(bool bEnable_69);
	void OnRep_bEnabled();
	void OnListenerExit();
	void OnListenerEnter();
};


// Class AudioGameplayVolume.AudioGameplayVolumeComponent
// 0x0028 (0x00D0 - 0x00A8)
class AudioGameplayVolumeComponent : public AudioGameplayComponent
{
public:
	unsigned char                                      UnknownData00[0x10];                                      // 0x00A8(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty AudioGameplayVolume.AudioGameplayVolumeComponent.OnProxyEnter_69
	unsigned char                                      UnknownData01[0x10];                                      // 0x00B8(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty AudioGameplayVolume.AudioGameplayVolumeComponent.OnProxyExit_69
	class AudioGameplayVolumeProxy*                    Proxy_69;                                                 // 0x00C8(0x0008) (Edit, BlueprintVisible, ExportObject, ZeroConstructor, InstancedReference)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AudioGameplayVolume.AudioGameplayVolumeComponent"));
		
		return ptr;
	}

};


// Class AudioGameplayVolume.AudioGameplayVolumeComponentBase
// 0x0008 (0x00B0 - 0x00A8)
class AudioGameplayVolumeComponentBase : public AudioGameplayComponent
{
public:
	unsigned char                                      UnknownData00[0x8];                                       // 0x00A8(0x0008) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AudioGameplayVolume.AudioGameplayVolumeComponentBase"));
		
		return ptr;
	}

};


// Class AudioGameplayVolume.AudioGameplayVolumeProxy
// 0x0020 (0x0048 - 0x0028)
class AudioGameplayVolumeProxy : public Object_32759
{
public:
	unsigned char                                      UnknownData00[0x20];                                      // 0x0028(0x0020) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AudioGameplayVolume.AudioGameplayVolumeProxy"));
		
		return ptr;
	}

};


// Class AudioGameplayVolume.AGVPrimitiveComponentProxy
// 0x0008 (0x0050 - 0x0048)
class AGVPrimitiveComponentProxy : public AudioGameplayVolumeProxy
{
public:
	unsigned char                                      UnknownData00[0x8];                                       // 0x0048(0x0008) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AudioGameplayVolume.AGVPrimitiveComponentProxy"));
		
		return ptr;
	}

};


// Class AudioGameplayVolume.AGVConditionProxy
// 0x0008 (0x0050 - 0x0048)
class AGVConditionProxy : public AudioGameplayVolumeProxy
{
public:
	unsigned char                                      UnknownData00[0x8];                                       // 0x0048(0x0008) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AudioGameplayVolume.AGVConditionProxy"));
		
		return ptr;
	}

};


// Class AudioGameplayVolume.AudioGameplayVolumeSubsystem
// 0x0128 (0x0158 - 0x0030)
class AudioGameplayVolumeSubsystem : public AudioEngineSubsystem
{
public:
	unsigned char                                      UnknownData00[0x8];                                       // 0x0030(0x0008) MISSED OFFSET
	TMap<uint32_t, class AudioGameplayVolumeComponent*> AGVComponents_69;                                         // 0x0038(0x0050) (ExportObject, Transient)
	unsigned char                                      UnknownData01[0xD0];                                      // 0x0088(0x00D0) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AudioGameplayVolume.AudioGameplayVolumeSubsystem"));
		
		return ptr;
	}

};


// Class AudioGameplayVolume.FilterVolumeComponent
// 0x0010 (0x00C0 - 0x00B0)
class FilterVolumeComponent : public AudioGameplayVolumeMutator
{
public:
	float                                              ExteriorLPF_69;                                           // 0x00B0(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              ExteriorLPFTime_69;                                       // 0x00B4(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              InteriorLPF_69;                                           // 0x00B8(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              InteriorLPFTime_69;                                       // 0x00BC(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AudioGameplayVolume.FilterVolumeComponent"));
		
		return ptr;
	}


	void SetInteriorLPF(float Volume_69, float InterpolateTime_69);
	void SetExteriorLPF(float Volume_69, float InterpolateTime_69);
};


// Class AudioGameplayVolume.ReverbVolumeComponent
// 0x0020 (0x00D0 - 0x00B0)
class ReverbVolumeComponent : public AudioGameplayVolumeMutator
{
public:
	struct FReverbSettings                             ReverbSettings_69;                                        // 0x00B0(0x0020) (Edit, BlueprintVisible, BlueprintReadOnly)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AudioGameplayVolume.ReverbVolumeComponent"));
		
		return ptr;
	}


	void SetReverbSettings(const struct FReverbSettings& NewReverbSettings_69);
};


// Class AudioGameplayVolume.SubmixOverrideVolumeComponent
// 0x0010 (0x00C0 - 0x00B0)
class SubmixOverrideVolumeComponent : public AudioGameplayVolumeMutator
{
public:
	TArray<struct FAudioVolumeSubmixOverrideSettings>  SubmixOverrideSettings_69;                                // 0x00B0(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AudioGameplayVolume.SubmixOverrideVolumeComponent"));
		
		return ptr;
	}


	void SetSubmixOverrideSettings(TArray<struct FAudioVolumeSubmixOverrideSettings> NewSubmixOverrideSettings_69);
};


// Class AudioGameplayVolume.SubmixSendVolumeComponent
// 0x0010 (0x00C0 - 0x00B0)
class SubmixSendVolumeComponent : public AudioGameplayVolumeMutator
{
public:
	TArray<struct FAudioVolumeSubmixSendSettings>      SubmixSendSettings_69;                                    // 0x00B0(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AudioGameplayVolume.SubmixSendVolumeComponent"));
		
		return ptr;
	}


	void SetSubmixSendSettings(TArray<struct FAudioVolumeSubmixSendSettings> NewSubmixSendSettings_69);
};


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Enums
//---------------------------------------------------------------------------

// Enum DiscoveryBrowserUI.EActivityBrowserTileStyle
enum class EActivityBrowserTileStyle : uint8_t
{
	Default                        = 0,
	Minimal                        = 1,
	Detailed                       = 2,
	EActivityBrowserTileStyle_MAX  = 3
};



//---------------------------------------------------------------------------
//Script Structs
//---------------------------------------------------------------------------

// ScriptStruct DiscoveryBrowserUI.CachedSurfaceData
// 0x0018
struct FCachedSurfaceData
{
	unsigned char                                      UnknownData00[0x8];                                       // 0x0000(0x0008) MISSED OFFSET
	TArray<class FortCreativeDiscoveryActivityProvider*> CachedDataProviders_69;                                   // 0x0008(0x0010) (ZeroConstructor)
};

// ScriptStruct DiscoveryBrowserUI.ColorSchemeParamaterValues
// 0x00A8
struct FColorSchemeParamaterValues
{
	class MaterialParameterCollection*                 AlternateMaterialCollection_69;                           // 0x0000(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
	TMap<struct FName, float>                          ScalarParameterValues_69;                                 // 0x0008(0x0050) (Edit, BlueprintVisible, BlueprintReadOnly)
	TMap<struct FName, struct FLinearColor>            VectorParameterValues_69;                                 // 0x0058(0x0050) (Edit, BlueprintVisible, BlueprintReadOnly)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

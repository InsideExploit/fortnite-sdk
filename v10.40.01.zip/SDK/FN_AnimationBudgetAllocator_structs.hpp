#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Script Structs
//---------------------------------------------------------------------------

// ScriptStruct AnimationBudgetAllocator.AnimationBudgetAllocatorParameters
// 0x0050
struct FAnimationBudgetAllocatorParameters
{
	float                                              BudgetInMs_69;                                            // 0x0000(0x0004) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              MinQuality_69;                                            // 0x0004(0x0004) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                MaxTickRate_69;                                           // 0x0008(0x0004) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              WorkUnitSmoothingSpeed_69;                                // 0x000C(0x0004) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              AlwaysTickFalloffAggression_69;                           // 0x0010(0x0004) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              InterpolationFalloffAggression_69;                        // 0x0014(0x0004) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                InterpolationMaxRate_69;                                  // 0x0018(0x0004) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                MaxInterpolatedComponents_69;                             // 0x001C(0x0004) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              InterpolationTickMultiplier_69;                           // 0x0020(0x0004) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              InitialEstimatedWorkUnitTimeMs_69;                        // 0x0024(0x0004) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                MaxTickedOffsreenComponents_69;                           // 0x0028(0x0004) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                StateChangeThrottleInFrames_69;                           // 0x002C(0x0004) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              BudgetFactorBeforeReducedWork_69;                         // 0x0030(0x0004) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              BudgetFactorBeforeReducedWorkEpsilon_69;                  // 0x0034(0x0004) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              BudgetPressureSmoothingSpeed_69;                          // 0x0038(0x0004) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                ReducedWorkThrottleMinInFrames_69;                        // 0x003C(0x0004) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                ReducedWorkThrottleMaxInFrames_69;                        // 0x0040(0x0004) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              BudgetFactorBeforeAggressiveReducedWork_69;               // 0x0044(0x0004) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                ReducedWorkThrottleMaxPerFrame_69;                        // 0x0048(0x0004) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              BudgetPressureBeforeEmergencyReducedWork_69;              // 0x004C(0x0004) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

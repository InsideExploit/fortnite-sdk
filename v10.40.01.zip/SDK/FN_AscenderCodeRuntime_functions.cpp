// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Functions
//---------------------------------------------------------------------------

// Function AscenderCodeRuntime.FortAscenderZipline.OnRep_TargetSplineEndLocation
// (Final, Native, Protected)

void FortAscenderZipline::OnRep_TargetSplineEndLocation()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AscenderCodeRuntime.FortAscenderZipline.OnRep_TargetSplineEndLocation"));

	FortAscenderZipline_OnRep_TargetSplineEndLocation_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AscenderCodeRuntime.FortAscenderZipline.OnRep_PawnUsingHandle
// (Final, Native, Protected)

void FortAscenderZipline::OnRep_PawnUsingHandle()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AscenderCodeRuntime.FortAscenderZipline.OnRep_PawnUsingHandle"));

	FortAscenderZipline_OnRep_PawnUsingHandle_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AscenderCodeRuntime.FortAscenderZipline.OnRep_InitialSplineEndLocation
// (Final, Native, Protected)

void FortAscenderZipline::OnRep_InitialSplineEndLocation()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AscenderCodeRuntime.FortAscenderZipline.OnRep_InitialSplineEndLocation"));

	FortAscenderZipline_OnRep_InitialSplineEndLocation_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AscenderCodeRuntime.FortAscenderZipline.HandlePawnUsingHandleDied
// (Final, Native, Protected)
// Parameters:
// class FortPawn*                DeadPawn_69                    (Parm, ZeroConstructor)

void FortAscenderZipline::HandlePawnUsingHandleDied(class FortPawn* DeadPawn_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AscenderCodeRuntime.FortAscenderZipline.HandlePawnUsingHandleDied"));

	FortAscenderZipline_HandlePawnUsingHandleDied_Params params;
	params.DeadPawn_69 = DeadPawn_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AscenderCodeRuntime.FortAscenderZipline.HandleFloorActorHealthChanged
// (Final, Native, Protected)

void FortAscenderZipline::HandleFloorActorHealthChanged()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AscenderCodeRuntime.FortAscenderZipline.HandleFloorActorHealthChanged"));

	FortAscenderZipline_HandleFloorActorHealthChanged_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AscenderCodeRuntime.FortAscenderZipline.HandleFloorActorDestroyed
// (Final, Native, Protected)
// Parameters:
// class Actor_32759*             Actor_69                       (Parm, ZeroConstructor)

void FortAscenderZipline::HandleFloorActorDestroyed(class Actor_32759* Actor_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AscenderCodeRuntime.FortAscenderZipline.HandleFloorActorDestroyed"));

	FortAscenderZipline_HandleFloorActorDestroyed_Params params;
	params.Actor_69 = Actor_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AscenderCodeRuntime.FortAscenderZipline.GetTopComponent
// (Event, Public, BlueprintCallable, BlueprintEvent, BlueprintPure, Const)
// Parameters:
// class PrimitiveComponent*      ReturnValue_69                 (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)

class PrimitiveComponent* FortAscenderZipline::GetTopComponent()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AscenderCodeRuntime.FortAscenderZipline.GetTopComponent"));

	FortAscenderZipline_GetTopComponent_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AscenderCodeRuntime.FortAscenderZipline.GetPawnUsingHandle
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// class FortPlayerPawn*          ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

class FortPlayerPawn* FortAscenderZipline::GetPawnUsingHandle()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AscenderCodeRuntime.FortAscenderZipline.GetPawnUsingHandle"));

	FortAscenderZipline_GetPawnUsingHandle_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AscenderCodeRuntime.FortAscenderZipline.GetInteractComponentOverride
// (Native, Event, Public, BlueprintEvent, Const)
// Parameters:
// class FortPlayerPawn*          InteractingPawn_69             (Parm, ZeroConstructor)
// class PrimitiveComponent*      InteractComponent_69           (Parm, ZeroConstructor, InstancedReference)
// class PrimitiveComponent*      ReturnValue_69                 (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)

class PrimitiveComponent* FortAscenderZipline::GetInteractComponentOverride(class FortPlayerPawn* InteractingPawn_69, class PrimitiveComponent* InteractComponent_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AscenderCodeRuntime.FortAscenderZipline.GetInteractComponentOverride"));

	FortAscenderZipline_GetInteractComponentOverride_Params params;
	params.InteractingPawn_69 = InteractingPawn_69;
	params.InteractComponent_69 = InteractComponent_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AscenderCodeRuntime.FortAscenderZipline.GetHandleComponent
// (Event, Public, BlueprintCallable, BlueprintEvent, BlueprintPure, Const)
// Parameters:
// class PrimitiveComponent*      ReturnValue_69                 (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)

class PrimitiveComponent* FortAscenderZipline::GetHandleComponent()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AscenderCodeRuntime.FortAscenderZipline.GetHandleComponent"));

	FortAscenderZipline_GetHandleComponent_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AscenderCodeRuntime.FortAscenderZipline.BP_HandleUpdatedLoweringHandle
// (Event, Public, BlueprintEvent)

void FortAscenderZipline::BP_HandleUpdatedLoweringHandle()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AscenderCodeRuntime.FortAscenderZipline.BP_HandleUpdatedLoweringHandle"));

	FortAscenderZipline_BP_HandleUpdatedLoweringHandle_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AscenderCodeRuntime.FortAscenderZipline.BP_HandleUpdatedLoweringCable
// (Event, Public, BlueprintEvent)

void FortAscenderZipline::BP_HandleUpdatedLoweringCable()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AscenderCodeRuntime.FortAscenderZipline.BP_HandleUpdatedLoweringCable"));

	FortAscenderZipline_BP_HandleUpdatedLoweringCable_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AscenderCodeRuntime.FortAscenderZipline.BP_HandleStoppedLoweringHandle
// (Event, Public, BlueprintEvent)

void FortAscenderZipline::BP_HandleStoppedLoweringHandle()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AscenderCodeRuntime.FortAscenderZipline.BP_HandleStoppedLoweringHandle"));

	FortAscenderZipline_BP_HandleStoppedLoweringHandle_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AscenderCodeRuntime.FortAscenderZipline.BP_HandleStoppedLoweringCable
// (Event, Public, BlueprintEvent)

void FortAscenderZipline::BP_HandleStoppedLoweringCable()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AscenderCodeRuntime.FortAscenderZipline.BP_HandleStoppedLoweringCable"));

	FortAscenderZipline_BP_HandleStoppedLoweringCable_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AscenderCodeRuntime.FortAscenderZipline.BP_HandleStartedLoweringHandle
// (Event, Public, BlueprintEvent)

void FortAscenderZipline::BP_HandleStartedLoweringHandle()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AscenderCodeRuntime.FortAscenderZipline.BP_HandleStartedLoweringHandle"));

	FortAscenderZipline_BP_HandleStartedLoweringHandle_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AscenderCodeRuntime.FortAscenderZipline.BP_HandleStartedLoweringCable
// (Event, Public, BlueprintEvent)

void FortAscenderZipline::BP_HandleStartedLoweringCable()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AscenderCodeRuntime.FortAscenderZipline.BP_HandleStartedLoweringCable"));

	FortAscenderZipline_BP_HandleStartedLoweringCable_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AscenderCodeRuntime.FortAscenderZipline.BP_HandlePlayerStoppedUsingHandle
// (Event, Public, BlueprintEvent)
// Parameters:
// class FortPlayerPawn*          Player_69                      (Parm, ZeroConstructor)

void FortAscenderZipline::BP_HandlePlayerStoppedUsingHandle(class FortPlayerPawn* Player_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AscenderCodeRuntime.FortAscenderZipline.BP_HandlePlayerStoppedUsingHandle"));

	FortAscenderZipline_BP_HandlePlayerStoppedUsingHandle_Params params;
	params.Player_69 = Player_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AscenderCodeRuntime.FortAscenderZipline.BP_HandlePlayerStartedUsingHandle
// (Event, Public, BlueprintEvent)
// Parameters:
// class FortPlayerPawn*          Player_69                      (Parm, ZeroConstructor)

void FortAscenderZipline::BP_HandlePlayerStartedUsingHandle(class FortPlayerPawn* Player_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AscenderCodeRuntime.FortAscenderZipline.BP_HandlePlayerStartedUsingHandle"));

	FortAscenderZipline_BP_HandlePlayerStartedUsingHandle_Params params;
	params.Player_69 = Player_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AscenderCodeRuntime.FortAscenderZipline.ApplyStructureDamage
// (Event, Public, BlueprintCallable, BlueprintEvent, Const)
// Parameters:
// class BuildingSMActor*         BuildingActor_69               (Parm, ZeroConstructor)
// class Actor_32759*             DamageSource_69                (Parm, ZeroConstructor)

void FortAscenderZipline::ApplyStructureDamage(class BuildingSMActor* BuildingActor_69, class Actor_32759* DamageSource_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AscenderCodeRuntime.FortAscenderZipline.ApplyStructureDamage"));

	FortAscenderZipline_ApplyStructureDamage_Params params;
	params.BuildingActor_69 = BuildingActor_69;
	params.DamageSource_69 = DamageSource_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

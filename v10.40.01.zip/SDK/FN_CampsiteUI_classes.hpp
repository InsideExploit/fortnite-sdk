#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Classes
//---------------------------------------------------------------------------

// Class CampsiteUI.CampsiteMarkerInfoBase
// 0x0010 (0x02A0 - 0x0290)
class CampsiteMarkerInfoBase : public CommonUserWidget
{
public:
	TWeakObjectPtr<class FortPlayerStateAthena>        WeakPSA_69;                                               // 0x0290(0x0008) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	class CommonTextBlock*                             Text_PlayerName_69;                                       // 0x0298(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CampsiteUI.CampsiteMarkerInfoBase"));
		
		return ptr;
	}


	void SetPlayerState(class FortPlayerStateAthena* InPlayerState_69);
	void OnSetPlayerState(class FortPlayerStateAthena* PSA_69);
};


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

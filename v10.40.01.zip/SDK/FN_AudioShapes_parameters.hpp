#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function AudioShapes.AudioShapeComponent.UpdateAudioShape
struct AudioShapeComponent_UpdateAudioShape_Params
{
	TArray<class PlayerController*>                    InLocalControllers_69;                                    // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
};

// Function AudioShapes.AudioShapePrimitiveComponent.GetIsPlayerInside
struct AudioShapePrimitiveComponent_GetIsPlayerInside_Params
{
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AudioShapes.AudioShapePrimitiveComponent.GetInsideAudioComponent
struct AudioShapePrimitiveComponent_GetInsideAudioComponent_Params
{
	class AudioComponent*                              ReturnValue_69;                                           // (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)
};

// Function AudioShapes.AudioShapePrimitiveComponent.GetEdgeAudioComponent
struct AudioShapePrimitiveComponent_GetEdgeAudioComponent_Params
{
	class AudioComponent*                              ReturnValue_69;                                           // (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)
};

// Function AudioShapes.AudioShapeBoxComponent.SetBoxTransform
struct AudioShapeBoxComponent_SetBoxTransform_Params
{
	struct FCoreUObject_FTransform                     InTransform_69;                                           // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
};

// Function AudioShapes.AudioShapeCylinderComponent.SetRadius
struct AudioShapeCylinderComponent_SetRadius_Params
{
	float                                              InRadius_69;                                              // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function AudioShapes.AudioShapeCylinderComponent.SetHalfHeight
struct AudioShapeCylinderComponent_SetHalfHeight_Params
{
	float                                              InHalfHeight_69;                                          // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function AudioShapes.AudioShapeLineComponent.SetStartPoint
struct AudioShapeLineComponent_SetStartPoint_Params
{
	struct FVector                                     InStartPoint_69;                                          // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
};

// Function AudioShapes.AudioShapeLineComponent.SetEndPoint
struct AudioShapeLineComponent_SetEndPoint_Params
{
	struct FVector                                     InEndPoint_69;                                            // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
};

// Function AudioShapes.AudioShapeLineListComponent.UpdatePoint
struct AudioShapeLineListComponent_UpdatePoint_Params
{
	int                                                InIndex_69;                                               // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector                                     InPoint_69;                                               // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AudioShapes.AudioShapeLineListComponent.RemovePoint
struct AudioShapeLineListComponent_RemovePoint_Params
{
	int                                                InIndex_69;                                               // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AudioShapes.AudioShapeLineListComponent.GetPoints
struct AudioShapeLineListComponent_GetPoints_Params
{
	TArray<struct FVector>                             OutPoints_69;                                             // (Parm, OutParm, ZeroConstructor)
};

// Function AudioShapes.AudioShapeLineListComponent.AddPoint
struct AudioShapeLineListComponent_AddPoint_Params
{
	struct FVector                                     InPoint_69;                                               // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
	int                                                ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AudioShapes.AudioShapeSphereComponent.SetRadius
struct AudioShapeSphereComponent_SetRadius_Params
{
	float                                              InRadius_69;                                              // (Parm, ZeroConstructor, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

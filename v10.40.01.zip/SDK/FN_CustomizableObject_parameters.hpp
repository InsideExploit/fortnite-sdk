#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function CustomizableObject.CustomizableObject.UnloadMaskOutCache
struct CustomizableObject_UnloadMaskOutCache_Params
{
};

// Function CustomizableObject.CustomizableObject.LoadMaskOutCache
struct CustomizableObject_LoadMaskOutCache_Params
{
};

// Function CustomizableObject.CustomizableObject.IsCompiled
struct CustomizableObject_IsCompiled_Params
{
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CustomizableObject.CustomizableObject.GetStateUIMetadataFromIndex
struct CustomizableObject_GetStateUIMetadataFromIndex_Params
{
	int                                                StateIndex_69;                                            // (Parm, ZeroConstructor, IsPlainOldData)
	struct FParameterUIData                            ReturnValue_69;                                           // (Parm, OutParm, ReturnParm)
};

// Function CustomizableObject.CustomizableObject.GetStateUIMetadata
struct CustomizableObject_GetStateUIMetadata_Params
{
	struct FString                                     StateName_69;                                             // (Parm, ZeroConstructor)
	struct FParameterUIData                            ReturnValue_69;                                           // (Parm, OutParm, ReturnParm)
};

// Function CustomizableObject.CustomizableObject.GetStateParameterName
struct CustomizableObject_GetStateParameterName_Params
{
	struct FString                                     StateName_69;                                             // (Parm, ZeroConstructor)
	int                                                ParameterIndex_69;                                        // (Parm, ZeroConstructor, IsPlainOldData)
	struct FString                                     ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function CustomizableObject.CustomizableObject.GetStateParameterCount
struct CustomizableObject_GetStateParameterCount_Params
{
	struct FString                                     StateName_69;                                             // (Parm, ZeroConstructor)
	int                                                ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CustomizableObject.CustomizableObject.GetStateName
struct CustomizableObject_GetStateName_Params
{
	int                                                StateIndex_69;                                            // (Parm, ZeroConstructor, IsPlainOldData)
	struct FString                                     ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function CustomizableObject.CustomizableObject.GetStateCount
struct CustomizableObject_GetStateCount_Params
{
	int                                                ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CustomizableObject.CustomizableObject.GetParameterUIMetadataFromIndex
struct CustomizableObject_GetParameterUIMetadataFromIndex_Params
{
	int                                                ParamIndex_69;                                            // (Parm, ZeroConstructor, IsPlainOldData)
	struct FParameterUIData                            ReturnValue_69;                                           // (Parm, OutParm, ReturnParm)
};

// Function CustomizableObject.CustomizableObject.GetParameterUIMetadata
struct CustomizableObject_GetParameterUIMetadata_Params
{
	struct FString                                     ParamName_69;                                             // (Parm, ZeroConstructor)
	struct FParameterUIData                            ReturnValue_69;                                           // (Parm, OutParm, ReturnParm)
};

// Function CustomizableObject.CustomizableObject.GetParameterTypeByName
struct CustomizableObject_GetParameterTypeByName_Params
{
	struct FString                                     Name_69;                                                  // (Parm, ZeroConstructor)
	EMutableParameterType                              ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CustomizableObject.CustomizableObject.GetParameterType
struct CustomizableObject_GetParameterType_Params
{
	int                                                ParamIndex_69;                                            // (Parm, ZeroConstructor, IsPlainOldData)
	EMutableParameterType                              ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CustomizableObject.CustomizableObject.GetParameterName
struct CustomizableObject_GetParameterName_Params
{
	int                                                ParamIndex_69;                                            // (Parm, ZeroConstructor, IsPlainOldData)
	struct FString                                     ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function CustomizableObject.CustomizableObject.GetParameterDescriptionCount
struct CustomizableObject_GetParameterDescriptionCount_Params
{
	struct FString                                     ParamName_69;                                             // (Parm, ZeroConstructor)
	int                                                ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CustomizableObject.CustomizableObject.GetParameterCount
struct CustomizableObject_GetParameterCount_Params
{
	int                                                ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CustomizableObject.CustomizableObject.GetIntParameterNumOptions
struct CustomizableObject_GetIntParameterNumOptions_Params
{
	int                                                ParamIndex_69;                                            // (Parm, ZeroConstructor, IsPlainOldData)
	int                                                ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CustomizableObject.CustomizableObject.GetIntParameterAvailableOption
struct CustomizableObject_GetIntParameterAvailableOption_Params
{
	int                                                ParamIndex_69;                                            // (Parm, ZeroConstructor, IsPlainOldData)
	int                                                K_69;                                                     // (Parm, ZeroConstructor, IsPlainOldData)
	struct FString                                     ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function CustomizableObject.CustomizableObject.FindParameter
struct CustomizableObject_FindParameter_Params
{
	struct FString                                     Name_69;                                                  // (Parm, ZeroConstructor)
	int                                                ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CustomizableObject.CustomizableObject.CreateInstance
struct CustomizableObject_CreateInstance_Params
{
	class CustomizableObjectInstance*                  ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function CustomizableObject.DGGUI.SetCustomizableSkeletalComponent
struct DGGUI_SetCustomizableSkeletalComponent_Params
{
	class CustomizableSkeletalComponent_32759*         CustomizableSkeletalComponent_69;                         // (Parm, ZeroConstructor, InstancedReference)
};

// Function CustomizableObject.DGGUI.GetCustomizableSkeletalComponent
struct DGGUI_GetCustomizableSkeletalComponent_Params
{
	class CustomizableSkeletalComponent_32759*         ReturnValue_69;                                           // (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)
};

// Function CustomizableObject.CustomizableObjectInstance.UpdateSkeletalMeshAsync
struct CustomizableObjectInstance_UpdateSkeletalMeshAsync_Params
{
	bool                                               bIgnoreCloseDist_69;                                      // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bForceHighPriority_69;                                    // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function CustomizableObject.CustomizableObjectInstance.SetVectorParameterSelectedOption
struct CustomizableObjectInstance_SetVectorParameterSelectedOption_Params
{
	struct FString                                     VectorParamName_69;                                       // (Parm, ZeroConstructor)
	struct FLinearColor                                VectorValue_69;                                           // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
};

// Function CustomizableObject.CustomizableObjectInstance.SetReplacePhysicsAssets
struct CustomizableObjectInstance_SetReplacePhysicsAssets_Params
{
	bool                                               bReplaceEnabled_69;                                       // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function CustomizableObject.CustomizableObjectInstance.SetRandomValues
struct CustomizableObjectInstance_SetRandomValues_Params
{
};

// Function CustomizableObject.CustomizableObjectInstance.SetProjectorValue
struct CustomizableObjectInstance_SetProjectorValue_Params
{
	struct FString                                     ProjectorParamName_69;                                    // (Parm, ZeroConstructor)
	struct FVector                                     OutPos_69;                                                // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
	struct FVector                                     OutDirection_69;                                          // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
	struct FVector                                     OutUp_69;                                                 // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
	struct FVector                                     OutScale_69;                                              // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
	float                                              OutAngle_69;                                              // (Parm, ZeroConstructor, IsPlainOldData)
	int                                                RangeIndex_69;                                            // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function CustomizableObject.CustomizableObjectInstance.SetObject
struct CustomizableObjectInstance_SetObject_Params
{
	class CustomizableObject*                          InObject_69;                                              // (Parm, ZeroConstructor)
};

// Function CustomizableObject.CustomizableObjectInstance.SetIntParameterSelectedOption
struct CustomizableObjectInstance_SetIntParameterSelectedOption_Params
{
	struct FString                                     ParamName_69;                                             // (Parm, ZeroConstructor)
	struct FString                                     SelectedOptionName_69;                                    // (Parm, ZeroConstructor)
	int                                                RangeIndex_69;                                            // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function CustomizableObject.CustomizableObjectInstance.SetFloatParameterSelectedOption
struct CustomizableObjectInstance_SetFloatParameterSelectedOption_Params
{
	struct FString                                     FloatParamName_69;                                        // (Parm, ZeroConstructor)
	float                                              FloatValue_69;                                            // (Parm, ZeroConstructor, IsPlainOldData)
	int                                                RangeIndex_69;                                            // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function CustomizableObject.CustomizableObjectInstance.SetCurrentState
struct CustomizableObjectInstance_SetCurrentState_Params
{
	struct FString                                     StateName_69;                                             // (Parm, ZeroConstructor)
};

// Function CustomizableObject.CustomizableObjectInstance.SetColorParameterSelectedOption
struct CustomizableObjectInstance_SetColorParameterSelectedOption_Params
{
	struct FString                                     ColorParamName_69;                                        // (Parm, ZeroConstructor)
	struct FLinearColor                                ColorValue_69;                                            // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
};

// Function CustomizableObject.CustomizableObjectInstance.SetBoolParameterSelectedOption
struct CustomizableObjectInstance_SetBoolParameterSelectedOption_Params
{
	struct FString                                     BoolParamName_69;                                         // (Parm, ZeroConstructor)
	bool                                               BoolValue_69;                                             // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function CustomizableObject.CustomizableObjectInstance.RemoveValueFromProjectorRange
struct CustomizableObjectInstance_RemoveValueFromProjectorRange_Params
{
	struct FString                                     ParamName_69;                                             // (Parm, ZeroConstructor)
	int                                                ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CustomizableObject.CustomizableObjectInstance.RemoveValueFromIntRange
struct CustomizableObjectInstance_RemoveValueFromIntRange_Params
{
	struct FString                                     ParamName_69;                                             // (Parm, ZeroConstructor)
	int                                                ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CustomizableObject.CustomizableObjectInstance.RemoveValueFromFloatRange
struct CustomizableObjectInstance_RemoveValueFromFloatRange_Params
{
	struct FString                                     ParamName_69;                                             // (Parm, ZeroConstructor)
	int                                                ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CustomizableObject.CustomizableObjectInstance.RemoveMultilayerProjector
struct CustomizableObjectInstance_RemoveMultilayerProjector_Params
{
	struct FName                                       ProjectorParamName_69;                                    // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
};

// Function CustomizableObject.CustomizableObjectInstance.MultilayerProjectorUpdateVirtualLayer
struct CustomizableObjectInstance_MultilayerProjectorUpdateVirtualLayer_Params
{
	struct FName                                       ProjectorParamName_69;                                    // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
	struct FName                                       ID_69;                                                    // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
	struct FMultilayerProjectorVirtualLayer            Layer_69;                                                 // (ConstParm, Parm, OutParm, ReferenceParm)
};

// Function CustomizableObject.CustomizableObjectInstance.MultilayerProjectorUpdateLayer
struct CustomizableObjectInstance_MultilayerProjectorUpdateLayer_Params
{
	struct FName                                       ProjectorParamName_69;                                    // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
	int                                                Index_69;                                                 // (Parm, ZeroConstructor, IsPlainOldData)
	struct FMultilayerProjectorLayer                   Layer_69;                                                 // (ConstParm, Parm, OutParm, ReferenceParm)
};

// Function CustomizableObject.CustomizableObjectInstance.MultilayerProjectorRemoveVirtualLayer
struct CustomizableObjectInstance_MultilayerProjectorRemoveVirtualLayer_Params
{
	struct FName                                       ProjectorParamName_69;                                    // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
	struct FName                                       ID_69;                                                    // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
};

// Function CustomizableObject.CustomizableObjectInstance.MultilayerProjectorRemoveLayerAt
struct CustomizableObjectInstance_MultilayerProjectorRemoveLayerAt_Params
{
	struct FName                                       ProjectorParamName_69;                                    // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
	int                                                Index_69;                                                 // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function CustomizableObject.CustomizableObjectInstance.MultilayerProjectorNumLayers
struct CustomizableObjectInstance_MultilayerProjectorNumLayers_Params
{
	struct FName                                       ProjectorParamName_69;                                    // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
	int                                                ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CustomizableObject.CustomizableObjectInstance.MultilayerProjectorGetVirtualLayers
struct CustomizableObjectInstance_MultilayerProjectorGetVirtualLayers_Params
{
	struct FName                                       ProjectorParamName_69;                                    // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
	TArray<struct FName>                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function CustomizableObject.CustomizableObjectInstance.MultilayerProjectorGetVirtualLayer
struct CustomizableObjectInstance_MultilayerProjectorGetVirtualLayer_Params
{
	struct FName                                       ProjectorParamName_69;                                    // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
	struct FName                                       ID_69;                                                    // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
	struct FMultilayerProjectorVirtualLayer            ReturnValue_69;                                           // (Parm, OutParm, ReturnParm)
};

// Function CustomizableObject.CustomizableObjectInstance.MultilayerProjectorGetLayer
struct CustomizableObjectInstance_MultilayerProjectorGetLayer_Params
{
	struct FName                                       ProjectorParamName_69;                                    // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
	int                                                Index_69;                                                 // (Parm, ZeroConstructor, IsPlainOldData)
	struct FMultilayerProjectorLayer                   ReturnValue_69;                                           // (Parm, OutParm, ReturnParm)
};

// Function CustomizableObject.CustomizableObjectInstance.MultilayerProjectorFindOrCreateVirtualLayer
struct CustomizableObjectInstance_MultilayerProjectorFindOrCreateVirtualLayer_Params
{
	struct FName                                       ProjectorParamName_69;                                    // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
	struct FName                                       ID_69;                                                    // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
	struct FMultilayerProjectorVirtualLayer            ReturnValue_69;                                           // (Parm, OutParm, ReturnParm)
};

// Function CustomizableObject.CustomizableObjectInstance.MultilayerProjectorCreateVirtualLayer
struct CustomizableObjectInstance_MultilayerProjectorCreateVirtualLayer_Params
{
	struct FName                                       ProjectorParamName_69;                                    // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
	struct FName                                       ID_69;                                                    // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
};

// Function CustomizableObject.CustomizableObjectInstance.MultilayerProjectorCreateLayer
struct CustomizableObjectInstance_MultilayerProjectorCreateLayer_Params
{
	struct FName                                       ProjectorParamName_69;                                    // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
	int                                                Index_69;                                                 // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function CustomizableObject.CustomizableObjectInstance.IsParamMultidimensional
struct CustomizableObjectInstance_IsParamMultidimensional_Params
{
	struct FString                                     ParamName_69;                                             // (Parm, ZeroConstructor)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CustomizableObject.CustomizableObjectInstance.IsParameterRelevant
struct CustomizableObjectInstance_IsParameterRelevant_Params
{
	struct FString                                     ParamName_69;                                             // (Parm, ZeroConstructor)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CustomizableObject.CustomizableObjectInstance.HasAnySkeletalMesh
struct CustomizableObjectInstance_HasAnySkeletalMesh_Params
{
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CustomizableObject.CustomizableObjectInstance.HasAnyParameters
struct CustomizableObjectInstance_HasAnyParameters_Params
{
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CustomizableObject.CustomizableObjectInstance.GetVectorParameters
struct CustomizableObjectInstance_GetVectorParameters_Params
{
	TArray<struct FCustomizableObjectVectorParameterValue> ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function CustomizableObject.CustomizableObjectInstance.GetTextureParameters
struct CustomizableObjectInstance_GetTextureParameters_Params
{
	TArray<struct FCustomizableObjectTextureParameterValue> ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function CustomizableObject.CustomizableObjectInstance.GetSkeletalMesh
struct CustomizableObjectInstance_GetSkeletalMesh_Params
{
	int                                                ComponentIndex_69;                                        // (Parm, ZeroConstructor, IsPlainOldData)
	class SkeletalMesh*                                ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function CustomizableObject.CustomizableObjectInstance.GetProjectorValue
struct CustomizableObjectInstance_GetProjectorValue_Params
{
	struct FString                                     ProjectorParamName_69;                                    // (Parm, ZeroConstructor)
	struct FVector                                     OutPos_69;                                                // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	struct FVector                                     OutDirection_69;                                          // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	struct FVector                                     OutUp_69;                                                 // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	struct FVector                                     OutScale_69;                                              // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	float                                              OutAngle_69;                                              // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	ECustomizableObjectProjectorType                   OutType_69;                                               // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	int                                                RangeIndex_69;                                            // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function CustomizableObject.CustomizableObjectInstance.GetProjectorUp
struct CustomizableObjectInstance_GetProjectorUp_Params
{
	struct FString                                     ParamName_69;                                             // (Parm, ZeroConstructor)
	int                                                RangeIndex_69;                                            // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector                                     ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CustomizableObject.CustomizableObjectInstance.GetProjectorScale
struct CustomizableObjectInstance_GetProjectorScale_Params
{
	struct FString                                     ParamName_69;                                             // (Parm, ZeroConstructor)
	int                                                RangeIndex_69;                                            // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector                                     ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CustomizableObject.CustomizableObjectInstance.GetProjectorPosition
struct CustomizableObjectInstance_GetProjectorPosition_Params
{
	struct FString                                     ParamName_69;                                             // (Parm, ZeroConstructor)
	int                                                RangeIndex_69;                                            // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector                                     ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CustomizableObject.CustomizableObjectInstance.GetProjectorParameterType
struct CustomizableObjectInstance_GetProjectorParameterType_Params
{
	struct FString                                     ParamName_69;                                             // (Parm, ZeroConstructor)
	int                                                RangeIndex_69;                                            // (Parm, ZeroConstructor, IsPlainOldData)
	ECustomizableObjectProjectorType                   ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CustomizableObject.CustomizableObjectInstance.GetProjectorParameters
struct CustomizableObjectInstance_GetProjectorParameters_Params
{
	TArray<struct FCustomizableObjectProjectorParameterValue> ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function CustomizableObject.CustomizableObjectInstance.GetProjectorDirection
struct CustomizableObjectInstance_GetProjectorDirection_Params
{
	struct FString                                     ParamName_69;                                             // (Parm, ZeroConstructor)
	int                                                RangeIndex_69;                                            // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector                                     ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CustomizableObject.CustomizableObjectInstance.GetProjectorAngle
struct CustomizableObjectInstance_GetProjectorAngle_Params
{
	struct FString                                     ParamName_69;                                             // (Parm, ZeroConstructor)
	int                                                RangeIndex_69;                                            // (Parm, ZeroConstructor, IsPlainOldData)
	float                                              ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CustomizableObject.CustomizableObjectInstance.GetParameterDescription
struct CustomizableObjectInstance_GetParameterDescription_Params
{
	struct FString                                     ParamName_69;                                             // (Parm, ZeroConstructor)
	int                                                DescIndex_69;                                             // (Parm, ZeroConstructor, IsPlainOldData)
	class Texture2D*                                   ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function CustomizableObject.CustomizableObjectInstance.GetIntParameterSelectedOption
struct CustomizableObjectInstance_GetIntParameterSelectedOption_Params
{
	struct FString                                     ParamName_69;                                             // (Parm, ZeroConstructor)
	int                                                RangeIndex_69;                                            // (Parm, ZeroConstructor, IsPlainOldData)
	struct FString                                     ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function CustomizableObject.CustomizableObjectInstance.GetIntParameters
struct CustomizableObjectInstance_GetIntParameters_Params
{
	TArray<struct FCustomizableObjectIntParameterValue> ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function CustomizableObject.CustomizableObjectInstance.GetFloatParameterSelectedOption
struct CustomizableObjectInstance_GetFloatParameterSelectedOption_Params
{
	struct FString                                     FloatParamName_69;                                        // (Parm, ZeroConstructor)
	int                                                RangeIndex_69;                                            // (Parm, ZeroConstructor, IsPlainOldData)
	float                                              ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CustomizableObject.CustomizableObjectInstance.GetFloatParameters
struct CustomizableObjectInstance_GetFloatParameters_Params
{
	TArray<struct FCustomizableObjectFloatParameterValue> ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function CustomizableObject.CustomizableObjectInstance.GetCustomizableObject
struct CustomizableObjectInstance_GetCustomizableObject_Params
{
	class CustomizableObject*                          ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function CustomizableObject.CustomizableObjectInstance.GetCurrentState
struct CustomizableObjectInstance_GetCurrentState_Params
{
	struct FString                                     ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function CustomizableObject.CustomizableObjectInstance.GetColorParameterSelectedOption
struct CustomizableObjectInstance_GetColorParameterSelectedOption_Params
{
	struct FString                                     ColorParamName_69;                                        // (Parm, ZeroConstructor)
	struct FLinearColor                                ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CustomizableObject.CustomizableObjectInstance.GetBoolParameterSelectedOption
struct CustomizableObjectInstance_GetBoolParameterSelectedOption_Params
{
	struct FString                                     BoolParamName_69;                                         // (Parm, ZeroConstructor)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CustomizableObject.CustomizableObjectInstance.GetBoolParameters
struct CustomizableObjectInstance_GetBoolParameters_Params
{
	TArray<struct FCustomizableObjectBoolParameterValue> ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function CustomizableObject.CustomizableObjectInstance.GetAnimBP
struct CustomizableObjectInstance_GetAnimBP_Params
{
	int                                                ComponentIndex_69;                                        // (Parm, ZeroConstructor, IsPlainOldData)
	int                                                SlotIndex_69;                                             // (Parm, ZeroConstructor, IsPlainOldData)
	class AnimInstance*                                ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function CustomizableObject.CustomizableObjectInstance.GetAnimationGameplayTags
struct CustomizableObjectInstance_GetAnimationGameplayTags_Params
{
	struct FGameplayTagContainer                       ReturnValue_69;                                           // (ConstParm, Parm, OutParm, ReturnParm, ReferenceParm)
};

// Function CustomizableObject.CustomizableObjectInstance.ForEachAnimInstance
struct CustomizableObjectInstance_ForEachAnimInstance_Params
{
	int                                                ComponentIndex_69;                                        // (Parm, ZeroConstructor, IsPlainOldData)
	struct FScriptDelegate                             Delegate_69;                                              // (Parm, ZeroConstructor)
};

// Function CustomizableObject.CustomizableObjectInstance.FindVectorParameterNameIndex
struct CustomizableObjectInstance_FindVectorParameterNameIndex_Params
{
	struct FString                                     ParamName_69;                                             // (Parm, ZeroConstructor)
	int                                                ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CustomizableObject.CustomizableObjectInstance.FindProjectorParameterNameIndex
struct CustomizableObjectInstance_FindProjectorParameterNameIndex_Params
{
	struct FString                                     ParamName_69;                                             // (Parm, ZeroConstructor)
	int                                                ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CustomizableObject.CustomizableObjectInstance.FindIntParameterNameIndex
struct CustomizableObjectInstance_FindIntParameterNameIndex_Params
{
	struct FString                                     ParamName_69;                                             // (Parm, ZeroConstructor)
	int                                                ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CustomizableObject.CustomizableObjectInstance.FindFloatParameterNameIndex
struct CustomizableObjectInstance_FindFloatParameterNameIndex_Params
{
	struct FString                                     ParamName_69;                                             // (Parm, ZeroConstructor)
	int                                                ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CustomizableObject.CustomizableObjectInstance.FindBoolParameterNameIndex
struct CustomizableObjectInstance_FindBoolParameterNameIndex_Params
{
	struct FString                                     ParamName_69;                                             // (Parm, ZeroConstructor)
	int                                                ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CustomizableObject.CustomizableObjectInstance.CurrentParamRange
struct CustomizableObjectInstance_CurrentParamRange_Params
{
	struct FString                                     ParamName_69;                                             // (Parm, ZeroConstructor)
	int                                                ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CustomizableObject.CustomizableObjectInstance.CreateMultiLayerProjector
struct CustomizableObjectInstance_CreateMultiLayerProjector_Params
{
	struct FName                                       ProjectorParamName_69;                                    // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CustomizableObject.CustomizableObjectInstance.CloneStatic
struct CustomizableObjectInstance_CloneStatic_Params
{
	class Object_32759*                                Outer_69;                                                 // (Parm, ZeroConstructor)
	class CustomizableObjectInstance*                  ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function CustomizableObject.CustomizableObjectInstance.Clone
struct CustomizableObjectInstance_Clone_Params
{
	class CustomizableObjectInstance*                  ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function CustomizableObject.CustomizableObjectInstance.AddValueToProjectorRange
struct CustomizableObjectInstance_AddValueToProjectorRange_Params
{
	struct FString                                     ParamName_69;                                             // (Parm, ZeroConstructor)
	int                                                ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CustomizableObject.CustomizableObjectInstance.AddValueToIntRange
struct CustomizableObjectInstance_AddValueToIntRange_Params
{
	struct FString                                     ParamName_69;                                             // (Parm, ZeroConstructor)
	int                                                ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CustomizableObject.CustomizableObjectInstance.AddValueToFloatRange
struct CustomizableObjectInstance_AddValueToFloatRange_Params
{
	struct FString                                     ParamName_69;                                             // (Parm, ZeroConstructor)
	int                                                ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CustomizableObject.CustomizableSkeletalComponent_32759.UpdateSkeletalMeshAsync
struct CustomizableSkeletalComponent_32759_UpdateSkeletalMeshAsync_Params
{
	bool                                               bNeverSkipUpdate_69;                                      // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function CustomizableObject.CustomizableObjectSystem.SetReleaseMutableTexturesImmediately
struct CustomizableObjectSystem_SetReleaseMutableTexturesImmediately_Params
{
	bool                                               bReleaseTextures_69;                                      // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function CustomizableObject.CustomizableObjectSystem.GetTotalInstances
struct CustomizableObjectSystem_GetTotalInstances_Params
{
	int                                                ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CustomizableObject.CustomizableObjectSystem.GetTextureMemoryUsed
struct CustomizableObjectSystem_GetTextureMemoryUsed_Params
{
	int                                                ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CustomizableObject.CustomizableObjectSystem.GetPluginVersion
struct CustomizableObjectSystem_GetPluginVersion_Params
{
	struct FString                                     ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function CustomizableObject.CustomizableObjectSystem.GetNumPendingInstances
struct CustomizableObjectSystem_GetNumPendingInstances_Params
{
	int                                                ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CustomizableObject.CustomizableObjectSystem.GetNumInstances
struct CustomizableObjectSystem_GetNumInstances_Params
{
	int                                                ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CustomizableObject.CustomizableObjectSystem.GetInstance
struct CustomizableObjectSystem_GetInstance_Params
{
	class CustomizableObjectSystem*                    ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function CustomizableObject.CustomizableObjectSystem.GetAverageBuildTime
struct CustomizableObjectSystem_GetAverageBuildTime_Params
{
	int                                                ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

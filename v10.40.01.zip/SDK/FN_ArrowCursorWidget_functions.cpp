// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Functions
//---------------------------------------------------------------------------

// Function ArrowCursorWidget.ArrowCursorWidget_C.GetBackground_0
// (Public, HasOutParms, BlueprintCallable, BlueprintEvent, BlueprintPure)
// Parameters:
// struct FSlateBrush             ReturnValue_1                  (Parm, OutParm, ReturnParm)

struct FSlateBrush ArrowCursorWidget_C::GetBackground_0()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ArrowCursorWidget.ArrowCursorWidget_C.GetBackground_0"));

	ArrowCursorWidget_C_GetBackground_0_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_1;
}


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

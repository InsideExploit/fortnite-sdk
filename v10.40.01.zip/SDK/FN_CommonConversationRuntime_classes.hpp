#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Classes
//---------------------------------------------------------------------------

// Class CommonConversationRuntime.ConversationParticipantComponent
// 0x0100 (0x01A0 - 0x00A0)
class ConversationParticipantComponent : public ActorComponent
{
public:
	unsigned char                                      UnknownData00[0x60];                                      // 0x00A0(0x0060) MISSED OFFSET
	int                                                ConversationsActive_69;                                   // 0x0100(0x0004) (Net, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x4];                                       // 0x0104(0x0004) MISSED OFFSET
	class ConversationInstance*                        Auth_CurrentConversation_69;                              // 0x0108(0x0008) (ZeroConstructor)
	TArray<class ConversationInstance*>                Auth_Conversations_69;                                    // 0x0110(0x0010) (ZeroConstructor)
	struct FClientConversationMessagePayload           LastMessage_69;                                           // 0x0120(0x0078)
	unsigned char                                      UnknownData02[0x8];                                       // 0x0198(0x0008) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CommonConversationRuntime.ConversationParticipantComponent"));
		
		return ptr;
	}


	void ServerAdvanceConversation(const struct FAdvanceConversationRequest& InChoicePicked_69);
	void RequestServerAdvanceConversation(const struct FAdvanceConversationRequest& InChoicePicked_69);
	void OnRep_ConversationsActive(int OldConversationsActive_69);
	bool IsInActiveConversation();
	struct FText GetParticipantDisplayName();
	void ClientUpdateParticipants(const struct FConversationParticipants& InParticipants_69);
	void ClientUpdateConversationTaskChoiceData(const struct FConversationNodeHandle& Handle_69, const struct FClientConversationOptionEntry& OptionEntry_69);
	void ClientUpdateConversations(int InConversationsActive_69);
	void ClientUpdateConversation(const struct FClientConversationMessagePayload& message_69);
	void ClientStartConversation(const struct FGameplayTag& AsParticipant_69);
	void ClientExecuteTaskAndSideEffects(const struct FConversationNodeHandle& Handle_69);
};


// Class CommonConversationRuntime.ConversationNode
// 0x0030 (0x0058 - 0x0028)
class ConversationNode : public Object_32759
{
public:
	class Object_32759*                                EvalWorldContextObj_69;                                   // 0x0028(0x0008) (BlueprintReadOnly, ZeroConstructor, Transient, DuplicateTransient)
	struct FString                                     NodeName_69;                                              // 0x0030(0x0010) (Edit, BlueprintReadOnly, ZeroConstructor)
	struct FGuid                                       Compiled_NodeGUID_69;                                     // 0x0040(0x0010) (BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	class ConversationNode*                            ParentNode_69;                                            // 0x0050(0x0008) (BlueprintReadOnly, ZeroConstructor)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CommonConversationRuntime.ConversationNode"));
		
		return ptr;
	}


	struct FLinearColor GetDebugParticipantColor(const struct FGameplayTag& ParticipantID_69);
};


// Class CommonConversationRuntime.ConversationSubNode
// 0x0000 (0x0058 - 0x0058)
class ConversationSubNode : public ConversationNode
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CommonConversationRuntime.ConversationSubNode"));
		
		return ptr;
	}

};


// Class CommonConversationRuntime.ConversationChoiceNode
// 0x0038 (0x0090 - 0x0058)
class ConversationChoiceNode : public ConversationSubNode
{
public:
	struct FText                                       DefaultChoiceDisplayText_69;                              // 0x0058(0x0018) (Edit, BlueprintVisible, BlueprintReadOnly)
	struct FGameplayTagContainer                       ChoiceTags_69;                                            // 0x0070(0x0020) (Edit, BlueprintVisible, BlueprintReadOnly)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CommonConversationRuntime.ConversationChoiceNode"));
		
		return ptr;
	}


	void FillChoice(const struct FConversationContext& Context_69, struct FClientConversationOptionEntry* ChoiceEntry_69);
};


// Class CommonConversationRuntime.ConversationContextHelpers
// 0x0000 (0x0028 - 0x0028)
class ConversationContextHelpers : public BlueprintFunctionLibrary
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CommonConversationRuntime.ConversationContextHelpers"));
		
		return ptr;
	}


	struct FConversationTaskResult STATIC_ReturnToLastClientChoice(const struct FConversationContext& Context_69);
	struct FConversationTaskResult STATIC_ReturnToCurrentClientChoice(const struct FConversationContext& Context_69);
	struct FConversationTaskResult STATIC_ReturnToConversationStart(const struct FConversationContext& Context_69);
	struct FConversationTaskResult STATIC_PauseConversationAndSendClientChoices(const struct FConversationContext& Context_69, const struct FClientConversationMessage& message_69);
	void STATIC_MakeConversationParticipant(const struct FConversationContext& Context_69, class Actor_32759* ParticipantActor_69, const struct FGameplayTag& ParticipantTag_69);
	struct FConversationNodeHandle STATIC_GetCurrentConversationNodeHandle(const struct FConversationContext& Context_69);
	class Actor_32759* STATIC_GetConversationParticipantActor(const struct FConversationContext& Context_69, const struct FGameplayTag& ParticipantTag_69);
	class ConversationParticipantComponent* STATIC_GetConversationParticipant(const struct FConversationContext& Context_69, const struct FGameplayTag& ParticipantTag_69);
	class ConversationInstance* STATIC_GetConversationInstance(const struct FConversationContext& Context_69);
	class ConversationParticipantComponent* STATIC_FindConversationComponent(class Actor_32759* Actor_69);
	bool STATIC_CanConversationContinue(const struct FConversationTaskResult& ConversationTasResult_69);
	struct FConversationTaskResult STATIC_AdvanceConversationWithChoice(const struct FConversationContext& Context_69, const struct FAdvanceConversationRequest& Choice_69);
	struct FConversationTaskResult STATIC_AdvanceConversation(const struct FConversationContext& Context_69);
	struct FConversationTaskResult STATIC_AbortConversation(const struct FConversationContext& Context_69);
};


// Class CommonConversationRuntime.ConversationDatabase
// 0x00B8 (0x00E8 - 0x0030)
class ConversationDatabase : public PrimaryDataAsset
{
public:
	int                                                CompilerVersion_69;                                       // 0x0030(0x0004) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0034(0x0004) MISSED OFFSET
	TMap<struct FGuid, class ConversationNode*>        ReachableNodeMap_69;                                      // 0x0038(0x0050)
	TArray<struct FConversationEntryList>              EntryTags_69;                                             // 0x0088(0x0010) (ZeroConstructor)
	struct FGameplayTagContainer                       ExitTags_69;                                              // 0x0098(0x0020)
	TArray<struct FGuid>                               InternalNodeIds_69;                                       // 0x00B8(0x0010) (ZeroConstructor)
	TArray<struct FGuid>                               LinkedToNodeIds_69;                                       // 0x00C8(0x0010) (ZeroConstructor)
	TArray<struct FCommonDialogueBankParticipant>      Speakers_69;                                              // 0x00D8(0x0010) (Edit, ZeroConstructor)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CommonConversationRuntime.ConversationDatabase"));
		
		return ptr;
	}

};


// Class CommonConversationRuntime.ConversationNodeWithLinks
// 0x0010 (0x0068 - 0x0058)
class ConversationNodeWithLinks : public ConversationNode
{
public:
	TArray<struct FGuid>                               OutputConnections_69;                                     // 0x0058(0x0010) (BlueprintReadOnly, ZeroConstructor)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CommonConversationRuntime.ConversationNodeWithLinks"));
		
		return ptr;
	}

};


// Class CommonConversationRuntime.ConversationEntryPointNode
// 0x0008 (0x0070 - 0x0068)
class ConversationEntryPointNode : public ConversationNodeWithLinks
{
public:
	struct FGameplayTag                                EntryTag_69;                                              // 0x0068(0x0004) (Edit, BlueprintReadOnly)
	unsigned char                                      UnknownData00[0x4];                                       // 0x006C(0x0004) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CommonConversationRuntime.ConversationEntryPointNode"));
		
		return ptr;
	}

};


// Class CommonConversationRuntime.ConversationInstance
// 0x0180 (0x01A8 - 0x0028)
class ConversationInstance : public Object_32759
{
public:
	unsigned char                                      UnknownData00[0x28];                                      // 0x0028(0x0028) MISSED OFFSET
	struct FConversationParticipants                   Participants_69;                                          // 0x0050(0x0010)
	unsigned char                                      UnknownData01[0x148];                                     // 0x0060(0x0148) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CommonConversationRuntime.ConversationInstance"));
		
		return ptr;
	}

};


// Class CommonConversationRuntime.ConversationLibrary
// 0x0000 (0x0028 - 0x0028)
class ConversationLibrary : public BlueprintFunctionLibrary
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CommonConversationRuntime.ConversationLibrary"));
		
		return ptr;
	}


	class ConversationInstance* STATIC_StartConversation(const struct FGameplayTag& ConversationEntryTag_69, class Actor_32759* Instigator_69, const struct FGameplayTag& InstigatorTag_69, class Actor_32759* Target_69, const struct FGameplayTag& TargetTag_69, class ConversationInstance* ConversationInstanceClass_69);
};


// Class CommonConversationRuntime.ConversationTaskNode
// 0x0018 (0x0080 - 0x0068)
class ConversationTaskNode : public ConversationNodeWithLinks
{
public:
	TArray<class ConversationSubNode*>                 SubNodes_69;                                              // 0x0068(0x0010) (BlueprintReadOnly, ZeroConstructor)
	bool                                               bIgnoreRequirementsWhileAdvancingConversations_69;        // 0x0078(0x0001) (Edit, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0079(0x0007) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CommonConversationRuntime.ConversationTaskNode"));
		
		return ptr;
	}


	EConversationRequirementResult IsRequirementSatisfied(const struct FConversationContext& Context_69);
	bool GetNodeBodyColor(struct FLinearColor* BodyColor_69);
	void GatherStaticExtraData(const struct FConversationContext& Context_69, TArray<struct FConversationNodeParameterPair>* InOutExtraData_69);
	struct FConversationTaskResult ExecuteTaskNode(const struct FConversationContext& Context_69);
	void ExecuteClientEffects(const struct FConversationContext& Context_69);
};


// Class CommonConversationRuntime.ConversationLinkNode
// 0x0008 (0x0088 - 0x0080)
class ConversationLinkNode : public ConversationTaskNode
{
public:
	struct FGameplayTag                                RemoteEntryTag_69;                                        // 0x0080(0x0004) (Edit, BlueprintReadOnly)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0084(0x0004) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CommonConversationRuntime.ConversationLinkNode"));
		
		return ptr;
	}

};


// Class CommonConversationRuntime.ConversationRegistry
// 0x01C8 (0x01F8 - 0x0030)
class ConversationRegistry : public WorldSubsystem
{
public:
	unsigned char                                      UnknownData00[0x8];                                       // 0x0030(0x0008) MISSED OFFSET
	struct FNetSerializeScriptStructCache_ConvVersion  ConversationChoiceDataStructCache_69;                     // 0x0038(0x0060) (Transient)
	unsigned char                                      UnknownData01[0x160];                                     // 0x0098(0x0160) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CommonConversationRuntime.ConversationRegistry"));
		
		return ptr;
	}

};


// Class CommonConversationRuntime.ConversationRequirementNode
// 0x0000 (0x0058 - 0x0058)
class ConversationRequirementNode : public ConversationSubNode
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CommonConversationRuntime.ConversationRequirementNode"));
		
		return ptr;
	}


	EConversationRequirementResult IsRequirementSatisfied(const struct FConversationContext& Context_69);
};


// Class CommonConversationRuntime.ConversationSettings
// 0x0028 (0x0058 - 0x0030)
class ConversationSettings : public DeveloperSettings
{
public:
	unsigned char                                      UnknownData00[0x28];                                      // 0x0030(0x0028) UNKNOWN PROPERTY: SoftClassProperty CommonConversationRuntime.ConversationSettings.ConversationInstanceClass_69

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CommonConversationRuntime.ConversationSettings"));
		
		return ptr;
	}

};


// Class CommonConversationRuntime.ConversationSideEffectNode
// 0x0000 (0x0058 - 0x0058)
class ConversationSideEffectNode : public ConversationSubNode
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CommonConversationRuntime.ConversationSideEffectNode"));
		
		return ptr;
	}


	void ServerCauseSideEffect(const struct FConversationContext& Context_69);
	void ClientCauseSideEffect(const struct FConversationContext& Context_69);
};


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

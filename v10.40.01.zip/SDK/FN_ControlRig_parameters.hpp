#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function ControlRig.ControlRig.SupportsEvent
struct ControlRig_SupportsEvent_Params
{
	struct FName                                       InEventName_69;                                           // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function ControlRig.ControlRig.SetVariableFromString
struct ControlRig_SetVariableFromString_Params
{
	struct FName                                       InVariableName_69;                                        // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
	struct FString                                     InValue_69;                                               // (Parm, ZeroConstructor)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function ControlRig.ControlRig.SetInteractionRigClass
struct ControlRig_SetInteractionRigClass_Params
{
	class ControlRig*                                  InInteractionRigClass_69;                                 // (Parm, ZeroConstructor)
};

// Function ControlRig.ControlRig.SetInteractionRig
struct ControlRig_SetInteractionRig_Params
{
	class ControlRig*                                  InInteractionRig_69;                                      // (Parm, ZeroConstructor)
};

// Function ControlRig.ControlRig.SetFramesPerSecond
struct ControlRig_SetFramesPerSecond_Params
{
	float                                              InFramesPerSecond_69;                                     // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function ControlRig.ControlRig.SetDeltaTime
struct ControlRig_SetDeltaTime_Params
{
	float                                              InDeltaTime_69;                                           // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function ControlRig.ControlRig.SetAbsoluteTime
struct ControlRig_SetAbsoluteTime_Params
{
	float                                              InAbsoluteTime_69;                                        // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               InSetDeltaTimeZero_69;                                    // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function ControlRig.ControlRig.SetAbsoluteAndDeltaTime
struct ControlRig_SetAbsoluteAndDeltaTime_Params
{
	float                                              InAbsoluteTime_69;                                        // (Parm, ZeroConstructor, IsPlainOldData)
	float                                              InDeltaTime_69;                                           // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function ControlRig.ControlRig.SelectControl
struct ControlRig_SelectControl_Params
{
	struct FName                                       InControlName_69;                                         // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
	bool                                               bSelect_69;                                               // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function ControlRig.ControlRig.RequestInit
struct ControlRig_RequestInit_Params
{
};

// Function ControlRig.ControlRig.RequestConstruction
struct ControlRig_RequestConstruction_Params
{
};

// SparseDelegateFunction ControlRig.ControlRig.OnControlSelectedBP__DelegateSignature
struct ControlRig_OnControlSelectedBP__DelegateSignature_Params
{
	class ControlRig*                                  Rig_69;                                                   // (Parm, ZeroConstructor)
	struct FRigControlElement                          Control_69;                                               // (ConstParm, Parm, OutParm, ReferenceParm)
	bool                                               bSelected_69;                                             // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function ControlRig.ControlRig.IsControlSelected
struct ControlRig_IsControlSelected_Params
{
	struct FName                                       InControlName_69;                                         // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function ControlRig.ControlRig.GetVM
struct ControlRig_GetVM_Params
{
	class RigVM*                                       ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function ControlRig.ControlRig.GetVariableType
struct ControlRig_GetVariableType_Params
{
	struct FName                                       InVariableName_69;                                        // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
	struct FName                                       ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function ControlRig.ControlRig.GetVariableAsString
struct ControlRig_GetVariableAsString_Params
{
	struct FName                                       InVariableName_69;                                        // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
	struct FString                                     ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function ControlRig.ControlRig.GetSupportedEvents
struct ControlRig_GetSupportedEvents_Params
{
	TArray<struct FName>                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function ControlRig.ControlRig.GetScriptAccessibleVariables
struct ControlRig_GetScriptAccessibleVariables_Params
{
	TArray<struct FName>                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function ControlRig.ControlRig.GetInteractionRigClass
struct ControlRig_GetInteractionRigClass_Params
{
	class ControlRig*                                  ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function ControlRig.ControlRig.GetInteractionRig
struct ControlRig_GetInteractionRig_Params
{
	class ControlRig*                                  ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function ControlRig.ControlRig.GetHostingActor
struct ControlRig_GetHostingActor_Params
{
	class Actor_32759*                                 ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function ControlRig.ControlRig.GetHierarchy
struct ControlRig_GetHierarchy_Params
{
	class RigHierarchy*                                ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function ControlRig.ControlRig.GetEvents
struct ControlRig_GetEvents_Params
{
	TArray<struct FName>                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function ControlRig.ControlRig.GetCurrentFramesPerSecond
struct ControlRig_GetCurrentFramesPerSecond_Params
{
	float                                              ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function ControlRig.ControlRig.GetAbsoluteTime
struct ControlRig_GetAbsoluteTime_Params
{
	float                                              ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function ControlRig.ControlRig.FindControlRigs
struct ControlRig_FindControlRigs_Params
{
	class Object_32759*                                Outer_69;                                                 // (Parm, ZeroConstructor)
	class ControlRig*                                  OptionalClass_69;                                         // (Parm, ZeroConstructor)
	TArray<class ControlRig*>                          ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function ControlRig.ControlRig.ExecuteEvent
struct ControlRig_ExecuteEvent_Params
{
	struct FName                                       InEventName_69;                                           // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function ControlRig.ControlRig.Execute
struct ControlRig_Execute_Params
{
	EControlRigState                                   State_69;                                                 // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	struct FName                                       InEventName_69;                                           // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function ControlRig.ControlRig.CurrentControlSelection
struct ControlRig_CurrentControlSelection_Params
{
	TArray<struct FName>                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function ControlRig.ControlRig.CreateTransformableControlHandle
struct ControlRig_CreateTransformableControlHandle_Params
{
	class Object_32759*                                Outer_69;                                                 // (Parm, ZeroConstructor)
	struct FName                                       ControlName_69;                                           // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
	class TransformableControlHandle_32759*            ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function ControlRig.ControlRig.ContainsEvent
struct ControlRig_ContainsEvent_Params
{
	struct FName                                       InEventName_69;                                           // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function ControlRig.ControlRig.ClearControlSelection
struct ControlRig_ClearControlSelection_Params
{
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function ControlRig.ControlRig.CanExecute
struct ControlRig_CanExecute_Params
{
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function ControlRig.RigHierarchy.UnsetCurveValueByIndex
struct RigHierarchy_UnsetCurveValueByIndex_Params
{
	int                                                InElementIndex_69;                                        // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bSetupUndo_69;                                            // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function ControlRig.RigHierarchy.UnsetCurveValue
struct RigHierarchy_UnsetCurveValue_Params
{
	struct FRigElementKey                              InKey_69;                                                 // (Parm)
	bool                                               bSetupUndo_69;                                            // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function ControlRig.RigHierarchy.SwitchToWorldSpace
struct RigHierarchy_SwitchToWorldSpace_Params
{
	struct FRigElementKey                              InChild_69;                                               // (Parm)
	bool                                               bInitial_69;                                              // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bAffectChildren_69;                                       // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function ControlRig.RigHierarchy.SwitchToParent
struct RigHierarchy_SwitchToParent_Params
{
	struct FRigElementKey                              InChild_69;                                               // (Parm)
	struct FRigElementKey                              InParent_69;                                              // (Parm)
	bool                                               bInitial_69;                                              // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bAffectChildren_69;                                       // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function ControlRig.RigHierarchy.SwitchToDefaultParent
struct RigHierarchy_SwitchToDefaultParent_Params
{
	struct FRigElementKey                              InChild_69;                                               // (Parm)
	bool                                               bInitial_69;                                              // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bAffectChildren_69;                                       // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function ControlRig.RigHierarchy.SortKeys
struct RigHierarchy_SortKeys_Params
{
	TArray<struct FRigElementKey>                      InKeys_69;                                                // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	TArray<struct FRigElementKey>                      ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function ControlRig.RigHierarchy.SetVectorMetadata
struct RigHierarchy_SetVectorMetadata_Params
{
	struct FRigElementKey                              InItem_69;                                                // (Parm)
	struct FName                                       InMetadataName_69;                                        // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector                                     InValue_69;                                               // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function ControlRig.RigHierarchy.SetVectorArrayMetadata
struct RigHierarchy_SetVectorArrayMetadata_Params
{
	struct FRigElementKey                              InItem_69;                                                // (Parm)
	struct FName                                       InMetadataName_69;                                        // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<struct FVector>                             InValue_69;                                               // (Parm, ZeroConstructor)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function ControlRig.RigHierarchy.SetTransformMetadata
struct RigHierarchy_SetTransformMetadata_Params
{
	struct FRigElementKey                              InItem_69;                                                // (Parm)
	struct FName                                       InMetadataName_69;                                        // (Parm, ZeroConstructor, IsPlainOldData)
	struct FCoreUObject_FTransform                     InValue_69;                                               // (Parm, IsPlainOldData)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function ControlRig.RigHierarchy.SetTransformArrayMetadata
struct RigHierarchy_SetTransformArrayMetadata_Params
{
	struct FRigElementKey                              InItem_69;                                                // (Parm)
	struct FName                                       InMetadataName_69;                                        // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<struct FCoreUObject_FTransform>             InValue_69;                                               // (Parm, ZeroConstructor)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function ControlRig.RigHierarchy.SetTag
struct RigHierarchy_SetTag_Params
{
	struct FRigElementKey                              InItem_69;                                                // (Parm)
	struct FName                                       InTag_69;                                                 // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function ControlRig.RigHierarchy.SetRotatorMetadata
struct RigHierarchy_SetRotatorMetadata_Params
{
	struct FRigElementKey                              InItem_69;                                                // (Parm)
	struct FName                                       InMetadataName_69;                                        // (Parm, ZeroConstructor, IsPlainOldData)
	struct FRotator                                    InValue_69;                                               // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function ControlRig.RigHierarchy.SetRotatorArrayMetadata
struct RigHierarchy_SetRotatorArrayMetadata_Params
{
	struct FRigElementKey                              InItem_69;                                                // (Parm)
	struct FName                                       InMetadataName_69;                                        // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<struct FRotator>                            InValue_69;                                               // (Parm, ZeroConstructor)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function ControlRig.RigHierarchy.SetRigElementKeyMetadata
struct RigHierarchy_SetRigElementKeyMetadata_Params
{
	struct FRigElementKey                              InItem_69;                                                // (Parm)
	struct FName                                       InMetadataName_69;                                        // (Parm, ZeroConstructor, IsPlainOldData)
	struct FRigElementKey                              InValue_69;                                               // (Parm)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function ControlRig.RigHierarchy.SetRigElementKeyArrayMetadata
struct RigHierarchy_SetRigElementKeyArrayMetadata_Params
{
	struct FRigElementKey                              InItem_69;                                                // (Parm)
	struct FName                                       InMetadataName_69;                                        // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<struct FRigElementKey>                      InValue_69;                                               // (Parm, ZeroConstructor)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function ControlRig.RigHierarchy.SetQuatMetadata
struct RigHierarchy_SetQuatMetadata_Params
{
	struct FRigElementKey                              InItem_69;                                                // (Parm)
	struct FName                                       InMetadataName_69;                                        // (Parm, ZeroConstructor, IsPlainOldData)
	struct FQuat                                       InValue_69;                                               // (Parm, IsPlainOldData)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function ControlRig.RigHierarchy.SetQuatArrayMetadata
struct RigHierarchy_SetQuatArrayMetadata_Params
{
	struct FRigElementKey                              InItem_69;                                                // (Parm)
	struct FName                                       InMetadataName_69;                                        // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<struct FQuat>                               InValue_69;                                               // (Parm, ZeroConstructor)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function ControlRig.RigHierarchy.SetPose_ForBlueprint
struct RigHierarchy_SetPose_ForBlueprint_Params
{
	struct FRigPose                                    InPose_69;                                                // (Parm)
};

// Function ControlRig.RigHierarchy.SetParentWeightArray
struct RigHierarchy_SetParentWeightArray_Params
{
	struct FRigElementKey                              InChild_69;                                               // (Parm)
	TArray<struct FRigElementWeight>                   InWeights_69;                                             // (Parm, ZeroConstructor)
	bool                                               bInitial_69;                                              // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bAffectChildren_69;                                       // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function ControlRig.RigHierarchy.SetParentWeight
struct RigHierarchy_SetParentWeight_Params
{
	struct FRigElementKey                              InChild_69;                                               // (Parm)
	struct FRigElementKey                              InParent_69;                                              // (Parm)
	struct FRigElementWeight                           InWeight_69;                                              // (Parm)
	bool                                               bInitial_69;                                              // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bAffectChildren_69;                                       // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function ControlRig.RigHierarchy.SetNameMetadata
struct RigHierarchy_SetNameMetadata_Params
{
	struct FRigElementKey                              InItem_69;                                                // (Parm)
	struct FName                                       InMetadataName_69;                                        // (Parm, ZeroConstructor, IsPlainOldData)
	struct FName                                       InValue_69;                                               // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function ControlRig.RigHierarchy.SetNameArrayMetadata
struct RigHierarchy_SetNameArrayMetadata_Params
{
	struct FRigElementKey                              InItem_69;                                                // (Parm)
	struct FName                                       InMetadataName_69;                                        // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<struct FName>                               InValue_69;                                               // (Parm, ZeroConstructor)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function ControlRig.RigHierarchy.SetLocalTransformByIndex
struct RigHierarchy_SetLocalTransformByIndex_Params
{
	int                                                InElementIndex_69;                                        // (Parm, ZeroConstructor, IsPlainOldData)
	struct FCoreUObject_FTransform                     InTransform_69;                                           // (Parm, IsPlainOldData)
	bool                                               bInitial_69;                                              // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bAffectChildren_69;                                       // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bSetupUndo_69;                                            // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bPrintPythonCommands_69;                                  // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function ControlRig.RigHierarchy.SetLocalTransform
struct RigHierarchy_SetLocalTransform_Params
{
	struct FRigElementKey                              InKey_69;                                                 // (Parm)
	struct FCoreUObject_FTransform                     InTransform_69;                                           // (Parm, IsPlainOldData)
	bool                                               bInitial_69;                                              // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bAffectChildren_69;                                       // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bSetupUndo_69;                                            // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bPrintPythonCommands_69;                                  // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function ControlRig.RigHierarchy.SetLinearColorMetadata
struct RigHierarchy_SetLinearColorMetadata_Params
{
	struct FRigElementKey                              InItem_69;                                                // (Parm)
	struct FName                                       InMetadataName_69;                                        // (Parm, ZeroConstructor, IsPlainOldData)
	struct FLinearColor                                InValue_69;                                               // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function ControlRig.RigHierarchy.SetLinearColorArrayMetadata
struct RigHierarchy_SetLinearColorArrayMetadata_Params
{
	struct FRigElementKey                              InItem_69;                                                // (Parm)
	struct FName                                       InMetadataName_69;                                        // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<struct FLinearColor>                        InValue_69;                                               // (Parm, ZeroConstructor)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function ControlRig.RigHierarchy.SetInt32Metadata
struct RigHierarchy_SetInt32Metadata_Params
{
	struct FRigElementKey                              InItem_69;                                                // (Parm)
	struct FName                                       InMetadataName_69;                                        // (Parm, ZeroConstructor, IsPlainOldData)
	int                                                InValue_69;                                               // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function ControlRig.RigHierarchy.SetInt32ArrayMetadata
struct RigHierarchy_SetInt32ArrayMetadata_Params
{
	struct FRigElementKey                              InItem_69;                                                // (Parm)
	struct FName                                       InMetadataName_69;                                        // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<int>                                        InValue_69;                                               // (Parm, ZeroConstructor)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function ControlRig.RigHierarchy.SetGlobalTransformByIndex
struct RigHierarchy_SetGlobalTransformByIndex_Params
{
	int                                                InElementIndex_69;                                        // (Parm, ZeroConstructor, IsPlainOldData)
	struct FCoreUObject_FTransform                     InTransform_69;                                           // (Parm, IsPlainOldData)
	bool                                               bInitial_69;                                              // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bAffectChildren_69;                                       // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bSetupUndo_69;                                            // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bPrintPythonCommand_69;                                   // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function ControlRig.RigHierarchy.SetGlobalTransform
struct RigHierarchy_SetGlobalTransform_Params
{
	struct FRigElementKey                              InKey_69;                                                 // (Parm)
	struct FCoreUObject_FTransform                     InTransform_69;                                           // (Parm, IsPlainOldData)
	bool                                               bInitial_69;                                              // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bAffectChildren_69;                                       // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bSetupUndo_69;                                            // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bPrintPythonCommand_69;                                   // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function ControlRig.RigHierarchy.SetFloatMetadata
struct RigHierarchy_SetFloatMetadata_Params
{
	struct FRigElementKey                              InItem_69;                                                // (Parm)
	struct FName                                       InMetadataName_69;                                        // (Parm, ZeroConstructor, IsPlainOldData)
	float                                              InValue_69;                                               // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function ControlRig.RigHierarchy.SetFloatArrayMetadata
struct RigHierarchy_SetFloatArrayMetadata_Params
{
	struct FRigElementKey                              InItem_69;                                                // (Parm)
	struct FName                                       InMetadataName_69;                                        // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<float>                                      InValue_69;                                               // (Parm, ZeroConstructor)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function ControlRig.RigHierarchy.SetCurveValueByIndex
struct RigHierarchy_SetCurveValueByIndex_Params
{
	int                                                InElementIndex_69;                                        // (Parm, ZeroConstructor, IsPlainOldData)
	float                                              InValue_69;                                               // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bSetupUndo_69;                                            // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function ControlRig.RigHierarchy.SetCurveValue
struct RigHierarchy_SetCurveValue_Params
{
	struct FRigElementKey                              InKey_69;                                                 // (Parm)
	float                                              InValue_69;                                               // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bSetupUndo_69;                                            // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function ControlRig.RigHierarchy.SetControlVisibilityByIndex
struct RigHierarchy_SetControlVisibilityByIndex_Params
{
	int                                                InElementIndex_69;                                        // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bVisibility_69;                                           // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function ControlRig.RigHierarchy.SetControlVisibility
struct RigHierarchy_SetControlVisibility_Params
{
	struct FRigElementKey                              InKey_69;                                                 // (Parm)
	bool                                               bVisibility_69;                                           // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function ControlRig.RigHierarchy.SetControlValueByIndex
struct RigHierarchy_SetControlValueByIndex_Params
{
	int                                                InElementIndex_69;                                        // (Parm, ZeroConstructor, IsPlainOldData)
	struct FRigControlValue                            InValue_69;                                               // (Parm)
	ERigControlValueType                               InValueType_69;                                           // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bSetupUndo_69;                                            // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bPrintPythonCommands_69;                                  // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function ControlRig.RigHierarchy.SetControlValue
struct RigHierarchy_SetControlValue_Params
{
	struct FRigElementKey                              InKey_69;                                                 // (Parm)
	struct FRigControlValue                            InValue_69;                                               // (Parm)
	ERigControlValueType                               InValueType_69;                                           // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bSetupUndo_69;                                            // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bPrintPythonCommands_69;                                  // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function ControlRig.RigHierarchy.SetControlShapeTransformByIndex
struct RigHierarchy_SetControlShapeTransformByIndex_Params
{
	int                                                InElementIndex_69;                                        // (Parm, ZeroConstructor, IsPlainOldData)
	struct FCoreUObject_FTransform                     InTransform_69;                                           // (Parm, IsPlainOldData)
	bool                                               bInitial_69;                                              // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bSetupUndo_69;                                            // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function ControlRig.RigHierarchy.SetControlShapeTransform
struct RigHierarchy_SetControlShapeTransform_Params
{
	struct FRigElementKey                              InKey_69;                                                 // (Parm)
	struct FCoreUObject_FTransform                     InTransform_69;                                           // (Parm, IsPlainOldData)
	bool                                               bInitial_69;                                              // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bSetupUndo_69;                                            // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function ControlRig.RigHierarchy.SetControlSettingsByIndex
struct RigHierarchy_SetControlSettingsByIndex_Params
{
	int                                                InElementIndex_69;                                        // (Parm, ZeroConstructor, IsPlainOldData)
	struct FRigControlSettings                         InSettings_69;                                            // (Parm)
	bool                                               bSetupUndo_69;                                            // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bForce_69;                                                // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bPrintPythonCommands_69;                                  // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function ControlRig.RigHierarchy.SetControlSettings
struct RigHierarchy_SetControlSettings_Params
{
	struct FRigElementKey                              InKey_69;                                                 // (Parm)
	struct FRigControlSettings                         InSettings_69;                                            // (Parm)
	bool                                               bSetupUndo_69;                                            // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bForce_69;                                                // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bPrintPythonCommands_69;                                  // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function ControlRig.RigHierarchy.SetControlPreferredRotatorByIndex
struct RigHierarchy_SetControlPreferredRotatorByIndex_Params
{
	int                                                InElementIndex_69;                                        // (Parm, ZeroConstructor, IsPlainOldData)
	struct FRotator                                    InValue_69;                                               // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
	bool                                               bInitial_69;                                              // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bFixEulerFlips_69;                                        // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function ControlRig.RigHierarchy.SetControlPreferredRotator
struct RigHierarchy_SetControlPreferredRotator_Params
{
	struct FRigElementKey                              InKey_69;                                                 // (Parm)
	struct FRotator                                    InValue_69;                                               // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
	bool                                               bInitial_69;                                              // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bFixEulerFlips_69;                                        // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function ControlRig.RigHierarchy.SetControlOffsetTransformByIndex
struct RigHierarchy_SetControlOffsetTransformByIndex_Params
{
	int                                                InElementIndex_69;                                        // (Parm, ZeroConstructor, IsPlainOldData)
	struct FCoreUObject_FTransform                     InTransform_69;                                           // (Parm, IsPlainOldData)
	bool                                               bInitial_69;                                              // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bAffectChildren_69;                                       // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bSetupUndo_69;                                            // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bPrintPythonCommands_69;                                  // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function ControlRig.RigHierarchy.SetControlOffsetTransform
struct RigHierarchy_SetControlOffsetTransform_Params
{
	struct FRigElementKey                              InKey_69;                                                 // (Parm)
	struct FCoreUObject_FTransform                     InTransform_69;                                           // (Parm, IsPlainOldData)
	bool                                               bInitial_69;                                              // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bAffectChildren_69;                                       // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bSetupUndo_69;                                            // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bPrintPythonCommands_69;                                  // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function ControlRig.RigHierarchy.SetBoolMetadata
struct RigHierarchy_SetBoolMetadata_Params
{
	struct FRigElementKey                              InItem_69;                                                // (Parm)
	struct FName                                       InMetadataName_69;                                        // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               InValue_69;                                               // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function ControlRig.RigHierarchy.SetBoolArrayMetadata
struct RigHierarchy_SetBoolArrayMetadata_Params
{
	struct FRigElementKey                              InItem_69;                                                // (Parm)
	struct FName                                       InMetadataName_69;                                        // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<bool>                                       InValue_69;                                               // (Parm, ZeroConstructor)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function ControlRig.RigHierarchy.SendAutoKeyEvent
struct RigHierarchy_SendAutoKeyEvent_Params
{
	struct FRigElementKey                              InElement_69;                                             // (Parm)
	float                                              InOffsetInSeconds_69;                                     // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bAsynchronous_69;                                         // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function ControlRig.RigHierarchy.ResetToDefault
struct RigHierarchy_ResetToDefault_Params
{
};

// Function ControlRig.RigHierarchy.ResetPoseToInitial
struct RigHierarchy_ResetPoseToInitial_Params
{
	ERigElementType                                    InTypeFilter_69;                                          // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function ControlRig.RigHierarchy.ResetCurveValues
struct RigHierarchy_ResetCurveValues_Params
{
};

// Function ControlRig.RigHierarchy.Reset
struct RigHierarchy_Reset_Params
{
};

// Function ControlRig.RigHierarchy.RemoveMetadata
struct RigHierarchy_RemoveMetadata_Params
{
	struct FRigElementKey                              InItem_69;                                                // (Parm)
	struct FName                                       InMetadataName_69;                                        // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function ControlRig.RigHierarchy.RemoveAllMetadata
struct RigHierarchy_RemoveAllMetadata_Params
{
	struct FRigElementKey                              InItem_69;                                                // (Parm)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function ControlRig.RigHierarchy.Num
struct RigHierarchy_Num_Params
{
	int                                                ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function ControlRig.RigHierarchy.MakeControlValueFromVector2D
struct RigHierarchy_MakeControlValueFromVector2D_Params
{
	struct FVector2D                                   InValue_69;                                               // (Parm, ZeroConstructor, IsPlainOldData)
	struct FRigControlValue                            ReturnValue_69;                                           // (Parm, OutParm, ReturnParm)
};

// Function ControlRig.RigHierarchy.MakeControlValueFromVector
struct RigHierarchy_MakeControlValueFromVector_Params
{
	struct FVector                                     InValue_69;                                               // (Parm, ZeroConstructor, IsPlainOldData)
	struct FRigControlValue                            ReturnValue_69;                                           // (Parm, OutParm, ReturnParm)
};

// Function ControlRig.RigHierarchy.MakeControlValueFromTransformNoScale
struct RigHierarchy_MakeControlValueFromTransformNoScale_Params
{
	struct FTransformNoScale                           InValue_69;                                               // (Parm)
	struct FRigControlValue                            ReturnValue_69;                                           // (Parm, OutParm, ReturnParm)
};

// Function ControlRig.RigHierarchy.MakeControlValueFromTransform
struct RigHierarchy_MakeControlValueFromTransform_Params
{
	struct FCoreUObject_FTransform                     InValue_69;                                               // (Parm, IsPlainOldData)
	struct FRigControlValue                            ReturnValue_69;                                           // (Parm, OutParm, ReturnParm)
};

// Function ControlRig.RigHierarchy.MakeControlValueFromRotator
struct RigHierarchy_MakeControlValueFromRotator_Params
{
	struct FRotator                                    InValue_69;                                               // (Parm, ZeroConstructor, IsPlainOldData)
	struct FRigControlValue                            ReturnValue_69;                                           // (Parm, OutParm, ReturnParm)
};

// Function ControlRig.RigHierarchy.MakeControlValueFromInt
struct RigHierarchy_MakeControlValueFromInt_Params
{
	int                                                InValue_69;                                               // (Parm, ZeroConstructor, IsPlainOldData)
	struct FRigControlValue                            ReturnValue_69;                                           // (Parm, OutParm, ReturnParm)
};

// Function ControlRig.RigHierarchy.MakeControlValueFromFloat
struct RigHierarchy_MakeControlValueFromFloat_Params
{
	float                                              InValue_69;                                               // (Parm, ZeroConstructor, IsPlainOldData)
	struct FRigControlValue                            ReturnValue_69;                                           // (Parm, OutParm, ReturnParm)
};

// Function ControlRig.RigHierarchy.MakeControlValueFromEulerTransform
struct RigHierarchy_MakeControlValueFromEulerTransform_Params
{
	struct FEulerTransform                             InValue_69;                                               // (Parm)
	struct FRigControlValue                            ReturnValue_69;                                           // (Parm, OutParm, ReturnParm)
};

// Function ControlRig.RigHierarchy.MakeControlValueFromBool
struct RigHierarchy_MakeControlValueFromBool_Params
{
	bool                                               InValue_69;                                               // (Parm, ZeroConstructor, IsPlainOldData)
	struct FRigControlValue                            ReturnValue_69;                                           // (Parm, OutParm, ReturnParm)
};

// Function ControlRig.RigHierarchy.IsValidIndex
struct RigHierarchy_IsValidIndex_Params
{
	int                                                InElementIndex_69;                                        // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function ControlRig.RigHierarchy.IsSelectedByIndex
struct RigHierarchy_IsSelectedByIndex_Params
{
	int                                                InIndex_69;                                               // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function ControlRig.RigHierarchy.IsSelected
struct RigHierarchy_IsSelected_Params
{
	struct FRigElementKey                              InKey_69;                                                 // (Parm)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function ControlRig.RigHierarchy.IsProcedural
struct RigHierarchy_IsProcedural_Params
{
	struct FRigElementKey                              InKey_69;                                                 // (ConstParm, Parm, OutParm, ReferenceParm)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function ControlRig.RigHierarchy.IsParentedTo
struct RigHierarchy_IsParentedTo_Params
{
	struct FRigElementKey                              InChild_69;                                               // (Parm)
	struct FRigElementKey                              InParent_69;                                              // (Parm)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function ControlRig.RigHierarchy.IsCurveValueSetByIndex
struct RigHierarchy_IsCurveValueSetByIndex_Params
{
	int                                                InElementIndex_69;                                        // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function ControlRig.RigHierarchy.IsCurveValueSet
struct RigHierarchy_IsCurveValueSet_Params
{
	struct FRigElementKey                              InKey_69;                                                 // (Parm)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function ControlRig.RigHierarchy.IsControllerAvailable
struct RigHierarchy_IsControllerAvailable_Params
{
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function ControlRig.RigHierarchy.HasTag
struct RigHierarchy_HasTag_Params
{
	struct FRigElementKey                              InItem_69;                                                // (Parm)
	struct FName                                       InTag_69;                                                 // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function ControlRig.RigHierarchy.GetVectorMetadata
struct RigHierarchy_GetVectorMetadata_Params
{
	struct FRigElementKey                              InItem_69;                                                // (Parm)
	struct FName                                       InMetadataName_69;                                        // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector                                     DefaultValue_69;                                          // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector                                     ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function ControlRig.RigHierarchy.GetVectorFromControlValue
struct RigHierarchy_GetVectorFromControlValue_Params
{
	struct FRigControlValue                            InValue_69;                                               // (Parm)
	struct FVector                                     ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function ControlRig.RigHierarchy.GetVectorArrayMetadata
struct RigHierarchy_GetVectorArrayMetadata_Params
{
	struct FRigElementKey                              InItem_69;                                                // (Parm)
	struct FName                                       InMetadataName_69;                                        // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<struct FVector>                             ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function ControlRig.RigHierarchy.GetVector2DFromControlValue
struct RigHierarchy_GetVector2DFromControlValue_Params
{
	struct FRigControlValue                            InValue_69;                                               // (Parm)
	struct FVector2D                                   ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function ControlRig.RigHierarchy.GetTransformNoScaleFromControlValue
struct RigHierarchy_GetTransformNoScaleFromControlValue_Params
{
	struct FRigControlValue                            InValue_69;                                               // (Parm)
	struct FTransformNoScale                           ReturnValue_69;                                           // (Parm, OutParm, ReturnParm)
};

// Function ControlRig.RigHierarchy.GetTransformMetadata
struct RigHierarchy_GetTransformMetadata_Params
{
	struct FRigElementKey                              InItem_69;                                                // (Parm)
	struct FName                                       InMetadataName_69;                                        // (Parm, ZeroConstructor, IsPlainOldData)
	struct FCoreUObject_FTransform                     DefaultValue_69;                                          // (Parm, IsPlainOldData)
	struct FCoreUObject_FTransform                     ReturnValue_69;                                           // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function ControlRig.RigHierarchy.GetTransformFromControlValue
struct RigHierarchy_GetTransformFromControlValue_Params
{
	struct FRigControlValue                            InValue_69;                                               // (Parm)
	struct FCoreUObject_FTransform                     ReturnValue_69;                                           // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function ControlRig.RigHierarchy.GetTransformArrayMetadata
struct RigHierarchy_GetTransformArrayMetadata_Params
{
	struct FRigElementKey                              InItem_69;                                                // (Parm)
	struct FName                                       InMetadataName_69;                                        // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<struct FCoreUObject_FTransform>             ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function ControlRig.RigHierarchy.GetTags
struct RigHierarchy_GetTags_Params
{
	struct FRigElementKey                              InItem_69;                                                // (Parm)
	TArray<struct FName>                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function ControlRig.RigHierarchy.GetSelectedKeys
struct RigHierarchy_GetSelectedKeys_Params
{
	ERigElementType                                    InTypeFilter_69;                                          // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<struct FRigElementKey>                      ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function ControlRig.RigHierarchy.GetRotatorMetadata
struct RigHierarchy_GetRotatorMetadata_Params
{
	struct FRigElementKey                              InItem_69;                                                // (Parm)
	struct FName                                       InMetadataName_69;                                        // (Parm, ZeroConstructor, IsPlainOldData)
	struct FRotator                                    DefaultValue_69;                                          // (Parm, ZeroConstructor, IsPlainOldData)
	struct FRotator                                    ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function ControlRig.RigHierarchy.GetRotatorFromControlValue
struct RigHierarchy_GetRotatorFromControlValue_Params
{
	struct FRigControlValue                            InValue_69;                                               // (Parm)
	struct FRotator                                    ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function ControlRig.RigHierarchy.GetRotatorArrayMetadata
struct RigHierarchy_GetRotatorArrayMetadata_Params
{
	struct FRigElementKey                              InItem_69;                                                // (Parm)
	struct FName                                       InMetadataName_69;                                        // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<struct FRotator>                            ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function ControlRig.RigHierarchy.GetRigidBodyKeys
struct RigHierarchy_GetRigidBodyKeys_Params
{
	bool                                               bTraverse_69;                                             // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<struct FRigElementKey>                      ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function ControlRig.RigHierarchy.GetRigElementKeyMetadata
struct RigHierarchy_GetRigElementKeyMetadata_Params
{
	struct FRigElementKey                              InItem_69;                                                // (Parm)
	struct FName                                       InMetadataName_69;                                        // (Parm, ZeroConstructor, IsPlainOldData)
	struct FRigElementKey                              DefaultValue_69;                                          // (Parm)
	struct FRigElementKey                              ReturnValue_69;                                           // (Parm, OutParm, ReturnParm)
};

// Function ControlRig.RigHierarchy.GetRigElementKeyArrayMetadata
struct RigHierarchy_GetRigElementKeyArrayMetadata_Params
{
	struct FRigElementKey                              InItem_69;                                                // (Parm)
	struct FName                                       InMetadataName_69;                                        // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<struct FRigElementKey>                      ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function ControlRig.RigHierarchy.GetReferenceKeys
struct RigHierarchy_GetReferenceKeys_Params
{
	bool                                               bTraverse_69;                                             // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<struct FRigElementKey>                      ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function ControlRig.RigHierarchy.GetQuatMetadata
struct RigHierarchy_GetQuatMetadata_Params
{
	struct FRigElementKey                              InItem_69;                                                // (Parm)
	struct FName                                       InMetadataName_69;                                        // (Parm, ZeroConstructor, IsPlainOldData)
	struct FQuat                                       DefaultValue_69;                                          // (Parm, IsPlainOldData)
	struct FQuat                                       ReturnValue_69;                                           // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function ControlRig.RigHierarchy.GetQuatArrayMetadata
struct RigHierarchy_GetQuatArrayMetadata_Params
{
	struct FRigElementKey                              InItem_69;                                                // (Parm)
	struct FName                                       InMetadataName_69;                                        // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<struct FQuat>                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function ControlRig.RigHierarchy.GetPreviousParent
struct RigHierarchy_GetPreviousParent_Params
{
	struct FRigElementKey                              InKey_69;                                                 // (ConstParm, Parm, OutParm, ReferenceParm)
	struct FRigElementKey                              ReturnValue_69;                                           // (Parm, OutParm, ReturnParm)
};

// Function ControlRig.RigHierarchy.GetPreviousName
struct RigHierarchy_GetPreviousName_Params
{
	struct FRigElementKey                              InKey_69;                                                 // (ConstParm, Parm, OutParm, ReferenceParm)
	struct FName                                       ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function ControlRig.RigHierarchy.GetPose
struct RigHierarchy_GetPose_Params
{
	bool                                               bInitial_69;                                              // (Parm, ZeroConstructor, IsPlainOldData)
	struct FRigPose                                    ReturnValue_69;                                           // (Parm, OutParm, ReturnParm)
};

// Function ControlRig.RigHierarchy.GetParentWeightArray
struct RigHierarchy_GetParentWeightArray_Params
{
	struct FRigElementKey                              InChild_69;                                               // (Parm)
	bool                                               bInitial_69;                                              // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<struct FRigElementWeight>                   ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function ControlRig.RigHierarchy.GetParentWeight
struct RigHierarchy_GetParentWeight_Params
{
	struct FRigElementKey                              InChild_69;                                               // (Parm)
	struct FRigElementKey                              InParent_69;                                              // (Parm)
	bool                                               bInitial_69;                                              // (Parm, ZeroConstructor, IsPlainOldData)
	struct FRigElementWeight                           ReturnValue_69;                                           // (Parm, OutParm, ReturnParm)
};

// Function ControlRig.RigHierarchy.GetParentTransformByIndex
struct RigHierarchy_GetParentTransformByIndex_Params
{
	int                                                InElementIndex_69;                                        // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bInitial_69;                                              // (Parm, ZeroConstructor, IsPlainOldData)
	struct FCoreUObject_FTransform                     ReturnValue_69;                                           // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function ControlRig.RigHierarchy.GetParentTransform
struct RigHierarchy_GetParentTransform_Params
{
	struct FRigElementKey                              InKey_69;                                                 // (Parm)
	bool                                               bInitial_69;                                              // (Parm, ZeroConstructor, IsPlainOldData)
	struct FCoreUObject_FTransform                     ReturnValue_69;                                           // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function ControlRig.RigHierarchy.GetParents
struct RigHierarchy_GetParents_Params
{
	struct FRigElementKey                              InKey_69;                                                 // (Parm)
	bool                                               bRecursive_69;                                            // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<struct FRigElementKey>                      ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function ControlRig.RigHierarchy.GetNumberOfParents
struct RigHierarchy_GetNumberOfParents_Params
{
	struct FRigElementKey                              InKey_69;                                                 // (Parm)
	int                                                ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function ControlRig.RigHierarchy.GetNullKeys
struct RigHierarchy_GetNullKeys_Params
{
	bool                                               bTraverse_69;                                             // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<struct FRigElementKey>                      ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function ControlRig.RigHierarchy.GetNameMetadata
struct RigHierarchy_GetNameMetadata_Params
{
	struct FRigElementKey                              InItem_69;                                                // (Parm)
	struct FName                                       InMetadataName_69;                                        // (Parm, ZeroConstructor, IsPlainOldData)
	struct FName                                       DefaultValue_69;                                          // (Parm, ZeroConstructor, IsPlainOldData)
	struct FName                                       ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function ControlRig.RigHierarchy.GetNameArrayMetadata
struct RigHierarchy_GetNameArrayMetadata_Params
{
	struct FRigElementKey                              InItem_69;                                                // (Parm)
	struct FName                                       InMetadataName_69;                                        // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<struct FName>                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function ControlRig.RigHierarchy.GetMetadataType
struct RigHierarchy_GetMetadataType_Params
{
	struct FRigElementKey                              InItem_69;                                                // (Parm)
	struct FName                                       InMetadataName_69;                                        // (Parm, ZeroConstructor, IsPlainOldData)
	ERigMetadataType                                   ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function ControlRig.RigHierarchy.GetMetadataNames
struct RigHierarchy_GetMetadataNames_Params
{
	struct FRigElementKey                              InItem_69;                                                // (Parm)
	TArray<struct FName>                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function ControlRig.RigHierarchy.GetLocalTransformByIndex
struct RigHierarchy_GetLocalTransformByIndex_Params
{
	int                                                InElementIndex_69;                                        // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bInitial_69;                                              // (Parm, ZeroConstructor, IsPlainOldData)
	struct FCoreUObject_FTransform                     ReturnValue_69;                                           // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function ControlRig.RigHierarchy.GetLocalTransform
struct RigHierarchy_GetLocalTransform_Params
{
	struct FRigElementKey                              InKey_69;                                                 // (Parm)
	bool                                               bInitial_69;                                              // (Parm, ZeroConstructor, IsPlainOldData)
	struct FCoreUObject_FTransform                     ReturnValue_69;                                           // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function ControlRig.RigHierarchy.GetLocalControlShapeTransformByIndex
struct RigHierarchy_GetLocalControlShapeTransformByIndex_Params
{
	int                                                InElementIndex_69;                                        // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bInitial_69;                                              // (Parm, ZeroConstructor, IsPlainOldData)
	struct FCoreUObject_FTransform                     ReturnValue_69;                                           // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function ControlRig.RigHierarchy.GetLocalControlShapeTransform
struct RigHierarchy_GetLocalControlShapeTransform_Params
{
	struct FRigElementKey                              InKey_69;                                                 // (Parm)
	bool                                               bInitial_69;                                              // (Parm, ZeroConstructor, IsPlainOldData)
	struct FCoreUObject_FTransform                     ReturnValue_69;                                           // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function ControlRig.RigHierarchy.GetLinearColorMetadata
struct RigHierarchy_GetLinearColorMetadata_Params
{
	struct FRigElementKey                              InItem_69;                                                // (Parm)
	struct FName                                       InMetadataName_69;                                        // (Parm, ZeroConstructor, IsPlainOldData)
	struct FLinearColor                                DefaultValue_69;                                          // (Parm, ZeroConstructor, IsPlainOldData)
	struct FLinearColor                                ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function ControlRig.RigHierarchy.GetLinearColorArrayMetadata
struct RigHierarchy_GetLinearColorArrayMetadata_Params
{
	struct FRigElementKey                              InItem_69;                                                // (Parm)
	struct FName                                       InMetadataName_69;                                        // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<struct FLinearColor>                        ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function ControlRig.RigHierarchy.GetKeys
struct RigHierarchy_GetKeys_Params
{
	TArray<int>                                        InElementIndices_69;                                      // (ConstParm, Parm, ZeroConstructor)
	TArray<struct FRigElementKey>                      ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function ControlRig.RigHierarchy.GetKey
struct RigHierarchy_GetKey_Params
{
	int                                                InElementIndex_69;                                        // (Parm, ZeroConstructor, IsPlainOldData)
	struct FRigElementKey                              ReturnValue_69;                                           // (Parm, OutParm, ReturnParm)
};

// Function ControlRig.RigHierarchy.GetIntFromControlValue
struct RigHierarchy_GetIntFromControlValue_Params
{
	struct FRigControlValue                            InValue_69;                                               // (Parm)
	int                                                ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function ControlRig.RigHierarchy.GetInt32Metadata
struct RigHierarchy_GetInt32Metadata_Params
{
	struct FRigElementKey                              InItem_69;                                                // (Parm)
	struct FName                                       InMetadataName_69;                                        // (Parm, ZeroConstructor, IsPlainOldData)
	int                                                DefaultValue_69;                                          // (Parm, ZeroConstructor, IsPlainOldData)
	int                                                ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function ControlRig.RigHierarchy.GetInt32ArrayMetadata
struct RigHierarchy_GetInt32ArrayMetadata_Params
{
	struct FRigElementKey                              InItem_69;                                                // (Parm)
	struct FName                                       InMetadataName_69;                                        // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<int>                                        ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function ControlRig.RigHierarchy.GetIndex_ForBlueprint
struct RigHierarchy_GetIndex_ForBlueprint_Params
{
	struct FRigElementKey                              InKey_69;                                                 // (Parm)
	int                                                ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function ControlRig.RigHierarchy.GetGlobalTransformByIndex
struct RigHierarchy_GetGlobalTransformByIndex_Params
{
	int                                                InElementIndex_69;                                        // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bInitial_69;                                              // (Parm, ZeroConstructor, IsPlainOldData)
	struct FCoreUObject_FTransform                     ReturnValue_69;                                           // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function ControlRig.RigHierarchy.GetGlobalTransform
struct RigHierarchy_GetGlobalTransform_Params
{
	struct FRigElementKey                              InKey_69;                                                 // (Parm)
	bool                                               bInitial_69;                                              // (Parm, ZeroConstructor, IsPlainOldData)
	struct FCoreUObject_FTransform                     ReturnValue_69;                                           // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function ControlRig.RigHierarchy.GetGlobalControlShapeTransformByIndex
struct RigHierarchy_GetGlobalControlShapeTransformByIndex_Params
{
	int                                                InElementIndex_69;                                        // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bInitial_69;                                              // (Parm, ZeroConstructor, IsPlainOldData)
	struct FCoreUObject_FTransform                     ReturnValue_69;                                           // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function ControlRig.RigHierarchy.GetGlobalControlShapeTransform
struct RigHierarchy_GetGlobalControlShapeTransform_Params
{
	struct FRigElementKey                              InKey_69;                                                 // (Parm)
	bool                                               bInitial_69;                                              // (Parm, ZeroConstructor, IsPlainOldData)
	struct FCoreUObject_FTransform                     ReturnValue_69;                                           // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function ControlRig.RigHierarchy.GetGlobalControlOffsetTransformByIndex
struct RigHierarchy_GetGlobalControlOffsetTransformByIndex_Params
{
	int                                                InElementIndex_69;                                        // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bInitial_69;                                              // (Parm, ZeroConstructor, IsPlainOldData)
	struct FCoreUObject_FTransform                     ReturnValue_69;                                           // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function ControlRig.RigHierarchy.GetGlobalControlOffsetTransform
struct RigHierarchy_GetGlobalControlOffsetTransform_Params
{
	struct FRigElementKey                              InKey_69;                                                 // (Parm)
	bool                                               bInitial_69;                                              // (Parm, ZeroConstructor, IsPlainOldData)
	struct FCoreUObject_FTransform                     ReturnValue_69;                                           // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function ControlRig.RigHierarchy.GetFloatMetadata
struct RigHierarchy_GetFloatMetadata_Params
{
	struct FRigElementKey                              InItem_69;                                                // (Parm)
	struct FName                                       InMetadataName_69;                                        // (Parm, ZeroConstructor, IsPlainOldData)
	float                                              DefaultValue_69;                                          // (Parm, ZeroConstructor, IsPlainOldData)
	float                                              ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function ControlRig.RigHierarchy.GetFloatFromControlValue
struct RigHierarchy_GetFloatFromControlValue_Params
{
	struct FRigControlValue                            InValue_69;                                               // (Parm)
	float                                              ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function ControlRig.RigHierarchy.GetFloatArrayMetadata
struct RigHierarchy_GetFloatArrayMetadata_Params
{
	struct FRigElementKey                              InItem_69;                                                // (Parm)
	struct FName                                       InMetadataName_69;                                        // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<float>                                      ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function ControlRig.RigHierarchy.GetFirstParent
struct RigHierarchy_GetFirstParent_Params
{
	struct FRigElementKey                              InKey_69;                                                 // (Parm)
	struct FRigElementKey                              ReturnValue_69;                                           // (Parm, OutParm, ReturnParm)
};

// Function ControlRig.RigHierarchy.GetEulerTransformFromControlValue
struct RigHierarchy_GetEulerTransformFromControlValue_Params
{
	struct FRigControlValue                            InValue_69;                                               // (Parm)
	struct FEulerTransform                             ReturnValue_69;                                           // (Parm, OutParm, ReturnParm)
};

// Function ControlRig.RigHierarchy.GetDefaultParent
struct RigHierarchy_GetDefaultParent_Params
{
	struct FRigElementKey                              InKey_69;                                                 // (Parm)
	struct FRigElementKey                              ReturnValue_69;                                           // (Parm, OutParm, ReturnParm)
};

// Function ControlRig.RigHierarchy.GetCurveValueByIndex
struct RigHierarchy_GetCurveValueByIndex_Params
{
	int                                                InElementIndex_69;                                        // (Parm, ZeroConstructor, IsPlainOldData)
	float                                              ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function ControlRig.RigHierarchy.GetCurveValue
struct RigHierarchy_GetCurveValue_Params
{
	struct FRigElementKey                              InKey_69;                                                 // (Parm)
	float                                              ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function ControlRig.RigHierarchy.GetCurveKeys
struct RigHierarchy_GetCurveKeys_Params
{
	TArray<struct FRigElementKey>                      ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function ControlRig.RigHierarchy.GetControlValueByIndex
struct RigHierarchy_GetControlValueByIndex_Params
{
	int                                                InElementIndex_69;                                        // (Parm, ZeroConstructor, IsPlainOldData)
	ERigControlValueType                               InValueType_69;                                           // (Parm, ZeroConstructor, IsPlainOldData)
	struct FRigControlValue                            ReturnValue_69;                                           // (Parm, OutParm, ReturnParm)
};

// Function ControlRig.RigHierarchy.GetControlValue
struct RigHierarchy_GetControlValue_Params
{
	struct FRigElementKey                              InKey_69;                                                 // (Parm)
	ERigControlValueType                               InValueType_69;                                           // (Parm, ZeroConstructor, IsPlainOldData)
	struct FRigControlValue                            ReturnValue_69;                                           // (Parm, OutParm, ReturnParm)
};

// Function ControlRig.RigHierarchy.GetControlPreferredRotatorByIndex
struct RigHierarchy_GetControlPreferredRotatorByIndex_Params
{
	int                                                InElementIndex_69;                                        // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bInitial_69;                                              // (Parm, ZeroConstructor, IsPlainOldData)
	struct FRotator                                    ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function ControlRig.RigHierarchy.GetControlPreferredRotator
struct RigHierarchy_GetControlPreferredRotator_Params
{
	struct FRigElementKey                              InKey_69;                                                 // (Parm)
	bool                                               bInitial_69;                                              // (Parm, ZeroConstructor, IsPlainOldData)
	struct FRotator                                    ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function ControlRig.RigHierarchy.GetController
struct RigHierarchy_GetController_Params
{
	bool                                               bCreateIfNeeded_69;                                       // (Parm, ZeroConstructor, IsPlainOldData)
	class RigHierarchyController*                      ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function ControlRig.RigHierarchy.GetControlKeys
struct RigHierarchy_GetControlKeys_Params
{
	bool                                               bTraverse_69;                                             // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<struct FRigElementKey>                      ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function ControlRig.RigHierarchy.GetChildren
struct RigHierarchy_GetChildren_Params
{
	struct FRigElementKey                              InKey_69;                                                 // (Parm)
	bool                                               bRecursive_69;                                            // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<struct FRigElementKey>                      ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function ControlRig.RigHierarchy.GetBoolMetadata
struct RigHierarchy_GetBoolMetadata_Params
{
	struct FRigElementKey                              InItem_69;                                                // (Parm)
	struct FName                                       InMetadataName_69;                                        // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               DefaultValue_69;                                          // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function ControlRig.RigHierarchy.GetBoolArrayMetadata
struct RigHierarchy_GetBoolArrayMetadata_Params
{
	struct FRigElementKey                              InItem_69;                                                // (Parm)
	struct FName                                       InMetadataName_69;                                        // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<bool>                                       ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function ControlRig.RigHierarchy.GetBoneKeys
struct RigHierarchy_GetBoneKeys_Params
{
	bool                                               bTraverse_69;                                             // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<struct FRigElementKey>                      ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function ControlRig.RigHierarchy.GetAllKeys_ForBlueprint
struct RigHierarchy_GetAllKeys_ForBlueprint_Params
{
	bool                                               bTraverse_69;                                             // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<struct FRigElementKey>                      ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function ControlRig.RigHierarchy.FindNull_ForBlueprintOnly
struct RigHierarchy_FindNull_ForBlueprintOnly_Params
{
	struct FRigElementKey                              InKey_69;                                                 // (ConstParm, Parm, OutParm, ReferenceParm)
	struct FRigNullElement                             ReturnValue_69;                                           // (Parm, OutParm, ReturnParm)
};

// Function ControlRig.RigHierarchy.FindControl_ForBlueprintOnly
struct RigHierarchy_FindControl_ForBlueprintOnly_Params
{
	struct FRigElementKey                              InKey_69;                                                 // (ConstParm, Parm, OutParm, ReferenceParm)
	struct FRigControlElement                          ReturnValue_69;                                           // (Parm, OutParm, ReturnParm)
};

// Function ControlRig.RigHierarchy.FindBone_ForBlueprintOnly
struct RigHierarchy_FindBone_ForBlueprintOnly_Params
{
	struct FRigElementKey                              InKey_69;                                                 // (ConstParm, Parm, OutParm, ReferenceParm)
	struct FRigBoneElement                             ReturnValue_69;                                           // (Parm, OutParm, ReturnParm)
};

// Function ControlRig.RigHierarchy.CopyPose
struct RigHierarchy_CopyPose_Params
{
	class RigHierarchy*                                InHierarchy_69;                                           // (Parm, ZeroConstructor)
	bool                                               bCurrent_69;                                              // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bInitial_69;                                              // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bWeights_69;                                              // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bMatchPoseInGlobalIfNeeded_69;                            // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function ControlRig.RigHierarchy.CopyHierarchy
struct RigHierarchy_CopyHierarchy_Params
{
	class RigHierarchy*                                InHierarchy_69;                                           // (Parm, ZeroConstructor)
};

// Function ControlRig.RigHierarchy.Contains_ForBlueprint
struct RigHierarchy_Contains_ForBlueprint_Params
{
	struct FRigElementKey                              InKey_69;                                                 // (Parm)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function ControlRig.ControlRigComponent.Update
struct ControlRigComponent_Update_Params
{
	float                                              DeltaTime_69;                                             // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function ControlRig.ControlRigComponent.SetObjectBinding
struct ControlRigComponent_SetObjectBinding_Params
{
	class Object_32759*                                InObjectToBind_69;                                        // (Parm, ZeroConstructor)
};

// Function ControlRig.ControlRigComponent.SetMappedElements
struct ControlRigComponent_SetMappedElements_Params
{
	TArray<struct FControlRigComponentMappedElement>   NewMappedElements_69;                                     // (Parm, ZeroConstructor)
};

// Function ControlRig.ControlRigComponent.SetInitialSpaceTransform
struct ControlRigComponent_SetInitialSpaceTransform_Params
{
	struct FName                                       SpaceName_69;                                             // (Parm, ZeroConstructor, IsPlainOldData)
	struct FCoreUObject_FTransform                     InitialTransform_69;                                      // (Parm, IsPlainOldData)
	EControlRigComponentSpace                          Space_69;                                                 // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function ControlRig.ControlRigComponent.SetInitialBoneTransform
struct ControlRigComponent_SetInitialBoneTransform_Params
{
	struct FName                                       BoneName_69;                                              // (Parm, ZeroConstructor, IsPlainOldData)
	struct FCoreUObject_FTransform                     InitialTransform_69;                                      // (Parm, IsPlainOldData)
	EControlRigComponentSpace                          Space_69;                                                 // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bPropagateToChildren_69;                                  // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function ControlRig.ControlRigComponent.SetControlVector2D
struct ControlRigComponent_SetControlVector2D_Params
{
	struct FName                                       ControlName_69;                                           // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector2D                                   Value_69;                                                 // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function ControlRig.ControlRigComponent.SetControlTransform
struct ControlRigComponent_SetControlTransform_Params
{
	struct FName                                       ControlName_69;                                           // (Parm, ZeroConstructor, IsPlainOldData)
	struct FCoreUObject_FTransform                     Value_69;                                                 // (Parm, IsPlainOldData)
	EControlRigComponentSpace                          Space_69;                                                 // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function ControlRig.ControlRigComponent.SetControlScale
struct ControlRigComponent_SetControlScale_Params
{
	struct FName                                       ControlName_69;                                           // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector                                     Value_69;                                                 // (Parm, ZeroConstructor, IsPlainOldData)
	EControlRigComponentSpace                          Space_69;                                                 // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function ControlRig.ControlRigComponent.SetControlRotator
struct ControlRigComponent_SetControlRotator_Params
{
	struct FName                                       ControlName_69;                                           // (Parm, ZeroConstructor, IsPlainOldData)
	struct FRotator                                    Value_69;                                                 // (Parm, ZeroConstructor, IsPlainOldData)
	EControlRigComponentSpace                          Space_69;                                                 // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function ControlRig.ControlRigComponent.SetControlRigClass
struct ControlRigComponent_SetControlRigClass_Params
{
	class ControlRig*                                  InControlRigClass_69;                                     // (Parm, ZeroConstructor)
};

// Function ControlRig.ControlRigComponent.SetControlPosition
struct ControlRigComponent_SetControlPosition_Params
{
	struct FName                                       ControlName_69;                                           // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector                                     Value_69;                                                 // (Parm, ZeroConstructor, IsPlainOldData)
	EControlRigComponentSpace                          Space_69;                                                 // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function ControlRig.ControlRigComponent.SetControlOffset
struct ControlRigComponent_SetControlOffset_Params
{
	struct FName                                       ControlName_69;                                           // (Parm, ZeroConstructor, IsPlainOldData)
	struct FCoreUObject_FTransform                     OffsetTransform_69;                                       // (Parm, IsPlainOldData)
	EControlRigComponentSpace                          Space_69;                                                 // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function ControlRig.ControlRigComponent.SetControlInt
struct ControlRigComponent_SetControlInt_Params
{
	struct FName                                       ControlName_69;                                           // (Parm, ZeroConstructor, IsPlainOldData)
	int                                                Value_69;                                                 // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function ControlRig.ControlRigComponent.SetControlFloat
struct ControlRigComponent_SetControlFloat_Params
{
	struct FName                                       ControlName_69;                                           // (Parm, ZeroConstructor, IsPlainOldData)
	float                                              Value_69;                                                 // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function ControlRig.ControlRigComponent.SetControlBool
struct ControlRigComponent_SetControlBool_Params
{
	struct FName                                       ControlName_69;                                           // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               Value_69;                                                 // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function ControlRig.ControlRigComponent.SetBoneTransform
struct ControlRigComponent_SetBoneTransform_Params
{
	struct FName                                       BoneName_69;                                              // (Parm, ZeroConstructor, IsPlainOldData)
	struct FCoreUObject_FTransform                     Transform_69;                                             // (Parm, IsPlainOldData)
	EControlRigComponentSpace                          Space_69;                                                 // (Parm, ZeroConstructor, IsPlainOldData)
	float                                              Weight_69;                                                // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bPropagateToChildren_69;                                  // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function ControlRig.ControlRigComponent.SetBoneInitialTransformsFromSkeletalMesh
struct ControlRigComponent_SetBoneInitialTransformsFromSkeletalMesh_Params
{
	class SkeletalMesh*                                InSkeletalMesh_69;                                        // (Parm, ZeroConstructor)
};

// Function ControlRig.ControlRigComponent.OnPreInitialize
struct ControlRigComponent_OnPreInitialize_Params
{
	class ControlRigComponent*                         Component_69;                                             // (Parm, ZeroConstructor, InstancedReference)
};

// Function ControlRig.ControlRigComponent.OnPreForwardsSolve
struct ControlRigComponent_OnPreForwardsSolve_Params
{
	class ControlRigComponent*                         Component_69;                                             // (Parm, ZeroConstructor, InstancedReference)
};

// Function ControlRig.ControlRigComponent.OnPreConstruction
struct ControlRigComponent_OnPreConstruction_Params
{
	class ControlRigComponent*                         Component_69;                                             // (Parm, ZeroConstructor, InstancedReference)
};

// Function ControlRig.ControlRigComponent.OnPostInitialize
struct ControlRigComponent_OnPostInitialize_Params
{
	class ControlRigComponent*                         Component_69;                                             // (Parm, ZeroConstructor, InstancedReference)
};

// Function ControlRig.ControlRigComponent.OnPostForwardsSolve
struct ControlRigComponent_OnPostForwardsSolve_Params
{
	class ControlRigComponent*                         Component_69;                                             // (Parm, ZeroConstructor, InstancedReference)
};

// Function ControlRig.ControlRigComponent.OnPostConstruction
struct ControlRigComponent_OnPostConstruction_Params
{
	class ControlRigComponent*                         Component_69;                                             // (Parm, ZeroConstructor, InstancedReference)
};

// Function ControlRig.ControlRigComponent.Initialize
struct ControlRigComponent_Initialize_Params
{
};

// Function ControlRig.ControlRigComponent.GetSpaceTransform
struct ControlRigComponent_GetSpaceTransform_Params
{
	struct FName                                       SpaceName_69;                                             // (Parm, ZeroConstructor, IsPlainOldData)
	EControlRigComponentSpace                          Space_69;                                                 // (Parm, ZeroConstructor, IsPlainOldData)
	struct FCoreUObject_FTransform                     ReturnValue_69;                                           // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function ControlRig.ControlRigComponent.GetInitialSpaceTransform
struct ControlRigComponent_GetInitialSpaceTransform_Params
{
	struct FName                                       SpaceName_69;                                             // (Parm, ZeroConstructor, IsPlainOldData)
	EControlRigComponentSpace                          Space_69;                                                 // (Parm, ZeroConstructor, IsPlainOldData)
	struct FCoreUObject_FTransform                     ReturnValue_69;                                           // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function ControlRig.ControlRigComponent.GetInitialBoneTransform
struct ControlRigComponent_GetInitialBoneTransform_Params
{
	struct FName                                       BoneName_69;                                              // (Parm, ZeroConstructor, IsPlainOldData)
	EControlRigComponentSpace                          Space_69;                                                 // (Parm, ZeroConstructor, IsPlainOldData)
	struct FCoreUObject_FTransform                     ReturnValue_69;                                           // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function ControlRig.ControlRigComponent.GetElementNames
struct ControlRigComponent_GetElementNames_Params
{
	ERigElementType                                    ElementType_69;                                           // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<struct FName>                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function ControlRig.ControlRigComponent.GetControlVector2D
struct ControlRigComponent_GetControlVector2D_Params
{
	struct FName                                       ControlName_69;                                           // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector2D                                   ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function ControlRig.ControlRigComponent.GetControlTransform
struct ControlRigComponent_GetControlTransform_Params
{
	struct FName                                       ControlName_69;                                           // (Parm, ZeroConstructor, IsPlainOldData)
	EControlRigComponentSpace                          Space_69;                                                 // (Parm, ZeroConstructor, IsPlainOldData)
	struct FCoreUObject_FTransform                     ReturnValue_69;                                           // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function ControlRig.ControlRigComponent.GetControlScale
struct ControlRigComponent_GetControlScale_Params
{
	struct FName                                       ControlName_69;                                           // (Parm, ZeroConstructor, IsPlainOldData)
	EControlRigComponentSpace                          Space_69;                                                 // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector                                     ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function ControlRig.ControlRigComponent.GetControlRotator
struct ControlRigComponent_GetControlRotator_Params
{
	struct FName                                       ControlName_69;                                           // (Parm, ZeroConstructor, IsPlainOldData)
	EControlRigComponentSpace                          Space_69;                                                 // (Parm, ZeroConstructor, IsPlainOldData)
	struct FRotator                                    ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function ControlRig.ControlRigComponent.GetControlRig
struct ControlRigComponent_GetControlRig_Params
{
	class ControlRig*                                  ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function ControlRig.ControlRigComponent.GetControlPosition
struct ControlRigComponent_GetControlPosition_Params
{
	struct FName                                       ControlName_69;                                           // (Parm, ZeroConstructor, IsPlainOldData)
	EControlRigComponentSpace                          Space_69;                                                 // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector                                     ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function ControlRig.ControlRigComponent.GetControlOffset
struct ControlRigComponent_GetControlOffset_Params
{
	struct FName                                       ControlName_69;                                           // (Parm, ZeroConstructor, IsPlainOldData)
	EControlRigComponentSpace                          Space_69;                                                 // (Parm, ZeroConstructor, IsPlainOldData)
	struct FCoreUObject_FTransform                     ReturnValue_69;                                           // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function ControlRig.ControlRigComponent.GetControlInt
struct ControlRigComponent_GetControlInt_Params
{
	struct FName                                       ControlName_69;                                           // (Parm, ZeroConstructor, IsPlainOldData)
	int                                                ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function ControlRig.ControlRigComponent.GetControlFloat
struct ControlRigComponent_GetControlFloat_Params
{
	struct FName                                       ControlName_69;                                           // (Parm, ZeroConstructor, IsPlainOldData)
	float                                              ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function ControlRig.ControlRigComponent.GetControlBool
struct ControlRigComponent_GetControlBool_Params
{
	struct FName                                       ControlName_69;                                           // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function ControlRig.ControlRigComponent.GetBoneTransform
struct ControlRigComponent_GetBoneTransform_Params
{
	struct FName                                       BoneName_69;                                              // (Parm, ZeroConstructor, IsPlainOldData)
	EControlRigComponentSpace                          Space_69;                                                 // (Parm, ZeroConstructor, IsPlainOldData)
	struct FCoreUObject_FTransform                     ReturnValue_69;                                           // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function ControlRig.ControlRigComponent.GetAbsoluteTime
struct ControlRigComponent_GetAbsoluteTime_Params
{
	float                                              ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function ControlRig.ControlRigComponent.DoesElementExist
struct ControlRigComponent_DoesElementExist_Params
{
	struct FName                                       Name_69;                                                  // (Parm, ZeroConstructor, IsPlainOldData)
	ERigElementType                                    ElementType_69;                                           // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function ControlRig.ControlRigComponent.ClearMappedElements
struct ControlRigComponent_ClearMappedElements_Params
{
};

// Function ControlRig.ControlRigComponent.CanExecute
struct ControlRigComponent_CanExecute_Params
{
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function ControlRig.ControlRigComponent.AddMappedSkeletalMesh
struct ControlRigComponent_AddMappedSkeletalMesh_Params
{
	class SkeletalMeshComponent*                       SkeletalMeshComponent_69;                                 // (Parm, ZeroConstructor, InstancedReference)
	TArray<struct FControlRigComponentMappedBone>      Bones_69;                                                 // (Parm, ZeroConstructor)
	TArray<struct FControlRigComponentMappedCurve>     Curves_69;                                                // (Parm, ZeroConstructor)
};

// Function ControlRig.ControlRigComponent.AddMappedElements
struct ControlRigComponent_AddMappedElements_Params
{
	TArray<struct FControlRigComponentMappedElement>   NewMappedElements_69;                                     // (Parm, ZeroConstructor)
};

// Function ControlRig.ControlRigComponent.AddMappedComponents
struct ControlRigComponent_AddMappedComponents_Params
{
	TArray<struct FControlRigComponentMappedComponent> Components_69;                                            // (Parm, ZeroConstructor)
};

// Function ControlRig.ControlRigComponent.AddMappedCompleteSkeletalMesh
struct ControlRigComponent_AddMappedCompleteSkeletalMesh_Params
{
	class SkeletalMeshComponent*                       SkeletalMeshComponent_69;                                 // (Parm, ZeroConstructor, InstancedReference)
};

// Function ControlRig.ControlRigControlActor_32759.Refresh
struct ControlRigControlActor_32759_Refresh_Params
{
};

// Function ControlRig.ControlRigControlActor_32759.Clear
struct ControlRigControlActor_32759_Clear_Params
{
};

// Function ControlRig.ControlRigShapeActor.SetSelected
struct ControlRigShapeActor_SetSelected_Params
{
	bool                                               bInSelected_69;                                           // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function ControlRig.ControlRigShapeActor.SetSelectable
struct ControlRigShapeActor_SetSelectable_Params
{
	bool                                               bInSelectable_69;                                         // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function ControlRig.ControlRigShapeActor.SetHovered
struct ControlRigShapeActor_SetHovered_Params
{
	bool                                               bInHovered_69;                                            // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function ControlRig.ControlRigShapeActor.SetGlobalTransform
struct ControlRigShapeActor_SetGlobalTransform_Params
{
	struct FCoreUObject_FTransform                     InTransform_69;                                           // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
};

// Function ControlRig.ControlRigShapeActor.SetEnabled
struct ControlRigShapeActor_SetEnabled_Params
{
	bool                                               bInEnabled_69;                                            // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function ControlRig.ControlRigShapeActor.OnTransformChanged
struct ControlRigShapeActor_OnTransformChanged_Params
{
	struct FCoreUObject_FTransform                     NewTransform_69;                                          // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
};

// Function ControlRig.ControlRigShapeActor.OnSelectionChanged
struct ControlRigShapeActor_OnSelectionChanged_Params
{
	bool                                               bIsSelected_69;                                           // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function ControlRig.ControlRigShapeActor.OnManipulatingChanged
struct ControlRigShapeActor_OnManipulatingChanged_Params
{
	bool                                               bIsManipulating_69;                                       // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function ControlRig.ControlRigShapeActor.OnHoveredChanged
struct ControlRigShapeActor_OnHoveredChanged_Params
{
	bool                                               bIsSelected_69;                                           // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function ControlRig.ControlRigShapeActor.OnEnabledChanged
struct ControlRigShapeActor_OnEnabledChanged_Params
{
	bool                                               bIsEnabled_69;                                            // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function ControlRig.ControlRigShapeActor.IsSelectedInEditor
struct ControlRigShapeActor_IsSelectedInEditor_Params
{
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function ControlRig.ControlRigShapeActor.IsHovered
struct ControlRigShapeActor_IsHovered_Params
{
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function ControlRig.ControlRigShapeActor.IsEnabled
struct ControlRigShapeActor_IsEnabled_Params
{
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function ControlRig.ControlRigShapeActor.GetGlobalTransform
struct ControlRigShapeActor_GetGlobalTransform_Params
{
	struct FCoreUObject_FTransform                     ReturnValue_69;                                           // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function ControlRig.RigHierarchyController.SetSelection
struct RigHierarchyController_SetSelection_Params
{
	TArray<struct FRigElementKey>                      InKeys_69;                                                // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	bool                                               bPrintPythonCommand_69;                                   // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function ControlRig.RigHierarchyController.SetParent
struct RigHierarchyController_SetParent_Params
{
	struct FRigElementKey                              InChild_69;                                               // (Parm)
	struct FRigElementKey                              InParent_69;                                              // (Parm)
	bool                                               bMaintainGlobalTransform_69;                              // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bSetupUndo_69;                                            // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bPrintPythonCommand_69;                                   // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function ControlRig.RigHierarchyController.SetHierarchy
struct RigHierarchyController_SetHierarchy_Params
{
	class RigHierarchy*                                InHierarchy_69;                                           // (Parm, ZeroConstructor)
};

// Function ControlRig.RigHierarchyController.SetDisplayName
struct RigHierarchyController_SetDisplayName_Params
{
	struct FRigElementKey                              InControl_69;                                             // (Parm)
	struct FName                                       InDisplayName_69;                                         // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bRenameElement_69;                                        // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bSetupUndo_69;                                            // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bPrintPythonCommand_69;                                   // (Parm, ZeroConstructor, IsPlainOldData)
	struct FName                                       ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function ControlRig.RigHierarchyController.SetControlSettings
struct RigHierarchyController_SetControlSettings_Params
{
	struct FRigElementKey                              InKey_69;                                                 // (Parm)
	struct FRigControlSettings                         InSettings_69;                                            // (Parm)
	bool                                               bSetupUndo_69;                                            // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function ControlRig.RigHierarchyController.SelectElement
struct RigHierarchyController_SelectElement_Params
{
	struct FRigElementKey                              InKey_69;                                                 // (Parm)
	bool                                               bSelect_69;                                               // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bClearSelection_69;                                       // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function ControlRig.RigHierarchyController.RenameElement
struct RigHierarchyController_RenameElement_Params
{
	struct FRigElementKey                              InElement_69;                                             // (Parm)
	struct FName                                       InName_69;                                                // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bSetupUndo_69;                                            // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bPrintPythonCommand_69;                                   // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bClearSelection_69;                                       // (Parm, ZeroConstructor, IsPlainOldData)
	struct FRigElementKey                              ReturnValue_69;                                           // (Parm, OutParm, ReturnParm)
};

// Function ControlRig.RigHierarchyController.RemoveParent
struct RigHierarchyController_RemoveParent_Params
{
	struct FRigElementKey                              InChild_69;                                               // (Parm)
	struct FRigElementKey                              InParent_69;                                              // (Parm)
	bool                                               bMaintainGlobalTransform_69;                              // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bSetupUndo_69;                                            // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bPrintPythonCommand_69;                                   // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function ControlRig.RigHierarchyController.RemoveElement
struct RigHierarchyController_RemoveElement_Params
{
	struct FRigElementKey                              InElement_69;                                             // (Parm)
	bool                                               bSetupUndo_69;                                            // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bPrintPythonCommand_69;                                   // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function ControlRig.RigHierarchyController.RemoveAllParents
struct RigHierarchyController_RemoveAllParents_Params
{
	struct FRigElementKey                              InChild_69;                                               // (Parm)
	bool                                               bMaintainGlobalTransform_69;                              // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bSetupUndo_69;                                            // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bPrintPythonCommand_69;                                   // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function ControlRig.RigHierarchyController.MirrorElements
struct RigHierarchyController_MirrorElements_Params
{
	TArray<struct FRigElementKey>                      InKeys_69;                                                // (Parm, ZeroConstructor)
	struct FRigMirrorSettings                          InSettings_69;                                            // (Parm)
	bool                                               bSelectNewElements_69;                                    // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bSetupUndo_69;                                            // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bPrintPythonCommands_69;                                  // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<struct FRigElementKey>                      ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function ControlRig.RigHierarchyController.ImportFromText
struct RigHierarchyController_ImportFromText_Params
{
	struct FString                                     InContent_69;                                             // (Parm, ZeroConstructor)
	bool                                               bReplaceExistingElements_69;                              // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bSelectNewElements_69;                                    // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bSetupUndo_69;                                            // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bPrintPythonCommands_69;                                  // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<struct FRigElementKey>                      ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function ControlRig.RigHierarchyController.ImportCurves
struct RigHierarchyController_ImportCurves_Params
{
	class Skeleton*                                    InSkeleton_69;                                            // (Parm, ZeroConstructor)
	struct FName                                       InNameSpace_69;                                           // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bSelectCurves_69;                                         // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bSetupUndo_69;                                            // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bPrintPythonCommand_69;                                   // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<struct FRigElementKey>                      ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function ControlRig.RigHierarchyController.ImportBones
struct RigHierarchyController_ImportBones_Params
{
	class Skeleton*                                    InSkeleton_69;                                            // (Parm, ZeroConstructor)
	struct FName                                       InNameSpace_69;                                           // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bReplaceExistingBones_69;                                 // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bRemoveObsoleteBones_69;                                  // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bSelectBones_69;                                          // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bSetupUndo_69;                                            // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bPrintPythonCommand_69;                                   // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<struct FRigElementKey>                      ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function ControlRig.RigHierarchyController.GetHierarchy
struct RigHierarchyController_GetHierarchy_Params
{
	class RigHierarchy*                                ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function ControlRig.RigHierarchyController.GetControlSettings
struct RigHierarchyController_GetControlSettings_Params
{
	struct FRigElementKey                              InKey_69;                                                 // (Parm)
	struct FRigControlSettings                         ReturnValue_69;                                           // (Parm, OutParm, ReturnParm)
};

// Function ControlRig.RigHierarchyController.ExportToText
struct RigHierarchyController_ExportToText_Params
{
	TArray<struct FRigElementKey>                      InKeys_69;                                                // (Parm, ZeroConstructor)
	struct FString                                     ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function ControlRig.RigHierarchyController.ExportSelectionToText
struct RigHierarchyController_ExportSelectionToText_Params
{
	struct FString                                     ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function ControlRig.RigHierarchyController.DuplicateElements
struct RigHierarchyController_DuplicateElements_Params
{
	TArray<struct FRigElementKey>                      InKeys_69;                                                // (Parm, ZeroConstructor)
	bool                                               bSelectNewElements_69;                                    // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bSetupUndo_69;                                            // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bPrintPythonCommands_69;                                  // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<struct FRigElementKey>                      ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function ControlRig.RigHierarchyController.DeselectElement
struct RigHierarchyController_DeselectElement_Params
{
	struct FRigElementKey                              InKey_69;                                                 // (Parm)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function ControlRig.RigHierarchyController.ClearSelection
struct RigHierarchyController_ClearSelection_Params
{
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function ControlRig.RigHierarchyController.AddRigidBody
struct RigHierarchyController_AddRigidBody_Params
{
	struct FName                                       InName_69;                                                // (Parm, ZeroConstructor, IsPlainOldData)
	struct FRigElementKey                              InParent_69;                                              // (Parm)
	struct FRigRigidBodySettings                       InSettings_69;                                            // (Parm)
	struct FCoreUObject_FTransform                     InLocalTransform_69;                                      // (Parm, IsPlainOldData)
	bool                                               bSetupUndo_69;                                            // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bPrintPythonCommand_69;                                   // (Parm, ZeroConstructor, IsPlainOldData)
	struct FRigElementKey                              ReturnValue_69;                                           // (Parm, OutParm, ReturnParm)
};

// Function ControlRig.RigHierarchyController.AddParent
struct RigHierarchyController_AddParent_Params
{
	struct FRigElementKey                              InChild_69;                                               // (Parm)
	struct FRigElementKey                              InParent_69;                                              // (Parm)
	float                                              InWeight_69;                                              // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bMaintainGlobalTransform_69;                              // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bSetupUndo_69;                                            // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function ControlRig.RigHierarchyController.AddNull
struct RigHierarchyController_AddNull_Params
{
	struct FName                                       InName_69;                                                // (Parm, ZeroConstructor, IsPlainOldData)
	struct FRigElementKey                              InParent_69;                                              // (Parm)
	struct FCoreUObject_FTransform                     InTransform_69;                                           // (Parm, IsPlainOldData)
	bool                                               bTransformInGlobal_69;                                    // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bSetupUndo_69;                                            // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bPrintPythonCommand_69;                                   // (Parm, ZeroConstructor, IsPlainOldData)
	struct FRigElementKey                              ReturnValue_69;                                           // (Parm, OutParm, ReturnParm)
};

// Function ControlRig.RigHierarchyController.AddCurve
struct RigHierarchyController_AddCurve_Params
{
	struct FName                                       InName_69;                                                // (Parm, ZeroConstructor, IsPlainOldData)
	float                                              InValue_69;                                               // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bSetupUndo_69;                                            // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bPrintPythonCommand_69;                                   // (Parm, ZeroConstructor, IsPlainOldData)
	struct FRigElementKey                              ReturnValue_69;                                           // (Parm, OutParm, ReturnParm)
};

// Function ControlRig.RigHierarchyController.AddControl_ForBlueprint
struct RigHierarchyController_AddControl_ForBlueprint_Params
{
	struct FName                                       InName_69;                                                // (Parm, ZeroConstructor, IsPlainOldData)
	struct FRigElementKey                              InParent_69;                                              // (Parm)
	struct FRigControlSettings                         InSettings_69;                                            // (Parm)
	struct FRigControlValue                            InValue_69;                                               // (Parm)
	bool                                               bSetupUndo_69;                                            // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bPrintPythonCommand_69;                                   // (Parm, ZeroConstructor, IsPlainOldData)
	struct FRigElementKey                              ReturnValue_69;                                           // (Parm, OutParm, ReturnParm)
};

// Function ControlRig.RigHierarchyController.AddBone
struct RigHierarchyController_AddBone_Params
{
	struct FName                                       InName_69;                                                // (Parm, ZeroConstructor, IsPlainOldData)
	struct FRigElementKey                              InParent_69;                                              // (Parm)
	struct FCoreUObject_FTransform                     InTransform_69;                                           // (Parm, IsPlainOldData)
	bool                                               bTransformInGlobal_69;                                    // (Parm, ZeroConstructor, IsPlainOldData)
	ERigBoneType                                       InBoneType_69;                                            // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bSetupUndo_69;                                            // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bPrintPythonCommand_69;                                   // (Parm, ZeroConstructor, IsPlainOldData)
	struct FRigElementKey                              ReturnValue_69;                                           // (Parm, OutParm, ReturnParm)
};

// Function ControlRig.RigHierarchyController.AddAnimationChannel_ForBlueprint
struct RigHierarchyController_AddAnimationChannel_ForBlueprint_Params
{
	struct FName                                       InName_69;                                                // (Parm, ZeroConstructor, IsPlainOldData)
	struct FRigElementKey                              InParentControl_69;                                       // (Parm)
	struct FRigControlSettings                         InSettings_69;                                            // (Parm)
	bool                                               bSetupUndo_69;                                            // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bPrintPythonCommand_69;                                   // (Parm, ZeroConstructor, IsPlainOldData)
	struct FRigElementKey                              ReturnValue_69;                                           // (Parm, OutParm, ReturnParm)
};

// Function ControlRig.ControlRigPoseAsset.SelectControls
struct ControlRigPoseAsset_SelectControls_Params
{
	class ControlRig*                                  InControlRig_69;                                          // (Parm, ZeroConstructor)
	bool                                               bDoMirror_69;                                             // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function ControlRig.ControlRigPoseAsset.SavePose
struct ControlRigPoseAsset_SavePose_Params
{
	class ControlRig*                                  InControlRig_69;                                          // (Parm, ZeroConstructor)
	bool                                               bUseAll_69;                                               // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function ControlRig.ControlRigPoseAsset.ReplaceControlName
struct ControlRigPoseAsset_ReplaceControlName_Params
{
	struct FName                                       CurrentName_69;                                           // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
	struct FName                                       NewName_69;                                               // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
};

// Function ControlRig.ControlRigPoseAsset.PastePose
struct ControlRigPoseAsset_PastePose_Params
{
	class ControlRig*                                  InControlRig_69;                                          // (Parm, ZeroConstructor)
	bool                                               bDoKey_69;                                                // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bDoMirror_69;                                             // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function ControlRig.ControlRigPoseAsset.GetCurrentPose
struct ControlRigPoseAsset_GetCurrentPose_Params
{
	class ControlRig*                                  InControlRig_69;                                          // (Parm, ZeroConstructor)
	struct FControlRigControlPose                      OutPose_69;                                               // (Parm, OutParm)
};

// Function ControlRig.ControlRigPoseAsset.GetControlNames
struct ControlRigPoseAsset_GetControlNames_Params
{
	TArray<struct FName>                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function ControlRig.ControlRigPoseAsset.DoesMirrorMatch
struct ControlRigPoseAsset_DoesMirrorMatch_Params
{
	class ControlRig*                                  ControlRig_69;                                            // (Parm, ZeroConstructor)
	struct FName                                       ControlName_69;                                           // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function ControlRig.ControlRigWorkflowOptions.EnsureAtLeastOneRigElementSelected
struct ControlRigWorkflowOptions_EnsureAtLeastOneRigElementSelected_Params
{
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function ControlRig.ControlRigTransformWorkflowOptions.ProvideWorkflows
struct ControlRigTransformWorkflowOptions_ProvideWorkflows_Params
{
	class Object_32759*                                InSubject_69;                                             // (ConstParm, Parm, ZeroConstructor)
	TArray<struct FRigVMUserWorkflow>                  ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Functions
//---------------------------------------------------------------------------

// Function DistortedWeaponsUI.ChromeWeaponInfoWidget.OnWeaponUpgraded
// (Event, Protected, BlueprintEvent)

void ChromeWeaponInfoWidget::OnWeaponUpgraded()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DistortedWeaponsUI.ChromeWeaponInfoWidget.OnWeaponUpgraded"));

	ChromeWeaponInfoWidget_OnWeaponUpgraded_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function DistortedWeaponsUI.ChromeWeaponInfoWidget.OnWeaponStartUpgrading
// (Event, Protected, BlueprintEvent)

void ChromeWeaponInfoWidget::OnWeaponStartUpgrading()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DistortedWeaponsUI.ChromeWeaponInfoWidget.OnWeaponStartUpgrading"));

	ChromeWeaponInfoWidget_OnWeaponStartUpgrading_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function DistortedWeaponsUI.ChromeWeaponInfoWidget.OnWeaponRemoved
// (Event, Protected, BlueprintEvent)

void ChromeWeaponInfoWidget::OnWeaponRemoved()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DistortedWeaponsUI.ChromeWeaponInfoWidget.OnWeaponRemoved"));

	ChromeWeaponInfoWidget_OnWeaponRemoved_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function DistortedWeaponsUI.ChromeWeaponInfoWidget.OnWeaponEquipped
// (Event, Protected, BlueprintEvent)

void ChromeWeaponInfoWidget::OnWeaponEquipped()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DistortedWeaponsUI.ChromeWeaponInfoWidget.OnWeaponEquipped"));

	ChromeWeaponInfoWidget_OnWeaponEquipped_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function DistortedWeaponsUI.ChromeWeaponInfoWidget.OnReadyToUpgradeWeapon
// (Event, Protected, BlueprintEvent)
// Parameters:
// EFortRarity                    NextRarity_69                  (Parm, ZeroConstructor, IsPlainOldData)

void ChromeWeaponInfoWidget::OnReadyToUpgradeWeapon(EFortRarity NextRarity_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DistortedWeaponsUI.ChromeWeaponInfoWidget.OnReadyToUpgradeWeapon"));

	ChromeWeaponInfoWidget_OnReadyToUpgradeWeapon_Params params;
	params.NextRarity_69 = NextRarity_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function DistortedWeaponsUI.ChromeWeaponInfoWidget.OnGainedXp
// (Event, Protected, BlueprintEvent)
// Parameters:
// float                          CurrentXPPercentage_69         (Parm, ZeroConstructor, IsPlainOldData)

void ChromeWeaponInfoWidget::OnGainedXp(float CurrentXPPercentage_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DistortedWeaponsUI.ChromeWeaponInfoWidget.OnGainedXp"));

	ChromeWeaponInfoWidget_OnGainedXp_Params params;
	params.CurrentXPPercentage_69 = CurrentXPPercentage_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function DistortedWeaponsUI.ChromeWeaponInfoWidget.HandleXpChanged
// (Final, Native, Protected)
// Parameters:
// float                          XPDelta_69                     (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// float                          CurrentXPPercentage_69         (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void ChromeWeaponInfoWidget::HandleXpChanged(float XPDelta_69, float CurrentXPPercentage_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DistortedWeaponsUI.ChromeWeaponInfoWidget.HandleXpChanged"));

	ChromeWeaponInfoWidget_HandleXpChanged_Params params;
	params.XPDelta_69 = XPDelta_69;
	params.CurrentXPPercentage_69 = CurrentXPPercentage_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function DistortedWeaponsUI.ChromeWeaponInfoWidget.HandleWeaponUpgraded
// (Final, Native, Protected)

void ChromeWeaponInfoWidget::HandleWeaponUpgraded()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DistortedWeaponsUI.ChromeWeaponInfoWidget.HandleWeaponUpgraded"));

	ChromeWeaponInfoWidget_HandleWeaponUpgraded_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function DistortedWeaponsUI.ChromeWeaponInfoWidget.HandleWeaponUnEquipped
// (Final, Native, Protected)

void ChromeWeaponInfoWidget::HandleWeaponUnEquipped()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DistortedWeaponsUI.ChromeWeaponInfoWidget.HandleWeaponUnEquipped"));

	ChromeWeaponInfoWidget_HandleWeaponUnEquipped_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function DistortedWeaponsUI.ChromeWeaponInfoWidget.HandleWeaponEquipped
// (Final, Native, Protected)
// Parameters:
// class FortWeapon*              NewWeapon_69                   (Parm, ZeroConstructor)
// class FortWeapon*              PrevWeapon_69                  (Parm, ZeroConstructor)

void ChromeWeaponInfoWidget::HandleWeaponEquipped(class FortWeapon* NewWeapon_69, class FortWeapon* PrevWeapon_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DistortedWeaponsUI.ChromeWeaponInfoWidget.HandleWeaponEquipped"));

	ChromeWeaponInfoWidget_HandleWeaponEquipped_Params params;
	params.NewWeapon_69 = NewWeapon_69;
	params.PrevWeapon_69 = PrevWeapon_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function DistortedWeaponsUI.ChromeWeaponInfoWidget.HandleUpgradeTriggered
// (Final, Native, Protected)
// Parameters:
// float                          ReloadTime_69                  (Parm, ZeroConstructor, IsPlainOldData)
// EFortWeaponReloadType          ReloadType_69                  (Parm, ZeroConstructor, IsPlainOldData)

void ChromeWeaponInfoWidget::HandleUpgradeTriggered(float ReloadTime_69, EFortWeaponReloadType ReloadType_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DistortedWeaponsUI.ChromeWeaponInfoWidget.HandleUpgradeTriggered"));

	ChromeWeaponInfoWidget_HandleUpgradeTriggered_Params params;
	params.ReloadTime_69 = ReloadTime_69;
	params.ReloadType_69 = ReloadType_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function DistortedWeaponsUI.ChromeWeaponInfoWidget.HandlePowerUpPending
// (Final, Native, Protected)

void ChromeWeaponInfoWidget::HandlePowerUpPending()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DistortedWeaponsUI.ChromeWeaponInfoWidget.HandlePowerUpPending"));

	ChromeWeaponInfoWidget_HandlePowerUpPending_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function DistortedWeaponsUI.ChromeWeaponInfoWidget.GetCurrentWeaponRarity
// (Final, Native, Protected, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// EFortRarity                    ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

EFortRarity ChromeWeaponInfoWidget::GetCurrentWeaponRarity()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DistortedWeaponsUI.ChromeWeaponInfoWidget.GetCurrentWeaponRarity"));

	ChromeWeaponInfoWidget_GetCurrentWeaponRarity_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

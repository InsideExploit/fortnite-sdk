// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Functions
//---------------------------------------------------------------------------

// Function ChromeGameplayRuntime.ChromeWaterBodyComponent.ApplyChromeMaterialToOwner
// (Final, BlueprintCosmetic, Native, Protected, BlueprintCallable)

void ChromeWaterBodyComponent::ApplyChromeMaterialToOwner()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ChromeGameplayRuntime.ChromeWaterBodyComponent.ApplyChromeMaterialToOwner"));

	ChromeWaterBodyComponent_ApplyChromeMaterialToOwner_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

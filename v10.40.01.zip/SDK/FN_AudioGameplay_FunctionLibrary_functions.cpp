// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Functions
//---------------------------------------------------------------------------

// Function AudioGameplay_FunctionLibrary.AudioGameplay_FunctionLibrary_C.GetAudioForPlayerEvent
// (Static, Public, HasOutParms, BlueprintCallable, BlueprintEvent, BlueprintPure)
// Parameters:
// class Actor_32759*             Target_1                       (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor)
// class SoundBase*               _1P_Sound_1                    (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor)
// class SoundBase*               _3P_Sound_1                    (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor)
// class Object_32759*            __WorldContext_1               (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor)
// class SoundBase*               AudioAsset_1                   (Parm, OutParm, ZeroConstructor)

void AudioGameplay_FunctionLibrary_C::STATIC_GetAudioForPlayerEvent(class Actor_32759* Target_1, class SoundBase* _1P_Sound_1, class SoundBase* _3P_Sound_1, class Object_32759* __WorldContext_1, class SoundBase** AudioAsset_1)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioGameplay_FunctionLibrary.AudioGameplay_FunctionLibrary_C.GetAudioForPlayerEvent"));

	AudioGameplay_FunctionLibrary_C_GetAudioForPlayerEvent_Params params;
	params.Target_1 = Target_1;
	params._1P_Sound_1 = _1P_Sound_1;
	params._3P_Sound_1 = _3P_Sound_1;
	params.__WorldContext_1 = __WorldContext_1;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (AudioAsset_1 != nullptr)
		*AudioAsset_1 = params.AudioAsset_1;
}


// Function AudioGameplay_FunctionLibrary.AudioGameplay_FunctionLibrary_C.IsActorLocal
// (Static, Private, HasOutParms, HasDefaults, BlueprintCallable, BlueprintEvent, BlueprintPure)
// Parameters:
// class Actor_32759*             Actor_1                        (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor)
// class Object_32759*            __WorldContext_1               (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor)
// bool                           ReturnValue_1                  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool AudioGameplay_FunctionLibrary_C::STATIC_IsActorLocal(class Actor_32759* Actor_1, class Object_32759* __WorldContext_1)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioGameplay_FunctionLibrary.AudioGameplay_FunctionLibrary_C.IsActorLocal"));

	AudioGameplay_FunctionLibrary_C_IsActorLocal_Params params;
	params.Actor_1 = Actor_1;
	params.__WorldContext_1 = __WorldContext_1;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_1;
}


// Function AudioGameplay_FunctionLibrary.AudioGameplay_FunctionLibrary_C.GetAudioForDamageEvent
// (Static, Public, HasOutParms, BlueprintCallable, BlueprintEvent, BlueprintPure)
// Parameters:
// class Actor_32759*             Receiver_1                     (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor)
// class Actor_32759*             Instigator_1                   (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor)
// class SoundBase*               ReceiverSound_1                (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor)
// class SoundBase*               InstigatorSound_1              (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor)
// class SoundBase*               ObserverSound_1                (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor)
// class Object_32759*            __WorldContext_1               (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor)
// class SoundBase*               AudioAsset_1                   (Parm, OutParm, ZeroConstructor)

void AudioGameplay_FunctionLibrary_C::STATIC_GetAudioForDamageEvent(class Actor_32759* Receiver_1, class Actor_32759* Instigator_1, class SoundBase* ReceiverSound_1, class SoundBase* InstigatorSound_1, class SoundBase* ObserverSound_1, class Object_32759* __WorldContext_1, class SoundBase** AudioAsset_1)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioGameplay_FunctionLibrary.AudioGameplay_FunctionLibrary_C.GetAudioForDamageEvent"));

	AudioGameplay_FunctionLibrary_C_GetAudioForDamageEvent_Params params;
	params.Receiver_1 = Receiver_1;
	params.Instigator_1 = Instigator_1;
	params.ReceiverSound_1 = ReceiverSound_1;
	params.InstigatorSound_1 = InstigatorSound_1;
	params.ObserverSound_1 = ObserverSound_1;
	params.__WorldContext_1 = __WorldContext_1;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (AudioAsset_1 != nullptr)
		*AudioAsset_1 = params.AudioAsset_1;
}


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

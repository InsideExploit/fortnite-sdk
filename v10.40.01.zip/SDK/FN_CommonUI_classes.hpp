#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Classes
//---------------------------------------------------------------------------

// Class CommonUI.CommonStyleSheetTypeBase
// 0x0008 (0x0030 - 0x0028)
class CommonStyleSheetTypeBase : public Object_32759
{
public:
	bool                                               bIsEnabled_69;                                            // 0x0028(0x0001) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0029(0x0007) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CommonUI.CommonStyleSheetTypeBase"));
		
		return ptr;
	}

};


// Class CommonUI.CommonStyleSheetTypeColor
// 0x0010 (0x0040 - 0x0030)
class CommonStyleSheetTypeColor : public CommonStyleSheetTypeBase
{
public:
	struct FLinearColor                                Color_69;                                                 // 0x0030(0x0010) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CommonUI.CommonStyleSheetTypeColor"));
		
		return ptr;
	}

};


// Class CommonUI.CommonStyleSheetTypeOpacity
// 0x0008 (0x0038 - 0x0030)
class CommonStyleSheetTypeOpacity : public CommonStyleSheetTypeBase
{
public:
	float                                              Opacity_69;                                               // 0x0030(0x0004) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0034(0x0004) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CommonUI.CommonStyleSheetTypeOpacity"));
		
		return ptr;
	}

};


// Class CommonUI.CommonStyleSheetTypeLineHeightPercentage
// 0x0008 (0x0038 - 0x0030)
class CommonStyleSheetTypeLineHeightPercentage : public CommonStyleSheetTypeBase
{
public:
	float                                              LineHeightPercentage_69;                                  // 0x0030(0x0004) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0034(0x0004) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CommonUI.CommonStyleSheetTypeLineHeightPercentage"));
		
		return ptr;
	}

};


// Class CommonUI.CommonStyleSheetTypeFontTypeface
// 0x0058 (0x0088 - 0x0030)
class CommonStyleSheetTypeFontTypeface : public CommonStyleSheetTypeBase
{
public:
	struct FSlateFontInfo                              Typeface_69;                                              // 0x0030(0x0058) (Edit, DisableEditOnInstance)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CommonUI.CommonStyleSheetTypeFontTypeface"));
		
		return ptr;
	}

};


// Class CommonUI.CommonStyleSheetTypeFontSize
// 0x0008 (0x0038 - 0x0030)
class CommonStyleSheetTypeFontSize : public CommonStyleSheetTypeBase
{
public:
	int                                                Size_69;                                                  // 0x0030(0x0004) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0034(0x0004) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CommonUI.CommonStyleSheetTypeFontSize"));
		
		return ptr;
	}

};


// Class CommonUI.CommonStyleSheetTypeFontLetterSpacing
// 0x0008 (0x0038 - 0x0030)
class CommonStyleSheetTypeFontLetterSpacing : public CommonStyleSheetTypeBase
{
public:
	int                                                LetterSpacing_69;                                         // 0x0030(0x0004) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0034(0x0004) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CommonUI.CommonStyleSheetTypeFontLetterSpacing"));
		
		return ptr;
	}

};


// Class CommonUI.CommonStyleSheetTypeMarginLeft
// 0x0008 (0x0038 - 0x0030)
class CommonStyleSheetTypeMarginLeft : public CommonStyleSheetTypeBase
{
public:
	float                                              Left_69;                                                  // 0x0030(0x0004) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0034(0x0004) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CommonUI.CommonStyleSheetTypeMarginLeft"));
		
		return ptr;
	}

};


// Class CommonUI.CommonStyleSheetTypeMarginRight
// 0x0008 (0x0038 - 0x0030)
class CommonStyleSheetTypeMarginRight : public CommonStyleSheetTypeBase
{
public:
	float                                              Right_69;                                                 // 0x0030(0x0004) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0034(0x0004) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CommonUI.CommonStyleSheetTypeMarginRight"));
		
		return ptr;
	}

};


// Class CommonUI.CommonStyleSheetTypeMarginTop
// 0x0008 (0x0038 - 0x0030)
class CommonStyleSheetTypeMarginTop : public CommonStyleSheetTypeBase
{
public:
	float                                              Top_69;                                                   // 0x0030(0x0004) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0034(0x0004) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CommonUI.CommonStyleSheetTypeMarginTop"));
		
		return ptr;
	}

};


// Class CommonUI.CommonStyleSheetTypeMarginBottom
// 0x0008 (0x0038 - 0x0030)
class CommonStyleSheetTypeMarginBottom : public CommonStyleSheetTypeBase
{
public:
	float                                              Bottom_69;                                                // 0x0030(0x0004) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0034(0x0004) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CommonUI.CommonStyleSheetTypeMarginBottom"));
		
		return ptr;
	}

};


// Class CommonUI.AnalogSlider
// 0x0020 (0x06B0 - 0x0690)
class AnalogSlider : public Slider
{
public:
	unsigned char                                      UnknownData00[0x10];                                      // 0x0690(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty CommonUI.AnalogSlider.OnAnalogCapture_69
	unsigned char                                      UnknownData01[0x10];                                      // 0x06A0(0x0010) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CommonUI.AnalogSlider"));
		
		return ptr;
	}

};


// Class CommonUI.CommonActionHandlerInterface_32759
// 0x0000 (0x0028 - 0x0028)
class CommonActionHandlerInterface_32759 : public Interface
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CommonUI.CommonActionHandlerInterface_32759"));
		
		return ptr;
	}

};


// Class CommonUI.CommonActionWidget
// 0x02D8 (0x0420 - 0x0148)
class CommonActionWidget : public Widget
{
public:
	unsigned char                                      UnknownData00[0x10];                                      // 0x0148(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty CommonUI.CommonActionWidget.OnInputMethodChanged_69
	unsigned char                                      UnknownData01[0x8];                                       // 0x0158(0x0008) MISSED OFFSET
	struct FSlateBrush                                 ProgressMaterialBrush_69;                                 // 0x0160(0x00C0) (Edit, BlueprintVisible)
	struct FName                                       ProgressMaterialParam_69;                                 // 0x0220(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData02[0xC];                                       // 0x0224(0x000C) MISSED OFFSET
	struct FSlateBrush                                 IconRimBrush_69;                                          // 0x0230(0x00C0) (Edit, BlueprintVisible, BlueprintReadOnly)
	TArray<struct FDataTableRowHandle>                 InputActions_69;                                          // 0x02F0(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
	unsigned char                                      UnknownData03[0x8];                                       // 0x0300(0x0008) MISSED OFFSET
	class MaterialInstanceDynamic*                     ProgressDynamicMaterial_69;                               // 0x0308(0x0008) (ZeroConstructor, Transient)
	unsigned char                                      UnknownData04[0x110];                                     // 0x0310(0x0110) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CommonUI.CommonActionWidget"));
		
		return ptr;
	}


	void SetInputActions(TArray<struct FDataTableRowHandle> NewInputActions_69);
	void SetInputAction(const struct FDataTableRowHandle& InputActionRow_69);
	void SetIconRimBrush(const struct FSlateBrush& InIconRimBrush_69);
	void OnInputMethodChanged__DelegateSignature(bool bUsingGamepad_69);
	bool IsHeldAction();
	struct FSlateBrush GetIcon();
	struct FText GetDisplayText();
};


// Class CommonUI.CommonUserWidget
// 0x0028 (0x0290 - 0x0268)
class CommonUserWidget : public UserWidget
{
public:
	bool                                               bDisplayInActionBar_69;                                   // 0x0268(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	bool                                               bConsumePointerInput_69;                                  // 0x0269(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x26];                                      // 0x026A(0x0026) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CommonUI.CommonUserWidget"));
		
		return ptr;
	}


	void SetConsumePointerInput(bool bInConsumePointerInput_69);
};


// Class CommonUI.CommonActivatableWidget
// 0x0118 (0x03A8 - 0x0290)
class CommonActivatableWidget : public CommonUserWidget
{
public:
	bool                                               bIsBackHandler_69;                                        // 0x0290(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	bool                                               bIsBackActionDisplayedInActionBar_69;                     // 0x0291(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	bool                                               bAutoActivate_69;                                         // 0x0292(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	bool                                               bSupportsActivationFocus_69;                              // 0x0293(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	bool                                               bIsModal_69;                                              // 0x0294(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	bool                                               bAutoRestoreFocus_69;                                     // 0x0295(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	bool                                               bOverrideActionDomain_69;                                 // 0x0296(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x1];                                       // 0x0297(0x0001) MISSED OFFSET
	unsigned char                                      UnknownData01[0x28];                                      // 0x0297(0x0028) UNKNOWN PROPERTY: SoftObjectProperty CommonUI.CommonActivatableWidget.ActionDomainOverride_69
	unsigned char                                      UnknownData02[0x10];                                      // 0x02C0(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty CommonUI.CommonActivatableWidget.BP_OnWidgetActivated_69
	unsigned char                                      UnknownData03[0x10];                                      // 0x02D0(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty CommonUI.CommonActivatableWidget.BP_OnWidgetDeactivated_69
	bool                                               bIsActive_69;                                             // 0x02E0(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData04[0x7];                                       // 0x02E1(0x0007) MISSED OFFSET
	TArray<TWeakObjectPtr<class CommonActivatableWidget>> VisibilityBoundWidgets_69;                                // 0x02E8(0x0010) (ExportObject, ZeroConstructor, Transient)
	unsigned char                                      UnknownData05[0xA8];                                      // 0x02F8(0x00A8) MISSED OFFSET
	bool                                               bSetVisibilityOnActivated_69;                             // 0x03A0(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	ESlateVisibility                                   ActivatedVisibility_69;                                   // 0x03A1(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	bool                                               bSetVisibilityOnDeactivated_69;                           // 0x03A2(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	ESlateVisibility                                   DeactivatedVisibility_69;                                 // 0x03A3(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData06[0x4];                                       // 0x03A4(0x0004) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CommonUI.CommonActivatableWidget"));
		
		return ptr;
	}


	void SetBindVisibilities(ESlateVisibility OnActivatedVisibility_69, ESlateVisibility OnDeactivatedVisibility_69, bool bInAllActive_69);
	bool IsActivated();
	class Widget* GetDesiredFocusTarget();
	void DeactivateWidget();
	bool BP_OnHandleBackAction();
	void BP_OnDeactivated();
	void BP_OnActivated();
	class Widget* BP_GetDesiredFocusTarget();
	void BindVisibilityToActivation(class CommonActivatableWidget* ActivatableWidget_69);
	void ActivateWidget();
};


// Class CommonUI.CommonAnimatedSwitcher
// 0x0070 (0x01E8 - 0x0178)
class CommonAnimatedSwitcher : public WidgetSwitcher
{
public:
	unsigned char                                      UnknownData00[0x30];                                      // 0x0178(0x0030) MISSED OFFSET
	ECommonSwitcherTransition                          TransitionType_69;                                        // 0x01A8(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	ETransitionCurve                                   TransitionCurveType_69;                                   // 0x01A9(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x2];                                       // 0x01AA(0x0002) MISSED OFFSET
	float                                              TransitionDuration_69;                                    // 0x01AC(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData02[0x38];                                      // 0x01B0(0x0038) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CommonUI.CommonAnimatedSwitcher"));
		
		return ptr;
	}


	void SetDisableTransitionAnimation(bool bDisableAnimation_69);
	bool IsTransitionPlaying();
	bool IsCurrentlySwitching();
	bool HasWidgets();
	void ActivatePreviousWidget(bool bCanWrap_69);
	void ActivateNextWidget(bool bCanWrap_69);
};


// Class CommonUI.CommonActivatableWidgetSwitcher_32759
// 0x0010 (0x01F8 - 0x01E8)
class CommonActivatableWidgetSwitcher_32759 : public CommonAnimatedSwitcher
{
public:
	unsigned char                                      UnknownData00[0x10];                                      // 0x01E8(0x0010) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CommonUI.CommonActivatableWidgetSwitcher_32759"));
		
		return ptr;
	}

};


// Class CommonUI.CommonBorderStyle
// 0x00C8 (0x00F0 - 0x0028)
class CommonBorderStyle : public Object_32759
{
public:
	unsigned char                                      UnknownData00[0x8];                                       // 0x0028(0x0008) MISSED OFFSET
	struct FSlateBrush                                 Background_69;                                            // 0x0030(0x00C0) (Edit, BlueprintVisible, BlueprintReadOnly, DisableEditOnInstance)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CommonUI.CommonBorderStyle"));
		
		return ptr;
	}


	void GetBackgroundBrush(struct FSlateBrush* Brush_69);
};


// Class CommonUI.CommonBorder
// 0x0020 (0x02F0 - 0x02D0)
class CommonBorder : public Border
{
public:
	class CommonBorderStyle*                           style_69;                                                 // 0x02D0(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
	bool                                               bReducePaddingBySafezone_69;                              // 0x02D8(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x02D9(0x0003) MISSED OFFSET
	struct FSlateCore_Fmargin                          MinimumPadding_69;                                        // 0x02DC(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x4];                                       // 0x02EC(0x0004) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CommonUI.CommonBorder"));
		
		return ptr;
	}


	void SetStyle(class CommonBorderStyle* InStyle_69);
};


// Class CommonUI.CommonButtonStyle
// 0x0708 (0x0730 - 0x0028)
class CommonButtonStyle : public Object_32759
{
public:
	bool                                               bSingleMaterial_69;                                       // 0x0028(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0029(0x0007) MISSED OFFSET
	struct FSlateBrush                                 SingleMaterialBrush_69;                                   // 0x0030(0x00C0) (Edit, BlueprintVisible, BlueprintReadOnly, DisableEditOnInstance)
	struct FSlateBrush                                 NormalBase_69;                                            // 0x00F0(0x00C0) (Edit, BlueprintVisible, BlueprintReadOnly, DisableEditOnInstance)
	struct FSlateBrush                                 NormalHovered_69;                                         // 0x01B0(0x00C0) (Edit, BlueprintVisible, BlueprintReadOnly, DisableEditOnInstance)
	struct FSlateBrush                                 NormalPressed_69;                                         // 0x0270(0x00C0) (Edit, BlueprintVisible, BlueprintReadOnly, DisableEditOnInstance)
	struct FSlateBrush                                 SelectedBase_69;                                          // 0x0330(0x00C0) (Edit, BlueprintVisible, BlueprintReadOnly, DisableEditOnInstance)
	struct FSlateBrush                                 SelectedHovered_69;                                       // 0x03F0(0x00C0) (Edit, BlueprintVisible, BlueprintReadOnly, DisableEditOnInstance)
	struct FSlateBrush                                 SelectedPressed_69;                                       // 0x04B0(0x00C0) (Edit, BlueprintVisible, BlueprintReadOnly, DisableEditOnInstance)
	struct FSlateBrush                                 Disabled_69;                                              // 0x0570(0x00C0) (Edit, BlueprintVisible, BlueprintReadOnly, DisableEditOnInstance)
	struct FSlateCore_Fmargin                          ButtonPadding_69;                                         // 0x0630(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	struct FSlateCore_Fmargin                          CustomPadding_69;                                         // 0x0640(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	int                                                MinWidth_69;                                              // 0x0650(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	int                                                MinHeight_69;                                             // 0x0654(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	class CommonTextStyle*                             NormalTextStyle_69;                                       // 0x0658(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance)
	class CommonTextStyle*                             NormalHoveredTextStyle_69;                                // 0x0660(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance)
	class CommonTextStyle*                             SelectedTextStyle_69;                                     // 0x0668(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance)
	class CommonTextStyle*                             SelectedHoveredTextStyle_69;                              // 0x0670(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance)
	class CommonTextStyle*                             DisabledTextStyle_69;                                     // 0x0678(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance)
	struct FSlateSound                                 PressedSlateSound_69;                                     // 0x0680(0x0018) (Edit, BlueprintVisible, BlueprintReadOnly, DisableEditOnInstance)
	struct FCommonButtonStyleOptionalSlateSound        SelectedPressedSlateSound_69;                             // 0x0698(0x0020) (Edit, BlueprintVisible, BlueprintReadOnly, DisableEditOnInstance)
	struct FCommonButtonStyleOptionalSlateSound        LockedPressedSlateSound_69;                               // 0x06B8(0x0020) (Edit, BlueprintVisible, BlueprintReadOnly, DisableEditOnInstance)
	struct FSlateSound                                 HoveredSlateSound_69;                                     // 0x06D8(0x0018) (Edit, BlueprintVisible, BlueprintReadOnly, DisableEditOnInstance)
	struct FCommonButtonStyleOptionalSlateSound        SelectedHoveredSlateSound_69;                             // 0x06F0(0x0020) (Edit, BlueprintVisible, BlueprintReadOnly, DisableEditOnInstance)
	struct FCommonButtonStyleOptionalSlateSound        LockedHoveredSlateSound_69;                               // 0x0710(0x0020) (Edit, BlueprintVisible, BlueprintReadOnly, DisableEditOnInstance)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CommonUI.CommonButtonStyle"));
		
		return ptr;
	}


	class CommonTextStyle* GetSelectedTextStyle();
	void GetSelectedPressedBrush(struct FSlateBrush* Brush_69);
	class CommonTextStyle* GetSelectedHoveredTextStyle();
	void GetSelectedHoveredBrush(struct FSlateBrush* Brush_69);
	void GetSelectedBaseBrush(struct FSlateBrush* Brush_69);
	class CommonTextStyle* GetNormalTextStyle();
	void GetNormalPressedBrush(struct FSlateBrush* Brush_69);
	class CommonTextStyle* GetNormalHoveredTextStyle();
	void GetNormalHoveredBrush(struct FSlateBrush* Brush_69);
	void GetNormalBaseBrush(struct FSlateBrush* Brush_69);
	void GetMaterialBrush(struct FSlateBrush* Brush_69);
	class CommonTextStyle* GetDisabledTextStyle();
	void GetDisabledBrush(struct FSlateBrush* Brush_69);
	void GetCustomPadding(struct FSlateCore_Fmargin* OutCustomPadding_69);
	void GetButtonPadding(struct FSlateCore_Fmargin* OutButtonPadding_69);
};


// Class CommonUI.CommonButtonInternalBase
// 0x0070 (0x0610 - 0x05A0)
class CommonButtonInternalBase : public Button
{
public:
	unsigned char                                      UnknownData00[0x8];                                       // 0x05A0(0x0008) MISSED OFFSET
	unsigned char                                      UnknownData01[0x10];                                      // 0x05A0(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty CommonUI.CommonButtonInternalBase.OnDoubleClicked_69
	unsigned char                                      UnknownData02[0x20];                                      // 0x05B8(0x0020) MISSED OFFSET
	int                                                MinWidth_69;                                              // 0x05D8(0x0004) (ZeroConstructor, IsPlainOldData)
	int                                                MinHeight_69;                                             // 0x05DC(0x0004) (ZeroConstructor, IsPlainOldData)
	bool                                               bButtonEnabled_69;                                        // 0x05E0(0x0001) (ZeroConstructor, IsPlainOldData)
	bool                                               bInteractionEnabled_69;                                   // 0x05E1(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData03[0x2E];                                      // 0x05E2(0x002E) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CommonUI.CommonButtonInternalBase"));
		
		return ptr;
	}

};


// Class CommonUI.CommonButtonBase
// 0x1150 (0x13E0 - 0x0290)
class CommonButtonBase : public CommonUserWidget
{
public:
	int                                                MinWidth_69;                                              // 0x0290(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                MinHeight_69;                                             // 0x0294(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	class CommonButtonStyle*                           style_69;                                                 // 0x0298(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
	bool                                               bHideInputAction_69;                                      // 0x02A0(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x02A1(0x0007) MISSED OFFSET
	struct FSlateSound                                 PressedSlateSoundOverride_69;                             // 0x02A8(0x0018) (Edit, BlueprintVisible, BlueprintReadOnly)
	struct FSlateSound                                 HoveredSlateSoundOverride_69;                             // 0x02C0(0x0018) (Edit, BlueprintVisible, BlueprintReadOnly)
	struct FSlateSound                                 SelectedPressedSlateSoundOverride_69;                     // 0x02D8(0x0018) (Edit, BlueprintVisible, BlueprintReadOnly)
	struct FSlateSound                                 SelectedHoveredSlateSoundOverride_69;                     // 0x02F0(0x0018) (Edit, BlueprintVisible, BlueprintReadOnly)
	struct FSlateSound                                 LockedPressedSlateSoundOverride_69;                       // 0x0308(0x0018) (Edit, BlueprintVisible, BlueprintReadOnly)
	struct FSlateSound                                 LockedHoveredSlateSoundOverride_69;                       // 0x0320(0x0018) (Edit, BlueprintVisible, BlueprintReadOnly)
	unsigned char                                      bApplyAlphaOnDisable_69 : 1;                              // 0x0338(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly)
	unsigned char                                      bLocked_69 : 1;                                           // 0x0338(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly)
	unsigned char                                      bSelectable_69 : 1;                                       // 0x0338(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly)
	unsigned char                                      bShouldSelectUponReceivingFocus_69 : 1;                   // 0x0338(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly)
	unsigned char                                      bInteractableWhenSelected_69 : 1;                         // 0x0338(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly)
	unsigned char                                      bToggleable_69 : 1;                                       // 0x0338(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly)
	unsigned char                                      bTriggerClickedAfterSelection_69 : 1;                     // 0x0338(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly)
	unsigned char                                      bDisplayInputActionWhenNotInteractable_69 : 1;            // 0x0338(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly)
	unsigned char                                      bHideInputActionWithKeyboard_69 : 1;                      // 0x0339(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly)
	unsigned char                                      bShouldUseFallbackDefaultInputAction_69 : 1;              // 0x0339(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly)
	TEnumAsByte<EButtonClickMethod>                    ClickMethod_69;                                           // 0x033A(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<EButtonTouchMethod>                    TouchMethod_69;                                           // 0x033B(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<EButtonPressMethod>                    PressMethod_69;                                           // 0x033C(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x3];                                       // 0x033D(0x0003) MISSED OFFSET
	int                                                InputPriority_69;                                         // 0x0340(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData02[0x4];                                       // 0x0344(0x0004) MISSED OFFSET
	struct FDataTableRowHandle                         TriggeringInputAction_69;                                 // 0x0348(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly)
	unsigned char                                      UnknownData03[0x10];                                      // 0x0358(0x0010) MISSED OFFSET
	unsigned char                                      UnknownData04[0x10];                                      // 0x0358(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty CommonUI.CommonButtonBase.OnSelectedChangedBase_69
	unsigned char                                      UnknownData05[0x10];                                      // 0x0378(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty CommonUI.CommonButtonBase.OnButtonBaseClicked_69
	unsigned char                                      UnknownData06[0x10];                                      // 0x0388(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty CommonUI.CommonButtonBase.OnButtonBaseDoubleClicked_69
	unsigned char                                      UnknownData07[0x10];                                      // 0x0398(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty CommonUI.CommonButtonBase.OnButtonBaseHovered_69
	unsigned char                                      UnknownData08[0x10];                                      // 0x03A8(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty CommonUI.CommonButtonBase.OnButtonBaseUnhovered_69
	unsigned char                                      UnknownData09[0x4];                                       // 0x03B8(0x0004) MISSED OFFSET
	bool                                               bIsPersistentBinding_69;                                  // 0x03BC(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	ECommonInputMode                                   InputModeOverride_69;                                     // 0x03BD(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData10[0x32];                                      // 0x03BE(0x0032) MISSED OFFSET
	class MaterialInstanceDynamic*                     SingleMaterialStyleMID_69;                                // 0x03F0(0x0008) (ZeroConstructor, Transient)
	unsigned char                                      UnknownData11[0x8];                                       // 0x03F8(0x0008) MISSED OFFSET
	struct FButtonStyle                                NormalStyle_69;                                           // 0x0400(0x03B0)
	struct FButtonStyle                                SelectedStyle_69;                                         // 0x07B0(0x03B0)
	struct FButtonStyle                                DisabledStyle_69;                                         // 0x0B60(0x03B0)
	struct FButtonStyle                                LockedStyle_69;                                           // 0x0F10(0x03B0)
	unsigned char                                      bStopDoubleClickPropagation_69 : 1;                       // 0x12C0(0x0001) (Transient)
	unsigned char                                      UnknownData12[0x117];                                     // 0x12C1(0x0117) MISSED OFFSET
	class CommonActionWidget*                          InputActionWidget_69;                                     // 0x13D8(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CommonUI.CommonButtonBase"));
		
		return ptr;
	}


	void StopDoubleClickPropagation();
	void SetTriggeringInputAction(const struct FDataTableRowHandle& InputActionRow_69);
	void SetTriggeredInputAction(const struct FDataTableRowHandle& InputActionRow_69);
	void SetTouchMethod(TEnumAsByte<EButtonTouchMethod> InTouchMethod_69);
	void SetStyle(class CommonButtonStyle* InStyle_69);
	void SetShouldUseFallbackDefaultInputAction(bool bInShouldUseFallbackDefaultInputAction_69);
	void SetShouldSelectUponReceivingFocus(bool bInShouldSelectUponReceivingFocus_69);
	void SetSelectedPressedSoundOverride(class SoundBase* sound_69);
	void SetSelectedInternal(bool bInSelected_69, bool bAllowSound_69, bool bBroadcast_69);
	void SetSelectedHoveredSoundOverride(class SoundBase* sound_69);
	void SetPressMethod(TEnumAsByte<EButtonPressMethod> InPressMethod_69);
	void SetPressedSoundOverride(class SoundBase* sound_69);
	void SetMinDimensions(int InMinWidth_69, int InMinHeight_69);
	void SetLockedPressedSoundOverride(class SoundBase* sound_69);
	void SetLockedHoveredSoundOverride(class SoundBase* sound_69);
	void SetIsToggleable(bool bInIsToggleable_69);
	void SetIsSelected(bool InSelected_69, bool bGiveClickFeedback_69);
	void SetIsSelectable(bool bInIsSelectable_69);
	void SetIsLocked(bool bInIsLocked_69);
	void SetIsInteractionEnabled(bool bInIsInteractionEnabled_69);
	void SetIsInteractableWhenSelected(bool bInInteractableWhenSelected_69);
	void SetIsFocusable(bool bInIsFocusable_69);
	void SetInputActionProgressMaterial(const struct FSlateBrush& InProgressMaterialBrush_69, const struct FName& InProgressMaterialParam_69);
	void SetHoveredSoundOverride(class SoundBase* sound_69);
	void SetHideInputAction(bool bInHideInputAction_69);
	void SetClickMethod(TEnumAsByte<EButtonClickMethod> InClickMethod_69);
	void OnTriggeringInputActionChanged(const struct FDataTableRowHandle& NewTriggeredAction_69);
	void OnTriggeredInputActionChanged(const struct FDataTableRowHandle& NewTriggeredAction_69);
	void OnInputMethodChanged(ECommonInputType CurrentInputType_69);
	void OnCurrentTextStyleChanged();
	void OnActionProgress(float HeldPercent_69);
	void OnActionComplete();
	void NativeOnActionProgress(float HeldPercent_69);
	void NativeOnActionComplete();
	bool IsPressed();
	bool IsInteractionEnabled();
	void HandleTriggeringActionCommited(bool* bPassThrough_69);
	void HandleFocusReceived();
	void HandleFocusLost();
	void HandleButtonReleased();
	void HandleButtonPressed();
	void HandleButtonClicked();
	class CommonButtonStyle* GetStyle();
	class MaterialInstanceDynamic* GetSingleMaterialStyleMID();
	bool GetShouldSelectUponReceivingFocus();
	bool GetSelected();
	bool GetLocked();
	bool GetIsFocusable();
	bool GetInputAction(struct FDataTableRowHandle* InputActionRow_69);
	class CommonTextStyle* GetCurrentTextStyleClass();
	class CommonTextStyle* GetCurrentTextStyle();
	void GetCurrentCustomPadding(struct FSlateCore_Fmargin* OutCustomPadding_69);
	void GetCurrentButtonPadding(struct FSlateCore_Fmargin* OutButtonPadding_69);
	void DisableButtonWithReason(const struct FText& DisabledReason_69);
	void ClearSelection();
	void BP_OnUnhovered();
	void BP_OnSelected();
	void BP_OnReleased();
	void BP_OnPressed();
	void BP_OnLockedChanged(bool bIsLocked_69);
	void BP_OnLockDoubleClicked();
	void BP_OnLockClicked();
	void BP_OnInputMethodChanged(ECommonInputType CurrentInputType_69);
	void BP_OnHovered();
	void BP_OnFocusReceived();
	void BP_OnFocusLost();
	void BP_OnEnabled();
	void BP_OnDoubleClicked();
	void BP_OnDisabled();
	void BP_OnDeselected();
	void BP_OnClicked();
};


// Class CommonUI.CommonCustomNavigation_32759
// 0x0010 (0x02E0 - 0x02D0)
class CommonCustomNavigation_32759 : public Border
{
public:
	struct FScriptDelegate                             OnNavigationEvent_69;                                     // 0x02D0(0x0010) (Edit, ZeroConstructor, InstancedReference)
	unsigned char                                      UnknownData00[0x4];                                       // 0x02DC(0x0004) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CommonUI.CommonCustomNavigation_32759"));
		
		return ptr;
	}

};


// Class CommonUI.CommonTextBlock
// 0x0030 (0x0350 - 0x0320)
class CommonTextBlock : public TextBlock
{
public:
	class CommonTextScrollStyle*                       ScrollStyle_69;                                           // 0x0320(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
	class CommonStyleSheet*                            StyleSheet_69;                                            // 0x0328(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
	bool                                               bIsScrollingEnabled_69;                                   // 0x0330(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	bool                                               bDisplayAllCaps_69;                                       // 0x0331(0x0001) (ZeroConstructor, Deprecated, IsPlainOldData)
	bool                                               bAutoCollapseWithEmptyText_69;                            // 0x0332(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x1];                                       // 0x0333(0x0001) MISSED OFFSET
	float                                              MobileFontSizeMultiplier_69;                              // 0x0334(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x18];                                      // 0x0338(0x0018) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CommonUI.CommonTextBlock"));
		
		return ptr;
	}


	void SetWrapTextWidth(int InWrapTextAt_69);
	void SetTextCase(bool bUseAllCaps_69);
	void SetStyle(class CommonTextStyle* InStyle_69);
	void SetScrollingEnabled(bool bInIsScrollingEnabled_69);
	void SetMargin(const struct FSlateCore_Fmargin& InMargin_69);
	void SetLineHeightPercentage(float InLineHeightPercentage_69);
	void ResetScrollState();
	struct FSlateCore_Fmargin GetMargin();
};


// Class CommonUI.CommonDateTimeTextBlock
// 0x0050 (0x03A0 - 0x0350)
class CommonDateTimeTextBlock : public CommonTextBlock
{
public:
	unsigned char                                      UnknownData00[0x50];                                      // 0x0350(0x0050) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CommonUI.CommonDateTimeTextBlock"));
		
		return ptr;
	}


	void SetTimespanValue(const struct FTimespan& InTimespan_69);
	void SetDateTimeValue(const struct FDateTime& InDateTime_69, bool bShowAsCountdown_69, float InRefreshDelay_69);
	void SetCountDownCompletionText(const struct FText& InCompletionText_69);
	struct FDateTime GetDateTime();
};


// Class CommonUI.CommonGameViewportClient
// 0x0040 (0x03D0 - 0x0390)
class CommonGameViewportClient : public GameViewportClient
{
public:
	unsigned char                                      UnknownData00[0x40];                                      // 0x0390(0x0040) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CommonUI.CommonGameViewportClient"));
		
		return ptr;
	}

};


// Class CommonUI.CommonHardwareVisibilityBorder
// 0x0050 (0x0340 - 0x02F0)
class CommonHardwareVisibilityBorder : public CommonBorder
{
public:
	struct FGameplayTagQuery                           VisibilityQuery_69;                                       // 0x02F0(0x0048) (Edit)
	ESlateVisibility                                   VisibleType_69;                                           // 0x0338(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	ESlateVisibility                                   HiddenType_69;                                            // 0x0339(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x6];                                       // 0x033A(0x0006) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CommonUI.CommonHardwareVisibilityBorder"));
		
		return ptr;
	}

};


// Class CommonUI.CommonHierarchicalScrollBox
// 0x0000 (0x0BC0 - 0x0BC0)
class CommonHierarchicalScrollBox : public ScrollBox
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CommonUI.CommonHierarchicalScrollBox"));
		
		return ptr;
	}

};


// Class CommonUI.CommonLazyImage
// 0x0100 (0x0380 - 0x0280)
class CommonLazyImage : public Image
{
public:
	struct FSlateBrush                                 LoadingBackgroundBrush_69;                                // 0x0280(0x00C0) (Edit)
	struct FName                                       MaterialTextureParamName_69;                              // 0x0340(0x0008) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0344(0x0004) MISSED OFFSET
	unsigned char                                      UnknownData01[0x10];                                      // 0x0344(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty CommonUI.CommonLazyImage.BP_OnLoadingStateChanged_69
	unsigned char                                      UnknownData02[0x28];                                      // 0x0358(0x0028) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CommonUI.CommonLazyImage"));
		
		return ptr;
	}


	void SetMaterialTextureParamName(const struct FName& TextureParamName_69);
	void SetBrushFromLazyTexture(bool bMatchSize_69);
	void SetBrushFromLazyMaterial();
	void SetBrushFromLazyDisplayAsset(bool bMatchTextureSize_69);
	bool IsLoading();
};


// Class CommonUI.CommonLazyWidget
// 0x0148 (0x0290 - 0x0148)
class CommonLazyWidget : public Widget
{
public:
	unsigned char                                      UnknownData00[0x8];                                       // 0x0148(0x0008) MISSED OFFSET
	struct FSlateBrush                                 LoadingBackgroundBrush_69;                                // 0x0150(0x00C0) (Edit)
	class UserWidget*                                  Content_69;                                               // 0x0210(0x0008) (ExportObject, ZeroConstructor, Transient, InstancedReference)
	unsigned char                                      UnknownData01[0x28];                                      // 0x0218(0x0028) MISSED OFFSET
	unsigned char                                      UnknownData02[0x10];                                      // 0x0218(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty CommonUI.CommonLazyWidget.BP_OnLoadingStateChanged_69
	unsigned char                                      UnknownData03[0x40];                                      // 0x0250(0x0040) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CommonUI.CommonLazyWidget"));
		
		return ptr;
	}


	void SetLazyContent();
	bool IsLoading();
	class UserWidget* GetContent();
};


// Class CommonUI.CommonListView
// 0x0000 (0x0B80 - 0x0B80)
class CommonListView : public ListView
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CommonUI.CommonListView"));
		
		return ptr;
	}


	void SetEntrySpacing(float InEntrySpacing_69);
};


// Class CommonUI.LoadGuardSlot
// 0x0028 (0x0060 - 0x0038)
class LoadGuardSlot : public PanelSlot
{
public:
	struct FSlateCore_Fmargin                          Padding_69;                                               // 0x0038(0x0010) (Edit, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<EHorizontalAlignment>                  HorizontalAlignment_69;                                   // 0x0048(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<EVerticalAlignment>                    VerticalAlignment_69;                                     // 0x0049(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x16];                                      // 0x004A(0x0016) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CommonUI.LoadGuardSlot"));
		
		return ptr;
	}


	void SetVerticalAlignment(TEnumAsByte<EVerticalAlignment> InVerticalAlignment_69);
	void SetPadding(const struct FSlateCore_Fmargin& InPadding_69);
	void SetHorizontalAlignment(TEnumAsByte<EHorizontalAlignment> InHorizontalAlignment_69);
};


// Class CommonUI.CommonLoadGuard
// 0x0150 (0x02B0 - 0x0160)
class CommonLoadGuard : public ContentWidget
{
public:
	struct FSlateBrush                                 LoadingBackgroundBrush_69;                                // 0x0160(0x00C0) (Edit)
	TEnumAsByte<EHorizontalAlignment>                  ThrobberAlignment_69;                                     // 0x0220(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0221(0x0003) MISSED OFFSET
	struct FSlateCore_Fmargin                          ThrobberPadding_69;                                       // 0x0224(0x0010) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x4];                                       // 0x0234(0x0004) MISSED OFFSET
	struct FText                                       LoadingText_69;                                           // 0x0238(0x0018) (Edit)
	class CommonTextStyle*                             TextStyle_69;                                             // 0x0250(0x0008) (Edit, ZeroConstructor)
	unsigned char                                      UnknownData02[0x10];                                      // 0x0258(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty CommonUI.CommonLoadGuard.BP_OnLoadingStateChanged_69
	struct FSoftObjectPath                             SpinnerMaterialPath_69;                                   // 0x0268(0x0018) (ZeroConstructor, Config)
	unsigned char                                      UnknownData03[0x30];                                      // 0x0280(0x0030) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CommonUI.CommonLoadGuard"));
		
		return ptr;
	}


	void SetLoadingText(const struct FText& InLoadingText_69);
	void SetIsLoading(bool bInIsLoading_69);
	void OnAssetLoaded__DelegateSignature(class Object_32759* Object_69);
	bool IsLoading();
	void BP_GuardAndLoadAsset(const struct FScriptDelegate& OnAssetLoaded_69);
};


// Class CommonUI.CommonNumericTextBlock
// 0x00A0 (0x03F0 - 0x0350)
class CommonNumericTextBlock : public CommonTextBlock
{
public:
	unsigned char                                      UnknownData00[0x8];                                       // 0x0350(0x0008) MISSED OFFSET
	unsigned char                                      UnknownData01[0x10];                                      // 0x0350(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty CommonUI.CommonNumericTextBlock.OnInterpolationUpdatedEvent_69
	unsigned char                                      UnknownData02[0x10];                                      // 0x0368(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty CommonUI.CommonNumericTextBlock.OnOutroEvent_69
	unsigned char                                      UnknownData03[0x10];                                      // 0x0378(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty CommonUI.CommonNumericTextBlock.OnInterpolationEndedEvent_69
	float                                              CurrentNumericValue_69;                                   // 0x0388(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	ECommonNumericType                                 NumericType_69;                                           // 0x038C(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData04[0x3];                                       // 0x038D(0x0003) MISSED OFFSET
	struct FCommonNumberFormattingOptions              FormattingSpecification_69;                               // 0x0390(0x0014) (Edit, BlueprintVisible, BlueprintReadOnly)
	float                                              EaseOutInterpolationExponent_69;                          // 0x03A4(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              InterpolationUpdateInterval_69;                           // 0x03A8(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              PostInterpolationShrinkDuration_69;                       // 0x03AC(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	bool                                               PerformSizeInterpolation_69;                              // 0x03B0(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	bool                                               IsPercentage_69;                                          // 0x03B1(0x0001) (ZeroConstructor, Deprecated, IsPlainOldData)
	unsigned char                                      UnknownData05[0x3E];                                      // 0x03B2(0x003E) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CommonUI.CommonNumericTextBlock"));
		
		return ptr;
	}


	void SetNumericType(ECommonNumericType InNumericType_69);
	void SetCurrentValue(float NewValue_69);
	void OnOutro__DelegateSignature(class CommonNumericTextBlock* NumericTextBlock_69);
	void OnInterpolationUpdated__DelegateSignature(class CommonNumericTextBlock* NumericTextBlock_69, float LastValue_69, float NewValue_69);
	void OnInterpolationStarted__DelegateSignature(class CommonNumericTextBlock* NumericTextBlock_69);
	void OnInterpolationEnded__DelegateSignature(class CommonNumericTextBlock* NumericTextBlock_69, bool HadCompleted_69);
	bool IsInterpolatingNumericValue();
	void InterpolateToValue(float TargetValue_69, float MaximumInterpolationDuration_69, float MinimumChangeRate_69, float OutroOffset_69);
	float GetTargetValue();
};


// Class CommonUI.CommonPoolableWidgetInterface
// 0x0000 (0x0028 - 0x0028)
class CommonPoolableWidgetInterface : public Interface
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CommonUI.CommonPoolableWidgetInterface"));
		
		return ptr;
	}


	void OnReleaseToPool();
	void OnAcquireFromPool();
};


// Class CommonUI.CommonRichTextBlock
// 0x0040 (0x0840 - 0x0800)
class CommonRichTextBlock : public RichTextBlock
{
public:
	ERichTextInlineIconDisplayMode                     InlineIconDisplayMode_69;                                 // 0x0800(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	bool                                               bTintInlineIcon_69;                                       // 0x0801(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x6];                                       // 0x0802(0x0006) MISSED OFFSET
	class CommonTextStyle*                             DefaultTextStyleOverrideClass_69;                         // 0x0808(0x0008) (Edit, ZeroConstructor)
	float                                              MobileTextBlockScale_69;                                  // 0x0810(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x4];                                       // 0x0814(0x0004) MISSED OFFSET
	class CommonTextScrollStyle*                       ScrollStyle_69;                                           // 0x0818(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
	bool                                               bIsScrollingEnabled_69;                                   // 0x0820(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	bool                                               bDisplayAllCaps_69;                                       // 0x0821(0x0001) (ZeroConstructor, Deprecated, IsPlainOldData)
	bool                                               bAutoCollapseWithEmptyText_69;                            // 0x0822(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData02[0x1D];                                      // 0x0823(0x001D) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CommonUI.CommonRichTextBlock"));
		
		return ptr;
	}


	void SetScrollingEnabled(bool bInIsScrollingEnabled_69);
};


// Class CommonUI.CommonRotator
// 0x0060 (0x1440 - 0x13E0)
class CommonRotator : public CommonButtonBase
{
public:
	unsigned char                                      UnknownData00[0x10];                                      // 0x13E0(0x0010) MISSED OFFSET
	unsigned char                                      UnknownData01[0x10];                                      // 0x13E0(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty CommonUI.CommonRotator.OnRotated_69
	unsigned char                                      UnknownData02[0x18];                                      // 0x1400(0x0018) MISSED OFFSET
	class CommonTextBlock*                             MyText_69;                                                // 0x1418(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)
	unsigned char                                      UnknownData03[0x20];                                      // 0x1420(0x0020) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CommonUI.CommonRotator"));
		
		return ptr;
	}


	void ShiftTextRight();
	void ShiftTextLeft();
	void SetSelectedItem(int InValue_69);
	void PopulateTextLabels(TArray<struct FText> Labels_69);
	struct FText GetSelectedText();
	int GetSelectedIndex();
	void BP_OnOptionsPopulated(int Count_69);
	void BP_OnOptionSelected(int Index_69);
};


// Class CommonUI.CommonTabListWidgetBase
// 0x00E0 (0x0370 - 0x0290)
class CommonTabListWidgetBase : public CommonUserWidget
{
public:
	unsigned char                                      UnknownData00[0x10];                                      // 0x0290(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty CommonUI.CommonTabListWidgetBase.OnTabSelected_69
	unsigned char                                      UnknownData01[0x10];                                      // 0x02A0(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty CommonUI.CommonTabListWidgetBase.OnTabButtonCreation_69
	unsigned char                                      UnknownData02[0x10];                                      // 0x02B0(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty CommonUI.CommonTabListWidgetBase.OnTabButtonRemoval_69
	unsigned char                                      UnknownData03[0x10];                                      // 0x02C0(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty CommonUI.CommonTabListWidgetBase.OnTabListRebuilt_69
	struct FDataTableRowHandle                         NextTabInputActionData_69;                                // 0x02D0(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly)
	struct FDataTableRowHandle                         PreviousTabInputActionData_69;                            // 0x02E0(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly)
	bool                                               bAutoListenForInput_69;                                   // 0x02F0(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	bool                                               bDeferRebuildingTabList_69;                               // 0x02F1(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData04[0x2];                                       // 0x02F2(0x0002) MISSED OFFSET
	TWeakObjectPtr<class CommonAnimatedSwitcher>       LinkedSwitcher_69;                                        // 0x02F4(0x0008) (ExportObject, ZeroConstructor, Transient, InstancedReference, IsPlainOldData)
	unsigned char                                      UnknownData05[0x4];                                       // 0x02FC(0x0004) MISSED OFFSET
	class CommonButtonGroupBase*                       TabButtonGroup_69;                                        // 0x0300(0x0008) (ZeroConstructor, Transient)
	unsigned char                                      UnknownData06[0x8];                                       // 0x0308(0x0008) MISSED OFFSET
	TMap<struct FName, struct FCommonRegisteredTabInfo> RegisteredTabsByID_69;                                    // 0x0310(0x0050) (Transient)
	unsigned char                                      UnknownData07[0x10];                                      // 0x0360(0x0010) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CommonUI.CommonTabListWidgetBase"));
		
		return ptr;
	}


	void SetTabVisibility(const struct FName& TabNameID_69, ESlateVisibility NewVisibility_69);
	void SetTabInteractionEnabled(const struct FName& TabNameID_69, bool bEnable_69);
	void SetTabEnabled(const struct FName& TabNameID_69, bool bEnable_69);
	void SetListeningForInput(bool bShouldListen_69);
	void SetLinkedSwitcher(class CommonAnimatedSwitcher* CommonSwitcher_69);
	bool SelectTabByID(const struct FName& TabNameID_69, bool bSuppressClickFeedback_69);
	bool RemoveTab(const struct FName& TabNameID_69);
	void RemoveAllTabs();
	bool RegisterTab(const struct FName& TabNameID_69, class CommonButtonBase* ButtonWidgetType_69, class Widget* ContentWidget_69, int TabIndex_69);
	void OnTabSelected__DelegateSignature(const struct FName& TabId_69);
	void OnTabListRebuilt__DelegateSignature();
	void OnTabButtonRemoval__DelegateSignature(const struct FName& TabId_69, class CommonButtonBase* TabButton_69);
	void OnTabButtonCreation__DelegateSignature(const struct FName& TabId_69, class CommonButtonBase* TabButton_69);
	void HandleTabRemoval(const struct FName& TabNameID_69, class CommonButtonBase* TabButton_69);
	void HandleTabCreation(const struct FName& TabNameID_69, class CommonButtonBase* TabButton_69);
	void HandleTabButtonSelected(class CommonButtonBase* SelectedTabButton_69, int ButtonIndex_69);
	void HandlePreviousTabInputAction(bool* bPassThrough_69);
	void HandlePreLinkedSwitcherChanged_BP();
	void HandlePostLinkedSwitcherChanged_BP();
	void HandleNextTabInputAction(bool* bPassThrough_69);
	struct FName GetTabIdAtIndex(int Index_69);
	int GetTabCount();
	class CommonButtonBase* GetTabButtonBaseByID(const struct FName& TabNameID_69);
	struct FName GetSelectedTabId();
	class CommonAnimatedSwitcher* GetLinkedSwitcher();
	struct FName GetActiveTab();
	void DisableTabWithReason(const struct FName& TabNameID_69, const struct FText& Reason_69);
};


// Class CommonUI.CommonTextStyle
// 0x0178 (0x01A0 - 0x0028)
class CommonTextStyle : public Object_32759
{
public:
	struct FSlateFontInfo                              Font_69;                                                  // 0x0028(0x0058) (Edit, BlueprintVisible, BlueprintReadOnly, DisableEditOnInstance)
	struct FLinearColor                                Color_69;                                                 // 0x0080(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	bool                                               bUsesDropShadow_69;                                       // 0x0090(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0091(0x0007) MISSED OFFSET
	struct FVector2D                                   ShadowOffset_69;                                          // 0x0098(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	struct FLinearColor                                ShadowColor_69;                                           // 0x00A8(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	struct FSlateCore_Fmargin                          margin_69;                                                // 0x00B8(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData01[0x8];                                       // 0x00C8(0x0008) MISSED OFFSET
	struct FSlateBrush                                 StrikeBrush_69;                                           // 0x00D0(0x00C0) (Edit, BlueprintVisible, BlueprintReadOnly, DisableEditOnInstance)
	float                                              LineHeightPercentage_69;                                  // 0x0190(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData02[0xC];                                       // 0x0194(0x000C) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CommonUI.CommonTextStyle"));
		
		return ptr;
	}


	void GetStrikeBrush(struct FSlateBrush* OutStrikeBrush_69);
	void GetShadowOffset(struct FVector2D* OutShadowOffset_69);
	void GetShadowColor(struct FLinearColor* OutColor_69);
	void GetMargin(struct FSlateCore_Fmargin* OutMargin_69);
	float GetLineHeightPercentage();
	void GetFont(struct FSlateFontInfo* OutFont_69);
	void GetColor(struct FLinearColor* OutColor_69);
};


// Class CommonUI.CommonTextScrollStyle
// 0x0018 (0x0040 - 0x0028)
class CommonTextScrollStyle : public Object_32759
{
public:
	float                                              Speed_69;                                                 // 0x0028(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              StartDelay_69;                                            // 0x002C(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              EndDelay_69;                                              // 0x0030(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              FadeInDelay_69;                                           // 0x0034(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              FadeOutDelay_69;                                          // 0x0038(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x003C(0x0004) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CommonUI.CommonTextScrollStyle"));
		
		return ptr;
	}

};


// Class CommonUI.CommonTileView
// 0x0000 (0x0BA0 - 0x0BA0)
class CommonTileView : public TileView
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CommonUI.CommonTileView"));
		
		return ptr;
	}

};


// Class CommonUI.CommonTreeView
// 0x0000 (0x0BE0 - 0x0BE0)
class CommonTreeView : public TreeView
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CommonUI.CommonTreeView"));
		
		return ptr;
	}

};


// Class CommonUI.CommonUIEditorSettings
// 0x0080 (0x00A8 - 0x0028)
class CommonUIEditorSettings : public Object_32759
{
public:
	unsigned char                                      UnknownData00[0x28];                                      // 0x0028(0x0028) UNKNOWN PROPERTY: SoftClassProperty CommonUI.CommonUIEditorSettings.TemplateTextStyle_69
	unsigned char                                      UnknownData01[0x28];                                      // 0x0050(0x0028) UNKNOWN PROPERTY: SoftClassProperty CommonUI.CommonUIEditorSettings.TemplateButtonStyle_69
	unsigned char                                      UnknownData02[0x28];                                      // 0x0078(0x0028) UNKNOWN PROPERTY: SoftClassProperty CommonUI.CommonUIEditorSettings.TemplateBorderStyle_69
	unsigned char                                      UnknownData03[0x8];                                       // 0x00A0(0x0008) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CommonUI.CommonUIEditorSettings"));
		
		return ptr;
	}

};


// Class CommonUI.CommonUILibrary
// 0x0000 (0x0028 - 0x0028)
class CommonUILibrary : public BlueprintFunctionLibrary
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CommonUI.CommonUILibrary"));
		
		return ptr;
	}


	class Widget* STATIC_FindParentWidgetOfType(class Widget* StartingWidget_69, class Widget* Type_69);
};


// Class CommonUI.CommonUIRichTextData
// 0x0008 (0x0030 - 0x0028)
class CommonUIRichTextData : public Object_32759
{
public:
	class DataTable*                                   InlineIconSet_69;                                         // 0x0028(0x0008) (Edit, ZeroConstructor, DisableEditOnInstance)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CommonUI.CommonUIRichTextData"));
		
		return ptr;
	}

};


// Class CommonUI.CommonUISettings
// 0x0198 (0x01C0 - 0x0028)
class CommonUISettings : public Object_32759
{
public:
	bool                                               bAutoLoadData_69;                                         // 0x0028(0x0001) (Edit, ZeroConstructor, Config, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0029(0x0007) MISSED OFFSET
	unsigned char                                      UnknownData01[0x28];                                      // 0x0029(0x0028) UNKNOWN PROPERTY: SoftObjectProperty CommonUI.CommonUISettings.DefaultImageResourceObject_69
	unsigned char                                      UnknownData02[0x28];                                      // 0x0058(0x0028) UNKNOWN PROPERTY: SoftObjectProperty CommonUI.CommonUISettings.DefaultThrobberMaterial_69
	unsigned char                                      UnknownData03[0x28];                                      // 0x0080(0x0028) UNKNOWN PROPERTY: SoftClassProperty CommonUI.CommonUISettings.DefaultRichTextDataClass_69
	TArray<struct FGameplayTag>                        PlatformTraits_69;                                        // 0x00A8(0x0010) (Edit, ZeroConstructor, Config)
	unsigned char                                      UnknownData04[0x28];                                      // 0x00B8(0x0028) MISSED OFFSET
	class Object_32759*                                DefaultImageResourceObjectInstance_69;                    // 0x00E0(0x0008) (ZeroConstructor, Transient)
	class MaterialInterface*                           DefaultThrobberMaterialInstance_69;                       // 0x00E8(0x0008) (ZeroConstructor, Transient)
	struct FSlateBrush                                 DefaultThrobberBrush_69;                                  // 0x00F0(0x00C0) (Transient)
	class CommonUIRichTextData*                        RichTextDataInstance_69;                                  // 0x01B0(0x0008) (ZeroConstructor, Transient)
	unsigned char                                      UnknownData05[0x8];                                       // 0x01B8(0x0008) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CommonUI.CommonUISettings"));
		
		return ptr;
	}

};


// Class CommonUI.CommonUISubsystemBase
// 0x0010 (0x0040 - 0x0030)
class CommonUISubsystemBase : public GameInstanceSubsystem
{
public:
	unsigned char                                      UnknownData00[0x10];                                      // 0x0030(0x0010) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CommonUI.CommonUISubsystemBase"));
		
		return ptr;
	}


	struct FSlateBrush GetInputActionButtonIcon(const struct FDataTableRowHandle& InputActionRowHandle_69, ECommonInputType InputType_69, const struct FName& GamepadName_69);
};


// Class CommonUI.CommonUIVisibilitySubsystem
// 0x0058 (0x0088 - 0x0030)
class CommonUIVisibilitySubsystem : public LocalPlayerSubsystem
{
public:
	unsigned char                                      UnknownData00[0x58];                                      // 0x0030(0x0058) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CommonUI.CommonUIVisibilitySubsystem"));
		
		return ptr;
	}

};


// Class CommonUI.CommonVideoPlayer
// 0x0148 (0x0290 - 0x0148)
class CommonVideoPlayer : public Widget
{
public:
	class MediaSource*                                 Video_69;                                                 // 0x0148(0x0008) (Edit, ZeroConstructor)
	class MediaPlayer*                                 MediaPlayer_69;                                           // 0x0150(0x0008) (ZeroConstructor, Transient)
	class MediaTexture*                                MediaTexture_69;                                          // 0x0158(0x0008) (ZeroConstructor, Transient)
	class Material*                                    VideoMaterial_69;                                         // 0x0160(0x0008) (ZeroConstructor, Transient)
	class MediaSoundComponent*                         SoundComponent_69;                                        // 0x0168(0x0008) (ExportObject, ZeroConstructor, Transient, InstancedReference)
	struct FSlateBrush                                 VideoBrush_69;                                            // 0x0170(0x00C0) (Transient)
	unsigned char                                      UnknownData00[0x60];                                      // 0x0230(0x0060) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CommonUI.CommonVideoPlayer"));
		
		return ptr;
	}

};


// Class CommonUI.CommonVisibilitySwitcher
// 0x0028 (0x0198 - 0x0170)
class CommonVisibilitySwitcher : public Overlay
{
public:
	ESlateVisibility                                   ShownVisibility_69;                                       // 0x0170(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0171(0x0003) MISSED OFFSET
	int                                                ActiveWidgetIndex_69;                                     // 0x0174(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	bool                                               bAutoActivateSlot_69;                                     // 0x0178(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	bool                                               bActivateFirstSlotOnAdding_69;                            // 0x0179(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x1E];                                      // 0x017A(0x001E) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CommonUI.CommonVisibilitySwitcher"));
		
		return ptr;
	}


	void SetActiveWidgetIndex(int Index_69);
	void SetActiveWidget(class Widget* Widget_69);
	void IncrementActiveWidgetIndex(bool bAllowWrapping_69);
	int GetActiveWidgetIndex();
	class Widget* GetActiveWidget();
	void DecrementActiveWidgetIndex(bool bAllowWrapping_69);
	void DeactivateVisibleSlot();
	void ActivateVisibleSlot();
};


// Class CommonUI.CommonVisibilitySwitcherSlot
// 0x0010 (0x0068 - 0x0058)
class CommonVisibilitySwitcherSlot : public OverlaySlot
{
public:
	unsigned char                                      UnknownData00[0x10];                                      // 0x0058(0x0010) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CommonUI.CommonVisibilitySwitcherSlot"));
		
		return ptr;
	}

};


// Class CommonUI.UCommonVisibilityWidgetBase
// 0x0060 (0x0350 - 0x02F0)
class UCommonVisibilityWidgetBase : public CommonBorder
{
public:
	TMap<struct FName, bool>                           VisibilityControls_69;                                    // 0x02F0(0x0050) (Edit, EditFixedSize)
	bool                                               bShowForGamepad_69;                                       // 0x0340(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	bool                                               bShowForMouseAndKeyboard_69;                              // 0x0341(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	bool                                               bShowForTouch_69;                                         // 0x0342(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	ESlateVisibility                                   VisibleType_69;                                           // 0x0343(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	ESlateVisibility                                   HiddenType_69;                                            // 0x0344(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0xB];                                       // 0x0345(0x000B) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CommonUI.UCommonVisibilityWidgetBase"));
		
		return ptr;
	}


	TArray<struct FName> STATIC_GetRegisteredPlatforms();
};


// Class CommonUI.CommonVisualAttachment
// 0x0020 (0x01B8 - 0x0198)
class CommonVisualAttachment : public SizeBox
{
public:
	struct FVector2D                                   ContentAnchor_69;                                         // 0x0198(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x10];                                      // 0x01A8(0x0010) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CommonUI.CommonVisualAttachment"));
		
		return ptr;
	}

};


// Class CommonUI.CommonWidgetCarousel
// 0x0048 (0x01A8 - 0x0160)
class CommonWidgetCarousel : public PanelWidget
{
public:
	int                                                ActiveWidgetIndex_69;                                     // 0x0160(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0164(0x0004) MISSED OFFSET
	unsigned char                                      UnknownData01[0x10];                                      // 0x0164(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty CommonUI.CommonWidgetCarousel.OnCurrentPageIndexChanged_69
	unsigned char                                      UnknownData02[0x30];                                      // 0x0178(0x0030) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CommonUI.CommonWidgetCarousel"));
		
		return ptr;
	}


	void SetActiveWidgetIndex(int Index_69);
	void SetActiveWidget(class Widget* Widget_69);
	void PreviousPage();
	void NextPage();
	class Widget* GetWidgetAtIndex(int Index_69);
	int GetActiveWidgetIndex();
	void EndAutoScrolling();
	void BeginAutoScrolling(float ScrollInterval_69);
};


// Class CommonUI.CommonWidgetCarouselNavBar
// 0x0048 (0x0190 - 0x0148)
class CommonWidgetCarouselNavBar : public Widget
{
public:
	class CommonButtonBase*                            ButtonWidgetType_69;                                      // 0x0148(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
	struct FSlateCore_Fmargin                          ButtonPadding_69;                                         // 0x0150(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x10];                                      // 0x0160(0x0010) MISSED OFFSET
	class CommonWidgetCarousel*                        LinkedCarousel_69;                                        // 0x0170(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	class CommonButtonGroupBase*                       ButtonGroup_69;                                           // 0x0178(0x0008) (ZeroConstructor)
	TArray<class CommonButtonBase*>                    Buttons_69;                                               // 0x0180(0x0010) (ExportObject, ZeroConstructor)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CommonUI.CommonWidgetCarouselNavBar"));
		
		return ptr;
	}


	void SetLinkedCarousel(class CommonWidgetCarousel* CommonCarousel_69);
	void HandlePageChanged(class CommonWidgetCarousel* CommonCarousel_69, int PageIndex_69);
	void HandleButtonClicked(class CommonButtonBase* AssociatedButton_69, int ButtonIndex_69);
};


// Class CommonUI.CommonWidgetGroupBase
// 0x0000 (0x0028 - 0x0028)
class CommonWidgetGroupBase : public Object_32759
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CommonUI.CommonWidgetGroupBase"));
		
		return ptr;
	}


	void RemoveWidget(class Widget* InWidget_69);
	void RemoveAll();
	void AddWidget(class Widget* InWidget_69);
};


// Class CommonUI.CommonButtonGroupBase
// 0x00E8 (0x0110 - 0x0028)
class CommonButtonGroupBase : public CommonWidgetGroupBase
{
public:
	unsigned char                                      UnknownData00[0x10];                                      // 0x0028(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty CommonUI.CommonButtonGroupBase.OnSelectedButtonBaseChanged_69
	unsigned char                                      UnknownData01[0x18];                                      // 0x0038(0x0018) MISSED OFFSET
	unsigned char                                      UnknownData02[0x10];                                      // 0x0038(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty CommonUI.CommonButtonGroupBase.OnHoveredButtonBaseChanged_69
	unsigned char                                      UnknownData03[0x18];                                      // 0x0060(0x0018) MISSED OFFSET
	unsigned char                                      UnknownData04[0x10];                                      // 0x0060(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty CommonUI.CommonButtonGroupBase.OnButtonBaseClicked_69
	unsigned char                                      UnknownData05[0x18];                                      // 0x0088(0x0018) MISSED OFFSET
	unsigned char                                      UnknownData06[0x10];                                      // 0x0088(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty CommonUI.CommonButtonGroupBase.OnButtonBaseDoubleClicked_69
	unsigned char                                      UnknownData07[0x18];                                      // 0x00B0(0x0018) MISSED OFFSET
	unsigned char                                      UnknownData08[0x10];                                      // 0x00B0(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty CommonUI.CommonButtonGroupBase.OnSelectionCleared_69
	unsigned char                                      UnknownData09[0x18];                                      // 0x00D8(0x0018) MISSED OFFSET
	bool                                               bSelectionRequired_69;                                    // 0x00F0(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData10[0x1F];                                      // 0x00F1(0x001F) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CommonUI.CommonButtonGroupBase"));
		
		return ptr;
	}


	void SetSelectionRequired(bool bRequireSelection_69);
	void SelectPreviousButton(bool bAllowWrap_69);
	void SelectNextButton(bool bAllowWrap_69);
	void SelectButtonAtIndex(int ButtonIndex_69, bool bAllowSound_69);
	void OnSelectionStateChangedBase(class CommonButtonBase* BaseButton_69, bool bIsSelected_69);
	void OnHandleButtonBaseDoubleClicked(class CommonButtonBase* BaseButton_69);
	void OnHandleButtonBaseClicked(class CommonButtonBase* BaseButton_69);
	void OnButtonBaseUnhovered(class CommonButtonBase* BaseButton_69);
	void OnButtonBaseHovered(class CommonButtonBase* BaseButton_69);
	bool HasAnyButtons();
	int GetSelectedButtonIndex();
	class CommonButtonBase* GetSelectedButtonBase();
	int GetHoveredButtonIndex();
	int GetButtonCount();
	class CommonButtonBase* GetButtonBaseAtIndex(int Index_69);
	int FindButtonIndex(class CommonButtonBase* ButtonToFind_69);
	void DeselectAll();
};


// Class CommonUI.CommonBoundActionBar
// 0x0010 (0x0238 - 0x0228)
class CommonBoundActionBar : public DynamicEntryBoxBase
{
public:
	class CommonBoundActionButton*                     ActionButtonClass_69;                                     // 0x0228(0x0008) (Edit, ZeroConstructor)
	bool                                               bDisplayOwningPlayerActionsOnly_69;                       // 0x0230(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	bool                                               bIgnoreDuplicateActions_69;                               // 0x0231(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x6];                                       // 0x0232(0x0006) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CommonUI.CommonBoundActionBar"));
		
		return ptr;
	}


	void SetDisplayOwningPlayerActionsOnly(bool bShouldOnlyDisplayOwningPlayerActions_69);
};


// Class CommonUI.CommonBoundActionButton
// 0x0010 (0x13F0 - 0x13E0)
class CommonBoundActionButton : public CommonButtonBase
{
public:
	class CommonTextBlock*                             Text_ActionName_69;                                       // 0x13E0(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)
	unsigned char                                      UnknownData00[0x8];                                       // 0x13E8(0x0008) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CommonUI.CommonBoundActionButton"));
		
		return ptr;
	}


	void OnUpdateInputAction();
};


// Class CommonUI.CommonGenericInputActionDataTable
// 0x0000 (0x00B0 - 0x00B0)
class CommonGenericInputActionDataTable : public DataTable
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CommonUI.CommonGenericInputActionDataTable"));
		
		return ptr;
	}

};


// Class CommonUI.CommonInputActionDataProcessor
// 0x0000 (0x0028 - 0x0028)
class CommonInputActionDataProcessor : public Object_32759
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CommonUI.CommonInputActionDataProcessor"));
		
		return ptr;
	}

};


// Class CommonUI.CommonUIActionRouterBase
// 0x0128 (0x0158 - 0x0030)
class CommonUIActionRouterBase : public LocalPlayerSubsystem
{
public:
	unsigned char                                      UnknownData00[0x128];                                     // 0x0030(0x0128) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CommonUI.CommonUIActionRouterBase"));
		
		return ptr;
	}

};


// Class CommonUI.CommonUIInputSettings
// 0x0050 (0x0078 - 0x0028)
class CommonUIInputSettings : public Object_32759
{
public:
	bool                                               bLinkCursorToGamepadFocus_69;                             // 0x0028(0x0001) (Edit, ZeroConstructor, Config, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0029(0x0003) MISSED OFFSET
	int                                                UIActionProcessingPriority_69;                            // 0x002C(0x0004) (Edit, ZeroConstructor, Config, IsPlainOldData)
	TArray<struct FUIInputAction>                      InputActions_69;                                          // 0x0030(0x0010) (Edit, ZeroConstructor, Config)
	TArray<struct FUIInputAction>                      ActionOverrides_69;                                       // 0x0040(0x0010) (ZeroConstructor, Config)
	struct FCommonAnalogCursorSettings                 AnalogCursorSettings_69;                                  // 0x0050(0x0024) (Edit, Config)
	unsigned char                                      UnknownData01[0x4];                                       // 0x0074(0x0004) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CommonUI.CommonUIInputSettings"));
		
		return ptr;
	}

};


// Class CommonUI.CommonStyleSheet
// 0x0028 (0x0058 - 0x0030)
class CommonStyleSheet : public DataAsset
{
public:
	TArray<class CommonStyleSheetTypeBase*>            Properties_69;                                            // 0x0030(0x0010) (Edit, ExportObject, ZeroConstructor, DisableEditOnInstance)
	TArray<class CommonStyleSheet*>                    ImportedStyleSheets_69;                                   // 0x0040(0x0010) (Edit, ZeroConstructor, DisableEditOnInstance)
	unsigned char                                      UnknownData00[0x8];                                       // 0x0050(0x0008) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CommonUI.CommonStyleSheet"));
		
		return ptr;
	}

};


// Class CommonUI.CommonActivatableWidgetContainerBase
// 0x0120 (0x0268 - 0x0148)
class CommonActivatableWidgetContainerBase : public Widget
{
public:
	unsigned char                                      UnknownData00[0x18];                                      // 0x0148(0x0018) MISSED OFFSET
	ECommonSwitcherTransition                          TransitionType_69;                                        // 0x0160(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	ETransitionCurve                                   TransitionCurveType_69;                                   // 0x0161(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x2];                                       // 0x0162(0x0002) MISSED OFFSET
	float                                              TransitionDuration_69;                                    // 0x0164(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	TArray<class CommonActivatableWidget*>             WidgetList_69;                                            // 0x0168(0x0010) (ExportObject, ZeroConstructor, Transient)
	class CommonActivatableWidget*                     DisplayedWidget_69;                                       // 0x0178(0x0008) (ExportObject, ZeroConstructor, Transient, InstancedReference)
	struct FUserWidgetPool                             GeneratedWidgetsPool_69;                                  // 0x0180(0x0088) (Transient)
	unsigned char                                      UnknownData02[0x60];                                      // 0x0208(0x0060) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CommonUI.CommonActivatableWidgetContainerBase"));
		
		return ptr;
	}


	void SetTransitionDuration(float Duration_69);
	void RemoveWidget(class CommonActivatableWidget* WidgetToRemove_69);
	float GetTransitionDuration();
	class CommonActivatableWidget* GetActiveWidget();
	void ClearWidgets();
	class CommonActivatableWidget* BP_AddWidget(class CommonActivatableWidget* ActivatableWidgetClass_69);
};


// Class CommonUI.CommonActivatableWidgetStack
// 0x0010 (0x0278 - 0x0268)
class CommonActivatableWidgetStack : public CommonActivatableWidgetContainerBase
{
public:
	class CommonActivatableWidget*                     RootContentWidgetClass_69;                                // 0x0268(0x0008) (Edit, ZeroConstructor)
	class CommonActivatableWidget*                     RootContentWidget_69;                                     // 0x0270(0x0008) (ExportObject, ZeroConstructor, Transient, InstancedReference)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CommonUI.CommonActivatableWidgetStack"));
		
		return ptr;
	}

};


// Class CommonUI.CommonActivatableWidgetQueue
// 0x0000 (0x0268 - 0x0268)
class CommonActivatableWidgetQueue : public CommonActivatableWidgetContainerBase
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CommonUI.CommonActivatableWidgetQueue"));
		
		return ptr;
	}

};


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Functions
//---------------------------------------------------------------------------

// Function CommonInput.CommonInputBaseControllerData.GetRegisteredGamepads
// (Final, Native, Static, Public)
// Parameters:
// TArray<struct FName>           ReturnValue_69                 (ConstParm, Parm, OutParm, ZeroConstructor, ReturnParm, ReferenceParm)

TArray<struct FName> CommonInputBaseControllerData::STATIC_GetRegisteredGamepads()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonInput.CommonInputBaseControllerData.GetRegisteredGamepads"));

	CommonInputBaseControllerData_GetRegisteredGamepads_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CommonInput.CommonInputSubsystem.ShouldShowInputKeys
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool CommonInputSubsystem::ShouldShowInputKeys()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonInput.CommonInputSubsystem.ShouldShowInputKeys"));

	CommonInputSubsystem_ShouldShowInputKeys_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CommonInput.CommonInputSubsystem.SetGamepadInputType
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// struct FName                   InGamepadInputType_69          (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void CommonInputSubsystem::SetGamepadInputType(const struct FName& InGamepadInputType_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonInput.CommonInputSubsystem.SetGamepadInputType"));

	CommonInputSubsystem_SetGamepadInputType_Params params;
	params.InGamepadInputType_69 = InGamepadInputType_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonInput.CommonInputSubsystem.SetCurrentInputType
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// ECommonInputType               NewInputType_69                (Parm, ZeroConstructor, IsPlainOldData)

void CommonInputSubsystem::SetCurrentInputType(ECommonInputType NewInputType_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonInput.CommonInputSubsystem.SetCurrentInputType"));

	CommonInputSubsystem_SetCurrentInputType_Params params;
	params.NewInputType_69 = NewInputType_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonInput.CommonInputSubsystem.IsUsingPointerInput
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool CommonInputSubsystem::IsUsingPointerInput()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonInput.CommonInputSubsystem.IsUsingPointerInput"));

	CommonInputSubsystem_IsUsingPointerInput_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CommonInput.CommonInputSubsystem.IsInputMethodActive
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// ECommonInputType               InputMethod_69                 (Parm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool CommonInputSubsystem::IsInputMethodActive(ECommonInputType InputMethod_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonInput.CommonInputSubsystem.IsInputMethodActive"));

	CommonInputSubsystem_IsInputMethodActive_Params params;
	params.InputMethod_69 = InputMethod_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CommonInput.CommonInputSubsystem.GetDefaultInputType
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// ECommonInputType               ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

ECommonInputType CommonInputSubsystem::GetDefaultInputType()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonInput.CommonInputSubsystem.GetDefaultInputType"));

	CommonInputSubsystem_GetDefaultInputType_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CommonInput.CommonInputSubsystem.GetCurrentInputType
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// ECommonInputType               ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

ECommonInputType CommonInputSubsystem::GetCurrentInputType()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonInput.CommonInputSubsystem.GetCurrentInputType"));

	CommonInputSubsystem_GetCurrentInputType_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CommonInput.CommonInputSubsystem.GetCurrentGamepadName
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FName                   ReturnValue_69                 (ConstParm, Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

struct FName CommonInputSubsystem::GetCurrentGamepadName()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonInput.CommonInputSubsystem.GetCurrentGamepadName"));

	CommonInputSubsystem_GetCurrentGamepadName_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

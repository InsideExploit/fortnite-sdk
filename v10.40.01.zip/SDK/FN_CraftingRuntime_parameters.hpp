#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function CraftingRuntime.CraftingObjectBGA.HandleInteractionRangeEndOverlap
struct CraftingObjectBGA_HandleInteractionRangeEndOverlap_Params
{
	class PrimitiveComponent*                          OverlappedComponent_69;                                   // (Parm, ZeroConstructor, InstancedReference)
	class Actor_32759*                                 OtherActor_69;                                            // (Parm, ZeroConstructor)
	class PrimitiveComponent*                          OtherComp_69;                                             // (Parm, ZeroConstructor, InstancedReference)
	int                                                OtherBodyIndex_69;                                        // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function CraftingRuntime.CraftingObjectBGA.HandleInteractionRangeBeginOverlap
struct CraftingObjectBGA_HandleInteractionRangeBeginOverlap_Params
{
	class PrimitiveComponent*                          OverlappedComponent_69;                                   // (Parm, ZeroConstructor, InstancedReference)
	class Actor_32759*                                 OtherActor_69;                                            // (Parm, ZeroConstructor)
	class PrimitiveComponent*                          OtherComp_69;                                             // (Parm, ZeroConstructor, InstancedReference)
	int                                                OtherBodyIndex_69;                                        // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bFromSweep_69;                                            // (Parm, ZeroConstructor, IsPlainOldData)
	struct FHitResult                                  SweepResult_69;                                           // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
};

// Function CraftingRuntime.CraftingCheatManager.ToggleFreeCrafting
struct CraftingCheatManager_ToggleFreeCrafting_Params
{
};

// Function CraftingRuntime.CraftingCheatManager.StartSelfCrafting
struct CraftingCheatManager_StartSelfCrafting_Params
{
	struct FName                                       FormulaName_69;                                           // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function CraftingRuntime.CraftingObjectComponent.OnRep_CraftingObjectRepStateData
struct CraftingObjectComponent_OnRep_CraftingObjectRepStateData_Params
{
};

// Function CraftingRuntime.CraftingObjectComponent.HandlePickupCraftingItemPickedUp
struct CraftingObjectComponent_HandlePickupCraftingItemPickedUp_Params
{
	class FortPickup*                                  PickUp_69;                                                // (Parm, ZeroConstructor)
	class FortPawn*                                    InteractingPawn_69;                                       // (Parm, ZeroConstructor)
	class FortWorldItemDefinition*                     WorldItemDefinition_69;                                   // (ConstParm, Parm, ZeroConstructor)
	struct FVector                                     PickupLocation_69;                                        // (Parm, ZeroConstructor, IsPlainOldData)
};

// DelegateFunction CraftingRuntime.CraftingObjectComponent.CraftingObjectStateChanged__DelegateSignature
struct CraftingObjectComponent_CraftingObjectStateChanged__DelegateSignature_Params
{
	ECraftingObjectState                               CraftingState_69;                                         // (Parm, ZeroConstructor, IsPlainOldData)
	float                                              CraftingStateStartTime_69;                                // (Parm, ZeroConstructor, IsPlainOldData)
	float                                              CraftingStateDuration_69;                                 // (Parm, ZeroConstructor, IsPlainOldData)
};

// DelegateFunction CraftingRuntime.CraftingObjectComponent.CraftingObjectOnFormulaCraftableChanged__DelegateSignature
struct CraftingObjectComponent_CraftingObjectOnFormulaCraftableChanged__DelegateSignature_Params
{
	struct FName                                       FormulaRowName_69;                                        // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
	bool                                               bIsCraftable_69;                                          // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function CraftingRuntime.FortControllerComponent_CraftingNetworkEvents.ServerStartCrafting
struct FortControllerComponent_CraftingNetworkEvents_ServerStartCrafting_Params
{
	class Actor_32759*                                 CraftingObject_69;                                        // (Parm, ZeroConstructor)
	struct FName                                       CraftingFormulaName_69;                                   // (ConstParm, Parm, ZeroConstructor, ReferenceParm, IsPlainOldData)
	int                                                NumberToCraft_69;                                         // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function CraftingRuntime.FortControllerComponent_CraftingNetworkEvents.ServerReportCraftingSuccess
struct FortControllerComponent_CraftingNetworkEvents_ServerReportCraftingSuccess_Params
{
	class Actor_32759*                                 CraftingObject_69;                                        // (Parm, ZeroConstructor)
};

// Function CraftingRuntime.FortControllerComponent_CraftingNetworkEvents.ServerPickupItemAndStartCrafting
struct FortControllerComponent_CraftingNetworkEvents_ServerPickupItemAndStartCrafting_Params
{
	class Actor_32759*                                 CraftingObject_69;                                        // (Parm, ZeroConstructor)
	class FortPickup*                                  PickUp_69;                                                // (Parm, ZeroConstructor)
	struct FName                                       CraftingFormulaName_69;                                   // (ConstParm, Parm, ZeroConstructor, ReferenceParm, IsPlainOldData)
};

// Function CraftingRuntime.FortControllerComponent_CraftingNetworkEvents.ServerEjectItems
struct FortControllerComponent_CraftingNetworkEvents_ServerEjectItems_Params
{
	class Actor_32759*                                 CraftingObject_69;                                        // (Parm, ZeroConstructor)
};

// Function CraftingRuntime.FortControllerComponent_CraftingNetworkEvents.ServerClaimCraftingResults
struct FortControllerComponent_CraftingNetworkEvents_ServerClaimCraftingResults_Params
{
	class Actor_32759*                                 CraftingObject_69;                                        // (Parm, ZeroConstructor)
};

// Function CraftingRuntime.FortControllerComponent_CraftingNetworkEvents.ServerCancelCrafting
struct FortControllerComponent_CraftingNetworkEvents_ServerCancelCrafting_Params
{
	class Actor_32759*                                 CraftingObject_69;                                        // (Parm, ZeroConstructor)
};

// Function CraftingRuntime.FortControllerComponent_CraftingNetworkEvents.NotifyCraftingSuccess
struct FortControllerComponent_CraftingNetworkEvents_NotifyCraftingSuccess_Params
{
	class Actor_32759*                                 CraftingObject_69;                                        // (Parm, ZeroConstructor)
	struct FName                                       FormulaRowName_69;                                        // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
};

// Function CraftingRuntime.FortControllerComponent_CraftingNetworkEvents.ClientNotifyCraftingSuccess
struct FortControllerComponent_CraftingNetworkEvents_ClientNotifyCraftingSuccess_Params
{
	class Actor_32759*                                 CraftingObject_69;                                        // (Parm, ZeroConstructor)
	struct FName                                       FormulaRowName_69;                                        // (ConstParm, Parm, ZeroConstructor, ReferenceParm, IsPlainOldData)
};

// Function CraftingRuntime.FortControllerComponent_CraftingNetworkEvents.ClientNotifyCraftingFailed
struct FortControllerComponent_CraftingNetworkEvents_ClientNotifyCraftingFailed_Params
{
	class Actor_32759*                                 CraftingObject_69;                                        // (Parm, ZeroConstructor)
	struct FGameplayTagContainer                       FailedReason_69;                                          // (ConstParm, Parm, ReferenceParm)
};

// Function CraftingRuntime.FortGameStateComponent_Crafting.OnRep_CraftingResultsList
struct FortGameStateComponent_Crafting_OnRep_CraftingResultsList_Params
{
};

// Function CraftingRuntime.FortGameStateComponent_Crafting.OnPlaylistDataReady
struct FortGameStateComponent_Crafting_OnPlaylistDataReady_Params
{
	class FortGameStateAthena*                         GameState_69;                                             // (Parm, ZeroConstructor)
	class FortPlaylist*                                Playlist_69;                                              // (ConstParm, Parm, ZeroConstructor)
	struct FGameplayTagContainer                       PlaylistContextTags_69;                                   // (ConstParm, Parm, OutParm, ReferenceParm)
};

// Function CraftingRuntime.FortContextualTutorial_CraftingComplete.OnCraftingSuccess
struct FortContextualTutorial_CraftingComplete_OnCraftingSuccess_Params
{
	class FortPlayerController*                        Instigator_69;                                            // (Parm, ZeroConstructor)
	class Actor_32759*                                 CraftingObject_69;                                        // (Parm, ZeroConstructor)
	struct FName                                       FormulaRowName_69;                                        // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
};

// Function CraftingRuntime.FortContextualTutorial_CraftingReady.HandleFormulaCraftableChanged
struct FortContextualTutorial_CraftingReady_HandleFormulaCraftableChanged_Params
{
	struct FName                                       FormulaRowName_69;                                        // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
	bool                                               bIsCraftable_69;                                          // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function CraftingRuntime.FortContextualTutorial_CraftingTabOpen.HandleInventoryTabChanged
struct FortContextualTutorial_CraftingTabOpen_HandleInventoryTabChanged_Params
{
	struct FName                                       InventoryTabNameId_69;                                    // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function CraftingRuntime.FortContextualTutorial_CraftingTabOpen.HandleFormulaCraftableChanged
struct FortContextualTutorial_CraftingTabOpen_HandleFormulaCraftableChanged_Params
{
	struct FName                                       FormulaRowName_69;                                        // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
	bool                                               bIsCraftable_69;                                          // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function CraftingRuntime.CraftingLibrary.StartCrafting
struct CraftingLibrary_StartCrafting_Params
{
	class FortPlayerController*                        Instigator_69;                                            // (Parm, ZeroConstructor)
	class Actor_32759*                                 CraftingObject_69;                                        // (Parm, ZeroConstructor)
	struct FName                                       CraftingFormulaName_69;                                   // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
	int                                                NumberToCraft_69;                                         // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function CraftingRuntime.CraftingLibrary.ReportCraftingSuccess
struct CraftingLibrary_ReportCraftingSuccess_Params
{
	class FortPlayerController*                        Instigator_69;                                            // (Parm, ZeroConstructor)
	class Actor_32759*                                 CraftingObject_69;                                        // (Parm, ZeroConstructor)
};

// Function CraftingRuntime.CraftingLibrary.PickupItemAndStartCrafting
struct CraftingLibrary_PickupItemAndStartCrafting_Params
{
	class FortPlayerController*                        Instigator_69;                                            // (Parm, ZeroConstructor)
	class Actor_32759*                                 CraftingObject_69;                                        // (Parm, ZeroConstructor)
	class FortPickup*                                  PickUp_69;                                                // (Parm, ZeroConstructor)
	struct FName                                       CraftingFormulaName_69;                                   // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
};

// Function CraftingRuntime.CraftingLibrary.IsValidIngredient
struct CraftingLibrary_IsValidIngredient_Params
{
	class FortPlayerController*                        FortPC_69;                                                // (ConstParm, Parm, ZeroConstructor)
	class Actor_32759*                                 CraftingObject_69;                                        // (ConstParm, Parm, ZeroConstructor)
	class FortItemDefinition*                          ItemDef_69;                                               // (ConstParm, Parm, ZeroConstructor)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CraftingRuntime.CraftingLibrary.GiveItemToCraftingObject
struct CraftingLibrary_GiveItemToCraftingObject_Params
{
	class FortPlayerController*                        Instigator_69;                                            // (Parm, ZeroConstructor)
	class Actor_32759*                                 CraftingObject_69;                                        // (Parm, ZeroConstructor)
	struct FFortItemEntry                              ItemEntryToGrant_69;                                      // (ConstParm, Parm, OutParm, ReferenceParm)
};

// Function CraftingRuntime.CraftingLibrary.GetValidIngredientsInInventory
struct CraftingLibrary_GetValidIngredientsInInventory_Params
{
	class FortPlayerController*                        FortPC_69;                                                // (ConstParm, Parm, ZeroConstructor)
	class Actor_32759*                                 CraftingObject_69;                                        // (ConstParm, Parm, ZeroConstructor)
	TArray<class FortWorldItem*>                       OutIngredients_69;                                        // (Parm, OutParm, ZeroConstructor)
};

// Function CraftingRuntime.CraftingLibrary.GetUIDataForCraftingIngredientTags
struct CraftingLibrary_GetUIDataForCraftingIngredientTags_Params
{
	class Object_32759*                                WorldContextObject_69;                                    // (Parm, ZeroConstructor)
	struct FGameplayTagContainer                       IngredientTags_69;                                        // (ConstParm, Parm, OutParm, ReferenceParm)
};

// Function CraftingRuntime.CraftingLibrary.GetKnownCraftingFormulas
struct CraftingLibrary_GetKnownCraftingFormulas_Params
{
	class FortPlayerController*                        FortPC_69;                                                // (ConstParm, Parm, ZeroConstructor)
	class Actor_32759*                                 CraftingObject_69;                                        // (ConstParm, Parm, ZeroConstructor)
	TArray<struct FName>                               OutFormulas_69;                                           // (Parm, OutParm, ZeroConstructor)
};

// Function CraftingRuntime.CraftingLibrary.GetIngredientsInCraftingObject
struct CraftingLibrary_GetIngredientsInCraftingObject_Params
{
	class Actor_32759*                                 CraftingObject_69;                                        // (Parm, ZeroConstructor)
	TArray<class FortWorldItem*>                       ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function CraftingRuntime.CraftingLibrary.GetCraftingResultsForRowName
struct CraftingLibrary_GetCraftingResultsForRowName_Params
{
	class Object_32759*                                WorldContextObject_69;                                    // (ConstParm, Parm, ZeroConstructor)
	struct FName                                       CraftingFormulaRow_69;                                    // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
	TArray<struct FItemAndCount>                       OutResults_69;                                            // (Parm, OutParm, ZeroConstructor)
	int                                                NumToCraft_69;                                            // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function CraftingRuntime.CraftingLibrary.GetCraftingObjectCurrentCraftingStateTimeLeft
struct CraftingLibrary_GetCraftingObjectCurrentCraftingStateTimeLeft_Params
{
	class Actor_32759*                                 CraftingObject_69;                                        // (ConstParm, Parm, ZeroConstructor)
	float                                              ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CraftingRuntime.CraftingLibrary.GetCraftingObjectCurrentCraftingStateStartTime
struct CraftingLibrary_GetCraftingObjectCurrentCraftingStateStartTime_Params
{
	class Actor_32759*                                 CraftingObject_69;                                        // (ConstParm, Parm, ZeroConstructor)
	float                                              ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CraftingRuntime.CraftingLibrary.GetCraftingObjectCurrentCraftingStateEndTime
struct CraftingLibrary_GetCraftingObjectCurrentCraftingStateEndTime_Params
{
	class Actor_32759*                                 CraftingObject_69;                                        // (ConstParm, Parm, ZeroConstructor)
	float                                              ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CraftingRuntime.CraftingLibrary.GetCraftingObjectCraftingState
struct CraftingLibrary_GetCraftingObjectCraftingState_Params
{
	class Actor_32759*                                 CraftingObject_69;                                        // (Parm, ZeroConstructor)
	ECraftingObjectState                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CraftingRuntime.CraftingLibrary.GetCraftingIngredients_TempItems
struct CraftingLibrary_GetCraftingIngredients_TempItems_Params
{
	class Actor_32759*                                 CraftingObject_69;                                        // (Parm, ZeroConstructor)
	TArray<class FortWorldItem*>                       ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function CraftingRuntime.CraftingLibrary.GetCraftingFormulaNameBeingCrafted
struct CraftingLibrary_GetCraftingFormulaNameBeingCrafted_Params
{
	class Actor_32759*                                 CraftingObject_69;                                        // (Parm, ZeroConstructor)
	struct FName                                       ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CraftingRuntime.CraftingLibrary.GetCraftingFormulaIngredientRequirements
struct CraftingLibrary_GetCraftingFormulaIngredientRequirements_Params
{
	class Object_32759*                                WorldContextObject_69;                                    // (Parm, ZeroConstructor)
	struct FName                                       CraftingFormulaRow_69;                                    // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
	TArray<struct FCraftingIngredientRequirement>      OutIngredientRequirements_69;                             // (Parm, OutParm, ZeroConstructor)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CraftingRuntime.CraftingLibrary.GetCraftedResults_TempItems
struct CraftingLibrary_GetCraftedResults_TempItems_Params
{
	class Actor_32759*                                 CraftingObject_69;                                        // (Parm, ZeroConstructor)
	TArray<class FortWorldItem*>                       ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function CraftingRuntime.CraftingLibrary.GetAllValidIngredients
struct CraftingLibrary_GetAllValidIngredients_Params
{
	class FortPlayerController*                        FortPC_69;                                                // (ConstParm, Parm, ZeroConstructor)
	class Actor_32759*                                 CraftingObject_69;                                        // (ConstParm, Parm, ZeroConstructor)
	TArray<struct FGameplayTagContainer>               OutIngredients_69;                                        // (Parm, OutParm, ZeroConstructor)
};

// Function CraftingRuntime.CraftingLibrary.GetAllCraftingFormulas
struct CraftingLibrary_GetAllCraftingFormulas_Params
{
	class FortPlayerController*                        FortPC_69;                                                // (ConstParm, Parm, ZeroConstructor)
	class Actor_32759*                                 CraftingObject_69;                                        // (ConstParm, Parm, ZeroConstructor)
	TArray<struct FName>                               OutFormulas_69;                                           // (Parm, OutParm, ZeroConstructor)
};

// Function CraftingRuntime.CraftingLibrary.GetAllCraftableFormulas
struct CraftingLibrary_GetAllCraftableFormulas_Params
{
	class FortPlayerController*                        FortPC_69;                                                // (ConstParm, Parm, ZeroConstructor)
	class Actor_32759*                                 CraftingObject_69;                                        // (ConstParm, Parm, ZeroConstructor)
	TArray<struct FName>                               OutFormulas_69;                                           // (Parm, OutParm, ZeroConstructor)
};

// Function CraftingRuntime.CraftingLibrary.EjectItems
struct CraftingLibrary_EjectItems_Params
{
	class FortPlayerController*                        Instigator_69;                                            // (Parm, ZeroConstructor)
	class Actor_32759*                                 CraftingObject_69;                                        // (Parm, ZeroConstructor)
};

// Function CraftingRuntime.CraftingLibrary.ClaimCraftingResults
struct CraftingLibrary_ClaimCraftingResults_Params
{
	class FortPlayerController*                        Instigator_69;                                            // (Parm, ZeroConstructor)
	class Actor_32759*                                 CraftingObject_69;                                        // (Parm, ZeroConstructor)
};

// Function CraftingRuntime.CraftingLibrary.CanCraftFormulaWithAdditionalItems
struct CraftingLibrary_CanCraftFormulaWithAdditionalItems_Params
{
	class FortPlayerController*                        FortPC_69;                                                // (ConstParm, Parm, ZeroConstructor)
	class Actor_32759*                                 CraftingObject_69;                                        // (ConstParm, Parm, ZeroConstructor)
	struct FName                                       CraftingFormulaRow_69;                                    // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	TArray<struct FItemAndCount>                       AdditionalItems_69;                                       // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	TArray<struct FCraftingIngredientQueryState>       OutIngredientStates_69;                                   // (Parm, OutParm, ZeroConstructor)
	int                                                NumberToCraft_69;                                         // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CraftingRuntime.CraftingLibrary.CanCraftFormula
struct CraftingLibrary_CanCraftFormula_Params
{
	class FortPlayerController*                        FortPC_69;                                                // (ConstParm, Parm, ZeroConstructor)
	class Actor_32759*                                 CraftingObject_69;                                        // (ConstParm, Parm, ZeroConstructor)
	struct FName                                       CraftingFormulaRow_69;                                    // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	TArray<struct FCraftingIngredientQueryState>       OutIngredientStates_69;                                   // (Parm, OutParm, ZeroConstructor)
	int                                                NumberToCraft_69;                                         // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CraftingRuntime.CraftingLibrary.CancelCrafting
struct CraftingLibrary_CancelCrafting_Params
{
	class FortPlayerController*                        Instigator_69;                                            // (Parm, ZeroConstructor)
	class Actor_32759*                                 CraftingObject_69;                                        // (Parm, ZeroConstructor)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

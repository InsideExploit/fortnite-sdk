// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Functions
//---------------------------------------------------------------------------

// Function CustomizableObjectPopulation.CustomizableObjectPopulation.RegeneratePopulation
// (Final, Native, Public, HasOutParms, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// int                            Seed_69                        (Parm, ZeroConstructor, IsPlainOldData)
// TArray<class CustomizableObjectInstance*> OutInstances_69                (Parm, OutParm, ZeroConstructor)
// int                            NumInstancesToGenerate_69      (Parm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool CustomizableObjectPopulation::RegeneratePopulation(int Seed_69, int NumInstancesToGenerate_69, TArray<class CustomizableObjectInstance*>* OutInstances_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CustomizableObjectPopulation.CustomizableObjectPopulation.RegeneratePopulation"));

	CustomizableObjectPopulation_RegeneratePopulation_Params params;
	params.Seed_69 = Seed_69;
	params.NumInstancesToGenerate_69 = NumInstancesToGenerate_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (OutInstances_69 != nullptr)
		*OutInstances_69 = params.OutInstances_69;

	return params.ReturnValue_69;
}


// Function CustomizableObjectPopulation.CustomizableObjectPopulation.GeneratePopulation
// (Final, Native, Public, HasOutParms, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// TArray<class CustomizableObjectInstance*> OutInstances_69                (Parm, OutParm, ZeroConstructor)
// int                            NumInstancesToGenerate_69      (Parm, ZeroConstructor, IsPlainOldData)
// int                            ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int CustomizableObjectPopulation::GeneratePopulation(int NumInstancesToGenerate_69, TArray<class CustomizableObjectInstance*>* OutInstances_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CustomizableObjectPopulation.CustomizableObjectPopulation.GeneratePopulation"));

	CustomizableObjectPopulation_GeneratePopulation_Params params;
	params.NumInstancesToGenerate_69 = NumInstancesToGenerate_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (OutInstances_69 != nullptr)
		*OutInstances_69 = params.OutInstances_69;

	return params.ReturnValue_69;
}


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

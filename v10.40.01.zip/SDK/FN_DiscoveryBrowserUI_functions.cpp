// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Functions
//---------------------------------------------------------------------------

// Function DiscoveryBrowserUI.FortActivityBrowserTabButton.OnFavoriteChanged
// (Event, Public, BlueprintEvent)
// Parameters:
// bool                           bIsFavorite_69                 (Parm, ZeroConstructor, IsPlainOldData)

void FortActivityBrowserTabButton::OnFavoriteChanged(bool bIsFavorite_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DiscoveryBrowserUI.FortActivityBrowserTabButton.OnFavoriteChanged"));

	FortActivityBrowserTabButton_OnFavoriteChanged_Params params;
	params.bIsFavorite_69 = bIsFavorite_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function DiscoveryBrowserUI.FortActivityBrowserView.OnSurfaceDataDirty
// (Event, Protected, BlueprintEvent)

void FortActivityBrowserView::OnSurfaceDataDirty()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DiscoveryBrowserUI.FortActivityBrowserView.OnSurfaceDataDirty"));

	FortActivityBrowserView_OnSurfaceDataDirty_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function DiscoveryBrowserUI.FortActivityBrowserView.GetInvalidActivityReason
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// EFortInvalidActivityReason     ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

EFortInvalidActivityReason FortActivityBrowserView::GetInvalidActivityReason()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DiscoveryBrowserUI.FortActivityBrowserView.GetInvalidActivityReason"));

	FortActivityBrowserView_GetInvalidActivityReason_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function DiscoveryBrowserUI.FortActivityPlayerBrowserView.PlayViewIntro
// (Final, Native, Public, BlueprintCallable)

void FortActivityPlayerBrowserView::PlayViewIntro()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DiscoveryBrowserUI.FortActivityPlayerBrowserView.PlayViewIntro"));

	FortActivityPlayerBrowserView_PlayViewIntro_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function DiscoveryBrowserUI.FortActivityPlayerBrowserView.OnPlayViewIntro
// (Event, Protected, BlueprintEvent)

void FortActivityPlayerBrowserView::OnPlayViewIntro()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DiscoveryBrowserUI.FortActivityPlayerBrowserView.OnPlayViewIntro"));

	FortActivityPlayerBrowserView_OnPlayViewIntro_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function DiscoveryBrowserUI.FortActivityPlayerBrowserView.BP_OnTileViewUpdated
// (Event, Protected, BlueprintEvent)

void FortActivityPlayerBrowserView::BP_OnTileViewUpdated()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DiscoveryBrowserUI.FortActivityPlayerBrowserView.BP_OnTileViewUpdated"));

	FortActivityPlayerBrowserView_BP_OnTileViewUpdated_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function DiscoveryBrowserUI.FortActivityCreatorPageView.OnPlayerQueueTypeChanged
// (Event, Protected, BlueprintEvent)
// Parameters:
// EPlayerQueueType               PlayerQueueType_69             (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void FortActivityCreatorPageView::OnPlayerQueueTypeChanged(EPlayerQueueType PlayerQueueType_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DiscoveryBrowserUI.FortActivityCreatorPageView.OnPlayerQueueTypeChanged"));

	FortActivityCreatorPageView_OnPlayerQueueTypeChanged_Params params;
	params.PlayerQueueType_69 = PlayerQueueType_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function DiscoveryBrowserUI.FortActivityCreatorPageView.OnCreatorActivitiesQueryFinished
// (Event, Protected, BlueprintEvent)

void FortActivityCreatorPageView::OnCreatorActivitiesQueryFinished()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DiscoveryBrowserUI.FortActivityCreatorPageView.OnCreatorActivitiesQueryFinished"));

	FortActivityCreatorPageView_OnCreatorActivitiesQueryFinished_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function DiscoveryBrowserUI.FortActivityBrowser.OnUpdateCategoryPage
// (Event, Protected, BlueprintEvent)
// Parameters:
// bool                           bShowCategoryPage_69           (Parm, ZeroConstructor, IsPlainOldData)

void FortActivityBrowser::OnUpdateCategoryPage(bool bShowCategoryPage_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DiscoveryBrowserUI.FortActivityBrowser.OnUpdateCategoryPage"));

	FortActivityBrowser_OnUpdateCategoryPage_Params params;
	params.bShowCategoryPage_69 = bShowCategoryPage_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function DiscoveryBrowserUI.FortActivityBrowser.OnSwapColorScheme
// (Event, Protected, BlueprintEvent)
// Parameters:
// bool                           bInIsUsingAlternateColorScheme_69 (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void FortActivityBrowser::OnSwapColorScheme(bool bInIsUsingAlternateColorScheme_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DiscoveryBrowserUI.FortActivityBrowser.OnSwapColorScheme"));

	FortActivityBrowser_OnSwapColorScheme_Params params;
	params.bInIsUsingAlternateColorScheme_69 = bInIsUsingAlternateColorScheme_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function DiscoveryBrowserUI.FortActivityBrowser.OnPlayerQueueTypeChanged
// (Event, Protected, BlueprintEvent)
// Parameters:
// EPlayerQueueType               PlayerQueueType_69             (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void FortActivityBrowser::OnPlayerQueueTypeChanged(EPlayerQueueType PlayerQueueType_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DiscoveryBrowserUI.FortActivityBrowser.OnPlayerQueueTypeChanged"));

	FortActivityBrowser_OnPlayerQueueTypeChanged_Params params;
	params.PlayerQueueType_69 = PlayerQueueType_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function DiscoveryBrowserUI.FortActivityBrowser.OnEnableColorScheme
// (Event, Protected, BlueprintEvent)
// Parameters:
// bool                           bIsColorSchemeActive_69        (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void FortActivityBrowser::OnEnableColorScheme(bool bIsColorSchemeActive_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DiscoveryBrowserUI.FortActivityBrowser.OnEnableColorScheme"));

	FortActivityBrowser_OnEnableColorScheme_Params params;
	params.bIsColorSchemeActive_69 = bIsColorSchemeActive_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function DiscoveryBrowserUI.FortActivityBrowser.OnActivitySelected
// (Event, Protected, BlueprintEvent)

void FortActivityBrowser::OnActivitySelected()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DiscoveryBrowserUI.FortActivityBrowser.OnActivitySelected"));

	FortActivityBrowser_OnActivitySelected_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function DiscoveryBrowserUI.FortActivityBrowser.HandleTabChanged
// (Final, Native, Private)
// Parameters:
// struct FName                   TabId_69                       (Parm, ZeroConstructor, IsPlainOldData)

void FortActivityBrowser::HandleTabChanged(const struct FName& TabId_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DiscoveryBrowserUI.FortActivityBrowser.HandleTabChanged"));

	FortActivityBrowser_HandleTabChanged_Params params;
	params.TabId_69 = TabId_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function DiscoveryBrowserUI.FortActivityBrowserRow.OnRowPeekStateChanged
// (Event, Protected, BlueprintEvent)
// Parameters:
// bool                           bIsInPeekState_69              (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void FortActivityBrowserRow::OnRowPeekStateChanged(bool bIsInPeekState_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DiscoveryBrowserUI.FortActivityBrowserRow.OnRowPeekStateChanged"));

	FortActivityBrowserRow_OnRowPeekStateChanged_Params params;
	params.bIsInPeekState_69 = bIsInPeekState_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function DiscoveryBrowserUI.FortActivityBrowserRow.OnRowMoveUp
// (Event, Protected, BlueprintEvent)
// Parameters:
// bool                           bMovingOffscreen_69            (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void FortActivityBrowserRow::OnRowMoveUp(bool bMovingOffscreen_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DiscoveryBrowserUI.FortActivityBrowserRow.OnRowMoveUp"));

	FortActivityBrowserRow_OnRowMoveUp_Params params;
	params.bMovingOffscreen_69 = bMovingOffscreen_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function DiscoveryBrowserUI.FortActivityBrowserRow.OnRowMoveDown
// (Event, Protected, BlueprintEvent)
// Parameters:
// bool                           bMovingOffscreen_69            (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void FortActivityBrowserRow::OnRowMoveDown(bool bMovingOffscreen_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DiscoveryBrowserUI.FortActivityBrowserRow.OnRowMoveDown"));

	FortActivityBrowserRow_OnRowMoveDown_Params params;
	params.bMovingOffscreen_69 = bMovingOffscreen_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function DiscoveryBrowserUI.FortActivityBrowserRow.OnRowIsSelectedChanged
// (Event, Protected, BlueprintEvent)
// Parameters:
// bool                           bIsSelected_69                 (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void FortActivityBrowserRow::OnRowIsSelectedChanged(bool bIsSelected_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DiscoveryBrowserUI.FortActivityBrowserRow.OnRowIsSelectedChanged"));

	FortActivityBrowserRow_OnRowIsSelectedChanged_Params params;
	params.bIsSelected_69 = bIsSelected_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function DiscoveryBrowserUI.FortActivityBrowserRow.OnRowIsActiveChanged
// (Event, Protected, BlueprintEvent)
// Parameters:
// bool                           bIsActive_69                   (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void FortActivityBrowserRow::OnRowIsActiveChanged(bool bIsActive_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DiscoveryBrowserUI.FortActivityBrowserRow.OnRowIsActiveChanged"));

	FortActivityBrowserRow_OnRowIsActiveChanged_Params params;
	params.bIsActive_69 = bIsActive_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function DiscoveryBrowserUI.FortActivityBrowserRow.OnCategoryItemChanged
// (Event, Protected, BlueprintEvent)
// Parameters:
// bool                           bPlayAnimation_69              (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void FortActivityBrowserRow::OnCategoryItemChanged(bool bPlayAnimation_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DiscoveryBrowserUI.FortActivityBrowserRow.OnCategoryItemChanged"));

	FortActivityBrowserRow_OnCategoryItemChanged_Params params;
	params.bPlayAnimation_69 = bPlayAnimation_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function DiscoveryBrowserUI.FortActivityBrowserRow.GetIsSelected
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool FortActivityBrowserRow::GetIsSelected()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DiscoveryBrowserUI.FortActivityBrowserRow.GetIsSelected"));

	FortActivityBrowserRow_GetIsSelected_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function DiscoveryBrowserUI.FortActivityBrowserRow.GetIsInPeekState
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool FortActivityBrowserRow::GetIsInPeekState()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DiscoveryBrowserUI.FortActivityBrowserRow.GetIsInPeekState"));

	FortActivityBrowserRow_GetIsInPeekState_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function DiscoveryBrowserUI.FortActivityBrowserRow.GetIsActive
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool FortActivityBrowserRow::GetIsActive()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DiscoveryBrowserUI.FortActivityBrowserRow.GetIsActive"));

	FortActivityBrowserRow_GetIsActive_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function DiscoveryBrowserUI.FortActivityBrowserRowHero.OnVideoStarted
// (Event, Public, BlueprintEvent)

void FortActivityBrowserRowHero::OnVideoStarted()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DiscoveryBrowserUI.FortActivityBrowserRowHero.OnVideoStarted"));

	FortActivityBrowserRowHero_OnVideoStarted_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function DiscoveryBrowserUI.FortActivityBrowserRowHero.OnVideoEndReached
// (Event, Public, BlueprintEvent)

void FortActivityBrowserRowHero::OnVideoEndReached()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DiscoveryBrowserUI.FortActivityBrowserRowHero.OnVideoEndReached"));

	FortActivityBrowserRowHero_OnVideoEndReached_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function DiscoveryBrowserUI.FortActivityBrowserRowHero.OnUpdateDetailsDisplay
// (Event, Public, BlueprintEvent)

void FortActivityBrowserRowHero::OnUpdateDetailsDisplay()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DiscoveryBrowserUI.FortActivityBrowserRowHero.OnUpdateDetailsDisplay"));

	FortActivityBrowserRowHero_OnUpdateDetailsDisplay_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function DiscoveryBrowserUI.FortActivityBrowserRowHero.OnRowHeroFocusChanged
// (Event, Public, BlueprintEvent)
// Parameters:
// bool                           bHasFocus_69                   (Parm, ZeroConstructor, IsPlainOldData)

void FortActivityBrowserRowHero::OnRowHeroFocusChanged(bool bHasFocus_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DiscoveryBrowserUI.FortActivityBrowserRowHero.OnRowHeroFocusChanged"));

	FortActivityBrowserRowHero_OnRowHeroFocusChanged_Params params;
	params.bHasFocus_69 = bHasFocus_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function DiscoveryBrowserUI.FortActivityBrowserRowHero.OnQueryStatusChanged
// (Event, Public, BlueprintEvent)
// Parameters:
// bool                           bIsActive_69                   (Parm, ZeroConstructor, IsPlainOldData)

void FortActivityBrowserRowHero::OnQueryStatusChanged(bool bIsActive_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DiscoveryBrowserUI.FortActivityBrowserRowHero.OnQueryStatusChanged"));

	FortActivityBrowserRowHero_OnQueryStatusChanged_Params params;
	params.bIsActive_69 = bIsActive_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function DiscoveryBrowserUI.FortActivityBrowserRowHero.OnQueryActivitiesFinished
// (Event, Public, BlueprintEvent)

void FortActivityBrowserRowHero::OnQueryActivitiesFinished()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DiscoveryBrowserUI.FortActivityBrowserRowHero.OnQueryActivitiesFinished"));

	FortActivityBrowserRowHero_OnQueryActivitiesFinished_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function DiscoveryBrowserUI.FortActivityBrowserRowHero.OnPreviewImageChanged
// (Event, Public, BlueprintEvent)
// Parameters:
// bool                           bIsLoading_69                  (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// class Texture*                 Texture_69                     (ConstParm, Parm, ZeroConstructor)

void FortActivityBrowserRowHero::OnPreviewImageChanged(bool bIsLoading_69, class Texture* Texture_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DiscoveryBrowserUI.FortActivityBrowserRowHero.OnPreviewImageChanged"));

	FortActivityBrowserRowHero_OnPreviewImageChanged_Params params;
	params.bIsLoading_69 = bIsLoading_69;
	params.Texture_69 = Texture_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function DiscoveryBrowserUI.FortActivityBrowserRowHero.OnPlayKeyArtOutro
// (Event, Public, BlueprintEvent)

void FortActivityBrowserRowHero::OnPlayKeyArtOutro()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DiscoveryBrowserUI.FortActivityBrowserRowHero.OnPlayKeyArtOutro"));

	FortActivityBrowserRowHero_OnPlayKeyArtOutro_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function DiscoveryBrowserUI.FortActivityBrowserRowHero.OnPlayKeyArtIntro
// (Event, Public, BlueprintEvent)

void FortActivityBrowserRowHero::OnPlayKeyArtIntro()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DiscoveryBrowserUI.FortActivityBrowserRowHero.OnPlayKeyArtIntro"));

	FortActivityBrowserRowHero_OnPlayKeyArtIntro_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function DiscoveryBrowserUI.FortActivityBrowserRowHero.OnActivityUpdated
// (Event, Public, BlueprintEvent)

void FortActivityBrowserRowHero::OnActivityUpdated()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DiscoveryBrowserUI.FortActivityBrowserRowHero.OnActivityUpdated"));

	FortActivityBrowserRowHero_OnActivityUpdated_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function DiscoveryBrowserUI.FortActivityBrowserRowHero.IsShowingSeasonalContent
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool FortActivityBrowserRowHero::IsShowingSeasonalContent()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DiscoveryBrowserUI.FortActivityBrowserRowHero.IsShowingSeasonalContent"));

	FortActivityBrowserRowHero_IsShowingSeasonalContent_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function DiscoveryBrowserUI.FortActivityBrowserRowHero.IsInOutroState
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool FortActivityBrowserRowHero::IsInOutroState()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DiscoveryBrowserUI.FortActivityBrowserRowHero.IsInOutroState"));

	FortActivityBrowserRowHero_IsInOutroState_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function DiscoveryBrowserUI.FortActivityBrowserRowHero.IsImageLoading
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool FortActivityBrowserRowHero::IsImageLoading()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DiscoveryBrowserUI.FortActivityBrowserRowHero.IsImageLoading"));

	FortActivityBrowserRowHero_IsImageLoading_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function DiscoveryBrowserUI.FortActivityBrowserRowHero.HandleActivityVideoCycleStarted
// (Final, Native, Private)

void FortActivityBrowserRowHero::HandleActivityVideoCycleStarted()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DiscoveryBrowserUI.FortActivityBrowserRowHero.HandleActivityVideoCycleStarted"));

	FortActivityBrowserRowHero_HandleActivityVideoCycleStarted_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function DiscoveryBrowserUI.FortActivityBrowserRowHero.HandleActivityVideoCycleEndReached
// (Final, Native, Private)

void FortActivityBrowserRowHero::HandleActivityVideoCycleEndReached()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DiscoveryBrowserUI.FortActivityBrowserRowHero.HandleActivityVideoCycleEndReached"));

	FortActivityBrowserRowHero_HandleActivityVideoCycleEndReached_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function DiscoveryBrowserUI.FortActivityBrowserRowHero.GetKeyArtOutroAnimation
// (Native, Event, Public, BlueprintCallable, BlueprintEvent, BlueprintPure, Const)
// Parameters:
// class WidgetAnimation*         ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

class WidgetAnimation* FortActivityBrowserRowHero::GetKeyArtOutroAnimation()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DiscoveryBrowserUI.FortActivityBrowserRowHero.GetKeyArtOutroAnimation"));

	FortActivityBrowserRowHero_GetKeyArtOutroAnimation_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function DiscoveryBrowserUI.FortActivityBrowserRowHero.GetCurrentTexture
// (Native, Event, Public, BlueprintCallable, BlueprintEvent, BlueprintPure, Const)
// Parameters:
// class Texture*                 ReturnValue_69                 (ConstParm, Parm, OutParm, ZeroConstructor, ReturnParm)

class Texture* FortActivityBrowserRowHero::GetCurrentTexture()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DiscoveryBrowserUI.FortActivityBrowserRowHero.GetCurrentTexture"));

	FortActivityBrowserRowHero_GetCurrentTexture_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function DiscoveryBrowserUI.FortActivityBrowserRowHero.CycleNextActivity
// (Final, Native, Public, BlueprintCallable)

void FortActivityBrowserRowHero::CycleNextActivity()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DiscoveryBrowserUI.FortActivityBrowserRowHero.CycleNextActivity"));

	FortActivityBrowserRowHero_CycleNextActivity_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function DiscoveryBrowserUI.FortActivityBrowserRowHero.CheckUpdateDetailsDelay
// (Final, Native, Private)

void FortActivityBrowserRowHero::CheckUpdateDetailsDelay()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DiscoveryBrowserUI.FortActivityBrowserRowHero.CheckUpdateDetailsDelay"));

	FortActivityBrowserRowHero_CheckUpdateDetailsDelay_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function DiscoveryBrowserUI.FortActivityBrowserRowList.OnQueryStatusChanged
// (Event, Public, BlueprintEvent)
// Parameters:
// bool                           bIsActive_69                   (Parm, ZeroConstructor, IsPlainOldData)

void FortActivityBrowserRowList::OnQueryStatusChanged(bool bIsActive_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DiscoveryBrowserUI.FortActivityBrowserRowList.OnQueryStatusChanged"));

	FortActivityBrowserRowList_OnQueryStatusChanged_Params params;
	params.bIsActive_69 = bIsActive_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function DiscoveryBrowserUI.FortActivityBrowserRowPromoted.OnPreviewImageChanged
// (Event, Protected, BlueprintEvent)
// Parameters:
// bool                           bIsLoading_69                  (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// class Texture*                 Texture_69                     (ConstParm, Parm, ZeroConstructor)

void FortActivityBrowserRowPromoted::OnPreviewImageChanged(bool bIsLoading_69, class Texture* Texture_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DiscoveryBrowserUI.FortActivityBrowserRowPromoted.OnPreviewImageChanged"));

	FortActivityBrowserRowPromoted_OnPreviewImageChanged_Params params;
	params.bIsLoading_69 = bIsLoading_69;
	params.Texture_69 = Texture_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function DiscoveryBrowserUI.FortActivityBrowserRowView.OnRowChanged
// (Event, Public, BlueprintEvent)
// Parameters:
// int                            NewCategoryIndex_69            (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void FortActivityBrowserRowView::OnRowChanged(int NewCategoryIndex_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DiscoveryBrowserUI.FortActivityBrowserRowView.OnRowChanged"));

	FortActivityBrowserRowView_OnRowChanged_Params params;
	params.NewCategoryIndex_69 = NewCategoryIndex_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function DiscoveryBrowserUI.FortActivityBrowserRowView.OnQueryActivitiesFinished
// (Event, Public, BlueprintEvent)

void FortActivityBrowserRowView::OnQueryActivitiesFinished()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DiscoveryBrowserUI.FortActivityBrowserRowView.OnQueryActivitiesFinished"));

	FortActivityBrowserRowView_OnQueryActivitiesFinished_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function DiscoveryBrowserUI.FortActivityBrowserRowView.OnActivityUpdated
// (Event, Public, BlueprintEvent)

void FortActivityBrowserRowView::OnActivityUpdated()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DiscoveryBrowserUI.FortActivityBrowserRowView.OnActivityUpdated"));

	FortActivityBrowserRowView_OnActivityUpdated_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function DiscoveryBrowserUI.FortActivityBrowserTile.HandleActivitySelected
// (Final, Native, Private)

void FortActivityBrowserTile::HandleActivitySelected()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DiscoveryBrowserUI.FortActivityBrowserTile.HandleActivitySelected"));

	FortActivityBrowserTile_HandleActivitySelected_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function DiscoveryBrowserUI.FortActivityCategoryTile.OnTileActiveSet
// (Event, Protected, BlueprintEvent)
// Parameters:
// bool                           bIsTileActive_69               (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void FortActivityCategoryTile::OnTileActiveSet(bool bIsTileActive_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DiscoveryBrowserUI.FortActivityCategoryTile.OnTileActiveSet"));

	FortActivityCategoryTile_OnTileActiveSet_Params params;
	params.bIsTileActive_69 = bIsTileActive_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function DiscoveryBrowserUI.FortActivityCategoryView.OnSurfaceDataReady
// (Event, Protected, BlueprintEvent)

void FortActivityCategoryView::OnSurfaceDataReady()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DiscoveryBrowserUI.FortActivityCategoryView.OnSurfaceDataReady"));

	FortActivityCategoryView_OnSurfaceDataReady_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function DiscoveryBrowserUI.FortActivityCategoryView.OnCategoryTilePanelSelected
// (Event, Protected, BlueprintEvent)
// Parameters:
// class FortActivityCategoryTilePanel* SelectedPanel_69               (ConstParm, Parm, ZeroConstructor, InstancedReference)

void FortActivityCategoryView::OnCategoryTilePanelSelected(class FortActivityCategoryTilePanel* SelectedPanel_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DiscoveryBrowserUI.FortActivityCategoryView.OnCategoryTilePanelSelected"));

	FortActivityCategoryView_OnCategoryTilePanelSelected_Params params;
	params.SelectedPanel_69 = SelectedPanel_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function DiscoveryBrowserUI.FortActivityCategoryView.NavigateFromPanel
// (Final, Native, Protected, BlueprintCallable)
// Parameters:
// EUINavigation                  Direction_69                   (Parm, ZeroConstructor, IsPlainOldData)
// class FortActivityCategoryTilePanel* NavigatingPanel_69             (Parm, ZeroConstructor, InstancedReference)
// class FortActivityCategoryTilePanel* ReturnValue_69                 (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)

class FortActivityCategoryTilePanel* FortActivityCategoryView::NavigateFromPanel(EUINavigation Direction_69, class FortActivityCategoryTilePanel* NavigatingPanel_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DiscoveryBrowserUI.FortActivityCategoryView.NavigateFromPanel"));

	FortActivityCategoryView_NavigateFromPanel_Params params;
	params.Direction_69 = Direction_69;
	params.NavigatingPanel_69 = NavigatingPanel_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function DiscoveryBrowserUI.FortActivityCategoryView.GetTopMostVisiblePanel
// (Native, Event, Protected, BlueprintEvent, Const)
// Parameters:
// class FortActivityCategoryTilePanel* ReturnValue_69                 (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)

class FortActivityCategoryTilePanel* FortActivityCategoryView::GetTopMostVisiblePanel()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DiscoveryBrowserUI.FortActivityCategoryView.GetTopMostVisiblePanel"));

	FortActivityCategoryView_GetTopMostVisiblePanel_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function DiscoveryBrowserUI.FortActivityCategoryView.GetCurrentSelectedPanel
// (Final, Native, Protected, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// class FortActivityCategoryTilePanel* ReturnValue_69                 (ConstParm, ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)

class FortActivityCategoryTilePanel* FortActivityCategoryView::GetCurrentSelectedPanel()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DiscoveryBrowserUI.FortActivityCategoryView.GetCurrentSelectedPanel"));

	FortActivityCategoryView_GetCurrentSelectedPanel_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function DiscoveryBrowserUI.FortActivityCreateView.OnCreativeActivityUpdated
// (Event, Protected, BlueprintEvent)

void FortActivityCreateView::OnCreativeActivityUpdated()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DiscoveryBrowserUI.FortActivityCreateView.OnCreativeActivityUpdated"));

	FortActivityCreateView_OnCreativeActivityUpdated_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function DiscoveryBrowserUI.FortActivityCreateView.GetInvalidCreativeActivityReason
// (Final, Native, Protected, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// EFortInvalidActivityReason     ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

EFortInvalidActivityReason FortActivityCreateView::GetInvalidCreativeActivityReason()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DiscoveryBrowserUI.FortActivityCreateView.GetInvalidCreativeActivityReason"));

	FortActivityCreateView_GetInvalidCreativeActivityReason_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function DiscoveryBrowserUI.FortActivityDiscoverView.OnUpdateDetailsDisplay
// (Event, Public, BlueprintEvent)

void FortActivityDiscoverView::OnUpdateDetailsDisplay()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DiscoveryBrowserUI.FortActivityDiscoverView.OnUpdateDetailsDisplay"));

	FortActivityDiscoverView_OnUpdateDetailsDisplay_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function DiscoveryBrowserUI.FortActivityDiscoverView.OnPreviewImageChanged
// (Event, Public, BlueprintEvent)
// Parameters:
// bool                           bIsLoading_69                  (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// class Texture*                 Texture_69                     (ConstParm, Parm, ZeroConstructor)

void FortActivityDiscoverView::OnPreviewImageChanged(bool bIsLoading_69, class Texture* Texture_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DiscoveryBrowserUI.FortActivityDiscoverView.OnPreviewImageChanged"));

	FortActivityDiscoverView_OnPreviewImageChanged_Params params;
	params.bIsLoading_69 = bIsLoading_69;
	params.Texture_69 = Texture_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function DiscoveryBrowserUI.FortActivityDiscoverView.OnPlayKeyArtOutro
// (Event, Public, BlueprintEvent)

void FortActivityDiscoverView::OnPlayKeyArtOutro()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DiscoveryBrowserUI.FortActivityDiscoverView.OnPlayKeyArtOutro"));

	FortActivityDiscoverView_OnPlayKeyArtOutro_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function DiscoveryBrowserUI.FortActivityDiscoverView.OnPlayKeyArtIntro
// (Event, Public, BlueprintEvent)

void FortActivityDiscoverView::OnPlayKeyArtIntro()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DiscoveryBrowserUI.FortActivityDiscoverView.OnPlayKeyArtIntro"));

	FortActivityDiscoverView_OnPlayKeyArtIntro_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function DiscoveryBrowserUI.FortActivityDiscoverView.OnMoviePreEndEvent
// (Event, Public, BlueprintEvent)

void FortActivityDiscoverView::OnMoviePreEndEvent()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DiscoveryBrowserUI.FortActivityDiscoverView.OnMoviePreEndEvent"));

	FortActivityDiscoverView_OnMoviePreEndEvent_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function DiscoveryBrowserUI.FortActivityDiscoverView.OnMoviePlayingChanged
// (Event, Public, BlueprintEvent)
// Parameters:
// bool                           bIsPlaying_69                  (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void FortActivityDiscoverView::OnMoviePlayingChanged(bool bIsPlaying_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DiscoveryBrowserUI.FortActivityDiscoverView.OnMoviePlayingChanged"));

	FortActivityDiscoverView_OnMoviePlayingChanged_Params params;
	params.bIsPlaying_69 = bIsPlaying_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function DiscoveryBrowserUI.FortActivityDiscoverView.IsShowingSeasonalContent
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool FortActivityDiscoverView::IsShowingSeasonalContent()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DiscoveryBrowserUI.FortActivityDiscoverView.IsShowingSeasonalContent"));

	FortActivityDiscoverView_IsShowingSeasonalContent_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function DiscoveryBrowserUI.FortActivityDiscoverView.IsShowingPromotedContent
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool FortActivityDiscoverView::IsShowingPromotedContent()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DiscoveryBrowserUI.FortActivityDiscoverView.IsShowingPromotedContent"));

	FortActivityDiscoverView_IsShowingPromotedContent_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function DiscoveryBrowserUI.FortActivityDiscoverView.IsInOutroState
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool FortActivityDiscoverView::IsInOutroState()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DiscoveryBrowserUI.FortActivityDiscoverView.IsInOutroState"));

	FortActivityDiscoverView_IsInOutroState_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function DiscoveryBrowserUI.FortActivityDiscoverView.IsImageLoading
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool FortActivityDiscoverView::IsImageLoading()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DiscoveryBrowserUI.FortActivityDiscoverView.IsImageLoading"));

	FortActivityDiscoverView_IsImageLoading_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function DiscoveryBrowserUI.FortActivityDiscoverView.HandleMovieWidgetMediaStarted
// (Final, Native, Private)

void FortActivityDiscoverView::HandleMovieWidgetMediaStarted()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DiscoveryBrowserUI.FortActivityDiscoverView.HandleMovieWidgetMediaStarted"));

	FortActivityDiscoverView_HandleMovieWidgetMediaStarted_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function DiscoveryBrowserUI.FortActivityDiscoverView.HandleMovieWidgetMediaPreEndEvent
// (Final, Native, Private)

void FortActivityDiscoverView::HandleMovieWidgetMediaPreEndEvent()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DiscoveryBrowserUI.FortActivityDiscoverView.HandleMovieWidgetMediaPreEndEvent"));

	FortActivityDiscoverView_HandleMovieWidgetMediaPreEndEvent_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function DiscoveryBrowserUI.FortActivityDiscoverView.GetPromotedMovieWidget
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// class FortActivatableMovieWidget* ReturnValue_69                 (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)

class FortActivatableMovieWidget* FortActivityDiscoverView::GetPromotedMovieWidget()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DiscoveryBrowserUI.FortActivityDiscoverView.GetPromotedMovieWidget"));

	FortActivityDiscoverView_GetPromotedMovieWidget_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function DiscoveryBrowserUI.FortActivityDiscoverView.GetMovieWidget
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// class FortActivatableMovieWidget* ReturnValue_69                 (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)

class FortActivatableMovieWidget* FortActivityDiscoverView::GetMovieWidget()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DiscoveryBrowserUI.FortActivityDiscoverView.GetMovieWidget"));

	FortActivityDiscoverView_GetMovieWidget_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function DiscoveryBrowserUI.FortActivityDiscoverView.GetKeyArtOutroAnimation
// (Native, Event, Public, BlueprintCallable, BlueprintEvent, BlueprintPure, Const)
// Parameters:
// class WidgetAnimation*         ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

class WidgetAnimation* FortActivityDiscoverView::GetKeyArtOutroAnimation()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DiscoveryBrowserUI.FortActivityDiscoverView.GetKeyArtOutroAnimation"));

	FortActivityDiscoverView_GetKeyArtOutroAnimation_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function DiscoveryBrowserUI.FortActivityDiscoverView.GetCurrentTexture
// (Native, Event, Public, BlueprintCallable, BlueprintEvent, BlueprintPure, Const)
// Parameters:
// class Texture*                 ReturnValue_69                 (ConstParm, Parm, OutParm, ZeroConstructor, ReturnParm)

class Texture* FortActivityDiscoverView::GetCurrentTexture()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DiscoveryBrowserUI.FortActivityDiscoverView.GetCurrentTexture"));

	FortActivityDiscoverView_GetCurrentTexture_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function DiscoveryBrowserUI.FortActivityDiscoverView.CheckUpdateDetailsDelay
// (Final, Native, Private)

void FortActivityDiscoverView::CheckUpdateDetailsDelay()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DiscoveryBrowserUI.FortActivityDiscoverView.CheckUpdateDetailsDelay"));

	FortActivityDiscoverView_CheckUpdateDetailsDelay_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function DiscoveryBrowserUI.FortActivityDiscoverViewV2.IsShowingSeasonalContent
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool FortActivityDiscoverViewV2::IsShowingSeasonalContent()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DiscoveryBrowserUI.FortActivityDiscoverViewV2.IsShowingSeasonalContent"));

	FortActivityDiscoverViewV2_IsShowingSeasonalContent_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function DiscoveryBrowserUI.FortActivityDiscoverViewV2.IsShowingPromotedContent
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool FortActivityDiscoverViewV2::IsShowingPromotedContent()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DiscoveryBrowserUI.FortActivityDiscoverViewV2.IsShowingPromotedContent"));

	FortActivityDiscoverViewV2_IsShowingPromotedContent_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function DiscoveryBrowserUI.FortActivityListView.GetInViewCount
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// int                            ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int FortActivityListView::GetInViewCount()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DiscoveryBrowserUI.FortActivityListView.GetInViewCount"));

	FortActivityListView_GetInViewCount_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function DiscoveryBrowserUI.FortActivityLobbyTile.TrySendFirstTimeNotification
// (Final, Native, Public, BlueprintCallable)

void FortActivityLobbyTile::TrySendFirstTimeNotification()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DiscoveryBrowserUI.FortActivityLobbyTile.TrySendFirstTimeNotification"));

	FortActivityLobbyTile_TrySendFirstTimeNotification_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function DiscoveryBrowserUI.FortActivityLobbyTile.ShowModeSetSelectionModal
// (Final, Native, Public, BlueprintCallable)

void FortActivityLobbyTile::ShowModeSetSelectionModal()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DiscoveryBrowserUI.FortActivityLobbyTile.ShowModeSetSelectionModal"));

	FortActivityLobbyTile_ShowModeSetSelectionModal_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function DiscoveryBrowserUI.FortActivityLobbyTile.OnShowChildActivityFirstTimeNotification
// (Event, Protected, BlueprintEvent)

void FortActivityLobbyTile::OnShowChildActivityFirstTimeNotification()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DiscoveryBrowserUI.FortActivityLobbyTile.OnShowChildActivityFirstTimeNotification"));

	FortActivityLobbyTile_OnShowChildActivityFirstTimeNotification_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function DiscoveryBrowserUI.FortActivityLobbyTile.OnShowChildActivityChangedNotification
// (Event, Protected, HasOutParms, BlueprintEvent)
// Parameters:
// struct FText                   DisplayName_69                 (ConstParm, Parm, OutParm, ReferenceParm)

void FortActivityLobbyTile::OnShowChildActivityChangedNotification(const struct FText& DisplayName_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DiscoveryBrowserUI.FortActivityLobbyTile.OnShowChildActivityChangedNotification"));

	FortActivityLobbyTile_OnShowChildActivityChangedNotification_Params params;
	params.DisplayName_69 = DisplayName_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function DiscoveryBrowserUI.FortActivityLobbyTile.OnPreviewImageChanged
// (Event, Protected, BlueprintEvent)
// Parameters:
// bool                           bIsLoading_69                  (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// class Texture*                 Texture_69                     (ConstParm, Parm, ZeroConstructor)

void FortActivityLobbyTile::OnPreviewImageChanged(bool bIsLoading_69, class Texture* Texture_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DiscoveryBrowserUI.FortActivityLobbyTile.OnPreviewImageChanged"));

	FortActivityLobbyTile_OnPreviewImageChanged_Params params;
	params.bIsLoading_69 = bIsLoading_69;
	params.Texture_69 = Texture_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function DiscoveryBrowserUI.FortActivityLobbyTile.OnHideChildActivityFirstTimeNotification
// (Event, Protected, BlueprintEvent)

void FortActivityLobbyTile::OnHideChildActivityFirstTimeNotification()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DiscoveryBrowserUI.FortActivityLobbyTile.OnHideChildActivityFirstTimeNotification"));

	FortActivityLobbyTile_OnHideChildActivityFirstTimeNotification_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function DiscoveryBrowserUI.FortActivityLobbyTile.OnDetailsUpdated
// (Event, Protected, BlueprintEvent)

void FortActivityLobbyTile::OnDetailsUpdated()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DiscoveryBrowserUI.FortActivityLobbyTile.OnDetailsUpdated"));

	FortActivityLobbyTile_OnDetailsUpdated_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function DiscoveryBrowserUI.FortActivityLobbyTile.IsModeSetActivity
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool FortActivityLobbyTile::IsModeSetActivity()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DiscoveryBrowserUI.FortActivityLobbyTile.IsModeSetActivity"));

	FortActivityLobbyTile_IsModeSetActivity_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function DiscoveryBrowserUI.FortActivityLobbyTile.IsActivityEpicCreated
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool FortActivityLobbyTile::IsActivityEpicCreated()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DiscoveryBrowserUI.FortActivityLobbyTile.IsActivityEpicCreated"));

	FortActivityLobbyTile_IsActivityEpicCreated_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function DiscoveryBrowserUI.FortActivityLobbyTile.GetChildActivityDisplayName
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FText                   ReturnValue_69                 (Parm, OutParm, ReturnParm)

struct FText FortActivityLobbyTile::GetChildActivityDisplayName()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DiscoveryBrowserUI.FortActivityLobbyTile.GetChildActivityDisplayName"));

	FortActivityLobbyTile_GetChildActivityDisplayName_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function DiscoveryBrowserUI.FortActivityModeSetSelectionModal.SaveSelectionAndClose
// (Final, Native, Protected, BlueprintCallable)

void FortActivityModeSetSelectionModal::SaveSelectionAndClose()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DiscoveryBrowserUI.FortActivityModeSetSelectionModal.SaveSelectionAndClose"));

	FortActivityModeSetSelectionModal_SaveSelectionAndClose_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function DiscoveryBrowserUI.FortActivityModeSetSelectionModal.OnSubModeSelectionChanged
// (Event, Protected, BlueprintEvent)

void FortActivityModeSetSelectionModal::OnSubModeSelectionChanged()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DiscoveryBrowserUI.FortActivityModeSetSelectionModal.OnSubModeSelectionChanged"));

	FortActivityModeSetSelectionModal_OnSubModeSelectionChanged_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function DiscoveryBrowserUI.FortActivityModeSetSelectionModal.OnSubModeSelected
// (Event, Protected, BlueprintEvent)

void FortActivityModeSetSelectionModal::OnSubModeSelected()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DiscoveryBrowserUI.FortActivityModeSetSelectionModal.OnSubModeSelected"));

	FortActivityModeSetSelectionModal_OnSubModeSelected_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function DiscoveryBrowserUI.FortActivityModeSetSelectionModal.OnPreviewImageChanged
// (Event, Protected, BlueprintEvent)
// Parameters:
// bool                           bIsLoading_69                  (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// class Texture*                 Texture_69                     (ConstParm, Parm, ZeroConstructor)

void FortActivityModeSetSelectionModal::OnPreviewImageChanged(bool bIsLoading_69, class Texture* Texture_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DiscoveryBrowserUI.FortActivityModeSetSelectionModal.OnPreviewImageChanged"));

	FortActivityModeSetSelectionModal_OnPreviewImageChanged_Params params;
	params.bIsLoading_69 = bIsLoading_69;
	params.Texture_69 = Texture_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function DiscoveryBrowserUI.FortActivityModeSetSelectionModal.OnActivityChanged
// (Event, Protected, BlueprintEvent)
// Parameters:
// class FortGameActivity*        GameActivity_69                (ConstParm, Parm, ZeroConstructor)
// struct FString                 StartingSelectedMnemonic_69    (Parm, ZeroConstructor)

void FortActivityModeSetSelectionModal::OnActivityChanged(class FortGameActivity* GameActivity_69, const struct FString& StartingSelectedMnemonic_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DiscoveryBrowserUI.FortActivityModeSetSelectionModal.OnActivityChanged"));

	FortActivityModeSetSelectionModal_OnActivityChanged_Params params;
	params.GameActivity_69 = GameActivity_69;
	params.StartingSelectedMnemonic_69 = StartingSelectedMnemonic_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function DiscoveryBrowserUI.FortActivityPlayerBrowserTile.HandleActivitySelected
// (Final, Native, Private)

void FortActivityPlayerBrowserTile::HandleActivitySelected()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DiscoveryBrowserUI.FortActivityPlayerBrowserTile.HandleActivitySelected"));

	FortActivityPlayerBrowserTile_HandleActivitySelected_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function DiscoveryBrowserUI.FortActivitySearchView.OnActivityValidated
// (Event, Protected, BlueprintEvent)
// Parameters:
// EFortActivityValidationResult  ValidateResult_69              (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void FortActivitySearchView::OnActivityValidated(EFortActivityValidationResult ValidateResult_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DiscoveryBrowserUI.FortActivitySearchView.OnActivityValidated"));

	FortActivitySearchView_OnActivityValidated_Params params;
	params.ValidateResult_69 = ValidateResult_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function DiscoveryBrowserUI.FortActivitySearchView.OnActivityClear
// (Event, Protected, BlueprintEvent)

void FortActivitySearchView::OnActivityClear()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DiscoveryBrowserUI.FortActivitySearchView.OnActivityClear"));

	FortActivitySearchView_OnActivityClear_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function DiscoveryBrowserUI.FortActivitySearchView.HandleTextCommitted
// (Final, Native, Private, HasOutParms)
// Parameters:
// struct FText                   InText_69                      (ConstParm, Parm, OutParm, ReferenceParm)
// TEnumAsByte<ETextCommit>       CommitInfo_69                  (Parm, ZeroConstructor, IsPlainOldData)

void FortActivitySearchView::HandleTextCommitted(const struct FText& InText_69, TEnumAsByte<ETextCommit> CommitInfo_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DiscoveryBrowserUI.FortActivitySearchView.HandleTextCommitted"));

	FortActivitySearchView_HandleTextCommitted_Params params;
	params.InText_69 = InText_69;
	params.CommitInfo_69 = CommitInfo_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function DiscoveryBrowserUI.FortActivitySearchView.HandleTextChanged
// (Final, Native, Private, HasOutParms)
// Parameters:
// struct FText                   Text_69                        (ConstParm, Parm, OutParm, ReferenceParm)

void FortActivitySearchView::HandleTextChanged(const struct FText& Text_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DiscoveryBrowserUI.FortActivitySearchView.HandleTextChanged"));

	FortActivitySearchView_HandleTextChanged_Params params;
	params.Text_69 = Text_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function DiscoveryBrowserUI.FortActivityTileDetailsDisplay.OnUpdateColumnSize
// (Event, Public, BlueprintEvent)
// Parameters:
// int                            NewColumnSize_69               (Parm, ZeroConstructor, IsPlainOldData)

void FortActivityTileDetailsDisplay::OnUpdateColumnSize(int NewColumnSize_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DiscoveryBrowserUI.FortActivityTileDetailsDisplay.OnUpdateColumnSize"));

	FortActivityTileDetailsDisplay_OnUpdateColumnSize_Params params;
	params.NewColumnSize_69 = NewColumnSize_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function DiscoveryBrowserUI.FortActivityTileDetailsDisplay.OnTileActiveSet
// (Event, Protected, BlueprintEvent)
// Parameters:
// bool                           bIsTileActive_69               (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void FortActivityTileDetailsDisplay::OnTileActiveSet(bool bIsTileActive_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DiscoveryBrowserUI.FortActivityTileDetailsDisplay.OnTileActiveSet"));

	FortActivityTileDetailsDisplay_OnTileActiveSet_Params params;
	params.bIsTileActive_69 = bIsTileActive_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function DiscoveryBrowserUI.FortActivityTileDetailsDisplay.OnSocialUsersPlayingChanged
// (Event, Protected, BlueprintEvent)
// Parameters:
// int                            NumPlaying_69                  (Parm, ZeroConstructor, IsPlainOldData)

void FortActivityTileDetailsDisplay::OnSocialUsersPlayingChanged(int NumPlaying_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DiscoveryBrowserUI.FortActivityTileDetailsDisplay.OnSocialUsersPlayingChanged"));

	FortActivityTileDetailsDisplay_OnSocialUsersPlayingChanged_Params params;
	params.NumPlaying_69 = NumPlaying_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function DiscoveryBrowserUI.FortActivityTileDetailsDisplay.OnRequiresPurchaseChanged
// (Event, Protected, BlueprintEvent)
// Parameters:
// bool                           bRequiresPurchase_69           (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void FortActivityTileDetailsDisplay::OnRequiresPurchaseChanged(bool bRequiresPurchase_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DiscoveryBrowserUI.FortActivityTileDetailsDisplay.OnRequiresPurchaseChanged"));

	FortActivityTileDetailsDisplay_OnRequiresPurchaseChanged_Params params;
	params.bRequiresPurchase_69 = bRequiresPurchase_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function DiscoveryBrowserUI.FortActivityTileDetailsDisplay.OnPreviewImageChanged
// (Event, Protected, BlueprintEvent)
// Parameters:
// bool                           bIsLoading_69                  (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// class Texture*                 Texture_69                     (ConstParm, Parm, ZeroConstructor)

void FortActivityTileDetailsDisplay::OnPreviewImageChanged(bool bIsLoading_69, class Texture* Texture_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DiscoveryBrowserUI.FortActivityTileDetailsDisplay.OnPreviewImageChanged"));

	FortActivityTileDetailsDisplay_OnPreviewImageChanged_Params params;
	params.bIsLoading_69 = bIsLoading_69;
	params.Texture_69 = Texture_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function DiscoveryBrowserUI.FortActivityTileDetailsDisplay.OnPartySizeChanged
// (Event, Protected, BlueprintEvent)
// Parameters:
// int                            PartySize_69                   (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void FortActivityTileDetailsDisplay::OnPartySizeChanged(int PartySize_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DiscoveryBrowserUI.FortActivityTileDetailsDisplay.OnPartySizeChanged"));

	FortActivityTileDetailsDisplay_OnPartySizeChanged_Params params;
	params.PartySize_69 = PartySize_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function DiscoveryBrowserUI.FortActivityTileDetailsDisplay.OnLocalPlayerPromotedToLeader
// (Event, Protected, BlueprintEvent)

void FortActivityTileDetailsDisplay::OnLocalPlayerPromotedToLeader()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DiscoveryBrowserUI.FortActivityTileDetailsDisplay.OnLocalPlayerPromotedToLeader"));

	FortActivityTileDetailsDisplay_OnLocalPlayerPromotedToLeader_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function DiscoveryBrowserUI.FortActivityTileDetailsDisplay.OnLocalPlayerDemoted
// (Event, Protected, BlueprintEvent)

void FortActivityTileDetailsDisplay::OnLocalPlayerDemoted()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DiscoveryBrowserUI.FortActivityTileDetailsDisplay.OnLocalPlayerDemoted"));

	FortActivityTileDetailsDisplay_OnLocalPlayerDemoted_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function DiscoveryBrowserUI.FortActivityTileDetailsDisplay.OnIsFavoriteChanged
// (Event, Protected, BlueprintEvent)
// Parameters:
// bool                           bIsFavorite_69                 (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void FortActivityTileDetailsDisplay::OnIsFavoriteChanged(bool bIsFavorite_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DiscoveryBrowserUI.FortActivityTileDetailsDisplay.OnIsFavoriteChanged"));

	FortActivityTileDetailsDisplay_OnIsFavoriteChanged_Params params;
	params.bIsFavorite_69 = bIsFavorite_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function DiscoveryBrowserUI.FortActivityTileDetailsDisplay.OnDetailsUpdated
// (Event, Protected, BlueprintEvent)

void FortActivityTileDetailsDisplay::OnDetailsUpdated()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DiscoveryBrowserUI.FortActivityTileDetailsDisplay.OnDetailsUpdated"));

	FortActivityTileDetailsDisplay_OnDetailsUpdated_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// DelegateFunction DiscoveryBrowserUI.FortActivityTileDetailsDisplay.OnActivityUnSelected__DelegateSignature
// (MulticastDelegate, Public, Delegate)

void FortActivityTileDetailsDisplay::OnActivityUnSelected__DelegateSignature()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("DelegateFunction DiscoveryBrowserUI.FortActivityTileDetailsDisplay.OnActivityUnSelected__DelegateSignature"));

	FortActivityTileDetailsDisplay_OnActivityUnSelected__DelegateSignature_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// DelegateFunction DiscoveryBrowserUI.FortActivityTileDetailsDisplay.OnActivitySelected__DelegateSignature
// (MulticastDelegate, Public, Delegate)

void FortActivityTileDetailsDisplay::OnActivitySelected__DelegateSignature()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("DelegateFunction DiscoveryBrowserUI.FortActivityTileDetailsDisplay.OnActivitySelected__DelegateSignature"));

	FortActivityTileDetailsDisplay_OnActivitySelected__DelegateSignature_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function DiscoveryBrowserUI.FortActivityTileDetailsDisplay.IsModeSetActivity
// (Final, Native, Protected, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool FortActivityTileDetailsDisplay::IsModeSetActivity()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DiscoveryBrowserUI.FortActivityTileDetailsDisplay.IsModeSetActivity"));

	FortActivityTileDetailsDisplay_IsModeSetActivity_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function DiscoveryBrowserUI.FortActivityTileDetailsDisplay.IsActivityFavorited
// (Final, Native, Protected, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool FortActivityTileDetailsDisplay::IsActivityFavorited()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DiscoveryBrowserUI.FortActivityTileDetailsDisplay.IsActivityFavorited"));

	FortActivityTileDetailsDisplay_IsActivityFavorited_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function DiscoveryBrowserUI.FortActivityTileDetailsDisplay.IsActivityEpicCreated
// (Final, Native, Protected, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool FortActivityTileDetailsDisplay::IsActivityEpicCreated()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DiscoveryBrowserUI.FortActivityTileDetailsDisplay.IsActivityEpicCreated"));

	FortActivityTileDetailsDisplay_IsActivityEpicCreated_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function DiscoveryBrowserUI.FortActivityTileDetailsDisplay.GetInvalidActivityReason
// (Final, Native, Protected, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// EFortInvalidActivityReason     ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

EFortInvalidActivityReason FortActivityTileDetailsDisplay::GetInvalidActivityReason()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DiscoveryBrowserUI.FortActivityTileDetailsDisplay.GetInvalidActivityReason"));

	FortActivityTileDetailsDisplay_GetInvalidActivityReason_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function DiscoveryBrowserUI.FortActivityTileDetailsDisplay.DoesActivityRequirePurchase
// (Final, Native, Protected, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool FortActivityTileDetailsDisplay::DoesActivityRequirePurchase()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DiscoveryBrowserUI.FortActivityTileDetailsDisplay.DoesActivityRequirePurchase"));

	FortActivityTileDetailsDisplay_DoesActivityRequirePurchase_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function DiscoveryBrowserUI.FortActivityTileView.SetListenForMouseWheelInput
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// bool                           bListenForInput_69             (Parm, ZeroConstructor, IsPlainOldData)

void FortActivityTileView::SetListenForMouseWheelInput(bool bListenForInput_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DiscoveryBrowserUI.FortActivityTileView.SetListenForMouseWheelInput"));

	FortActivityTileView_SetListenForMouseWheelInput_Params params;
	params.bListenForInput_69 = bListenForInput_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

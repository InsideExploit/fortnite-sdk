#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Classes
//---------------------------------------------------------------------------

// Class AIPatrolPath.AIPatrolPathComponent
// 0x02A8 (0x0348 - 0x00A0)
class AIPatrolPathComponent : public ActorComponent
{
public:
	unsigned char                                      UnknownData00[0x20];                                      // 0x00A0(0x0020) MISSED OFFSET
	unsigned char                                      UnknownData01[0x28];                                      // 0x00A0(0x0028) UNKNOWN PROPERTY: SoftClassProperty AIPatrolPath.AIPatrolPathComponent.DefaultAIPawn_69
	class BuildingActor*                               PathRendererClass_69;                                     // 0x00E8(0x0008) (Edit, BlueprintVisible, ZeroConstructor)
	bool                                               bAllowPartialPaths_69;                                    // 0x00F0(0x0001) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData02[0x7];                                       // 0x00F1(0x0007) MISSED OFFSET
	struct FGameplayTagContainer                       UnableToPlaceNewDeviceTags_69;                            // 0x00F8(0x0020) (Edit, DisableEditOnInstance)
	struct FNavAgentProperties                         CachedAIAgentProperties_69;                               // 0x0118(0x0030) (Transient)
	class NavigationSystemV1*                          CachedNavSystem_69;                                       // 0x0148(0x0008) (ZeroConstructor, Transient)
	class NavigationData*                              CachedNavData_69;                                         // 0x0150(0x0008) (ZeroConstructor, Transient)
	class NavigationQueryFilter*                       CachedFilterClass_69;                                     // 0x0158(0x0008) (Edit, ZeroConstructor, DisableEditOnInstance)
	unsigned char                                      UnknownData03[0x10];                                      // 0x0160(0x0010) MISSED OFFSET
	unsigned char                                      UnknownData04[0x10];                                      // 0x0160(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty AIPatrolPath.AIPatrolPathComponent.OnPatrolPointFailedToReach_69
	unsigned char                                      UnknownData05[0x10];                                      // 0x0180(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty AIPatrolPath.AIPatrolPathComponent.OnPatrolPointReached_69
	unsigned char                                      UnknownData06[0x10];                                      // 0x0190(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty AIPatrolPath.AIPatrolPathComponent.OnPatrolPathStarted_69
	unsigned char                                      UnknownData07[0x10];                                      // 0x01A0(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty AIPatrolPath.AIPatrolPathComponent.OnPatrolPathStopped_69
	unsigned char                                      UnknownData08[0x8];                                       // 0x01B0(0x0008) MISSED OFFSET
	TArray<class AIPatrolPathComponent*>               PatrolPath_69;                                            // 0x01B8(0x0010) (ExportObject, ZeroConstructor, Transient)
	struct FPatrolPathSegmentDetails                   PathSegmentDetails_69;                                    // 0x01C8(0x0108) (Transient)
	unsigned char                                      UnknownData09[0x10];                                      // 0x02D0(0x0010) MISSED OFFSET
	class AIPatrolPathComponent*                       CopiedFrom_69;                                            // 0x02E0(0x0008) (ExportObject, ZeroConstructor, Transient, InstancedReference)
	unsigned char                                      UnknownData10[0x8];                                       // 0x02E8(0x0008) MISSED OFFSET
	class AIPatrolPathComponent*                       CopiedFromCut_69;                                         // 0x02F0(0x0008) (ExportObject, ZeroConstructor, Transient, InstancedReference)
	class FortCreativePatrolPath*                      PatrolPathActor_69;                                       // 0x02F8(0x0008) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, Transient)
	class FortAthenaPatrolPoint*                       PatrolPointActor_69;                                      // 0x0300(0x0008) (ZeroConstructor, Transient)
	TArray<class AIPatrolPathComponent*>               MultiSelectActorToEnterList_69;                           // 0x0308(0x0010) (ExportObject, ZeroConstructor, Transient)
	unsigned char                                      UnknownData11[0x30];                                      // 0x0318(0x0030) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIPatrolPath.AIPatrolPathComponent"));
		
		return ptr;
	}


	bool SyncSharedUserOptions(class AIPatrolPathComponent* CopyToAIPatrolPathComp_69, TMap<struct FString, struct FString> UserOptionValues_69);
	bool ShouldRenderPath();
	void SetRenderPath(bool bRenderPath_69);
	void SetPatrolPathGroup(EFortCreativePatrolPathGroup PatrolPathGroup_69);
	void SetPatrolPathEnabled(bool bIsEnabled_69);
	void SetPatrollingMode(EPatrollingMode NewMode_69);
	void RequestRenderPath();
	void RenderToNextPoint();
	void RenderToNextAndPreviousPoint();
	bool RemovePoint();
	void PatrolPointReached(class FortAthenaPatrolPoint* PathPoint_69, class AIController* Instigator_69);
	void PatrolPointFailedToReach(class FortAthenaPatrolPoint* PathPoint_69, class AIController* Instigator_69);
	void PatrolPathStopped(class AIController* Instigator_69);
	void PatrolPathStarted(class AIController* Instigator_69);
	void OnPatrolPathGroupsMerged();
	void OnPatrolPathActorAssigned();
	void OnPathExtremitiesChanged(bool bIsStart_69, bool bIsEnd_69);
	bool HasValidPatrolPath();
	int GetPatrolPathPointIndex();
	class AIPatrolPathComponent* GetPatrolPathPoint(int InPatrolPathIndex_69, int InPatrolPathPointIndex_69);
	int GetPatrolPathIndex();
	class NavigationQueryFilter* GetPatrolFilterOptions();
	bool GetNextAvailablePatrolPathIndex(int* NextAvailableIndex_69);
	TArray<class AIPatrolPathComponent*> GetLinkedPatrolPoints();
	void GeneratePathPoints(EFortCreativePatrolPathGroup PatrolPathGroup_69);
	bool CanNextPointBeReached();
};


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

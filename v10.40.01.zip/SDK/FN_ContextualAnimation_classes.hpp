#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Classes
//---------------------------------------------------------------------------

// Class ContextualAnimation.AnimNotifyState_IKWindow
// 0x0070 (0x00A0 - 0x0030)
class AnimNotifyState_IKWindow : public AnimNotifyState
{
public:
	struct FName                                       GoalName_69;                                              // 0x0030(0x0008) (Edit, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0034(0x0004) MISSED OFFSET
	struct FAlphaBlend                                 BlendIn_69;                                               // 0x0038(0x0030) (Edit, BlueprintReadOnly)
	struct FAlphaBlend                                 BlendOut_69;                                              // 0x0068(0x0030) (Edit, BlueprintReadOnly)
	bool                                               bEnable_69;                                               // 0x0098(0x0001) (BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x7];                                       // 0x0099(0x0007) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class ContextualAnimation.AnimNotifyState_IKWindow"));
		
		return ptr;
	}

};


// Class ContextualAnimation.ContextualAnimActorInterface
// 0x0000 (0x0028 - 0x0028)
class ContextualAnimActorInterface : public Interface
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class ContextualAnimation.ContextualAnimActorInterface"));
		
		return ptr;
	}


	class SkeletalMeshComponent* GetMesh();
};


// Class ContextualAnimation.ContextualAnimManager
// 0x0068 (0x0090 - 0x0028)
class ContextualAnimManager : public Object_32759
{
public:
	unsigned char                                      UnknownData00[0x8];                                       // 0x0028(0x0008) MISSED OFFSET
	unsigned char                                      UnknownData01[0x50];                                      // 0x0028(0x0050) UNKNOWN PROPERTY: SetProperty ContextualAnimation.ContextualAnimManager.SceneActorCompContainer_69
	TArray<class ContextualAnimSceneInstance*>         Instances_69;                                             // 0x0080(0x0010) (ZeroConstructor)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class ContextualAnimation.ContextualAnimManager"));
		
		return ptr;
	}


	bool TryStopSceneWithActor(class Actor_32759* Actor_69);
	void OnSceneInstanceEnded(class ContextualAnimSceneInstance* SceneInstance_69);
	bool IsActorInAnyScene(class Actor_32759* Actor_69);
	class ContextualAnimSceneInstance* GetSceneWithActor(class Actor_32759* Actor_69);
	class ContextualAnimManager* STATIC_GetContextualAnimManager(class Object_32759* WorldContextObject_69);
	class ContextualAnimSceneInstance* BP_TryStartScene(class ContextualAnimSceneAsset* SceneAsset_69, const struct FContextualAnimStartSceneParams& Params_69);
};


// Class ContextualAnimation.ContextualAnimSceneActorComponent
// 0x0060 (0x0590 - 0x0530)
class ContextualAnimSceneActorComponent : public PrimitiveComponent
{
public:
	unsigned char                                      UnknownData00[0x8];                                       // 0x0530(0x0008) MISSED OFFSET
	unsigned char                                      UnknownData01[0x10];                                      // 0x0530(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty ContextualAnimation.ContextualAnimSceneActorComponent.OnJoinedSceneDelegate_69
	unsigned char                                      UnknownData02[0x10];                                      // 0x0548(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty ContextualAnimation.ContextualAnimSceneActorComponent.OnLeftSceneDelegate_69
	class ContextualAnimSceneAsset*                    SceneAsset_69;                                            // 0x0558(0x0008) (Edit, BlueprintVisible, ZeroConstructor)
	bool                                               bEnableDebug_69;                                          // 0x0560(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData03[0xF];                                       // 0x0561(0x000F) MISSED OFFSET
	TArray<struct FContextualAnimIKTarget>             IKTargets_69;                                             // 0x0570(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData04[0x10];                                      // 0x0580(0x0010) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class ContextualAnimation.ContextualAnimSceneActorComponent"));
		
		return ptr;
	}


	void OnTickPose(class SkinnedMeshComponent* SkinnedMeshComponent_69, float DeltaTime_69, bool bNeedsValidRootMotion_69);
	TArray<struct FContextualAnimIKTarget> GetIKTargets();
	struct FContextualAnimIKTarget GetIKTargetByGoalName(const struct FName& GoalName_69);
};


// Class ContextualAnimation.ContextualAnimRolesAsset
// 0x0010 (0x0040 - 0x0030)
class ContextualAnimRolesAsset : public DataAsset
{
public:
	TArray<struct FContextualAnimRoleDefinition>       Roles_69;                                                 // 0x0030(0x0010) (Edit, BlueprintVisible, ZeroConstructor)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class ContextualAnimation.ContextualAnimRolesAsset"));
		
		return ptr;
	}

};


// Class ContextualAnimation.ContextualAnimSceneAsset
// 0x0038 (0x0068 - 0x0030)
class ContextualAnimSceneAsset : public DataAsset
{
public:
	class ContextualAnimRolesAsset*                    RolesAsset_69;                                            // 0x0030(0x0008) (Edit, ZeroConstructor)
	struct FName                                       PrimaryRole_69;                                           // 0x0038(0x0008) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x003C(0x0004) MISSED OFFSET
	TArray<struct FContextualAnimSceneSection>         Sections_69;                                              // 0x0040(0x0010) (Edit, ZeroConstructor)
	float                                              Radius_69;                                                // 0x0050(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x4];                                       // 0x0054(0x0004) MISSED OFFSET
	class ContextualAnimSceneInstance*                 SceneInstanceClass_69;                                    // 0x0058(0x0008) (Edit, ZeroConstructor)
	bool                                               bDisableCollisionBetweenActors_69;                        // 0x0060(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData02[0x3];                                       // 0x0061(0x0003) MISSED OFFSET
	int                                                SampleRate_69;                                            // 0x0064(0x0004) (Edit, ZeroConstructor, IsPlainOldData)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class ContextualAnimation.ContextualAnimSceneAsset"));
		
		return ptr;
	}


	bool Query(const struct FName& Role_69, const struct FContextualAnimQueryParams& QueryParams_69, const struct FCoreUObject_FTransform& ToWorldTransform_69, struct FContextualAnimQueryResult* OutResult_69);
	TArray<struct FName> GetRoles();
	void BP_GetStartAndEndTimeForWarpSection(int SectionIdx_69, int AnimSetIdx_69, const struct FName& Role_69, const struct FName& WarpSectionName_69, float* OutStartTime_69, float* OutEndTime_69);
	struct FCoreUObject_FTransform BP_GetIKTargetTransformForRoleAtTime(int SectionIdx_69, int AnimSetIdx_69, const struct FName& Role_69, const struct FName& TrackName_69, float Time_69);
	struct FCoreUObject_FTransform BP_GetAlignmentTransformForRoleRelativeToPivot(int SectionIdx_69, int AnimSetIdx_69, const struct FName& Role_69, float Time_69);
	int BP_FindAnimSetIndexByAnimation(int SectionIdx_69, class AnimSequenceBase* Animation_69);
	class AnimSequenceBase* BP_FindAnimationForRole(int SectionIdx_69, int AnimSetIdx_69, const struct FName& Role_69);
};


// Class ContextualAnimation.ContextualAnimSceneInstance
// 0x0090 (0x00B8 - 0x0028)
class ContextualAnimSceneInstance : public Object_32759
{
public:
	unsigned char                                      UnknownData00[0x10];                                      // 0x0028(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty ContextualAnimation.ContextualAnimSceneInstance.OnSectionEndTimeReached_69
	unsigned char                                      UnknownData01[0x10];                                      // 0x0038(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty ContextualAnimation.ContextualAnimSceneInstance.OnSceneEnded_69
	unsigned char                                      UnknownData02[0x10];                                      // 0x0048(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty ContextualAnimation.ContextualAnimSceneInstance.OnActorJoined_69
	unsigned char                                      UnknownData03[0x10];                                      // 0x0058(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty ContextualAnimation.ContextualAnimSceneInstance.OnActorLeft_69
	unsigned char                                      UnknownData04[0x10];                                      // 0x0068(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty ContextualAnimation.ContextualAnimSceneInstance.OnNotifyBegin_69
	unsigned char                                      UnknownData05[0x10];                                      // 0x0078(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty ContextualAnimation.ContextualAnimSceneInstance.OnNotifyEnd_69
	class ContextualAnimSceneAsset*                    SceneAsset_69;                                            // 0x0088(0x0008) (ZeroConstructor)
	struct FContextualAnimSceneBindings                Bindings_69;                                              // 0x0090(0x0010)
	unsigned char                                      UnknownData06[0x18];                                      // 0x00A0(0x0018) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class ContextualAnimation.ContextualAnimSceneInstance"));
		
		return ptr;
	}


	void OnNotifyEndReceived(const struct FName& NotifyName_69, const struct FBranchingPointNotifyPayload& BranchingPointNotifyPayload_69);
	void OnNotifyBeginReceived(const struct FName& NotifyName_69, const struct FBranchingPointNotifyPayload& BranchingPointNotifyPayload_69);
	void OnMontageBlendingOut(class AnimMontage* Montage_69, bool bInterrupted_69);
	class Actor_32759* GetActorByRole(const struct FName& Role_69);
};


// Class ContextualAnimation.ContextualAnimSelectionCriterion
// 0x0008 (0x0030 - 0x0028)
class ContextualAnimSelectionCriterion : public Object_32759
{
public:
	EContextualAnimCriterionType                       Type_69;                                                  // 0x0028(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0029(0x0007) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class ContextualAnimation.ContextualAnimSelectionCriterion"));
		
		return ptr;
	}

};


// Class ContextualAnimation.ContextualAnimSelectionCriterion_Blueprint
// 0x0000 (0x0030 - 0x0030)
class ContextualAnimSelectionCriterion_Blueprint : public ContextualAnimSelectionCriterion
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class ContextualAnimation.ContextualAnimSelectionCriterion_Blueprint"));
		
		return ptr;
	}


	class ContextualAnimSceneAsset* GetSceneAsset();
	bool BP_DoesQuerierPassCondition(const struct FContextualAnimSceneBindingContext& Primary_69, const struct FContextualAnimSceneBindingContext& Querier_69);
};


// Class ContextualAnimation.ContextualAnimSelectionCriterion_TriggerArea
// 0x0018 (0x0048 - 0x0030)
class ContextualAnimSelectionCriterion_TriggerArea : public ContextualAnimSelectionCriterion
{
public:
	TArray<struct FVector>                             PolygonPoints_69;                                         // 0x0030(0x0010) (Edit, BlueprintVisible, EditFixedSize, ZeroConstructor)
	float                                              Height_69;                                                // 0x0040(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0044(0x0004) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class ContextualAnimation.ContextualAnimSelectionCriterion_TriggerArea"));
		
		return ptr;
	}

};


// Class ContextualAnimation.ContextualAnimSelectionCriterion_Cone
// 0x0010 (0x0040 - 0x0030)
class ContextualAnimSelectionCriterion_Cone : public ContextualAnimSelectionCriterion
{
public:
	EContextualAnimCriterionConeMode                   Mode_69;                                                  // 0x0030(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0031(0x0003) MISSED OFFSET
	float                                              Distance_69;                                              // 0x0034(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              HalfAngle_69;                                             // 0x0038(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              Offset_69;                                                // 0x003C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class ContextualAnimation.ContextualAnimSelectionCriterion_Cone"));
		
		return ptr;
	}

};


// Class ContextualAnimation.ContextualAnimSelectionCriterion_Distance
// 0x0010 (0x0040 - 0x0030)
class ContextualAnimSelectionCriterion_Distance : public ContextualAnimSelectionCriterion
{
public:
	EContextualAnimCriterionDistanceMode               Mode_69;                                                  // 0x0030(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0031(0x0003) MISSED OFFSET
	float                                              MinDistance_69;                                           // 0x0034(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              MaxDistance_69;                                           // 0x0038(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x4];                                       // 0x003C(0x0004) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class ContextualAnimation.ContextualAnimSelectionCriterion_Distance"));
		
		return ptr;
	}

};


// Class ContextualAnimation.ContextualAnimTransition
// 0x0000 (0x0028 - 0x0028)
class ContextualAnimTransition : public Object_32759
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class ContextualAnimation.ContextualAnimTransition"));
		
		return ptr;
	}


	bool CanEnterTransition(class ContextualAnimSceneInstance* SceneInstance_69, const struct FName& FromSection_69, const struct FName& ToSection_69);
};


// Class ContextualAnimation.ContextualAnimUtilities
// 0x0000 (0x0028 - 0x0028)
class ContextualAnimUtilities : public BlueprintFunctionLibrary
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class ContextualAnimation.ContextualAnimUtilities"));
		
		return ptr;
	}


	void STATIC_BP_SceneBindings_GetSectionAndAnimSetIndices(const struct FContextualAnimSceneBindings& Bindings_69, int* SectionIdx_69, int* AnimSetIdx_69);
	class ContextualAnimSceneAsset* STATIC_BP_SceneBindings_GetSceneAsset(const struct FContextualAnimSceneBindings& Bindings_69);
	TArray<struct FContextualAnimSceneBinding> STATIC_BP_SceneBindings_GetBindings(const struct FContextualAnimSceneBindings& Bindings_69);
	struct FContextualAnimSceneBinding STATIC_BP_SceneBindings_GetBindingByRole(const struct FContextualAnimSceneBindings& Bindings_69, const struct FName& Role_69);
	struct FContextualAnimSceneBinding STATIC_BP_SceneBindings_GetBindingByActor(const struct FContextualAnimSceneBindings& Bindings_69, class Actor_32759* Actor_69);
	struct FCoreUObject_FTransform STATIC_BP_SceneBindings_GetAlignmentTransformForRoleRelativeToPivot(const struct FContextualAnimSceneBindings& Bindings_69, const struct FName& Role_69, const struct FContextualAnimSetPivot& Pivot_69, float Time_69);
	struct FCoreUObject_FTransform STATIC_BP_SceneBindings_GetAlignmentTransformForRoleRelativeToOtherRole(const struct FContextualAnimSceneBindings& Bindings_69, const struct FName& Role_69, const struct FName& RelativeToRole_69, float Time_69);
	void STATIC_BP_SceneBindings_CalculateAnimSetPivots(const struct FContextualAnimSceneBindings& Bindings_69, TArray<struct FContextualAnimSetPivot>* OutPivots_69);
	void STATIC_BP_SceneBindings_AddOrUpdateWarpTargetsForBindings(const struct FContextualAnimSceneBindings& Bindings_69);
	struct FContextualAnimSceneBindingContext STATIC_BP_SceneBindingContext_MakeFromActorWithExternalTransform(class Actor_32759* Actor_69, const struct FCoreUObject_FTransform& ExternalTransform_69);
	struct FContextualAnimSceneBindingContext STATIC_BP_SceneBindingContext_MakeFromActor(class Actor_32759* Actor_69);
	struct FVector STATIC_BP_SceneBindingContext_GetVelocity(const struct FContextualAnimSceneBindingContext& BindingContext_69);
	struct FCoreUObject_FTransform STATIC_BP_SceneBindingContext_GetTransform(const struct FContextualAnimSceneBindingContext& BindingContext_69);
	class Actor_32759* STATIC_BP_SceneBindingContext_GetActor(const struct FContextualAnimSceneBindingContext& BindingContext_69);
	class SkeletalMeshComponent* STATIC_BP_SceneBinding_GetSkeletalMesh(const struct FContextualAnimSceneBinding& Binding_69);
	struct FName STATIC_BP_SceneBinding_GetRole(const struct FContextualAnimSceneBinding& Binding_69);
	class AnimSequenceBase* STATIC_BP_SceneBinding_GetAnimationToPlay(const struct FContextualAnimSceneBinding& Binding_69);
	class Actor_32759* STATIC_BP_SceneBinding_GetActor(const struct FContextualAnimSceneBinding& Binding_69);
	float STATIC_BP_Montage_GetSectionTimeLeftFromPos(class AnimMontage* Montage_69, float Position_69);
	void STATIC_BP_Montage_GetSectionStartAndEndTime(class AnimMontage* Montage_69, int SectionIndex_69, float* OutStartTime_69, float* OutEndTime_69);
	float STATIC_BP_Montage_GetSectionLength(class AnimMontage* Montage_69, int SectionIndex_69);
	void STATIC_BP_DrawDebugPose(class Object_32759* WorldContextObject_69, class AnimSequenceBase* Animation_69, float Time_69, const struct FCoreUObject_FTransform& LocalToWorldTransform_69, const struct FLinearColor& Color_69, float LifeTime_69, float Thickness_69);
	bool STATIC_BP_CreateContextualAnimSceneBindingsForTwoActors(class ContextualAnimSceneAsset* SceneAsset_69, const struct FContextualAnimSceneBindingContext& Primary_69, const struct FContextualAnimSceneBindingContext& Secondary_69, struct FContextualAnimSceneBindings* OutBindings_69);
	bool STATIC_BP_CreateContextualAnimSceneBindings(class ContextualAnimSceneAsset* SceneAsset_69, TMap<struct FName, struct FContextualAnimSceneBindingContext> Params_69, struct FContextualAnimSceneBindings* OutBindings_69);
};


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

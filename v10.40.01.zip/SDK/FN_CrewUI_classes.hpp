#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Classes
//---------------------------------------------------------------------------

// Class CrewUI.BattlePassCrewContentInterface
// 0x0000 (0x0028 - 0x0028)
class BattlePassCrewContentInterface : public Interface
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CrewUI.BattlePassCrewContentInterface"));
		
		return ptr;
	}

};


// Class CrewUI.FortProgressiveContentInterface
// 0x0000 (0x0028 - 0x0028)
class FortProgressiveContentInterface : public Interface
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CrewUI.FortProgressiveContentInterface"));
		
		return ptr;
	}

};


// Class CrewUI.BattlePassCrewPurchaseButton
// 0x0020 (0x14A0 - 0x1480)
class BattlePassCrewPurchaseButton : public FortHoldableButton
{
public:
	class CommonTextBlock*                             Text_Label_69;                                            // 0x1480(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)
	class CommonTextBlock*                             Text_SecondaryLabel_69;                                   // 0x1488(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)
	class CommonTextBlock*                             Text_FinalCost_69;                                        // 0x1490(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)
	class Widget*                                      Container_SecondaryLabel_69;                              // 0x1498(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CrewUI.BattlePassCrewPurchaseButton"));
		
		return ptr;
	}


	void OnCurrencyUpdated();
};


// Class CrewUI.BattlePassCrewPurchaseContainer
// 0x0080 (0x0428 - 0x03A8)
class BattlePassCrewPurchaseContainer : public CommonActivatableWidget
{
public:
	unsigned char                                      UnknownData00[0x20];                                      // 0x03A8(0x0020) MISSED OFFSET
	float                                              CrewUpsellTransitionDelayTime_69;                         // 0x03C8(0x0004) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData01[0xC];                                       // 0x03CC(0x000C) MISSED OFFSET
	class CommonActivatableWidgetSwitcher_32759*       Switcher_ContentContainer_69;                             // 0x03D8(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)
	class BattlePassPurchaseScreen*                    BattlePassPurchaseScreen_69;                              // 0x03E0(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)
	class WidgetAnimation*                             Intro_69;                                                 // 0x03E8(0x0008) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, Transient)
	class WidgetAnimation*                             QuickIntro_69;                                            // 0x03F0(0x0008) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, Transient)
	class WidgetAnimation*                             CrewBenefitsIntro_69;                                     // 0x03F8(0x0008) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, Transient)
	class CrewSubscriptionErrorModal*                  CrewSubscriptionErrorModalClass_69;                       // 0x0400(0x0008) (Edit, ZeroConstructor, DisableEditOnInstance)
	unsigned char                                      UnknownData02[0x20];                                      // 0x0408(0x0020) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CrewUI.BattlePassCrewPurchaseContainer"));
		
		return ptr;
	}


	void OnTriggerIntroAnimation(bool bCanClaimRewards_69);
	void OnContentStateUpdated(EBattlePassCrewContentState InState_69, bool bInScreenOpened_69);
};


// Class CrewUI.BattlePassSeasonHeading
// 0x0008 (0x0298 - 0x0290)
class BattlePassSeasonHeading : public CommonUserWidget
{
public:
	class CommonRichTextBlock*                         Text_Season_69;                                           // 0x0290(0x0008) (ExportObject, ZeroConstructor, InstancedReference)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CrewUI.BattlePassSeasonHeading"));
		
		return ptr;
	}

};


// Class CrewUI.BattlePassPurchaseScreen
// 0x0118 (0x0500 - 0x03E8)
class BattlePassPurchaseScreen : public CMSBackgroundWidget
{
public:
	unsigned char                                      UnknownData00[0xA0];                                      // 0x03E8(0x00A0) MISSED OFFSET
	class CommonActivatableWidget*                     PurchaseCompleteModal_69;                                 // 0x0488(0x0008) (Edit, ZeroConstructor)
	class CommonButtonBase*                            Button_ToCrew_69;                                         // 0x0490(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)
	class BattlePassCrewPurchaseButton*                Button_Purchase_69;                                       // 0x0498(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)
	class CommonButtonBase*                            Button_MoreInfo_69;                                       // 0x04A0(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	class CommonButtonBase*                            Button_GiftBattlePass_69;                                 // 0x04A8(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	class BattlePassCrewPurchaseButton*                Button_ConfirmBase_69;                                    // 0x04B0(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)
	class BattlePassCrewPurchaseButton*                Button_ConfirmBundle_69;                                  // 0x04B8(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)
	class BattlePassSeasonHeading*                     Heading_Primary_69;                                       // 0x04C0(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)
	class BattlePassSeasonHeading*                     Heading_Secondary_69;                                     // 0x04C8(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)
	class CommonRichTextBlock*                         RichText_Disclaimer_69;                                   // 0x04D0(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)
	class CommonTextBlock*                             Text_Description_69;                                      // 0x04D8(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)
	class CommonAnimatedSwitcher*                      Switcher_PurchaseState_69;                                // 0x04E0(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)
	unsigned char                                      UnknownData01[0x18];                                      // 0x04E8(0x0018) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CrewUI.BattlePassPurchaseScreen"));
		
		return ptr;
	}


	void OnShowNavButtonNotification(bool bShowNotification_69);
	void OnSetScreenInteractable(bool bInteractable_69);
	void OnSetNavButtonNotificationText(const struct FText& NotificationText_69);
	void OnPurchaseStateChanged(EBattlePassPurchaseState InCurrentState_69);
	void OnPurchaseConfirmed();
};


// Class CrewUI.CrewMultiSubscriptionAlertModal
// 0x00D8 (0x0480 - 0x03A8)
class CrewMultiSubscriptionAlertModal : public CommonActivatableWidget
{
public:
	unsigned char                                      UnknownData00[0x8];                                       // 0x03A8(0x0008) MISSED OFFSET
	class DynamicEntryBox*                             EntryBox_BulletPoints_69;                                 // 0x03B0(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	class CommonButtonBase*                            Button_OpenHowToURL_69;                                   // 0x03B8(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	class CommonButtonBase*                            Button_TextURL_69;                                        // 0x03C0(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)
	class CommonButtonBase*                            Button_DoNotRemind_69;                                    // 0x03C8(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	class CommonButtonBase*                            Button_Close_69;                                          // 0x03D0(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	TArray<struct FText>                               BulletPoints_69;                                          // 0x03D8(0x0010) (Edit, ZeroConstructor, DisableEditOnInstance)
	TMap<EAppStore, struct FText>                      AppStorePlatformMapping_69;                               // 0x03E8(0x0050) (Edit, DisableEditOnInstance)
	struct FString                                     HowToCancelURL_69;                                        // 0x0438(0x0010) (Edit, ZeroConstructor, DisableEditOnInstance)
	unsigned char                                      UnknownData01[0x20];                                      // 0x0448(0x0020) MISSED OFFSET
	struct FText                                       PlatformTextStyle_69;                                     // 0x0468(0x0018) (Edit, DisableEditOnInstance)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CrewUI.CrewMultiSubscriptionAlertModal"));
		
		return ptr;
	}


	void OnSetHowToCancelURL(const struct FString& MoreInfoUrl_69);
};


// Class CrewUI.CrewPriceChangeAcknowledgeModal
// 0x01A0 (0x0548 - 0x03A8)
class CrewPriceChangeAcknowledgeModal : public CommonActivatableWidget
{
public:
	unsigned char                                      UnknownData00[0x8];                                       // 0x03A8(0x0008) MISSED OFFSET
	class CommonButtonBase*                            Button_Accept_69;                                         // 0x03B0(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)
	class CommonButtonBase*                            Button_CancelSubscription_69;                             // 0x03B8(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)
	class CommonButtonBase*                            Button_MoreInfo_69;                                       // 0x03C0(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)
	class CommonButtonBase*                            Button_TextURL_69;                                        // 0x03C8(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)
	unsigned char                                      UnknownData01[0x28];                                      // 0x03D0(0x0028) UNKNOWN PROPERTY: SoftClassProperty CrewUI.CrewPriceChangeAcknowledgeModal.CancellationInfoModalClass_69
	unsigned char                                      UnknownData02[0x150];                                     // 0x03F8(0x0150) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CrewUI.CrewPriceChangeAcknowledgeModal"));
		
		return ptr;
	}


	void OnSetPriceChangeAcknowledgeTitle(const struct FText& Title_69);
	void OnSetPriceChangeAcknowledgeMoreInfoUrl(const struct FText& MoreInfoUrl_69);
	void OnSetPriceChangeAcknowledgeMoreInfoText(const struct FText& ConfirmButtonText_69);
	void OnSetPriceChangeAcknowledgeConfirmButtonText(const struct FText& ConfirmButtonText_69);
	void OnSetPriceChangeAcknowledgeCheckboxText(const struct FText& CheckboxText_69);
	void OnSetPriceChangeAcknowledgeCancelSubscriptionButtonText(const struct FText& CancelSubscriptionButtonText_69);
	void OnSetPriceChangeAcknowledgeBodyText(const struct FText& BodyText_69);
	void OnSetPriceChangeAcknowledgeBodyTable(TArray<struct FCrewTableRow> PriceChangeByRegionRows_69);
	void OnModalBackout();
	void ExitModal();
};


// Class CrewUI.CrewPurchaseScreen
// 0x0190 (0x0578 - 0x03E8)
class CrewPurchaseScreen : public CMSBackgroundWidget
{
public:
	unsigned char                                      UnknownData00[0x68];                                      // 0x03E8(0x0068) MISSED OFFSET
	bool                                               bManagementModeEnabled_69;                                // 0x0450(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnTemplate, IsPlainOldData)
	unsigned char                                      UnknownData01[0x7];                                       // 0x0451(0x0007) MISSED OFFSET
	class Widget*                                      FocusWidget_69;                                           // 0x0458(0x0008) (ExportObject, ZeroConstructor, Transient, InstancedReference)
	class CommonButtonGroupBase*                       ButtonGroup_BenefitsTiles_69;                             // 0x0460(0x0008) (ZeroConstructor)
	unsigned char                                      UnknownData02[0x28];                                      // 0x0468(0x0028) UNKNOWN PROPERTY: SoftClassProperty CrewUI.CrewPurchaseScreen.CancellationInfoModalClass_69
	unsigned char                                      UnknownData03[0x28];                                      // 0x0490(0x0028) UNKNOWN PROPERTY: SoftClassProperty CrewUI.CrewPurchaseScreen.LegalInfoModalClass_69
	unsigned char                                      UnknownData04[0x28];                                      // 0x04B8(0x0028) UNKNOWN PROPERTY: SoftClassProperty CrewUI.CrewPurchaseScreen.ResolveIssueModalClass_69
	unsigned char                                      UnknownData05[0x28];                                      // 0x04E0(0x0028) UNKNOWN PROPERTY: SoftClassProperty CrewUI.CrewPurchaseScreen.RejoinModalClass_69
	class CommonButtonBase*                            Button_ToBattlePass_69;                                   // 0x0508(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)
	class BattlePassCrewPurchaseButton*                Button_Purchase_69;                                       // 0x0510(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)
	class BattlePassCrewPurchaseButton*                Button_Rejoin_69;                                         // 0x0518(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)
	class CommonButtonBase*                            Button_ResolvePayment_69;                                 // 0x0520(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)
	class CommonButtonBase*                            Button_WatchTrailer_69;                                   // 0x0528(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	class CommonButtonBase*                            Button_Terms_69;                                          // 0x0530(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	class CommonButtonBase*                            Button_CancellationInfo_69;                               // 0x0538(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	class DynamicEntryBox*                             EntryBox_RecurringRewards_69;                             // 0x0540(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)
	class DynamicEntryBox*                             EntryBox_LimitedTimeRewards_69;                           // 0x0548(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)
	class CrewTileDetails*                             Details_CurrentCrewTile_69;                               // 0x0550(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	class CommonTextBlock*                             Text_LimitedTime_69;                                      // 0x0558(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)
	class Overlay*                                     Overlay_UserInformation_69;                               // 0x0560(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)
	class CommonTextBlock*                             Text_UserInformation_69;                                  // 0x0568(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)
	class CommonTextBlock*                             Text_CrewDisclaimer_69;                                   // 0x0570(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CrewUI.CrewPurchaseScreen"));
		
		return ptr;
	}


	void OnUserInformationTextsUpdated(const struct FText& UserInformationText1_69, const struct FText& UserInformationText2_69, EMcpSubscriptionState SubscriptionState_69);
	void OnUpdateVBuckRefundVisibility(bool bVisible_69);
	void OnUpdatePurchaseButtonState(ECrewPurchaseButtonState ButtonState_69);
	void OnShowNavButtonNotification(bool bShowNotification_69);
	void OnSetNavButtonNotificationText(const struct FText& NotificationText_69);
	void OnContainerTabVisibilityUpdated(bool bTabsVisible_69, float SpacingAdjustmentForTabs_69);
	void EndProgress();
	void BeginProgress(const struct FText& ProgressLabel_69);
};


// Class CrewUI.CrewRewardTile
// 0x0060 (0x1440 - 0x13E0)
class CrewRewardTile : public CommonButtonBase
{
public:
	unsigned char                                      UnknownData00[0x40];                                      // 0x13E0(0x0040) MISSED OFFSET
	float                                              TileImageStreamoutSeconds_69;                             // 0x1420(0x0004) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData01[0x4];                                       // 0x1424(0x0004) MISSED OFFSET
	class Image*                                       Image_TileImage_69;                                       // 0x1428(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)
	class CommonTextBlock*                             Text_TileLabel_69;                                        // 0x1430(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	unsigned char                                      UnknownData02[0x8];                                       // 0x1438(0x0008) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CrewUI.CrewRewardTile"));
		
		return ptr;
	}


	void OnUpdateOwnedState(bool bOwned_69);
	void OnStartingDownloadTileImage();
	void OnDownloadTileImageComplete(class Texture2D* Texture_69);
	bool IsMonthlyBenefit();
};


// Class CrewUI.CrewSeasonLaunchScreen
// 0x00F0 (0x04D8 - 0x03E8)
class CrewSeasonLaunchScreen : public CMSBackgroundWidget
{
public:
	unsigned char                                      UnknownData00[0x38];                                      // 0x03E8(0x0038) MISSED OFFSET
	unsigned char                                      UnknownData01[0x28];                                      // 0x03E8(0x0028) UNKNOWN PROPERTY: SoftClassProperty CrewUI.CrewSeasonLaunchScreen.ResolveIssueModalClass_69
	class BattlePassSeasonHeading*                     Heading_SeasonInfo_69;                                    // 0x0448(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)
	class CommonTextBlock*                             Text_Description_69;                                      // 0x0450(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)
	class CommonButtonBase*                            Button_Claim_69;                                          // 0x0458(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)
	class CommonButtonBase*                            Button_ResolveIssue_69;                                   // 0x0460(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)
	class CommonButtonBase*                            Button_GiftBattlePass_69;                                 // 0x0468(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)
	class CommonRichTextBlock*                         RichText_Disclaimer_69;                                   // 0x0470(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)
	unsigned char                                      UnknownData02[0x60];                                      // 0x0478(0x0060) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CrewUI.CrewSeasonLaunchScreen"));
		
		return ptr;
	}

};


// Class CrewUI.CrewStandaloneSubscriptionContentContainer
// 0x0008 (0x05E8 - 0x05E0)
class CrewStandaloneSubscriptionContentContainer : public FortStandaloneFrontend
{
public:
	class CrewSubscriptionContentContainer*            Widget_CrewContentContainer_69;                           // 0x05E0(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CrewUI.CrewStandaloneSubscriptionContentContainer"));
		
		return ptr;
	}

};


// Class CrewUI.CrewSubscriptionContentContainer
// 0x00A0 (0x0448 - 0x03A8)
class CrewSubscriptionContentContainer : public CommonActivatableWidget
{
public:
	unsigned char                                      UnknownData00[0x30];                                      // 0x03A8(0x0030) MISSED OFFSET
	TArray<struct FCrewSubscriptionContentTabData>     TabsData_69;                                              // 0x03D8(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance)
	struct FDataTableRowHandle                         NextTabInputAction_69;                                    // 0x03E8(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly)
	struct FDataTableRowHandle                         PreviousTabInputAction_69;                                // 0x03F8(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly)
	class DynamicEntryBox*                             EntryBox_Tabs_69;                                         // 0x0408(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)
	class CommonButtonGroupBase*                       ButtonGroup_Tabs_69;                                      // 0x0410(0x0008) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, Transient)
	class CommonActivatableWidgetSwitcher_32759*       Switcher_Tabs_69;                                         // 0x0418(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)
	class Widget*                                      Widget_TabsContainer_69;                                  // 0x0420(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	float                                              SpacingAdjustmentForTabs_69;                              // 0x0428(0x0004) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	struct FPrimaryContentSetup                        ContentSetup_69;                                          // 0x042C(0x0003)
	unsigned char                                      UnknownData01[0x19];                                      // 0x042F(0x0019) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CrewUI.CrewSubscriptionContentContainer"));
		
		return ptr;
	}


	void OnTabSelected(int TabIndex_69);
};


// Class CrewUI.CrewSubscriptionErrorModal
// 0x0010 (0x03B8 - 0x03A8)
class CrewSubscriptionErrorModal : public CommonActivatableWidget
{
public:
	class CommonButtonBase*                            Button_Confirm_69;                                        // 0x03A8(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	class CommonButtonBase*                            Button_CloseMobile_69;                                    // 0x03B0(0x0008) (ExportObject, ZeroConstructor, InstancedReference)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CrewUI.CrewSubscriptionErrorModal"));
		
		return ptr;
	}

};


// Class CrewUI.CrewTileDetails
// 0x0048 (0x02D8 - 0x0290)
class CrewTileDetails : public CommonUserWidget
{
public:
	unsigned char                                      UnknownData00[0x28];                                      // 0x0290(0x0028) MISSED OFFSET
	class CommonTextBlock*                             Text_Title_69;                                            // 0x02B8(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)
	class CommonRichTextBlock*                         RichText_Description_69;                                  // 0x02C0(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)
	class DynamicEntryBox*                             EntryBox_Tags_69;                                         // 0x02C8(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	class CommonButtonBase*                            Button_MobileMoreInfo_69;                                 // 0x02D0(0x0008) (ExportObject, ZeroConstructor, InstancedReference)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CrewUI.CrewTileDetails"));
		
		return ptr;
	}

};


// Class CrewUI.CrewTileDetailsTag
// 0x0008 (0x0298 - 0x0290)
class CrewTileDetailsTag : public CommonUserWidget
{
public:
	class CommonRichTextBlock*                         Text_Label_69;                                            // 0x0290(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CrewUI.CrewTileDetailsTag"));
		
		return ptr;
	}


	void OnTagSetup(ECrewDetailsTag RewardTag_69, bool bIsOwnedTag_69);
};


// Class CrewUI.CrewUIGameFeatureAction
// 0x0138 (0x0160 - 0x0028)
class CrewUIGameFeatureAction : public FortUIGameFeatureAction
{
public:
	unsigned char                                      UnknownData00[0x28];                                      // 0x0028(0x0028) UNKNOWN PROPERTY: SoftClassProperty CrewUI.CrewUIGameFeatureAction.BattlePassCrewContainerClass_69
	unsigned char                                      UnknownData01[0x28];                                      // 0x0050(0x0028) UNKNOWN PROPERTY: SoftClassProperty CrewUI.CrewUIGameFeatureAction.CrewContentContainerClass_69
	unsigned char                                      UnknownData02[0x28];                                      // 0x0078(0x0028) UNKNOWN PROPERTY: SoftClassProperty CrewUI.CrewUIGameFeatureAction.CrewStandaloneContentContainerClass_69
	unsigned char                                      UnknownData03[0x28];                                      // 0x00A0(0x0028) UNKNOWN PROPERTY: SoftClassProperty CrewUI.CrewUIGameFeatureAction.CrewPurchaseScreenClass_69
	unsigned char                                      UnknownData04[0x28];                                      // 0x00C8(0x0028) UNKNOWN PROPERTY: SoftClassProperty CrewUI.CrewUIGameFeatureAction.ProgressionScreenClass_69
	unsigned char                                      UnknownData05[0x28];                                      // 0x00F0(0x0028) UNKNOWN PROPERTY: SoftClassProperty CrewUI.CrewUIGameFeatureAction.CrewPriceChangeAcknowledgeModalClass_69
	unsigned char                                      UnknownData06[0x28];                                      // 0x0118(0x0028) UNKNOWN PROPERTY: SoftClassProperty CrewUI.CrewUIGameFeatureAction.MultiSubAlertModalClass_69
	TArray<struct FFortProgressiveSet>                 ProgressiveCosmeticSets_69;                               // 0x0140(0x0010) (Edit, ZeroConstructor, DisableEditOnInstance)
	unsigned char                                      UnknownData07[0x10];                                      // 0x0150(0x0010) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CrewUI.CrewUIGameFeatureAction"));
		
		return ptr;
	}

};


// Class CrewUI.FortProgressiveContentContainer
// 0x0050 (0x03F8 - 0x03A8)
class FortProgressiveContentContainer : public CommonActivatableWidget
{
public:
	unsigned char                                      UnknownData00[0x38];                                      // 0x03A8(0x0038) MISSED OFFSET
	class CommonActivatableWidgetSwitcher_32759*       Switcher_PrimaryContent_69;                               // 0x03E0(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	class FortProgressiveTableOfContentsScreen*        Widget_ProgressiveTableOfContentsScreen_69;               // 0x03E8(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	class FortProgressiveItemScreen*                   Widget_ProgressiveItemScreen_69;                          // 0x03F0(0x0008) (ExportObject, ZeroConstructor, InstancedReference)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CrewUI.FortProgressiveContentContainer"));
		
		return ptr;
	}

};


// Class CrewUI.FortProgressiveItemDetailsWidget
// 0x0028 (0x0290 - 0x0268)
class FortProgressiveItemDetailsWidget : public UserWidget
{
public:
	class CommonTextBlock*                             Text_CosmeticStage_69;                                    // 0x0268(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	class CommonRichTextBlock*                         Text_UnlockCriteria_69;                                   // 0x0270(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)
	class Widget*                                      Widget_UnlockCriteriaContainer_69;                        // 0x0278(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	class AthenaRewardItemTypeRarityTag*               Widget_ItemTypeRarityTag_69;                              // 0x0280(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)
	class Widget*                                      Tag_Owned_69;                                             // 0x0288(0x0008) (ExportObject, ZeroConstructor, InstancedReference)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CrewUI.FortProgressiveItemDetailsWidget"));
		
		return ptr;
	}

};


// Class CrewUI.FortProgressiveScreenBase
// 0x0068 (0x06D0 - 0x0668)
class FortProgressiveScreenBase : public FortItemPreviewScreen
{
public:
	unsigned char                                      UnknownData00[0x54];                                      // 0x0668(0x0054) MISSED OFFSET
	float                                              VariantPreviewTime_69;                                    // 0x06BC(0x0004) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData01[0x10];                                      // 0x06C0(0x0010) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CrewUI.FortProgressiveScreenBase"));
		
		return ptr;
	}


	void BP_OnContainerTabVisibilityUpdated(bool bTabsVisible_69, float SpacingAdjustmentForTabs_69);
};


// Class CrewUI.FortProgressiveItemScreen
// 0x0118 (0x07E8 - 0x06D0)
class FortProgressiveItemScreen : public FortProgressiveScreenBase
{
public:
	class CommonButtonBase*                            Button_Back_69;                                           // 0x06D0(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)
	class CommonButtonBase*                            Button_MobileBack_69;                                     // 0x06D8(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	class CommonButtonBase*                            Button_MoreInfo_69;                                       // 0x06E0(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	class BattlePassCrewPurchaseButton*                Button_Subscribe_69;                                      // 0x06E8(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	class CommonButtonBase*                            Button_PreviewStyles_69;                                  // 0x06F0(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	class CommonTextBlock*                             Text_ExpirationFinePrint_69;                              // 0x06F8(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)
	class CommonTextBlock*                             Text_NewStagesUnlockFinePrint_69;                         // 0x0700(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)
	class DynamicEntryBox*                             EntryBox_StagesPips_69;                                   // 0x0708(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)
	class CommonButtonGroupBase*                       ButtonGroup_StagesPips_69;                                // 0x0710(0x0008) (ZeroConstructor)
	class FortProgressiveItemDetailsWidget*            Widget_ProgressiveItemDetails_69;                         // 0x0718(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)
	class FortProgressiveStageList*                    Widget_ProgressiveStageList_69;                           // 0x0720(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)
	class FortProgressiveItemStateTitleWidget*         ProgressiveItemStateTitle_69;                             // 0x0728(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)
	unsigned char                                      UnknownData00[0x28];                                      // 0x0730(0x0028) UNKNOWN PROPERTY: SoftClassProperty CrewUI.FortProgressiveItemScreen.MoreInfoModalClass_69
	struct FName                                       SubscribedMaterialParameterName_69;                       // 0x0758(0x0008) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData01[0x8C];                                      // 0x075C(0x008C) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CrewUI.FortProgressiveItemScreen"));
		
		return ptr;
	}


	void OnUpdateSubscriptionState(bool bSubscribed_69);
	void OnSetIsSoloScreen(bool bInIsSoloScreen_69);
	void OnItemSelected();
	void OnErrorStateTextUpdated(const struct FText& ErrorStateText_69);
};


// Class CrewUI.FortProgressiveItemStateTitleWidget
// 0x0000 (0x0268 - 0x0268)
class FortProgressiveItemStateTitleWidget : public UserWidget
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CrewUI.FortProgressiveItemStateTitleWidget"));
		
		return ptr;
	}


	void BP_OnSetHeaderInfo(const struct FText& Subheading_69, bool bSubscribed_69, int UnlockedStages_69, int MaxStages_69);
};


// Class CrewUI.FortProgressiveItemWidget
// 0x0090 (0x1470 - 0x13E0)
class FortProgressiveItemWidget : public CommonButtonBase
{
public:
	class AthenaItemShopReactiveTileText*              TileText_ItemName_69;                                     // 0x13E0(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	struct FProgressiveStageItemInfo                   StageItemInfo_69;                                         // 0x13E8(0x0070) (Transient)
	unsigned char                                      UnknownData00[0x18];                                      // 0x1458(0x0018) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CrewUI.FortProgressiveItemWidget"));
		
		return ptr;
	}


	void OnUnhighlighted();
	void OnTileMaterialLoaded(bool bSubscribed_69);
	void OnStageItemChanged(const struct FProgressiveStageItemInfo& InStageItemInfo_69);
	void OnPeekStateChanged(bool bIsInPeekState_69);
	void OnHighlighted();
};


// Class CrewUI.FortProgressiveSetDetailsWidget
// 0x0030 (0x0298 - 0x0268)
class FortProgressiveSetDetailsWidget : public UserWidget
{
public:
	class CommonButtonBase*                            Button_MoreInfo_69;                                       // 0x0268(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	unsigned char                                      UnknownData00[0x28];                                      // 0x0270(0x0028) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CrewUI.FortProgressiveSetDetailsWidget"));
		
		return ptr;
	}


	void BP_OnUpdateSetDetails(const struct FText& SetName_69, const struct FText& ExpiringText_69, bool bCompleted_69);
};


// Class CrewUI.FortProgressiveSetList
// 0x0080 (0x0428 - 0x03A8)
class FortProgressiveSetList : public CommonActivatableWidget
{
public:
	unsigned char                                      UnknownData00[0x8];                                       // 0x03A8(0x0008) MISSED OFFSET
	class AthenaScrollBox*                             ScrollBox_SetList_69;                                     // 0x03B0(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	class FortSwipePanel*                              SwipePanel_Navigation_69;                                 // 0x03B8(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	class CommonButtonGroupBase*                       ButtonGroup_SetTiles_69;                                  // 0x03C0(0x0008) (ZeroConstructor, Transient)
	int                                                NumTilesPerPage_69;                                       // 0x03C8(0x0004) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData01[0x4];                                       // 0x03CC(0x0004) MISSED OFFSET
	TArray<class FortProgressiveSetTile*>              SetTiles_69;                                              // 0x03D0(0x0010) (ExportObject, ZeroConstructor, Transient)
	unsigned char                                      UnknownData02[0x48];                                      // 0x03E0(0x0048) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CrewUI.FortProgressiveSetList"));
		
		return ptr;
	}


	void ClearSetTiles();
	class FortProgressiveSetTile* AddSetTile();
};


// Class CrewUI.FortProgressiveSetTile
// 0x00B0 (0x1490 - 0x13E0)
class FortProgressiveSetTile : public CommonButtonBase
{
public:
	unsigned char                                      UnknownData00[0xB0];                                      // 0x13E0(0x00B0) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CrewUI.FortProgressiveSetTile"));
		
		return ptr;
	}


	void BP_OnTileMaterialLoaded(bool bSubscribed_69);
	void BP_OnInitializeSetInfo(const struct FProgressiveSetInfo& InSetInfo_69, const struct FText& BottomText_69, const struct FText& BottomSubtext_69, bool bSubscribed_69);
};


// Class CrewUI.FortProgressiveStageList
// 0x0050 (0x03F8 - 0x03A8)
class FortProgressiveStageList : public CommonActivatableWidget
{
public:
	unsigned char                                      UnknownData00[0x18];                                      // 0x03A8(0x0018) MISSED OFFSET
	class CommonButtonGroupBase*                       ButtonGroup_StageItems_69;                                // 0x03C0(0x0008) (ZeroConstructor, Transient)
	class AthenaScrollBox*                             ScrollBox_StageList_69;                                   // 0x03C8(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	class FortSwipePanel*                              SwipePanel_Navigation_69;                                 // 0x03D0(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	unsigned char                                      UnknownData01[0x8];                                       // 0x03D8(0x0008) MISSED OFFSET
	TArray<class FortProgressiveStageWidget*>          Stages_69;                                                // 0x03E0(0x0010) (ExportObject, ZeroConstructor, Transient)
	unsigned char                                      UnknownData02[0x8];                                       // 0x03F0(0x0008) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CrewUI.FortProgressiveStageList"));
		
		return ptr;
	}


	void SelectStageInDirection(int Direction_69);
	void ClearStageWidgets();
	class FortProgressiveStageWidget* AddStageWidget();
};


// Class CrewUI.FortProgressiveStageWidget
// 0x0020 (0x02B0 - 0x0290)
class FortProgressiveStageWidget : public CommonUserWidget
{
public:
	class CommonTextBlock*                             Text_Month_69;                                            // 0x0290(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	unsigned char                                      UnknownData00[0x18];                                      // 0x0298(0x0018) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CrewUI.FortProgressiveStageWidget"));
		
		return ptr;
	}


	void OnSetTooltipVisible(bool bVisible_69);
	void OnSetTooltipText(const struct FText& InToolTipText_69);
	void OnPeekStateChanged(bool bIsInPeekState_69);
	void ClearStageItemWidgets();
	class FortProgressiveItemWidget* AddStageItemWidget();
};


// Class CrewUI.FortProgressiveTableOfContentsScreen
// 0x0088 (0x0758 - 0x06D0)
class FortProgressiveTableOfContentsScreen : public FortProgressiveScreenBase
{
public:
	class CommonButtonBase*                            Button_Back_69;                                           // 0x06D0(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	class CommonButtonBase*                            Button_MobileBack_69;                                     // 0x06D8(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	class CommonButtonBase*                            Button_MoreInfo_69;                                       // 0x06E0(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	class BattlePassCrewPurchaseButton*                Button_Subscribe_69;                                      // 0x06E8(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	class FortProgressiveSetList*                      Widget_SetList_69;                                        // 0x06F0(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	class FortProgressiveSetDetailsWidget*             Widget_SetDetails_69;                                     // 0x06F8(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	class FortProgressiveItemStateTitleWidget*         Widget_ItemStateTitle_69;                                 // 0x0700(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	class DynamicEntryBox*                             EntryBox_SetPagesPips_69;                                 // 0x0708(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)
	class CommonButtonGroupBase*                       ButtonGroup_SetPagesPips_69;                              // 0x0710(0x0008) (ZeroConstructor)
	unsigned char                                      UnknownData00[0x28];                                      // 0x0718(0x0028) UNKNOWN PROPERTY: SoftClassProperty CrewUI.FortProgressiveTableOfContentsScreen.MoreInfoModalClass_69
	struct FName                                       SubscribedMaterialParameterName_69;                       // 0x0740(0x0008) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData01[0x14];                                      // 0x0744(0x0014) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CrewUI.FortProgressiveTableOfContentsScreen"));
		
		return ptr;
	}


	void BP_OnUpdateSubscriptionState(bool bSubscribed_69);
	void BP_OnUpdateNumTilesAvailable(int NumTiles_69);
	void BP_OnUpdateErrorStateText(const struct FText& ErrorStateText_69);
	void BP_OnUpdateBanner(const struct FText& BannerText_69, bool bAllSetsCompleted_69, bool bSubscribed_69);
	void BP_OnSetDescriptionText(const struct FText& ProductDescription_69);
};


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

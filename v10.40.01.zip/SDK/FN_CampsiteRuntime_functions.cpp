// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Functions
//---------------------------------------------------------------------------

// Function CampsiteRuntime.AbandonedCampsiteManager.OnGamePhaseStepChanged
// (Final, Native, Protected, HasOutParms)
// Parameters:
// TScriptInterface<class FortSafeZoneInterface> SafeZoneInterface_69           (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
// EAthenaGamePhaseStep           GamePhaseStep_69               (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void AbandonedCampsiteManager::OnGamePhaseStepChanged(const TScriptInterface<class FortSafeZoneInterface>& SafeZoneInterface_69, EAthenaGamePhaseStep GamePhaseStep_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CampsiteRuntime.AbandonedCampsiteManager.OnGamePhaseStepChanged"));

	AbandonedCampsiteManager_OnGamePhaseStepChanged_Params params;
	params.SafeZoneInterface_69 = SafeZoneInterface_69;
	params.GamePhaseStep_69 = GamePhaseStep_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CampsiteRuntime.AbandonedCampsitePlacedSpawner.SpawnCampsite
// (Native, Event, Public, BlueprintEvent)

void AbandonedCampsitePlacedSpawner::SpawnCampsite()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CampsiteRuntime.AbandonedCampsitePlacedSpawner.SpawnCampsite"));

	AbandonedCampsitePlacedSpawner_SpawnCampsite_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CampsiteRuntime.CampsiteConversationComponent.StartConversation
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// class FortPlayerController*    InstigatingController_69       (Parm, ZeroConstructor)

void CampsiteConversationComponent::StartConversation(class FortPlayerController* InstigatingController_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CampsiteRuntime.CampsiteConversationComponent.StartConversation"));

	CampsiteConversationComponent_StartConversation_Params params;
	params.InstigatingController_69 = InstigatingController_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CampsiteRuntime.CampsiteFunctionLibraryNative.StoreHealthOnPickupFromProp
// (Final, BlueprintAuthorityOnly, Native, Static, Private, BlueprintCallable)
// Parameters:
// class BuildingProp*            BuildingProp_69                (ConstParm, Parm, ZeroConstructor)
// class FortPickup*              PickUp_69                      (Parm, ZeroConstructor)

void CampsiteFunctionLibraryNative::STATIC_StoreHealthOnPickupFromProp(class BuildingProp* BuildingProp_69, class FortPickup* PickUp_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CampsiteRuntime.CampsiteFunctionLibraryNative.StoreHealthOnPickupFromProp"));

	CampsiteFunctionLibraryNative_StoreHealthOnPickupFromProp_Params params;
	params.BuildingProp_69 = BuildingProp_69;
	params.PickUp_69 = PickUp_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CampsiteRuntime.CampsiteFunctionLibraryNative.SetHealthOnPropFromItemEntry
// (Final, BlueprintAuthorityOnly, Native, Static, Private, HasOutParms, BlueprintCallable)
// Parameters:
// struct FFortItemEntry          FortItem_69                    (ConstParm, Parm, OutParm, ReferenceParm)
// class BuildingProp*            BuildingProp_69                (Parm, ZeroConstructor)

void CampsiteFunctionLibraryNative::STATIC_SetHealthOnPropFromItemEntry(const struct FFortItemEntry& FortItem_69, class BuildingProp* BuildingProp_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CampsiteRuntime.CampsiteFunctionLibraryNative.SetHealthOnPropFromItemEntry"));

	CampsiteFunctionLibraryNative_SetHealthOnPropFromItemEntry_Params params;
	params.FortItem_69 = FortItem_69;
	params.BuildingProp_69 = BuildingProp_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CampsiteRuntime.CampsiteFunctionLibraryNative.IsItemEntryAvailable
// (Final, BlueprintAuthorityOnly, Native, Static, Private, HasOutParms, BlueprintCallable)
// Parameters:
// class Object_32759*            WorldContextObject_69          (Parm, ZeroConstructor)
// struct FFortItemEntry          FortItem_69                    (ConstParm, Parm, OutParm, ReferenceParm)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool CampsiteFunctionLibraryNative::STATIC_IsItemEntryAvailable(class Object_32759* WorldContextObject_69, const struct FFortItemEntry& FortItem_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CampsiteRuntime.CampsiteFunctionLibraryNative.IsItemEntryAvailable"));

	CampsiteFunctionLibraryNative_IsItemEntryAvailable_Params params;
	params.WorldContextObject_69 = WorldContextObject_69;
	params.FortItem_69 = FortItem_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CampsiteRuntime.CampsiteFunctionLibraryNative.IsItemDefinitionAvailable
// (Final, BlueprintAuthorityOnly, Native, Static, Private, BlueprintCallable)
// Parameters:
// class Object_32759*            WorldContextObject_69          (Parm, ZeroConstructor)
// class FortItemDefinition*      FortItem_69                    (ConstParm, Parm, ZeroConstructor)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool CampsiteFunctionLibraryNative::STATIC_IsItemDefinitionAvailable(class Object_32759* WorldContextObject_69, class FortItemDefinition* FortItem_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CampsiteRuntime.CampsiteFunctionLibraryNative.IsItemDefinitionAvailable"));

	CampsiteFunctionLibraryNative_IsItemDefinitionAvailable_Params params;
	params.WorldContextObject_69 = WorldContextObject_69;
	params.FortItem_69 = FortItem_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CampsiteRuntime.CampsiteFunctionLibraryNative.IsItemAvailable
// (Final, BlueprintAuthorityOnly, Native, Static, Private, BlueprintCallable)
// Parameters:
// class Object_32759*            WorldContextObject_69          (Parm, ZeroConstructor)
// class FortItem*                FortItem_69                    (ConstParm, Parm, ZeroConstructor)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool CampsiteFunctionLibraryNative::STATIC_IsItemAvailable(class Object_32759* WorldContextObject_69, class FortItem* FortItem_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CampsiteRuntime.CampsiteFunctionLibraryNative.IsItemAvailable"));

	CampsiteFunctionLibraryNative_IsItemAvailable_Params params;
	params.WorldContextObject_69 = WorldContextObject_69;
	params.FortItem_69 = FortItem_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CampsiteRuntime.CampsiteFunctionLibraryNative.GetItemEntryCopyFromWeapon
// (Final, BlueprintAuthorityOnly, Native, Static, Private, BlueprintCallable)
// Parameters:
// class FortWeapon*              Weapon_69                      (ConstParm, Parm, ZeroConstructor)
// struct FFortItemEntry          ReturnValue_69                 (ConstParm, Parm, OutParm, ReturnParm)

struct FFortItemEntry CampsiteFunctionLibraryNative::STATIC_GetItemEntryCopyFromWeapon(class FortWeapon* Weapon_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CampsiteRuntime.CampsiteFunctionLibraryNative.GetItemEntryCopyFromWeapon"));

	CampsiteFunctionLibraryNative_GetItemEntryCopyFromWeapon_Params params;
	params.Weapon_69 = Weapon_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CampsiteRuntime.CampsiteImprovementComponent.SetImprovementOwnerSquadId
// (Final, Native, Protected, BlueprintCallable)
// Parameters:
// int                            SquadId_69                     (Parm, ZeroConstructor, IsPlainOldData)

void CampsiteImprovementComponent::SetImprovementOwnerSquadId(int SquadId_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CampsiteRuntime.CampsiteImprovementComponent.SetImprovementOwnerSquadId"));

	CampsiteImprovementComponent_SetImprovementOwnerSquadId_Params params;
	params.SquadId_69 = SquadId_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CampsiteRuntime.CampsiteImprovementComponent.RemoveIndicator
// (Final, Native, Protected, BlueprintCallable)

void CampsiteImprovementComponent::RemoveIndicator()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CampsiteRuntime.CampsiteImprovementComponent.RemoveIndicator"));

	CampsiteImprovementComponent_RemoveIndicator_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CampsiteRuntime.CampsiteImprovementComponent.OnRep_ImprovementOwnerSquadId
// (Final, Native, Protected)

void CampsiteImprovementComponent::OnRep_ImprovementOwnerSquadId()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CampsiteRuntime.CampsiteImprovementComponent.OnRep_ImprovementOwnerSquadId"));

	CampsiteImprovementComponent_OnRep_ImprovementOwnerSquadId_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CampsiteRuntime.CampsiteImprovementComponent.CreateIndicator
// (Final, Native, Protected, BlueprintCallable)

void CampsiteImprovementComponent::CreateIndicator()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CampsiteRuntime.CampsiteImprovementComponent.CreateIndicator"));

	CampsiteImprovementComponent_CreateIndicator_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CampsiteRuntime.FortControllerComponent_CampsiteAccountItem.WriteStashedItemFromEntry
// (Final, BlueprintAuthorityOnly, Native, Public, HasOutParms, BlueprintCallable)
// Parameters:
// class FortPlayerControllerAthena* PlayerController_69            (Parm, ZeroConstructor)
// struct FFortItemEntry          ItemEntry_69                   (ConstParm, Parm, OutParm, ReferenceParm)
// int                            StashedItemIndex_69            (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void FortControllerComponent_CampsiteAccountItem::WriteStashedItemFromEntry(class FortPlayerControllerAthena* PlayerController_69, const struct FFortItemEntry& ItemEntry_69, int StashedItemIndex_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CampsiteRuntime.FortControllerComponent_CampsiteAccountItem.WriteStashedItemFromEntry"));

	FortControllerComponent_CampsiteAccountItem_WriteStashedItemFromEntry_Params params;
	params.PlayerController_69 = PlayerController_69;
	params.ItemEntry_69 = ItemEntry_69;
	params.StashedItemIndex_69 = StashedItemIndex_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CampsiteRuntime.FortControllerComponent_CampsiteAccountItem.WriteStashedItem
// (Final, BlueprintAuthorityOnly, Native, Public, BlueprintCallable)
// Parameters:
// class FortPlayerControllerAthena* PlayerController_69            (Parm, ZeroConstructor)
// class FortWorldItem*           Item_69                        (ConstParm, Parm, ZeroConstructor)
// int                            StashedItemIndex_69            (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void FortControllerComponent_CampsiteAccountItem::WriteStashedItem(class FortPlayerControllerAthena* PlayerController_69, class FortWorldItem* Item_69, int StashedItemIndex_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CampsiteRuntime.FortControllerComponent_CampsiteAccountItem.WriteStashedItem"));

	FortControllerComponent_CampsiteAccountItem_WriteStashedItem_Params params;
	params.PlayerController_69 = PlayerController_69;
	params.Item_69 = Item_69;
	params.StashedItemIndex_69 = StashedItemIndex_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CampsiteRuntime.FortControllerComponent_CampsiteAccountItem.SwapStashedItem
// (Final, BlueprintAuthorityOnly, Native, Public, BlueprintCallable)
// Parameters:
// class Actor_32759*             SourceActor_69                 (ConstParm, Parm, ZeroConstructor)
// int                            StashedItemIndex_69            (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool FortControllerComponent_CampsiteAccountItem::SwapStashedItem(class Actor_32759* SourceActor_69, int StashedItemIndex_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CampsiteRuntime.FortControllerComponent_CampsiteAccountItem.SwapStashedItem"));

	FortControllerComponent_CampsiteAccountItem_SwapStashedItem_Params params;
	params.SourceActor_69 = SourceActor_69;
	params.StashedItemIndex_69 = StashedItemIndex_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CampsiteRuntime.FortControllerComponent_CampsiteAccountItem.StashCurrentlyHeldItemAndRemoveFromInventory
// (Final, BlueprintAuthorityOnly, Native, Public, BlueprintCallable)
// Parameters:
// int                            StashedItemIndex_69            (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool FortControllerComponent_CampsiteAccountItem::StashCurrentlyHeldItemAndRemoveFromInventory(int StashedItemIndex_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CampsiteRuntime.FortControllerComponent_CampsiteAccountItem.StashCurrentlyHeldItemAndRemoveFromInventory"));

	FortControllerComponent_CampsiteAccountItem_StashCurrentlyHeldItemAndRemoveFromInventory_Params params;
	params.StashedItemIndex_69 = StashedItemIndex_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CampsiteRuntime.FortControllerComponent_CampsiteAccountItem.OnAthenaProfileInitialized
// (Final, Native, Private)

void FortControllerComponent_CampsiteAccountItem::OnAthenaProfileInitialized()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CampsiteRuntime.FortControllerComponent_CampsiteAccountItem.OnAthenaProfileInitialized"));

	FortControllerComponent_CampsiteAccountItem_OnAthenaProfileInitialized_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CampsiteRuntime.FortControllerComponent_CampsiteAccountItem.HasCurrentlyStashedItem
// (Final, BlueprintAuthorityOnly, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// int                            StashedItemIndex_69            (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool FortControllerComponent_CampsiteAccountItem::HasCurrentlyStashedItem(int StashedItemIndex_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CampsiteRuntime.FortControllerComponent_CampsiteAccountItem.HasCurrentlyStashedItem"));

	FortControllerComponent_CampsiteAccountItem_HasCurrentlyStashedItem_Params params;
	params.StashedItemIndex_69 = StashedItemIndex_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CampsiteRuntime.FortControllerComponent_CampsiteAccountItem.GetCurrentlyStashedItemAsItemEntry
// (Final, BlueprintAuthorityOnly, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// int                            StashedItemIndex_69            (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// struct FFortItemEntry          ReturnValue_69                 (Parm, OutParm, ReturnParm)

struct FFortItemEntry FortControllerComponent_CampsiteAccountItem::GetCurrentlyStashedItemAsItemEntry(int StashedItemIndex_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CampsiteRuntime.FortControllerComponent_CampsiteAccountItem.GetCurrentlyStashedItemAsItemEntry"));

	FortControllerComponent_CampsiteAccountItem_GetCurrentlyStashedItemAsItemEntry_Params params;
	params.StashedItemIndex_69 = StashedItemIndex_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CampsiteRuntime.FortControllerComponent_CampsiteAccountItem.ClearStoredCampsiteLocations
// (Final, BlueprintAuthorityOnly, Native, Public, BlueprintCallable)

void FortControllerComponent_CampsiteAccountItem::ClearStoredCampsiteLocations()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CampsiteRuntime.FortControllerComponent_CampsiteAccountItem.ClearStoredCampsiteLocations"));

	FortControllerComponent_CampsiteAccountItem_ClearStoredCampsiteLocations_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CampsiteRuntime.FortControllerComponent_CampsiteAccountItem.ClearStashedItemAndGiveToPlayer
// (Final, BlueprintAuthorityOnly, Native, Public, BlueprintCallable)
// Parameters:
// class Actor_32759*             SourceActor_69                 (ConstParm, Parm, ZeroConstructor)
// int                            StashedItemIndex_69            (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool FortControllerComponent_CampsiteAccountItem::ClearStashedItemAndGiveToPlayer(class Actor_32759* SourceActor_69, int StashedItemIndex_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CampsiteRuntime.FortControllerComponent_CampsiteAccountItem.ClearStashedItemAndGiveToPlayer"));

	FortControllerComponent_CampsiteAccountItem_ClearStashedItemAndGiveToPlayer_Params params;
	params.SourceActor_69 = SourceActor_69;
	params.StashedItemIndex_69 = StashedItemIndex_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CampsiteRuntime.FortControllerComponent_CampsiteAccountItem.ClearStashedItem
// (Final, BlueprintAuthorityOnly, Native, Public, BlueprintCallable)
// Parameters:
// int                            StashedItemIndex_69            (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void FortControllerComponent_CampsiteAccountItem::ClearStashedItem(int StashedItemIndex_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CampsiteRuntime.FortControllerComponent_CampsiteAccountItem.ClearStashedItem"));

	FortControllerComponent_CampsiteAccountItem_ClearStashedItem_Params params;
	params.StashedItemIndex_69 = StashedItemIndex_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CampsiteRuntime.FortControllerComponent_CampsiteAccountItem.CacheAccountItemData
// (Final, Native, Private)

void FortControllerComponent_CampsiteAccountItem::CacheAccountItemData()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CampsiteRuntime.FortControllerComponent_CampsiteAccountItem.CacheAccountItemData"));

	FortControllerComponent_CampsiteAccountItem_CacheAccountItemData_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CampsiteRuntime.FortGameStateComponent_Campsite.RegisterPreplacedCampsite
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// class AbandonedCampsitePlacedSpawner* PreplacedCampsiteSpawnPoint_69 (Parm, ZeroConstructor)

void FortGameStateComponent_Campsite::RegisterPreplacedCampsite(class AbandonedCampsitePlacedSpawner* PreplacedCampsiteSpawnPoint_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CampsiteRuntime.FortGameStateComponent_Campsite.RegisterPreplacedCampsite"));

	FortGameStateComponent_Campsite_RegisterPreplacedCampsite_Params params;
	params.PreplacedCampsiteSpawnPoint_69 = PreplacedCampsiteSpawnPoint_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CampsiteRuntime.FortGameStateComponent_Campsite.RegisterCampsiteLocation
// (Final, Native, Public, HasOutParms, HasDefaults, BlueprintCallable)
// Parameters:
// struct FVector                 NewCampsiteLocation_69         (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)

void FortGameStateComponent_Campsite::RegisterCampsiteLocation(const struct FVector& NewCampsiteLocation_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CampsiteRuntime.FortGameStateComponent_Campsite.RegisterCampsiteLocation"));

	FortGameStateComponent_Campsite_RegisterCampsiteLocation_Params params;
	params.NewCampsiteLocation_69 = NewCampsiteLocation_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CampsiteRuntime.FortGameStateComponent_Campsite.ClaimUnusedBotName
// (Final, BlueprintAuthorityOnly, Native, Public, HasOutParms, BlueprintCallable)
// Parameters:
// struct FString                 OutBotName_69                  (Parm, OutParm, ZeroConstructor)

void FortGameStateComponent_Campsite::ClaimUnusedBotName(struct FString* OutBotName_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CampsiteRuntime.FortGameStateComponent_Campsite.ClaimUnusedBotName"));

	FortGameStateComponent_Campsite_ClaimUnusedBotName_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (OutBotName_69 != nullptr)
		*OutBotName_69 = params.OutBotName_69;
}


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Classes
//---------------------------------------------------------------------------

// Class Curie.CurieComponent
// 0x0010 (0x00B0 - 0x00A0)
class CurieComponent : public ActorComponent
{
public:
	unsigned char                                      UnknownData00[0x10];                                      // 0x00A0(0x0010) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class Curie.CurieComponent"));
		
		return ptr;
	}

};


// Class Curie.CurieElementGameplayEffectOwner
// 0x0000 (0x0028 - 0x0028)
class CurieElementGameplayEffectOwner : public Object_32759
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class Curie.CurieElementGameplayEffectOwner"));
		
		return ptr;
	}

};


// Class Curie.CurieEntityStateBehavior
// 0x0098 (0x00C0 - 0x0028)
class CurieEntityStateBehavior : public CurieElementGameplayEffectOwner
{
public:
	struct FGameplayTagContainer                       RequiredAttachedElements_69;                              // 0x0028(0x0020) (Edit, BlueprintReadOnly, DisableEditOnInstance)
	struct FGameplayTagContainer                       RequiredInteractingElements_69;                           // 0x0048(0x0020) (Edit, BlueprintReadOnly, DisableEditOnInstance)
	struct FGameplayTagContainer                       AllowedAttachmentEntityTypes_69;                          // 0x0068(0x0020) (Edit, BlueprintReadOnly, DisableEditOnInstance)
	TArray<struct FCurieEffectContainer>               OnBeginEffects_69;                                        // 0x0088(0x0010) (Edit, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance)
	TArray<struct FCurieEffectContainer>               OngoingEffects_69;                                        // 0x0098(0x0010) (Edit, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance)
	TArray<struct FCurieEffectContainer>               OnEndEffects_69;                                          // 0x00A8(0x0010) (Edit, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance)
	unsigned char                                      bShouldDetach_69 : 1;                                     // 0x00B8(0x0001) (Edit, BlueprintReadOnly, DisableEditOnInstance)
	unsigned char                                      bSkipExecuteAttachDetach_69 : 1;                          // 0x00B8(0x0001) (Edit, BlueprintReadOnly, DisableEditOnInstance)
	unsigned char                                      UnknownData00[0x7];                                       // 0x00B9(0x0007) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class Curie.CurieEntityStateBehavior"));
		
		return ptr;
	}

};


// Class Curie.CurieGlobals
// 0x0028 (0x0050 - 0x0028)
class CurieGlobals : public Object_32759
{
public:
	bool                                               bEnableCurie_69;                                          // 0x0028(0x0001) (ZeroConstructor, Config, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0029(0x0007) MISSED OFFSET
	struct FSoftClassPath                              CurieGlobalsClassName_69;                                 // 0x0030(0x0018) (ZeroConstructor, Config)
	class CurieManager*                                RegisteredCurieManager_69;                                // 0x0048(0x0008) (ExportObject, ZeroConstructor, Transient, InstancedReference)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class Curie.CurieGlobals"));
		
		return ptr;
	}

};


// Class Curie.CurieElementAllocationHandler
// 0x0000 (0x0028 - 0x0028)
class CurieElementAllocationHandler : public Object_32759
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class Curie.CurieElementAllocationHandler"));
		
		return ptr;
	}

};


// Class Curie.CurieElementInteractWithElementHandler
// 0x0008 (0x0030 - 0x0028)
class CurieElementInteractWithElementHandler : public Object_32759
{
public:
	ECurieHandlerPriority                              HandlerPriority_69;                                       // 0x0028(0x0001) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	ECurieHandlerBehavior                              HandlerBehavior_69;                                       // 0x0029(0x0001) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData00[0x2];                                       // 0x002A(0x0002) MISSED OFFSET
	struct FGameplayTag                                ElementTag_69;                                            // 0x002C(0x0004) (Edit, DisableEditOnInstance)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class Curie.CurieElementInteractWithElementHandler"));
		
		return ptr;
	}

};


// Class Curie.CurieElementInteractWithMaterialHandler
// 0x0008 (0x0030 - 0x0028)
class CurieElementInteractWithMaterialHandler : public Object_32759
{
public:
	ECurieHandlerPriority                              HandlerPriority_69;                                       // 0x0028(0x0001) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	ECurieHandlerBehavior                              HandlerBehavior_69;                                       // 0x0029(0x0001) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData00[0x2];                                       // 0x002A(0x0002) MISSED OFFSET
	struct FGameplayTag                                ElementTag_69;                                            // 0x002C(0x0004) (Edit, DisableEditOnInstance)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class Curie.CurieElementInteractWithMaterialHandler"));
		
		return ptr;
	}

};


// Class Curie.CurieElementAttachHandler
// 0x0038 (0x0060 - 0x0028)
class CurieElementAttachHandler : public CurieElementGameplayEffectOwner
{
public:
	ECurieHandlerPriority                              HandlerPriority_69;                                       // 0x0028(0x0001) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	ECurieHandlerBehavior                              HandlerBehavior_69;                                       // 0x0029(0x0001) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData00[0x2];                                       // 0x002A(0x0002) MISSED OFFSET
	struct FGameplayTag                                ElementTag_69;                                            // 0x002C(0x0004) (Edit, DisableEditOnInstance)
	TArray<struct FCurieEffectContainer>               OnBeginAttachmentEffects_69;                              // 0x0030(0x0010) (Edit, ZeroConstructor, DisableEditOnInstance)
	TArray<struct FCurieEffectContainer>               OngoingAttachmentEffects_69;                              // 0x0040(0x0010) (Edit, ZeroConstructor, DisableEditOnInstance)
	TArray<struct FCurieEffectContainer>               OnEndAttachmentEffects_69;                                // 0x0050(0x0010) (Edit, ZeroConstructor, DisableEditOnInstance)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class Curie.CurieElementAttachHandler"));
		
		return ptr;
	}

};


// Class Curie.CurieElementAttachConditionHandler
// 0x0008 (0x0030 - 0x0028)
class CurieElementAttachConditionHandler : public Object_32759
{
public:
	ECurieHandlerPriority                              HandlerPriority_69;                                       // 0x0028(0x0001) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0029(0x0003) MISSED OFFSET
	struct FGameplayTag                                ElementTag_69;                                            // 0x002C(0x0004) (Edit, DisableEditOnInstance)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class Curie.CurieElementAttachConditionHandler"));
		
		return ptr;
	}

};


// Class Curie.CurieElementInteractWithContainerHandler
// 0x0048 (0x0070 - 0x0028)
class CurieElementInteractWithContainerHandler : public CurieElementGameplayEffectOwner
{
public:
	ECurieHandlerPriority                              HandlerPriority_69;                                       // 0x0028(0x0001) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	ECurieHandlerBehavior                              HandlerBehavior_69;                                       // 0x0029(0x0001) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData00[0x2];                                       // 0x002A(0x0002) MISSED OFFSET
	struct FGameplayTag                                ElementTag_69;                                            // 0x002C(0x0004) (Edit, DisableEditOnInstance)
	TArray<struct FCurieEffectContainer>               OnInstantInteractionEffects_69;                           // 0x0030(0x0010) (Edit, ZeroConstructor, DisableEditOnInstance)
	TArray<struct FCurieEffectContainer>               OnBeginInteractionEffects_69;                             // 0x0040(0x0010) (Edit, ZeroConstructor, DisableEditOnInstance)
	TArray<struct FCurieEffectContainer>               OngoingInteractionEffects_69;                             // 0x0050(0x0010) (Edit, ZeroConstructor, DisableEditOnInstance)
	TArray<struct FCurieEffectContainer>               OnEndInteractionEffects_69;                               // 0x0060(0x0010) (Edit, ZeroConstructor, DisableEditOnInstance)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class Curie.CurieElementInteractWithContainerHandler"));
		
		return ptr;
	}

};


// Class Curie.CurieInterface
// 0x0000 (0x0028 - 0x0028)
class CurieInterface : public Interface
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class Curie.CurieInterface"));
		
		return ptr;
	}


	void OnCurieStateDetached_BP(const struct FCurieContainerHandle& CurieContainerHandle_69, const struct FGameplayTag& StateTag_69);
	void OnCurieStateAttached_BP(const struct FCurieContainerHandle& CurieContainerHandle_69, const struct FGameplayTag& StateTag_69);
	void OnCurieElementInteractEnded_BP(const struct FCurieContainerHandle& CurieContainerHandle_69, const struct FGameplayTag& ElementTag_69, const struct FCurieInteractParamsHandle& InteractParamsHandle_69);
	void OnCurieElementInteractBegun_BP(const struct FCurieContainerHandle& CurieContainerHandle_69, const struct FGameplayTag& ElementTag_69, const struct FCurieInteractParamsHandle& InteractParamsHandle_69);
	void OnCurieElementInteract_BP(const struct FCurieContainerHandle& CurieContainerHandle_69, const struct FGameplayTag& ElementTag_69, const struct FCurieInteractParamsHandle& InteractParamsHandle_69);
	void OnCurieElementDetached_BP(const struct FCurieContainerHandle& CurieContainerHandle_69, const struct FGameplayTag& ElementTag_69);
	void OnCurieElementAttached_BP(const struct FCurieContainerHandle& CurieContainerHandle_69, const struct FGameplayTag& ElementTag_69);
	void OnCurieContainerReparented_BP(const struct FCurieContainerHandle& CurieContainerHandle_69);
	void OnCurieContainerReleased_BP(const struct FCurieContainerHandle& CurieContainerHandle_69);
	void OnCurieContainerAcquired_BP(const struct FCurieContainerHandle& CurieContainerHandle_69);
};


// Class Curie.CurieManager
// 0x0590 (0x0630 - 0x00A0)
class CurieManager : public GameStateComponent
{
public:
	class CurieComponent*                              CurieComponentClass_69;                                   // 0x00A0(0x0008) (Edit, ZeroConstructor, DisableEditOnInstance)
	struct FName                                       CurieManagerRegistryName_69;                              // 0x00A8(0x0008) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	struct FName                                       MaterialDataRegistryName_69;                              // 0x00AC(0x0008) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	struct FName                                       ElementDataRegistryName_69;                               // 0x00B0(0x0008) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	struct FName                                       EntityStateDataRegistryName_69;                           // 0x00B4(0x0008) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData00[0x298];                                     // 0x00B8(0x0298) MISSED OFFSET
	TMap<struct FGameplayTag, class CurieElementAllocationHandler*> ElementAllocationHandlers_69;                             // 0x0350(0x0050) (Transient)
	TMap<struct FGameplayTag, struct FCurieElementAttachHandlersContainer> ElementAttachmentHandlers_69;                             // 0x03A0(0x0050) (Transient)
	TMap<struct FGameplayTag, struct FCurieElementAttachConditionHandlersContainer> ElementAttachmentConditionHandlers_69;                    // 0x03F0(0x0050) (Transient)
	TMap<struct FCurieElementPairKey, struct FCurieElementInteractWithElementHandlersContainer> ElementInteractWithElementHandlers_69;                    // 0x0440(0x0050) (Transient)
	TMap<struct FGameplayTag, struct FCurieElementInteractWithMaterialHandlersContainer> ElementInteractWithMaterialHandlers_69;                   // 0x0490(0x0050) (Transient)
	TMap<struct FGameplayTag, struct FCurieElementInteractWithContainerHandlersContainer> ElementInteractWithContainerHandlers_69;                  // 0x04E0(0x0050) (Transient)
	TArray<class CurieManagerComponent*>               CurieManagerComponents_69;                                // 0x0530(0x0010) (ZeroConstructor, Transient)
	unsigned char                                      UnknownData01[0xF0];                                      // 0x0540(0x00F0) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class Curie.CurieManager"));
		
		return ptr;
	}


	void UnbindDelegateForCurieStateDetached(class Object_32759* CurieOwner_69, const struct FScriptDelegate& Delegate_69);
	void UnbindDelegateForCurieStateAttached(class Object_32759* CurieOwner_69, const struct FScriptDelegate& Delegate_69);
	void UnbindDelegateForCurieElementInteract(class Object_32759* CurieOwner_69, const struct FScriptDelegate& Delegate_69);
	void UnbindDelegateForCurieElementEndInteract(class Object_32759* CurieOwner_69, const struct FScriptDelegate& Delegate_69);
	void UnbindDelegateForCurieElementDetached(class Object_32759* CurieOwner_69, const struct FScriptDelegate& Delegate_69);
	void UnbindDelegateForCurieElementBeginInteract(class Object_32759* CurieOwner_69, const struct FScriptDelegate& Delegate_69);
	void UnbindDelegateForCurieElementAttached(class Object_32759* CurieOwner_69, const struct FScriptDelegate& Delegate_69);
	void HandleContainerOwnerDestroyed(class Actor_32759* OwnerActor_69);
	void BindDelegateForCurieStateDetached(class Object_32759* CurieOwner_69, const struct FScriptDelegate& Delegate_69);
	void BindDelegateForCurieStateAttached(class Object_32759* CurieOwner_69, const struct FScriptDelegate& Delegate_69);
	void BindDelegateForCurieElementInteract(class Object_32759* CurieOwner_69, const struct FScriptDelegate& Delegate_69);
	void BindDelegateForCurieElementEndInteract(class Object_32759* CurieOwner_69, const struct FScriptDelegate& Delegate_69);
	void BindDelegateForCurieElementDetached(class Object_32759* CurieOwner_69, const struct FScriptDelegate& Delegate_69);
	void BindDelegateForCurieElementBeginInteract(class Object_32759* CurieOwner_69, const struct FScriptDelegate& Delegate_69);
	void BindDelegateForCurieElementAttached(class Object_32759* CurieOwner_69, const struct FScriptDelegate& Delegate_69);
};


// Class Curie.CurieManagerComponentInterface
// 0x0000 (0x0028 - 0x0028)
class CurieManagerComponentInterface : public Interface
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class Curie.CurieManagerComponentInterface"));
		
		return ptr;
	}

};


// Class Curie.CurieManagerComponentConfig
// 0x0010 (0x0040 - 0x0030)
class CurieManagerComponentConfig : public PrimaryDataAsset
{
public:
	unsigned char                                      UnknownData00[0x8];                                       // 0x0030(0x0008) MISSED OFFSET
	struct FName                                       ConfigName_69;                                            // 0x0038(0x0008) (Edit, ZeroConstructor, EditConst, IsPlainOldData)
	struct FGameplayTag                                ConfigTag_69;                                             // 0x003C(0x0004) (Edit, DisableEditOnInstance)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class Curie.CurieManagerComponentConfig"));
		
		return ptr;
	}

};


// Class Curie.CurieManagerComponent
// 0x0008 (0x0030 - 0x0028)
class CurieManagerComponent : public Object_32759
{
public:
	class CurieManagerComponentConfig*                 CachedConfig_69;                                          // 0x0028(0x0008) (ZeroConstructor)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class Curie.CurieManagerComponent"));
		
		return ptr;
	}

};


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

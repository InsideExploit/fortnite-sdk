#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Enums
//---------------------------------------------------------------------------

// Enum CoreOnline.ECoreOnlineDummy
enum class ECoreOnlineDummy : uint8_t
{
	Dummy                          = 0,
	ECoreOnlineDummy_MAX           = 1
};



//---------------------------------------------------------------------------
//Script Structs
//---------------------------------------------------------------------------

// ScriptStruct CoreOnline.JoinabilitySettings
// 0x0010
struct FJoinabilitySettings
{
	struct FName                                       SessionName_69;                                           // 0x0000(0x0008) (ZeroConstructor, IsPlainOldData)
	bool                                               bPublicSearchable_69;                                     // 0x0004(0x0001) (ZeroConstructor, IsPlainOldData)
	bool                                               bAllowInvites_69;                                         // 0x0005(0x0001) (ZeroConstructor, IsPlainOldData)
	bool                                               bJoinViaPresence_69;                                      // 0x0006(0x0001) (ZeroConstructor, IsPlainOldData)
	bool                                               bJoinViaPresenceFriendsOnly_69;                           // 0x0007(0x0001) (ZeroConstructor, IsPlainOldData)
	int                                                MaxPlayers_69;                                            // 0x0008(0x0004) (ZeroConstructor, IsPlainOldData)
	int                                                MaxPartySize_69;                                          // 0x000C(0x0004) (ZeroConstructor, IsPlainOldData)
};

// ScriptStruct CoreOnline.UniqueNetIdWrapper
// 0x0001
struct FUniqueNetIdWrapper
{
	unsigned char                                      UnknownData00[0x1];                                       // 0x0000(0x0001) MISSED OFFSET
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

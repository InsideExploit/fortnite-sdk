#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Classes
//---------------------------------------------------------------------------

// Class CommonInput.CommonInputActionDomain
// 0x0010 (0x0040 - 0x0030)
class CommonInputActionDomain : public DataAsset
{
public:
	ECommonInputEventFlowBehavior                      Behavior_69;                                              // 0x0030(0x0001) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0030(0x0003) FIX WRONG TYPE SIZE OF PREVIOUS PROPERTY
	ECommonInputEventFlowBehavior                      InnerBehavior_69;                                         // 0x0034(0x0001) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData01[0x3];                                       // 0x0034(0x0003) FIX WRONG TYPE SIZE OF PREVIOUS PROPERTY
	bool                                               bUseActionDomainDesiredInputConfig_69;                    // 0x0038(0x0001) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	ECommonInputMode                                   InputMode_69;                                             // 0x0039(0x0001) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	EMouseCaptureMode                                  MouseCaptureMode_69;                                      // 0x003A(0x0001) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData02[0x5];                                       // 0x003B(0x0005) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CommonInput.CommonInputActionDomain"));
		
		return ptr;
	}

};


// Class CommonInput.CommonInputActionDomainTable
// 0x0018 (0x0048 - 0x0030)
class CommonInputActionDomainTable : public DataAsset
{
public:
	TArray<class CommonInputActionDomain*>             ActionDomains_69;                                         // 0x0030(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance)
	ECommonInputMode                                   InputMode_69;                                             // 0x0040(0x0001) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	EMouseCaptureMode                                  MouseCaptureMode_69;                                      // 0x0041(0x0001) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData00[0x6];                                       // 0x0042(0x0006) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CommonInput.CommonInputActionDomainTable"));
		
		return ptr;
	}

};


// Class CommonInput.CommonUIInputData
// 0x0020 (0x0048 - 0x0028)
class CommonUIInputData : public Object_32759
{
public:
	struct FDataTableRowHandle                         DefaultClickAction_69;                                    // 0x0028(0x0010) (Edit, DisableEditOnInstance)
	struct FDataTableRowHandle                         DefaultBackAction_69;                                     // 0x0038(0x0010) (Edit, DisableEditOnInstance)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CommonInput.CommonUIInputData"));
		
		return ptr;
	}

};


// Class CommonInput.CommonInputBaseControllerData
// 0x00D0 (0x00F8 - 0x0028)
class CommonInputBaseControllerData : public Object_32759
{
public:
	ECommonInputType                                   InputType_69;                                             // 0x0028(0x0001) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0029(0x0003) MISSED OFFSET
	struct FName                                       GamepadName_69;                                           // 0x002C(0x0008) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	struct FText                                       GamepadDisplayName_69;                                    // 0x0030(0x0018) (Edit, DisableEditOnInstance)
	struct FText                                       GamepadCategory_69;                                       // 0x0048(0x0018) (Edit, DisableEditOnInstance)
	struct FText                                       GamepadPlatformName_69;                                   // 0x0060(0x0018) (Edit, DisableEditOnInstance)
	TArray<struct FInputDeviceIdentifierPair>          GamepadHardwareIdMapping_69;                              // 0x0078(0x0010) (Edit, ZeroConstructor, DisableEditOnInstance)
	unsigned char                                      UnknownData01[0x28];                                      // 0x0088(0x0028) UNKNOWN PROPERTY: SoftObjectProperty CommonInput.CommonInputBaseControllerData.ControllerTexture_69
	unsigned char                                      UnknownData02[0x28];                                      // 0x00B0(0x0028) UNKNOWN PROPERTY: SoftObjectProperty CommonInput.CommonInputBaseControllerData.ControllerButtonMaskTexture_69
	TArray<struct FCommonInputKeyBrushConfiguration>   InputBrushDataMap_69;                                     // 0x00D8(0x0010) (Edit, ZeroConstructor, DisableEditOnInstance)
	TArray<struct FCommonInputKeySetBrushConfiguration> InputBrushKeySets_69;                                     // 0x00E8(0x0010) (Edit, ZeroConstructor, DisableEditOnInstance)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CommonInput.CommonInputBaseControllerData"));
		
		return ptr;
	}


	TArray<struct FName> STATIC_GetRegisteredGamepads();
};


// Class CommonInput.CommonInputPlatformSettings
// 0x0030 (0x0070 - 0x0040)
class CommonInputPlatformSettings : public PlatformSettings
{
public:
	ECommonInputType                                   DefaultInputType_69;                                      // 0x0040(0x0001) (Edit, ZeroConstructor, Config, IsPlainOldData)
	bool                                               bSupportsMouseAndKeyboard_69;                             // 0x0041(0x0001) (Edit, ZeroConstructor, Config, IsPlainOldData)
	bool                                               bSupportsTouch_69;                                        // 0x0042(0x0001) (Edit, ZeroConstructor, Config, IsPlainOldData)
	bool                                               bSupportsGamepad_69;                                      // 0x0043(0x0001) (Edit, ZeroConstructor, Config, IsPlainOldData)
	struct FName                                       DefaultGamepadName_69;                                    // 0x0044(0x0008) (Edit, ZeroConstructor, Config, IsPlainOldData)
	bool                                               bCanChangeGamepadType_69;                                 // 0x0048(0x0001) (Edit, ZeroConstructor, Config, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0049(0x0007) MISSED OFFSET
	unsigned char                                      UnknownData01[0x10];                                      // 0x0049(0x0010) UNKNOWN PROPERTY: ArrayProperty CommonInput.CommonInputPlatformSettings.ControllerData_69
	TArray<class CommonInputBaseControllerData*>       ControllerDataClasses_69;                                 // 0x0060(0x0010) (ZeroConstructor, Transient)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CommonInput.CommonInputPlatformSettings"));
		
		return ptr;
	}

};


// Class CommonInput.CommonInputSettings
// 0x00E8 (0x0118 - 0x0030)
class CommonInputSettings : public DeveloperSettings
{
public:
	unsigned char                                      UnknownData00[0x28];                                      // 0x0030(0x0028) UNKNOWN PROPERTY: SoftClassProperty CommonInput.CommonInputSettings.InputData_69
	struct FPerPlatformSettings                        PlatformInput_69;                                         // 0x0058(0x0010) (Edit)
	TMap<struct FName, struct FCommonInputPlatformBaseData> CommonInputPlatformData_69;                               // 0x0068(0x0050) (Config, Deprecated)
	bool                                               bEnableInputMethodThrashingProtection_69;                 // 0x00B8(0x0001) (Edit, ZeroConstructor, Config, IsPlainOldData)
	unsigned char                                      UnknownData01[0x3];                                       // 0x00B9(0x0003) MISSED OFFSET
	int                                                InputMethodThrashingLimit_69;                             // 0x00BC(0x0004) (Edit, ZeroConstructor, Config, IsPlainOldData)
	double                                             InputMethodThrashingWindowInSeconds_69;                   // 0x00C0(0x0008) (Edit, ZeroConstructor, Config, IsPlainOldData)
	double                                             InputMethodThrashingCooldownInSeconds_69;                 // 0x00C8(0x0008) (Edit, ZeroConstructor, Config, IsPlainOldData)
	bool                                               bAllowOutOfFocusDeviceInput_69;                           // 0x00D0(0x0001) (Edit, ZeroConstructor, Config, IsPlainOldData)
	bool                                               bEnableDefaultInputConfig_69;                             // 0x00D1(0x0001) (Edit, ZeroConstructor, Config, IsPlainOldData)
	unsigned char                                      UnknownData02[0x6];                                       // 0x00D2(0x0006) MISSED OFFSET
	unsigned char                                      UnknownData03[0x28];                                      // 0x00D2(0x0028) UNKNOWN PROPERTY: SoftObjectProperty CommonInput.CommonInputSettings.ActionDomainTable_69
	unsigned char                                      UnknownData04[0x8];                                       // 0x0100(0x0008) MISSED OFFSET
	class CommonUIInputData*                           InputDataClass_69;                                        // 0x0108(0x0008) (ZeroConstructor, Transient)
	class CommonInputActionDomainTable*                ActionDomainTablePtr_69;                                  // 0x0110(0x0008) (ZeroConstructor, Transient)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CommonInput.CommonInputSettings"));
		
		return ptr;
	}

};


// Class CommonInput.CommonInputSubsystem
// 0x00D0 (0x0100 - 0x0030)
class CommonInputSubsystem : public LocalPlayerSubsystem
{
public:
	unsigned char                                      UnknownData00[0x28];                                      // 0x0030(0x0028) MISSED OFFSET
	unsigned char                                      UnknownData01[0x10];                                      // 0x0030(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty CommonInput.CommonInputSubsystem.OnInputMethodChanged_69
	int                                                NumberOfInputMethodChangesRecently_69;                    // 0x0068(0x0004) (ZeroConstructor, Transient, IsPlainOldData)
	unsigned char                                      UnknownData02[0x4];                                       // 0x006C(0x0004) MISSED OFFSET
	double                                             LastInputMethodChangeTime_69;                             // 0x0070(0x0008) (ZeroConstructor, Transient, IsPlainOldData)
	double                                             LastTimeInputMethodThrashingBegan_69;                     // 0x0078(0x0008) (ZeroConstructor, Transient, IsPlainOldData)
	ECommonInputType                                   LastInputType_69;                                         // 0x0080(0x0001) (ZeroConstructor, Transient, IsPlainOldData)
	ECommonInputType                                   CurrentInputType_69;                                      // 0x0081(0x0001) (ZeroConstructor, Transient, IsPlainOldData)
	unsigned char                                      UnknownData03[0x2];                                       // 0x0082(0x0002) MISSED OFFSET
	struct FName                                       GamepadInputType_69;                                      // 0x0084(0x0008) (ZeroConstructor, Transient, IsPlainOldData)
	TMap<struct FName, ECommonInputType>               CurrentInputLocks_69;                                     // 0x0088(0x0050) (Transient)
	unsigned char                                      UnknownData04[0x18];                                      // 0x00D8(0x0018) MISSED OFFSET
	class CommonInputActionDomainTable*                ActionDomainTable_69;                                     // 0x00F0(0x0008) (ZeroConstructor, Transient)
	bool                                               bIsGamepadSimulatedClick_69;                              // 0x00F8(0x0001) (ZeroConstructor, Transient, IsPlainOldData)
	unsigned char                                      UnknownData05[0x7];                                       // 0x00F9(0x0007) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CommonInput.CommonInputSubsystem"));
		
		return ptr;
	}


	bool ShouldShowInputKeys();
	void SetGamepadInputType(const struct FName& InGamepadInputType_69);
	void SetCurrentInputType(ECommonInputType NewInputType_69);
	bool IsUsingPointerInput();
	bool IsInputMethodActive(ECommonInputType InputMethod_69);
	ECommonInputType GetDefaultInputType();
	ECommonInputType GetCurrentInputType();
	struct FName GetCurrentGamepadName();
};


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

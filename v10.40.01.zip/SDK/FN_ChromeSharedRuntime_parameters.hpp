#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function ChromeSharedRuntime.ChromeSoundComponentBase.SetupChromeAudio
struct ChromeSoundComponentBase_SetupChromeAudio_Params
{
	class Actor_32759*                                 Actor_69;                                                 // (ConstParm, Parm, ZeroConstructor)
	bool                                               bAdd_69;                                                  // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	ELacklusterChromeType                              ChromeType_69;                                            // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function ChromeSharedRuntime.FortChromeSubsystem.ShouldDelayASCCreation
struct FortChromeSubsystem_ShouldDelayASCCreation_Params
{
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function ChromeSharedRuntime.FortChromeSubsystem.SetupChromeOnActor
struct FortChromeSubsystem_SetupChromeOnActor_Params
{
	class Actor_32759*                                 Actor_69;                                                 // (ConstParm, Parm, ZeroConstructor)
};

// Function ChromeSharedRuntime.FortChromeSubsystem.RestoreActorOriginalMaterials
struct FortChromeSubsystem_RestoreActorOriginalMaterials_Params
{
	class Actor_32759*                                 Actor_69;                                                 // (ConstParm, Parm, ZeroConstructor)
};

// Function ChromeSharedRuntime.FortChromeSubsystem.PawnHitActor
struct FortChromeSubsystem_PawnHitActor_Params
{
	class FortPlayerPawn*                              Pawn_69;                                                  // (Parm, ZeroConstructor)
	struct FHitResult                                  HitResult_69;                                             // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	class Actor_32759*                                 HitActor_69;                                              // (Parm, ZeroConstructor)
};

// Function ChromeSharedRuntime.FortChromeSubsystem.OnPlaylistDataReady
struct FortChromeSubsystem_OnPlaylistDataReady_Params
{
	class FortGameStateAthena*                         GameState_69;                                             // (Parm, ZeroConstructor)
	class FortPlaylist*                                Playlist_69;                                              // (ConstParm, Parm, ZeroConstructor)
	struct FGameplayTagContainer                       PlaylistContextTags_69;                                   // (ConstParm, Parm, OutParm, ReferenceParm)
};

// Function ChromeSharedRuntime.FortChromeSubsystem.NativeSetupChromeOnActor
struct FortChromeSubsystem_NativeSetupChromeOnActor_Params
{
	class Actor_32759*                                 Actor_69;                                                 // (Parm, ZeroConstructor)
};

// Function ChromeSharedRuntime.FortChromeSubsystem.NativeHandleVehicleModUpdated
struct FortChromeSubsystem_NativeHandleVehicleModUpdated_Params
{
	class FortAthenaVehicle*                           Vehicle_69;                                               // (ConstParm, Parm, ZeroConstructor)
	struct FGameplayTag                                ModTag_69;                                                // (ConstParm, Parm, OutParm, ReferenceParm)
};

// Function ChromeSharedRuntime.FortChromeSubsystem.NativeHandleContainerSearchedStateChanged
struct FortChromeSubsystem_NativeHandleContainerSearchedStateChanged_Params
{
	class BuildingContainer*                           BuildingContainer_69;                                     // (Parm, ZeroConstructor)
	bool                                               bSearched_69;                                             // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function ChromeSharedRuntime.FortChromeSubsystem.NativeHandleContainerRandomUpgradeApplied
struct FortChromeSubsystem_NativeHandleContainerRandomUpgradeApplied_Params
{
	class BuildingContainer*                           BuildingContainer_69;                                     // (Parm, ZeroConstructor)
	int                                                UpgradeIndex_69;                                          // (Parm, ZeroConstructor, IsPlainOldData)
	struct FName                                       UpgradeLootTierGroup_69;                                  // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
};

// Function ChromeSharedRuntime.FortChromeSubsystem.NativeHandleContainerMeshSetChanged
struct FortChromeSubsystem_NativeHandleContainerMeshSetChanged_Params
{
	class BuildingSMActor*                             BuildingSMActor_69;                                       // (Parm, ZeroConstructor)
	struct FMeshSet                                    NewMeshSet_69;                                            // (ConstParm, Parm, OutParm, ReferenceParm)
};

// Function ChromeSharedRuntime.FortChromeSubsystem.IsActorPhaseable
struct FortChromeSubsystem_IsActorPhaseable_Params
{
	class Actor_32759*                                 Actor_69;                                                 // (ConstParm, Parm, ZeroConstructor)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function ChromeSharedRuntime.FortChromeSubsystem.IsActorChromable
struct FortChromeSubsystem_IsActorChromable_Params
{
	class Actor_32759*                                 Actor_69;                                                 // (ConstParm, Parm, ZeroConstructor)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function ChromeSharedRuntime.FortChromeSubsystem.InitLacklusterFunctionLibrary
struct FortChromeSubsystem_InitLacklusterFunctionLibrary_Params
{
};

// Function ChromeSharedRuntime.FortChromeSubsystem.GetSharedChromeMID
struct FortChromeSubsystem_GetSharedChromeMID_Params
{
	class Actor_32759*                                 Actor_69;                                                 // (Parm, ZeroConstructor)
	class MaterialInterface*                           Parent_69;                                                // (Parm, ZeroConstructor)
	TMap<struct FName, class Texture*>                 NamesToTexturesMap_69;                                    // (Parm, OutParm, ReferenceParm)
	class MaterialInstanceDynamic*                     ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function ChromeSharedRuntime.FortChromeSubsystem.GetOverlappingActorsOfClass
struct FortChromeSubsystem_GetOverlappingActorsOfClass_Params
{
	class Actor_32759*                                 Actor_69;                                                 // (ConstParm, Parm, ZeroConstructor)
	class Actor_32759*                                 Class_69;                                                 // (ConstParm, Parm, ZeroConstructor)
	TArray<class Actor_32759*>                         OutOverlappingActors_69;                                  // (Parm, OutParm, ZeroConstructor, ReferenceParm)
};

// Function ChromeSharedRuntime.FortChromeSubsystem.ApplyChromeToActor
struct FortChromeSubsystem_ApplyChromeToActor_Params
{
	class Actor_32759*                                 Actor_69;                                                 // (ConstParm, Parm, ZeroConstructor)
};

// Function ChromeSharedRuntime.LacklusterFunctionLibrary.UseNativeFunctions
struct LacklusterFunctionLibrary_UseNativeFunctions_Params
{
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function ChromeSharedRuntime.LacklusterFunctionLibrary.NativeUnbindChromeEvents
struct LacklusterFunctionLibrary_NativeUnbindChromeEvents_Params
{
	class Actor_32759*                                 Actor_69;                                                 // (Parm, ZeroConstructor)
};

// Function ChromeSharedRuntime.LacklusterFunctionLibrary.NativeStopBuildingAudio
struct LacklusterFunctionLibrary_NativeStopBuildingAudio_Params
{
	class BuildingActor*                               BuildingActor_69;                                         // (ConstParm, Parm, ZeroConstructor)
};

// Function ChromeSharedRuntime.LacklusterFunctionLibrary.NativeShouldIgnoreMaterial
struct LacklusterFunctionLibrary_NativeShouldIgnoreMaterial_Params
{
	class MaterialInterface*                           Material_69;                                              // (Parm, ZeroConstructor)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function ChromeSharedRuntime.LacklusterFunctionLibrary.NativeSetupChromeOnActor
struct LacklusterFunctionLibrary_NativeSetupChromeOnActor_Params
{
	class Actor_32759*                                 Actor_69;                                                 // (Parm, ZeroConstructor)
	ELacklusterActorType                               ActorType_69;                                             // (Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
	ELacklusterChromeType                              ChromeType_69;                                            // (Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
	TArray<struct FLacklusterMaterialData>             ChromeMaterialData_69;                                    // (Parm, OutParm, ZeroConstructor, ReferenceParm)
	TArray<struct FLacklusterOriginalMaterialData>     OriginalMaterialData_69;                                  // (Parm, OutParm, ZeroConstructor, ReferenceParm)
	TMap<struct FName, float>                          ContainerMatScalarParamMap_69;                            // (Parm, OutParm, ReferenceParm)
	TMap<struct FName, struct FLinearColor>            ContainerMatVectorParamMap_69;                            // (Parm, OutParm, ReferenceParm)
};

// Function ChromeSharedRuntime.LacklusterFunctionLibrary.NativeSetChromeMaterials
struct LacklusterFunctionLibrary_NativeSetChromeMaterials_Params
{
	TArray<struct FLacklusterMaterialData>             ChromeMaterialStructs_69;                                 // (Parm, OutParm, ZeroConstructor, ReferenceParm)
	ELacklusterChromeType                              ChromeType_69;                                            // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function ChromeSharedRuntime.LacklusterFunctionLibrary.NativeSetChromeAudio
struct LacklusterFunctionLibrary_NativeSetChromeAudio_Params
{
	class Actor_32759*                                 Actor_69;                                                 // (Parm, ZeroConstructor)
	bool                                               bAdd_69;                                                  // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	ELacklusterChromeType                              ChromeType_69;                                            // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function ChromeSharedRuntime.LacklusterFunctionLibrary.NativeRestoreOriginalMaterials
struct LacklusterFunctionLibrary_NativeRestoreOriginalMaterials_Params
{
	class Actor_32759*                                 Actor_69;                                                 // (Parm, ZeroConstructor)
	TArray<struct FLacklusterOriginalMaterialData>     OriginalMaterialDataArray_69;                             // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
};

// Function ChromeSharedRuntime.LacklusterFunctionLibrary.NativeIsMaskedBlendMode
struct LacklusterFunctionLibrary_NativeIsMaskedBlendMode_Params
{
	class MaterialInterface*                           MaterialInterface_69;                                     // (ConstParm, Parm, ZeroConstructor)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function ChromeSharedRuntime.LacklusterFunctionLibrary.NativeHandleActorTypeSpecialCases
struct LacklusterFunctionLibrary_NativeHandleActorTypeSpecialCases_Params
{
	ELacklusterActorType                               ActorType_69;                                             // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bIsMaskedMaterial_69;                                     // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bIsChonkers_69;                                           // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	ELacklusterActorType                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function ChromeSharedRuntime.LacklusterFunctionLibrary.NativeGetChromeVisualComponent
struct LacklusterFunctionLibrary_NativeGetChromeVisualComponent_Params
{
	class Actor_32759*                                 Actor_69;                                                 // (Parm, ZeroConstructor)
	bool                                               bCreateComponentIfNotFound_69;                            // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	class ApplyChromeComponent*                        ReturnValue_69;                                           // (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)
};

// Function ChromeSharedRuntime.LacklusterFunctionLibrary.NativeGetChromeTieredChestMaterial
struct LacklusterFunctionLibrary_NativeGetChromeTieredChestMaterial_Params
{
	class Actor_32759*                                 Actor_69;                                                 // (ConstParm, Parm, ZeroConstructor)
	class MaterialInstance*                            ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function ChromeSharedRuntime.LacklusterFunctionLibrary.NativeGetChromeSoundComponent
struct LacklusterFunctionLibrary_NativeGetChromeSoundComponent_Params
{
	class Actor_32759*                                 Actor_69;                                                 // (Parm, ZeroConstructor)
	bool                                               bCreateComponentIfNotFound_69;                            // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	class ChromeSoundComponentBase*                    ReturnValue_69;                                           // (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)
};

// Function ChromeSharedRuntime.LacklusterFunctionLibrary.NativeGetChromeMaterialOverride
struct LacklusterFunctionLibrary_NativeGetChromeMaterialOverride_Params
{
	bool                                               bIsMaskedMaterial_69;                                     // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bIsChonkers_69;                                           // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	ELacklusterActorType                               ActorType_69;                                             // (Parm, ZeroConstructor, IsPlainOldData)
	class Actor_32759*                                 Actor_69;                                                 // (Parm, ZeroConstructor)
	ELacklusterChromeType                              ChromeType_69;                                            // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	class MaterialInterface*                           ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function ChromeSharedRuntime.LacklusterFunctionLibrary.NativeGetChromeChonkerTires
struct LacklusterFunctionLibrary_NativeGetChromeChonkerTires_Params
{
	class MeshComponent*                               MeshComponent_69;                                         // (ConstParm, Parm, ZeroConstructor, InstancedReference)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function ChromeSharedRuntime.LacklusterFunctionLibrary.NativeGetChromeActorType
struct LacklusterFunctionLibrary_NativeGetChromeActorType_Params
{
	class Actor_32759*                                 Actor_69;                                                 // (Parm, ZeroConstructor)
	ELacklusterChromeType                              ChromeTypeOut_69;                                         // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	ELacklusterActorType                               ActorTypeOut_69;                                          // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
};

// Function ChromeSharedRuntime.LacklusterFunctionLibrary.NativeFindTexturesFromComponents
struct LacklusterFunctionLibrary_NativeFindTexturesFromComponents_Params
{
	ELacklusterActorType                               ActorType_69;                                             // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	class Actor_32759*                                 Actor_69;                                                 // (Parm, ZeroConstructor)
	TArray<struct FLacklusterMaterialData>             ChromeMaterialStructs_69;                                 // (Parm, OutParm, ZeroConstructor)
	TArray<struct FLacklusterOriginalMaterialData>     OriginalMaterialStructs_69;                               // (Parm, OutParm, ZeroConstructor)
};

// Function ChromeSharedRuntime.LacklusterFunctionLibrary.NativeFindSetParameterName
struct LacklusterFunctionLibrary_NativeFindSetParameterName_Params
{
	ELacklusterTextureGroup                            TextureGroup_69;                                          // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	struct FName                                       ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function ChromeSharedRuntime.LacklusterFunctionLibrary.NativeFindGetSetParameters
struct LacklusterFunctionLibrary_NativeFindGetSetParameters_Params
{
	bool                                               bIsMaskedMaterial_69;                                     // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bIsChonkers_69;                                           // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	ELacklusterActorType                               ActorType_69;                                             // (Parm, ZeroConstructor, IsPlainOldData)
	class MeshComponent*                               MeshComponent_69;                                         // (Parm, ZeroConstructor, InstancedReference)
	TArray<struct FLacklusterTextureSet>               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function ChromeSharedRuntime.LacklusterFunctionLibrary.NativeExecuteOwnerTypeFunctionality_PreChrome_Container
struct LacklusterFunctionLibrary_NativeExecuteOwnerTypeFunctionality_PreChrome_Container_Params
{
	class Actor_32759*                                 Actor_69;                                                 // (Parm, ZeroConstructor)
	struct FGameplayTagContainer                       ContainerTags_69;                                         // (ConstParm, Parm, OutParm, ReferenceParm)
	TMap<struct FName, float>                          ContainerMatScalarParamMap_69;                            // (Parm, OutParm, ReferenceParm)
	TMap<struct FName, struct FLinearColor>            ContainerMatVectorParamMap_69;                            // (Parm, OutParm, ReferenceParm)
};

// Function ChromeSharedRuntime.LacklusterFunctionLibrary.NativeExecuteOwnerTypeFunctionality_PreChrome
struct LacklusterFunctionLibrary_NativeExecuteOwnerTypeFunctionality_PreChrome_Params
{
	class Actor_32759*                                 Actor_69;                                                 // (Parm, ZeroConstructor)
	ELacklusterActorType                               ActorType_69;                                             // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	struct FGameplayTagContainer                       ContainerTags_69;                                         // (ConstParm, Parm, OutParm, ReferenceParm)
	TMap<struct FName, float>                          ContainerMatScalarParamMap_69;                            // (Parm, OutParm, ReferenceParm)
	TMap<struct FName, struct FLinearColor>            ContainerMatVectorParamMap_69;                            // (Parm, OutParm, ReferenceParm)
};

// Function ChromeSharedRuntime.LacklusterFunctionLibrary.NativeExecuteOwnerTypeFunctionality_PostChrome_Vehicle
struct LacklusterFunctionLibrary_NativeExecuteOwnerTypeFunctionality_PostChrome_Vehicle_Params
{
	class Actor_32759*                                 Actor_69;                                                 // (Parm, ZeroConstructor)
};

// Function ChromeSharedRuntime.LacklusterFunctionLibrary.NativeExecuteOwnerTypeFunctionality_PostChrome_Container
struct LacklusterFunctionLibrary_NativeExecuteOwnerTypeFunctionality_PostChrome_Container_Params
{
	class Actor_32759*                                 Actor_69;                                                 // (Parm, ZeroConstructor)
	struct FGameplayTagContainer                       ContainerTags_69;                                         // (ConstParm, Parm, OutParm, ReferenceParm)
	TMap<struct FName, float>                          ContainerMatScalarParamMap_69;                            // (ConstParm, Parm, OutParm, ReferenceParm)
	TMap<struct FName, struct FLinearColor>            ContainerMatVectorParamMap_69;                            // (ConstParm, Parm, OutParm, ReferenceParm)
};

// Function ChromeSharedRuntime.LacklusterFunctionLibrary.NativeExecuteOwnerTypeFunctionality_PostChrome
struct LacklusterFunctionLibrary_NativeExecuteOwnerTypeFunctionality_PostChrome_Params
{
	class Actor_32759*                                 Actor_69;                                                 // (Parm, ZeroConstructor)
	ELacklusterActorType                               ActorType_69;                                             // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	struct FGameplayTagContainer                       ContainerTags_69;                                         // (ConstParm, Parm, OutParm, ReferenceParm)
	TMap<struct FName, float>                          ContainerMatScalarParamMap_69;                            // (ConstParm, Parm, OutParm, ReferenceParm)
	TMap<struct FName, struct FLinearColor>            ContainerMatVectorParamMap_69;                            // (ConstParm, Parm, OutParm, ReferenceParm)
};

// Function ChromeSharedRuntime.LacklusterFunctionLibrary.NativeExcludeFromChroming
struct LacklusterFunctionLibrary_NativeExcludeFromChroming_Params
{
	class SceneComponent*                              Component_69;                                             // (ConstParm, Parm, ZeroConstructor, InstancedReference)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function ChromeSharedRuntime.LacklusterFunctionLibrary.NativeDoesActorSupportChromeSoundComponent
struct LacklusterFunctionLibrary_NativeDoesActorSupportChromeSoundComponent_Params
{
	class Actor_32759*                                 Actor_69;                                                 // (Parm, ZeroConstructor)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function ChromeSharedRuntime.LacklusterFunctionLibrary.NativeDisableShadowProxyWPO
struct LacklusterFunctionLibrary_NativeDisableShadowProxyWPO_Params
{
	class Actor_32759*                                 Actor_69;                                                 // (Parm, ZeroConstructor)
};

// Function ChromeSharedRuntime.LacklusterFunctionLibrary.NativeCastToSpecificClasses
struct LacklusterFunctionLibrary_NativeCastToSpecificClasses_Params
{
	class Actor_32759*                                 Actor_69;                                                 // (Parm, ZeroConstructor)
	ELacklusterChromeType                              ChromeTypeIn_69;                                          // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	ELacklusterChromeType                              ChromeTypeOut_69;                                         // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	ELacklusterActorType                               ActorTypeOut_69;                                          // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function ChromeSharedRuntime.LacklusterFunctionLibrary.NativeCastToParentClasses
struct LacklusterFunctionLibrary_NativeCastToParentClasses_Params
{
	class Actor_32759*                                 Actor_69;                                                 // (Parm, ZeroConstructor)
	ELacklusterActorType                               ActorTypeOut_69;                                          // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function ChromeSharedRuntime.LacklusterFunctionLibrary.NativeBindChromeEvents
struct LacklusterFunctionLibrary_NativeBindChromeEvents_Params
{
	class Actor_32759*                                 Actor_69;                                                 // (Parm, ZeroConstructor)
};

// Function ChromeSharedRuntime.LacklusterFunctionLibrary.NativeAreWeOverridingAudio
struct LacklusterFunctionLibrary_NativeAreWeOverridingAudio_Params
{
	class Actor_32759*                                 Actor_69;                                                 // (ConstParm, Parm, ZeroConstructor)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function ChromeSharedRuntime.LacklusterFunctionLibrary.NativeApplyChromeToActor
struct LacklusterFunctionLibrary_NativeApplyChromeToActor_Params
{
	class Actor_32759*                                 Actor_69;                                                 // (Parm, ZeroConstructor)
	ELacklusterActorType                               ActorType_69;                                             // (Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
	ELacklusterChromeType                              ChromeType_69;                                            // (Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
	TArray<struct FLacklusterMaterialData>             ChromeMaterialData_69;                                    // (Parm, OutParm, ZeroConstructor, ReferenceParm)
	TArray<struct FLacklusterOriginalMaterialData>     OriginalMaterialData_69;                                  // (Parm, OutParm, ZeroConstructor, ReferenceParm)
	TMap<struct FName, float>                          ContainerMatScalarParamMap_69;                            // (Parm, OutParm, ReferenceParm)
	TMap<struct FName, struct FLinearColor>            ContainerMatVectorParamMap_69;                            // (Parm, OutParm, ReferenceParm)
};

// Function ChromeSharedRuntime.LacklusterFunctionLibrary.NativeApplyChromeMaterial
struct LacklusterFunctionLibrary_NativeApplyChromeMaterial_Params
{
	class Actor_32759*                                 Actor_69;                                                 // (Parm, ZeroConstructor)
	TArray<struct FLacklusterMaterialData>             ChromeMaterialStructs_69;                                 // (Parm, OutParm, ZeroConstructor, ReferenceParm)
	TArray<struct FLacklusterOriginalMaterialData>     OriginalMaterialStructs_69;                               // (Parm, OutParm, ZeroConstructor, ReferenceParm)
	ELacklusterChromeType                              ChromeType_69;                                            // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	ELacklusterActorType                               OverrideActorType_69;                                     // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function ChromeSharedRuntime.LacklusterFunctionLibrary.NativeAddTextureData
struct LacklusterFunctionLibrary_NativeAddTextureData_Params
{
	ELacklusterActorType                               ActorType_69;                                             // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	class Actor_32759*                                 Actor_69;                                                 // (Parm, ZeroConstructor)
	TArray<struct FLacklusterMaterialData>             ChromeMaterialStructs_69;                                 // (Parm, OutParm, ZeroConstructor)
	TArray<struct FLacklusterOriginalMaterialData>     OriginalMaterialStructs_69;                               // (Parm, OutParm, ZeroConstructor)
	int                                                MaterialIndex_69;                                         // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	class MaterialInterface*                           Material_69;                                              // (Parm, ZeroConstructor)
	class MeshComponent*                               MeshComponent_69;                                         // (Parm, ZeroConstructor, InstancedReference)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

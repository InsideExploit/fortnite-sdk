#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Enums
//---------------------------------------------------------------------------

// Enum ButterCakeRuntime.EFortButterCakeFootPhase
enum class EFortButterCakeFootPhase : uint8_t
{
	RightPlantA                    = 0,
	RightPlantB                    = 1,
	RightPlantC                    = 2,
	LeftPlantA                     = 3,
	LeftPlantB                     = 4,
	LeftPlantC                     = 5,
	HostileRightPass               = 6,
	HostileRightPlant              = 7,
	HostileLeftPass                = 8,
	HostileLeftPlant               = 9,
	BothPlant                      = 10,
	BothPlantA                     = 11,
	BothPlantB                     = 12,
	BothPlantC                     = 13,
	BothPlantD                     = 14,
	EFortButterCakeFootPhase_MAX   = 15
};



//---------------------------------------------------------------------------
//Script Structs
//---------------------------------------------------------------------------

// ScriptStruct ButterCakeRuntime.RigUnit_ButterCakeBase
// 0x0000 (0x0008 - 0x0008)
struct FRigUnit_ButterCakeBase : public FRigUnit
{

};

// ScriptStruct ButterCakeRuntime.RigUnit_ButterCakeBaseMutable
// 0x0000 (0x0038 - 0x0038)
struct FRigUnit_ButterCakeBaseMutable : public FRigUnitMutable
{

};

// ScriptStruct ButterCakeRuntime.RigUnit_GetGroundHitAtIndex
// 0x0038 (0x0040 - 0x0008)
struct FRigUnit_GetGroundHitAtIndex : public FRigUnit_ButterCakeBase
{
	int                                                Index_69;                                                 // 0x0008(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x000C(0x0004) MISSED OFFSET
	struct FVector                                     Location_69;                                              // 0x0010(0x0018) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	struct FVector                                     Normal_69;                                                // 0x0028(0x0018) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct ButterCakeRuntime.RigUnit_BoneGroundTrace
// 0x0048 (0x0050 - 0x0008)
struct FRigUnit_BoneGroundTrace : public FRigUnit_ButterCakeBase
{
	struct FRigElementKey                              bone_69;                                                  // 0x0008(0x0008) (Edit, BlueprintVisible)
	float                                              Above_69;                                                 // 0x0010(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              Below_69;                                                 // 0x0014(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bHit_69;                                                  // 0x0018(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0019(0x0007) MISSED OFFSET
	struct FVector                                     HitLocation_69;                                           // 0x0020(0x0018) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	struct FVector                                     HitNormal_69;                                             // 0x0038(0x0018) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct ButterCakeRuntime.RigUnit_UpdateSomeGroundTraces
// 0x0000 (0x0038 - 0x0038)
struct FRigUnit_UpdateSomeGroundTraces : public FRigUnit_ButterCakeBaseMutable
{

};

// ScriptStruct ButterCakeRuntime.RigUnit_UpdateAllGroundTraces
// 0x0000 (0x0038 - 0x0038)
struct FRigUnit_UpdateAllGroundTraces : public FRigUnit_ButterCakeBaseMutable
{

};

// ScriptStruct ButterCakeRuntime.RigUnit_MoveFeetToGround
// 0x0020 (0x0058 - 0x0038)
struct FRigUnit_MoveFeetToGround : public FRigUnit_ButterCakeBaseMutable
{
	TArray<struct FCoreUObject_FTransform>             FootEffectorTransformList_69;                             // 0x0038(0x0010) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
	TArray<float>                                      FootEffectorStrengthAlphaList_69;                         // 0x0048(0x0010) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
};

// ScriptStruct ButterCakeRuntime.RigUnit_MoveTailOutOfGround
// 0x0068 (0x00A0 - 0x0038)
struct FRigUnit_MoveTailOutOfGround : public FRigUnit_ButterCakeBaseMutable
{
	bool                                               bShouldDoIK_69;                                           // 0x0038(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0039(0x0007) MISSED OFFSET
	struct FCoreUObject_FTransform                     TailTipEffectorTransform_69;                              // 0x0040(0x0060) (BlueprintVisible, BlueprintReadOnly, IsPlainOldData)
};

// ScriptStruct ButterCakeRuntime.RigUnit_MoveChinOutOfGround
// 0x0068 (0x00A0 - 0x0038)
struct FRigUnit_MoveChinOutOfGround : public FRigUnit_ButterCakeBaseMutable
{
	bool                                               bShouldDoIK_69;                                           // 0x0038(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0039(0x0007) MISSED OFFSET
	struct FCoreUObject_FTransform                     ChinEffectorTransform_69;                                 // 0x0040(0x0060) (BlueprintVisible, BlueprintReadOnly, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Classes
//---------------------------------------------------------------------------

// Class AnnualRefundTokenUI.FortAnnualRefundTicket
// 0x0008 (0x0270 - 0x0268)
class FortAnnualRefundTicket : public UserWidget
{
public:
	class CommonTextBlock*                             Text_AvailableDate_69;                                    // 0x0268(0x0008) (ExportObject, ZeroConstructor, InstancedReference)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AnnualRefundTokenUI.FortAnnualRefundTicket"));
		
		return ptr;
	}


	void OnUpdatePendingState(bool bIsPending_69);
	void OnUpdateAvailableState(bool bIsAvailable_69);
	void OnPlayLockingAnimation();
};


// Class AnnualRefundTokenUI.FortAnnualRefundTokenData
// 0x0028 (0x0548 - 0x0520)
class FortAnnualRefundTokenData : public FortGameFeatureData
{
public:
	unsigned char                                      UnknownData00[0x28];                                      // 0x0520(0x0028) UNKNOWN PROPERTY: SoftClassProperty AnnualRefundTokenUI.FortAnnualRefundTokenData.PurchaseHistoryScreenClass_69

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AnnualRefundTokenUI.FortAnnualRefundTokenData"));
		
		return ptr;
	}

};


// Class AnnualRefundTokenUI.FortPurchaseHistoryEntry
// 0x0030 (0x14B0 - 0x1480)
class FortPurchaseHistoryEntry : public FortHoldableButton
{
public:
	class FortCosmeticItemCard*                        ItemCardClass_69;                                         // 0x1480(0x0008) (Edit, ZeroConstructor)
	float                                              CardWidthOverride_69;                                     // 0x1488(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x148C(0x0004) MISSED OFFSET
	class CommonTextBlock*                             Text_Name_69;                                             // 0x1490(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	TArray<struct FString>                             LootEntryItemTypesToExclude_69;                           // 0x1498(0x0010) (ZeroConstructor, Config)
	unsigned char                                      UnknownData01[0x8];                                       // 0x14A8(0x0008) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AnnualRefundTokenUI.FortPurchaseHistoryEntry"));
		
		return ptr;
	}


	void UpdateItemList(TArray<class FortCosmeticItemCard*> ItemCards_69);
	void SetupItemCard(class FortCosmeticItemCard* ItemCard_69, class FortItem* Item_69);
	void SetPurchaseText(const struct FText& PurchaseDateText_69, const struct FText& RefundDateText_69, bool bHasBeenRefunded_69, EFortPurchaseHistoryRefundType RefundType_69);
	void OnSetHistory(bool bHasBeenRefunded_69, bool bIsTokenlessRefund_69, bool bPlayerHasTokens_69, bool bNonRefundable_69);
};


// Class AnnualRefundTokenUI.FortPurchaseHistoryListView
// 0x0110 (0x0370 - 0x0260)
class FortPurchaseHistoryListView : public ListViewBase
{
public:
	unsigned char                                      UnknownData00[0x110];                                     // 0x0260(0x0110) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AnnualRefundTokenUI.FortPurchaseHistoryListView"));
		
		return ptr;
	}

};


// Class AnnualRefundTokenUI.FortPurchaseHistoryScreen
// 0x00F8 (0x0610 - 0x0518)
class FortPurchaseHistoryScreen : public FortActivatablePanel
{
public:
	struct FDataTableRowHandle                         BackAction_69;                                            // 0x0518(0x0010) (Edit, DisableEditOnInstance)
	unsigned char                                      UnknownData00[0x18];                                      // 0x0528(0x0018) MISSED OFFSET
	unsigned char                                      UnknownData01[0x28];                                      // 0x0528(0x0028) UNKNOWN PROPERTY: SoftClassProperty AnnualRefundTokenUI.FortPurchaseHistoryScreen.RefundConfirmationClass_69
	unsigned char                                      UnknownData02[0x28];                                      // 0x0568(0x0028) UNKNOWN PROPERTY: SoftClassProperty AnnualRefundTokenUI.FortPurchaseHistoryScreen.DirectPurchaseInfoModalClass_69
	class CommonAnimatedSwitcher*                      Switcher_MainContent_69;                                  // 0x0590(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)
	class FortPurchaseHistoryListView*                 ListView_Purchases_69;                                    // 0x0598(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	class CommonButtonBase*                            Button_CloseMobile_69;                                    // 0x05A0(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	class CommonButtonBase*                            Button_PostApproval_69;                                   // 0x05A8(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	class CommonTextBlock*                             Text_Desc_69;                                             // 0x05B0(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	class CommonTextBlock*                             Text_RefundCount_69;                                      // 0x05B8(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	class CommonTextBlock*                             Text_ResultHeader_69;                                     // 0x05C0(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	class CommonTextBlock*                             Text_ResultTitle_69;                                      // 0x05C8(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	class CommonTextBlock*                             Text_ResultDesc_69;                                       // 0x05D0(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	class FortAnnualRefundTicket*                      RefundTicket_Left_69;                                     // 0x05D8(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	class FortAnnualRefundTicket*                      RefundTicket_Center_69;                                   // 0x05E0(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	class FortAnnualRefundTicket*                      RefundTicket_Right_69;                                    // 0x05E8(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	class Widget*                                      Widget_CancelPurchaseInfo_69;                             // 0x05F0(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	class Widget*                                      Widget_ReturnTicketInfo_69;                               // 0x05F8(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	class Widget*                                      Widget_TokenlessRefundInfo_69;                            // 0x0600(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	class Widget*                                      Widget_NonRefundableInfo_69;                              // 0x0608(0x0008) (ExportObject, ZeroConstructor, InstancedReference)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AnnualRefundTokenUI.FortPurchaseHistoryScreen"));
		
		return ptr;
	}


	void OnPopulateView();
	void OnNoPurchasesAvailable();
	void OnEndRefundSubmission();
	void OnBeginRefundSubmission();
	bool BP_IsShowingPurchases();
};


// Class AnnualRefundTokenUI.FortRefundConfirmation
// 0x0058 (0x0570 - 0x0518)
class FortRefundConfirmation : public FortActivatablePanel
{
public:
	unsigned char                                      UnknownData00[0x10];                                      // 0x0518(0x0010) MISSED OFFSET
	class CommonTextBlock*                             Text_RefundsRemaining_69;                                 // 0x0528(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	class CommonTextBlock*                             Text_RefundCount_69;                                      // 0x0530(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	class CommonTextBlock*                             Text_AreYouSure_69;                                       // 0x0538(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	class CommonButtonBase*                            Button_Yes_69;                                            // 0x0540(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	class CommonButtonBase*                            Button_No_69;                                             // 0x0548(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	class CommonButtonBase*                            Button_CloseMobile_69;                                    // 0x0550(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	class FortAnnualRefundTicket*                      RefundTicket_Left_69;                                     // 0x0558(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	class FortAnnualRefundTicket*                      RefundTicket_Center_69;                                   // 0x0560(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	class FortAnnualRefundTicket*                      RefundTicket_Right_69;                                    // 0x0568(0x0008) (ExportObject, ZeroConstructor, InstancedReference)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AnnualRefundTokenUI.FortRefundConfirmation"));
		
		return ptr;
	}


	void BP_UpdateRefundType(EFortPurchaseHistoryRefundType RefundType_69);
	void BP_UpdateItemsList(TArray<class FortItemDefinition*> SelectedItemDefs_69, int TotalMtxPaid_69);
};


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Enums
//---------------------------------------------------------------------------

// Enum CustomizableObject.ECustomizableObjectRelevancy
enum class ECustomizableObjectRelevancy : uint8_t
{
	All                            = 0,
	ClientOnly                     = 1,
	ECustomizableObjectRelevancy_MAX = 2
};


// Enum CustomizableObject.ECustomizableObjectCompilationState
enum class ECustomizableObjectCompilationState : uint8_t
{
	None                           = 0,
	InProgress                     = 1,
	Completed                      = 2,
	Failed                         = 3,
	ECustomizableObjectCompilationState_MAX = 4
};


// Enum CustomizableObject.EMutableParameterType
enum class EMutableParameterType : uint8_t
{
	None                           = 0,
	Bool                           = 1,
	Int                            = 2,
	Float                          = 3,
	Color                          = 4,
	Projector                      = 5,
	Texture                        = 6,
	EMutableParameterType_MAX      = 7
};


// Enum CustomizableObject.ECustomizableObjectGroupType
enum class ECustomizableObjectGroupType : uint8_t
{
	COGT_TOGGLE                    = 0,
	COGT_ALL                       = 1,
	COGT_ONE                       = 2,
	COGT_ONE_OR_NONE               = 3,
	COGT_MAX                       = 4
};


// Enum CustomizableObject.EMutableCompileMeshType
enum class EMutableCompileMeshType : uint8_t
{
	Full                           = 0,
	Local                          = 1,
	LocalAndChildren               = 2,
	AddWorkingSetNoChildren        = 3,
	AddWorkingSetAndChildren       = 4,
	EMutableCompileMeshType_MAX    = 5
};


// Enum CustomizableObject.ECustomizableObjectProjectorType
enum class ECustomizableObjectProjectorType : uint8_t
{
	Planar                         = 0,
	Cylindrical                    = 1,
	Wrapping                       = 2,
	ECustomizableObjectProjectorType_MAX = 3
};



//---------------------------------------------------------------------------
//Script Structs
//---------------------------------------------------------------------------

// ScriptStruct CustomizableObject.GeneratedTexture
// 0x0020
struct FGeneratedTexture
{
	int                                                ID_69;                                                    // 0x0000(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0004(0x0004) MISSED OFFSET
	struct FString                                     Name_69;                                                  // 0x0008(0x0010) (Edit, ZeroConstructor)
	class Texture2D*                                   Texture_69;                                               // 0x0018(0x0008) (Edit, ZeroConstructor)
};

// ScriptStruct CustomizableObject.GeneratedMaterial
// 0x0010
struct FGeneratedMaterial
{
	TArray<struct FGeneratedTexture>                   Textures_69;                                              // 0x0000(0x0010) (Edit, ZeroConstructor, EditConst)
};

// ScriptStruct CustomizableObject.ParameterDecorations
// 0x0010
struct FParameterDecorations
{
	TArray<class Texture2D*>                           Images_69;                                                // 0x0000(0x0010) (ZeroConstructor, Transient)
};

// ScriptStruct CustomizableObject.ReferencedSkeletons
// 0x0020
struct FReferencedSkeletons
{
	TArray<int>                                        SkeletonsToLoad_69;                                       // 0x0000(0x0010) (ZeroConstructor)
	TArray<class Skeleton*>                            SkeletonsToMerge_69;                                      // 0x0010(0x0010) (ZeroConstructor)
};

// ScriptStruct CustomizableObject.ReferencedPhysicsAssets
// 0x0020
struct FReferencedPhysicsAssets
{
	unsigned char                                      UnknownData00[0x10];                                      // 0x0000(0x0010) MISSED OFFSET
	TArray<class PhysicsAsset*>                        PhysicsAssetsToMerge_69;                                  // 0x0010(0x0010) (ZeroConstructor, Transient)
};

// ScriptStruct CustomizableObject.CustomizableInstanceComponentData
// 0x00B8
struct FCustomizableInstanceComponentData
{
	unsigned char                                      UnknownData00[0x8];                                       // 0x0000(0x0008) MISSED OFFSET
	unsigned char                                      UnknownData01[0x50];                                      // 0x0000(0x0050) UNKNOWN PROPERTY: MapProperty CustomizableObject.CustomizableInstanceComponentData.AnimSlotToBP_69
	struct FReferencedSkeletons                        Skeletons_69;                                             // 0x0058(0x0020) (Transient)
	struct FReferencedPhysicsAssets                    PhysicsAssets_69;                                         // 0x0078(0x0020) (Transient)
	unsigned char                                      UnknownData02[0x20];                                      // 0x0098(0x0020) MISSED OFFSET
};

// ScriptStruct CustomizableObject.MaskOutTexture
// 0x0018
struct FMaskOutTexture
{
	int                                                SizeX_69;                                                 // 0x0000(0x0004) (ZeroConstructor, IsPlainOldData)
	int                                                SizeY_69;                                                 // 0x0004(0x0004) (ZeroConstructor, IsPlainOldData)
	TArray<uint32_t>                                   Data_69;                                                  // 0x0008(0x0010) (ZeroConstructor)
};

// ScriptStruct CustomizableObject.MutableRefSkeletalMeshData
// 0x0100
struct FMutableRefSkeletalMeshData
{
	unsigned char                                      UnknownData00[0x60];                                      // 0x0000(0x0060) MISSED OFFSET
	unsigned char                                      UnknownData01[0x28];                                      // 0x0000(0x0028) UNKNOWN PROPERTY: SoftObjectProperty CustomizableObject.MutableRefSkeletalMeshData.Skeleton_69
	unsigned char                                      UnknownData02[0x28];                                      // 0x0088(0x0028) UNKNOWN PROPERTY: SoftObjectProperty CustomizableObject.MutableRefSkeletalMeshData.PhysicsAsset_69
	unsigned char                                      UnknownData03[0x28];                                      // 0x00B0(0x0028) UNKNOWN PROPERTY: SoftClassProperty CustomizableObject.MutableRefSkeletalMeshData.PostProcessAnimInst_69
	unsigned char                                      UnknownData04[0x28];                                      // 0x00D8(0x0028) UNKNOWN PROPERTY: SoftObjectProperty CustomizableObject.MutableRefSkeletalMeshData.ShadowPhysicsAsset_69
};

// ScriptStruct CustomizableObject.MutableLODSettings
// 0x0010
struct FMutableLODSettings
{
	int                                                NumLODsInRoot_69;                                         // 0x0000(0x0004) (ZeroConstructor, IsPlainOldData)
	int                                                FirstLODAvailable_69;                                     // 0x0004(0x0004) (ZeroConstructor, IsPlainOldData)
	bool                                               bLODStreamingEnabled_69;                                  // 0x0008(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0009(0x0003) MISSED OFFSET
	uint32_t                                           NumLODsToStream_69;                                       // 0x000C(0x0004) (ZeroConstructor, IsPlainOldData)
};

// ScriptStruct CustomizableObject.MutableModelImageProperties
// 0x0020
struct FMutableModelImageProperties
{
	struct FString                                     TextureParameterName_69;                                  // 0x0000(0x0010) (ZeroConstructor)
	TEnumAsByte<ETextureFilter>                        Filter_69;                                                // 0x0010(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0011(0x0003) MISSED OFFSET
	unsigned char                                      SRGB_69 : 1;                                              // 0x0014(0x0001)
	unsigned char                                      FlipGreenChannel_69 : 1;                                  // 0x0014(0x0001)
	unsigned char                                      UnknownData01[0x3];                                       // 0x0015(0x0003) MISSED OFFSET
	int                                                LODBias_69;                                               // 0x0018(0x0004) (ZeroConstructor, IsPlainOldData)
	TEnumAsByte<ETextureGroup>                         LODGroup_69;                                              // 0x001C(0x0001) (ZeroConstructor, IsPlainOldData)
	TEnumAsByte<ETextureAddress>                       AddressX_69;                                              // 0x001D(0x0001) (ZeroConstructor, IsPlainOldData)
	TEnumAsByte<ETextureAddress>                       AddressY_69;                                              // 0x001E(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData02[0x1];                                       // 0x001F(0x0001) MISSED OFFSET
};

// ScriptStruct CustomizableObject.MorphTargetInfo
// 0x0008
struct FMorphTargetInfo
{
	struct FName                                       Name_69;                                                  // 0x0000(0x0008) (ZeroConstructor, IsPlainOldData)
	int                                                LodNum_69;                                                // 0x0004(0x0004) (ZeroConstructor, IsPlainOldData)
};

// ScriptStruct CustomizableObject.MorphTargetVertexData
// 0x0020
struct FMorphTargetVertexData
{
	struct FVector3f                                   PositionDelta_69;                                         // 0x0000(0x000C) (ZeroConstructor, IsPlainOldData)
	struct FVector3f                                   TangentZDelta_69;                                         // 0x000C(0x000C) (ZeroConstructor, IsPlainOldData)
	int                                                MorphIndex_69;                                            // 0x0018(0x0004) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x001C(0x0004) MISSED OFFSET
};

// ScriptStruct CustomizableObject.CustomizableObjectClothConfigData
// 0x0028
struct FCustomizableObjectClothConfigData
{
	struct FString                                     ClassPath_69;                                             // 0x0000(0x0010) (ZeroConstructor)
	struct FName                                       ConfigName_69;                                            // 0x0010(0x0008) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0014(0x0004) MISSED OFFSET
	TArray<unsigned char>                              ConfigBytes_69;                                           // 0x0018(0x0010) (ZeroConstructor)
};

// ScriptStruct CustomizableObject.CustomizableObjectClothingAssetData
// 0x0080
struct FCustomizableObjectClothingAssetData
{
	TArray<struct FClothLODDataCommon>                 LodData_69;                                               // 0x0000(0x0010) (ZeroConstructor)
	TArray<int>                                        LodMap_69;                                                // 0x0010(0x0010) (ZeroConstructor)
	TArray<struct FName>                               UsedBoneNames_69;                                         // 0x0020(0x0010) (ZeroConstructor)
	TArray<int>                                        UsedBoneIndices_69;                                       // 0x0030(0x0010) (ZeroConstructor)
	int                                                ReferenceBoneIndex_69;                                    // 0x0040(0x0004) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0044(0x0004) MISSED OFFSET
	TArray<struct FCustomizableObjectClothConfigData>  ConfigsData_69;                                           // 0x0048(0x0010) (ZeroConstructor)
	struct FString                                     PhysicsAssetPath_69;                                      // 0x0058(0x0010) (ZeroConstructor)
	struct FName                                       Name_69;                                                  // 0x0068(0x0008) (ZeroConstructor, IsPlainOldData)
	struct FGuid                                       OriginalAssetGuid_69;                                     // 0x006C(0x0010) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x4];                                       // 0x007C(0x0004) MISSED OFFSET
};

// ScriptStruct CustomizableObject.CustomizableObjectMeshToMeshVertData
// 0x0040
struct FCustomizableObjectMeshToMeshVertData
{
	float                                              PositionBaryCoordsAndDist_69[0x4];                        // 0x0000(0x0004) (ZeroConstructor, IsPlainOldData)
	float                                              NormalBaryCoordsAndDist_69[0x4];                          // 0x0010(0x0004) (ZeroConstructor, IsPlainOldData)
	float                                              TangentBaryCoordsAndDist_69[0x4];                         // 0x0020(0x0004) (ZeroConstructor, IsPlainOldData)
	uint16_t                                           SourceMeshVertIndices_69[0x4];                            // 0x0030(0x0002) (ZeroConstructor, IsPlainOldData)
	float                                              Weight_69;                                                // 0x0038(0x0004) (ZeroConstructor, IsPlainOldData)
	int16_t                                            SourceAssetIndex_69;                                      // 0x003C(0x0002) (ZeroConstructor, IsPlainOldData)
	int16_t                                            SourceAssetLodIndex_69;                                   // 0x003E(0x0002) (ZeroConstructor, IsPlainOldData)
};

// ScriptStruct CustomizableObject.MutableModelParameterValue
// 0x0018
struct FMutableModelParameterValue
{
	struct FString                                     Name_69;                                                  // 0x0000(0x0010) (ZeroConstructor)
	int                                                Value_69;                                                 // 0x0010(0x0004) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0014(0x0004) MISSED OFFSET
};

// ScriptStruct CustomizableObject.MutableModelParameterProperties
// 0x0028
struct FMutableModelParameterProperties
{
	unsigned char                                      UnknownData00[0x10];                                      // 0x0000(0x0010) MISSED OFFSET
	EMutableParameterType                              Type_69;                                                  // 0x0010(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x3];                                       // 0x0011(0x0003) MISSED OFFSET
	int                                                ImageDescriptionCount_69;                                 // 0x0014(0x0004) (ZeroConstructor, IsPlainOldData)
	TArray<struct FMutableModelParameterValue>         PossibleValues_69;                                        // 0x0018(0x0010) (ZeroConstructor)
};

// ScriptStruct CustomizableObject.MutableParamUIMetadata
// 0x00F8
struct FMutableParamUIMetadata
{
	struct FString                                     ObjectFriendlyName_69;                                    // 0x0000(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     UISectionName_69;                                         // 0x0010(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	int                                                UIOrder_69;                                               // 0x0020(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0024(0x0004) MISSED OFFSET
	unsigned char                                      UnknownData01[0x28];                                      // 0x0024(0x0028) UNKNOWN PROPERTY: SoftObjectProperty CustomizableObject.MutableParamUIMetadata.UIThumbnail_69
	TMap<struct FString, struct FString>               ExtraInformation_69;                                      // 0x0050(0x0050) (Edit, BlueprintVisible)
	unsigned char                                      UnknownData02[0x50];                                      // 0x00A0(0x0050) UNKNOWN PROPERTY: MapProperty CustomizableObject.MutableParamUIMetadata.ExtraAssets_69
	float                                              MinimumValue_69;                                          // 0x00F0(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              MaximumValue_69;                                          // 0x00F4(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct CustomizableObject.IntegerParameterUIData
// 0x0108
struct FIntegerParameterUIData
{
	struct FString                                     Name_69;                                                  // 0x0000(0x0010) (BlueprintVisible, ZeroConstructor)
	struct FMutableParamUIMetadata                     ParamUIMetadata_69;                                       // 0x0010(0x00F8) (BlueprintVisible)
};

// ScriptStruct CustomizableObject.ParameterUIData
// 0x0178
struct FParameterUIData
{
	struct FString                                     Name_69;                                                  // 0x0000(0x0010) (BlueprintVisible, ZeroConstructor)
	struct FMutableParamUIMetadata                     ParamUIMetadata_69;                                       // 0x0010(0x00F8) (BlueprintVisible)
	EMutableParameterType                              Type_69;                                                  // 0x0108(0x0001) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0109(0x0007) MISSED OFFSET
	TArray<struct FIntegerParameterUIData>             ArrayIntegerParameterOption_69;                           // 0x0110(0x0010) (BlueprintVisible, ZeroConstructor)
	ECustomizableObjectGroupType                       IntegerParameterGroupType_69;                             // 0x0120(0x0001) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bDontCompressRuntimeTextures_69;                          // 0x0121(0x0001) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x6];                                       // 0x0122(0x0006) MISSED OFFSET
	TMap<struct FString, struct FString>               ForcedParameterValues_69;                                 // 0x0128(0x0050) (BlueprintVisible)
};

// ScriptStruct CustomizableObject.MutableStreamableBlock
// 0x0018
struct FMutableStreamableBlock
{
	uint16_t                                           FileIndex_69;                                             // 0x0000(0x0002) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x6];                                       // 0x0002(0x0006) MISSED OFFSET
	uint64_t                                           Offset_69;                                                // 0x0008(0x0008) (ZeroConstructor, IsPlainOldData)
	uint32_t                                           Size_69;                                                  // 0x0010(0x0004) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x4];                                       // 0x0014(0x0004) MISSED OFFSET
};

// ScriptStruct CustomizableObject.FParameterOptionsTags
// 0x0010
struct FFParameterOptionsTags
{
	TArray<struct FString>                             Tags_69;                                                  // 0x0000(0x0010) (Edit, ZeroConstructor)
};

// ScriptStruct CustomizableObject.ParameterTags
// 0x0060
struct FParameterTags
{
	TArray<struct FString>                             Tags_69;                                                  // 0x0000(0x0010) (Edit, ZeroConstructor)
	TMap<struct FString, struct FFParameterOptionsTags> ParameterOptions_69;                                      // 0x0010(0x0050) (Edit)
};

// ScriptStruct CustomizableObject.CustomizableObjectBoolParameterValue
// 0x0028
struct FCustomizableObjectBoolParameterValue
{
	struct FString                                     ParameterName_69;                                         // 0x0000(0x0010) (Edit, ZeroConstructor, EditConst)
	bool                                               ParameterValue_69;                                        // 0x0010(0x0001) (Edit, ZeroConstructor, EditConst, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0011(0x0007) MISSED OFFSET
	struct FString                                     UID_69;                                                   // 0x0018(0x0010) (Edit, ZeroConstructor, EditConst)
};

// ScriptStruct CustomizableObject.CustomizableObjectIntParameterValue
// 0x0040
struct FCustomizableObjectIntParameterValue
{
	struct FString                                     ParameterName_69;                                         // 0x0000(0x0010) (Edit, ZeroConstructor, EditConst)
	struct FString                                     ParameterValueName_69;                                    // 0x0010(0x0010) (Edit, ZeroConstructor, EditConst)
	struct FString                                     UID_69;                                                   // 0x0020(0x0010) (Edit, ZeroConstructor, EditConst)
	TArray<struct FString>                             ParameterRangeValueNames_69;                              // 0x0030(0x0010) (ZeroConstructor)
};

// ScriptStruct CustomizableObject.CustomizableObjectFloatParameterValue
// 0x0038
struct FCustomizableObjectFloatParameterValue
{
	struct FString                                     ParameterName_69;                                         // 0x0000(0x0010) (Edit, ZeroConstructor, EditConst)
	float                                              ParameterValue_69;                                        // 0x0010(0x0004) (Edit, ZeroConstructor, EditConst, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0014(0x0004) MISSED OFFSET
	struct FString                                     UID_69;                                                   // 0x0018(0x0010) (Edit, ZeroConstructor, EditConst)
	TArray<float>                                      ParameterRangeValues_69;                                  // 0x0028(0x0010) (Edit, ZeroConstructor, EditConst)
};

// ScriptStruct CustomizableObject.CustomizableObjectTextureParameterValue
// 0x0028
struct FCustomizableObjectTextureParameterValue
{
	struct FString                                     ParameterName_69;                                         // 0x0000(0x0010) (Edit, ZeroConstructor, EditConst)
	uint64_t                                           ParameterValue_69;                                        // 0x0010(0x0008) (Edit, ZeroConstructor, EditConst, IsPlainOldData)
	struct FString                                     UID_69;                                                   // 0x0018(0x0010) (Edit, ZeroConstructor, EditConst)
};

// ScriptStruct CustomizableObject.CustomizableObjectVectorParameterValue
// 0x0030
struct FCustomizableObjectVectorParameterValue
{
	struct FString                                     ParameterName_69;                                         // 0x0000(0x0010) (Edit, ZeroConstructor, EditConst)
	struct FLinearColor                                ParameterValue_69;                                        // 0x0010(0x0010) (Edit, ZeroConstructor, EditConst, IsPlainOldData)
	struct FString                                     UID_69;                                                   // 0x0020(0x0010) (Edit, ZeroConstructor, EditConst)
};

// ScriptStruct CustomizableObject.CustomizableObjectProjector
// 0x0038
struct FCustomizableObjectProjector
{
	struct FVector3f                                   Position_69;                                              // 0x0000(0x000C) (Edit, ZeroConstructor, IsPlainOldData)
	struct FVector3f                                   Direction_69;                                             // 0x000C(0x000C) (Edit, ZeroConstructor, IsPlainOldData)
	struct FVector3f                                   Up_69;                                                    // 0x0018(0x000C) (Edit, ZeroConstructor, IsPlainOldData)
	struct FVector3f                                   Scale_69;                                                 // 0x0024(0x000C) (Edit, ZeroConstructor, IsPlainOldData)
	ECustomizableObjectProjectorType                   ProjectionType_69;                                        // 0x0030(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0031(0x0003) MISSED OFFSET
	float                                              Angle_69;                                                 // 0x0034(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct CustomizableObject.CustomizableObjectProjectorParameterValue
// 0x0068
struct FCustomizableObjectProjectorParameterValue
{
	struct FString                                     ParameterName_69;                                         // 0x0000(0x0010) (Edit, ZeroConstructor, EditConst)
	struct FCustomizableObjectProjector                Value_69;                                                 // 0x0010(0x0038) (Edit, EditConst)
	struct FString                                     UID_69;                                                   // 0x0048(0x0010) (Edit, ZeroConstructor, EditConst)
	TArray<struct FCustomizableObjectProjector>        RangeValues_69;                                           // 0x0058(0x0010) (Edit, ZeroConstructor, EditConst)
};

// ScriptStruct CustomizableObject.CustomizableObjectInstanceDescriptor
// 0x00C0
struct FCustomizableObjectInstanceDescriptor
{
	class CustomizableObject*                          CustomizableObject_69;                                    // 0x0000(0x0008) (ZeroConstructor)
	TArray<struct FCustomizableObjectBoolParameterValue> BoolParameters_69;                                        // 0x0008(0x0010) (ZeroConstructor)
	TArray<struct FCustomizableObjectIntParameterValue> IntParameters_69;                                         // 0x0018(0x0010) (ZeroConstructor)
	TArray<struct FCustomizableObjectFloatParameterValue> FloatParameters_69;                                       // 0x0028(0x0010) (ZeroConstructor)
	TArray<struct FCustomizableObjectTextureParameterValue> TextureParameters_69;                                     // 0x0038(0x0010) (ZeroConstructor)
	TArray<struct FCustomizableObjectVectorParameterValue> VectorParameters_69;                                      // 0x0048(0x0010) (ZeroConstructor)
	TArray<struct FCustomizableObjectProjectorParameterValue> ProjectorParameters_69;                                   // 0x0058(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData00[0x58];                                      // 0x0068(0x0058) MISSED OFFSET
};

// ScriptStruct CustomizableObject.MultilayerProjectorLayer
// 0x0080
struct FMultilayerProjectorLayer
{
	unsigned char                                      UnknownData00[0x80];                                      // 0x0000(0x0080) MISSED OFFSET
};

// ScriptStruct CustomizableObject.MultilayerProjector
// 0x0100
struct FMultilayerProjector
{
	class CustomizableObjectInstance*                  Instance_69;                                              // 0x0000(0x0008) (ZeroConstructor)
	struct FName                                       ParamName_69;                                             // 0x0008(0x0008) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x000C(0x0004) MISSED OFFSET
	TMap<struct FName, int>                            VirtualLayersMapping_69;                                  // 0x0010(0x0050)
	TMap<struct FName, int>                            VirtualLayersOrder_69;                                    // 0x0060(0x0050)
	TMap<struct FName, struct FMultilayerProjectorLayer> DisableVirtualLayers_69;                                  // 0x00B0(0x0050)
};

// ScriptStruct CustomizableObject.MultilayerProjectorVirtualLayer
// 0x0008 (0x0088 - 0x0080)
struct FMultilayerProjectorVirtualLayer : public FMultilayerProjectorLayer
{
	unsigned char                                      UnknownData00[0x8];                                       // 0x0080(0x0008) MISSED OFFSET
};

// ScriptStruct CustomizableObject.PendingReleaseSkeletalMeshInfo
// 0x0010
struct FPendingReleaseSkeletalMeshInfo
{
	class SkeletalMesh*                                SkeletalMesh_69;                                          // 0x0000(0x0008) (ZeroConstructor)
	double                                             Timestamp_69;                                             // 0x0008(0x0008) (ZeroConstructor, IsPlainOldData)
};

// ScriptStruct CustomizableObject.ProfileParameterDat
// 0x0070
struct FProfileParameterDat
{
	struct FString                                     ProfileName_69;                                           // 0x0000(0x0010) (ZeroConstructor)
	TArray<struct FCustomizableObjectBoolParameterValue> BoolParameters_69;                                        // 0x0010(0x0010) (ZeroConstructor)
	TArray<struct FCustomizableObjectIntParameterValue> IntParameters_69;                                         // 0x0020(0x0010) (ZeroConstructor)
	TArray<struct FCustomizableObjectFloatParameterValue> FloatParameters_69;                                       // 0x0030(0x0010) (ZeroConstructor)
	TArray<struct FCustomizableObjectTextureParameterValue> TextureParameters_69;                                     // 0x0040(0x0010) (ZeroConstructor)
	TArray<struct FCustomizableObjectVectorParameterValue> VectorParameters_69;                                      // 0x0050(0x0010) (ZeroConstructor)
	TArray<struct FCustomizableObjectProjectorParameterValue> ProjectorParameters_69;                                   // 0x0060(0x0010) (ZeroConstructor)
};

// ScriptStruct CustomizableObject.CompilationOptions
// 0x0020
struct FCompilationOptions
{
	bool                                               bTextureCompression_69;                                   // 0x0000(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0001(0x0003) MISSED OFFSET
	int                                                OptimizationLevel_69;                                     // 0x0004(0x0004) (ZeroConstructor, IsPlainOldData)
	bool                                               bUseParallelCompilation_69;                               // 0x0008(0x0001) (ZeroConstructor, IsPlainOldData)
	bool                                               bUseDiskCompilation_69;                                   // 0x0009(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x16];                                      // 0x000A(0x0016) MISSED OFFSET
};

// ScriptStruct CustomizableObject.CustomizableObjectIdPair
// 0x0020
struct FCustomizableObjectIdPair
{
	struct FString                                     CustomizableObjectGroupName_69;                           // 0x0000(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance)
	struct FString                                     CustomizableObjectName_69;                                // 0x0010(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance)
};

// ScriptStruct CustomizableObject.CustomizableObjectIdentifier
// 0x0030
struct FCustomizableObjectIdentifier
{
	struct FString                                     CustomizableObjectGroupName_69;                           // 0x0000(0x0010) (ZeroConstructor)
	struct FString                                     CustomizableObjectName_69;                                // 0x0010(0x0010) (ZeroConstructor)
	struct FString                                     Guid_69;                                                  // 0x0020(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance)
};

// ScriptStruct CustomizableObject.CustomizedMaterialTexture2D
// 0x0010
struct FCustomizedMaterialTexture2D
{
	struct FName                                       Name_69;                                                  // 0x0000(0x0008) (Edit, ZeroConstructor, EditConst, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0004(0x0004) MISSED OFFSET
	class Texture2D*                                   Texture_69;                                               // 0x0008(0x0008) (Edit, ZeroConstructor)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Classes
//---------------------------------------------------------------------------

// VerseClass CompanionAI.$SolarisSignatureFunctionOuter
// 0x0000 (0x0028 - 0x0028)
class $SolarisSignatureFunctionOuter : public Object_32759
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("VerseClass CompanionAI.$SolarisSignatureFunctionOuter"));
		
		return ptr;
	}

};


// VerseClass CompanionAI.companion_ai
// 0x01F4 (0x02F4 - 0x0100)
class companion_ai : public ai_behavior
{
public:
	unsigned char                                      UnknownData00[0x8];                                       // 0x0100(0x0008) UNKNOWN PROPERTY: OptionProperty CompanionAI.companion_ai.__verse_0x9146CB8B_AIMovementInterface
	unsigned char                                      UnknownData01[0x8];                                       // 0x0108(0x0008) UNKNOWN PROPERTY: OptionProperty CompanionAI.companion_ai.__verse_0x4645AA12_PingActionsInterface
	unsigned char                                      UnknownData02[0x8];                                       // 0x0110(0x0008) UNKNOWN PROPERTY: OptionProperty CompanionAI.companion_ai.__verse_0xC37E44D5_AIActionsInterface
	unsigned char                                      UnknownData03[0x8];                                       // 0x0118(0x0008) UNKNOWN PROPERTY: OptionProperty CompanionAI.companion_ai.__verse_0xCC490D1F_WeaponActionsInterface
	unsigned char                                      UnknownData04[0x8];                                       // 0x0120(0x0008) UNKNOWN PROPERTY: OptionProperty CompanionAI.companion_ai.__verse_0x93DA469B_ThreatPerceptionInterface
	unsigned char                                      UnknownData05[0x8];                                       // 0x0128(0x0008) UNKNOWN PROPERTY: OptionProperty CompanionAI.companion_ai.__verse_0xC410E5F5_ObstaclePerceptionInterface
	unsigned char                                      UnknownData06[0x8];                                       // 0x0130(0x0008) UNKNOWN PROPERTY: OptionProperty CompanionAI.companion_ai.__verse_0x3F17BA42_HealthInterface
	class screen_log*                                  __verse_0xF524C2AC_Logger;                                // 0x0138(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	unsigned char                                      __verse_0x4222121E_DebugDisplay : 1;                      // 0x0140(0x0001) (InstancedReference)
	unsigned char                                      UnknownData07[0x7];                                       // 0x0141(0x0007) MISSED OFFSET
	double                                             __verse_0x5155C58D_GoToLeashDistance;                     // 0x0148(0x0008) (ZeroConstructor, InstancedReference, IsPlainOldData)
	double                                             __verse_0x4D92C49B_GoToAttackTargetDistance;              // 0x0150(0x0008) (ZeroConstructor, InstancedReference, IsPlainOldData)
	double                                             __verse_0x8D041DAB_HoldPositionLeashDistance;             // 0x0158(0x0008) (ZeroConstructor, InstancedReference, IsPlainOldData)
	double                                             __verse_0x5EF17E77_BackToMeMovementThreshold;             // 0x0160(0x0008) (ZeroConstructor, InstancedReference, IsPlainOldData)
	struct FScriptDelegate                             __verse_0xFD71F6F9_CrouchService;                         // 0x0168(0x0010) (ZeroConstructor, InstancedReference)
	struct FScriptDelegate                             __verse_0x42EEAE4C_CrouchUntilHit;                        // 0x0174(0x0010) (ZeroConstructor, InstancedReference)
	struct FScriptDelegate                             __verse_0x4611DC7E_DrawSphere_L_Nvector3_M_Nfloat_M_Ncolor_R;// 0x0180(0x0010) (ZeroConstructor, InstancedReference)
	struct FScriptDelegate                             __verse_0xAAC24BD9_GameLoop;                              // 0x018C(0x0010) (ZeroConstructor, InstancedReference)
	struct FScriptDelegate                             __verse_0x0C45B447_GetNewObstacle;                        // 0x0198(0x0010) (ZeroConstructor, InstancedReference)
	struct FScriptDelegate                             __verse_0x06CA25FE_GetNewTargetPerception_L_N_Qthreat__info_R;// 0x01A4(0x0010) (ZeroConstructor, InstancedReference)
	struct FScriptDelegate                             __verse_0x0CD61383_GetNewThreat;                          // 0x01B0(0x0010) (ZeroConstructor, InstancedReference)
	struct FScriptDelegate                             __verse_0x8CAF1B4F_GetObstacle;                           // 0x01BC(0x0010) (ZeroConstructor, InstancedReference)
	struct FScriptDelegate                             __verse_0x088B6B1E_GetThreat;                             // 0x01C8(0x0010) (ZeroConstructor, InstancedReference)
	struct FScriptDelegate                             __verse_0x56FDE9B1_GoToAndAttackTask_L_Nthreat__info_R;   // 0x01D4(0x0010) (ZeroConstructor, InstancedReference)
	struct FScriptDelegate                             __verse_0x37E9A1B8_GoToPositionTask_L_Nvector3_M_N_Qfort__character_M_Nlogic_M_Nnavigation__parameters_R;// 0x01E0(0x0010) (ZeroConstructor, InstancedReference)
	struct FScriptDelegate                             __verse_0xCDB7A2EB_HandleBackToMeCommand_L_Nping__info_R; // 0x01EC(0x0010) (ZeroConstructor, InstancedReference)
	struct FScriptDelegate                             __verse_0xA6BE52A1_HandleGoTo_L_Nping__info_R;            // 0x01F8(0x0010) (ZeroConstructor, InstancedReference)
	struct FScriptDelegate                             __verse_0xDA8C4382_HandleGoToCommand_L_Nping__info_R;     // 0x0204(0x0010) (ZeroConstructor, InstancedReference)
	struct FScriptDelegate                             __verse_0x732222FF_HandleHoldPositionCommand_L_Nping__info_R;// 0x0210(0x0010) (ZeroConstructor, InstancedReference)
	struct FScriptDelegate                             __verse_0x598CA1A6_HandleNPCCommand_L_Nping__info_R;      // 0x021C(0x0010) (ZeroConstructor, InstancedReference)
	struct FScriptDelegate                             __verse_0x6FDBE601_HandleObstacleTask_L_N_Qentity_R;      // 0x0228(0x0010) (ZeroConstructor, InstancedReference)
	struct FScriptDelegate                             __verse_0x76F49D7B_HandleReviveCommand_L_Nping__info_R;   // 0x0234(0x0010) (ZeroConstructor, InstancedReference)
	struct FScriptDelegate                             __verse_0x3ED65A6D__L_2fFortnite_2ecom_2fAI_2fCompanionAI_2fcompanion__ai_N_RLogAndDisplayOnScreen_L_N_Kchar_R;// 0x0240(0x0010) (ZeroConstructor, InstancedReference)
	struct FScriptDelegate                             __verse_0xB0983B50_LookAroundTask_L_Nvector3_M_Nfloat_M_Nfloat_R;// 0x024C(0x0010) (ZeroConstructor, InstancedReference)
	struct FScriptDelegate                             __verse_0x62AFAEFE_LookAtOrAttackTarget;                  // 0x0258(0x0010) (ZeroConstructor, InstancedReference)
	struct FScriptDelegate                             __verse_0x3F6E3D53_LookAtThreatTask;                      // 0x0264(0x0010) (ZeroConstructor, InstancedReference)
	struct FScriptDelegate                             __verse_0x77AE90F1__L_2fFortnite_2ecom_2fAI_2fCompanionAI_2fcompanion__ai_N_ROnConverted_L_Nany_R_Nvoid;// 0x0270(0x0010) (ZeroConstructor, InstancedReference)
	struct FScriptDelegate                             __verse_0x49F41DF3__L_2fFortnite_2ecom_2fAI_2fCompanionAI_2fcompanion__ai_N_ROnConverted;// 0x027C(0x0010) (ZeroConstructor, InstancedReference)
	struct FScriptDelegate                             __verse_0xC72BE77D__L_2fFortnite_2ecom_2fAI_2fCompanionAI_2fcompanion__ai_N_ROnUnconverted_L_Nany_R_Nvoid;// 0x0288(0x0010) (ZeroConstructor, InstancedReference)
	struct FScriptDelegate                             __verse_0x11CAF1E5__L_2fFortnite_2ecom_2fAI_2fCompanionAI_2fcompanion__ai_N_ROnUnconverted;// 0x0294(0x0010) (ZeroConstructor, InstancedReference)
	struct FScriptDelegate                             __verse_0xE121C3A4_ReviveCommand_L_Nfort__character_R;    // 0x02A0(0x0010) (ZeroConstructor, InstancedReference)
	struct FScriptDelegate                             __verse_0xD09E21A2_SetLeashPosition_L_Nvector3_M_Nfloat_M_Nentity_R;// 0x02AC(0x0010) (ZeroConstructor, InstancedReference)
	struct FScriptDelegate                             __verse_0xDBC1E5D6_ShootTargetService_L_Nfloat_R;         // 0x02B8(0x0010) (ZeroConstructor, InstancedReference)
	struct FScriptDelegate                             __verse_0xED5B1563_SprintService;                         // 0x02C4(0x0010) (ZeroConstructor, InstancedReference)
	struct FScriptDelegate                             __verse_0x10E1DFC8_TacticalSprintService;                 // 0x02D0(0x0010) (ZeroConstructor, InstancedReference)
	struct FScriptDelegate                             __verse_0x76BD3EE2_WaitForDamage;                         // 0x02DC(0x0010) (ZeroConstructor, InstancedReference)
	struct FScriptDelegate                             __verse_0xD52E5C4D_WaitForEntityMovement_L_Nentity_M_Nfloat_R;// 0x02E8(0x0010) (ZeroConstructor, InstancedReference)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("VerseClass CompanionAI.companion_ai"));
		
		return ptr;
	}


	class task_t_* WaitForEntityMovement_L_Nentity_M_Nfloat_R(class task_t_* __verse_0xC1E81372_CallingTask, int64_t __verse_0xA3A00DDB_CallerResumeState, int64_t __verse_0x2AC0E4D8_CallerCancelState, const struct Ftuple_Lentity_Mfloat_R& __verse_0xB2CDDD72_Argument);
	class task_t_* WaitForDamage(class task_t_* __verse_0xC1E81372_CallingTask, int64_t __verse_0xA3A00DDB_CallerResumeState, int64_t __verse_0x2AC0E4D8_CallerCancelState, const struct FCompanionAI_Ftuple_L_R& __verse_0xB2CDDD72_Argument);
	class task_t_* TacticalSprintService(class task_t_* __verse_0xC1E81372_CallingTask, int64_t __verse_0xA3A00DDB_CallerResumeState, int64_t __verse_0x2AC0E4D8_CallerCancelState, const struct FCompanionAI_Ftuple_L_R& __verse_0xB2CDDD72_Argument);
	class task_t_* SprintService(class task_t_* __verse_0xC1E81372_CallingTask, int64_t __verse_0xA3A00DDB_CallerResumeState, int64_t __verse_0x2AC0E4D8_CallerCancelState, const struct FCompanionAI_Ftuple_L_R& __verse_0xB2CDDD72_Argument);
	class task_t_* ShootTargetService_L_Nfloat_R(class task_t_* __verse_0xC1E81372_CallingTask, int64_t __verse_0xA3A00DDB_CallerResumeState, int64_t __verse_0x2AC0E4D8_CallerCancelState, double __verse_0xB2CDDD72_Argument);
	class task_t_* SetLeashPosition_L_Nvector3_M_Nfloat_M_Nentity_R(class task_t_* __verse_0xC1E81372_CallingTask, int64_t __verse_0xA3A00DDB_CallerResumeState, int64_t __verse_0x2AC0E4D8_CallerCancelState, const struct Ftuple_Lvector3_Mfloat_Mentity_R& __verse_0xB2CDDD72_Argument);
	class task_t_* ReviveCommand_L_Nfort__character_R(class task_t_* __verse_0xC1E81372_CallingTask, int64_t __verse_0xA3A00DDB_CallerResumeState, int64_t __verse_0x2AC0E4D8_CallerCancelState, class Object_32759* __verse_0xB2CDDD72_Argument);
	void _L_2fFortnite_2ecom_2fAI_2fCompanionAI_2fcompanion__ai_N_ROnUnconverted(const struct FCompanionAI_Ftuple_L_R& __verse_0xB2CDDD72_Argument);
	void _L_2fFortnite_2ecom_2fAI_2fCompanionAI_2fcompanion__ai_N_ROnUnconverted_L_Nany_R_Nvoid();
	void _L_2fFortnite_2ecom_2fAI_2fCompanionAI_2fcompanion__ai_N_ROnConverted(const struct FCompanionAI_Ftuple_L_R& __verse_0xB2CDDD72_Argument);
	void _L_2fFortnite_2ecom_2fAI_2fCompanionAI_2fcompanion__ai_N_ROnConverted_L_Nany_R_Nvoid();
	class task_t_* OnBegin(class task_t_* __verse_0xC1E81372_CallingTask, int64_t __verse_0xA3A00DDB_CallerResumeState, int64_t __verse_0x2AC0E4D8_CallerCancelState, const struct FCompanionAI_Ftuple_L_R& __verse_0xB2CDDD72_Argument);
	class task_t_* LookAtThreatTask(class task_t_* __verse_0xC1E81372_CallingTask, int64_t __verse_0xA3A00DDB_CallerResumeState, int64_t __verse_0x2AC0E4D8_CallerCancelState, const struct FCompanionAI_Ftuple_L_R& __verse_0xB2CDDD72_Argument);
	class task_t_* LookAtOrAttackTarget(class task_t_* __verse_0xC1E81372_CallingTask, int64_t __verse_0xA3A00DDB_CallerResumeState, int64_t __verse_0x2AC0E4D8_CallerCancelState, const struct FCompanionAI_Ftuple_L_R& __verse_0xB2CDDD72_Argument);
	class task_t_* LookAroundTask_L_Nvector3_M_Nfloat_M_Nfloat_R(class task_t_* __verse_0xC1E81372_CallingTask, int64_t __verse_0xA3A00DDB_CallerResumeState, int64_t __verse_0x2AC0E4D8_CallerCancelState, const struct FCompanionAI_Ftuple_Lvector3_Mfloat_Mfloat_R& __verse_0xB2CDDD72_Argument);
	void _L_2fFortnite_2ecom_2fAI_2fCompanionAI_2fcompanion__ai_N_RLogAndDisplayOnScreen_L_N_Kchar_R();
	class task_t_* HandleReviveCommand_L_Nping__info_R(class task_t_* __verse_0xC1E81372_CallingTask, int64_t __verse_0xA3A00DDB_CallerResumeState, int64_t __verse_0x2AC0E4D8_CallerCancelState, const struct Fping_info& __verse_0xB2CDDD72_Argument);
	class task_t_* HandleObstacleTask_L_N_Qentity_R(class task_t_* __verse_0xC1E81372_CallingTask, int64_t __verse_0xA3A00DDB_CallerResumeState, int64_t __verse_0x2AC0E4D8_CallerCancelState);
	class task_t_* HandleNPCCommand_L_Nping__info_R(class task_t_* __verse_0xC1E81372_CallingTask, int64_t __verse_0xA3A00DDB_CallerResumeState, int64_t __verse_0x2AC0E4D8_CallerCancelState, const struct Fping_info& __verse_0xB2CDDD72_Argument);
	class task_t_* HandleHoldPositionCommand_L_Nping__info_R(class task_t_* __verse_0xC1E81372_CallingTask, int64_t __verse_0xA3A00DDB_CallerResumeState, int64_t __verse_0x2AC0E4D8_CallerCancelState, const struct Fping_info& __verse_0xB2CDDD72_Argument);
	class task_t_* HandleGoToCommand_L_Nping__info_R(class task_t_* __verse_0xC1E81372_CallingTask, int64_t __verse_0xA3A00DDB_CallerResumeState, int64_t __verse_0x2AC0E4D8_CallerCancelState, const struct Fping_info& __verse_0xB2CDDD72_Argument);
	class task_t_* HandleGoTo_L_Nping__info_R(class task_t_* __verse_0xC1E81372_CallingTask, int64_t __verse_0xA3A00DDB_CallerResumeState, int64_t __verse_0x2AC0E4D8_CallerCancelState, const struct Fping_info& __verse_0xB2CDDD72_Argument);
	class task_t_* HandleBackToMeCommand_L_Nping__info_R(class task_t_* __verse_0xC1E81372_CallingTask, int64_t __verse_0xA3A00DDB_CallerResumeState, int64_t __verse_0x2AC0E4D8_CallerCancelState, const struct Fping_info& __verse_0xB2CDDD72_Argument);
	class task_t_* GoToPositionTask_L_Nvector3_M_N_Qfort__character_M_Nlogic_M_Nnavigation__parameters_R(class task_t_* __verse_0xC1E81372_CallingTask, int64_t __verse_0xA3A00DDB_CallerResumeState, int64_t __verse_0x2AC0E4D8_CallerCancelState, const struct Ftuple_Lvector3_M_Qfort__character_Mlogic_M_QNavigationParameters_Nnavigation__parameters_20_3d_20_2e_2e_2e_R& __verse_0xB2CDDD72_Argument);
	class task_t_* GoToAndAttackTask_L_Nthreat__info_R(class task_t_* __verse_0xC1E81372_CallingTask, int64_t __verse_0xA3A00DDB_CallerResumeState, int64_t __verse_0x2AC0E4D8_CallerCancelState, const struct Fthreat_info& __verse_0xB2CDDD72_Argument);
	class task_t_* GetThreat(class task_t_* __verse_0xC1E81372_CallingTask, int64_t __verse_0xA3A00DDB_CallerResumeState, int64_t __verse_0x2AC0E4D8_CallerCancelState, const struct FCompanionAI_Ftuple_L_R& __verse_0xB2CDDD72_Argument);
	class task_t_* GetObstacle(class task_t_* __verse_0xC1E81372_CallingTask, int64_t __verse_0xA3A00DDB_CallerResumeState, int64_t __verse_0x2AC0E4D8_CallerCancelState, const struct FCompanionAI_Ftuple_L_R& __verse_0xB2CDDD72_Argument);
	class task_t_* GetNewThreat(class task_t_* __verse_0xC1E81372_CallingTask, int64_t __verse_0xA3A00DDB_CallerResumeState, int64_t __verse_0x2AC0E4D8_CallerCancelState, const struct FCompanionAI_Ftuple_L_R& __verse_0xB2CDDD72_Argument);
	class task_t_* GetNewTargetPerception_L_N_Qthreat__info_R(class task_t_* __verse_0xC1E81372_CallingTask, int64_t __verse_0xA3A00DDB_CallerResumeState, int64_t __verse_0x2AC0E4D8_CallerCancelState);
	class task_t_* GetNewObstacle(class task_t_* __verse_0xC1E81372_CallingTask, int64_t __verse_0xA3A00DDB_CallerResumeState, int64_t __verse_0x2AC0E4D8_CallerCancelState, const struct FCompanionAI_Ftuple_L_R& __verse_0xB2CDDD72_Argument);
	class task_t_* GameLoop(class task_t_* __verse_0xC1E81372_CallingTask, int64_t __verse_0xA3A00DDB_CallerResumeState, int64_t __verse_0x2AC0E4D8_CallerCancelState, const struct FCompanionAI_Ftuple_L_R& __verse_0xB2CDDD72_Argument);
	class task_t_* DrawSphere_L_Nvector3_M_Nfloat_M_Ncolor_R(class task_t_* __verse_0xC1E81372_CallingTask, int64_t __verse_0xA3A00DDB_CallerResumeState, int64_t __verse_0x2AC0E4D8_CallerCancelState, const struct Ftuple_Lvector3_Mfloat_Mcolor_R& __verse_0xB2CDDD72_Argument);
	class task_t_* CrouchUntilHit(class task_t_* __verse_0xC1E81372_CallingTask, int64_t __verse_0xA3A00DDB_CallerResumeState, int64_t __verse_0x2AC0E4D8_CallerCancelState, const struct FCompanionAI_Ftuple_L_R& __verse_0xB2CDDD72_Argument);
	class task_t_* CrouchService(class task_t_* __verse_0xC1E81372_CallingTask, int64_t __verse_0xA3A00DDB_CallerResumeState, int64_t __verse_0x2AC0E4D8_CallerCancelState, const struct FCompanionAI_Ftuple_L_R& __verse_0xB2CDDD72_Argument);
	void $InitInstance();
	void $Block();
	void $InitCDO();
};


// VerseClass CompanionAI.CompanionAI
// 0x0000 (0x0028 - 0x0028)
class CompanionAI : public Object_32759
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("VerseClass CompanionAI.CompanionAI"));
		
		return ptr;
	}


	void STATIC__L_2fFortnite_2ecom_2fAI_2fCompanionAI_N_RToString_L_Ncommand__type_R(Ecommand_type __verse_0xB2CDDD72_Argument);
	void STATIC__L_2fFortnite_2ecom_2fAI_2fCompanionAI_N_RToString_L_Nentity__type_R(Eentity_type __verse_0xB2CDDD72_Argument);
	void STATIC__L_2fFortnite_2ecom_2fAI_2fCompanionAI_N_RGetFortCharacter_L_Nentity_R(class Entity* __verse_0xB2CDDD72_Argument);
	bool STATIC__L_2fFortnite_2ecom_2fAI_2fCompanionAI_N_RCompare_L_Nobstacle__info_M_Nentity_R(const struct Ftuple_Lobstacle__info_Mentity_R& __verse_0xB2CDDD72_Argument);
	struct Fping_info STATIC_ping_info$Factory();
	void $InitCDO();
};


// VerseClass CompanionAI.fort_br_ai_actions_interface
// 0x0000 (0x0028 - 0x0028)
class fort_br_ai_actions_interface : public Object_32759
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("VerseClass CompanionAI.fort_br_ai_actions_interface"));
		
		return ptr;
	}


	class task_t_* RunDefaultBehavior(class task_t_* __verse_0xC1E81372_CallingTask, int64_t __verse_0xA3A00DDB_CallerResumeState, int64_t __verse_0x2AC0E4D8_CallerCancelState, const struct FCompanionAI_Ftuple_L_R& __verse_0xB2CDDD72_Argument);
};


// VerseClass CompanionAI.fort_br_ai_movement_interface
// 0x0000 (0x0028 - 0x0028)
class fort_br_ai_movement_interface : public Object_32759
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("VerseClass CompanionAI.fort_br_ai_movement_interface"));
		
		return ptr;
	}


	void _L_2fFortnite_2ecom_2fAI_2fCompanionAI_2ffort__br__ai__movement__interface_N_RSetLeashActor_L_Nentity_R(class Entity* __verse_0xB2CDDD72_Argument);
};


// VerseClass CompanionAI.fort_npc_component
// 0x0018 (0x02B0 - 0x0298)
class fort_npc_component : public npc_component
{
public:
	struct FScriptDelegate                             __verse_0xECDDAB04_RunDefaultBehavior;                    // 0x0298(0x0010) (ZeroConstructor, InstancedReference)
	struct FScriptDelegate                             __verse_0x711BBCAD__L_2fFortnite_2ecom_2fAI_2fCompanionAI_2ffort__br__ai__movement__interface_N_RSetLeashActor_L_Nentity_R;// 0x02A4(0x0010) (ZeroConstructor, InstancedReference)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("VerseClass CompanionAI.fort_npc_component"));
		
		return ptr;
	}


	void _L_2fFortnite_2ecom_2fAI_2fCompanionAI_2ffort__br__ai__movement__interface_N_RSetLeashActor_L_Nentity_R(class Entity* __verse_0xB2CDDD72_Argument);
	class task_t_* RunDefaultBehavior(class task_t_* __verse_0xC1E81372_CallingTask, int64_t __verse_0xA3A00DDB_CallerResumeState, int64_t __verse_0x2AC0E4D8_CallerCancelState, const struct FCompanionAI_Ftuple_L_R& __verse_0xB2CDDD72_Argument);
	void $InitInstance();
	void $Block();
	void $InitCDO();
};


// VerseClass CompanionAI.fort_ping_interface
// 0x0000 (0x0028 - 0x0028)
class fort_ping_interface : public Object_32759
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("VerseClass CompanionAI.fort_ping_interface"));
		
		return ptr;
	}


	class Object_32759* _L_2fFortnite_2ecom_2fAI_2fCompanionAI_2ffort__ping__interface_N_RUnconvertedEvent(const struct FCompanionAI_Ftuple_L_R& __verse_0xB2CDDD72_Argument);
	class task_t_* OnNPCCommand(class task_t_* __verse_0xC1E81372_CallingTask, int64_t __verse_0xA3A00DDB_CallerResumeState, int64_t __verse_0x2AC0E4D8_CallerCancelState, const struct FCompanionAI_Ftuple_L_R& __verse_0xB2CDDD72_Argument);
	void _L_2fFortnite_2ecom_2fAI_2fCompanionAI_2ffort__ping__interface_N_RGetCurrentNPCCommand(const struct FCompanionAI_Ftuple_L_R& __verse_0xB2CDDD72_Argument);
	void _L_2fFortnite_2ecom_2fAI_2fCompanionAI_2ffort__ping__interface_N_REnableCommandWheel_L_Nlogic_R(bool __verse_0xB2CDDD72_Argument);
	void _L_2fFortnite_2ecom_2fAI_2fCompanionAI_2ffort__ping__interface_N_RDeclineNPCCommand_L_Nlogic_R(bool __verse_0xB2CDDD72_Argument);
	class Object_32759* _L_2fFortnite_2ecom_2fAI_2fCompanionAI_2ffort__ping__interface_N_RConvertedEvent(const struct FCompanionAI_Ftuple_L_R& __verse_0xB2CDDD72_Argument);
	bool _L_2fFortnite_2ecom_2fAI_2fCompanionAI_2ffort__ping__interface_N_RAreNPCCommandsEnabled(const struct FCompanionAI_Ftuple_L_R& __verse_0xB2CDDD72_Argument);
};


// VerseClass CompanionAI.log_companion_ai
// 0x0000 (0x0028 - 0x0028)
class log_companion_ai : public log_channel
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("VerseClass CompanionAI.log_companion_ai"));
		
		return ptr;
	}


	void $InitInstance();
	void $Block();
	void $InitCDO();
};


// VerseClass CompanionAI.ping_component
// 0x0068 (0x0100 - 0x0098)
class ping_component : public PingComponentBase
{
public:
	unsigned char                                      UnknownData00[0x58];                                      // 0x0098(0x0058) MISSED OFFSET
	class multicast_delegate_t_*                       __verse_0xC18257FD_ConvertedEventInternal;                // 0x00F0(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	class multicast_delegate_t_*                       __verse_0x0E297686_UnconvertedEventInternal;              // 0x00F8(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	struct FScriptDelegate                             __verse_0x4A0C11E4__L_2fFortnite_2ecom_2fAI_2fCompanionAI_2ffort__ping__interface_N_RAreNPCCommandsEnabled;// 0x0098(0x0010) (ZeroConstructor, InstancedReference)
	unsigned char                                      UnknownData01[0x30];                                      // 0x00A4(0x0030) MISSED OFFSET
	struct FScriptDelegate                             __verse_0xC34E89EF__L_2fFortnite_2ecom_2fAI_2fCompanionAI_2ffort__ping__interface_N_RConvertedEvent;// 0x00D4(0x0010) (ZeroConstructor, InstancedReference)
	struct FScriptDelegate                             __verse_0xA8918968__L_2fFortnite_2ecom_2fAI_2fCompanionAI_2ffort__ping__interface_N_RDeclineNPCCommand_L_Nlogic_R;// 0x00C8(0x0010) (ZeroConstructor, InstancedReference)
	struct FScriptDelegate                             __verse_0xFCB4C0C9__L_2fFortnite_2ecom_2fAI_2fCompanionAI_2ffort__ping__interface_N_REnableCommandWheel_L_Nlogic_R;// 0x00A4(0x0010) (ZeroConstructor, InstancedReference)
	struct FScriptDelegate                             __verse_0xD6588DA4__L_2fFortnite_2ecom_2fAI_2fCompanionAI_2ffort__ping__interface_N_RGetCurrentNPCCommand;// 0x00B0(0x0010) (ZeroConstructor, InstancedReference)
	struct FScriptDelegate                             __verse_0x68114BBA_OnNPCCommand;                          // 0x00BC(0x0010) (ZeroConstructor, InstancedReference)
	unsigned char                                      UnknownData02[0x18];                                      // 0x00C8(0x0018) MISSED OFFSET
	struct FScriptDelegate                             __verse_0x19DD9F60__L_2fFortnite_2ecom_2fAI_2fCompanionAI_2ffort__ping__interface_N_RUnconvertedEvent;// 0x00E0(0x0010) (ZeroConstructor, InstancedReference)
	unsigned char                                      UnknownData03[0x14];                                      // 0x00EC(0x0014) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("VerseClass CompanionAI.ping_component"));
		
		return ptr;
	}


	class Object_32759* _L_2fFortnite_2ecom_2fAI_2fCompanionAI_2ffort__ping__interface_N_RUnconvertedEvent(const struct FCompanionAI_Ftuple_L_R& __verse_0xB2CDDD72_Argument);
	class task_t_* OnNPCCommand(class task_t_* __verse_0xC1E81372_CallingTask, int64_t __verse_0xA3A00DDB_CallerResumeState, int64_t __verse_0x2AC0E4D8_CallerCancelState, const struct FCompanionAI_Ftuple_L_R& __verse_0xB2CDDD72_Argument);
	void _L_2fFortnite_2ecom_2fAI_2fCompanionAI_2ffort__ping__interface_N_RGetCurrentNPCCommand(const struct FCompanionAI_Ftuple_L_R& __verse_0xB2CDDD72_Argument);
	void _L_2fFortnite_2ecom_2fAI_2fCompanionAI_2ffort__ping__interface_N_REnableCommandWheel_L_Nlogic_R(bool __verse_0xB2CDDD72_Argument);
	void _L_2fFortnite_2ecom_2fAI_2fCompanionAI_2ffort__ping__interface_N_RDeclineNPCCommand_L_Nlogic_R(bool __verse_0xB2CDDD72_Argument);
	class Object_32759* _L_2fFortnite_2ecom_2fAI_2fCompanionAI_2ffort__ping__interface_N_RConvertedEvent(const struct FCompanionAI_Ftuple_L_R& __verse_0xB2CDDD72_Argument);
	bool _L_2fFortnite_2ecom_2fAI_2fCompanionAI_2ffort__ping__interface_N_RAreNPCCommandsEnabled(const struct FCompanionAI_Ftuple_L_R& __verse_0xB2CDDD72_Argument);
	void $InitInstance();
	void $Block();
	void $InitCDO();
};


// VerseClass CompanionAI.task_companion_ai$CrouchService
// 0x0064 (0x0184 - 0x0120)
class task_companion_ai$CrouchService : public task_t_
{
public:
	class companion_ai*                                _Self;                                                    // 0x0120(0x0008) (Parm, ZeroConstructor)
	struct FCompanionAI_Ftuple_L_R                     __verse_0xB2CDDD72_Argument;                              // 0x0128(0x0001) (Parm)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0129(0x0007) MISSED OFFSET
	class Object_32759*                                __verse_0xCA7BB203_AIMovement_1;                          // 0x0130(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	unsigned char                                      UnknownData01[0x8];                                       // 0x0138(0x0008) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$CrouchService.$ExprResultStack_0
	class task_t_*                                     $AsyncTask_1;                                             // 0x0140(0x0008) (ZeroConstructor)
	struct FScriptDelegate                             $AsyncTaskClass_2;                                        // 0x0148(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData02[0x4];                                       // 0x0154(0x0004) MISSED OFFSET
	int64_t                                            $AsyncResult_3;                                           // 0x0158(0x0008) (ZeroConstructor, IsPlainOldData)
	class Object_32759*                                __verse_0x00000000__3;                                    // 0x0160(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	struct FScriptDelegate                             $AsyncTaskClass_4;                                        // 0x0168(0x0010) (ZeroConstructor)
	struct FCompanionAI_Ftuple_L_R                     $ExprResult_5;                                            // 0x0174(0x0001)
	unsigned char                                      UnknownData03[0x3];                                       // 0x0175(0x0003) MISSED OFFSET
	struct FScriptDelegate                             $AsyncTaskClass_6;                                        // 0x0178(0x0010) (ZeroConstructor)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("VerseClass CompanionAI.task_companion_ai$CrouchService"));
		
		return ptr;
	}


	int64_t Update();
};


// VerseClass CompanionAI.task_companion_ai$CrouchUntilHit
// 0x00B0 (0x01D0 - 0x0120)
class task_companion_ai$CrouchUntilHit : public task_t_
{
public:
	class companion_ai*                                _Self;                                                    // 0x0120(0x0008) (Parm, ZeroConstructor)
	struct FCompanionAI_Ftuple_L_R                     __verse_0xB2CDDD72_Argument;                              // 0x0128(0x0001) (Parm)
	EVerseTrue                                         $InvokeSureResultDummy_0;                                 // 0x0129(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x2];                                       // 0x012A(0x0002) MISSED OFFSET
	struct FScriptDelegate                             $Callee_1;                                                // 0x012C(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData01[0x10];                                      // 0x0138(0x0010) UNKNOWN PROPERTY: VerseStringProperty CompanionAI.task_companion_ai$CrouchUntilHit.$ExprResult_2
	int64_t                                            $AsyncBeginCount_3;                                       // 0x0148(0x0008) (ZeroConstructor, IsPlainOldData)
	class task_t_*                                     $AsyncTask_4;                                             // 0x0150(0x0008) (ZeroConstructor)
	struct FScriptDelegate                             $AsyncTaskClass_5;                                        // 0x0158(0x0010) (ZeroConstructor)
	struct FCompanionAI_Ftuple_L_R                     $ExprResult_6;                                            // 0x0164(0x0001)
	unsigned char                                      UnknownData02[0x3];                                       // 0x0165(0x0003) MISSED OFFSET
	int64_t                                            $AsyncResult_7;                                           // 0x0168(0x0008) (ZeroConstructor, IsPlainOldData)
	class task_t_*                                     $AsyncTask_8;                                             // 0x0170(0x0008) (ZeroConstructor)
	struct FScriptDelegate                             $AsyncTaskClass_9;                                        // 0x0178(0x0010) (ZeroConstructor)
	struct FCompanionAI_Ftuple_L_R                     $ExprResult_10;                                           // 0x0184(0x0001)
	unsigned char                                      UnknownData03[0x3];                                       // 0x0185(0x0003) MISSED OFFSET
	int64_t                                            $AsyncResult_11;                                          // 0x0188(0x0008) (ZeroConstructor, IsPlainOldData)
	class task_t_*                                     $AsyncTask_12;                                            // 0x0190(0x0008) (ZeroConstructor)
	struct FScriptDelegate                             $AsyncTaskClass_13;                                       // 0x0198(0x0010) (ZeroConstructor)
	struct FCompanionAI_Ftuple_L_R                     $ExprResult_14;                                           // 0x01A4(0x0001)
	unsigned char                                      UnknownData04[0x3];                                       // 0x01A5(0x0003) MISSED OFFSET
	int64_t                                            $AsyncResult_15;                                          // 0x01A8(0x0008) (ZeroConstructor, IsPlainOldData)
	EVerseTrue                                         $InvokeSureResultDummy_16;                                // 0x01B0(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData05[0x3];                                       // 0x01B1(0x0003) MISSED OFFSET
	struct FScriptDelegate                             $Callee_17;                                               // 0x01B4(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData06[0x10];                                      // 0x01C0(0x0010) UNKNOWN PROPERTY: VerseStringProperty CompanionAI.task_companion_ai$CrouchUntilHit.$ExprResult_18

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("VerseClass CompanionAI.task_companion_ai$CrouchUntilHit"));
		
		return ptr;
	}


	int64_t Update();
};


// VerseClass CompanionAI.task_companion_ai$DrawSphere_L_Nvector3_M_Nfloat_M_Ncolor_R
// 0x0181 (0x02A1 - 0x0120)
class task_companion_ai$DrawSphere_L_Nvector3_M_Nfloat_M_Ncolor_R : public task_t_
{
public:
	class companion_ai*                                _Self;                                                    // 0x0120(0x0008) (Parm, ZeroConstructor)
	struct Ftuple_Lvector3_Mfloat_Mcolor_R             __verse_0xB2CDDD72_Argument;                              // 0x0128(0x0038) (Parm)
	unsigned char                                      UnknownData00[0x2];                                       // 0x0160(0x0002) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$DrawSphere_L_Nvector3_M_Nfloat_M_Ncolor_R.$ExprResultStack_0
	EVerseTrue                                         $InvokeSureResultDummy_1;                                 // 0x0162(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x1];                                       // 0x0163(0x0001) MISSED OFFSET
	struct FScriptDelegate                             $Callee_2;                                                // 0x0164(0x0010) (ZeroConstructor)
	struct Ftuple_Lvector3_M_QParams_Nsphere__draw__params_R $ExprResult_3;                                            // 0x0170(0x0068)
	unsigned char                                      UnknownData02[0x49];                                      // 0x01D8(0x0049) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$DrawSphere_L_Nvector3_M_Nfloat_M_Ncolor_R.$ExprResult_4
	unsigned char                                      UnknownData03[0x7];                                       // 0x0221(0x0007) MISSED OFFSET
	struct Fsphere_draw_params                         $ExprResult_5;                                            // 0x0228(0x0048)
	class task_t_*                                     $AsyncTask_6;                                             // 0x0270(0x0008) (ZeroConstructor)
	struct FScriptDelegate                             $AsyncTaskClass_7;                                        // 0x0278(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData04[0x4];                                       // 0x0284(0x0004) MISSED OFFSET
	int64_t                                            $AsyncResult_8;                                           // 0x0288(0x0008) (ZeroConstructor, IsPlainOldData)
	EVerseTrue                                         $InvokeSureResultDummy_9;                                 // 0x0290(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData05[0x3];                                       // 0x0291(0x0003) MISSED OFFSET
	struct FScriptDelegate                             $Callee_10;                                               // 0x0294(0x0010) (ZeroConstructor)
	struct FCompanionAI_Ftuple_L_R                     $ExprResult_11;                                           // 0x02A0(0x0001)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("VerseClass CompanionAI.task_companion_ai$DrawSphere_L_Nvector3_M_Nfloat_M_Ncolor_R"));
		
		return ptr;
	}


	int64_t Update();
};


// VerseClass CompanionAI.task_companion_ai$GameLoop
// 0x0360 (0x0480 - 0x0120)
class task_companion_ai$GameLoop : public task_t_
{
public:
	class companion_ai*                                _Self;                                                    // 0x0120(0x0008) (Parm, ZeroConstructor)
	struct FCompanionAI_Ftuple_L_R                     __verse_0xB2CDDD72_Argument;                              // 0x0128(0x0001) (Parm)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0129(0x0007) MISSED OFFSET
	unsigned char                                      UnknownData01[0x10];                                      // 0x0129(0x0010) UNKNOWN PROPERTY: VerseDynamicProperty CompanionAI.task_companion_ai$GameLoop.InvokeResultDummy_0
	unsigned char                                      UnknownData02[0x11];                                      // 0x0140(0x0011) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$GameLoop.$ExprResultStack_1
	unsigned char                                      UnknownData03[0x7];                                       // 0x0151(0x0007) MISSED OFFSET
	unsigned char                                      UnknownData04[0x10];                                      // 0x0151(0x0010) UNKNOWN PROPERTY: VerseDynamicProperty CompanionAI.task_companion_ai$GameLoop.$ExprResult_2
	unsigned char                                      $ExprResult_3 : 1;                                        // 0x0168(0x0001)
	unsigned char                                      UnknownData05[0x7];                                       // 0x0169(0x0007) MISSED OFFSET
	class Object_32759*                                __verse_0x00000000__3;                                    // 0x0170(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	unsigned char                                      UnknownData06[0x8];                                       // 0x0178(0x0008) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$GameLoop.$ExprResultStack_4
	struct FScriptDelegate                             $Callee_5;                                                // 0x0180(0x0010) (ZeroConstructor)
	struct FCompanionAI_Ftuple_L_R                     $ExprResult_6;                                            // 0x018C(0x0001)
	unsigned char                                      UnknownData07[0x3];                                       // 0x018D(0x0003) MISSED OFFSET
	unsigned char                                      UnknownData08[0x10];                                      // 0x018D(0x0010) UNKNOWN PROPERTY: VerseDynamicProperty CompanionAI.task_companion_ai$GameLoop.$ExprResult_7
	class Object_32759*                                __verse_0xE8036CC4_AIActions_2;                           // 0x01A0(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	unsigned char                                      UnknownData09[0x8];                                       // 0x01A8(0x0008) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$GameLoop.$ExprResultStack_8
	class Object_32759*                                __verse_0x00000000__5;                                    // 0x01B0(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	class task_t_*                                     $AsyncTask_9;                                             // 0x01B8(0x0008) (ZeroConstructor)
	struct FScriptDelegate                             $AsyncTaskClass_10;                                       // 0x01C0(0x0010) (ZeroConstructor)
	struct FCompanionAI_Ftuple_L_R                     $ExprResult_11;                                           // 0x01CC(0x0001)
	unsigned char                                      UnknownData10[0x3];                                       // 0x01CD(0x0003) MISSED OFFSET
	int64_t                                            $AsyncResult_12;                                          // 0x01D0(0x0008) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData11[0x39];                                      // 0x01D8(0x0039) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$GameLoop.__verse_0x01443115_PingInfo_1
	unsigned char                                      UnknownData12[0x2];                                       // 0x0211(0x0002) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$GameLoop.__verse_0x00000000__6
	unsigned char                                      $ExprResult_13 : 1;                                       // 0x0213(0x0001)
	unsigned char                                      UnknownData13[0x2];                                       // 0x0214(0x0002) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$GameLoop.$ExprResultStack_14
	unsigned char                                      UnknownData14[0x2];                                       // 0x0216(0x0002) MISSED OFFSET
	class Object_32759*                                __verse_0xB4DBB24F_PingActions_8;                         // 0x0218(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	unsigned char                                      UnknownData15[0x8];                                       // 0x0220(0x0008) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$GameLoop.$ExprResultStack_15
	class Object_32759*                                __verse_0xE8036CC4_AIActions_8;                           // 0x0228(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	unsigned char                                      UnknownData16[0x8];                                       // 0x0230(0x0008) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$GameLoop.$ExprResultStack_16
	class Object_32759*                                __verse_0x00000000__9;                                    // 0x0238(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	class Object_32759*                                __verse_0x00000000__10;                                   // 0x0240(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	struct FScriptDelegate                             $Callee_17;                                               // 0x0248(0x0010) (ZeroConstructor)
	struct FCompanionAI_Ftuple_L_R                     $ExprResult_18;                                           // 0x0254(0x0001)
	unsigned char                                      UnknownData17[0x3];                                       // 0x0255(0x0003) MISSED OFFSET
	class Object_32759*                                $InvokeSureResultDummy_19;                                // 0x0258(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	struct FScriptDelegate                             $Callee_20;                                               // 0x0260(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData18[0x4];                                       // 0x026C(0x0004) MISSED OFFSET
	class Object_32759*                                __verse_0x00000000__11;                                   // 0x0270(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	class Object_32759*                                __verse_0x00000000__12;                                   // 0x0278(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	struct FScriptDelegate                             $Callee_21;                                               // 0x0280(0x0010) (ZeroConstructor)
	struct FCompanionAI_Ftuple_L_R                     $ExprResult_22;                                           // 0x028C(0x0001)
	unsigned char                                      UnknownData19[0x3];                                       // 0x028D(0x0003) MISSED OFFSET
	class Object_32759*                                $InvokeSureResultDummy_23;                                // 0x0290(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	struct FScriptDelegate                             $Callee_24;                                               // 0x0298(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData20[0x4];                                       // 0x02A4(0x0004) MISSED OFFSET
	struct Fping_info                                  __verse_0x78680F6D_CurrentCommand_14;                     // 0x02A8(0x0038)
	unsigned char                                      UnknownData21[0x39];                                      // 0x02E0(0x0039) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$GameLoop.$ExprResultStack_25
	unsigned char                                      UnknownData22[0x7];                                       // 0x0319(0x0007) MISSED OFFSET
	int64_t                                            $AsyncBeginCount_26;                                      // 0x0320(0x0008) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData23[0x39];                                      // 0x0328(0x0039) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$GameLoop.$ExprResult_27
	unsigned char                                      UnknownData24[0x7];                                       // 0x0361(0x0007) MISSED OFFSET
	class Object_32759*                                __verse_0x00000000__15;                                   // 0x0368(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	class task_t_*                                     $AsyncTask_28;                                            // 0x0370(0x0008) (ZeroConstructor)
	struct FScriptDelegate                             $AsyncTaskClass_29;                                       // 0x0378(0x0010) (ZeroConstructor)
	struct FCompanionAI_Ftuple_L_R                     $ExprResult_30;                                           // 0x0384(0x0001)
	unsigned char                                      UnknownData25[0x3];                                       // 0x0385(0x0003) MISSED OFFSET
	int64_t                                            $AsyncResult_31;                                          // 0x0388(0x0008) (ZeroConstructor, IsPlainOldData)
	class task_t_*                                     $AsyncTask_32;                                            // 0x0390(0x0008) (ZeroConstructor)
	struct FScriptDelegate                             $AsyncTaskClass_33;                                       // 0x0398(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData26[0x4];                                       // 0x03A4(0x0004) MISSED OFFSET
	int64_t                                            $AsyncResult_34;                                          // 0x03A8(0x0008) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData27[0x39];                                      // 0x03B0(0x0039) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$GameLoop.$ExprResult_35
	unsigned char                                      UnknownData28[0x2];                                       // 0x03E9(0x0002) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$GameLoop.__verse_0x00000000__17
	unsigned char                                      $ExprResult_36 : 1;                                       // 0x03EB(0x0001)
	unsigned char                                      UnknownData29[0x2];                                       // 0x03EC(0x0002) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$GameLoop.$ExprResultStack_37
	unsigned char                                      UnknownData30[0x2];                                       // 0x03EE(0x0002) MISSED OFFSET
	class Object_32759*                                __verse_0x00000000__20;                                   // 0x03F0(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	class task_t_*                                     $AsyncTask_38;                                            // 0x03F8(0x0008) (ZeroConstructor)
	struct FScriptDelegate                             $AsyncTaskClass_39;                                       // 0x0400(0x0010) (ZeroConstructor)
	struct FCompanionAI_Ftuple_L_R                     $ExprResult_40;                                           // 0x040C(0x0001)
	unsigned char                                      UnknownData31[0x3];                                       // 0x040D(0x0003) MISSED OFFSET
	int64_t                                            $AsyncResult_41;                                          // 0x0410(0x0008) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData32[0x39];                                      // 0x0418(0x0039) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$GameLoop.$ExprResult_42
	unsigned char                                      UnknownData33[0x7];                                       // 0x0451(0x0007) MISSED OFFSET
	class Object_32759*                                __verse_0x00000000__21;                                   // 0x0458(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	class task_t_*                                     $AsyncTask_43;                                            // 0x0460(0x0008) (ZeroConstructor)
	struct FScriptDelegate                             $AsyncTaskClass_44;                                       // 0x0468(0x0010) (ZeroConstructor)
	struct FCompanionAI_Ftuple_L_R                     $ExprResult_45;                                           // 0x0474(0x0001)
	unsigned char                                      UnknownData34[0x3];                                       // 0x0475(0x0003) MISSED OFFSET
	int64_t                                            $AsyncResult_46;                                          // 0x0478(0x0008) (ZeroConstructor, IsPlainOldData)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("VerseClass CompanionAI.task_companion_ai$GameLoop"));
		
		return ptr;
	}


	int64_t Update();
};


// VerseClass CompanionAI.task_companion_ai$GetNewObstacle
// 0x007B (0x019B - 0x0120)
class task_companion_ai$GetNewObstacle : public task_t_
{
public:
	class companion_ai*                                _Self;                                                    // 0x0120(0x0008) (Parm, ZeroConstructor)
	struct FCompanionAI_Ftuple_L_R                     __verse_0xB2CDDD72_Argument;                              // 0x0128(0x0001) (Parm)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0129(0x0007) MISSED OFFSET
	unsigned char                                      UnknownData01[0x29];                                      // 0x0129(0x0029) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$GetNewObstacle._RetVal
	unsigned char                                      UnknownData02[0x2];                                       // 0x0159(0x0002) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$GetNewObstacle.__verse_0x00000000__1
	unsigned char                                      UnknownData03[0x5];                                       // 0x015B(0x0005) MISSED OFFSET
	class Object_32759*                                __verse_0x00C33D6C_ObstaclePerception_3;                  // 0x0160(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	unsigned char                                      UnknownData04[0x8];                                       // 0x0168(0x0008) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$GetNewObstacle.$ExprResultStack_0
	class Object_32759*                                __verse_0x00000000__5;                                    // 0x0170(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	class task_t_*                                     $AsyncTask_1;                                             // 0x0178(0x0008) (ZeroConstructor)
	struct FScriptDelegate                             $AsyncTaskClass_2;                                        // 0x0180(0x0010) (ZeroConstructor)
	struct FCompanionAI_Ftuple_L_R                     $ExprResult_3;                                            // 0x018C(0x0001)
	unsigned char                                      UnknownData05[0x3];                                       // 0x018D(0x0003) MISSED OFFSET
	int64_t                                            $AsyncResult_4;                                           // 0x0190(0x0008) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      $ExprResult_5 : 1;                                        // 0x0198(0x0001)
	unsigned char                                      UnknownData06[0x2];                                       // 0x0199(0x0002) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$GetNewObstacle.$ExprResultStack_6

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("VerseClass CompanionAI.task_companion_ai$GetNewObstacle"));
		
		return ptr;
	}


	int64_t Update();
};


// VerseClass CompanionAI.task_companion_ai$GetNewTargetPerception_L_N_Qthreat__info_R
// 0x0147 (0x0267 - 0x0120)
class task_companion_ai$GetNewTargetPerception_L_N_Qthreat__info_R : public task_t_
{
public:
	class companion_ai*                                _Self;                                                    // 0x0120(0x0008) (Parm, ZeroConstructor)
	unsigned char                                      UnknownData00[0x39];                                      // 0x0128(0x0039) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$GetNewTargetPerception_L_N_Qthreat__info_R.__verse_0xB2CDDD72_Argument
	unsigned char                                      UnknownData01[0x7];                                       // 0x0161(0x0007) MISSED OFFSET
	unsigned char                                      UnknownData02[0x39];                                      // 0x0161(0x0039) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$GetNewTargetPerception_L_N_Qthreat__info_R._RetVal
	unsigned char                                      UnknownData03[0x2];                                       // 0x01A1(0x0002) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$GetNewTargetPerception_L_N_Qthreat__info_R.__verse_0x00000000__1
	unsigned char                                      UnknownData04[0x5];                                       // 0x01A3(0x0005) MISSED OFFSET
	struct Fthreat_info                                __verse_0x2CFDBF0A_CurrentThreat_3;                       // 0x01A8(0x0038)
	unsigned char                                      UnknownData05[0x39];                                      // 0x01E0(0x0039) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$GetNewTargetPerception_L_N_Qthreat__info_R.$ExprResultStack_0
	unsigned char                                      UnknownData06[0x7];                                       // 0x0219(0x0007) MISSED OFFSET
	class Object_32759*                                __verse_0x0F05355D_ThreatPerception_3;                    // 0x0220(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	unsigned char                                      UnknownData07[0x8];                                       // 0x0228(0x0008) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$GetNewTargetPerception_L_N_Qthreat__info_R.$ExprResultStack_1
	class Object_32759*                                __verse_0x00000000__5;                                    // 0x0230(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	class task_t_*                                     $AsyncTask_2;                                             // 0x0238(0x0008) (ZeroConstructor)
	struct FScriptDelegate                             $AsyncTaskClass_3;                                        // 0x0240(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData08[0x4];                                       // 0x024C(0x0004) MISSED OFFSET
	int64_t                                            $AsyncResult_4;                                           // 0x0250(0x0008) (ZeroConstructor, IsPlainOldData)
	struct FScriptDelegate                             $AsyncTaskClass_5;                                        // 0x0258(0x0010) (ZeroConstructor)
	unsigned char                                      $ExprResult_6 : 1;                                        // 0x0264(0x0001)
	unsigned char                                      UnknownData09[0x2];                                       // 0x0265(0x0002) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$GetNewTargetPerception_L_N_Qthreat__info_R.$ExprResultStack_7

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("VerseClass CompanionAI.task_companion_ai$GetNewTargetPerception_L_N_Qthreat__info_R"));
		
		return ptr;
	}


	int64_t Update();
};


// VerseClass CompanionAI.task_companion_ai$GetNewThreat
// 0x008B (0x01AB - 0x0120)
class task_companion_ai$GetNewThreat : public task_t_
{
public:
	class companion_ai*                                _Self;                                                    // 0x0120(0x0008) (Parm, ZeroConstructor)
	struct FCompanionAI_Ftuple_L_R                     __verse_0xB2CDDD72_Argument;                              // 0x0128(0x0001) (Parm)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0129(0x0007) MISSED OFFSET
	unsigned char                                      UnknownData01[0x39];                                      // 0x0129(0x0039) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$GetNewThreat._RetVal
	unsigned char                                      UnknownData02[0x2];                                       // 0x0169(0x0002) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$GetNewThreat.__verse_0x00000000__1
	unsigned char                                      UnknownData03[0x5];                                       // 0x016B(0x0005) MISSED OFFSET
	class Object_32759*                                __verse_0x0F05355D_ThreatPerception_3;                    // 0x0170(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	unsigned char                                      UnknownData04[0x8];                                       // 0x0178(0x0008) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$GetNewThreat.$ExprResultStack_0
	class Object_32759*                                __verse_0x00000000__5;                                    // 0x0180(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	class task_t_*                                     $AsyncTask_1;                                             // 0x0188(0x0008) (ZeroConstructor)
	struct FScriptDelegate                             $AsyncTaskClass_2;                                        // 0x0190(0x0010) (ZeroConstructor)
	struct FCompanionAI_Ftuple_L_R                     $ExprResult_3;                                            // 0x019C(0x0001)
	unsigned char                                      UnknownData05[0x3];                                       // 0x019D(0x0003) MISSED OFFSET
	int64_t                                            $AsyncResult_4;                                           // 0x01A0(0x0008) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      $ExprResult_5 : 1;                                        // 0x01A8(0x0001)
	unsigned char                                      UnknownData06[0x2];                                       // 0x01A9(0x0002) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$GetNewThreat.$ExprResultStack_6

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("VerseClass CompanionAI.task_companion_ai$GetNewThreat"));
		
		return ptr;
	}


	int64_t Update();
};


// VerseClass CompanionAI.task_companion_ai$GetObstacle
// 0x00B4 (0x01D4 - 0x0120)
class task_companion_ai$GetObstacle : public task_t_
{
public:
	class companion_ai*                                _Self;                                                    // 0x0120(0x0008) (Parm, ZeroConstructor)
	struct FCompanionAI_Ftuple_L_R                     __verse_0xB2CDDD72_Argument;                              // 0x0128(0x0001) (Parm)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0129(0x0007) MISSED OFFSET
	unsigned char                                      UnknownData01[0x29];                                      // 0x0129(0x0029) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$GetObstacle._RetVal
	unsigned char                                      UnknownData02[0x2];                                       // 0x0159(0x0002) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$GetObstacle.__verse_0x00000000__1
	unsigned char                                      UnknownData03[0x5];                                       // 0x015B(0x0005) MISSED OFFSET
	struct Fobstacle_info                              __verse_0x39C5E53E_ObstacleInfo_3;                        // 0x0160(0x0028)
	class Object_32759*                                __verse_0x00000000__4;                                    // 0x0188(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	unsigned char                                      UnknownData04[0x8];                                       // 0x0190(0x0008) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$GetObstacle.$ExprResultStack_0
	unsigned char                                      UnknownData05[0x29];                                      // 0x0198(0x0029) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$GetObstacle.$ExprResultStack_1
	unsigned char                                      UnknownData06[0x3];                                       // 0x01C1(0x0003) MISSED OFFSET
	struct FScriptDelegate                             $Callee_2;                                                // 0x01C4(0x0010) (ZeroConstructor)
	struct FCompanionAI_Ftuple_L_R                     $ExprResult_3;                                            // 0x01D0(0x0001)
	unsigned char                                      $ExprResult_4 : 1;                                        // 0x01D1(0x0001)
	unsigned char                                      UnknownData07[0x2];                                       // 0x01D2(0x0002) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$GetObstacle.$ExprResultStack_5

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("VerseClass CompanionAI.task_companion_ai$GetObstacle"));
		
		return ptr;
	}


	int64_t Update();
};


// VerseClass CompanionAI.task_companion_ai$GetThreat
// 0x00E4 (0x0204 - 0x0120)
class task_companion_ai$GetThreat : public task_t_
{
public:
	class companion_ai*                                _Self;                                                    // 0x0120(0x0008) (Parm, ZeroConstructor)
	struct FCompanionAI_Ftuple_L_R                     __verse_0xB2CDDD72_Argument;                              // 0x0128(0x0001) (Parm)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0129(0x0007) MISSED OFFSET
	unsigned char                                      UnknownData01[0x39];                                      // 0x0129(0x0039) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$GetThreat._RetVal
	unsigned char                                      UnknownData02[0x2];                                       // 0x0169(0x0002) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$GetThreat.__verse_0x00000000__1
	unsigned char                                      UnknownData03[0x5];                                       // 0x016B(0x0005) MISSED OFFSET
	struct Fthreat_info                                __verse_0x1EB80E5B_ThreatInfo_3;                          // 0x0170(0x0038)
	class Object_32759*                                __verse_0x00000000__4;                                    // 0x01A8(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	unsigned char                                      UnknownData04[0x8];                                       // 0x01B0(0x0008) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$GetThreat.$ExprResultStack_0
	unsigned char                                      UnknownData05[0x39];                                      // 0x01B8(0x0039) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$GetThreat.$ExprResultStack_1
	unsigned char                                      UnknownData06[0x3];                                       // 0x01F1(0x0003) MISSED OFFSET
	struct FScriptDelegate                             $Callee_2;                                                // 0x01F4(0x0010) (ZeroConstructor)
	struct FCompanionAI_Ftuple_L_R                     $ExprResult_3;                                            // 0x0200(0x0001)
	unsigned char                                      $ExprResult_4 : 1;                                        // 0x0201(0x0001)
	unsigned char                                      UnknownData07[0x2];                                       // 0x0202(0x0002) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$GetThreat.$ExprResultStack_5

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("VerseClass CompanionAI.task_companion_ai$GetThreat"));
		
		return ptr;
	}


	int64_t Update();
};


// VerseClass CompanionAI.task_companion_ai$GoToAndAttackTask_L_Nthreat__info_R
// 0x0120 (0x0240 - 0x0120)
class task_companion_ai$GoToAndAttackTask_L_Nthreat__info_R : public task_t_
{
public:
	class companion_ai*                                _Self;                                                    // 0x0120(0x0008) (Parm, ZeroConstructor)
	struct Fthreat_info                                __verse_0xB2CDDD72_Argument;                              // 0x0128(0x0038) (Parm)
	EVerseTrue                                         $InvokeSureResultDummy_0;                                 // 0x0160(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0161(0x0003) MISSED OFFSET
	struct FScriptDelegate                             $Callee_1;                                                // 0x0164(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData01[0x10];                                      // 0x0170(0x0010) UNKNOWN PROPERTY: VerseStringProperty CompanionAI.task_companion_ai$GoToAndAttackTask_L_Nthreat__info_R.$ExprResult_2
	int64_t                                            $AsyncBeginCount_3;                                       // 0x0180(0x0008) (ZeroConstructor, IsPlainOldData)
	class task_t_*                                     $AsyncTask_4;                                             // 0x0188(0x0008) (ZeroConstructor)
	struct FScriptDelegate                             $AsyncTaskClass_5;                                        // 0x0190(0x0010) (ZeroConstructor)
	struct FCompanionAI_Ftuple_L_R                     $ExprResult_6;                                            // 0x019C(0x0001)
	unsigned char                                      UnknownData02[0x3];                                       // 0x019D(0x0003) MISSED OFFSET
	int64_t                                            $AsyncResult_7;                                           // 0x01A0(0x0008) (ZeroConstructor, IsPlainOldData)
	int64_t                                            $AsyncBeginCount_8;                                       // 0x01A8(0x0008) (ZeroConstructor, IsPlainOldData)
	class Object_32759*                                __verse_0xF161303F_WeaponActions_2;                       // 0x01B0(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	unsigned char                                      UnknownData03[0x8];                                       // 0x01B8(0x0008) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$GoToAndAttackTask_L_Nthreat__info_R.$ExprResultStack_9
	class Object_32759*                                __verse_0x00000000__4;                                    // 0x01C0(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	class task_t_*                                     $AsyncTask_10;                                            // 0x01C8(0x0008) (ZeroConstructor)
	struct FScriptDelegate                             $AsyncTaskClass_11;                                       // 0x01D0(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData04[0x4];                                       // 0x01DC(0x0004) MISSED OFFSET
	int64_t                                            $AsyncResult_12;                                          // 0x01E0(0x0008) (ZeroConstructor, IsPlainOldData)
	class Object_32759*                                __verse_0xCA7BB203_AIMovement_5;                          // 0x01E8(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	unsigned char                                      UnknownData05[0x8];                                       // 0x01F0(0x0008) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$GoToAndAttackTask_L_Nthreat__info_R.$ExprResultStack_13
	class Object_32759*                                __verse_0x00000000__7;                                    // 0x01F8(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	class task_t_*                                     $AsyncTask_14;                                            // 0x0200(0x0008) (ZeroConstructor)
	struct FScriptDelegate                             $AsyncTaskClass_15;                                       // 0x0208(0x0010) (ZeroConstructor)
	struct FCompanionAI_Ftuple_L_R                     $ExprResult_16;                                           // 0x0214(0x0001)
	unsigned char                                      UnknownData06[0x3];                                       // 0x0215(0x0003) MISSED OFFSET
	int64_t                                            $AsyncResult_17;                                          // 0x0218(0x0008) (ZeroConstructor, IsPlainOldData)
	EVerseTrue                                         $InvokeSureResultDummy_18;                                // 0x0220(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData07[0x3];                                       // 0x0221(0x0003) MISSED OFFSET
	struct FScriptDelegate                             $Callee_19;                                               // 0x0224(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData08[0x10];                                      // 0x0230(0x0010) UNKNOWN PROPERTY: VerseStringProperty CompanionAI.task_companion_ai$GoToAndAttackTask_L_Nthreat__info_R.$ExprResult_20

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("VerseClass CompanionAI.task_companion_ai$GoToAndAttackTask_L_Nthreat__info_R"));
		
		return ptr;
	}


	int64_t Update();
};


// VerseClass CompanionAI.task_companion_ai$GoToPositionTask_L_Nvector3_M_N_Qfort__character_M_Nlogic_M_Nnavigation__parameters_R
// 0x0428 (0x0548 - 0x0120)
class task_companion_ai$GoToPositionTask_L_Nvector3_M_N_Qfort__character_M_Nlogic_M_Nnavigation__parameters_R : public task_t_
{
public:
	class companion_ai*                                _Self;                                                    // 0x0120(0x0008) (Parm, ZeroConstructor)
	struct Ftuple_Lvector3_M_Qfort__character_Mlogic_M_QNavigationParameters_Nnavigation__parameters_20_3d_20_2e_2e_2e_R __verse_0xB2CDDD72_Argument;                              // 0x0128(0x0040) (Parm)
	unsigned char                                      _RetVal : 1;                                              // 0x0168(0x0001) (Parm, OutParm, ReturnParm)
	EVerseTrue                                         $InvokeSureResultDummy_0;                                 // 0x0169(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x2];                                       // 0x016A(0x0002) MISSED OFFSET
	struct FScriptDelegate                             $Callee_1;                                                // 0x016C(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData01[0x10];                                      // 0x0178(0x0010) UNKNOWN PROPERTY: VerseStringProperty CompanionAI.task_companion_ai$GoToPositionTask_L_Nvector3_M_N_Qfort__character_M_Nlogic_M_Nnavigation__parameters_R.$ExprResult_2
	unsigned char                                      UnknownData02[0x10];                                      // 0x0188(0x0010) UNKNOWN PROPERTY: ArrayProperty CompanionAI.task_companion_ai$GoToPositionTask_L_Nvector3_M_N_Qfort__character_M_Nlogic_M_Nnavigation__parameters_R.__verse_0xFFC68BC5_Array_2
	struct FScriptDelegate                             $Callee_3;                                                // 0x0198(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData03[0x4];                                       // 0x01A4(0x0004) MISSED OFFSET
	unsigned char                                      UnknownData04[0x10];                                      // 0x01A4(0x0010) UNKNOWN PROPERTY: ArrayProperty CompanionAI.task_companion_ai$GoToPositionTask_L_Nvector3_M_N_Qfort__character_M_Nlogic_M_Nnavigation__parameters_R.$ExprResult_4
	unsigned char                                      UnknownData05[0x10];                                      // 0x01B8(0x0010) UNKNOWN PROPERTY: ArrayProperty CompanionAI.task_companion_ai$GoToPositionTask_L_Nvector3_M_N_Qfort__character_M_Nlogic_M_Nnavigation__parameters_R.__verse_0xFFC68BC5_Array_3
	struct FCompanionAI_Ftuple_L_Kchar_M_Kchar_R       __verse_0x00000000__4;                                    // 0x01C8(0x0020)
	unsigned char                                      UnknownData06[0x10];                                      // 0x01E8(0x0010) UNKNOWN PROPERTY: VerseStringProperty CompanionAI.task_companion_ai$GoToPositionTask_L_Nvector3_M_N_Qfort__character_M_Nlogic_M_Nnavigation__parameters_R.$ExprResult_5
	unsigned char                                      UnknownData07[0x10];                                      // 0x01F8(0x0010) UNKNOWN PROPERTY: VerseStringProperty CompanionAI.task_companion_ai$GoToPositionTask_L_Nvector3_M_N_Qfort__character_M_Nlogic_M_Nnavigation__parameters_R.$ExprResultStack_6
	struct FScriptDelegate                             $Callee_7;                                                // 0x0208(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData08[0x4];                                       // 0x0214(0x0004) MISSED OFFSET
	unsigned char                                      UnknownData09[0x10];                                      // 0x0214(0x0010) UNKNOWN PROPERTY: VerseStringProperty CompanionAI.task_companion_ai$GoToPositionTask_L_Nvector3_M_N_Qfort__character_M_Nlogic_M_Nnavigation__parameters_R.$ExprResultStack_8
	struct FScriptDelegate                             $Callee_9;                                                // 0x0228(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData10[0x4];                                       // 0x0234(0x0004) MISSED OFFSET
	unsigned char                                      UnknownData11[0x10];                                      // 0x0234(0x0010) UNKNOWN PROPERTY: VerseStringProperty CompanionAI.task_companion_ai$GoToPositionTask_L_Nvector3_M_N_Qfort__character_M_Nlogic_M_Nnavigation__parameters_R.$ExprResultDummy_10
	unsigned char                                      UnknownData12[0x10];                                      // 0x0248(0x0010) UNKNOWN PROPERTY: VerseStringProperty CompanionAI.task_companion_ai$GoToPositionTask_L_Nvector3_M_N_Qfort__character_M_Nlogic_M_Nnavigation__parameters_R.$ExprResultDummy_11
	unsigned char                                      UnknownData13[0x10];                                      // 0x0258(0x0010) UNKNOWN PROPERTY: ArrayProperty CompanionAI.task_companion_ai$GoToPositionTask_L_Nvector3_M_N_Qfort__character_M_Nlogic_M_Nnavigation__parameters_R.$ForResult_12
	int64_t                                            $ForIndex_13;                                             // 0x0268(0x0008) (ZeroConstructor, IsPlainOldData)
	int64_t                                            $ForLength_14;                                            // 0x0270(0x0008) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData14[0x10];                                      // 0x0278(0x0010) UNKNOWN PROPERTY: VerseStringProperty CompanionAI.task_companion_ai$GoToPositionTask_L_Nvector3_M_N_Qfort__character_M_Nlogic_M_Nnavigation__parameters_R.__verse_0xFB88B569_Item_6
	unsigned char                                      UnknownData15[0x10];                                      // 0x0288(0x0010) UNKNOWN PROPERTY: ArrayProperty CompanionAI.task_companion_ai$GoToPositionTask_L_Nvector3_M_N_Qfort__character_M_Nlogic_M_Nnavigation__parameters_R.$ExprResult_15
	unsigned char                                      UnknownData16[0x10];                                      // 0x0298(0x0010) UNKNOWN PROPERTY: VerseStringProperty CompanionAI.task_companion_ai$GoToPositionTask_L_Nvector3_M_N_Qfort__character_M_Nlogic_M_Nnavigation__parameters_R.__verse_0xFFC68BC5_Array_7
	unsigned char                                      UnknownData17[0x10];                                      // 0x02A8(0x0010) UNKNOWN PROPERTY: ArrayProperty CompanionAI.task_companion_ai$GoToPositionTask_L_Nvector3_M_N_Qfort__character_M_Nlogic_M_Nnavigation__parameters_R.$ForResult_16
	int64_t                                            $ForIndex_17;                                             // 0x02B8(0x0008) (ZeroConstructor, IsPlainOldData)
	int64_t                                            $ForLength_18;                                            // 0x02C0(0x0008) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      __verse_0xFB88B569_Item_9;                                // 0x02C8(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData18[0x7];                                       // 0x02C9(0x0007) MISSED OFFSET
	unsigned char                                      UnknownData19[0x10];                                      // 0x02C9(0x0010) UNKNOWN PROPERTY: VerseDynamicProperty CompanionAI.task_companion_ai$GoToPositionTask_L_Nvector3_M_N_Qfort__character_M_Nlogic_M_Nnavigation__parameters_R.$ExprResult_19
	unsigned char                                      UnknownData20[0x10];                                      // 0x02E0(0x0010) UNKNOWN PROPERTY: VerseStringProperty CompanionAI.task_companion_ai$GoToPositionTask_L_Nvector3_M_N_Qfort__character_M_Nlogic_M_Nnavigation__parameters_R.$ForResult_20
	int64_t                                            $ForIndex_21;                                             // 0x02F0(0x0008) (ZeroConstructor, IsPlainOldData)
	int64_t                                            $ForLength_22;                                            // 0x02F8(0x0008) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData21[0x10];                                      // 0x0300(0x0010) UNKNOWN PROPERTY: VerseDynamicProperty CompanionAI.task_companion_ai$GoToPositionTask_L_Nvector3_M_N_Qfort__character_M_Nlogic_M_Nnavigation__parameters_R.__verse_0xFB88B569_Item_11
	unsigned char                                      $ExprResult_23;                                           // 0x0310(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData22[0x7];                                       // 0x0311(0x0007) MISSED OFFSET
	class Object_32759*                                __verse_0xCA7BB203_AIMovement_12;                         // 0x0318(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	unsigned char                                      UnknownData23[0x8];                                       // 0x0320(0x0008) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$GoToPositionTask_L_Nvector3_M_N_Qfort__character_M_Nlogic_M_Nnavigation__parameters_R.$ExprResultStack_24
	unsigned char                                      UnknownData24[0x2];                                       // 0x0328(0x0002) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$GoToPositionTask_L_Nvector3_M_N_Qfort__character_M_Nlogic_M_Nnavigation__parameters_R.$ExprResultStack_25
	unsigned char                                      UnknownData25[0x6];                                       // 0x032A(0x0006) MISSED OFFSET
	int64_t                                            $AsyncBeginCount_26;                                      // 0x0330(0x0008) (ZeroConstructor, IsPlainOldData)
	class task_t_*                                     $AsyncTask_27;                                            // 0x0338(0x0008) (ZeroConstructor)
	struct FScriptDelegate                             $AsyncTaskClass_28;                                       // 0x0340(0x0010) (ZeroConstructor)
	struct FCompanionAI_Ftuple_L_R                     $ExprResult_29;                                           // 0x034C(0x0001)
	unsigned char                                      UnknownData26[0x3];                                       // 0x034D(0x0003) MISSED OFFSET
	int64_t                                            $AsyncResult_30;                                          // 0x0350(0x0008) (ZeroConstructor, IsPlainOldData)
	class Object_32759*                                __verse_0xFE707B39_TargetCharacter_14;                    // 0x0358(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	unsigned char                                      UnknownData27[0x8];                                       // 0x0360(0x0008) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$GoToPositionTask_L_Nvector3_M_N_Qfort__character_M_Nlogic_M_Nnavigation__parameters_R.$ExprResultStack_31
	Enavigate_result                                   __verse_0x95D09D0E_Result_14;                             // 0x0368(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData28[0x7];                                       // 0x0369(0x0007) MISSED OFFSET
	class Object_32759*                                __verse_0x00000000__15;                                   // 0x0370(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	class task_t_*                                     $AsyncTask_32;                                            // 0x0378(0x0008) (ZeroConstructor)
	struct FScriptDelegate                             $AsyncTaskClass_33;                                       // 0x0380(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData29[0x4];                                       // 0x038C(0x0004) MISSED OFFSET
	struct Ftuple_Lnavigation__target_M_QNavigationParameters_Nnavigation__parameters_R $ExprResult_34;                                           // 0x0390(0x0020)
	class navigation_target*                           $ExprResultStack_35;                                      // 0x03B0(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	struct FScriptDelegate                             $Callee_36;                                               // 0x03B8(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData30[0x4];                                       // 0x03C4(0x0004) MISSED OFFSET
	unsigned char                                      UnknownData31[0x11];                                      // 0x03C4(0x0011) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$GoToPositionTask_L_Nvector3_M_N_Qfort__character_M_Nlogic_M_Nnavigation__parameters_R.$ExprResult_37
	unsigned char                                      UnknownData32[0x7];                                       // 0x03D9(0x0007) MISSED OFFSET
	int64_t                                            $AsyncResult_38;                                          // 0x03E0(0x0008) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData33[0x10];                                      // 0x03E8(0x0010) UNKNOWN PROPERTY: VerseDynamicProperty CompanionAI.task_companion_ai$GoToPositionTask_L_Nvector3_M_N_Qfort__character_M_Nlogic_M_Nnavigation__parameters_R.InvokeResultDummy_39
	unsigned char                                      UnknownData34[0x11];                                      // 0x03F8(0x0011) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$GoToPositionTask_L_Nvector3_M_N_Qfort__character_M_Nlogic_M_Nnavigation__parameters_R.$ExprResultStack_40
	unsigned char                                      UnknownData35[0x7];                                       // 0x0409(0x0007) MISSED OFFSET
	unsigned char                                      UnknownData36[0x10];                                      // 0x0409(0x0010) UNKNOWN PROPERTY: VerseDynamicProperty CompanionAI.task_companion_ai$GoToPositionTask_L_Nvector3_M_N_Qfort__character_M_Nlogic_M_Nnavigation__parameters_R.$ExprResult_41
	unsigned char                                      UnknownData37[0x10];                                      // 0x0420(0x0010) UNKNOWN PROPERTY: VerseDynamicProperty CompanionAI.task_companion_ai$GoToPositionTask_L_Nvector3_M_N_Qfort__character_M_Nlogic_M_Nnavigation__parameters_R.$ExprResult_42
	EVerseTrue                                         $InvokeSureResultDummy_43;                                // 0x0430(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData38[0x3];                                       // 0x0431(0x0003) MISSED OFFSET
	struct FScriptDelegate                             $Callee_44;                                               // 0x0434(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData39[0x10];                                      // 0x0440(0x0010) UNKNOWN PROPERTY: VerseStringProperty CompanionAI.task_companion_ai$GoToPositionTask_L_Nvector3_M_N_Qfort__character_M_Nlogic_M_Nnavigation__parameters_R.$ExprResult_45
	Enavigate_result                                   __verse_0x95D09D0E_Result_18;                             // 0x0450(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData40[0x7];                                       // 0x0451(0x0007) MISSED OFFSET
	class Object_32759*                                __verse_0x00000000__19;                                   // 0x0458(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	struct FScriptDelegate                             $AsyncTaskClass_46;                                       // 0x0460(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData41[0x4];                                       // 0x046C(0x0004) MISSED OFFSET
	struct Ftuple_Lnavigation__target_M_QNavigationParameters_Nnavigation__parameters_R $ExprResult_47;                                           // 0x0470(0x0020)
	class navigation_target*                           $ExprResultStack_48;                                      // 0x0490(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	struct FScriptDelegate                             $Callee_49;                                               // 0x0498(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData42[0x4];                                       // 0x04A4(0x0004) MISSED OFFSET
	unsigned char                                      UnknownData43[0x11];                                      // 0x04A4(0x0011) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$GoToPositionTask_L_Nvector3_M_N_Qfort__character_M_Nlogic_M_Nnavigation__parameters_R.$ExprResult_50
	unsigned char                                      UnknownData44[0x7];                                       // 0x04B9(0x0007) MISSED OFFSET
	unsigned char                                      UnknownData45[0x10];                                      // 0x04B9(0x0010) UNKNOWN PROPERTY: VerseDynamicProperty CompanionAI.task_companion_ai$GoToPositionTask_L_Nvector3_M_N_Qfort__character_M_Nlogic_M_Nnavigation__parameters_R.InvokeResultDummy_51
	unsigned char                                      UnknownData46[0x11];                                      // 0x04D0(0x0011) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$GoToPositionTask_L_Nvector3_M_N_Qfort__character_M_Nlogic_M_Nnavigation__parameters_R.$ExprResultStack_52
	unsigned char                                      UnknownData47[0x7];                                       // 0x04E1(0x0007) MISSED OFFSET
	unsigned char                                      UnknownData48[0x10];                                      // 0x04E1(0x0010) UNKNOWN PROPERTY: VerseDynamicProperty CompanionAI.task_companion_ai$GoToPositionTask_L_Nvector3_M_N_Qfort__character_M_Nlogic_M_Nnavigation__parameters_R.$ExprResult_53
	unsigned char                                      UnknownData49[0x10];                                      // 0x04F8(0x0010) UNKNOWN PROPERTY: VerseDynamicProperty CompanionAI.task_companion_ai$GoToPositionTask_L_Nvector3_M_N_Qfort__character_M_Nlogic_M_Nnavigation__parameters_R.$ExprResult_54
	EVerseTrue                                         $InvokeSureResultDummy_55;                                // 0x0508(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData50[0x3];                                       // 0x0509(0x0003) MISSED OFFSET
	struct FScriptDelegate                             $Callee_56;                                               // 0x050C(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData51[0x10];                                      // 0x0518(0x0010) UNKNOWN PROPERTY: VerseStringProperty CompanionAI.task_companion_ai$GoToPositionTask_L_Nvector3_M_N_Qfort__character_M_Nlogic_M_Nnavigation__parameters_R.$ExprResult_57
	EVerseTrue                                         $InvokeSureResultDummy_58;                                // 0x0528(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData52[0x3];                                       // 0x0529(0x0003) MISSED OFFSET
	struct FScriptDelegate                             $Callee_59;                                               // 0x052C(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData53[0x10];                                      // 0x0538(0x0010) UNKNOWN PROPERTY: VerseStringProperty CompanionAI.task_companion_ai$GoToPositionTask_L_Nvector3_M_N_Qfort__character_M_Nlogic_M_Nnavigation__parameters_R.$ExprResult_60

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("VerseClass CompanionAI.task_companion_ai$GoToPositionTask_L_Nvector3_M_N_Qfort__character_M_Nlogic_M_Nnavigation__parameters_R"));
		
		return ptr;
	}


	int64_t Update();
};


// VerseClass CompanionAI.task_companion_ai$HandleBackToMeCommand_L_Nping__info_R
// 0x01D8 (0x02F8 - 0x0120)
class task_companion_ai$HandleBackToMeCommand_L_Nping__info_R : public task_t_
{
public:
	class companion_ai*                                _Self;                                                    // 0x0120(0x0008) (Parm, ZeroConstructor)
	struct Fping_info                                  __verse_0xB2CDDD72_Argument;                              // 0x0128(0x0038) (Parm)
	EVerseTrue                                         $InvokeSureResultDummy_0;                                 // 0x0160(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0161(0x0003) MISSED OFFSET
	struct FScriptDelegate                             $Callee_1;                                                // 0x0164(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData01[0x10];                                      // 0x0170(0x0010) UNKNOWN PROPERTY: VerseStringProperty CompanionAI.task_companion_ai$HandleBackToMeCommand_L_Nping__info_R.$ExprResult_2
	class Entity*                                      __verse_0xFD64D7AA_Emitter_2;                             // 0x0180(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	unsigned char                                      UnknownData02[0x8];                                       // 0x0188(0x0008) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$HandleBackToMeCommand_L_Nping__info_R.$ExprResultStack_3
	unsigned char                                      __verse_0x7EBDC403_HasReachedPosition_2 : 1;              // 0x0190(0x0001)
	unsigned char                                      UnknownData03[0x7];                                       // 0x0191(0x0007) MISSED OFFSET
	class task_t_*                                     $AsyncTask_4;                                             // 0x0198(0x0008) (ZeroConstructor)
	struct FScriptDelegate                             $AsyncTaskClass_5;                                        // 0x01A0(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData04[0x4];                                       // 0x01AC(0x0004) MISSED OFFSET
	struct Ftuple_Lvector3_M_Qfort__character_Mlogic_M_QNavigationParameters_Nnavigation__parameters_R $ExprResult_6;                                            // 0x01B0(0x0040)
	struct Fvector3                                    $ExprResult_7;                                            // 0x01F0(0x0018) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData05[0x8];                                       // 0x0208(0x0008) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$HandleBackToMeCommand_L_Nping__info_R.$ExprResultStack_8
	struct FScriptDelegate                             $Callee_9;                                                // 0x0210(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData06[0x4];                                       // 0x021C(0x0004) MISSED OFFSET
	unsigned char                                      UnknownData07[0x11];                                      // 0x021C(0x0011) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$HandleBackToMeCommand_L_Nping__info_R.$ExprResult_10
	unsigned char                                      UnknownData08[0x7];                                       // 0x0231(0x0007) MISSED OFFSET
	struct Fnavigation_parameters                      $ExprResult_11;                                           // 0x0238(0x0010)
	int64_t                                            $AsyncResult_12;                                          // 0x0248(0x0008) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData09[0x2];                                       // 0x0250(0x0002) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$HandleBackToMeCommand_L_Nping__info_R.$ExprResultStack_13
	unsigned char                                      UnknownData10[0x6];                                       // 0x0252(0x0006) MISSED OFFSET
	int64_t                                            $AsyncBeginCount_14;                                      // 0x0258(0x0008) (ZeroConstructor, IsPlainOldData)
	class task_t_*                                     $AsyncTask_15;                                            // 0x0260(0x0008) (ZeroConstructor)
	struct FScriptDelegate                             $AsyncTaskClass_16;                                       // 0x0268(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData11[0x4];                                       // 0x0274(0x0004) MISSED OFFSET
	struct Ftuple_Lentity_Mfloat_R                     $ExprResult_17;                                           // 0x0278(0x0010)
	int64_t                                            $AsyncResult_18;                                          // 0x0288(0x0008) (ZeroConstructor, IsPlainOldData)
	class task_t_*                                     $AsyncTask_19;                                            // 0x0290(0x0008) (ZeroConstructor)
	struct FScriptDelegate                             $AsyncTaskClass_20;                                       // 0x0298(0x0010) (ZeroConstructor)
	struct FCompanionAI_Ftuple_L_R                     $ExprResult_21;                                           // 0x02A4(0x0001)
	unsigned char                                      UnknownData12[0x3];                                       // 0x02A5(0x0003) MISSED OFFSET
	int64_t                                            $AsyncResult_22;                                          // 0x02A8(0x0008) (ZeroConstructor, IsPlainOldData)
	class Object_32759*                                __verse_0xB4DBB24F_PingActions_5;                         // 0x02B0(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	unsigned char                                      UnknownData13[0x8];                                       // 0x02B8(0x0008) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$HandleBackToMeCommand_L_Nping__info_R.$ExprResultStack_23
	class Object_32759*                                __verse_0x00000000__6;                                    // 0x02C0(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	EVerseTrue                                         $InvokeSureResultDummy_24;                                // 0x02C8(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData14[0x3];                                       // 0x02C9(0x0003) MISSED OFFSET
	struct FScriptDelegate                             $Callee_25;                                               // 0x02CC(0x0010) (ZeroConstructor)
	EVerseTrue                                         $InvokeSureResultDummy_26;                                // 0x02D8(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData15[0x3];                                       // 0x02D9(0x0003) MISSED OFFSET
	struct FScriptDelegate                             $Callee_27;                                               // 0x02DC(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData16[0x10];                                      // 0x02E8(0x0010) UNKNOWN PROPERTY: VerseStringProperty CompanionAI.task_companion_ai$HandleBackToMeCommand_L_Nping__info_R.$ExprResult_28

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("VerseClass CompanionAI.task_companion_ai$HandleBackToMeCommand_L_Nping__info_R"));
		
		return ptr;
	}


	int64_t Update();
};


// VerseClass CompanionAI.task_companion_ai$HandleGoTo_L_Nping__info_R
// 0x0570 (0x0690 - 0x0120)
class task_companion_ai$HandleGoTo_L_Nping__info_R : public task_t_
{
public:
	class companion_ai*                                _Self;                                                    // 0x0120(0x0008) (Parm, ZeroConstructor)
	struct Fping_info                                  __verse_0xB2CDDD72_Argument;                              // 0x0128(0x0038) (Parm)
	EVerseTrue                                         $InvokeSureResultDummy_0;                                 // 0x0160(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0161(0x0003) MISSED OFFSET
	struct FScriptDelegate                             $Callee_1;                                                // 0x0164(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData01[0x10];                                      // 0x0170(0x0010) UNKNOWN PROPERTY: VerseStringProperty CompanionAI.task_companion_ai$HandleGoTo_L_Nping__info_R.$ExprResult_2
	int64_t                                            $AsyncBeginCount_3;                                       // 0x0180(0x0008) (ZeroConstructor, IsPlainOldData)
	class task_t_*                                     $AsyncTask_4;                                             // 0x0188(0x0008) (ZeroConstructor)
	struct FScriptDelegate                             $AsyncTaskClass_5;                                        // 0x0190(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData02[0x4];                                       // 0x019C(0x0004) MISSED OFFSET
	int64_t                                            $AsyncResult_6;                                           // 0x01A0(0x0008) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData03[0x10];                                      // 0x01A8(0x0010) UNKNOWN PROPERTY: VerseDynamicProperty CompanionAI.task_companion_ai$HandleGoTo_L_Nping__info_R.InvokeResultDummy_7
	unsigned char                                      UnknownData04[0x11];                                      // 0x01B8(0x0011) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$HandleGoTo_L_Nping__info_R.$ExprResultStack_8
	unsigned char                                      UnknownData05[0x7];                                       // 0x01C9(0x0007) MISSED OFFSET
	unsigned char                                      UnknownData06[0x10];                                      // 0x01C9(0x0010) UNKNOWN PROPERTY: VerseDynamicProperty CompanionAI.task_companion_ai$HandleGoTo_L_Nping__info_R.$ExprResult_9
	unsigned char                                      UnknownData07[0x10];                                      // 0x01E0(0x0010) UNKNOWN PROPERTY: VerseDynamicProperty CompanionAI.task_companion_ai$HandleGoTo_L_Nping__info_R.$ExprResult_10
	class Entity*                                      __verse_0x459049A1_Target_3;                              // 0x01F0(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	unsigned char                                      UnknownData08[0x8];                                       // 0x01F8(0x0008) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$HandleGoTo_L_Nping__info_R.$ExprResultStack_11
	class task_t_*                                     $AsyncTask_12;                                            // 0x0200(0x0008) (ZeroConstructor)
	struct FScriptDelegate                             $AsyncTaskClass_13;                                       // 0x0208(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData09[0x4];                                       // 0x0214(0x0004) MISSED OFFSET
	struct Ftuple_Lvector3_M_Qfort__character_Mlogic_M_QNavigationParameters_Nnavigation__parameters_R $ExprResult_14;                                           // 0x0218(0x0040)
	unsigned char                                      UnknownData10[0x8];                                       // 0x0258(0x0008) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$HandleGoTo_L_Nping__info_R.$ExprResultStack_15
	struct FScriptDelegate                             $Callee_16;                                               // 0x0260(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData11[0x4];                                       // 0x026C(0x0004) MISSED OFFSET
	unsigned char                                      UnknownData12[0x11];                                      // 0x026C(0x0011) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$HandleGoTo_L_Nping__info_R.$ExprResult_17
	unsigned char                                      UnknownData13[0x7];                                       // 0x0281(0x0007) MISSED OFFSET
	struct Fnavigation_parameters                      $ExprResult_18;                                           // 0x0288(0x0010)
	int64_t                                            $AsyncResult_19;                                          // 0x0298(0x0008) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData14[0x10];                                      // 0x02A0(0x0010) UNKNOWN PROPERTY: VerseDynamicProperty CompanionAI.task_companion_ai$HandleGoTo_L_Nping__info_R.InvokeResultDummy_20
	unsigned char                                      UnknownData15[0x11];                                      // 0x02B0(0x0011) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$HandleGoTo_L_Nping__info_R.$ExprResultStack_21
	unsigned char                                      UnknownData16[0x7];                                       // 0x02C1(0x0007) MISSED OFFSET
	unsigned char                                      UnknownData17[0x10];                                      // 0x02C1(0x0010) UNKNOWN PROPERTY: VerseDynamicProperty CompanionAI.task_companion_ai$HandleGoTo_L_Nping__info_R.$ExprResult_22
	unsigned char                                      UnknownData18[0x10];                                      // 0x02D8(0x0010) UNKNOWN PROPERTY: VerseDynamicProperty CompanionAI.task_companion_ai$HandleGoTo_L_Nping__info_R.$ExprResult_23
	unsigned char                                      UnknownData19[0x10];                                      // 0x02E8(0x0010) UNKNOWN PROPERTY: VerseDynamicProperty CompanionAI.task_companion_ai$HandleGoTo_L_Nping__info_R.InvokeResultDummy_24
	unsigned char                                      UnknownData20[0x11];                                      // 0x02F8(0x0011) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$HandleGoTo_L_Nping__info_R.$ExprResultStack_25
	unsigned char                                      UnknownData21[0x7];                                       // 0x0309(0x0007) MISSED OFFSET
	unsigned char                                      UnknownData22[0x10];                                      // 0x0309(0x0010) UNKNOWN PROPERTY: VerseDynamicProperty CompanionAI.task_companion_ai$HandleGoTo_L_Nping__info_R.$ExprResult_26
	unsigned char                                      UnknownData23[0x10];                                      // 0x0320(0x0010) UNKNOWN PROPERTY: VerseDynamicProperty CompanionAI.task_companion_ai$HandleGoTo_L_Nping__info_R.$ExprResult_27
	unsigned char                                      UnknownData24[0x10];                                      // 0x0330(0x0010) UNKNOWN PROPERTY: VerseDynamicProperty CompanionAI.task_companion_ai$HandleGoTo_L_Nping__info_R.InvokeResultDummy_28
	unsigned char                                      UnknownData25[0x11];                                      // 0x0340(0x0011) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$HandleGoTo_L_Nping__info_R.$ExprResultStack_29
	unsigned char                                      UnknownData26[0x7];                                       // 0x0351(0x0007) MISSED OFFSET
	unsigned char                                      UnknownData27[0x10];                                      // 0x0351(0x0010) UNKNOWN PROPERTY: VerseDynamicProperty CompanionAI.task_companion_ai$HandleGoTo_L_Nping__info_R.$ExprResult_30
	unsigned char                                      UnknownData28[0x10];                                      // 0x0368(0x0010) UNKNOWN PROPERTY: VerseDynamicProperty CompanionAI.task_companion_ai$HandleGoTo_L_Nping__info_R.$ExprResult_31
	int64_t                                            $AsyncBeginCount_32;                                      // 0x0378(0x0008) (ZeroConstructor, IsPlainOldData)
	class task_t_*                                     $AsyncTask_33;                                            // 0x0380(0x0008) (ZeroConstructor)
	struct FScriptDelegate                             $AsyncTaskClass_34;                                       // 0x0388(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData29[0x4];                                       // 0x0394(0x0004) MISSED OFFSET
	struct Ftuple_Lvector3_M_Qfort__character_Mlogic_M_QNavigationParameters_Nnavigation__parameters_20_3d_20_2e_2e_2e_R $ExprResult_35;                                           // 0x0398(0x0040)
	struct Ftuple_Lvector3_M_Qfalse_Mlogic_M_QNavigationParameters_Nnavigation__parameters_R __verse_0x00000000__5;                                    // 0x03D8(0x0038)
	unsigned char                                      UnknownData30[0x2];                                       // 0x0410(0x0002) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$HandleGoTo_L_Nping__info_R.$ExprResult_36
	unsigned char                                      UnknownData31[0x6];                                       // 0x0412(0x0006) MISSED OFFSET
	unsigned char                                      UnknownData32[0x11];                                      // 0x0412(0x0011) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$HandleGoTo_L_Nping__info_R.$ExprResult_37
	unsigned char                                      UnknownData33[0x7];                                       // 0x0429(0x0007) MISSED OFFSET
	struct Fnavigation_parameters                      $ExprResult_38;                                           // 0x0430(0x0010)
	unsigned char                                      UnknownData34[0x8];                                       // 0x0440(0x0008) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$HandleGoTo_L_Nping__info_R.$ExprResult_39
	unsigned char                                      UnknownData35[0x2];                                       // 0x0448(0x0002) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$HandleGoTo_L_Nping__info_R.__verse_0x00000000__6
	unsigned char                                      $ExprResult_40 : 1;                                       // 0x044A(0x0001)
	unsigned char                                      UnknownData36[0x2];                                       // 0x044B(0x0002) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$HandleGoTo_L_Nping__info_R.$ExprResultStack_41
	unsigned char                                      UnknownData37[0x3];                                       // 0x044D(0x0003) MISSED OFFSET
	int64_t                                            $AsyncResult_42;                                          // 0x0450(0x0008) (ZeroConstructor, IsPlainOldData)
	class task_t_*                                     $AsyncTask_43;                                            // 0x0458(0x0008) (ZeroConstructor)
	struct FScriptDelegate                             $AsyncTaskClass_44;                                       // 0x0460(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData38[0x4];                                       // 0x046C(0x0004) MISSED OFFSET
	int64_t                                            $AsyncResult_45;                                          // 0x0470(0x0008) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData39[0x2];                                       // 0x0478(0x0002) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$HandleGoTo_L_Nping__info_R.$ExprResultStack_46
	unsigned char                                      UnknownData40[0x6];                                       // 0x047A(0x0006) MISSED OFFSET
	class task_t_*                                     $AsyncTask_47;                                            // 0x0480(0x0008) (ZeroConstructor)
	struct FScriptDelegate                             $AsyncTaskClass_48;                                       // 0x0488(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData41[0x4];                                       // 0x0494(0x0004) MISSED OFFSET
	struct Ftuple_Lvector3_M_Qfort__character_Mlogic_M_QNavigationParameters_Nnavigation__parameters_20_3d_20_2e_2e_2e_R $ExprResult_49;                                           // 0x0498(0x0040)
	struct Ftuple_Lvector3_M_Qfalse_Mlogic_M_QNavigationParameters_Nnavigation__parameters_R __verse_0x00000000__9;                                    // 0x04D8(0x0038)
	unsigned char                                      UnknownData42[0x2];                                       // 0x0510(0x0002) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$HandleGoTo_L_Nping__info_R.$ExprResult_50
	unsigned char                                      UnknownData43[0x6];                                       // 0x0512(0x0006) MISSED OFFSET
	unsigned char                                      UnknownData44[0x11];                                      // 0x0512(0x0011) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$HandleGoTo_L_Nping__info_R.$ExprResult_51
	unsigned char                                      UnknownData45[0x7];                                       // 0x0529(0x0007) MISSED OFFSET
	struct Fnavigation_parameters                      $ExprResult_52;                                           // 0x0530(0x0010)
	unsigned char                                      UnknownData46[0x8];                                       // 0x0540(0x0008) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$HandleGoTo_L_Nping__info_R.$ExprResult_53
	unsigned char                                      UnknownData47[0x2];                                       // 0x0548(0x0002) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$HandleGoTo_L_Nping__info_R.__verse_0x00000000__10
	unsigned char                                      $ExprResult_54 : 1;                                       // 0x054A(0x0001)
	unsigned char                                      UnknownData48[0x2];                                       // 0x054B(0x0002) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$HandleGoTo_L_Nping__info_R.$ExprResultStack_55
	unsigned char                                      UnknownData49[0x3];                                       // 0x054D(0x0003) MISSED OFFSET
	int64_t                                            $AsyncResult_56;                                          // 0x0550(0x0008) (ZeroConstructor, IsPlainOldData)
	class task_t_*                                     $AsyncTask_57;                                            // 0x0558(0x0008) (ZeroConstructor)
	struct FScriptDelegate                             $AsyncTaskClass_58;                                       // 0x0560(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData50[0x4];                                       // 0x056C(0x0004) MISSED OFFSET
	int64_t                                            $AsyncResult_59;                                          // 0x0570(0x0008) (ZeroConstructor, IsPlainOldData)
	class task_t_*                                     $AsyncTask_60;                                            // 0x0578(0x0008) (ZeroConstructor)
	struct FScriptDelegate                             $AsyncTaskClass_61;                                       // 0x0580(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData51[0x4];                                       // 0x058C(0x0004) MISSED OFFSET
	struct Ftuple_Lvector3_M_Qfort__character_Mlogic_M_QNavigationParameters_Nnavigation__parameters_20_3d_20_2e_2e_2e_R $ExprResult_62;                                           // 0x0590(0x0040)
	struct Ftuple_Lvector3_M_Qfalse_Mlogic_M_QNavigationParameters_Nnavigation__parameters_R __verse_0x00000000__13;                                   // 0x05D0(0x0038)
	unsigned char                                      UnknownData52[0x2];                                       // 0x0608(0x0002) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$HandleGoTo_L_Nping__info_R.$ExprResult_63
	unsigned char                                      UnknownData53[0x6];                                       // 0x060A(0x0006) MISSED OFFSET
	unsigned char                                      UnknownData54[0x11];                                      // 0x060A(0x0011) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$HandleGoTo_L_Nping__info_R.$ExprResult_64
	unsigned char                                      UnknownData55[0x7];                                       // 0x0621(0x0007) MISSED OFFSET
	struct Fnavigation_parameters                      $ExprResult_65;                                           // 0x0628(0x0010)
	unsigned char                                      UnknownData56[0x8];                                       // 0x0638(0x0008) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$HandleGoTo_L_Nping__info_R.$ExprResult_66
	unsigned char                                      UnknownData57[0x2];                                       // 0x0640(0x0002) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$HandleGoTo_L_Nping__info_R.__verse_0x00000000__14
	unsigned char                                      $ExprResult_67 : 1;                                       // 0x0642(0x0001)
	unsigned char                                      UnknownData58[0x2];                                       // 0x0643(0x0002) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$HandleGoTo_L_Nping__info_R.$ExprResultStack_68
	unsigned char                                      UnknownData59[0x3];                                       // 0x0645(0x0003) MISSED OFFSET
	int64_t                                            $AsyncResult_69;                                          // 0x0648(0x0008) (ZeroConstructor, IsPlainOldData)
	class task_t_*                                     $AsyncTask_70;                                            // 0x0650(0x0008) (ZeroConstructor)
	struct FScriptDelegate                             $AsyncTaskClass_71;                                       // 0x0658(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData60[0x4];                                       // 0x0664(0x0004) MISSED OFFSET
	int64_t                                            $AsyncResult_72;                                          // 0x0668(0x0008) (ZeroConstructor, IsPlainOldData)
	EVerseTrue                                         $InvokeSureResultDummy_73;                                // 0x0670(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData61[0x3];                                       // 0x0671(0x0003) MISSED OFFSET
	struct FScriptDelegate                             $Callee_74;                                               // 0x0674(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData62[0x10];                                      // 0x0680(0x0010) UNKNOWN PROPERTY: VerseStringProperty CompanionAI.task_companion_ai$HandleGoTo_L_Nping__info_R.$ExprResult_75

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("VerseClass CompanionAI.task_companion_ai$HandleGoTo_L_Nping__info_R"));
		
		return ptr;
	}


	int64_t Update();
};


// VerseClass CompanionAI.task_companion_ai$HandleGoToCommand_L_Nping__info_R
// 0x0408 (0x0528 - 0x0120)
class task_companion_ai$HandleGoToCommand_L_Nping__info_R : public task_t_
{
public:
	class companion_ai*                                _Self;                                                    // 0x0120(0x0008) (Parm, ZeroConstructor)
	struct Fping_info                                  __verse_0xB2CDDD72_Argument;                              // 0x0128(0x0038) (Parm)
	EVerseTrue                                         $InvokeSureResultDummy_0;                                 // 0x0160(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0161(0x0003) MISSED OFFSET
	struct FScriptDelegate                             $Callee_1;                                                // 0x0164(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData01[0x10];                                      // 0x0170(0x0010) UNKNOWN PROPERTY: VerseStringProperty CompanionAI.task_companion_ai$HandleGoToCommand_L_Nping__info_R.$ExprResult_2
	class Entity*                                      __verse_0xFD64D7AA_Emitter_2;                             // 0x0180(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	unsigned char                                      UnknownData02[0x8];                                       // 0x0188(0x0008) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$HandleGoToCommand_L_Nping__info_R.$ExprResultStack_3
	int64_t                                            $AsyncBeginCount_4;                                       // 0x0190(0x0008) (ZeroConstructor, IsPlainOldData)
	class task_t_*                                     $AsyncTask_5;                                             // 0x0198(0x0008) (ZeroConstructor)
	struct FScriptDelegate                             $AsyncTaskClass_6;                                        // 0x01A0(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData03[0x4];                                       // 0x01AC(0x0004) MISSED OFFSET
	struct Ftuple_Lvector3_Mfloat_Mentity_R            $ExprResult_7;                                            // 0x01B0(0x0028)
	int64_t                                            $AsyncResult_8;                                           // 0x01D8(0x0008) (ZeroConstructor, IsPlainOldData)
	class task_t_*                                     $AsyncTask_9;                                             // 0x01E0(0x0008) (ZeroConstructor)
	struct FScriptDelegate                             $AsyncTaskClass_10;                                       // 0x01E8(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData04[0x4];                                       // 0x01F4(0x0004) MISSED OFFSET
	int64_t                                            $AsyncResult_11;                                          // 0x01F8(0x0008) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData05[0x39];                                      // 0x0200(0x0039) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$HandleGoToCommand_L_Nping__info_R.__verse_0x1EB80E5B_ThreatInfo_3
	unsigned char                                      UnknownData06[0x3];                                       // 0x0239(0x0003) MISSED OFFSET
	struct FScriptDelegate                             $AsyncTaskClass_12;                                       // 0x023C(0x0010) (ZeroConstructor)
	struct FCompanionAI_Ftuple_L_R                     $ExprResult_13;                                           // 0x0248(0x0001)
	unsigned char                                      UnknownData07[0x7];                                       // 0x0249(0x0007) MISSED OFFSET
	int64_t                                            $AsyncBeginCount_14;                                      // 0x0250(0x0008) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData08[0x39];                                      // 0x0258(0x0039) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$HandleGoToCommand_L_Nping__info_R.$ExprResult_15
	unsigned char                                      UnknownData09[0x7];                                       // 0x0291(0x0007) MISSED OFFSET
	class task_t_*                                     $AsyncTask_16;                                            // 0x0298(0x0008) (ZeroConstructor)
	struct FScriptDelegate                             $AsyncTaskClass_17;                                       // 0x02A0(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData10[0x4];                                       // 0x02AC(0x0004) MISSED OFFSET
	int64_t                                            $AsyncResult_18;                                          // 0x02B0(0x0008) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData11[0x39];                                      // 0x02B8(0x0039) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$HandleGoToCommand_L_Nping__info_R.$ExprResult_19
	unsigned char                                      UnknownData12[0x7];                                       // 0x02F1(0x0007) MISSED OFFSET
	class task_t_*                                     $AsyncTask_20;                                            // 0x02F8(0x0008) (ZeroConstructor)
	struct FScriptDelegate                             $AsyncTaskClass_21;                                       // 0x0300(0x0010) (ZeroConstructor)
	struct FCompanionAI_Ftuple_L_R                     $ExprResult_22;                                           // 0x030C(0x0001)
	unsigned char                                      UnknownData13[0x3];                                       // 0x030D(0x0003) MISSED OFFSET
	int64_t                                            $AsyncResult_23;                                          // 0x0310(0x0008) (ZeroConstructor, IsPlainOldData)
	struct Fthreat_info                                __verse_0xD4ED8431_Threat_4;                              // 0x0318(0x0038)
	unsigned char                                      UnknownData14[0x39];                                      // 0x0350(0x0039) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$HandleGoToCommand_L_Nping__info_R.$ExprResultStack_24
	unsigned char                                      UnknownData15[0x7];                                       // 0x0389(0x0007) MISSED OFFSET
	unsigned char                                      UnknownData16[0x10];                                      // 0x0389(0x0010) UNKNOWN PROPERTY: VerseDynamicProperty CompanionAI.task_companion_ai$HandleGoToCommand_L_Nping__info_R.InvokeResultDummy_25
	unsigned char                                      UnknownData17[0x11];                                      // 0x03A0(0x0011) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$HandleGoToCommand_L_Nping__info_R.$ExprResultStack_26
	unsigned char                                      UnknownData18[0x7];                                       // 0x03B1(0x0007) MISSED OFFSET
	unsigned char                                      UnknownData19[0x10];                                      // 0x03B1(0x0010) UNKNOWN PROPERTY: VerseDynamicProperty CompanionAI.task_companion_ai$HandleGoToCommand_L_Nping__info_R.$ExprResult_27
	unsigned char                                      UnknownData20[0x10];                                      // 0x03C8(0x0010) UNKNOWN PROPERTY: VerseDynamicProperty CompanionAI.task_companion_ai$HandleGoToCommand_L_Nping__info_R.$ExprResult_28
	class task_t_*                                     $AsyncTask_29;                                            // 0x03D8(0x0008) (ZeroConstructor)
	struct FScriptDelegate                             $AsyncTaskClass_30;                                       // 0x03E0(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData21[0x4];                                       // 0x03EC(0x0004) MISSED OFFSET
	int64_t                                            $AsyncResult_31;                                          // 0x03F0(0x0008) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData22[0x39];                                      // 0x03F8(0x0039) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$HandleGoToCommand_L_Nping__info_R.$ExprResultStack_32
	unsigned char                                      UnknownData23[0x3];                                       // 0x0431(0x0003) MISSED OFFSET
	struct FScriptDelegate                             $AsyncTaskClass_33;                                       // 0x0434(0x0010) (ZeroConstructor)
	struct FCompanionAI_Ftuple_L_R                     $ExprResult_34;                                           // 0x0440(0x0001)
	unsigned char                                      UnknownData24[0x3];                                       // 0x0441(0x0003) MISSED OFFSET
	struct FScriptDelegate                             $AsyncTaskClass_35;                                       // 0x0444(0x0010) (ZeroConstructor)
	struct Ftuple_Lvector3_Mtype_7b0_2e500000_7d_Mtype_7b1_2e500000_7d_R $ExprResult_36;                                           // 0x0450(0x0028)
	unsigned char                                      UnknownData25[0x9];                                       // 0x0478(0x0009) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$HandleGoToCommand_L_Nping__info_R.$ExprResultStack_37
	unsigned char                                      UnknownData26[0x7];                                       // 0x0481(0x0007) MISSED OFFSET
	double                                             $ExprResultStack_38;                                      // 0x0488(0x0008) (ZeroConstructor, IsPlainOldData)
	struct FScriptDelegate                             $Callee_39;                                               // 0x0490(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData27[0x4];                                       // 0x049C(0x0004) MISSED OFFSET
	struct FCompanionAI_Ftuple_Lvector3_Mvector3_R     $ExprResult_40;                                           // 0x04A0(0x0030)
	struct Fvector3                                    $ExprResult_41;                                           // 0x04D0(0x0018) (ZeroConstructor, IsPlainOldData)
	class Object_32759*                                __verse_0x00000000__10;                                   // 0x04E8(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	unsigned char                                      UnknownData28[0x8];                                       // 0x04F0(0x0008) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$HandleGoToCommand_L_Nping__info_R.$ExprResultStack_42
	struct FScriptDelegate                             $Callee_43;                                               // 0x04F8(0x0010) (ZeroConstructor)
	struct FCompanionAI_Ftuple_L_R                     $ExprResult_44;                                           // 0x0504(0x0001)
	EVerseTrue                                         $InvokeSureResultDummy_45;                                // 0x0505(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData29[0x2];                                       // 0x0506(0x0002) MISSED OFFSET
	struct FScriptDelegate                             $Callee_46;                                               // 0x0508(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData30[0x4];                                       // 0x0514(0x0004) MISSED OFFSET
	unsigned char                                      UnknownData31[0x10];                                      // 0x0514(0x0010) UNKNOWN PROPERTY: VerseStringProperty CompanionAI.task_companion_ai$HandleGoToCommand_L_Nping__info_R.$ExprResult_47

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("VerseClass CompanionAI.task_companion_ai$HandleGoToCommand_L_Nping__info_R"));
		
		return ptr;
	}


	int64_t Update();
};


// VerseClass CompanionAI.task_companion_ai$HandleHoldPositionCommand_L_Nping__info_R
// 0x0160 (0x0280 - 0x0120)
class task_companion_ai$HandleHoldPositionCommand_L_Nping__info_R : public task_t_
{
public:
	class companion_ai*                                _Self;                                                    // 0x0120(0x0008) (Parm, ZeroConstructor)
	struct Fping_info                                  __verse_0xB2CDDD72_Argument;                              // 0x0128(0x0038) (Parm)
	EVerseTrue                                         $InvokeSureResultDummy_0;                                 // 0x0160(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0161(0x0003) MISSED OFFSET
	struct FScriptDelegate                             $Callee_1;                                                // 0x0164(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData01[0x10];                                      // 0x0170(0x0010) UNKNOWN PROPERTY: VerseStringProperty CompanionAI.task_companion_ai$HandleHoldPositionCommand_L_Nping__info_R.$ExprResult_2
	struct Fvector3                                    __verse_0x60C61594_CurrentPosition_1;                     // 0x0180(0x0018) (ZeroConstructor, IsPlainOldData)
	struct Fvector3                                    $ExprResult_3;                                            // 0x0198(0x0018) (ZeroConstructor, IsPlainOldData)
	class Object_32759*                                __verse_0x00000000__3;                                    // 0x01B0(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	unsigned char                                      UnknownData02[0x8];                                       // 0x01B8(0x0008) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$HandleHoldPositionCommand_L_Nping__info_R.$ExprResultStack_4
	struct FScriptDelegate                             $Callee_5;                                                // 0x01C0(0x0010) (ZeroConstructor)
	struct FCompanionAI_Ftuple_L_R                     $ExprResult_6;                                            // 0x01CC(0x0001)
	unsigned char                                      UnknownData03[0x3];                                       // 0x01CD(0x0003) MISSED OFFSET
	class Entity*                                      __verse_0xFD64D7AA_Emitter_4;                             // 0x01D0(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	unsigned char                                      UnknownData04[0x8];                                       // 0x01D8(0x0008) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$HandleHoldPositionCommand_L_Nping__info_R.$ExprResultStack_7
	int64_t                                            $AsyncBeginCount_8;                                       // 0x01E0(0x0008) (ZeroConstructor, IsPlainOldData)
	class task_t_*                                     $AsyncTask_9;                                             // 0x01E8(0x0008) (ZeroConstructor)
	struct FScriptDelegate                             $AsyncTaskClass_10;                                       // 0x01F0(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData05[0x4];                                       // 0x01FC(0x0004) MISSED OFFSET
	struct Ftuple_Lvector3_Mfloat_Mentity_R            $ExprResult_11;                                           // 0x0200(0x0028)
	int64_t                                            $AsyncResult_12;                                          // 0x0228(0x0008) (ZeroConstructor, IsPlainOldData)
	class task_t_*                                     $AsyncTask_13;                                            // 0x0230(0x0008) (ZeroConstructor)
	struct FScriptDelegate                             $AsyncTaskClass_14;                                       // 0x0238(0x0010) (ZeroConstructor)
	struct FCompanionAI_Ftuple_L_R                     $ExprResult_15;                                           // 0x0244(0x0001)
	unsigned char                                      UnknownData06[0x3];                                       // 0x0245(0x0003) MISSED OFFSET
	int64_t                                            $AsyncResult_16;                                          // 0x0248(0x0008) (ZeroConstructor, IsPlainOldData)
	struct FScriptDelegate                             $AsyncTaskClass_17;                                       // 0x0250(0x0010) (ZeroConstructor)
	struct FCompanionAI_Ftuple_L_R                     $ExprResult_18;                                           // 0x025C(0x0001)
	EVerseTrue                                         $InvokeSureResultDummy_19;                                // 0x025D(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData07[0x2];                                       // 0x025E(0x0002) MISSED OFFSET
	struct FScriptDelegate                             $Callee_20;                                               // 0x0260(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData08[0x4];                                       // 0x026C(0x0004) MISSED OFFSET
	unsigned char                                      UnknownData09[0x10];                                      // 0x026C(0x0010) UNKNOWN PROPERTY: VerseStringProperty CompanionAI.task_companion_ai$HandleHoldPositionCommand_L_Nping__info_R.$ExprResult_21

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("VerseClass CompanionAI.task_companion_ai$HandleHoldPositionCommand_L_Nping__info_R"));
		
		return ptr;
	}


	int64_t Update();
};


// VerseClass CompanionAI.task_companion_ai$HandleNPCCommand_L_Nping__info_R
// 0x04A8 (0x05C8 - 0x0120)
class task_companion_ai$HandleNPCCommand_L_Nping__info_R : public task_t_
{
public:
	class companion_ai*                                _Self;                                                    // 0x0120(0x0008) (Parm, ZeroConstructor)
	struct Fping_info                                  __verse_0xB2CDDD72_Argument;                              // 0x0128(0x0038) (Parm)
	EVerseTrue                                         $InvokeSureResultDummy_0;                                 // 0x0160(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0161(0x0003) MISSED OFFSET
	struct FScriptDelegate                             $Callee_1;                                                // 0x0164(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData01[0x10];                                      // 0x0170(0x0010) UNKNOWN PROPERTY: VerseStringProperty CompanionAI.task_companion_ai$HandleNPCCommand_L_Nping__info_R.$ExprResult_2
	unsigned char                                      UnknownData02[0x10];                                      // 0x0180(0x0010) UNKNOWN PROPERTY: ArrayProperty CompanionAI.task_companion_ai$HandleNPCCommand_L_Nping__info_R.__verse_0xFFC68BC5_Array_2
	struct FScriptDelegate                             $Callee_3;                                                // 0x0190(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData03[0x4];                                       // 0x019C(0x0004) MISSED OFFSET
	unsigned char                                      UnknownData04[0x10];                                      // 0x019C(0x0010) UNKNOWN PROPERTY: ArrayProperty CompanionAI.task_companion_ai$HandleNPCCommand_L_Nping__info_R.$ExprResult_4
	unsigned char                                      UnknownData05[0x10];                                      // 0x01B0(0x0010) UNKNOWN PROPERTY: ArrayProperty CompanionAI.task_companion_ai$HandleNPCCommand_L_Nping__info_R.__verse_0xFFC68BC5_Array_3
	struct Ftuple_L_Kchar_M_Kchar_M_Kchar_M_Kchar_R    __verse_0x00000000__4;                                    // 0x01C0(0x0040)
	unsigned char                                      UnknownData06[0x10];                                      // 0x0200(0x0010) UNKNOWN PROPERTY: VerseStringProperty CompanionAI.task_companion_ai$HandleNPCCommand_L_Nping__info_R.$ExprResult_5
	unsigned char                                      UnknownData07[0x10];                                      // 0x0210(0x0010) UNKNOWN PROPERTY: VerseStringProperty CompanionAI.task_companion_ai$HandleNPCCommand_L_Nping__info_R.$ExprResultStack_6
	struct FScriptDelegate                             $Callee_7;                                                // 0x0220(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData08[0x4];                                       // 0x022C(0x0004) MISSED OFFSET
	unsigned char                                      UnknownData09[0x10];                                      // 0x022C(0x0010) UNKNOWN PROPERTY: VerseStringProperty CompanionAI.task_companion_ai$HandleNPCCommand_L_Nping__info_R.$ExprResultStack_8
	struct FScriptDelegate                             $Callee_9;                                                // 0x0240(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData10[0x4];                                       // 0x024C(0x0004) MISSED OFFSET
	unsigned char                                      UnknownData11[0x10];                                      // 0x024C(0x0010) UNKNOWN PROPERTY: VerseStringProperty CompanionAI.task_companion_ai$HandleNPCCommand_L_Nping__info_R.$ExprResult_10
	unsigned char                                      UnknownData12[0x10];                                      // 0x0260(0x0010) UNKNOWN PROPERTY: VerseStringProperty CompanionAI.task_companion_ai$HandleNPCCommand_L_Nping__info_R.$ExprResultStack_11
	struct FScriptDelegate                             $Callee_12;                                               // 0x0270(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData13[0x4];                                       // 0x027C(0x0004) MISSED OFFSET
	unsigned char                                      UnknownData14[0x10];                                      // 0x027C(0x0010) UNKNOWN PROPERTY: VerseStringProperty CompanionAI.task_companion_ai$HandleNPCCommand_L_Nping__info_R.$ExprResultStack_13
	struct FScriptDelegate                             $Callee_14;                                               // 0x0290(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData15[0x4];                                       // 0x029C(0x0004) MISSED OFFSET
	unsigned char                                      UnknownData16[0x10];                                      // 0x029C(0x0010) UNKNOWN PROPERTY: VerseStringProperty CompanionAI.task_companion_ai$HandleNPCCommand_L_Nping__info_R.$ExprResultDummy_15
	unsigned char                                      UnknownData17[0x10];                                      // 0x02B0(0x0010) UNKNOWN PROPERTY: VerseStringProperty CompanionAI.task_companion_ai$HandleNPCCommand_L_Nping__info_R.$ExprResultDummy_16
	unsigned char                                      UnknownData18[0x10];                                      // 0x02C0(0x0010) UNKNOWN PROPERTY: VerseStringProperty CompanionAI.task_companion_ai$HandleNPCCommand_L_Nping__info_R.$ExprResultDummy_17
	unsigned char                                      UnknownData19[0x10];                                      // 0x02D0(0x0010) UNKNOWN PROPERTY: VerseStringProperty CompanionAI.task_companion_ai$HandleNPCCommand_L_Nping__info_R.$ExprResultDummy_18
	unsigned char                                      UnknownData20[0x10];                                      // 0x02E0(0x0010) UNKNOWN PROPERTY: ArrayProperty CompanionAI.task_companion_ai$HandleNPCCommand_L_Nping__info_R.$ForResult_19
	int64_t                                            $ForIndex_20;                                             // 0x02F0(0x0008) (ZeroConstructor, IsPlainOldData)
	int64_t                                            $ForLength_21;                                            // 0x02F8(0x0008) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData21[0x10];                                      // 0x0300(0x0010) UNKNOWN PROPERTY: VerseStringProperty CompanionAI.task_companion_ai$HandleNPCCommand_L_Nping__info_R.__verse_0xFB88B569_Item_6
	unsigned char                                      UnknownData22[0x10];                                      // 0x0310(0x0010) UNKNOWN PROPERTY: ArrayProperty CompanionAI.task_companion_ai$HandleNPCCommand_L_Nping__info_R.$ExprResult_22
	unsigned char                                      UnknownData23[0x10];                                      // 0x0320(0x0010) UNKNOWN PROPERTY: VerseStringProperty CompanionAI.task_companion_ai$HandleNPCCommand_L_Nping__info_R.__verse_0xFFC68BC5_Array_7
	unsigned char                                      UnknownData24[0x10];                                      // 0x0330(0x0010) UNKNOWN PROPERTY: ArrayProperty CompanionAI.task_companion_ai$HandleNPCCommand_L_Nping__info_R.$ForResult_23
	int64_t                                            $ForIndex_24;                                             // 0x0340(0x0008) (ZeroConstructor, IsPlainOldData)
	int64_t                                            $ForLength_25;                                            // 0x0348(0x0008) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      __verse_0xFB88B569_Item_9;                                // 0x0350(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData25[0x7];                                       // 0x0351(0x0007) MISSED OFFSET
	unsigned char                                      UnknownData26[0x10];                                      // 0x0351(0x0010) UNKNOWN PROPERTY: VerseDynamicProperty CompanionAI.task_companion_ai$HandleNPCCommand_L_Nping__info_R.$ExprResult_26
	unsigned char                                      UnknownData27[0x10];                                      // 0x0368(0x0010) UNKNOWN PROPERTY: VerseStringProperty CompanionAI.task_companion_ai$HandleNPCCommand_L_Nping__info_R.$ForResult_27
	int64_t                                            $ForIndex_28;                                             // 0x0378(0x0008) (ZeroConstructor, IsPlainOldData)
	int64_t                                            $ForLength_29;                                            // 0x0380(0x0008) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData28[0x10];                                      // 0x0388(0x0010) UNKNOWN PROPERTY: VerseDynamicProperty CompanionAI.task_companion_ai$HandleNPCCommand_L_Nping__info_R.__verse_0xFB88B569_Item_11
	unsigned char                                      $ExprResult_30;                                           // 0x0398(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData29[0x7];                                       // 0x0399(0x0007) MISSED OFFSET
	unsigned char                                      UnknownData30[0x10];                                      // 0x0399(0x0010) UNKNOWN PROPERTY: VerseDynamicProperty CompanionAI.task_companion_ai$HandleNPCCommand_L_Nping__info_R.InvokeResultDummy_31
	unsigned char                                      UnknownData31[0x11];                                      // 0x03B0(0x0011) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$HandleNPCCommand_L_Nping__info_R.$ExprResultStack_32
	unsigned char                                      UnknownData32[0x7];                                       // 0x03C1(0x0007) MISSED OFFSET
	unsigned char                                      UnknownData33[0x10];                                      // 0x03C1(0x0010) UNKNOWN PROPERTY: VerseDynamicProperty CompanionAI.task_companion_ai$HandleNPCCommand_L_Nping__info_R.$ExprResult_33
	unsigned char                                      UnknownData34[0x10];                                      // 0x03D8(0x0010) UNKNOWN PROPERTY: VerseDynamicProperty CompanionAI.task_companion_ai$HandleNPCCommand_L_Nping__info_R.$ExprResult_34
	class task_t_*                                     $AsyncTask_35;                                            // 0x03E8(0x0008) (ZeroConstructor)
	struct FScriptDelegate                             $AsyncTaskClass_36;                                       // 0x03F0(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData35[0x4];                                       // 0x03FC(0x0004) MISSED OFFSET
	int64_t                                            $AsyncResult_37;                                          // 0x0400(0x0008) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData36[0x10];                                      // 0x0408(0x0010) UNKNOWN PROPERTY: VerseDynamicProperty CompanionAI.task_companion_ai$HandleNPCCommand_L_Nping__info_R.InvokeResultDummy_38
	unsigned char                                      UnknownData37[0x11];                                      // 0x0418(0x0011) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$HandleNPCCommand_L_Nping__info_R.$ExprResultStack_39
	unsigned char                                      UnknownData38[0x7];                                       // 0x0429(0x0007) MISSED OFFSET
	unsigned char                                      UnknownData39[0x10];                                      // 0x0429(0x0010) UNKNOWN PROPERTY: VerseDynamicProperty CompanionAI.task_companion_ai$HandleNPCCommand_L_Nping__info_R.$ExprResult_40
	unsigned char                                      UnknownData40[0x10];                                      // 0x0440(0x0010) UNKNOWN PROPERTY: VerseDynamicProperty CompanionAI.task_companion_ai$HandleNPCCommand_L_Nping__info_R.$ExprResult_41
	struct FScriptDelegate                             $AsyncTaskClass_42;                                       // 0x0450(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData41[0x4];                                       // 0x045C(0x0004) MISSED OFFSET
	unsigned char                                      UnknownData42[0x10];                                      // 0x045C(0x0010) UNKNOWN PROPERTY: VerseDynamicProperty CompanionAI.task_companion_ai$HandleNPCCommand_L_Nping__info_R.InvokeResultDummy_43
	unsigned char                                      UnknownData43[0x11];                                      // 0x0470(0x0011) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$HandleNPCCommand_L_Nping__info_R.$ExprResultStack_44
	unsigned char                                      UnknownData44[0x7];                                       // 0x0481(0x0007) MISSED OFFSET
	unsigned char                                      UnknownData45[0x10];                                      // 0x0481(0x0010) UNKNOWN PROPERTY: VerseDynamicProperty CompanionAI.task_companion_ai$HandleNPCCommand_L_Nping__info_R.$ExprResult_45
	unsigned char                                      UnknownData46[0x10];                                      // 0x0498(0x0010) UNKNOWN PROPERTY: VerseDynamicProperty CompanionAI.task_companion_ai$HandleNPCCommand_L_Nping__info_R.$ExprResult_46
	struct FScriptDelegate                             $AsyncTaskClass_47;                                       // 0x04A8(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData47[0x4];                                       // 0x04B4(0x0004) MISSED OFFSET
	unsigned char                                      UnknownData48[0x10];                                      // 0x04B4(0x0010) UNKNOWN PROPERTY: VerseDynamicProperty CompanionAI.task_companion_ai$HandleNPCCommand_L_Nping__info_R.InvokeResultDummy_48
	unsigned char                                      UnknownData49[0x11];                                      // 0x04C8(0x0011) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$HandleNPCCommand_L_Nping__info_R.$ExprResultStack_49
	unsigned char                                      UnknownData50[0x7];                                       // 0x04D9(0x0007) MISSED OFFSET
	unsigned char                                      UnknownData51[0x10];                                      // 0x04D9(0x0010) UNKNOWN PROPERTY: VerseDynamicProperty CompanionAI.task_companion_ai$HandleNPCCommand_L_Nping__info_R.$ExprResult_50
	unsigned char                                      UnknownData52[0x10];                                      // 0x04F0(0x0010) UNKNOWN PROPERTY: VerseDynamicProperty CompanionAI.task_companion_ai$HandleNPCCommand_L_Nping__info_R.$ExprResult_51
	struct FScriptDelegate                             $AsyncTaskClass_52;                                       // 0x0500(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData53[0x4];                                       // 0x050C(0x0004) MISSED OFFSET
	unsigned char                                      UnknownData54[0x10];                                      // 0x050C(0x0010) UNKNOWN PROPERTY: VerseDynamicProperty CompanionAI.task_companion_ai$HandleNPCCommand_L_Nping__info_R.InvokeResultDummy_53
	unsigned char                                      UnknownData55[0x11];                                      // 0x0520(0x0011) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$HandleNPCCommand_L_Nping__info_R.$ExprResultStack_54
	unsigned char                                      UnknownData56[0x7];                                       // 0x0531(0x0007) MISSED OFFSET
	unsigned char                                      UnknownData57[0x10];                                      // 0x0531(0x0010) UNKNOWN PROPERTY: VerseDynamicProperty CompanionAI.task_companion_ai$HandleNPCCommand_L_Nping__info_R.$ExprResult_55
	unsigned char                                      UnknownData58[0x10];                                      // 0x0548(0x0010) UNKNOWN PROPERTY: VerseDynamicProperty CompanionAI.task_companion_ai$HandleNPCCommand_L_Nping__info_R.$ExprResult_56
	class Object_32759*                                __verse_0xE8036CC4_AIActions_17;                          // 0x0558(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	unsigned char                                      UnknownData59[0x8];                                       // 0x0560(0x0008) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$HandleNPCCommand_L_Nping__info_R.$ExprResultStack_57
	class Object_32759*                                __verse_0x00000000__19;                                   // 0x0568(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	struct FScriptDelegate                             $AsyncTaskClass_58;                                       // 0x0570(0x0010) (ZeroConstructor)
	struct FCompanionAI_Ftuple_L_R                     $ExprResult_59;                                           // 0x057C(0x0001)
	unsigned char                                      UnknownData60[0x3];                                       // 0x057D(0x0003) MISSED OFFSET
	class Object_32759*                                __verse_0xB4DBB24F_PingActions_20;                        // 0x0580(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	unsigned char                                      UnknownData61[0x8];                                       // 0x0588(0x0008) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$HandleNPCCommand_L_Nping__info_R.$ExprResultStack_60
	class Object_32759*                                __verse_0x00000000__21;                                   // 0x0590(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	EVerseTrue                                         $InvokeSureResultDummy_61;                                // 0x0598(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData62[0x3];                                       // 0x0599(0x0003) MISSED OFFSET
	struct FScriptDelegate                             $Callee_62;                                               // 0x059C(0x0010) (ZeroConstructor)
	EVerseTrue                                         $InvokeSureResultDummy_63;                                // 0x05A8(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData63[0x3];                                       // 0x05A9(0x0003) MISSED OFFSET
	struct FScriptDelegate                             $Callee_64;                                               // 0x05AC(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData64[0x10];                                      // 0x05B8(0x0010) UNKNOWN PROPERTY: VerseStringProperty CompanionAI.task_companion_ai$HandleNPCCommand_L_Nping__info_R.$ExprResult_65

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("VerseClass CompanionAI.task_companion_ai$HandleNPCCommand_L_Nping__info_R"));
		
		return ptr;
	}


	int64_t Update();
};


// VerseClass CompanionAI.task_companion_ai$HandleObstacleTask_L_N_Qentity_R
// 0x0200 (0x0320 - 0x0120)
class task_companion_ai$HandleObstacleTask_L_N_Qentity_R : public task_t_
{
public:
	class companion_ai*                                _Self;                                                    // 0x0120(0x0008) (Parm, ZeroConstructor)
	unsigned char                                      UnknownData00[0x8];                                       // 0x0128(0x0008) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$HandleObstacleTask_L_N_Qentity_R.__verse_0xB2CDDD72_Argument
	EVerseTrue                                         $InvokeSureResultDummy_0;                                 // 0x0130(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x3];                                       // 0x0131(0x0003) MISSED OFFSET
	struct FScriptDelegate                             $Callee_1;                                                // 0x0134(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData02[0x10];                                      // 0x0140(0x0010) UNKNOWN PROPERTY: VerseStringProperty CompanionAI.task_companion_ai$HandleObstacleTask_L_N_Qentity_R.$ExprResult_2
	unsigned char                                      UnknownData03[0x29];                                      // 0x0150(0x0029) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$HandleObstacleTask_L_N_Qentity_R.__verse_0x39C5E53E_ObstacleInfo_1
	unsigned char                                      UnknownData04[0x7];                                       // 0x0179(0x0007) MISSED OFFSET
	class task_t_*                                     $AsyncTask_3;                                             // 0x0180(0x0008) (ZeroConstructor)
	struct FScriptDelegate                             $AsyncTaskClass_4;                                        // 0x0188(0x0010) (ZeroConstructor)
	struct FCompanionAI_Ftuple_L_R                     $ExprResult_5;                                            // 0x0194(0x0001)
	unsigned char                                      UnknownData05[0x3];                                       // 0x0195(0x0003) MISSED OFFSET
	int64_t                                            $AsyncResult_6;                                           // 0x0198(0x0008) (ZeroConstructor, IsPlainOldData)
	int64_t                                            $AsyncBeginCount_7;                                       // 0x01A0(0x0008) (ZeroConstructor, IsPlainOldData)
	struct Fobstacle_info                              __verse_0x82A44C52_Obstacle_4;                            // 0x01A8(0x0028)
	unsigned char                                      UnknownData06[0x29];                                      // 0x01D0(0x0029) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$HandleObstacleTask_L_N_Qentity_R.$ExprResultStack_8
	unsigned char                                      UnknownData07[0x7];                                       // 0x01F9(0x0007) MISSED OFFSET
	class Entity*                                      __verse_0xBD80729A_CurrentTarget_5;                       // 0x0200(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	unsigned char                                      UnknownData08[0x8];                                       // 0x0208(0x0008) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$HandleObstacleTask_L_N_Qentity_R.$ExprResultStack_9
	unsigned char                                      UnknownData09[0x2];                                       // 0x0210(0x0002) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$HandleObstacleTask_L_N_Qentity_R.$ExprResultStack_10
	unsigned char                                      $ExprResultStack_11 : 1;                                  // 0x0212(0x0001)
	unsigned char                                      UnknownData10[0x1];                                       // 0x0213(0x0001) MISSED OFFSET
	struct FScriptDelegate                             $Callee_12;                                               // 0x0214(0x0010) (ZeroConstructor)
	struct Ftuple_Lobstacle__info_Mentity_R            $ExprResult_13;                                           // 0x0220(0x0030)
	class task_t_*                                     $AsyncTask_14;                                            // 0x0250(0x0008) (ZeroConstructor)
	struct FScriptDelegate                             $AsyncTaskClass_15;                                       // 0x0258(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData11[0x4];                                       // 0x0264(0x0004) MISSED OFFSET
	int64_t                                            $AsyncResult_16;                                          // 0x0268(0x0008) (ZeroConstructor, IsPlainOldData)
	struct FScriptDelegate                             $AsyncTaskClass_17;                                       // 0x0270(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData12[0x4];                                       // 0x027C(0x0004) MISSED OFFSET
	class Object_32759*                                __verse_0xF161303F_WeaponActions_7;                       // 0x0280(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	unsigned char                                      UnknownData13[0x8];                                       // 0x0288(0x0008) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$HandleObstacleTask_L_N_Qentity_R.$ExprResultStack_18
	class Object_32759*                                __verse_0x00000000__9;                                    // 0x0290(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	struct FScriptDelegate                             $AsyncTaskClass_19;                                       // 0x0298(0x0010) (ZeroConstructor)
	struct FScriptDelegate                             $AsyncTaskClass_20;                                       // 0x02A4(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData14[0x29];                                      // 0x02B0(0x0029) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$HandleObstacleTask_L_N_Qentity_R.$ExprResult_21
	unsigned char                                      UnknownData15[0x7];                                       // 0x02D9(0x0007) MISSED OFFSET
	class task_t_*                                     $AsyncTask_22;                                            // 0x02E0(0x0008) (ZeroConstructor)
	struct FScriptDelegate                             $AsyncTaskClass_23;                                       // 0x02E8(0x0010) (ZeroConstructor)
	struct FCompanionAI_Ftuple_L_R                     $ExprResult_24;                                           // 0x02F4(0x0001)
	unsigned char                                      UnknownData16[0x3];                                       // 0x02F5(0x0003) MISSED OFFSET
	int64_t                                            $AsyncResult_25;                                          // 0x02F8(0x0008) (ZeroConstructor, IsPlainOldData)
	EVerseTrue                                         $InvokeSureResultDummy_26;                                // 0x0300(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData17[0x3];                                       // 0x0301(0x0003) MISSED OFFSET
	struct FScriptDelegate                             $Callee_27;                                               // 0x0304(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData18[0x10];                                      // 0x0310(0x0010) UNKNOWN PROPERTY: VerseStringProperty CompanionAI.task_companion_ai$HandleObstacleTask_L_N_Qentity_R.$ExprResult_28

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("VerseClass CompanionAI.task_companion_ai$HandleObstacleTask_L_N_Qentity_R"));
		
		return ptr;
	}


	int64_t Update();
};


// VerseClass CompanionAI.task_companion_ai$HandleReviveCommand_L_Nping__info_R
// 0x0160 (0x0280 - 0x0120)
class task_companion_ai$HandleReviveCommand_L_Nping__info_R : public task_t_
{
public:
	class companion_ai*                                _Self;                                                    // 0x0120(0x0008) (Parm, ZeroConstructor)
	struct Fping_info                                  __verse_0xB2CDDD72_Argument;                              // 0x0128(0x0038) (Parm)
	EVerseTrue                                         $InvokeSureResultDummy_0;                                 // 0x0160(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0161(0x0003) MISSED OFFSET
	struct FScriptDelegate                             $Callee_1;                                                // 0x0164(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData01[0x10];                                      // 0x0170(0x0010) UNKNOWN PROPERTY: VerseStringProperty CompanionAI.task_companion_ai$HandleReviveCommand_L_Nping__info_R.$ExprResult_2
	unsigned char                                      __verse_0xC5DFEEC1_PlayDeclineCommandAnim_1 : 1;          // 0x0180(0x0001)
	unsigned char                                      UnknownData02[0x7];                                       // 0x0181(0x0007) MISSED OFFSET
	class Entity*                                      __verse_0xFD64D7AA_Emitter_2;                             // 0x0188(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	unsigned char                                      UnknownData03[0x8];                                       // 0x0190(0x0008) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$HandleReviveCommand_L_Nping__info_R.$ExprResultStack_3
	class Object_32759*                                __verse_0x6B4100B8_EmitterCharacter_4;                    // 0x0198(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	unsigned char                                      UnknownData04[0x8];                                       // 0x01A0(0x0008) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$HandleReviveCommand_L_Nping__info_R.$ExprResultStack_4
	unsigned char                                      UnknownData05[0x8];                                       // 0x01A8(0x0008) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$HandleReviveCommand_L_Nping__info_R.$ExprResultStack_5
	struct FScriptDelegate                             $Callee_6;                                                // 0x01B0(0x0010) (ZeroConstructor)
	unsigned char                                      __verse_0xC96E9091_HasRevivedEmitter_4 : 1;               // 0x01BC(0x0001)
	unsigned char                                      UnknownData06[0x3];                                       // 0x01BD(0x0003) MISSED OFFSET
	class task_t_*                                     $AsyncTask_7;                                             // 0x01C0(0x0008) (ZeroConstructor)
	struct FScriptDelegate                             $AsyncTaskClass_8;                                        // 0x01C8(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData07[0x4];                                       // 0x01D4(0x0004) MISSED OFFSET
	int64_t                                            $AsyncResult_9;                                           // 0x01D8(0x0008) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData08[0x2];                                       // 0x01E0(0x0002) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$HandleReviveCommand_L_Nping__info_R.$ExprResultStack_10
	unsigned char                                      UnknownData09[0x6];                                       // 0x01E2(0x0006) MISSED OFFSET
	TArray<class Object_32759*>                        __verse_0xBFBCE682_TeamMembers_3;                         // 0x01E8(0x0010)
	struct FScriptDelegate                             $Callee_11;                                               // 0x01F8(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData10[0x4];                                       // 0x0204(0x0004) MISSED OFFSET
	int64_t                                            $ForIndex_12;                                             // 0x0208(0x0008) (ZeroConstructor, IsPlainOldData)
	int64_t                                            $ForLength_13;                                            // 0x0210(0x0008) (ZeroConstructor, IsPlainOldData)
	class Object_32759*                                __verse_0xAE35E375_TeamMember_9;                          // 0x0218(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	unsigned char                                      __verse_0x87226150_HasRevivedTeamMember_11 : 1;           // 0x0220(0x0001)
	unsigned char                                      UnknownData11[0x3];                                       // 0x0221(0x0003) MISSED OFFSET
	struct FScriptDelegate                             $AsyncTaskClass_14;                                       // 0x0224(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData12[0x2];                                       // 0x0230(0x0002) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$HandleReviveCommand_L_Nping__info_R.$ExprResultStack_15
	unsigned char                                      UnknownData13[0x6];                                       // 0x0232(0x0006) MISSED OFFSET
	class Object_32759*                                __verse_0xB4DBB24F_PingActions_14;                        // 0x0238(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	unsigned char                                      UnknownData14[0x8];                                       // 0x0240(0x0008) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$HandleReviveCommand_L_Nping__info_R.$ExprResultStack_16
	class Object_32759*                                __verse_0x00000000__15;                                   // 0x0248(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	EVerseTrue                                         $InvokeSureResultDummy_17;                                // 0x0250(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData15[0x3];                                       // 0x0251(0x0003) MISSED OFFSET
	struct FScriptDelegate                             $Callee_18;                                               // 0x0254(0x0010) (ZeroConstructor)
	EVerseTrue                                         $InvokeSureResultDummy_19;                                // 0x0260(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData16[0x3];                                       // 0x0261(0x0003) MISSED OFFSET
	struct FScriptDelegate                             $Callee_20;                                               // 0x0264(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData17[0x10];                                      // 0x0270(0x0010) UNKNOWN PROPERTY: VerseStringProperty CompanionAI.task_companion_ai$HandleReviveCommand_L_Nping__info_R.$ExprResult_21

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("VerseClass CompanionAI.task_companion_ai$HandleReviveCommand_L_Nping__info_R"));
		
		return ptr;
	}


	int64_t Update();
};


// VerseClass CompanionAI.task_companion_ai$LookAroundTask_L_Nvector3_M_Nfloat_M_Nfloat_R
// 0x01E0 (0x0300 - 0x0120)
class task_companion_ai$LookAroundTask_L_Nvector3_M_Nfloat_M_Nfloat_R : public task_t_
{
public:
	class companion_ai*                                _Self;                                                    // 0x0120(0x0008) (Parm, ZeroConstructor)
	struct FCompanionAI_Ftuple_Lvector3_Mfloat_Mfloat_R __verse_0xB2CDDD72_Argument;                              // 0x0128(0x0028) (Parm)
	EVerseTrue                                         $InvokeSureResultDummy_0;                                 // 0x0150(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0151(0x0003) MISSED OFFSET
	struct FScriptDelegate                             $Callee_1;                                                // 0x0154(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData01[0x10];                                      // 0x0160(0x0010) UNKNOWN PROPERTY: VerseStringProperty CompanionAI.task_companion_ai$LookAroundTask_L_Nvector3_M_Nfloat_M_Nfloat_R.$ExprResult_2
	class Object_32759*                                __verse_0xE8036CC4_AIActions_2;                           // 0x0170(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	unsigned char                                      UnknownData02[0x8];                                       // 0x0178(0x0008) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$LookAroundTask_L_Nvector3_M_Nfloat_M_Nfloat_R.$ExprResultStack_3
	struct Fvector3                                    __verse_0x68BA2569_RandomOffset_2;                        // 0x0180(0x0018) (ZeroConstructor, IsPlainOldData)
	double                                             $ExprResultStack_4;                                       // 0x0198(0x0008) (ZeroConstructor, IsPlainOldData)
	struct FScriptDelegate                             $Callee_5;                                                // 0x01A0(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData03[0x4];                                       // 0x01AC(0x0004) MISSED OFFSET
	struct Ftuple_Ltype_7b_2d1_2e000000e_2b03_7d_Mtype_7b1_2e000000e_2b03_7d_R $ExprResult_6;                                            // 0x01B0(0x0010)
	double                                             $ExprResultStack_7;                                       // 0x01C0(0x0008) (ZeroConstructor, IsPlainOldData)
	struct FScriptDelegate                             $Callee_8;                                                // 0x01C8(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData04[0x4];                                       // 0x01D4(0x0004) MISSED OFFSET
	struct Ftuple_Ltype_7b_2d1_2e000000e_2b03_7d_Mtype_7b1_2e000000e_2b03_7d_R $ExprResult_9;                                            // 0x01D8(0x0010)
	double                                             $ExprResultStack_10;                                      // 0x01E8(0x0008) (ZeroConstructor, IsPlainOldData)
	struct FScriptDelegate                             $Callee_11;                                               // 0x01F0(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData05[0x4];                                       // 0x01FC(0x0004) MISSED OFFSET
	struct Ftuple_Ltype_7b5_2e000000e_2b01_7d_Mtype_7b2_2e000000e_2b02_7d_R $ExprResult_12;                                           // 0x0200(0x0010)
	int64_t                                            $AsyncBeginCount_13;                                      // 0x0210(0x0008) (ZeroConstructor, IsPlainOldData)
	class Object_32759*                                __verse_0x00000000__3;                                    // 0x0218(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	class task_t_*                                     $AsyncTask_14;                                            // 0x0220(0x0008) (ZeroConstructor)
	struct FScriptDelegate                             $AsyncTaskClass_15;                                       // 0x0228(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData06[0x4];                                       // 0x0234(0x0004) MISSED OFFSET
	struct Fvector3                                    $ExprResultStack_16;                                      // 0x0238(0x0018) (ZeroConstructor, IsPlainOldData)
	struct FScriptDelegate                             $Callee_17;                                               // 0x0250(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData07[0x4];                                       // 0x025C(0x0004) MISSED OFFSET
	struct FCompanionAI_Ftuple_Lvector3_Mvector3_R     $ExprResult_18;                                           // 0x0260(0x0030)
	int64_t                                            $AsyncResult_19;                                          // 0x0290(0x0008) (ZeroConstructor, IsPlainOldData)
	class task_t_*                                     $AsyncTask_20;                                            // 0x0298(0x0008) (ZeroConstructor)
	struct FScriptDelegate                             $AsyncTaskClass_21;                                       // 0x02A0(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData08[0x4];                                       // 0x02AC(0x0004) MISSED OFFSET
	double                                             $ExprResultStack_22;                                      // 0x02B0(0x0008) (ZeroConstructor, IsPlainOldData)
	struct FScriptDelegate                             $Callee_23;                                               // 0x02B8(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData09[0x4];                                       // 0x02C4(0x0004) MISSED OFFSET
	struct FCompanionAI_Ftuple_Lfloat_Mfloat_R         $ExprResult_24;                                           // 0x02C8(0x0010)
	int64_t                                            $AsyncResult_25;                                          // 0x02D8(0x0008) (ZeroConstructor, IsPlainOldData)
	EVerseTrue                                         $InvokeSureResultDummy_26;                                // 0x02E0(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData10[0x3];                                       // 0x02E1(0x0003) MISSED OFFSET
	struct FScriptDelegate                             $Callee_27;                                               // 0x02E4(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData11[0x10];                                      // 0x02F0(0x0010) UNKNOWN PROPERTY: VerseStringProperty CompanionAI.task_companion_ai$LookAroundTask_L_Nvector3_M_Nfloat_M_Nfloat_R.$ExprResult_28

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("VerseClass CompanionAI.task_companion_ai$LookAroundTask_L_Nvector3_M_Nfloat_M_Nfloat_R"));
		
		return ptr;
	}


	int64_t Update();
};


// VerseClass CompanionAI.task_companion_ai$LookAtOrAttackTarget
// 0x02D8 (0x03F8 - 0x0120)
class task_companion_ai$LookAtOrAttackTarget : public task_t_
{
public:
	class companion_ai*                                _Self;                                                    // 0x0120(0x0008) (Parm, ZeroConstructor)
	struct FCompanionAI_Ftuple_L_R                     __verse_0xB2CDDD72_Argument;                              // 0x0128(0x0001) (Parm)
	EVerseTrue                                         $InvokeSureResultDummy_0;                                 // 0x0129(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x2];                                       // 0x012A(0x0002) MISSED OFFSET
	struct FScriptDelegate                             $Callee_1;                                                // 0x012C(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData01[0x10];                                      // 0x0138(0x0010) UNKNOWN PROPERTY: VerseStringProperty CompanionAI.task_companion_ai$LookAtOrAttackTarget.$ExprResult_2
	unsigned char                                      UnknownData02[0x39];                                      // 0x0148(0x0039) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$LookAtOrAttackTarget.__verse_0x1EB80E5B_ThreatInfo_1
	unsigned char                                      UnknownData03[0x7];                                       // 0x0181(0x0007) MISSED OFFSET
	class task_t_*                                     $AsyncTask_3;                                             // 0x0188(0x0008) (ZeroConstructor)
	struct FScriptDelegate                             $AsyncTaskClass_4;                                        // 0x0190(0x0010) (ZeroConstructor)
	struct FCompanionAI_Ftuple_L_R                     $ExprResult_5;                                            // 0x019C(0x0001)
	unsigned char                                      UnknownData04[0x3];                                       // 0x019D(0x0003) MISSED OFFSET
	int64_t                                            $AsyncResult_6;                                           // 0x01A0(0x0008) (ZeroConstructor, IsPlainOldData)
	struct Fthreat_info                                __verse_0x26CBBAEB_CurrentThreatInfo_3;                   // 0x01A8(0x0038)
	unsigned char                                      UnknownData05[0x39];                                      // 0x01E0(0x0039) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$LookAtOrAttackTarget.$ExprResultStack_7
	unsigned char                                      UnknownData06[0x7];                                       // 0x0219(0x0007) MISSED OFFSET
	int64_t                                            $AsyncBeginCount_8;                                       // 0x0220(0x0008) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData07[0x39];                                      // 0x0228(0x0039) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$LookAtOrAttackTarget.$ExprResult_9
	unsigned char                                      UnknownData08[0x7];                                       // 0x0261(0x0007) MISSED OFFSET
	class task_t_*                                     $AsyncTask_10;                                            // 0x0268(0x0008) (ZeroConstructor)
	struct FScriptDelegate                             $AsyncTaskClass_11;                                       // 0x0270(0x0010) (ZeroConstructor)
	struct FCompanionAI_Ftuple_L_R                     $ExprResult_12;                                           // 0x027C(0x0001)
	unsigned char                                      UnknownData09[0x3];                                       // 0x027D(0x0003) MISSED OFFSET
	int64_t                                            $AsyncResult_13;                                          // 0x0280(0x0008) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData10[0x39];                                      // 0x0288(0x0039) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$LookAtOrAttackTarget.$ExprResult_14
	unsigned char                                      UnknownData11[0x7];                                       // 0x02C1(0x0007) MISSED OFFSET
	class task_t_*                                     $AsyncTask_15;                                            // 0x02C8(0x0008) (ZeroConstructor)
	struct FScriptDelegate                             $AsyncTaskClass_16;                                       // 0x02D0(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData12[0x4];                                       // 0x02DC(0x0004) MISSED OFFSET
	int64_t                                            $AsyncResult_17;                                          // 0x02E0(0x0008) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData13[0x10];                                      // 0x02E8(0x0010) UNKNOWN PROPERTY: VerseDynamicProperty CompanionAI.task_companion_ai$LookAtOrAttackTarget.InvokeResultDummy_18
	unsigned char                                      UnknownData14[0x11];                                      // 0x02F8(0x0011) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$LookAtOrAttackTarget.$ExprResultStack_19
	unsigned char                                      UnknownData15[0x7];                                       // 0x0309(0x0007) MISSED OFFSET
	unsigned char                                      UnknownData16[0x10];                                      // 0x0309(0x0010) UNKNOWN PROPERTY: VerseDynamicProperty CompanionAI.task_companion_ai$LookAtOrAttackTarget.$ExprResult_20
	unsigned char                                      UnknownData17[0x10];                                      // 0x0320(0x0010) UNKNOWN PROPERTY: VerseDynamicProperty CompanionAI.task_companion_ai$LookAtOrAttackTarget.$ExprResult_21
	class task_t_*                                     $AsyncTask_22;                                            // 0x0330(0x0008) (ZeroConstructor)
	struct FScriptDelegate                             $AsyncTaskClass_23;                                       // 0x0338(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData18[0x4];                                       // 0x0344(0x0004) MISSED OFFSET
	int64_t                                            $AsyncResult_24;                                          // 0x0348(0x0008) (ZeroConstructor, IsPlainOldData)
	class Object_32759*                                __verse_0xE8036CC4_AIActions_6;                           // 0x0350(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	unsigned char                                      UnknownData19[0x8];                                       // 0x0358(0x0008) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$LookAtOrAttackTarget.$ExprResultStack_25
	int64_t                                            $AsyncBeginCount_26;                                      // 0x0360(0x0008) (ZeroConstructor, IsPlainOldData)
	class task_t_*                                     $AsyncTask_27;                                            // 0x0368(0x0008) (ZeroConstructor)
	struct FScriptDelegate                             $AsyncTaskClass_28;                                       // 0x0370(0x0010) (ZeroConstructor)
	struct FCompanionAI_Ftuple_L_R                     $ExprResult_29;                                           // 0x037C(0x0001)
	unsigned char                                      UnknownData20[0x3];                                       // 0x037D(0x0003) MISSED OFFSET
	int64_t                                            $AsyncResult_30;                                          // 0x0380(0x0008) (ZeroConstructor, IsPlainOldData)
	class Object_32759*                                __verse_0x00000000__7;                                    // 0x0388(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	class task_t_*                                     $AsyncTask_31;                                            // 0x0390(0x0008) (ZeroConstructor)
	struct FScriptDelegate                             $AsyncTaskClass_32;                                       // 0x0398(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData21[0x4];                                       // 0x03A4(0x0004) MISSED OFFSET
	struct Fvector3                                    $ExprResultStack_33;                                      // 0x03A8(0x0018) (ZeroConstructor, IsPlainOldData)
	struct FScriptDelegate                             $Callee_34;                                               // 0x03C0(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData22[0x4];                                       // 0x03CC(0x0004) MISSED OFFSET
	int64_t                                            $AsyncResult_35;                                          // 0x03D0(0x0008) (ZeroConstructor, IsPlainOldData)
	EVerseTrue                                         $InvokeSureResultDummy_36;                                // 0x03D8(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData23[0x3];                                       // 0x03D9(0x0003) MISSED OFFSET
	struct FScriptDelegate                             $Callee_37;                                               // 0x03DC(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData24[0x10];                                      // 0x03E8(0x0010) UNKNOWN PROPERTY: VerseStringProperty CompanionAI.task_companion_ai$LookAtOrAttackTarget.$ExprResult_38

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("VerseClass CompanionAI.task_companion_ai$LookAtOrAttackTarget"));
		
		return ptr;
	}


	int64_t Update();
};


// VerseClass CompanionAI.task_companion_ai$LookAtThreatTask
// 0x01F8 (0x0318 - 0x0120)
class task_companion_ai$LookAtThreatTask : public task_t_
{
public:
	class companion_ai*                                _Self;                                                    // 0x0120(0x0008) (Parm, ZeroConstructor)
	struct FCompanionAI_Ftuple_L_R                     __verse_0xB2CDDD72_Argument;                              // 0x0128(0x0001) (Parm)
	EVerseTrue                                         $InvokeSureResultDummy_0;                                 // 0x0129(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x2];                                       // 0x012A(0x0002) MISSED OFFSET
	struct FScriptDelegate                             $Callee_1;                                                // 0x012C(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData01[0x10];                                      // 0x0138(0x0010) UNKNOWN PROPERTY: VerseStringProperty CompanionAI.task_companion_ai$LookAtThreatTask.$ExprResult_2
	class Object_32759*                                __verse_0xE8036CC4_AIActions_3;                           // 0x0148(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	unsigned char                                      UnknownData02[0x8];                                       // 0x0150(0x0008) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$LookAtThreatTask.$ExprResultStack_3
	struct Fthreat_info                                __verse_0x1EB80E5B_ThreatInfo_3;                          // 0x0158(0x0038)
	class Object_32759*                                __verse_0x00000000__4;                                    // 0x0190(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	unsigned char                                      UnknownData03[0x8];                                       // 0x0198(0x0008) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$LookAtThreatTask.$ExprResultStack_4
	unsigned char                                      UnknownData04[0x39];                                      // 0x01A0(0x0039) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$LookAtThreatTask.$ExprResultStack_5
	unsigned char                                      UnknownData05[0x3];                                       // 0x01D9(0x0003) MISSED OFFSET
	struct FScriptDelegate                             $Callee_6;                                                // 0x01DC(0x0010) (ZeroConstructor)
	struct FCompanionAI_Ftuple_L_R                     $ExprResult_7;                                            // 0x01E8(0x0001)
	unsigned char                                      UnknownData06[0x7];                                       // 0x01E9(0x0007) MISSED OFFSET
	int64_t                                            $AsyncBeginCount_8;                                       // 0x01F0(0x0008) (ZeroConstructor, IsPlainOldData)
	class task_t_*                                     $AsyncTask_9;                                             // 0x01F8(0x0008) (ZeroConstructor)
	struct FScriptDelegate                             $AsyncTaskClass_10;                                       // 0x0200(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData07[0x4];                                       // 0x020C(0x0004) MISSED OFFSET
	unsigned char                                      UnknownData08[0x39];                                      // 0x020C(0x0039) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$LookAtThreatTask.$ExprResult_11
	unsigned char                                      UnknownData09[0x7];                                       // 0x0249(0x0007) MISSED OFFSET
	int64_t                                            $AsyncResult_12;                                          // 0x0250(0x0008) (ZeroConstructor, IsPlainOldData)
	class task_t_*                                     $AsyncTask_13;                                            // 0x0258(0x0008) (ZeroConstructor)
	struct FScriptDelegate                             $AsyncTaskClass_14;                                       // 0x0260(0x0010) (ZeroConstructor)
	struct FCompanionAI_Ftuple_L_R                     $ExprResult_15;                                           // 0x026C(0x0001)
	unsigned char                                      UnknownData10[0x3];                                       // 0x026D(0x0003) MISSED OFFSET
	int64_t                                            $AsyncResult_16;                                          // 0x0270(0x0008) (ZeroConstructor, IsPlainOldData)
	class Object_32759*                                __verse_0x00000000__6;                                    // 0x0278(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	class task_t_*                                     $AsyncTask_17;                                            // 0x0280(0x0008) (ZeroConstructor)
	struct FScriptDelegate                             $AsyncTaskClass_18;                                       // 0x0288(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData11[0x4];                                       // 0x0294(0x0004) MISSED OFFSET
	struct Fvector3                                    $ExprResultStack_19;                                      // 0x0298(0x0018) (ZeroConstructor, IsPlainOldData)
	struct FScriptDelegate                             $Callee_20;                                               // 0x02B0(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData12[0x4];                                       // 0x02BC(0x0004) MISSED OFFSET
	int64_t                                            $AsyncResult_21;                                          // 0x02C0(0x0008) (ZeroConstructor, IsPlainOldData)
	struct FScriptDelegate                             $AsyncTaskClass_22;                                       // 0x02C8(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData13[0x4];                                       // 0x02D4(0x0004) MISSED OFFSET
	class task_t_*                                     $AsyncTask_23;                                            // 0x02D8(0x0008) (ZeroConstructor)
	struct FScriptDelegate                             $AsyncTaskClass_24;                                       // 0x02E0(0x0010) (ZeroConstructor)
	struct FCompanionAI_Ftuple_L_R                     $ExprResult_25;                                           // 0x02EC(0x0001)
	unsigned char                                      UnknownData14[0x3];                                       // 0x02ED(0x0003) MISSED OFFSET
	int64_t                                            $AsyncResult_26;                                          // 0x02F0(0x0008) (ZeroConstructor, IsPlainOldData)
	EVerseTrue                                         $InvokeSureResultDummy_27;                                // 0x02F8(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData15[0x3];                                       // 0x02F9(0x0003) MISSED OFFSET
	struct FScriptDelegate                             $Callee_28;                                               // 0x02FC(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData16[0x10];                                      // 0x0308(0x0010) UNKNOWN PROPERTY: VerseStringProperty CompanionAI.task_companion_ai$LookAtThreatTask.$ExprResult_29

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("VerseClass CompanionAI.task_companion_ai$LookAtThreatTask"));
		
		return ptr;
	}


	int64_t Update();
};


// VerseClass CompanionAI.task_companion_ai$OnBegin
// 0x0221 (0x0341 - 0x0120)
class task_companion_ai$OnBegin : public task_t_
{
public:
	class companion_ai*                                _Self;                                                    // 0x0120(0x0008) (Parm, ZeroConstructor)
	struct FCompanionAI_Ftuple_L_R                     __verse_0xB2CDDD72_Argument;                              // 0x0128(0x0001) (Parm)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0129(0x0007) MISSED OFFSET
	class Object_32759*                                __verse_0xCA7BB203_AIMovement_1;                          // 0x0130(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	unsigned char                                      UnknownData01[0x8];                                       // 0x0138(0x0008) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$OnBegin.$ExprResultStack_0
	unsigned char                                      UnknownData02[0x8];                                       // 0x0140(0x0008) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$OnBegin.$ExprResultStack_1
	struct FScriptDelegate                             $Callee_2;                                                // 0x0148(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData03[0x4];                                       // 0x0154(0x0004) MISSED OFFSET
	class Object_32759*                                __verse_0xB4DBB24F_PingActions_1;                         // 0x0158(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	unsigned char                                      UnknownData04[0x8];                                       // 0x0160(0x0008) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$OnBegin.$ExprResultStack_3
	unsigned char                                      UnknownData05[0x8];                                       // 0x0168(0x0008) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$OnBegin.$ExprResultStack_4
	struct FScriptDelegate                             $Callee_5;                                                // 0x0170(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData06[0x4];                                       // 0x017C(0x0004) MISSED OFFSET
	class Object_32759*                                __verse_0xE8036CC4_AIActions_1;                           // 0x0180(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	unsigned char                                      UnknownData07[0x8];                                       // 0x0188(0x0008) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$OnBegin.$ExprResultStack_6
	unsigned char                                      UnknownData08[0x8];                                       // 0x0190(0x0008) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$OnBegin.$ExprResultStack_7
	struct FScriptDelegate                             $Callee_8;                                                // 0x0198(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData09[0x4];                                       // 0x01A4(0x0004) MISSED OFFSET
	class Object_32759*                                __verse_0xF161303F_WeaponActions_1;                       // 0x01A8(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	unsigned char                                      UnknownData10[0x8];                                       // 0x01B0(0x0008) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$OnBegin.$ExprResultStack_9
	unsigned char                                      UnknownData11[0x8];                                       // 0x01B8(0x0008) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$OnBegin.$ExprResultStack_10
	struct FScriptDelegate                             $Callee_11;                                               // 0x01C0(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData12[0x4];                                       // 0x01CC(0x0004) MISSED OFFSET
	class Object_32759*                                __verse_0x0F05355D_ThreatPerception_1;                    // 0x01D0(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	unsigned char                                      UnknownData13[0x8];                                       // 0x01D8(0x0008) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$OnBegin.$ExprResultStack_12
	unsigned char                                      UnknownData14[0x8];                                       // 0x01E0(0x0008) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$OnBegin.$ExprResultStack_13
	struct FScriptDelegate                             $Callee_14;                                               // 0x01E8(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData15[0x4];                                       // 0x01F4(0x0004) MISSED OFFSET
	class Object_32759*                                __verse_0x00C33D6C_ObstaclePerception_1;                  // 0x01F8(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	unsigned char                                      UnknownData16[0x8];                                       // 0x0200(0x0008) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$OnBegin.$ExprResultStack_15
	unsigned char                                      UnknownData17[0x8];                                       // 0x0208(0x0008) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$OnBegin.$ExprResultStack_16
	struct FScriptDelegate                             $Callee_17;                                               // 0x0210(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData18[0x4];                                       // 0x021C(0x0004) MISSED OFFSET
	class Object_32759*                                __verse_0x3051673F_Health_1;                              // 0x0220(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	unsigned char                                      UnknownData19[0x8];                                       // 0x0228(0x0008) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$OnBegin.$ExprResultStack_18
	unsigned char                                      UnknownData20[0x8];                                       // 0x0230(0x0008) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$OnBegin.$ExprResultStack_19
	struct FScriptDelegate                             $Callee_20;                                               // 0x0238(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData21[0x4];                                       // 0x0244(0x0004) MISSED OFFSET
	unsigned char                                      UnknownData22[0x8];                                       // 0x0244(0x0008) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$OnBegin.$ExprResult_21
	unsigned char                                      UnknownData23[0x8];                                       // 0x0250(0x0008) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$OnBegin.$ExprResult_22
	unsigned char                                      UnknownData24[0x8];                                       // 0x0258(0x0008) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$OnBegin.$ExprResult_23
	unsigned char                                      UnknownData25[0x8];                                       // 0x0260(0x0008) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$OnBegin.$ExprResult_24
	unsigned char                                      UnknownData26[0x8];                                       // 0x0268(0x0008) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$OnBegin.$ExprResult_25
	unsigned char                                      UnknownData27[0x8];                                       // 0x0270(0x0008) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$OnBegin.$ExprResult_26
	unsigned char                                      UnknownData28[0x8];                                       // 0x0278(0x0008) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$OnBegin.$ExprResult_27
	class task_t_*                                     $AsyncTask_28;                                            // 0x0280(0x0008) (ZeroConstructor)
	struct FScriptDelegate                             $AsyncTaskClass_29;                                       // 0x0288(0x0010) (ZeroConstructor)
	struct FCompanionAI_Ftuple_L_R                     $ExprResult_30;                                           // 0x0294(0x0001)
	unsigned char                                      UnknownData29[0x3];                                       // 0x0295(0x0003) MISSED OFFSET
	int64_t                                            $AsyncResult_31;                                          // 0x0298(0x0008) (ZeroConstructor, IsPlainOldData)
	class screen_log*                                  __verse_0x00000000__3;                                    // 0x02A0(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	EVerseTrue                                         $InvokeSureResultDummy_32;                                // 0x02A8(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData30[0x3];                                       // 0x02A9(0x0003) MISSED OFFSET
	struct FScriptDelegate                             $Callee_33;                                               // 0x02AC(0x0010) (ZeroConstructor)
	struct FCompanionAI_Ftuple_L_Kchar_M_QLevel_Nlog__level_20_3d_20_2e_2e_2e_M_QDuration_Nfloat_20_3d_20_2e_2e_2e_M_QColor_Ncolor_20_3d_20_2e_2e_2e_R $ExprResult_34;                                           // 0x02B8(0x0048)
	unsigned char                                      UnknownData31[0x10];                                      // 0x0300(0x0010) UNKNOWN PROPERTY: VerseStringProperty CompanionAI.task_companion_ai$OnBegin.$ExprResult_35
	unsigned char                                      UnknownData32[0x2];                                       // 0x0310(0x0002) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$OnBegin.$ExprResult_36
	unsigned char                                      UnknownData33[0x6];                                       // 0x0312(0x0006) MISSED OFFSET
	unsigned char                                      UnknownData34[0x9];                                       // 0x0312(0x0009) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$OnBegin.$ExprResult_37
	unsigned char                                      UnknownData35[0x7];                                       // 0x0321(0x0007) MISSED OFFSET
	unsigned char                                      UnknownData36[0x19];                                      // 0x0321(0x0019) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$OnBegin.$ExprResult_38

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("VerseClass CompanionAI.task_companion_ai$OnBegin"));
		
		return ptr;
	}


	int64_t Update();
};


// VerseClass CompanionAI.task_companion_ai$ReviveCommand_L_Nfort__character_R
// 0x01C0 (0x02E0 - 0x0120)
class task_companion_ai$ReviveCommand_L_Nfort__character_R : public task_t_
{
public:
	class companion_ai*                                _Self;                                                    // 0x0120(0x0008) (Parm, ZeroConstructor)
	class Object_32759*                                __verse_0xB2CDDD72_Argument;                              // 0x0128(0x0008) (ExportObject, Parm, ZeroConstructor, InstancedReference)
	unsigned char                                      _RetVal : 1;                                              // 0x0130(0x0001) (Parm, OutParm, ReturnParm)
	EVerseTrue                                         $InvokeSureResultDummy_0;                                 // 0x0131(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x2];                                       // 0x0132(0x0002) MISSED OFFSET
	struct FScriptDelegate                             $Callee_1;                                                // 0x0134(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData01[0x10];                                      // 0x0140(0x0010) UNKNOWN PROPERTY: VerseStringProperty CompanionAI.task_companion_ai$ReviveCommand_L_Nfort__character_R.$ExprResult_2
	class Object_32759*                                __verse_0x00000000__3;                                    // 0x0150(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	unsigned char                                      $InvokeSureResultDummy_3 : 1;                             // 0x0158(0x0001)
	unsigned char                                      UnknownData02[0x3];                                       // 0x0159(0x0003) MISSED OFFSET
	struct FScriptDelegate                             $Callee_4;                                                // 0x015C(0x0010) (ZeroConstructor)
	struct FCompanionAI_Ftuple_L_R                     $ExprResult_5;                                            // 0x0168(0x0001)
	unsigned char                                      UnknownData03[0x7];                                       // 0x0169(0x0007) MISSED OFFSET
	class Object_32759*                                __verse_0xE8036CC4_AIActions_2;                           // 0x0170(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	unsigned char                                      UnknownData04[0x8];                                       // 0x0178(0x0008) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$ReviveCommand_L_Nfort__character_R.$ExprResultStack_6
	int64_t                                            $AsyncBeginCount_7;                                       // 0x0180(0x0008) (ZeroConstructor, IsPlainOldData)
	class task_t_*                                     $AsyncTask_8;                                             // 0x0188(0x0008) (ZeroConstructor)
	struct FScriptDelegate                             $AsyncTaskClass_9;                                        // 0x0190(0x0010) (ZeroConstructor)
	struct FCompanionAI_Ftuple_L_R                     $ExprResult_10;                                           // 0x019C(0x0001)
	unsigned char                                      UnknownData05[0x3];                                       // 0x019D(0x0003) MISSED OFFSET
	int64_t                                            $AsyncResult_11;                                          // 0x01A0(0x0008) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      __verse_0x7EBDC403_HasReachedPosition_4 : 1;              // 0x01A8(0x0001)
	unsigned char                                      UnknownData06[0x7];                                       // 0x01A9(0x0007) MISSED OFFSET
	class task_t_*                                     $AsyncTask_12;                                            // 0x01B0(0x0008) (ZeroConstructor)
	struct FScriptDelegate                             $AsyncTaskClass_13;                                       // 0x01B8(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData07[0x4];                                       // 0x01C4(0x0004) MISSED OFFSET
	struct Ftuple_Lvector3_M_Qfort__character_Mlogic_M_QNavigationParameters_Nnavigation__parameters_R $ExprResult_14;                                           // 0x01C8(0x0040)
	struct Fvector3                                    $ExprResult_15;                                           // 0x0208(0x0018) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData08[0x8];                                       // 0x0220(0x0008) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$ReviveCommand_L_Nfort__character_R.$ExprResult_16
	unsigned char                                      UnknownData09[0x11];                                      // 0x0228(0x0011) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$ReviveCommand_L_Nfort__character_R.$ExprResult_17
	unsigned char                                      UnknownData10[0x7];                                       // 0x0239(0x0007) MISSED OFFSET
	struct Fnavigation_parameters                      $ExprResult_18;                                           // 0x0240(0x0010)
	int64_t                                            $AsyncResult_19;                                          // 0x0250(0x0008) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData11[0x2];                                       // 0x0258(0x0002) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$ReviveCommand_L_Nfort__character_R.$ExprResultStack_20
	Eaction_result                                     __verse_0x40FB4916_ReviveResult_4;                        // 0x025A(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData12[0x5];                                       // 0x025B(0x0005) MISSED OFFSET
	class Object_32759*                                __verse_0x00000000__7;                                    // 0x0260(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	struct FScriptDelegate                             $AsyncTaskClass_21;                                       // 0x0268(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData13[0x4];                                       // 0x0274(0x0004) MISSED OFFSET
	unsigned char                                      UnknownData14[0x10];                                      // 0x0274(0x0010) UNKNOWN PROPERTY: VerseDynamicProperty CompanionAI.task_companion_ai$ReviveCommand_L_Nfort__character_R.InvokeResultDummy_22
	unsigned char                                      UnknownData15[0x11];                                      // 0x0288(0x0011) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$ReviveCommand_L_Nfort__character_R.$ExprResultStack_23
	unsigned char                                      UnknownData16[0x7];                                       // 0x0299(0x0007) MISSED OFFSET
	unsigned char                                      UnknownData17[0x10];                                      // 0x0299(0x0010) UNKNOWN PROPERTY: VerseDynamicProperty CompanionAI.task_companion_ai$ReviveCommand_L_Nfort__character_R.$ExprResult_24
	unsigned char                                      UnknownData18[0x10];                                      // 0x02B0(0x0010) UNKNOWN PROPERTY: VerseDynamicProperty CompanionAI.task_companion_ai$ReviveCommand_L_Nfort__character_R.$ExprResult_25
	EVerseTrue                                         $InvokeSureResultDummy_26;                                // 0x02C0(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData19[0x3];                                       // 0x02C1(0x0003) MISSED OFFSET
	struct FScriptDelegate                             $Callee_27;                                               // 0x02C4(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData20[0x10];                                      // 0x02D0(0x0010) UNKNOWN PROPERTY: VerseStringProperty CompanionAI.task_companion_ai$ReviveCommand_L_Nfort__character_R.$ExprResult_28

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("VerseClass CompanionAI.task_companion_ai$ReviveCommand_L_Nfort__character_R"));
		
		return ptr;
	}


	int64_t Update();
};


// VerseClass CompanionAI.task_companion_ai$SetLeashPosition_L_Nvector3_M_Nfloat_M_Nentity_R
// 0x02C8 (0x03E8 - 0x0120)
class task_companion_ai$SetLeashPosition_L_Nvector3_M_Nfloat_M_Nentity_R : public task_t_
{
public:
	class companion_ai*                                _Self;                                                    // 0x0120(0x0008) (Parm, ZeroConstructor)
	struct Ftuple_Lvector3_Mfloat_Mentity_R            __verse_0xB2CDDD72_Argument;                              // 0x0128(0x0028) (Parm)
	EVerseTrue                                         $InvokeSureResultDummy_0;                                 // 0x0150(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0151(0x0003) MISSED OFFSET
	struct FScriptDelegate                             $Callee_1;                                                // 0x0154(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData01[0x10];                                      // 0x0160(0x0010) UNKNOWN PROPERTY: VerseStringProperty CompanionAI.task_companion_ai$SetLeashPosition_L_Nvector3_M_Nfloat_M_Nentity_R.$ExprResult_2
	unsigned char                                      UnknownData02[0x10];                                      // 0x0170(0x0010) UNKNOWN PROPERTY: ArrayProperty CompanionAI.task_companion_ai$SetLeashPosition_L_Nvector3_M_Nfloat_M_Nentity_R.__verse_0xFFC68BC5_Array_2
	struct FScriptDelegate                             $Callee_3;                                                // 0x0180(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData03[0x4];                                       // 0x018C(0x0004) MISSED OFFSET
	unsigned char                                      UnknownData04[0x10];                                      // 0x018C(0x0010) UNKNOWN PROPERTY: ArrayProperty CompanionAI.task_companion_ai$SetLeashPosition_L_Nvector3_M_Nfloat_M_Nentity_R.$ExprResult_4
	unsigned char                                      UnknownData05[0x10];                                      // 0x01A0(0x0010) UNKNOWN PROPERTY: ArrayProperty CompanionAI.task_companion_ai$SetLeashPosition_L_Nvector3_M_Nfloat_M_Nentity_R.__verse_0xFFC68BC5_Array_3
	struct FCompanionAI_Ftuple_L_Kchar_M_Kchar_R       __verse_0x00000000__4;                                    // 0x01B0(0x0020)
	unsigned char                                      UnknownData06[0x10];                                      // 0x01D0(0x0010) UNKNOWN PROPERTY: VerseStringProperty CompanionAI.task_companion_ai$SetLeashPosition_L_Nvector3_M_Nfloat_M_Nentity_R.$ExprResult_5
	unsigned char                                      UnknownData07[0x10];                                      // 0x01E0(0x0010) UNKNOWN PROPERTY: VerseStringProperty CompanionAI.task_companion_ai$SetLeashPosition_L_Nvector3_M_Nfloat_M_Nentity_R.$ExprResultStack_6
	struct FScriptDelegate                             $Callee_7;                                                // 0x01F0(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData08[0x4];                                       // 0x01FC(0x0004) MISSED OFFSET
	unsigned char                                      UnknownData09[0x10];                                      // 0x01FC(0x0010) UNKNOWN PROPERTY: VerseStringProperty CompanionAI.task_companion_ai$SetLeashPosition_L_Nvector3_M_Nfloat_M_Nentity_R.$ExprResultDummy_8
	unsigned char                                      UnknownData10[0x10];                                      // 0x0210(0x0010) UNKNOWN PROPERTY: VerseStringProperty CompanionAI.task_companion_ai$SetLeashPosition_L_Nvector3_M_Nfloat_M_Nentity_R.$ExprResultDummy_9
	unsigned char                                      UnknownData11[0x10];                                      // 0x0220(0x0010) UNKNOWN PROPERTY: ArrayProperty CompanionAI.task_companion_ai$SetLeashPosition_L_Nvector3_M_Nfloat_M_Nentity_R.$ForResult_10
	int64_t                                            $ForIndex_11;                                             // 0x0230(0x0008) (ZeroConstructor, IsPlainOldData)
	int64_t                                            $ForLength_12;                                            // 0x0238(0x0008) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData12[0x10];                                      // 0x0240(0x0010) UNKNOWN PROPERTY: VerseStringProperty CompanionAI.task_companion_ai$SetLeashPosition_L_Nvector3_M_Nfloat_M_Nentity_R.__verse_0xFB88B569_Item_6
	unsigned char                                      UnknownData13[0x10];                                      // 0x0250(0x0010) UNKNOWN PROPERTY: ArrayProperty CompanionAI.task_companion_ai$SetLeashPosition_L_Nvector3_M_Nfloat_M_Nentity_R.$ExprResult_13
	unsigned char                                      UnknownData14[0x10];                                      // 0x0260(0x0010) UNKNOWN PROPERTY: VerseStringProperty CompanionAI.task_companion_ai$SetLeashPosition_L_Nvector3_M_Nfloat_M_Nentity_R.__verse_0xFFC68BC5_Array_7
	unsigned char                                      UnknownData15[0x10];                                      // 0x0270(0x0010) UNKNOWN PROPERTY: ArrayProperty CompanionAI.task_companion_ai$SetLeashPosition_L_Nvector3_M_Nfloat_M_Nentity_R.$ForResult_14
	int64_t                                            $ForIndex_15;                                             // 0x0280(0x0008) (ZeroConstructor, IsPlainOldData)
	int64_t                                            $ForLength_16;                                            // 0x0288(0x0008) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      __verse_0xFB88B569_Item_9;                                // 0x0290(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData16[0x7];                                       // 0x0291(0x0007) MISSED OFFSET
	unsigned char                                      UnknownData17[0x10];                                      // 0x0291(0x0010) UNKNOWN PROPERTY: VerseDynamicProperty CompanionAI.task_companion_ai$SetLeashPosition_L_Nvector3_M_Nfloat_M_Nentity_R.$ExprResult_17
	unsigned char                                      UnknownData18[0x10];                                      // 0x02A8(0x0010) UNKNOWN PROPERTY: VerseStringProperty CompanionAI.task_companion_ai$SetLeashPosition_L_Nvector3_M_Nfloat_M_Nentity_R.$ForResult_18
	int64_t                                            $ForIndex_19;                                             // 0x02B8(0x0008) (ZeroConstructor, IsPlainOldData)
	int64_t                                            $ForLength_20;                                            // 0x02C0(0x0008) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData19[0x10];                                      // 0x02C8(0x0010) UNKNOWN PROPERTY: VerseDynamicProperty CompanionAI.task_companion_ai$SetLeashPosition_L_Nvector3_M_Nfloat_M_Nentity_R.__verse_0xFB88B569_Item_11
	unsigned char                                      $ExprResult_21;                                           // 0x02D8(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData20[0x7];                                       // 0x02D9(0x0007) MISSED OFFSET
	int64_t                                            $AsyncBeginCount_22;                                      // 0x02E0(0x0008) (ZeroConstructor, IsPlainOldData)
	class task_t_*                                     $AsyncTask_23;                                            // 0x02E8(0x0008) (ZeroConstructor)
	struct FScriptDelegate                             $AsyncTaskClass_24;                                       // 0x02F0(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData21[0x4];                                       // 0x02FC(0x0004) MISSED OFFSET
	struct Ftuple_Lvector3_Mfloat_Mcolor_R             $ExprResult_25;                                           // 0x0300(0x0038)
	int64_t                                            $AsyncResult_26;                                          // 0x0338(0x0008) (ZeroConstructor, IsPlainOldData)
	class Object_32759*                                __verse_0xCA7BB203_AIMovement_12;                         // 0x0340(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	unsigned char                                      UnknownData22[0x8];                                       // 0x0348(0x0008) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$SetLeashPosition_L_Nvector3_M_Nfloat_M_Nentity_R.$ExprResultStack_27
	class Object_32759*                                __verse_0x00000000__13;                                   // 0x0350(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	EVerseTrue                                         $InvokeSureResultDummy_28;                                // 0x0358(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData23[0x3];                                       // 0x0359(0x0003) MISSED OFFSET
	struct FScriptDelegate                             $Callee_29;                                               // 0x035C(0x0010) (ZeroConstructor)
	struct Ftuple_Lvector3_Mtype_7b1_2e000000e_2b02_7d_Mfloat_R $ExprResult_30;                                           // 0x0368(0x0028)
	class Object_32759*                                __verse_0x00000000__15;                                   // 0x0390(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	EVerseTrue                                         $InvokeSureResultDummy_31;                                // 0x0398(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData24[0x3];                                       // 0x0399(0x0003) MISSED OFFSET
	struct FScriptDelegate                             $Callee_32;                                               // 0x039C(0x0010) (ZeroConstructor)
	class task_t_*                                     $AsyncTask_33;                                            // 0x03A8(0x0008) (ZeroConstructor)
	struct FScriptDelegate                             $AsyncTaskClass_34;                                       // 0x03B0(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData25[0x4];                                       // 0x03BC(0x0004) MISSED OFFSET
	int64_t                                            $AsyncResult_35;                                          // 0x03C0(0x0008) (ZeroConstructor, IsPlainOldData)
	EVerseTrue                                         $InvokeSureResultDummy_36;                                // 0x03C8(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData26[0x3];                                       // 0x03C9(0x0003) MISSED OFFSET
	struct FScriptDelegate                             $Callee_37;                                               // 0x03CC(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData27[0x10];                                      // 0x03D8(0x0010) UNKNOWN PROPERTY: VerseStringProperty CompanionAI.task_companion_ai$SetLeashPosition_L_Nvector3_M_Nfloat_M_Nentity_R.$ExprResult_38

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("VerseClass CompanionAI.task_companion_ai$SetLeashPosition_L_Nvector3_M_Nfloat_M_Nentity_R"));
		
		return ptr;
	}


	int64_t Update();
};


// VerseClass CompanionAI.task_companion_ai$ShootTargetService_L_Nfloat_R
// 0x03B0 (0x04D0 - 0x0120)
class task_companion_ai$ShootTargetService_L_Nfloat_R : public task_t_
{
public:
	class companion_ai*                                _Self;                                                    // 0x0120(0x0008) (Parm, ZeroConstructor)
	double                                             __verse_0xB2CDDD72_Argument;                              // 0x0128(0x0008) (Parm, ZeroConstructor, IsPlainOldData)
	EVerseTrue                                         $InvokeSureResultDummy_0;                                 // 0x0130(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0131(0x0003) MISSED OFFSET
	struct FScriptDelegate                             $Callee_1;                                                // 0x0134(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData01[0x10];                                      // 0x0140(0x0010) UNKNOWN PROPERTY: VerseStringProperty CompanionAI.task_companion_ai$ShootTargetService_L_Nfloat_R.$ExprResult_2
	class task_t_*                                     $AsyncTask_3;                                             // 0x0150(0x0008) (ZeroConstructor)
	struct FScriptDelegate                             $AsyncTaskClass_4;                                        // 0x0158(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData02[0x4];                                       // 0x0164(0x0004) MISSED OFFSET
	int64_t                                            $AsyncResult_5;                                           // 0x0168(0x0008) (ZeroConstructor, IsPlainOldData)
	struct Fthreat_info                                __verse_0x1EB80E5B_ThreatInfo_3;                          // 0x0170(0x0038)
	class Object_32759*                                __verse_0x00000000__4;                                    // 0x01A8(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	unsigned char                                      UnknownData03[0x8];                                       // 0x01B0(0x0008) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$ShootTargetService_L_Nfloat_R.$ExprResultStack_6
	unsigned char                                      UnknownData04[0x39];                                      // 0x01B8(0x0039) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$ShootTargetService_L_Nfloat_R.$ExprResultStack_7
	unsigned char                                      UnknownData05[0x3];                                       // 0x01F1(0x0003) MISSED OFFSET
	struct FScriptDelegate                             $Callee_8;                                                // 0x01F4(0x0010) (ZeroConstructor)
	struct FCompanionAI_Ftuple_L_R                     $ExprResult_9;                                            // 0x0200(0x0001)
	unsigned char                                      UnknownData06[0x7];                                       // 0x0201(0x0007) MISSED OFFSET
	int64_t                                            $AsyncBeginCount_10;                                      // 0x0208(0x0008) (ZeroConstructor, IsPlainOldData)
	class task_t_*                                     $AsyncTask_11;                                            // 0x0210(0x0008) (ZeroConstructor)
	struct FScriptDelegate                             $AsyncTaskClass_12;                                       // 0x0218(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData07[0x4];                                       // 0x0224(0x0004) MISSED OFFSET
	unsigned char                                      UnknownData08[0x39];                                      // 0x0224(0x0039) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$ShootTargetService_L_Nfloat_R.$ExprResult_13
	unsigned char                                      UnknownData09[0x7];                                       // 0x0261(0x0007) MISSED OFFSET
	int64_t                                            $AsyncResult_14;                                          // 0x0268(0x0008) (ZeroConstructor, IsPlainOldData)
	class task_t_*                                     $AsyncTask_15;                                            // 0x0270(0x0008) (ZeroConstructor)
	struct FScriptDelegate                             $AsyncTaskClass_16;                                       // 0x0278(0x0010) (ZeroConstructor)
	struct FCompanionAI_Ftuple_L_R                     $ExprResult_17;                                           // 0x0284(0x0001)
	unsigned char                                      UnknownData10[0x3];                                       // 0x0285(0x0003) MISSED OFFSET
	int64_t                                            $AsyncResult_18;                                          // 0x0288(0x0008) (ZeroConstructor, IsPlainOldData)
	class Object_32759*                                __verse_0xF161303F_WeaponActions_6;                       // 0x0290(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	unsigned char                                      UnknownData11[0x8];                                       // 0x0298(0x0008) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$ShootTargetService_L_Nfloat_R.$ExprResultStack_19
	unsigned char                                      UnknownData12[0x10];                                      // 0x02A0(0x0010) UNKNOWN PROPERTY: VerseDynamicProperty CompanionAI.task_companion_ai$ShootTargetService_L_Nfloat_R.InvokeResultDummy_20
	unsigned char                                      UnknownData13[0x11];                                      // 0x02B0(0x0011) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$ShootTargetService_L_Nfloat_R.$ExprResultStack_21
	unsigned char                                      UnknownData14[0x7];                                       // 0x02C1(0x0007) MISSED OFFSET
	unsigned char                                      UnknownData15[0x10];                                      // 0x02C1(0x0010) UNKNOWN PROPERTY: VerseDynamicProperty CompanionAI.task_companion_ai$ShootTargetService_L_Nfloat_R.$ExprResult_22
	unsigned char                                      UnknownData16[0x10];                                      // 0x02D8(0x0010) UNKNOWN PROPERTY: VerseDynamicProperty CompanionAI.task_companion_ai$ShootTargetService_L_Nfloat_R.$ExprResult_23
	struct Fvector3                                    __verse_0x96EC8CCE_Destination_6;                         // 0x02E8(0x0018) (ZeroConstructor, IsPlainOldData)
	class Object_32759*                                __verse_0x00000000__7;                                    // 0x0300(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	unsigned char                                      UnknownData17[0x8];                                       // 0x0308(0x0008) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$ShootTargetService_L_Nfloat_R.$ExprResultStack_24
	unsigned char                                      UnknownData18[0x19];                                      // 0x0310(0x0019) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$ShootTargetService_L_Nfloat_R.$ExprResultStack_25
	unsigned char                                      UnknownData19[0x3];                                       // 0x0329(0x0003) MISSED OFFSET
	struct FScriptDelegate                             $Callee_26;                                               // 0x032C(0x0010) (ZeroConstructor)
	struct FCompanionAI_Ftuple_L_R                     $ExprResult_27;                                           // 0x0338(0x0001)
	unsigned char                                      UnknownData20[0x7];                                       // 0x0339(0x0007) MISSED OFFSET
	unsigned char                                      UnknownData21[0x9];                                       // 0x0339(0x0009) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$ShootTargetService_L_Nfloat_R.$ExprResultStack_28
	unsigned char                                      UnknownData22[0x7];                                       // 0x0349(0x0007) MISSED OFFSET
	double                                             $ExprResultStack_29;                                      // 0x0350(0x0008) (ZeroConstructor, IsPlainOldData)
	struct FScriptDelegate                             $Callee_30;                                               // 0x0358(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData23[0x4];                                       // 0x0364(0x0004) MISSED OFFSET
	struct FCompanionAI_Ftuple_Lvector3_Mvector3_R     $ExprResult_31;                                           // 0x0368(0x0030)
	struct Fvector3                                    $ExprResult_32;                                           // 0x0398(0x0018) (ZeroConstructor, IsPlainOldData)
	class Object_32759*                                __verse_0x00000000__8;                                    // 0x03B0(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	unsigned char                                      UnknownData24[0x8];                                       // 0x03B8(0x0008) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$ShootTargetService_L_Nfloat_R.$ExprResultStack_33
	struct FScriptDelegate                             $Callee_34;                                               // 0x03C0(0x0010) (ZeroConstructor)
	struct FCompanionAI_Ftuple_L_R                     $ExprResult_35;                                           // 0x03CC(0x0001)
	unsigned char                                      UnknownData25[0x3];                                       // 0x03CD(0x0003) MISSED OFFSET
	unsigned char                                      UnknownData26[0x9];                                       // 0x03CD(0x0009) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$ShootTargetService_L_Nfloat_R.$ExprResultStack_36
	unsigned char                                      UnknownData27[0x7];                                       // 0x03D9(0x0007) MISSED OFFSET
	double                                             $ExprResultStack_37;                                      // 0x03E0(0x0008) (ZeroConstructor, IsPlainOldData)
	struct FScriptDelegate                             $Callee_38;                                               // 0x03E8(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData28[0x4];                                       // 0x03F4(0x0004) MISSED OFFSET
	struct FCompanionAI_Ftuple_Lvector3_Mvector3_R     $ExprResult_39;                                           // 0x03F8(0x0030)
	struct Fvector3                                    $ExprResultStack_40;                                      // 0x0428(0x0018) (ZeroConstructor, IsPlainOldData)
	struct FScriptDelegate                             $Callee_41;                                               // 0x0440(0x0010) (ZeroConstructor)
	EVerseTrue                                         $InvokeSureResultDummy_42;                                // 0x044C(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData29[0x3];                                       // 0x044D(0x0003) MISSED OFFSET
	struct FScriptDelegate                             $Callee_43;                                               // 0x0450(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData30[0x4];                                       // 0x045C(0x0004) MISSED OFFSET
	unsigned char                                      UnknownData31[0x10];                                      // 0x045C(0x0010) UNKNOWN PROPERTY: VerseStringProperty CompanionAI.task_companion_ai$ShootTargetService_L_Nfloat_R.$ExprResult_44
	class Object_32759*                                __verse_0x00000000__9;                                    // 0x0470(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	class task_t_*                                     $AsyncTask_45;                                            // 0x0478(0x0008) (ZeroConstructor)
	struct FScriptDelegate                             $AsyncTaskClass_46;                                       // 0x0480(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData32[0x4];                                       // 0x048C(0x0004) MISSED OFFSET
	int64_t                                            $AsyncResult_47;                                          // 0x0490(0x0008) (ZeroConstructor, IsPlainOldData)
	struct FScriptDelegate                             $AsyncTaskClass_48;                                       // 0x0498(0x0010) (ZeroConstructor)
	struct FScriptDelegate                             $AsyncTaskClass_49;                                       // 0x04A4(0x0010) (ZeroConstructor)
	struct FCompanionAI_Ftuple_L_R                     $ExprResult_50;                                           // 0x04B0(0x0001)
	EVerseTrue                                         $InvokeSureResultDummy_51;                                // 0x04B1(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData33[0x2];                                       // 0x04B2(0x0002) MISSED OFFSET
	struct FScriptDelegate                             $Callee_52;                                               // 0x04B4(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData34[0x10];                                      // 0x04C0(0x0010) UNKNOWN PROPERTY: VerseStringProperty CompanionAI.task_companion_ai$ShootTargetService_L_Nfloat_R.$ExprResult_53

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("VerseClass CompanionAI.task_companion_ai$ShootTargetService_L_Nfloat_R"));
		
		return ptr;
	}


	int64_t Update();
};


// VerseClass CompanionAI.task_companion_ai$SprintService
// 0x0048 (0x0168 - 0x0120)
class task_companion_ai$SprintService : public task_t_
{
public:
	class companion_ai*                                _Self;                                                    // 0x0120(0x0008) (Parm, ZeroConstructor)
	struct FCompanionAI_Ftuple_L_R                     __verse_0xB2CDDD72_Argument;                              // 0x0128(0x0001) (Parm)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0129(0x0007) MISSED OFFSET
	class Object_32759*                                __verse_0xCA7BB203_AIMovement_1;                          // 0x0130(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	unsigned char                                      UnknownData01[0x8];                                       // 0x0138(0x0008) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$SprintService.$ExprResultStack_0
	class Object_32759*                                __verse_0x00000000__2;                                    // 0x0140(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	class task_t_*                                     $AsyncTask_1;                                             // 0x0148(0x0008) (ZeroConstructor)
	struct FScriptDelegate                             $AsyncTaskClass_2;                                        // 0x0150(0x0010) (ZeroConstructor)
	struct FCompanionAI_Ftuple_L_R                     $ExprResult_3;                                            // 0x015C(0x0001)
	unsigned char                                      UnknownData02[0x3];                                       // 0x015D(0x0003) MISSED OFFSET
	int64_t                                            $AsyncResult_4;                                           // 0x0160(0x0008) (ZeroConstructor, IsPlainOldData)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("VerseClass CompanionAI.task_companion_ai$SprintService"));
		
		return ptr;
	}


	int64_t Update();
};


// VerseClass CompanionAI.task_companion_ai$TacticalSprintService
// 0x0048 (0x0168 - 0x0120)
class task_companion_ai$TacticalSprintService : public task_t_
{
public:
	class companion_ai*                                _Self;                                                    // 0x0120(0x0008) (Parm, ZeroConstructor)
	struct FCompanionAI_Ftuple_L_R                     __verse_0xB2CDDD72_Argument;                              // 0x0128(0x0001) (Parm)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0129(0x0007) MISSED OFFSET
	class Object_32759*                                __verse_0xCA7BB203_AIMovement_1;                          // 0x0130(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	unsigned char                                      UnknownData01[0x8];                                       // 0x0138(0x0008) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$TacticalSprintService.$ExprResultStack_0
	class Object_32759*                                __verse_0x00000000__2;                                    // 0x0140(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	class task_t_*                                     $AsyncTask_1;                                             // 0x0148(0x0008) (ZeroConstructor)
	struct FScriptDelegate                             $AsyncTaskClass_2;                                        // 0x0150(0x0010) (ZeroConstructor)
	struct FCompanionAI_Ftuple_L_R                     $ExprResult_3;                                            // 0x015C(0x0001)
	unsigned char                                      UnknownData02[0x3];                                       // 0x015D(0x0003) MISSED OFFSET
	int64_t                                            $AsyncResult_4;                                           // 0x0160(0x0008) (ZeroConstructor, IsPlainOldData)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("VerseClass CompanionAI.task_companion_ai$TacticalSprintService"));
		
		return ptr;
	}


	int64_t Update();
};


// VerseClass CompanionAI.task_companion_ai$WaitForDamage
// 0x0080 (0x01A0 - 0x0120)
class task_companion_ai$WaitForDamage : public task_t_
{
public:
	class companion_ai*                                _Self;                                                    // 0x0120(0x0008) (Parm, ZeroConstructor)
	struct FCompanionAI_Ftuple_L_R                     __verse_0xB2CDDD72_Argument;                              // 0x0128(0x0001) (Parm)
	EVerseTrue                                         $InvokeSureResultDummy_0;                                 // 0x0129(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x2];                                       // 0x012A(0x0002) MISSED OFFSET
	struct FScriptDelegate                             $Callee_1;                                                // 0x012C(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData01[0x10];                                      // 0x0138(0x0010) UNKNOWN PROPERTY: VerseStringProperty CompanionAI.task_companion_ai$WaitForDamage.$ExprResult_2
	class Object_32759*                                __verse_0x3051673F_Health_2;                              // 0x0148(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	unsigned char                                      UnknownData02[0x8];                                       // 0x0150(0x0008) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$WaitForDamage.$ExprResultStack_3
	class Object_32759*                                __verse_0x00000000__4;                                    // 0x0158(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	class task_t_*                                     $AsyncTask_4;                                             // 0x0160(0x0008) (ZeroConstructor)
	struct FScriptDelegate                             $AsyncTaskClass_5;                                        // 0x0168(0x0010) (ZeroConstructor)
	struct FCompanionAI_Ftuple_L_R                     $ExprResult_6;                                            // 0x0174(0x0001)
	unsigned char                                      UnknownData03[0x3];                                       // 0x0175(0x0003) MISSED OFFSET
	int64_t                                            $AsyncResult_7;                                           // 0x0178(0x0008) (ZeroConstructor, IsPlainOldData)
	EVerseTrue                                         $InvokeSureResultDummy_8;                                 // 0x0180(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData04[0x3];                                       // 0x0181(0x0003) MISSED OFFSET
	struct FScriptDelegate                             $Callee_9;                                                // 0x0184(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData05[0x10];                                      // 0x0190(0x0010) UNKNOWN PROPERTY: VerseStringProperty CompanionAI.task_companion_ai$WaitForDamage.$ExprResult_10

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("VerseClass CompanionAI.task_companion_ai$WaitForDamage"));
		
		return ptr;
	}


	int64_t Update();
};


// VerseClass CompanionAI.task_companion_ai$WaitForEntityMovement_L_Nentity_M_Nfloat_R
// 0x0128 (0x0248 - 0x0120)
class task_companion_ai$WaitForEntityMovement_L_Nentity_M_Nfloat_R : public task_t_
{
public:
	class companion_ai*                                _Self;                                                    // 0x0120(0x0008) (Parm, ZeroConstructor)
	struct Ftuple_Lentity_Mfloat_R                     __verse_0xB2CDDD72_Argument;                              // 0x0128(0x0010) (Parm)
	unsigned char                                      UnknownData00[0x8];                                       // 0x0138(0x0008) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$WaitForEntityMovement_L_Nentity_M_Nfloat_R.__verse_0xA8951FC3_EntityPositionComponent_1
	class Entity*                                      __verse_0x00000000__2;                                    // 0x0140(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	struct FScriptDelegate                             $Callee_0;                                                // 0x0148(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData01[0x4];                                       // 0x0154(0x0004) MISSED OFFSET
	class position_component*                          __verse_0xE47E86AC_EntityPositionComponentRef_3;          // 0x0158(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	unsigned char                                      UnknownData02[0x8];                                       // 0x0160(0x0008) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$WaitForEntityMovement_L_Nentity_M_Nfloat_R.$FallibleType_1
	unsigned char                                      UnknownData03[0x8];                                       // 0x0168(0x0008) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$WaitForEntityMovement_L_Nentity_M_Nfloat_R.$ExprResultStack_2
	struct Fvector3                                    __verse_0x455F599A_ReferencePosition_3;                   // 0x0170(0x0018) (ZeroConstructor, IsPlainOldData)
	class position_component*                          __verse_0x00000000__4;                                    // 0x0188(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	struct FScriptDelegate                             $Callee_3;                                                // 0x0190(0x0010) (ZeroConstructor)
	struct FCompanionAI_Ftuple_L_R                     $ExprResult_4;                                            // 0x019C(0x0001)
	unsigned char                                      UnknownData04[0x3];                                       // 0x019D(0x0003) MISSED OFFSET
	double                                             __verse_0x525BA815_DistanceFromReferencePosition_5;       // 0x01A0(0x0008) (ZeroConstructor, IsPlainOldData)
	struct FScriptDelegate                             $Callee_5;                                                // 0x01A8(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData05[0x4];                                       // 0x01B4(0x0004) MISSED OFFSET
	struct FCompanionAI_Ftuple_Lvector3_Mvector3_R     $ExprResult_6;                                            // 0x01B8(0x0030)
	struct Fvector3                                    $ExprResult_7;                                            // 0x01E8(0x0018) (ZeroConstructor, IsPlainOldData)
	class position_component*                          __verse_0x00000000__6;                                    // 0x0200(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	struct FScriptDelegate                             $Callee_8;                                                // 0x0208(0x0010) (ZeroConstructor)
	struct FCompanionAI_Ftuple_L_R                     $ExprResult_9;                                            // 0x0214(0x0001)
	unsigned char                                      UnknownData06[0x3];                                       // 0x0215(0x0003) MISSED OFFSET
	unsigned char                                      UnknownData07[0x9];                                       // 0x0215(0x0009) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_companion_ai$WaitForEntityMovement_L_Nentity_M_Nfloat_R.$ExprResultStack_10
	unsigned char                                      UnknownData08[0x7];                                       // 0x0221(0x0007) MISSED OFFSET
	class task_t_*                                     $AsyncTask_11;                                            // 0x0228(0x0008) (ZeroConstructor)
	struct FScriptDelegate                             $AsyncTaskClass_12;                                       // 0x0230(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData09[0x4];                                       // 0x023C(0x0004) MISSED OFFSET
	int64_t                                            $AsyncResult_13;                                          // 0x0240(0x0008) (ZeroConstructor, IsPlainOldData)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("VerseClass CompanionAI.task_companion_ai$WaitForEntityMovement_L_Nentity_M_Nfloat_R"));
		
		return ptr;
	}


	int64_t Update();
};


// VerseClass CompanionAI.task_fort_br_ai_actions_interface$RunDefaultBehavior
// 0x000A (0x012A - 0x0120)
class task_fort_br_ai_actions_interface$RunDefaultBehavior : public task_t_
{
public:
	class fort_br_ai_actions_interface*                _Self;                                                    // 0x0120(0x0008) (Parm, ZeroConstructor)
	struct FCompanionAI_Ftuple_L_R                     __verse_0xB2CDDD72_Argument;                              // 0x0128(0x0001) (Parm)
	Eaction_result                                     _RetVal;                                                  // 0x0129(0x0001) (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("VerseClass CompanionAI.task_fort_br_ai_actions_interface$RunDefaultBehavior"));
		
		return ptr;
	}


	int64_t Update();
};


// VerseClass CompanionAI.task_fort_npc_component$RunDefaultBehavior
// 0x000A (0x012A - 0x0120)
class task_fort_npc_component$RunDefaultBehavior : public task_t_
{
public:
	class fort_npc_component*                          _Self;                                                    // 0x0120(0x0008) (Parm, ZeroConstructor)
	struct FCompanionAI_Ftuple_L_R                     __verse_0xB2CDDD72_Argument;                              // 0x0128(0x0001) (Parm)
	Eaction_result                                     _RetVal;                                                  // 0x0129(0x0001) (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("VerseClass CompanionAI.task_fort_npc_component$RunDefaultBehavior"));
		
		return ptr;
	}


	int64_t Update();
};


// VerseClass CompanionAI.task_fort_ping_interface$OnNPCCommand
// 0x0049 (0x0169 - 0x0120)
class task_fort_ping_interface$OnNPCCommand : public task_t_
{
public:
	class fort_ping_interface*                         _Self;                                                    // 0x0120(0x0008) (Parm, ZeroConstructor)
	struct FCompanionAI_Ftuple_L_R                     __verse_0xB2CDDD72_Argument;                              // 0x0128(0x0001) (Parm)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0129(0x0007) MISSED OFFSET
	unsigned char                                      UnknownData01[0x39];                                      // 0x0129(0x0039) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_fort_ping_interface$OnNPCCommand._RetVal

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("VerseClass CompanionAI.task_fort_ping_interface$OnNPCCommand"));
		
		return ptr;
	}


	int64_t Update();
};


// VerseClass CompanionAI.task_ping_component$OnNPCCommand
// 0x0049 (0x0169 - 0x0120)
class task_ping_component$OnNPCCommand : public task_t_
{
public:
	class ping_component*                              _Self;                                                    // 0x0120(0x0008) (Parm, ZeroConstructor)
	struct FCompanionAI_Ftuple_L_R                     __verse_0xB2CDDD72_Argument;                              // 0x0128(0x0001) (Parm)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0129(0x0007) MISSED OFFSET
	unsigned char                                      UnknownData01[0x39];                                      // 0x0129(0x0039) UNKNOWN PROPERTY: OptionProperty CompanionAI.task_ping_component$OnNPCCommand._RetVal

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("VerseClass CompanionAI.task_ping_component$OnNPCCommand"));
		
		return ptr;
	}


	int64_t Update();
};


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

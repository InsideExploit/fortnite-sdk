// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Functions
//---------------------------------------------------------------------------

// Function CraftingUI.AthenaCraftingQuickBarButton.OnIsCraftableItemChanged
// (Event, Protected, BlueprintEvent)
// Parameters:
// bool                           bIsCraftableItem_69            (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void AthenaCraftingQuickBarButton::OnIsCraftableItemChanged(bool bIsCraftableItem_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CraftingUI.AthenaCraftingQuickBarButton.OnIsCraftableItemChanged"));

	AthenaCraftingQuickBarButton_OnIsCraftableItemChanged_Params params;
	params.bIsCraftableItem_69 = bIsCraftableItem_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CraftingUI.AthenaCraftingQuickBarButton.OnCanCraftNowChanged
// (Event, Protected, BlueprintEvent)
// Parameters:
// bool                           bCanCraftNow_69                (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void AthenaCraftingQuickBarButton::OnCanCraftNowChanged(bool bCanCraftNow_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CraftingUI.AthenaCraftingQuickBarButton.OnCanCraftNowChanged"));

	AthenaCraftingQuickBarButton_OnCanCraftNowChanged_Params params;
	params.bCanCraftNow_69 = bCanCraftNow_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CraftingUI.AthenaEquippedItemCraftingIndicator.OnIsCraftableItemChanged
// (Event, Protected, BlueprintEvent)
// Parameters:
// bool                           bIsCraftableItem_69            (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void AthenaEquippedItemCraftingIndicator::OnIsCraftableItemChanged(bool bIsCraftableItem_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CraftingUI.AthenaEquippedItemCraftingIndicator.OnIsCraftableItemChanged"));

	AthenaEquippedItemCraftingIndicator_OnIsCraftableItemChanged_Params params;
	params.bIsCraftableItem_69 = bIsCraftableItem_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CraftingUI.AthenaEquippedItemCraftingIndicator.OnCanCraftNowChanged
// (Event, Protected, BlueprintEvent)
// Parameters:
// bool                           bCanCraftNow_69                (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void AthenaEquippedItemCraftingIndicator::OnCanCraftNowChanged(bool bCanCraftNow_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CraftingUI.AthenaEquippedItemCraftingIndicator.OnCanCraftNowChanged"));

	AthenaEquippedItemCraftingIndicator_OnCanCraftNowChanged_Params params;
	params.bCanCraftNow_69 = bCanCraftNow_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CraftingUI.AthenaEquippedItemCraftingIndicator.HandleWeaponEquipped
// (Final, Native, Private)
// Parameters:
// class FortWeapon*              NewWeapon_69                   (Parm, ZeroConstructor)
// class FortWeapon*              PrevWeapon_69                  (Parm, ZeroConstructor)

void AthenaEquippedItemCraftingIndicator::HandleWeaponEquipped(class FortWeapon* NewWeapon_69, class FortWeapon* PrevWeapon_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CraftingUI.AthenaEquippedItemCraftingIndicator.HandleWeaponEquipped"));

	AthenaEquippedItemCraftingIndicator_HandleWeaponEquipped_Params params;
	params.NewWeapon_69 = NewWeapon_69;
	params.PrevWeapon_69 = PrevWeapon_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CraftingUI.AthenaInventoryItemInfoCraftingIndicator.OnIsCraftableItemChanged
// (Event, Protected, BlueprintEvent)
// Parameters:
// bool                           bIsCraftableItem_69            (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void AthenaInventoryItemInfoCraftingIndicator::OnIsCraftableItemChanged(bool bIsCraftableItem_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CraftingUI.AthenaInventoryItemInfoCraftingIndicator.OnIsCraftableItemChanged"));

	AthenaInventoryItemInfoCraftingIndicator_OnIsCraftableItemChanged_Params params;
	params.bIsCraftableItem_69 = bIsCraftableItem_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CraftingUI.AthenaInventoryItemInfoCraftingIndicator.OnCanCraftNowChanged
// (Event, Protected, BlueprintEvent)
// Parameters:
// bool                           bCanCraftNow_69                (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void AthenaInventoryItemInfoCraftingIndicator::OnCanCraftNowChanged(bool bCanCraftNow_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CraftingUI.AthenaInventoryItemInfoCraftingIndicator.OnCanCraftNowChanged"));

	AthenaInventoryItemInfoCraftingIndicator_OnCanCraftNowChanged_Params params;
	params.bCanCraftNow_69 = bCanCraftNow_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CraftingUI.AthenaInventoryItemInfoCraftingIndicator.HandleInventoryItemSelected
// (Final, Native, Private)
// Parameters:
// class FortItem*                SelectedItem_69                (Parm, ZeroConstructor)

void AthenaInventoryItemInfoCraftingIndicator::HandleInventoryItemSelected(class FortItem* SelectedItem_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CraftingUI.AthenaInventoryItemInfoCraftingIndicator.HandleInventoryItemSelected"));

	AthenaInventoryItemInfoCraftingIndicator_HandleInventoryItemSelected_Params params;
	params.SelectedItem_69 = SelectedItem_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CraftingUI.AthenaQuickBarSlotCraftingIndicator.OnIsCraftableItemChanged
// (Event, Protected, BlueprintEvent)
// Parameters:
// bool                           bIsCraftableItem_69            (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void AthenaQuickBarSlotCraftingIndicator::OnIsCraftableItemChanged(bool bIsCraftableItem_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CraftingUI.AthenaQuickBarSlotCraftingIndicator.OnIsCraftableItemChanged"));

	AthenaQuickBarSlotCraftingIndicator_OnIsCraftableItemChanged_Params params;
	params.bIsCraftableItem_69 = bIsCraftableItem_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CraftingUI.AthenaQuickBarSlotCraftingIndicator.OnIngredientChanged
// (Event, Protected, BlueprintEvent)
// Parameters:
// bool                           bCanCraftNow_69                (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void AthenaQuickBarSlotCraftingIndicator::OnIngredientChanged(bool bCanCraftNow_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CraftingUI.AthenaQuickBarSlotCraftingIndicator.OnIngredientChanged"));

	AthenaQuickBarSlotCraftingIndicator_OnIngredientChanged_Params params;
	params.bCanCraftNow_69 = bCanCraftNow_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CraftingUI.AthenaQuickBarSlotCraftingIndicator.OnCanCraftNowChanged
// (Event, Protected, BlueprintEvent)
// Parameters:
// bool                           bCanCraftNow_69                (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void AthenaQuickBarSlotCraftingIndicator::OnCanCraftNowChanged(bool bCanCraftNow_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CraftingUI.AthenaQuickBarSlotCraftingIndicator.OnCanCraftNowChanged"));

	AthenaQuickBarSlotCraftingIndicator_OnCanCraftNowChanged_Params params;
	params.bCanCraftNow_69 = bCanCraftNow_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CraftingUI.AthenaQuickBarSlotCraftingIndicator.HandleWeaponEquipped
// (Final, Native, Private)
// Parameters:
// class FortWeapon*              NewWeapon_69                   (Parm, ZeroConstructor)
// class FortWeapon*              PrevWeapon_69                  (Parm, ZeroConstructor)

void AthenaQuickBarSlotCraftingIndicator::HandleWeaponEquipped(class FortWeapon* NewWeapon_69, class FortWeapon* PrevWeapon_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CraftingUI.AthenaQuickBarSlotCraftingIndicator.HandleWeaponEquipped"));

	AthenaQuickBarSlotCraftingIndicator_HandleWeaponEquipped_Params params;
	params.NewWeapon_69 = NewWeapon_69;
	params.PrevWeapon_69 = PrevWeapon_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CraftingUI.FortCraftingIngredientWidget.OnIngredientWidgetUpdated
// (Event, Protected, BlueprintEvent)
// Parameters:
// int                            NumAvailable_69                (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// int                            NumRequired_69                 (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// bool                           bIsPrimaryIngredient_69        (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// bool                           bIsLastIngredient_69           (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void FortCraftingIngredientWidget::OnIngredientWidgetUpdated(int NumAvailable_69, int NumRequired_69, bool bIsPrimaryIngredient_69, bool bIsLastIngredient_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CraftingUI.FortCraftingIngredientWidget.OnIngredientWidgetUpdated"));

	FortCraftingIngredientWidget_OnIngredientWidgetUpdated_Params params;
	params.NumAvailable_69 = NumAvailable_69;
	params.NumRequired_69 = NumRequired_69;
	params.bIsPrimaryIngredient_69 = bIsPrimaryIngredient_69;
	params.bIsLastIngredient_69 = bIsLastIngredient_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CraftingUI.FortCraftingItemInfoWidget.OnItemRaritySet
// (Event, Protected, BlueprintEvent)
// Parameters:
// EFortRarity                    Rarity_69                      (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// struct FFortRarityItemData     RarityItemData_69              (ConstParm, Parm)

void FortCraftingItemInfoWidget::OnItemRaritySet(EFortRarity Rarity_69, const struct FFortRarityItemData& RarityItemData_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CraftingUI.FortCraftingItemInfoWidget.OnItemRaritySet"));

	FortCraftingItemInfoWidget_OnItemRaritySet_Params params;
	params.Rarity_69 = Rarity_69;
	params.RarityItemData_69 = RarityItemData_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CraftingUI.FortCraftingListEntry.OnCraftingListItemSet
// (Event, Protected, BlueprintEvent)

void FortCraftingListEntry::OnCraftingListItemSet()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CraftingUI.FortCraftingListEntry.OnCraftingListItemSet"));

	FortCraftingListEntry_OnCraftingListItemSet_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CraftingUI.FortCraftingTab.OnFormulaListUpdated
// (Event, Protected, BlueprintEvent)
// Parameters:
// int                            NumFormulas_69                 (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void FortCraftingTab::OnFormulaListUpdated(int NumFormulas_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CraftingUI.FortCraftingTab.OnFormulaListUpdated"));

	FortCraftingTab_OnFormulaListUpdated_Params params;
	params.NumFormulas_69 = NumFormulas_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CraftingUI.FortCraftingTab.HandleInventoryItemSelected
// (Final, Native, Private)
// Parameters:
// class FortItem*                Item_69                        (Parm, ZeroConstructor)

void FortCraftingTab::HandleInventoryItemSelected(class FortItem* Item_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CraftingUI.FortCraftingTab.HandleInventoryItemSelected"));

	FortCraftingTab_HandleInventoryItemSelected_Params params;
	params.Item_69 = Item_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CraftingUI.FortPotContentsPopup.SetOwningCraftingObject
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// class CraftingObjectBGA*       InCraftingObject_69            (Parm, ZeroConstructor)

void FortPotContentsPopup::SetOwningCraftingObject(class CraftingObjectBGA* InCraftingObject_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CraftingUI.FortPotContentsPopup.SetOwningCraftingObject"));

	FortPotContentsPopup_SetOwningCraftingObject_Params params;
	params.InCraftingObject_69 = InCraftingObject_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

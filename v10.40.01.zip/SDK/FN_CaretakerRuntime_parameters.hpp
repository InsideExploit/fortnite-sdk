#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function CaretakerRuntime.FortAthenaCaretakerAIController.OnMovementModeChanged
struct FortAthenaCaretakerAIController_OnMovementModeChanged_Params
{
	class Character*                                   CharacterOwner_69;                                        // (Parm, ZeroConstructor)
	TEnumAsByte<EMovementMode>                         PreviousMovementMode_69;                                  // (Parm, ZeroConstructor, IsPlainOldData)
	unsigned char                                      PreviousCustomMode_69;                                    // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function CaretakerRuntime.FortAthenaCaretakerAIController.DebugUpdate
struct FortAthenaCaretakerAIController_DebugUpdate_Params
{
	float                                              UpdateInterval_69;                                        // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function CaretakerRuntime.FortAIAnimInstance_Caretaker.SetDelayedMaterialParameters
struct FortAIAnimInstance_Caretaker_SetDelayedMaterialParameters_Params
{
};

// Function CaretakerRuntime.FortAIAnimInstance_Caretaker.GetWorldStriderComponent
struct FortAIAnimInstance_Caretaker_GetWorldStriderComponent_Params
{
	class FortAnimWorldStriderComponent*               ReturnValue_69;                                           // (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)
};

// Function CaretakerRuntime.FortAIAnimInstance_Caretaker.GetWalkSpeedWarpingValue
struct FortAIAnimInstance_Caretaker_GetWalkSpeedWarpingValue_Params
{
	float                                              ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CaretakerRuntime.FortAIAnimInstance_Caretaker.GetWalkPlayRateValue
struct FortAIAnimInstance_Caretaker_GetWalkPlayRateValue_Params
{
	float                                              ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CaretakerRuntime.FortAIAnimInstance_Caretaker.GetStartAnimPosition
struct FortAIAnimInstance_Caretaker_GetStartAnimPosition_Params
{
	float                                              ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

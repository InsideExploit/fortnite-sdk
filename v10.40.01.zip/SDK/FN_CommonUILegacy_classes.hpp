#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Classes
//---------------------------------------------------------------------------

// Class CommonUILegacy.CommonActivatablePanelLegacy
// 0x0138 (0x04E0 - 0x03A8)
class CommonActivatablePanelLegacy : public CommonActivatableWidget
{
public:
	unsigned char                                      UnknownData00[0x8];                                       // 0x03A8(0x0008) MISSED OFFSET
	unsigned char                                      UnknownData01[0x10];                                      // 0x03A8(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty CommonUILegacy.CommonActivatablePanelLegacy.OnWidgetActivated_69
	unsigned char                                      UnknownData02[0x10];                                      // 0x03C0(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty CommonUILegacy.CommonActivatablePanelLegacy.OnWidgetDeactivated_69
	bool                                               bConsumeAllActions_69;                                    // 0x03D0(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	bool                                               bExposeActionsExternally_69;                              // 0x03D1(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	bool                                               bShouldBypassStack_69;                                    // 0x03D2(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData03[0x10D];                                     // 0x03D3(0x010D) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CommonUILegacy.CommonActivatablePanelLegacy"));
		
		return ptr;
	}


	void SetInputActionHandlerWithProgressPopupMenu(const struct FDataTableRowHandle& InputActionRow_69, const struct FScriptDelegate& CommitedEvent_69, const struct FScriptDelegate& ProgressEvent_69, class CommonPopupMenuLegacy* PopupMenu_69);
	void SetInputActionHandlerWithProgress(const struct FDataTableRowHandle& InputActionRow_69, const struct FScriptDelegate& CommitedEvent_69, const struct FScriptDelegate& ProgressEvent_69);
	void SetInputActionHandlerWithPopupMenu(const struct FDataTableRowHandle& InputActionRow_69, const struct FScriptDelegate& CommitedEvent_69, class CommonPopupMenuLegacy* PopupMenu_69);
	void SetInputActionHandler(const struct FDataTableRowHandle& InputActionRow_69, const struct FScriptDelegate& CommitedEvent_69);
	void SetActionHandlerStateWithDisabledCommitEvent(class DataTable* DataTable_69, const struct FName& RowName_69, EInputActionState State_69, const struct FScriptDelegate& DisabledCommitEvent_69);
	void SetActionHandlerStateFromHandleWithDisabledCommitEvent(const struct FDataTableRowHandle& InputActionRow_69, EInputActionState State_69, const struct FScriptDelegate& DisabledCommitEvent_69);
	void SetActionHandlerStateFromHandle(const struct FDataTableRowHandle& InputActionRow_69, EInputActionState State_69);
	void SetActionHandlerState(class DataTable* DataTable_69, const struct FName& RowName_69, EInputActionState State_69);
	void RemoveInputActionHandler(const struct FDataTableRowHandle& InputActionRow_69);
	void RemoveAllInputActionHandlers();
	void PopPanel();
	void OnTransitionedBySwitcher();
	void OnRemovedFromActivationStack();
	void OnInputModeChanged(bool bUsingGamepad_69);
	void OnBeginOutro();
	void OnBeginIntro();
	void OnAddedToActivationStack();
	bool IsIntroed();
	bool IsInActivationStack();
	bool HasInputActionHandler(const struct FDataTableRowHandle& InputActionRow_69);
	bool GetInputActions(TArray<struct FCommonInputActionHandlerData>* InputActionDataRows_69);
	void EndOutro();
	void EndIntro();
	void BeginOutro();
	void BeginIntro();
	void AddInputActionNoHandler(class DataTable* DataTable_69, const struct FName& RowName_69);
	void AddInputActionHandlerWithProgressPopup(class DataTable* DataTable_69, const struct FName& RowName_69, const struct FScriptDelegate& CommitedEvent_69, const struct FScriptDelegate& ProgressEvent_69, class CommonPopupMenuLegacy* PopupMenu_69);
	void AddInputActionHandlerWithProgress(class DataTable* DataTable_69, const struct FName& RowName_69, const struct FScriptDelegate& CommitedEvent_69, const struct FScriptDelegate& ProgressEvent_69);
	void AddInputActionHandlerWithPopup(class DataTable* DataTable_69, const struct FName& RowName_69, const struct FScriptDelegate& CommitedEvent_69, class CommonPopupMenuLegacy* PopupMenu_69);
	void AddInputActionHandler(class DataTable* DataTable_69, const struct FName& RowName_69, const struct FScriptDelegate& CommitedEvent_69);
};


// Class CommonUILegacy.CommonButtonGroupLegacy
// 0x00A0 (0x01B0 - 0x0110)
class CommonButtonGroupLegacy : public CommonButtonGroupBase
{
public:
	unsigned char                                      UnknownData00[0x10];                                      // 0x0110(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty CommonUILegacy.CommonButtonGroupLegacy.OnSelectedButtonChanged_69
	unsigned char                                      UnknownData01[0x18];                                      // 0x0120(0x0018) MISSED OFFSET
	unsigned char                                      UnknownData02[0x10];                                      // 0x0120(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty CommonUILegacy.CommonButtonGroupLegacy.OnHoveredButtonChanged_69
	unsigned char                                      UnknownData03[0x18];                                      // 0x0148(0x0018) MISSED OFFSET
	unsigned char                                      UnknownData04[0x10];                                      // 0x0148(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty CommonUILegacy.CommonButtonGroupLegacy.OnButtonClicked_69
	unsigned char                                      UnknownData05[0x18];                                      // 0x0170(0x0018) MISSED OFFSET
	unsigned char                                      UnknownData06[0x10];                                      // 0x0170(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty CommonUILegacy.CommonButtonGroupLegacy.OnButtonDoubleClicked_69
	unsigned char                                      UnknownData07[0x18];                                      // 0x0198(0x0018) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CommonUILegacy.CommonButtonGroupLegacy"));
		
		return ptr;
	}


	void OnSelectionStateChanged(class CommonButtonLegacy* BaseButton_69, bool bIsSelected_69);
	void OnHandleButtonDoubleClicked(class CommonButtonLegacy* BaseButton_69);
	void OnHandleButtonClicked(class CommonButtonLegacy* BaseButton_69);
	void OnButtonUnhovered(class CommonButtonLegacy* BaseButton_69);
	void OnButtonHovered(class CommonButtonLegacy* BaseButton_69);
	void HandleOnSelectedButtonChanged(class CommonButtonBase* BaseButton_69, int InSelectedButtonIndex_69);
	void HandleOnHoveredButtonChanged(class CommonButtonBase* BaseButton_69, int InSelectedButtonIndex_69);
	void HandleOnButtonDoubleClicked(class CommonButtonBase* BaseButton_69, int InSelectedButtonIndex_69);
	void HandleOnButtonClicked(class CommonButtonBase* BaseButton_69, int InSelectedButtonIndex_69);
	void HandleNativeOnSelectedButtonChanged(class CommonButtonBase* BaseButton_69, int InSelectedButtonIndex_69);
	void HandleNativeOnHoveredButtonChanged(class CommonButtonBase* BaseButton_69, int InSelectedButtonIndex_69);
	void HandleNativeOnButtonDoubleClicked(class CommonButtonBase* BaseButton_69, int InSelectedButtonIndex_69);
	void HandleNativeOnButtonClicked(class CommonButtonBase* BaseButton_69, int InSelectedButtonIndex_69);
	class CommonButtonLegacy* GetSelectedButton();
	class CommonButtonLegacy* GetButtonAtIndex(int Index_69);
	class CommonButtonGroupLegacy* STATIC_CreateButtonGroup(class Object_32759* ContextObject_69, bool bInSelectionRequired_69);
};


// Class CommonUILegacy.CommonButtonInternalLegacy
// 0x0000 (0x0610 - 0x0610)
class CommonButtonInternalLegacy : public CommonButtonInternalBase
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CommonUILegacy.CommonButtonInternalLegacy"));
		
		return ptr;
	}

};


// Class CommonUILegacy.CommonButtonLegacy
// 0x0050 (0x1430 - 0x13E0)
class CommonButtonLegacy : public CommonButtonBase
{
public:
	unsigned char                                      UnknownData00[0x10];                                      // 0x13E0(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty CommonUILegacy.CommonButtonLegacy.OnSelectedChanged_69
	unsigned char                                      UnknownData01[0x10];                                      // 0x13F0(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty CommonUILegacy.CommonButtonLegacy.OnButtonClicked_69
	unsigned char                                      UnknownData02[0x10];                                      // 0x1400(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty CommonUILegacy.CommonButtonLegacy.OnButtonDoubleClicked_69
	unsigned char                                      UnknownData03[0x10];                                      // 0x1410(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty CommonUILegacy.CommonButtonLegacy.OnButtonHovered_69
	unsigned char                                      UnknownData04[0x10];                                      // 0x1420(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty CommonUILegacy.CommonButtonLegacy.OnButtonUnhovered_69

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CommonUILegacy.CommonButtonLegacy"));
		
		return ptr;
	}


	void SetTriggeredInputActionLegacy(const struct FDataTableRowHandle& InputActionRow_69, class CommonActivatablePanelLegacy* OldPanel_69);
	void HandleOnSelectedChanged(class CommonButtonBase* Button_69, bool InSelected_69);
	void HandleOnButtonUnhovered(class CommonButtonBase* Button_69);
	void HandleOnButtonHovered(class CommonButtonBase* Button_69);
	void HandleOnButtonDoubleClicked(class CommonButtonBase* Button_69);
	void HandleOnButtonClicked(class CommonButtonBase* Button_69);
};


// Class CommonUILegacy.CommonGlobalInputHandlerLegacy
// 0x0048 (0x0070 - 0x0028)
class CommonGlobalInputHandlerLegacy : public Object_32759
{
public:
	unsigned char                                      UnknownData00[0x48];                                      // 0x0028(0x0048) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CommonUILegacy.CommonGlobalInputHandlerLegacy"));
		
		return ptr;
	}

};


// Class CommonUILegacy.CommonInputManagerLegacy
// 0x00E0 (0x0108 - 0x0028)
class CommonInputManagerLegacy : public Object_32759
{
public:
	unsigned char                                      UnknownData00[0x80];                                      // 0x0028(0x0080) MISSED OFFSET
	TScriptInterface<class CommonActionHandlerInterface_32759> CurrentlyHeldActionInputHandler_69;                       // 0x00A8(0x0010) (ZeroConstructor, IsPlainOldData)
	TArray<class CommonActivatablePanelLegacy*>        ActivatablePanelStack_69;                                 // 0x00B8(0x0010) (ExportObject, ZeroConstructor)
	class CommonGlobalInputHandlerLegacy*              GlobalInputHandler_69;                                    // 0x00C8(0x0008) (ZeroConstructor)
	unsigned char                                      UnknownData01[0x18];                                      // 0x00D0(0x0018) MISSED OFFSET
	TArray<struct FOperation>                          Operations_69;                                            // 0x00E8(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData02[0x10];                                      // 0x00F8(0x0010) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CommonUILegacy.CommonInputManagerLegacy"));
		
		return ptr;
	}


	void SuspendStartingOperationProcessing();
	bool StopListeningForExistingHeldAction(const struct FDataTableRowHandle& InputActionDataRow_69, const struct FScriptDelegate& CompleteEvent_69, const struct FScriptDelegate& ProgressEvent_69);
	bool StartListeningForExistingHeldAction(const struct FDataTableRowHandle& InputActionDataRow_69, const struct FScriptDelegate& CompleteEvent_69, const struct FScriptDelegate& ProgressEvent_69);
	void SetGlobalInputHandlerPriorityFilter(int InFilterPriority_69);
	void ResumeStartingOperationProcessing();
	void PushActivatablePanel(class CommonActivatablePanelLegacy* ActivatablePanel_69, bool bIntroPanel_69, bool bOutroPanelBelow_69);
	void PopActivatablePanel(class CommonActivatablePanelLegacy* ActivatablePanel_69);
	bool IsPanelOnStack(class CommonActivatablePanelLegacy* InPanel_69);
	bool IsInputSuspended();
	class CommonActivatablePanelLegacy* GetTopPanel();
	int GetGlobalInputHandlerPriorityFilter();
	bool GetAvailableInputActions(TArray<struct FCommonInputActionHandlerData>* AvailableInputActions_69);
};


// Class CommonUILegacy.CommonInputReflectorLegacy
// 0x0030 (0x02C0 - 0x0290)
class CommonInputReflectorLegacy : public CommonUserWidget
{
public:
	class CommonButtonLegacy*                          ButtonType_69;                                            // 0x0290(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
	TArray<class CommonButtonLegacy*>                  ActiveButtons_69;                                         // 0x0298(0x0010) (ExportObject, ZeroConstructor)
	TArray<class CommonButtonLegacy*>                  InactiveButtons_69;                                       // 0x02A8(0x0010) (ExportObject, ZeroConstructor)
	unsigned char                                      UnknownData00[0x8];                                       // 0x02B8(0x0008) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CommonUILegacy.CommonInputReflectorLegacy"));
		
		return ptr;
	}


	void OnButtonAdded(class CommonButtonLegacy* AddedButton_69, const struct FCommonInputActionHandlerData& Data_69);
};


// Class CommonUILegacy.CommonPopupButtonLegacy
// 0x0010 (0x1440 - 0x1430)
class CommonPopupButtonLegacy : public CommonButtonLegacy
{
public:
	class MenuAnchor*                                  PopupMenuAnchor_69;                                       // 0x1430(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)
	class CommonPopupMenuLegacy*                       PopupMenu_69;                                             // 0x1438(0x0008) (ExportObject, ZeroConstructor, InstancedReference)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CommonUILegacy.CommonPopupButtonLegacy"));
		
		return ptr;
	}


	class UserWidget* GetMenuAnchorWidget();
};


// Class CommonUILegacy.CommonPopupMenuLegacy
// 0x0018 (0x04F8 - 0x04E0)
class CommonPopupMenuLegacy : public CommonActivatablePanelLegacy
{
public:
	bool                                               bUseInputStack_69;                                        // 0x04E0(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x04E1(0x0003) MISSED OFFSET
	TWeakObjectPtr<class MenuAnchor>                   OwningMenuAnchor_69;                                      // 0x04E4(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference, IsPlainOldData)
	TWeakObjectPtr<class Object_32759>                 ContextProvidingObject_69;                                // 0x04EC(0x0008) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x4];                                       // 0x04F4(0x0004) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CommonUILegacy.CommonPopupMenuLegacy"));
		
		return ptr;
	}


	void SetOwningMenuAnchor(class MenuAnchor* MenuAnchor_69);
	void SetContextProvider(class Object_32759* ContextProvidingObject_69);
	void RequestClose();
	void OnIsOpenChanged(bool IsOpen_69);
	void HandlePreDifferentContextProviderSet();
	void HandlePostDifferentContextProviderSet();
};


// Class CommonUILegacy.CommonTabListWidgetLegacy
// 0x0020 (0x0390 - 0x0370)
class CommonTabListWidgetLegacy : public CommonTabListWidgetBase
{
public:
	unsigned char                                      UnknownData00[0x10];                                      // 0x0370(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty CommonUILegacy.CommonTabListWidgetLegacy.OnTabButtonCreated_69
	unsigned char                                      UnknownData01[0x10];                                      // 0x0380(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty CommonUILegacy.CommonTabListWidgetLegacy.OnTabButtonRemoved_69

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CommonUILegacy.CommonTabListWidgetLegacy"));
		
		return ptr;
	}


	void OnTabButtonRemoved__DelegateSignature(const struct FName& TabId_69, class CommonButtonLegacy* TabButton_69);
	void OnTabButtonCreated__DelegateSignature(const struct FName& TabId_69, class CommonButtonLegacy* TabButton_69);
	void HandleTabRemoved(const struct FName& TabNameID_69, class CommonButtonLegacy* TabButton_69);
	void HandleTabCreated(const struct FName& TabNameID_69, class CommonButtonLegacy* TabButton_69);
	void HandleOnTabButtonRemoved(const struct FName& TabId_69, class CommonButtonBase* TabButton_69);
	void HandleOnTabButtonCreated(const struct FName& TabId_69, class CommonButtonBase* TabButton_69);
	class CommonButtonLegacy* GetTabButtonByID(const struct FName& TabNameID_69);
};


// Class CommonUILegacy.CommonUIActionRouterLegacy
// 0x0008 (0x0160 - 0x0158)
class CommonUIActionRouterLegacy : public CommonUIActionRouterBase
{
public:
	unsigned char                                      UnknownData00[0x8];                                       // 0x0158(0x0008) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CommonUILegacy.CommonUIActionRouterLegacy"));
		
		return ptr;
	}

};


// Class CommonUILegacy.CommonUISubsystemLegacy
// 0x0030 (0x0070 - 0x0040)
class CommonUISubsystemLegacy : public CommonUISubsystemBase
{
public:
	unsigned char                                      UnknownData00[0x10];                                      // 0x0040(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty CommonUILegacy.CommonUISubsystemLegacy.OnInputSuspensionChanged_69
	class CommonInputManagerLegacy*                    CommonInputManager_69;                                    // 0x0050(0x0008) (ZeroConstructor, Transient)
	unsigned char                                      UnknownData01[0x18];                                      // 0x0058(0x0018) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CommonUILegacy.CommonUISubsystemLegacy"));
		
		return ptr;
	}


	void InputSuspensionChanged__DelegateSignature(bool bInputSuspended_69);
	class CommonInputManagerLegacy* GetInputManager();
};


// Class CommonUILegacy.CommonVisibilityWidgetLegacy
// 0x0010 (0x0300 - 0x02F0)
class CommonVisibilityWidgetLegacy : public CommonBorder
{
public:
	bool                                               bShowForGamepad_69;                                       // 0x02F0(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	bool                                               bShowForMouseAndKeyboard_69;                              // 0x02F1(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	bool                                               bShowForTouch_69;                                         // 0x02F2(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	bool                                               bShowForPC_69;                                            // 0x02F3(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	bool                                               bShowForMac_69;                                           // 0x02F4(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	bool                                               bShowForPS4_69;                                           // 0x02F5(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	bool                                               bShowForPS5_69;                                           // 0x02F6(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	bool                                               bShowForXBox_69;                                          // 0x02F7(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	bool                                               bShowForXSX_69;                                           // 0x02F8(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	bool                                               bShowForIOS_69;                                           // 0x02F9(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	bool                                               bShowForAndroid_69;                                       // 0x02FA(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	bool                                               bShowForErebus_69;                                        // 0x02FB(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	ESlateVisibility                                   VisibleType_69;                                           // 0x02FC(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	ESlateVisibility                                   HiddenType_69;                                            // 0x02FD(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x2];                                       // 0x02FE(0x0002) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CommonUILegacy.CommonVisibilityWidgetLegacy"));
		
		return ptr;
	}

};


// Class CommonUILegacy.CommonWidgetStackLegacy
// 0x0010 (0x01A8 - 0x0198)
class CommonWidgetStackLegacy : public CommonVisibilitySwitcher
{
public:
	unsigned char                                      UnknownData00[0x10];                                      // 0x0198(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty CommonUILegacy.CommonWidgetStackLegacy.OnActiveWidgetChangedLegacyEvent_69

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CommonUILegacy.CommonWidgetStackLegacy"));
		
		return ptr;
	}


	void PushWidget(class Widget* InWidget_69);
	class Widget* PopWidget();
	void OnActiveWidgetChangedLegacy__DelegateSignature(class Widget* InActiveWidget_69, int InActiveWidgetIndex_69);
	void DeactivateWidget();
	void ActivateWidget();
};


// Class CommonUILegacy.CommonWidgetSwitcherLegacy
// 0x0028 (0x0210 - 0x01E8)
class CommonWidgetSwitcherLegacy : public CommonAnimatedSwitcher
{
public:
	unsigned char                                      UnknownData00[0x10];                                      // 0x01E8(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty CommonUILegacy.CommonWidgetSwitcherLegacy.OnActiveWidgetDeactivated_69
	unsigned char                                      UnknownData01[0x10];                                      // 0x01F8(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty CommonUILegacy.CommonWidgetSwitcherLegacy.OnActiveWidgetChanged_69
	bool                                               bWidgetActivationEnabled_69;                              // 0x0208(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	bool                                               bOutroPanelBelow_69;                                      // 0x0209(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData02[0x6];                                       // 0x020A(0x0006) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CommonUILegacy.CommonWidgetSwitcherLegacy"));
		
		return ptr;
	}


	void SetActiveWidgetIndex_Advanced(int Index_69, bool AttemptActivationChange_69);
	void SetActiveWidget_Advanced(class Widget* Widget_69, bool AttemptActivationChange_69);
	void HandleActiveWidgetDeactivated(class CommonActivatablePanelLegacy* DeactivatedPanel_69);
	void DeactivateWidget();
	void ActivateWidget();
};


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

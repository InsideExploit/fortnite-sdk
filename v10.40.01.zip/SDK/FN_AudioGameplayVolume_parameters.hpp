#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function AudioGameplayVolume.AudioGameplayVolumeMutator.SetPriority
struct AudioGameplayVolumeMutator_SetPriority_Params
{
	int                                                InPriority_69;                                            // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function AudioGameplayVolume.AttenuationVolumeComponent.SetInteriorVolume
struct AttenuationVolumeComponent_SetInteriorVolume_Params
{
	float                                              Volume_69;                                                // (Parm, ZeroConstructor, IsPlainOldData)
	float                                              InterpolateTime_69;                                       // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function AudioGameplayVolume.AttenuationVolumeComponent.SetExteriorVolume
struct AttenuationVolumeComponent_SetExteriorVolume_Params
{
	float                                              Volume_69;                                                // (Parm, ZeroConstructor, IsPlainOldData)
	float                                              InterpolateTime_69;                                       // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function AudioGameplayVolume.AudioGameplayVolume.SetEnabled
struct AudioGameplayVolume_SetEnabled_Params
{
	bool                                               bEnable_69;                                               // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function AudioGameplayVolume.AudioGameplayVolume.OnRep_bEnabled
struct AudioGameplayVolume_OnRep_bEnabled_Params
{
};

// Function AudioGameplayVolume.AudioGameplayVolume.OnListenerExit
struct AudioGameplayVolume_OnListenerExit_Params
{
};

// Function AudioGameplayVolume.AudioGameplayVolume.OnListenerEnter
struct AudioGameplayVolume_OnListenerEnter_Params
{
};

// Function AudioGameplayVolume.FilterVolumeComponent.SetInteriorLPF
struct FilterVolumeComponent_SetInteriorLPF_Params
{
	float                                              Volume_69;                                                // (Parm, ZeroConstructor, IsPlainOldData)
	float                                              InterpolateTime_69;                                       // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function AudioGameplayVolume.FilterVolumeComponent.SetExteriorLPF
struct FilterVolumeComponent_SetExteriorLPF_Params
{
	float                                              Volume_69;                                                // (Parm, ZeroConstructor, IsPlainOldData)
	float                                              InterpolateTime_69;                                       // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function AudioGameplayVolume.ReverbVolumeComponent.SetReverbSettings
struct ReverbVolumeComponent_SetReverbSettings_Params
{
	struct FReverbSettings                             NewReverbSettings_69;                                     // (ConstParm, Parm, OutParm, ReferenceParm)
};

// Function AudioGameplayVolume.SubmixOverrideVolumeComponent.SetSubmixOverrideSettings
struct SubmixOverrideVolumeComponent_SetSubmixOverrideSettings_Params
{
	TArray<struct FAudioVolumeSubmixOverrideSettings>  NewSubmixOverrideSettings_69;                             // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
};

// Function AudioGameplayVolume.SubmixSendVolumeComponent.SetSubmixSendSettings
struct SubmixSendVolumeComponent_SetSubmixSendSettings_Params
{
	TArray<struct FAudioVolumeSubmixSendSettings>      NewSubmixSendSettings_69;                                 // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

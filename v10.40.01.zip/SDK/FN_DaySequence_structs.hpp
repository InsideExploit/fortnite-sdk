#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Script Structs
//---------------------------------------------------------------------------

// ScriptStruct DaySequence.DaySequenceBindingReference
// 0x0060
struct FDaySequenceBindingReference
{
	unsigned char                                      UnknownData00[0x28];                                      // 0x0000(0x0028) UNKNOWN PROPERTY: SoftObjectProperty DaySequence.DaySequenceBindingReference.ExternalObjectPath_69
	struct FString                                     ObjectPath_69;                                            // 0x0028(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData01[0x28];                                      // 0x0038(0x0028) UNKNOWN PROPERTY: SoftClassProperty DaySequence.DaySequenceBindingReference.ObjectClass_69
};

// ScriptStruct DaySequence.DaySequenceBindingReferenceArray
// 0x0010
struct FDaySequenceBindingReferenceArray
{
	TArray<struct FDaySequenceBindingReference>        References_69;                                            // 0x0000(0x0010) (ZeroConstructor)
};

// ScriptStruct DaySequence.DaySequenceBindingReferences
// 0x00A0
struct FDaySequenceBindingReferences
{
	TMap<struct FGuid, struct FDaySequenceBindingReferenceArray> BindingIdToReferences_69;                                 // 0x0000(0x0050)
	unsigned char                                      UnknownData00[0x50];                                      // 0x0050(0x0050) UNKNOWN PROPERTY: SetProperty DaySequence.DaySequenceBindingReferences.AnimSequenceInstances_69
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Classes
//---------------------------------------------------------------------------

// Class DataAssetDirectory.DataAssetDirectoryManager
// 0x01A8 (0x01D0 - 0x0028)
class DataAssetDirectoryManager : public Object_32759
{
public:
	unsigned char                                      UnknownData00[0x178];                                     // 0x0028(0x0178) MISSED OFFSET
	TArray<class Object_32759*>                        PatchedAssets_69;                                         // 0x01A0(0x0010) (ZeroConstructor)
	struct FDateTime                                   LastUpdateCheck_69;                                       // 0x01B0(0x0008) (ZeroConstructor)
	uint32_t                                           UpdateCheckLimitSeconds_69;                               // 0x01B8(0x0004) (ZeroConstructor, Config, IsPlainOldData)
	bool                                               bEnabled_69;                                              // 0x01BC(0x0001) (ZeroConstructor, Config, IsPlainOldData)
	bool                                               bFailOnError_69;                                          // 0x01BD(0x0001) (ZeroConstructor, Config, IsPlainOldData)
	bool                                               bAnalyticsEnabled_69;                                     // 0x01BE(0x0001) (ZeroConstructor, Config, IsPlainOldData)
	unsigned char                                      UnknownData01[0x11];                                      // 0x01BF(0x0011) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class DataAssetDirectory.DataAssetDirectoryManager"));
		
		return ptr;
	}

};


// Class DataAssetDirectory.DataAssetDirectoryPatchableAsset
// 0x0000 (0x0028 - 0x0028)
class DataAssetDirectoryPatchableAsset : public Interface
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class DataAssetDirectory.DataAssetDirectoryPatchableAsset"));
		
		return ptr;
	}

};


// Class DataAssetDirectory.DataAssetDirectoryPatcher
// 0x0000 (0x0028 - 0x0028)
class DataAssetDirectoryPatcher : public Object_32759
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class DataAssetDirectory.DataAssetDirectoryPatcher"));
		
		return ptr;
	}

};


// Class DataAssetDirectory.DataAssetDirectorySimpleObject
// 0x0008 (0x0030 - 0x0028)
class DataAssetDirectorySimpleObject : public Object_32759
{
public:
	int                                                IntProperty_69;                                           // 0x0028(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x002C(0x0004) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class DataAssetDirectory.DataAssetDirectorySimpleObject"));
		
		return ptr;
	}

};


// Class DataAssetDirectory.DataAssetDirectoryTestPODAsset
// 0x0050 (0x0078 - 0x0028)
class DataAssetDirectoryTestPODAsset : public Object_32759
{
public:
	struct FString                                     AssetName_69;                                             // 0x0028(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance)
	EDataAssetDirectoryTestEnum                        EnumProperty_69;                                          // 0x0038(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0039(0x0003) MISSED OFFSET
	int                                                IntProperty_69;                                           // 0x003C(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	float                                              FloatProperty_69;                                         // 0x0040(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	bool                                               BoolProperty_69;                                          // 0x0044(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData01[0x3];                                       // 0x0045(0x0003) MISSED OFFSET
	struct FString                                     StringProperty_69;                                        // 0x0048(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance)
	struct FName                                       NameProperty_69;                                          // 0x0058(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData02[0x4];                                       // 0x005C(0x0004) MISSED OFFSET
	struct FText                                       TextProperty_69;                                          // 0x0060(0x0018) (Edit, BlueprintVisible, BlueprintReadOnly, DisableEditOnInstance)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class DataAssetDirectory.DataAssetDirectoryTestPODAsset"));
		
		return ptr;
	}

};


// Class DataAssetDirectory.DataAssetDirectoryTestStructAsset
// 0x0040 (0x0068 - 0x0028)
class DataAssetDirectoryTestStructAsset : public Object_32759
{
public:
	struct FDataAssetDirectoryTestPODStruct            TestStruct_69;                                            // 0x0028(0x0040) (Edit, BlueprintVisible, BlueprintReadOnly, DisableEditOnInstance)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class DataAssetDirectory.DataAssetDirectoryTestStructAsset"));
		
		return ptr;
	}

};


// Class DataAssetDirectory.DataAssetDirectoryTestArrayAsset
// 0x0020 (0x0048 - 0x0028)
class DataAssetDirectoryTestArrayAsset : public Object_32759
{
public:
	TArray<int>                                        IntArray_69;                                              // 0x0028(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance)
	TArray<struct FDataAssetDirectoryTestSimpleStruct> SimpleStructArray_69;                                     // 0x0038(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class DataAssetDirectory.DataAssetDirectoryTestArrayAsset"));
		
		return ptr;
	}

};


// Class DataAssetDirectory.DataAssetDirectoryTestObjectAsset
// 0x0008 (0x0030 - 0x0028)
class DataAssetDirectoryTestObjectAsset : public Object_32759
{
public:
	class DataAssetDirectorySimpleObject*              SimpleObject_69;                                          // 0x0028(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class DataAssetDirectory.DataAssetDirectoryTestObjectAsset"));
		
		return ptr;
	}

};


// Class DataAssetDirectory.DataAssetDirectoryTestMapAsset
// 0x0140 (0x0168 - 0x0028)
class DataAssetDirectoryTestMapAsset : public Object_32759
{
public:
	TMap<struct FString, int>                          StringIntMap_69;                                          // 0x0028(0x0050) (Edit, BlueprintVisible, BlueprintReadOnly, DisableEditOnInstance)
	TMap<struct FString, int>                          ShrinkStringIntMap_69;                                    // 0x0078(0x0050) (Edit, BlueprintVisible, BlueprintReadOnly, DisableEditOnInstance)
	TMap<struct FString, int>                          GrowStringIntMap_69;                                      // 0x00C8(0x0050) (Edit, BlueprintVisible, BlueprintReadOnly, DisableEditOnInstance)
	TMap<int, struct FDataAssetDirectoryTestSimpleStruct> IntStructMap_69;                                          // 0x0118(0x0050) (Edit, BlueprintVisible, BlueprintReadOnly, DisableEditOnInstance)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class DataAssetDirectory.DataAssetDirectoryTestMapAsset"));
		
		return ptr;
	}

};


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

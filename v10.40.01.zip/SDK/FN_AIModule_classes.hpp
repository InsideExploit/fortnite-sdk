#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Classes
//---------------------------------------------------------------------------

// Class AIModule.EnvQueryNode
// 0x0008 (0x0030 - 0x0028)
class EnvQueryNode : public Object_32759
{
public:
	int                                                VerNum_69;                                                // 0x0028(0x0004) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x002C(0x0004) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.EnvQueryNode"));
		
		return ptr;
	}

};


// Class AIModule.EnvQueryTest
// 0x01C8 (0x01F8 - 0x0030)
class EnvQueryTest : public EnvQueryNode
{
public:
	int                                                TestOrder_69;                                             // 0x0030(0x0004) (ZeroConstructor, IsPlainOldData)
	TEnumAsByte<EEnvTestPurpose>                       TestPurpose_69;                                           // 0x0034(0x0001) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0035(0x0003) MISSED OFFSET
	struct FString                                     TestComment_69;                                           // 0x0038(0x0010) (Edit, ZeroConstructor, DisableEditOnInstance)
	TEnumAsByte<EEnvTestFilterOperator>                MultipleContextFilterOp_69;                               // 0x0048(0x0001) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	TEnumAsByte<EEnvTestScoreOperator>                 MultipleContextScoreOp_69;                                // 0x0049(0x0001) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	TEnumAsByte<EEnvTestFilterType>                    FilterType_69;                                            // 0x004A(0x0001) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData01[0x5];                                       // 0x004B(0x0005) MISSED OFFSET
	struct FAIDataProviderBoolValue                    BoolValue_69;                                             // 0x0050(0x0038) (Edit, DisableEditOnInstance)
	struct FAIDataProviderFloatValue                   FloatValueMin_69;                                         // 0x0088(0x0038) (Edit, DisableEditOnInstance)
	struct FAIDataProviderFloatValue                   FloatValueMax_69;                                         // 0x00C0(0x0038) (Edit, DisableEditOnInstance)
	unsigned char                                      UnknownData02[0x1];                                       // 0x00F8(0x0001) MISSED OFFSET
	TEnumAsByte<EEnvTestScoreEquation>                 ScoringEquation_69;                                       // 0x00F9(0x0001) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	TEnumAsByte<EEnvQueryTestClamping>                 ClampMinType_69;                                          // 0x00FA(0x0001) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	TEnumAsByte<EEnvQueryTestClamping>                 ClampMaxType_69;                                          // 0x00FB(0x0001) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	EEQSNormalizationType                              NormalizationType_69;                                     // 0x00FC(0x0001) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData03[0x3];                                       // 0x00FD(0x0003) MISSED OFFSET
	struct FAIDataProviderFloatValue                   ScoreClampMin_69;                                         // 0x0100(0x0038) (Edit, DisableEditOnInstance)
	struct FAIDataProviderFloatValue                   ScoreClampMax_69;                                         // 0x0138(0x0038) (Edit, DisableEditOnInstance)
	struct FAIDataProviderFloatValue                   ScoringFactor_69;                                         // 0x0170(0x0038) (Edit, DisableEditOnInstance)
	struct FAIDataProviderFloatValue                   ReferenceValue_69;                                        // 0x01A8(0x0038) (Edit, DisableEditOnInstance)
	bool                                               bDefineReferenceValue_69;                                 // 0x01E0(0x0001) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData04[0xF];                                       // 0x01E1(0x000F) MISSED OFFSET
	unsigned char                                      bWorkOnFloatValues_69 : 1;                                // 0x01F0(0x0001)
	unsigned char                                      UnknownData05[0x7];                                       // 0x01F1(0x0007) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.EnvQueryTest"));
		
		return ptr;
	}

};


// Class AIModule.BTNode
// 0x0030 (0x0058 - 0x0028)
class BTNode : public Object_32759
{
public:
	unsigned char                                      UnknownData00[0x8];                                       // 0x0028(0x0008) MISSED OFFSET
	struct FString                                     NodeName_69;                                              // 0x0030(0x0010) (Edit, ZeroConstructor)
	class BehaviorTree*                                TreeAsset_69;                                             // 0x0040(0x0008) (ZeroConstructor)
	class BTCompositeNode*                             ParentNode_69;                                            // 0x0048(0x0008) (ZeroConstructor)
	unsigned char                                      UnknownData01[0x8];                                       // 0x0050(0x0008) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.BTNode"));
		
		return ptr;
	}

};


// Class AIModule.BTTaskNode
// 0x0018 (0x0070 - 0x0058)
class BTTaskNode : public BTNode
{
public:
	TArray<class BTService*>                           Services_69;                                              // 0x0058(0x0010) (ZeroConstructor)
	unsigned char                                      bIgnoreRestartSelf_69 : 1;                                // 0x0068(0x0001) (Edit)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0069(0x0007) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.BTTaskNode"));
		
		return ptr;
	}

};


// Class AIModule.BTTask_BlackboardBase
// 0x0028 (0x0098 - 0x0070)
class BTTask_BlackboardBase : public BTTaskNode
{
public:
	struct FBlackboardKeySelector                      BlackboardKey_69;                                         // 0x0070(0x0028) (Edit)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.BTTask_BlackboardBase"));
		
		return ptr;
	}

};


// Class AIModule.BTTask_MoveTo
// 0x0018 (0x00B0 - 0x0098)
class BTTask_MoveTo : public BTTask_BlackboardBase
{
public:
	float                                              AcceptableRadius_69;                                      // 0x0098(0x0004) (Edit, ZeroConstructor, Config, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x009C(0x0004) MISSED OFFSET
	class NavigationQueryFilter*                       FilterClass_69;                                           // 0x00A0(0x0008) (Edit, ZeroConstructor)
	float                                              ObservedBlackboardValueTolerance_69;                      // 0x00A8(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      bObserveBlackboardValue_69 : 1;                           // 0x00AC(0x0001) (Edit)
	unsigned char                                      bAllowStrafe_69 : 1;                                      // 0x00AC(0x0001) (Edit)
	unsigned char                                      bAllowPartialPath_69 : 1;                                 // 0x00AC(0x0001) (Edit)
	unsigned char                                      bTrackMovingGoal_69 : 1;                                  // 0x00AC(0x0001) (Edit)
	unsigned char                                      bProjectGoalLocation_69 : 1;                              // 0x00AC(0x0001) (Edit)
	unsigned char                                      bReachTestIncludesAgentRadius_69 : 1;                     // 0x00AC(0x0001) (Edit)
	unsigned char                                      bReachTestIncludesGoalRadius_69 : 1;                      // 0x00AC(0x0001) (Edit)
	unsigned char                                      bStopOnOverlap_69 : 1;                                    // 0x00AC(0x0001) (Edit, DisableEditOnTemplate, EditConst)
	unsigned char                                      bStopOnOverlapNeedsUpdate_69 : 1;                         // 0x00AD(0x0001)
	unsigned char                                      UnknownData01[0x2];                                       // 0x00AE(0x0002) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.BTTask_MoveTo"));
		
		return ptr;
	}

};


// Class AIModule.AIController
// 0x0090 (0x03B0 - 0x0320)
class AIController : public Controller
{
public:
	unsigned char                                      UnknownData00[0x38];                                      // 0x0320(0x0038) MISSED OFFSET
	unsigned char                                      bStartAILogicOnPossess_69 : 1;                            // 0x0358(0x0001) (Edit, BlueprintVisible)
	unsigned char                                      bStopAILogicOnUnposses_69 : 1;                            // 0x0358(0x0001) (Edit, BlueprintVisible)
	unsigned char                                      bLOSflag_69 : 1;                                          // 0x0358(0x0001)
	unsigned char                                      bSkipExtraLOSChecks_69 : 1;                               // 0x0358(0x0001) (Edit, BlueprintVisible)
	unsigned char                                      bAllowStrafe_69 : 1;                                      // 0x0358(0x0001) (Edit, BlueprintVisible)
	unsigned char                                      bWantsPlayerState_69 : 1;                                 // 0x0358(0x0001) (Edit, BlueprintVisible)
	unsigned char                                      bSetControlRotationFromPawnOrientation_69 : 1;            // 0x0358(0x0001) (Edit, BlueprintVisible)
	unsigned char                                      UnknownData01[0x7];                                       // 0x0359(0x0007) MISSED OFFSET
	class PathFollowingComponent*                      PathFollowingComponent_69;                                // 0x0360(0x0008) (Edit, ExportObject, ZeroConstructor, DisableEditOnInstance, EditConst, InstancedReference)
	class BrainComponent*                              BrainComponent_69;                                        // 0x0368(0x0008) (BlueprintVisible, ExportObject, ZeroConstructor, InstancedReference)
	class AIPerceptionComponent*                       PerceptionComponent_69;                                   // 0x0370(0x0008) (Edit, ExportObject, ZeroConstructor, DisableEditOnInstance, EditConst, InstancedReference)
	class PawnActionsComponent*                        ActionsComp_69;                                           // 0x0378(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)
	class BlackboardComponent*                         Blackboard_69;                                            // 0x0380(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)
	class GameplayTasksComponent*                      CachedGameplayTasksComponent_69;                          // 0x0388(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	class NavigationQueryFilter*                       DefaultNavigationFilterClass_69;                          // 0x0390(0x0008) (Edit, BlueprintVisible, ZeroConstructor)
	unsigned char                                      UnknownData02[0x10];                                      // 0x0398(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty AIModule.AIController.ReceiveMoveCompleted_69
	unsigned char                                      UnknownData03[0x8];                                       // 0x03A8(0x0008) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.AIController"));
		
		return ptr;
	}


	bool UseBlackboard(class BlackboardData* BlackboardAsset_69, class BlackboardComponent** BlackboardComponent_69);
	void UnclaimTaskResource(class GameplayTaskResource* ResourceClass_69);
	void SetPathFollowingComponent(class PathFollowingComponent* NewPFComponent_69);
	void SetMoveBlockDetection(bool bEnable_69);
	bool RunBehaviorTree(class BehaviorTree* BTAsset_69);
	void OnUsingBlackBoard(class BlackboardComponent* BlackboardComp_69, class BlackboardData* BlackboardAsset_69);
	void OnGameplayTaskResourcesClaimed(const struct FGameplayResourceSet& NewlyClaimed_69, const struct FGameplayResourceSet& FreshlyReleased_69);
	TEnumAsByte<EPathFollowingRequestResult> MoveToLocation(const struct FVector& Dest_69, float AcceptanceRadius_69, bool bStopOnOverlap_69, bool bUsePathfinding_69, bool bProjectDestinationToNavigation_69, bool bCanStrafe_69, class NavigationQueryFilter* FilterClass_69, bool bAllowPartialPath_69);
	TEnumAsByte<EPathFollowingRequestResult> MoveToActor(class Actor_32759* Goal_69, float AcceptanceRadius_69, bool bStopOnOverlap_69, bool bUsePathfinding_69, bool bCanStrafe_69, class NavigationQueryFilter* FilterClass_69, bool bAllowPartialPath_69);
	void K2_SetFocus(class Actor_32759* NewFocus_69);
	void K2_SetFocalPoint(const struct FVector& FP_69);
	void K2_ClearFocus();
	bool HasPartialPath();
	class PathFollowingComponent* GetPathFollowingComponent();
	TEnumAsByte<EPathFollowingStatus> GetMoveStatus();
	struct FVector GetImmediateMoveDestination();
	class Actor_32759* GetFocusActor();
	struct FVector GetFocalPointOnActor(class Actor_32759* Actor_69);
	struct FVector GetFocalPoint();
	class AIPerceptionComponent* GetAIPerceptionComponent();
	void ClaimTaskResource(class GameplayTaskResource* ResourceClass_69);
};


// Class AIModule.AITask
// 0x0008 (0x0068 - 0x0060)
class AITask : public GameplayTask
{
public:
	class AIController*                                OwnerController_69;                                       // 0x0060(0x0008) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.AITask"));
		
		return ptr;
	}

};


// Class AIModule.AITask_MoveTo
// 0x00A8 (0x0110 - 0x0068)
class AITask_MoveTo : public AITask
{
public:
	unsigned char                                      UnknownData00[0x10];                                      // 0x0068(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty AIModule.AITask_MoveTo.OnRequestFailed_69
	unsigned char                                      UnknownData01[0x10];                                      // 0x0078(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty AIModule.AITask_MoveTo.OnMoveFinished_69
	struct FAIMoveRequest                              MoveRequest_69;                                           // 0x0088(0x0048)
	unsigned char                                      UnknownData02[0x40];                                      // 0x00D0(0x0040) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.AITask_MoveTo"));
		
		return ptr;
	}


	class AITask_MoveTo* STATIC_AIMoveTo(class AIController* Controller_69, const struct FVector& GoalLocation_69, class Actor_32759* GoalActor_69, float AcceptanceRadius_69, TEnumAsByte<EAIOptionFlag> StopOnOverlap_69, TEnumAsByte<EAIOptionFlag> AcceptPartialPath_69, bool bUsePathfinding_69, bool bLockAILogic_69, bool bUseContinuousGoalTracking_69, TEnumAsByte<EAIOptionFlag> ProjectGoalOnNavigation_69);
};


// Class AIModule.EnvQueryContext
// 0x0000 (0x0028 - 0x0028)
class EnvQueryContext : public Object_32759
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.EnvQueryContext"));
		
		return ptr;
	}

};


// Class AIModule.BlackboardKeyType
// 0x0008 (0x0030 - 0x0028)
class BlackboardKeyType : public Object_32759
{
public:
	unsigned char                                      UnknownData00[0x8];                                       // 0x0028(0x0008) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.BlackboardKeyType"));
		
		return ptr;
	}

};


// Class AIModule.BTAuxiliaryNode
// 0x0008 (0x0060 - 0x0058)
class BTAuxiliaryNode : public BTNode
{
public:
	unsigned char                                      UnknownData00[0x8];                                       // 0x0058(0x0008) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.BTAuxiliaryNode"));
		
		return ptr;
	}

};


// Class AIModule.BTDecorator
// 0x0008 (0x0068 - 0x0060)
class BTDecorator : public BTAuxiliaryNode
{
public:
	unsigned char                                      UnknownData00 : 7;                                        // 0x0060(0x0001)
	unsigned char                                      bInverseCondition_69 : 1;                                 // 0x0060(0x0001) (Edit)
	unsigned char                                      UnknownData01[0x3];                                       // 0x0061(0x0003) MISSED OFFSET
	TEnumAsByte<EBTFlowAbortMode>                      FlowAbortMode_69;                                         // 0x0064(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData02[0x3];                                       // 0x0065(0x0003) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.BTDecorator"));
		
		return ptr;
	}

};


// Class AIModule.GenericTeamAgentInterface
// 0x0000 (0x0028 - 0x0028)
class GenericTeamAgentInterface : public Interface
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.GenericTeamAgentInterface"));
		
		return ptr;
	}

};


// Class AIModule.AIAsyncTaskBlueprintProxy
// 0x0040 (0x0068 - 0x0028)
class AIAsyncTaskBlueprintProxy : public Object_32759
{
public:
	unsigned char                                      UnknownData00[0x10];                                      // 0x0028(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty AIModule.AIAsyncTaskBlueprintProxy.OnSuccess_69
	unsigned char                                      UnknownData01[0x10];                                      // 0x0038(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty AIModule.AIAsyncTaskBlueprintProxy.OnFail_69
	unsigned char                                      UnknownData02[0x20];                                      // 0x0048(0x0020) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.AIAsyncTaskBlueprintProxy"));
		
		return ptr;
	}


	void OnMoveCompleted(const struct FAIRequestID& RequestId_69, TEnumAsByte<EPathFollowingResult> MovementResult_69);
};


// Class AIModule.AIResourceInterface
// 0x0000 (0x0028 - 0x0028)
class AIResourceInterface : public Interface
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.AIResourceInterface"));
		
		return ptr;
	}

};


// Class AIModule.AISenseBlueprintListener
// 0x0000 (0x0108 - 0x0108)
class AISenseBlueprintListener : public UserDefinedStruct
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.AISenseBlueprintListener"));
		
		return ptr;
	}

};


// Class AIModule.AISenseConfig
// 0x0020 (0x0048 - 0x0028)
class AISenseConfig : public Object_32759
{
public:
	struct FCoreUObject_FColor                         DebugColor_69;                                            // 0x0028(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              MaxAge_69;                                                // 0x002C(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      bStartsEnabled_69 : 1;                                    // 0x0030(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, DisableEditOnInstance)
	unsigned char                                      UnknownData00[0x17];                                      // 0x0031(0x0017) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.AISenseConfig"));
		
		return ptr;
	}

};


// Class AIModule.AISenseConfig_Blueprint
// 0x0008 (0x0050 - 0x0048)
class AISenseConfig_Blueprint : public AISenseConfig
{
public:
	class AISense_Blueprint*                           Implementation_69;                                        // 0x0048(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, Config, DisableEditOnInstance, NoClear)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.AISenseConfig_Blueprint"));
		
		return ptr;
	}

};


// Class AIModule.AISenseConfig_Hearing
// 0x0018 (0x0060 - 0x0048)
class AISenseConfig_Hearing : public AISenseConfig
{
public:
	class AISense_Hearing*                             Implementation_69;                                        // 0x0048(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, Config, DisableEditOnInstance, NoClear)
	float                                              HearingRange_69;                                          // 0x0050(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	float                                              LoSHearingRange_69;                                       // 0x0054(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      bUseLoSHearing_69 : 1;                                    // 0x0058(0x0001) (Edit, DisableEditOnInstance)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0059(0x0003) MISSED OFFSET
	struct FAISenseAffiliationFilter                   DetectionByAffiliation_69;                                // 0x005C(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, Config, DisableEditOnInstance)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.AISenseConfig_Hearing"));
		
		return ptr;
	}

};


// Class AIModule.AISenseConfig_Prediction
// 0x0000 (0x0048 - 0x0048)
class AISenseConfig_Prediction : public AISenseConfig
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.AISenseConfig_Prediction"));
		
		return ptr;
	}

};


// Class AIModule.AISenseConfig_Sight
// 0x0028 (0x0070 - 0x0048)
class AISenseConfig_Sight : public AISenseConfig
{
public:
	class AISense_Sight*                               Implementation_69;                                        // 0x0048(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, Config, DisableEditOnInstance, NoClear)
	float                                              SightRadius_69;                                           // 0x0050(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, Config, DisableEditOnInstance, IsPlainOldData)
	float                                              LoseSightRadius_69;                                       // 0x0054(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, Config, DisableEditOnInstance, IsPlainOldData)
	float                                              PeripheralVisionAngleDegrees_69;                          // 0x0058(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, Config, DisableEditOnInstance, IsPlainOldData)
	struct FAISenseAffiliationFilter                   DetectionByAffiliation_69;                                // 0x005C(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, Config, DisableEditOnInstance)
	float                                              AutoSuccessRangeFromLastSeenLocation_69;                  // 0x0060(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, Config, DisableEditOnInstance, IsPlainOldData)
	float                                              PointOfViewBackwardOffset_69;                             // 0x0064(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, Config, DisableEditOnInstance, IsPlainOldData)
	float                                              NearClippingRadius_69;                                    // 0x0068(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, Config, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x006C(0x0004) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.AISenseConfig_Sight"));
		
		return ptr;
	}

};


// Class AIModule.AISenseConfig_Team
// 0x0000 (0x0048 - 0x0048)
class AISenseConfig_Team : public AISenseConfig
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.AISenseConfig_Team"));
		
		return ptr;
	}

};


// Class AIModule.AISenseConfig_Touch
// 0x0000 (0x0048 - 0x0048)
class AISenseConfig_Touch : public AISenseConfig
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.AISenseConfig_Touch"));
		
		return ptr;
	}

};


// Class AIModule.AISenseEvent
// 0x0000 (0x0028 - 0x0028)
class AISenseEvent : public Object_32759
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.AISenseEvent"));
		
		return ptr;
	}

};


// Class AIModule.AISenseEvent_Damage
// 0x0050 (0x0078 - 0x0028)
class AISenseEvent_Damage : public AISenseEvent
{
public:
	struct FAIDamageEvent                              Event_69;                                                 // 0x0028(0x0050) (Edit, BlueprintVisible)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.AISenseEvent_Damage"));
		
		return ptr;
	}

};


// Class AIModule.AISenseEvent_Hearing
// 0x0038 (0x0060 - 0x0028)
class AISenseEvent_Hearing : public AISenseEvent
{
public:
	struct FAINoiseEvent                               Event_69;                                                 // 0x0028(0x0038) (Edit, BlueprintVisible)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.AISenseEvent_Hearing"));
		
		return ptr;
	}

};


// Class AIModule.CrowdAgentInterface
// 0x0000 (0x0028 - 0x0028)
class CrowdAgentInterface : public Interface
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.CrowdAgentInterface"));
		
		return ptr;
	}

};


// Class AIModule.EnvQueryTypes
// 0x0000 (0x0028 - 0x0028)
class EnvQueryTypes : public Object_32759
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.EnvQueryTypes"));
		
		return ptr;
	}

};


// Class AIModule.EQSQueryResultSourceInterface
// 0x0000 (0x0028 - 0x0028)
class EQSQueryResultSourceInterface : public Interface
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.EQSQueryResultSourceInterface"));
		
		return ptr;
	}

};


// Class AIModule.PawnAction
// 0x0068 (0x0090 - 0x0028)
class PawnAction : public Object_32759
{
public:
	class PawnAction*                                  ChildAction_69;                                           // 0x0028(0x0008) (ZeroConstructor, Transient)
	class PawnAction*                                  ParentAction_69;                                          // 0x0030(0x0008) (ZeroConstructor, Transient)
	class PawnActionsComponent*                        OwnerComponent_69;                                        // 0x0038(0x0008) (ExportObject, ZeroConstructor, Transient, InstancedReference)
	class Object_32759*                                Instigator_69;                                            // 0x0040(0x0008) (ZeroConstructor, Transient)
	class BrainComponent*                              BrainComp_69;                                             // 0x0048(0x0008) (ExportObject, ZeroConstructor, Transient, InstancedReference)
	unsigned char                                      UnknownData00[0x30];                                      // 0x0050(0x0030) MISSED OFFSET
	unsigned char                                      bAllowNewSameClassInstance_69 : 1;                        // 0x0080(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, DisableEditOnInstance)
	unsigned char                                      bReplaceActiveSameClassInstance_69 : 1;                   // 0x0080(0x0001) (Edit, BlueprintVisible, DisableEditOnInstance)
	unsigned char                                      bShouldPauseMovement_69 : 1;                              // 0x0080(0x0001) (Edit, BlueprintVisible, DisableEditOnInstance)
	unsigned char                                      bAlwaysNotifyOnFinished_69 : 1;                           // 0x0080(0x0001) (Edit, BlueprintVisible, DisableEditOnInstance)
	unsigned char                                      UnknownData01[0xF];                                       // 0x0081(0x000F) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.PawnAction"));
		
		return ptr;
	}


	TEnumAsByte<EAIRequestPriority> GetActionPriority();
	void Finish(TEnumAsByte<EPawnActionResult> WithResult_69);
	class PawnAction* STATIC_CreateActionInstance(class Object_32759* WorldContextObject_69, class PawnAction* ActionClass_69);
};


// Class AIModule.PawnActionsComponent
// 0x0038 (0x00D8 - 0x00A0)
class PawnActionsComponent : public ActorComponent
{
public:
	class Pawn*                                        ControlledPawn_69;                                        // 0x00A0(0x0008) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
	TArray<struct FPawnActionStack>                    ActionStacks_69;                                          // 0x00A8(0x0010) (ZeroConstructor)
	TArray<struct FPawnActionEvent>                    ActionEvents_69;                                          // 0x00B8(0x0010) (ZeroConstructor)
	class PawnAction*                                  CurrentAction_69;                                         // 0x00C8(0x0008) (ZeroConstructor, Transient)
	unsigned char                                      UnknownData00[0x8];                                       // 0x00D0(0x0008) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.PawnActionsComponent"));
		
		return ptr;
	}


	bool K2_PushAction(class PawnAction* NewAction_69, TEnumAsByte<EAIRequestPriority> Priority_69, class Object_32759* Instigator_69);
	bool STATIC_K2_PerformAction(class Pawn* Pawn_69, class PawnAction* Action_69, TEnumAsByte<EAIRequestPriority> Priority_69);
	TEnumAsByte<EPawnActionAbortState> K2_ForceAbortAction(class PawnAction* ActionToAbort_69);
	TEnumAsByte<EPawnActionAbortState> K2_AbortAction(class PawnAction* ActionToAbort_69);
};


// Class AIModule.PawnAction_BlueprintBase
// 0x0000 (0x0090 - 0x0090)
class PawnAction_BlueprintBase : public PawnAction
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.PawnAction_BlueprintBase"));
		
		return ptr;
	}


	void ActionTick(class Pawn* ControlledPawn_69, float DeltaSeconds_69);
	void ActionStart(class Pawn* ControlledPawn_69);
	void ActionResume(class Pawn* ControlledPawn_69);
	void ActionPause(class Pawn* ControlledPawn_69);
	void ActionFinished(class Pawn* ControlledPawn_69, TEnumAsByte<EPawnActionResult> WithResult_69);
};


// Class AIModule.PawnAction_Move
// 0x0060 (0x00F0 - 0x0090)
class PawnAction_Move : public PawnAction
{
public:
	class Actor_32759*                                 GoalActor_69;                                             // 0x0090(0x0008) (Edit, BlueprintVisible, ZeroConstructor)
	struct FVector                                     GoalLocation_69;                                          // 0x0098(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              AcceptableRadius_69;                                      // 0x00B0(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x00B4(0x0004) MISSED OFFSET
	class NavigationQueryFilter*                       FilterClass_69;                                           // 0x00B8(0x0008) (Edit, BlueprintVisible, ZeroConstructor)
	unsigned char                                      bAllowStrafe_69 : 1;                                      // 0x00C0(0x0001) (Edit, BlueprintVisible)
	unsigned char                                      bFinishOnOverlap_69 : 1;                                  // 0x00C0(0x0001)
	unsigned char                                      bUsePathfinding_69 : 1;                                   // 0x00C0(0x0001)
	unsigned char                                      bAllowPartialPath_69 : 1;                                 // 0x00C0(0x0001)
	unsigned char                                      bProjectGoalToNavigation_69 : 1;                          // 0x00C0(0x0001)
	unsigned char                                      bUpdatePathToGoal_69 : 1;                                 // 0x00C0(0x0001)
	unsigned char                                      bAbortChildActionOnPathChange_69 : 1;                     // 0x00C0(0x0001)
	unsigned char                                      UnknownData01[0x2F];                                      // 0x00C1(0x002F) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.PawnAction_Move"));
		
		return ptr;
	}

};


// Class AIModule.PawnAction_Repeat
// 0x0020 (0x00B0 - 0x0090)
class PawnAction_Repeat : public PawnAction
{
public:
	class PawnAction*                                  ActionToRepeat_69;                                        // 0x0090(0x0008) (ZeroConstructor)
	class PawnAction*                                  RecentActionCopy_69;                                      // 0x0098(0x0008) (ZeroConstructor, Transient)
	TEnumAsByte<EPawnActionFailHandling>               ChildFailureHandlingMode_69;                              // 0x00A0(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0xF];                                       // 0x00A1(0x000F) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.PawnAction_Repeat"));
		
		return ptr;
	}

};


// Class AIModule.PawnAction_Sequence
// 0x0028 (0x00B8 - 0x0090)
class PawnAction_Sequence : public PawnAction
{
public:
	TArray<class PawnAction*>                          ActionSequence_69;                                        // 0x0090(0x0010) (ZeroConstructor)
	TEnumAsByte<EPawnActionFailHandling>               ChildFailureHandlingMode_69;                              // 0x00A0(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x00A1(0x0007) MISSED OFFSET
	class PawnAction*                                  RecentActionCopy_69;                                      // 0x00A8(0x0008) (ZeroConstructor, Transient)
	unsigned char                                      UnknownData01[0x8];                                       // 0x00B0(0x0008) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.PawnAction_Sequence"));
		
		return ptr;
	}

};


// Class AIModule.PawnAction_Wait
// 0x0010 (0x00A0 - 0x0090)
class PawnAction_Wait : public PawnAction
{
public:
	float                                              TimeToWait_69;                                            // 0x0090(0x0004) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0xC];                                       // 0x0094(0x000C) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.PawnAction_Wait"));
		
		return ptr;
	}

};


// Class AIModule.AIResource_Movement
// 0x0000 (0x0038 - 0x0038)
class AIResource_Movement : public GameplayTaskResource
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.AIResource_Movement"));
		
		return ptr;
	}

};


// Class AIModule.AIResource_Logic
// 0x0000 (0x0038 - 0x0038)
class AIResource_Logic : public GameplayTaskResource
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.AIResource_Logic"));
		
		return ptr;
	}

};


// Class AIModule.AISubsystem
// 0x0010 (0x0038 - 0x0028)
class AISubsystem : public Object_32759
{
public:
	unsigned char                                      UnknownData00[0x8];                                       // 0x0028(0x0008) MISSED OFFSET
	class AISystem*                                    AISystem_69;                                              // 0x0030(0x0008) (ZeroConstructor)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.AISubsystem"));
		
		return ptr;
	}

};


// Class AIModule.AISystem
// 0x00F0 (0x0148 - 0x0058)
class AISystem : public AISystemBase
{
public:
	struct FSoftClassPath                              PerceptionSystemClassName_69;                             // 0x0058(0x0018) (Edit, ZeroConstructor, Config, GlobalConfig)
	struct FSoftClassPath                              HotSpotManagerClassName_69;                               // 0x0070(0x0018) (Edit, ZeroConstructor, Config, GlobalConfig)
	struct FSoftClassPath                              EnvQueryManagerClassName_69;                              // 0x0088(0x0018) (Edit, ZeroConstructor, Config, GlobalConfig)
	float                                              AcceptanceRadius_69;                                      // 0x00A0(0x0004) (Edit, ZeroConstructor, Config, DisableEditOnInstance, GlobalConfig, IsPlainOldData)
	float                                              PathfollowingRegularPathPointAcceptanceRadius_69;         // 0x00A4(0x0004) (Edit, ZeroConstructor, Config, DisableEditOnInstance, GlobalConfig, IsPlainOldData)
	float                                              PathfollowingNavLinkAcceptanceRadius_69;                  // 0x00A8(0x0004) (Edit, ZeroConstructor, Config, DisableEditOnInstance, GlobalConfig, IsPlainOldData)
	bool                                               bFinishMoveOnGoalOverlap_69;                              // 0x00AC(0x0001) (Edit, ZeroConstructor, Config, DisableEditOnInstance, GlobalConfig, IsPlainOldData)
	bool                                               bAcceptPartialPaths_69;                                   // 0x00AD(0x0001) (Edit, ZeroConstructor, Config, DisableEditOnInstance, GlobalConfig, IsPlainOldData)
	bool                                               bAllowStrafing_69;                                        // 0x00AE(0x0001) (Edit, ZeroConstructor, Config, DisableEditOnInstance, GlobalConfig, IsPlainOldData)
	bool                                               bEnableBTAITasks_69;                                      // 0x00AF(0x0001) (Edit, ZeroConstructor, Config, DisableEditOnInstance, GlobalConfig, IsPlainOldData)
	bool                                               bAllowControllersAsEQSQuerier_69;                         // 0x00B0(0x0001) (Edit, ZeroConstructor, Config, DisableEditOnInstance, GlobalConfig, IsPlainOldData)
	bool                                               bEnableDebuggerPlugin_69;                                 // 0x00B1(0x0001) (Edit, ZeroConstructor, Config, DisableEditOnInstance, GlobalConfig, IsPlainOldData)
	bool                                               bForgetStaleActors_69;                                    // 0x00B2(0x0001) (Edit, ZeroConstructor, Config, DisableEditOnInstance, GlobalConfig, IsPlainOldData)
	bool                                               bAddBlackboardSelfKey_69;                                 // 0x00B3(0x0001) (Edit, ZeroConstructor, Config, DisableEditOnInstance, GlobalConfig, IsPlainOldData)
	bool                                               bClearBBEntryOnBTEQSFail_69;                              // 0x00B4(0x0001) (Edit, ZeroConstructor, Config, DisableEditOnInstance, GlobalConfig, IsPlainOldData)
	TEnumAsByte<ECollisionChannel>                     DefaultSightCollisionChannel_69;                          // 0x00B5(0x0001) (Edit, ZeroConstructor, Config, DisableEditOnInstance, GlobalConfig, IsPlainOldData)
	unsigned char                                      UnknownData00[0x2];                                       // 0x00B6(0x0002) MISSED OFFSET
	class BehaviorTreeManager*                         BehaviorTreeManager_69;                                   // 0x00B8(0x0008) (ZeroConstructor, Transient)
	class EnvQueryManager*                             EnvironmentQueryManager_69;                               // 0x00C0(0x0008) (ZeroConstructor, Transient)
	class AIPerceptionSystem*                          PerceptionSystem_69;                                      // 0x00C8(0x0008) (ZeroConstructor, Transient)
	TArray<class AIAsyncTaskBlueprintProxy*>           AllProxyObjects_69;                                       // 0x00D0(0x0010) (ZeroConstructor, Transient)
	class AIHotSpotManager*                            HotSpotManager_69;                                        // 0x00E0(0x0008) (ZeroConstructor, Transient)
	class NavLocalGridManager*                         NavLocalGrids_69;                                         // 0x00E8(0x0008) (ZeroConstructor, Transient)
	unsigned char                                      UnknownData01[0x58];                                      // 0x00F0(0x0058) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.AISystem"));
		
		return ptr;
	}


	void AILoggingVerbose();
	void AIIgnorePlayers();
};


// Class AIModule.BehaviorTree
// 0x0040 (0x0068 - 0x0028)
class BehaviorTree : public Object_32759
{
public:
	unsigned char                                      UnknownData00[0x8];                                       // 0x0028(0x0008) MISSED OFFSET
	class BTCompositeNode*                             RootNode_69;                                              // 0x0030(0x0008) (ZeroConstructor)
	class BlackboardData*                              BlackboardAsset_69;                                       // 0x0038(0x0008) (ZeroConstructor)
	TArray<class BTDecorator*>                         RootDecorators_69;                                        // 0x0040(0x0010) (ZeroConstructor)
	TArray<struct FBTDecoratorLogic>                   RootDecoratorOps_69;                                      // 0x0050(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData01[0x8];                                       // 0x0060(0x0008) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.BehaviorTree"));
		
		return ptr;
	}

};


// Class AIModule.BrainComponent
// 0x0058 (0x00F8 - 0x00A0)
class BrainComponent : public ActorComponent
{
public:
	unsigned char                                      UnknownData00[0x8];                                       // 0x00A0(0x0008) MISSED OFFSET
	class BlackboardComponent*                         BlackboardComp_69;                                        // 0x00A8(0x0008) (ExportObject, ZeroConstructor, Transient, InstancedReference)
	class AIController*                                AIOwner_69;                                               // 0x00B0(0x0008) (ZeroConstructor, Transient)
	unsigned char                                      UnknownData01[0x40];                                      // 0x00B8(0x0040) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.BrainComponent"));
		
		return ptr;
	}


	void StopLogic(const struct FString& Reason_69);
	void StartLogic();
	void RestartLogic();
	bool IsRunning();
	bool IsPaused();
};


// Class AIModule.BehaviorTreeComponent
// 0x0198 (0x0290 - 0x00F8)
class BehaviorTreeComponent : public BrainComponent
{
public:
	unsigned char                                      UnknownData00[0x20];                                      // 0x00F8(0x0020) MISSED OFFSET
	TArray<class BTNode*>                              NodeInstances_69;                                         // 0x0118(0x0010) (ZeroConstructor, Transient)
	unsigned char                                      UnknownData01[0x148];                                     // 0x0128(0x0148) MISSED OFFSET
	class BehaviorTree*                                DefaultBehaviorTreeAsset_69;                              // 0x0270(0x0008) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance)
	unsigned char                                      UnknownData02[0x18];                                      // 0x0278(0x0018) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.BehaviorTreeComponent"));
		
		return ptr;
	}


	void SetDynamicSubtree(const struct FGameplayTag& InjectTag_69, class BehaviorTree* BehaviorAsset_69);
	float GetTagCooldownEndTime(const struct FGameplayTag& CooldownTag_69);
	void AddCooldownTagDuration(const struct FGameplayTag& CooldownTag_69, float CooldownDuration_69, bool bAddToExistingDuration_69);
};


// Class AIModule.BehaviorTreeManager
// 0x0028 (0x0050 - 0x0028)
class BehaviorTreeManager : public Object_32759
{
public:
	int                                                MaxDebuggerSteps_69;                                      // 0x0028(0x0004) (ZeroConstructor, Config, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x002C(0x0004) MISSED OFFSET
	TArray<struct FBehaviorTreeTemplateInfo>           LoadedTemplates_69;                                       // 0x0030(0x0010) (ZeroConstructor)
	TArray<class BehaviorTreeComponent*>               ActiveComponents_69;                                      // 0x0040(0x0010) (ExportObject, ZeroConstructor)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.BehaviorTreeManager"));
		
		return ptr;
	}

};


// Class AIModule.BehaviorTreeTypes
// 0x0000 (0x0028 - 0x0028)
class BehaviorTreeTypes : public Object_32759
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.BehaviorTreeTypes"));
		
		return ptr;
	}

};


// Class AIModule.BlackboardAssetProvider
// 0x0000 (0x0028 - 0x0028)
class BlackboardAssetProvider : public Interface
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.BlackboardAssetProvider"));
		
		return ptr;
	}


	class BlackboardData* GetBlackboardAsset();
};


// Class AIModule.BlackboardComponent
// 0x0108 (0x01A8 - 0x00A0)
class BlackboardComponent : public ActorComponent
{
public:
	class BrainComponent*                              BrainComp_69;                                             // 0x00A0(0x0008) (ExportObject, ZeroConstructor, Transient, InstancedReference)
	class BlackboardData*                              DefaultBlackboardAsset_69;                                // 0x00A8(0x0008) (Edit, ZeroConstructor, DisableEditOnInstance)
	class BlackboardData*                              BlackboardAsset_69;                                       // 0x00B0(0x0008) (ZeroConstructor, Transient)
	unsigned char                                      UnknownData00[0x20];                                      // 0x00B8(0x0020) MISSED OFFSET
	TArray<class BlackboardKeyType*>                   KeyInstances_69;                                          // 0x00D8(0x0010) (ZeroConstructor, Transient)
	unsigned char                                      UnknownData01[0xC0];                                      // 0x00E8(0x00C0) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.BlackboardComponent"));
		
		return ptr;
	}


	void SetValueAsVector(const struct FName& KeyName_69, const struct FVector& VectorValue_69);
	void SetValueAsString(const struct FName& KeyName_69, const struct FString& StringValue_69);
	void SetValueAsRotator(const struct FName& KeyName_69, const struct FRotator& VectorValue_69);
	void SetValueAsObject(const struct FName& KeyName_69, class Object_32759* ObjectValue_69);
	void SetValueAsName(const struct FName& KeyName_69, const struct FName& NameValue_69);
	void SetValueAsInt(const struct FName& KeyName_69, int IntValue_69);
	void SetValueAsFloat(const struct FName& KeyName_69, float FloatValue_69);
	void SetValueAsEnum(const struct FName& KeyName_69, unsigned char EnumValue_69);
	void SetValueAsClass(const struct FName& KeyName_69, class Object_32759* ClassValue_69);
	void SetValueAsBool(const struct FName& KeyName_69, bool BoolValue_69);
	bool IsVectorValueSet(const struct FName& KeyName_69);
	struct FVector GetValueAsVector(const struct FName& KeyName_69);
	struct FString GetValueAsString(const struct FName& KeyName_69);
	struct FRotator GetValueAsRotator(const struct FName& KeyName_69);
	class Object_32759* GetValueAsObject(const struct FName& KeyName_69);
	struct FName GetValueAsName(const struct FName& KeyName_69);
	int GetValueAsInt(const struct FName& KeyName_69);
	float GetValueAsFloat(const struct FName& KeyName_69);
	unsigned char GetValueAsEnum(const struct FName& KeyName_69);
	class Object_32759* GetValueAsClass(const struct FName& KeyName_69);
	bool GetValueAsBool(const struct FName& KeyName_69);
	bool GetRotationFromEntry(const struct FName& KeyName_69, struct FRotator* ResultRotation_69);
	bool GetLocationFromEntry(const struct FName& KeyName_69, struct FVector* ResultLocation_69);
	void ClearValue(const struct FName& KeyName_69);
};


// Class AIModule.BlackboardData
// 0x0020 (0x0050 - 0x0030)
class BlackboardData : public DataAsset
{
public:
	class BlackboardData*                              Parent_69;                                                // 0x0030(0x0008) (Edit, ZeroConstructor)
	TArray<struct FBlackboardEntry>                    Keys_69;                                                  // 0x0038(0x0010) (Edit, ZeroConstructor)
	unsigned char                                      bHasSynchronizedKeys_69 : 1;                              // 0x0048(0x0001)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0049(0x0007) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.BlackboardData"));
		
		return ptr;
	}

};


// Class AIModule.BlackboardKeyType_Bool
// 0x0000 (0x0030 - 0x0030)
class BlackboardKeyType_Bool : public BlackboardKeyType
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.BlackboardKeyType_Bool"));
		
		return ptr;
	}

};


// Class AIModule.BlackboardKeyType_Class
// 0x0008 (0x0038 - 0x0030)
class BlackboardKeyType_Class : public BlackboardKeyType
{
public:
	unsigned char                                      UnknownData00[0x8];                                       // 0x0030(0x0008) UNKNOWN PROPERTY: ClassPtrProperty AIModule.BlackboardKeyType_Class.BASEClass_69

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.BlackboardKeyType_Class"));
		
		return ptr;
	}

};


// Class AIModule.BlackboardKeyType_Enum
// 0x0020 (0x0050 - 0x0030)
class BlackboardKeyType_Enum : public BlackboardKeyType
{
public:
	class Enum*                                        EnumType_69;                                              // 0x0030(0x0008) (Edit, ZeroConstructor, DisableEditOnInstance)
	struct FString                                     EnumName_69;                                              // 0x0038(0x0010) (Edit, ZeroConstructor, DisableEditOnInstance)
	unsigned char                                      bIsEnumNameValid_69 : 1;                                  // 0x0048(0x0001) (Edit, DisableEditOnInstance, EditConst)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0049(0x0007) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.BlackboardKeyType_Enum"));
		
		return ptr;
	}

};


// Class AIModule.BlackboardKeyType_Float
// 0x0000 (0x0030 - 0x0030)
class BlackboardKeyType_Float : public BlackboardKeyType
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.BlackboardKeyType_Float"));
		
		return ptr;
	}

};


// Class AIModule.BlackboardKeyType_Int
// 0x0000 (0x0030 - 0x0030)
class BlackboardKeyType_Int : public BlackboardKeyType
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.BlackboardKeyType_Int"));
		
		return ptr;
	}

};


// Class AIModule.BlackboardKeyType_Name
// 0x0000 (0x0030 - 0x0030)
class BlackboardKeyType_Name : public BlackboardKeyType
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.BlackboardKeyType_Name"));
		
		return ptr;
	}

};


// Class AIModule.BlackboardKeyType_NativeEnum
// 0x0018 (0x0048 - 0x0030)
class BlackboardKeyType_NativeEnum : public BlackboardKeyType
{
public:
	struct FString                                     EnumName_69;                                              // 0x0030(0x0010) (Edit, ZeroConstructor, DisableEditOnInstance)
	class Enum*                                        EnumType_69;                                              // 0x0040(0x0008) (ZeroConstructor)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.BlackboardKeyType_NativeEnum"));
		
		return ptr;
	}

};


// Class AIModule.BlackboardKeyType_Object
// 0x0008 (0x0038 - 0x0030)
class BlackboardKeyType_Object : public BlackboardKeyType
{
public:
	unsigned char                                      UnknownData00[0x8];                                       // 0x0030(0x0008) UNKNOWN PROPERTY: ClassPtrProperty AIModule.BlackboardKeyType_Object.BASEClass_69

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.BlackboardKeyType_Object"));
		
		return ptr;
	}

};


// Class AIModule.BlackboardKeyType_Rotator
// 0x0000 (0x0030 - 0x0030)
class BlackboardKeyType_Rotator : public BlackboardKeyType
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.BlackboardKeyType_Rotator"));
		
		return ptr;
	}

};


// Class AIModule.BlackboardKeyType_String
// 0x0010 (0x0040 - 0x0030)
class BlackboardKeyType_String : public BlackboardKeyType
{
public:
	struct FString                                     StringValue_69;                                           // 0x0030(0x0010) (ZeroConstructor)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.BlackboardKeyType_String"));
		
		return ptr;
	}

};


// Class AIModule.BlackboardKeyType_Vector
// 0x0000 (0x0030 - 0x0030)
class BlackboardKeyType_Vector : public BlackboardKeyType
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.BlackboardKeyType_Vector"));
		
		return ptr;
	}

};


// Class AIModule.BTCompositeNode
// 0x0038 (0x0090 - 0x0058)
class BTCompositeNode : public BTNode
{
public:
	TArray<struct FBTCompositeChild>                   Children_69;                                              // 0x0058(0x0010) (ZeroConstructor)
	TArray<class BTService*>                           Services_69;                                              // 0x0068(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData00[0x10];                                      // 0x0078(0x0010) MISSED OFFSET
	unsigned char                                      bApplyDecoratorScope_69 : 1;                              // 0x0088(0x0001) (Edit)
	unsigned char                                      UnknownData01[0x7];                                       // 0x0089(0x0007) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.BTCompositeNode"));
		
		return ptr;
	}

};


// Class AIModule.BTFunctionLibrary
// 0x0000 (0x0028 - 0x0028)
class BTFunctionLibrary : public BlueprintFunctionLibrary
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.BTFunctionLibrary"));
		
		return ptr;
	}


	void STATIC_StopUsingExternalEvent(class BTNode* NodeOwner_69);
	void STATIC_StartUsingExternalEvent(class BTNode* NodeOwner_69, class Actor_32759* OwningActor_69);
	void STATIC_SetBlackboardValueAsVector(class BTNode* NodeOwner_69, const struct FBlackboardKeySelector& Key_69, const struct FVector& Value_69);
	void STATIC_SetBlackboardValueAsString(class BTNode* NodeOwner_69, const struct FBlackboardKeySelector& Key_69, const struct FString& Value_69);
	void STATIC_SetBlackboardValueAsRotator(class BTNode* NodeOwner_69, const struct FBlackboardKeySelector& Key_69, const struct FRotator& Value_69);
	void STATIC_SetBlackboardValueAsObject(class BTNode* NodeOwner_69, const struct FBlackboardKeySelector& Key_69, class Object_32759* Value_69);
	void STATIC_SetBlackboardValueAsName(class BTNode* NodeOwner_69, const struct FBlackboardKeySelector& Key_69, const struct FName& Value_69);
	void STATIC_SetBlackboardValueAsInt(class BTNode* NodeOwner_69, const struct FBlackboardKeySelector& Key_69, int Value_69);
	void STATIC_SetBlackboardValueAsFloat(class BTNode* NodeOwner_69, const struct FBlackboardKeySelector& Key_69, float Value_69);
	void STATIC_SetBlackboardValueAsEnum(class BTNode* NodeOwner_69, const struct FBlackboardKeySelector& Key_69, unsigned char Value_69);
	void STATIC_SetBlackboardValueAsClass(class BTNode* NodeOwner_69, const struct FBlackboardKeySelector& Key_69, class Object_32759* Value_69);
	void STATIC_SetBlackboardValueAsBool(class BTNode* NodeOwner_69, const struct FBlackboardKeySelector& Key_69, bool Value_69);
	class BlackboardComponent* STATIC_GetOwnersBlackboard(class BTNode* NodeOwner_69);
	class BehaviorTreeComponent* STATIC_GetOwnerComponent(class BTNode* NodeOwner_69);
	struct FVector STATIC_GetBlackboardValueAsVector(class BTNode* NodeOwner_69, const struct FBlackboardKeySelector& Key_69);
	struct FString STATIC_GetBlackboardValueAsString(class BTNode* NodeOwner_69, const struct FBlackboardKeySelector& Key_69);
	struct FRotator STATIC_GetBlackboardValueAsRotator(class BTNode* NodeOwner_69, const struct FBlackboardKeySelector& Key_69);
	class Object_32759* STATIC_GetBlackboardValueAsObject(class BTNode* NodeOwner_69, const struct FBlackboardKeySelector& Key_69);
	struct FName STATIC_GetBlackboardValueAsName(class BTNode* NodeOwner_69, const struct FBlackboardKeySelector& Key_69);
	int STATIC_GetBlackboardValueAsInt(class BTNode* NodeOwner_69, const struct FBlackboardKeySelector& Key_69);
	float STATIC_GetBlackboardValueAsFloat(class BTNode* NodeOwner_69, const struct FBlackboardKeySelector& Key_69);
	unsigned char STATIC_GetBlackboardValueAsEnum(class BTNode* NodeOwner_69, const struct FBlackboardKeySelector& Key_69);
	class Object_32759* STATIC_GetBlackboardValueAsClass(class BTNode* NodeOwner_69, const struct FBlackboardKeySelector& Key_69);
	bool STATIC_GetBlackboardValueAsBool(class BTNode* NodeOwner_69, const struct FBlackboardKeySelector& Key_69);
	class Actor_32759* STATIC_GetBlackboardValueAsActor(class BTNode* NodeOwner_69, const struct FBlackboardKeySelector& Key_69);
	void STATIC_ClearBlackboardValueAsVector(class BTNode* NodeOwner_69, const struct FBlackboardKeySelector& Key_69);
	void STATIC_ClearBlackboardValue(class BTNode* NodeOwner_69, const struct FBlackboardKeySelector& Key_69);
};


// Class AIModule.BTService
// 0x0010 (0x0070 - 0x0060)
class BTService : public BTAuxiliaryNode
{
public:
	float                                              Interval_69;                                              // 0x0060(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	float                                              RandomDeviation_69;                                       // 0x0064(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      bCallTickOnSearchStart_69 : 1;                            // 0x0068(0x0001) (Edit)
	unsigned char                                      bRestartTimerOnEachActivation_69 : 1;                     // 0x0068(0x0001) (Edit)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0069(0x0007) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.BTService"));
		
		return ptr;
	}

};


// Class AIModule.BTComposite_Selector
// 0x0000 (0x0090 - 0x0090)
class BTComposite_Selector : public BTCompositeNode
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.BTComposite_Selector"));
		
		return ptr;
	}

};


// Class AIModule.BTComposite_Sequence
// 0x0000 (0x0090 - 0x0090)
class BTComposite_Sequence : public BTCompositeNode
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.BTComposite_Sequence"));
		
		return ptr;
	}

};


// Class AIModule.BTComposite_SimpleParallel
// 0x0008 (0x0098 - 0x0090)
class BTComposite_SimpleParallel : public BTCompositeNode
{
public:
	TEnumAsByte<EBTParallelMode>                       FinishMode_69;                                            // 0x0090(0x0001) (Edit, ZeroConstructor, DisableEditOnTemplate, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0091(0x0007) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.BTComposite_SimpleParallel"));
		
		return ptr;
	}

};


// Class AIModule.BTDecorator_BlackboardBase
// 0x0028 (0x0090 - 0x0068)
class BTDecorator_BlackboardBase : public BTDecorator
{
public:
	struct FBlackboardKeySelector                      BlackboardKey_69;                                         // 0x0068(0x0028) (Edit)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.BTDecorator_BlackboardBase"));
		
		return ptr;
	}

};


// Class AIModule.BTDecorator_Blackboard
// 0x0030 (0x00C0 - 0x0090)
class BTDecorator_Blackboard : public BTDecorator_BlackboardBase
{
public:
	int                                                IntValue_69;                                              // 0x0090(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	float                                              FloatValue_69;                                            // 0x0094(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	struct FString                                     StringValue_69;                                           // 0x0098(0x0010) (Edit, ZeroConstructor)
	struct FString                                     CachedDescription_69;                                     // 0x00A8(0x0010) (ZeroConstructor)
	unsigned char                                      OperationType_69;                                         // 0x00B8(0x0001) (ZeroConstructor, IsPlainOldData)
	TEnumAsByte<EBTBlackboardRestart>                  NotifyObserver_69;                                        // 0x00B9(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x6];                                       // 0x00BA(0x0006) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.BTDecorator_Blackboard"));
		
		return ptr;
	}

};


// Class AIModule.BTDecorator_BlueprintBase
// 0x0038 (0x00A0 - 0x0068)
class BTDecorator_BlueprintBase : public BTDecorator
{
public:
	class AIController*                                AIOwner_69;                                               // 0x0068(0x0008) (ZeroConstructor, Transient)
	class Actor_32759*                                 ActorOwner_69;                                            // 0x0070(0x0008) (ZeroConstructor, Transient)
	TArray<struct FName>                               ObservedKeyNames_69;                                      // 0x0078(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData00[0x10];                                      // 0x0088(0x0010) MISSED OFFSET
	unsigned char                                      bShowPropertyDetails_69 : 1;                              // 0x0098(0x0001) (Edit, DisableEditOnTemplate)
	unsigned char                                      bCheckConditionOnlyBlackBoardChanges_69 : 1;              // 0x0098(0x0001) (Edit, DisableEditOnInstance)
	unsigned char                                      bIsObservingBB_69 : 1;                                    // 0x0098(0x0001)
	unsigned char                                      UnknownData01[0x7];                                       // 0x0099(0x0007) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.BTDecorator_BlueprintBase"));
		
		return ptr;
	}


	void ReceiveTickAI(class AIController* OwnerController_69, class Pawn* ControlledPawn_69, float DeltaSeconds_69);
	void ReceiveTick(class Actor_32759* OwnerActor_69, float DeltaSeconds_69);
	void ReceiveObserverDeactivatedAI(class AIController* OwnerController_69, class Pawn* ControlledPawn_69);
	void ReceiveObserverDeactivated(class Actor_32759* OwnerActor_69);
	void ReceiveObserverActivatedAI(class AIController* OwnerController_69, class Pawn* ControlledPawn_69);
	void ReceiveObserverActivated(class Actor_32759* OwnerActor_69);
	void ReceiveExecutionStartAI(class AIController* OwnerController_69, class Pawn* ControlledPawn_69);
	void ReceiveExecutionStart(class Actor_32759* OwnerActor_69);
	void ReceiveExecutionFinishAI(class AIController* OwnerController_69, class Pawn* ControlledPawn_69, TEnumAsByte<EBTNodeResult> NodeResult_69);
	void ReceiveExecutionFinish(class Actor_32759* OwnerActor_69, TEnumAsByte<EBTNodeResult> NodeResult_69);
	bool PerformConditionCheckAI(class AIController* OwnerController_69, class Pawn* ControlledPawn_69);
	bool PerformConditionCheck(class Actor_32759* OwnerActor_69);
	bool IsDecoratorObserverActive();
	bool IsDecoratorExecutionActive();
};


// Class AIModule.BTDecorator_CheckGameplayTagsOnActor
// 0x0060 (0x00C8 - 0x0068)
class BTDecorator_CheckGameplayTagsOnActor : public BTDecorator
{
public:
	struct FBlackboardKeySelector                      ActorToCheck_69;                                          // 0x0068(0x0028) (Edit)
	EGameplayContainerMatchType                        TagsToMatch_69;                                           // 0x0090(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0091(0x0007) MISSED OFFSET
	struct FGameplayTagContainer                       GameplayTags_69;                                          // 0x0098(0x0020) (Edit)
	struct FString                                     CachedDescription_69;                                     // 0x00B8(0x0010) (ZeroConstructor)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.BTDecorator_CheckGameplayTagsOnActor"));
		
		return ptr;
	}

};


// Class AIModule.BTDecorator_CompareBBEntries
// 0x0058 (0x00C0 - 0x0068)
class BTDecorator_CompareBBEntries : public BTDecorator
{
public:
	TEnumAsByte<EBlackBoardEntryComparison>            Operator_69;                                              // 0x0068(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0069(0x0007) MISSED OFFSET
	struct FBlackboardKeySelector                      BlackboardKeyA_69;                                        // 0x0070(0x0028) (Edit)
	struct FBlackboardKeySelector                      BlackboardKeyB_69;                                        // 0x0098(0x0028) (Edit)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.BTDecorator_CompareBBEntries"));
		
		return ptr;
	}

};


// Class AIModule.BTDecorator_ConditionalLoop
// 0x0000 (0x00C0 - 0x00C0)
class BTDecorator_ConditionalLoop : public BTDecorator_Blackboard
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.BTDecorator_ConditionalLoop"));
		
		return ptr;
	}

};


// Class AIModule.BTDecorator_ConeCheck
// 0x0088 (0x00F0 - 0x0068)
class BTDecorator_ConeCheck : public BTDecorator
{
public:
	float                                              ConeHalfAngle_69;                                         // 0x0068(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x006C(0x0004) MISSED OFFSET
	struct FBlackboardKeySelector                      ConeOrigin_69;                                            // 0x0070(0x0028) (Edit)
	struct FBlackboardKeySelector                      ConeDirection_69;                                         // 0x0098(0x0028) (Edit)
	struct FBlackboardKeySelector                      Observed_69;                                              // 0x00C0(0x0028) (Edit)
	unsigned char                                      UnknownData01[0x8];                                       // 0x00E8(0x0008) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.BTDecorator_ConeCheck"));
		
		return ptr;
	}

};


// Class AIModule.BTDecorator_Cooldown
// 0x0008 (0x0070 - 0x0068)
class BTDecorator_Cooldown : public BTDecorator
{
public:
	float                                              CoolDownTime_69;                                          // 0x0068(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x006C(0x0004) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.BTDecorator_Cooldown"));
		
		return ptr;
	}

};


// Class AIModule.BTDecorator_DoesPathExist
// 0x0060 (0x00C8 - 0x0068)
class BTDecorator_DoesPathExist : public BTDecorator
{
public:
	struct FBlackboardKeySelector                      BlackboardKeyA_69;                                        // 0x0068(0x0028) (Edit)
	struct FBlackboardKeySelector                      BlackboardKeyB_69;                                        // 0x0090(0x0028) (Edit)
	unsigned char                                      bUseSelf_69 : 1;                                          // 0x00B8(0x0001)
	unsigned char                                      UnknownData00[0x3];                                       // 0x00B9(0x0003) MISSED OFFSET
	TEnumAsByte<EPathExistanceQueryType>               PathQueryType_69;                                         // 0x00BC(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x3];                                       // 0x00BD(0x0003) MISSED OFFSET
	class NavigationQueryFilter*                       FilterClass_69;                                           // 0x00C0(0x0008) (Edit, ZeroConstructor)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.BTDecorator_DoesPathExist"));
		
		return ptr;
	}

};


// Class AIModule.BTDecorator_ForceSuccess
// 0x0000 (0x0068 - 0x0068)
class BTDecorator_ForceSuccess : public BTDecorator
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.BTDecorator_ForceSuccess"));
		
		return ptr;
	}

};


// Class AIModule.BTDecorator_IsAtLocation
// 0x0048 (0x00D8 - 0x0090)
class BTDecorator_IsAtLocation : public BTDecorator_BlackboardBase
{
public:
	float                                              AcceptableRadius_69;                                      // 0x0090(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0094(0x0004) MISSED OFFSET
	struct FAIDataProviderFloatValue                   ParametrizedAcceptableRadius_69;                          // 0x0098(0x0038) (Edit)
	EFAIDistanceType                                   GeometricDistanceType_69;                                 // 0x00D0(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x3];                                       // 0x00D1(0x0003) MISSED OFFSET
	unsigned char                                      bUseParametrizedRadius_69 : 1;                            // 0x00D4(0x0001)
	unsigned char                                      bUseNavAgentGoalLocation_69 : 1;                          // 0x00D4(0x0001) (Edit)
	unsigned char                                      bPathFindingBasedTest_69 : 1;                             // 0x00D4(0x0001) (Edit)
	unsigned char                                      UnknownData02[0x3];                                       // 0x00D5(0x0003) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.BTDecorator_IsAtLocation"));
		
		return ptr;
	}

};


// Class AIModule.BTDecorator_IsBBEntryOfClass
// 0x0008 (0x0098 - 0x0090)
class BTDecorator_IsBBEntryOfClass : public BTDecorator_BlackboardBase
{
public:
	class Object_32759*                                TestClass_69;                                             // 0x0090(0x0008) (Edit, ZeroConstructor)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.BTDecorator_IsBBEntryOfClass"));
		
		return ptr;
	}

};


// Class AIModule.BTDecorator_KeepInCone
// 0x0060 (0x00C8 - 0x0068)
class BTDecorator_KeepInCone : public BTDecorator
{
public:
	float                                              ConeHalfAngle_69;                                         // 0x0068(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x006C(0x0004) MISSED OFFSET
	struct FBlackboardKeySelector                      ConeOrigin_69;                                            // 0x0070(0x0028) (Edit)
	struct FBlackboardKeySelector                      Observed_69;                                              // 0x0098(0x0028) (Edit)
	unsigned char                                      bUseSelfAsOrigin_69 : 1;                                  // 0x00C0(0x0001)
	unsigned char                                      bUseSelfAsObserved_69 : 1;                                // 0x00C0(0x0001)
	unsigned char                                      UnknownData01[0x7];                                       // 0x00C1(0x0007) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.BTDecorator_KeepInCone"));
		
		return ptr;
	}

};


// Class AIModule.BTDecorator_Loop
// 0x0010 (0x0078 - 0x0068)
class BTDecorator_Loop : public BTDecorator
{
public:
	int                                                NumLoops_69;                                              // 0x0068(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	bool                                               bInfiniteLoop_69;                                         // 0x006C(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x006D(0x0003) MISSED OFFSET
	float                                              InfiniteLoopTimeoutTime_69;                               // 0x0070(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x4];                                       // 0x0074(0x0004) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.BTDecorator_Loop"));
		
		return ptr;
	}

};


// Class AIModule.BTDecorator_ReachedMoveGoal
// 0x0000 (0x0068 - 0x0068)
class BTDecorator_ReachedMoveGoal : public BTDecorator
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.BTDecorator_ReachedMoveGoal"));
		
		return ptr;
	}

};


// Class AIModule.BTDecorator_SetTagCooldown
// 0x0010 (0x0078 - 0x0068)
class BTDecorator_SetTagCooldown : public BTDecorator
{
public:
	struct FGameplayTag                                CooldownTag_69;                                           // 0x0068(0x0004) (Edit)
	float                                              CooldownDuration_69;                                      // 0x006C(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	bool                                               bAddToExistingDuration_69;                                // 0x0070(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0071(0x0007) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.BTDecorator_SetTagCooldown"));
		
		return ptr;
	}

};


// Class AIModule.BTDecorator_TagCooldown
// 0x0010 (0x0078 - 0x0068)
class BTDecorator_TagCooldown : public BTDecorator
{
public:
	struct FGameplayTag                                CooldownTag_69;                                           // 0x0068(0x0004) (Edit)
	float                                              CooldownDuration_69;                                      // 0x006C(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	bool                                               bAddToExistingDuration_69;                                // 0x0070(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	bool                                               bActivatesCooldown_69;                                    // 0x0071(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x6];                                       // 0x0072(0x0006) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.BTDecorator_TagCooldown"));
		
		return ptr;
	}

};


// Class AIModule.BTDecorator_TimeLimit
// 0x0008 (0x0070 - 0x0068)
class BTDecorator_TimeLimit : public BTDecorator
{
public:
	float                                              TimeLimit_69;                                             // 0x0068(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x006C(0x0004) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.BTDecorator_TimeLimit"));
		
		return ptr;
	}

};


// Class AIModule.BTService_BlackboardBase
// 0x0028 (0x0098 - 0x0070)
class BTService_BlackboardBase : public BTService
{
public:
	struct FBlackboardKeySelector                      BlackboardKey_69;                                         // 0x0070(0x0028) (Edit)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.BTService_BlackboardBase"));
		
		return ptr;
	}

};


// Class AIModule.BTService_BlueprintBase
// 0x0028 (0x0098 - 0x0070)
class BTService_BlueprintBase : public BTService
{
public:
	class AIController*                                AIOwner_69;                                               // 0x0070(0x0008) (ZeroConstructor, Transient)
	class Actor_32759*                                 ActorOwner_69;                                            // 0x0078(0x0008) (ZeroConstructor, Transient)
	unsigned char                                      UnknownData00[0x10];                                      // 0x0080(0x0010) MISSED OFFSET
	unsigned char                                      bShowPropertyDetails_69 : 1;                              // 0x0090(0x0001) (Edit, DisableEditOnTemplate)
	unsigned char                                      bShowEventDetails_69 : 1;                                 // 0x0090(0x0001) (Edit, DisableEditOnTemplate)
	unsigned char                                      UnknownData01[0x7];                                       // 0x0091(0x0007) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.BTService_BlueprintBase"));
		
		return ptr;
	}


	void ReceiveTickAI(class AIController* OwnerController_69, class Pawn* ControlledPawn_69, float DeltaSeconds_69);
	void ReceiveTick(class Actor_32759* OwnerActor_69, float DeltaSeconds_69);
	void ReceiveSearchStartAI(class AIController* OwnerController_69, class Pawn* ControlledPawn_69);
	void ReceiveSearchStart(class Actor_32759* OwnerActor_69);
	void ReceiveDeactivationAI(class AIController* OwnerController_69, class Pawn* ControlledPawn_69);
	void ReceiveDeactivation(class Actor_32759* OwnerActor_69);
	void ReceiveActivationAI(class AIController* OwnerController_69, class Pawn* ControlledPawn_69);
	void ReceiveActivation(class Actor_32759* OwnerActor_69);
	bool IsServiceActive();
};


// Class AIModule.BTService_DefaultFocus
// 0x0008 (0x00A0 - 0x0098)
class BTService_DefaultFocus : public BTService_BlackboardBase
{
public:
	unsigned char                                      FocusPriority_69;                                         // 0x0098(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0099(0x0007) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.BTService_DefaultFocus"));
		
		return ptr;
	}

};


// Class AIModule.BTService_RunEQS
// 0x0060 (0x00F8 - 0x0098)
class BTService_RunEQS : public BTService_BlackboardBase
{
public:
	struct FEQSParametrizedQueryExecutionRequest       EQSRequest_69;                                            // 0x0098(0x0048) (Edit)
	bool                                               bUpdateBBOnFail_69;                                       // 0x00E0(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x17];                                      // 0x00E1(0x0017) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.BTService_RunEQS"));
		
		return ptr;
	}

};


// Class AIModule.BTTask_BlueprintBase
// 0x0038 (0x00A8 - 0x0070)
class BTTask_BlueprintBase : public BTTaskNode
{
public:
	class AIController*                                AIOwner_69;                                               // 0x0070(0x0008) (ZeroConstructor, Transient)
	class Actor_32759*                                 ActorOwner_69;                                            // 0x0078(0x0008) (ZeroConstructor, Transient)
	struct FIntervalCountdown                          TickInterval_69;                                          // 0x0080(0x0008) (Edit)
	unsigned char                                      UnknownData00[0x18];                                      // 0x0088(0x0018) MISSED OFFSET
	unsigned char                                      bShowPropertyDetails_69 : 1;                              // 0x00A0(0x0001) (Edit, DisableEditOnTemplate)
	unsigned char                                      UnknownData01[0x7];                                       // 0x00A1(0x0007) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.BTTask_BlueprintBase"));
		
		return ptr;
	}


	void SetFinishOnMessageWithId(const struct FName& MessageName_69, int RequestId_69);
	void SetFinishOnMessage(const struct FName& MessageName_69);
	void ReceiveTickAI(class AIController* OwnerController_69, class Pawn* ControlledPawn_69, float DeltaSeconds_69);
	void ReceiveTick(class Actor_32759* OwnerActor_69, float DeltaSeconds_69);
	void ReceiveExecuteAI(class AIController* OwnerController_69, class Pawn* ControlledPawn_69);
	void ReceiveExecute(class Actor_32759* OwnerActor_69);
	void ReceiveAbortAI(class AIController* OwnerController_69, class Pawn* ControlledPawn_69);
	void ReceiveAbort(class Actor_32759* OwnerActor_69);
	bool IsTaskExecuting();
	bool IsTaskAborting();
	void FinishExecute(bool bSuccess_69);
	void FinishAbort();
};


// Class AIModule.BTTask_FinishWithResult
// 0x0008 (0x0078 - 0x0070)
class BTTask_FinishWithResult : public BTTaskNode
{
public:
	TEnumAsByte<EBTNodeResult>                         Result_69;                                                // 0x0070(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0071(0x0007) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.BTTask_FinishWithResult"));
		
		return ptr;
	}

};


// Class AIModule.BTTask_GameplayTaskBase
// 0x0008 (0x0078 - 0x0070)
class BTTask_GameplayTaskBase : public BTTaskNode
{
public:
	unsigned char                                      bWaitForGameplayTask_69 : 1;                              // 0x0070(0x0001) (Edit)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0071(0x0007) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.BTTask_GameplayTaskBase"));
		
		return ptr;
	}

};


// Class AIModule.BTTask_MakeNoise
// 0x0008 (0x0078 - 0x0070)
class BTTask_MakeNoise : public BTTaskNode
{
public:
	float                                              Loudnes_69;                                               // 0x0070(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0074(0x0004) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.BTTask_MakeNoise"));
		
		return ptr;
	}

};


// Class AIModule.BTTask_MoveDirectlyToward
// 0x0008 (0x00B8 - 0x00B0)
class BTTask_MoveDirectlyToward : public BTTask_MoveTo
{
public:
	unsigned char                                      bDisablePathUpdateOnGoalLocationChange_69 : 1;            // 0x00B0(0x0001)
	unsigned char                                      bProjectVectorGoalToNavigation_69 : 1;                    // 0x00B0(0x0001)
	unsigned char                                      bUpdatedDeprecatedProperties_69 : 1;                      // 0x00B0(0x0001)
	unsigned char                                      UnknownData00[0x7];                                       // 0x00B1(0x0007) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.BTTask_MoveDirectlyToward"));
		
		return ptr;
	}

};


// Class AIModule.BTTask_PawnActionBase
// 0x0000 (0x0070 - 0x0070)
class BTTask_PawnActionBase : public BTTaskNode
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.BTTask_PawnActionBase"));
		
		return ptr;
	}

};


// Class AIModule.BTTask_PlayAnimation
// 0x0040 (0x00B0 - 0x0070)
class BTTask_PlayAnimation : public BTTaskNode
{
public:
	class AnimationAsset*                              AnimationToPlay_69;                                       // 0x0070(0x0008) (Edit, ZeroConstructor)
	unsigned char                                      bLooping_69 : 1;                                          // 0x0078(0x0001) (Edit)
	unsigned char                                      bNonBlocking_69 : 1;                                      // 0x0078(0x0001) (Edit)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0079(0x0007) MISSED OFFSET
	class BehaviorTreeComponent*                       MyOwnerComp_69;                                           // 0x0080(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	class SkeletalMeshComponent*                       CachedSkelMesh_69;                                        // 0x0088(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	unsigned char                                      UnknownData01[0x20];                                      // 0x0090(0x0020) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.BTTask_PlayAnimation"));
		
		return ptr;
	}

};


// Class AIModule.BTTask_PlaySound
// 0x0008 (0x0078 - 0x0070)
class BTTask_PlaySound : public BTTaskNode
{
public:
	class SoundCue*                                    SoundToPlay_69;                                           // 0x0070(0x0008) (Edit, ZeroConstructor)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.BTTask_PlaySound"));
		
		return ptr;
	}

};


// Class AIModule.BTTask_PushPawnAction
// 0x0008 (0x0078 - 0x0070)
class BTTask_PushPawnAction : public BTTask_PawnActionBase
{
public:
	class PawnAction*                                  Action_69;                                                // 0x0070(0x0008) (Edit, ExportObject, ZeroConstructor, InstancedReference)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.BTTask_PushPawnAction"));
		
		return ptr;
	}

};


// Class AIModule.BTTask_RotateToFaceBBEntry
// 0x0008 (0x00A0 - 0x0098)
class BTTask_RotateToFaceBBEntry : public BTTask_BlackboardBase
{
public:
	float                                              Precision_69;                                             // 0x0098(0x0004) (Edit, ZeroConstructor, Config, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x009C(0x0004) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.BTTask_RotateToFaceBBEntry"));
		
		return ptr;
	}

};


// Class AIModule.BTTask_RunBehavior
// 0x0008 (0x0078 - 0x0070)
class BTTask_RunBehavior : public BTTaskNode
{
public:
	class BehaviorTree*                                BehaviorAsset_69;                                         // 0x0070(0x0008) (Edit, ZeroConstructor)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.BTTask_RunBehavior"));
		
		return ptr;
	}

};


// Class AIModule.BTTask_RunBehaviorDynamic
// 0x0018 (0x0088 - 0x0070)
class BTTask_RunBehaviorDynamic : public BTTaskNode
{
public:
	struct FGameplayTag                                InjectionTag_69;                                          // 0x0070(0x0004) (Edit)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0074(0x0004) MISSED OFFSET
	class BehaviorTree*                                DefaultBehaviorAsset_69;                                  // 0x0078(0x0008) (Edit, ZeroConstructor)
	class BehaviorTree*                                BehaviorAsset_69;                                         // 0x0080(0x0008) (ZeroConstructor)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.BTTask_RunBehaviorDynamic"));
		
		return ptr;
	}

};


// Class AIModule.BTTask_RunEQSQuery
// 0x00C0 (0x0158 - 0x0098)
class BTTask_RunEQSQuery : public BTTask_BlackboardBase
{
public:
	class EnvQuery*                                    QueryTemplate_69;                                         // 0x0098(0x0008) (ZeroConstructor)
	TArray<struct FEnvNamedValue>                      QueryParams_69;                                           // 0x00A0(0x0010) (ZeroConstructor)
	TArray<struct FAIDynamicParam>                     QueryConfig_69;                                           // 0x00B0(0x0010) (ZeroConstructor)
	TEnumAsByte<EEnvQueryRunMode>                      RunMode_69;                                               // 0x00C0(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x00C1(0x0007) MISSED OFFSET
	struct FBlackboardKeySelector                      EQSQueryBlackboardKey_69;                                 // 0x00C8(0x0028)
	bool                                               bUseBBKey_69;                                             // 0x00F0(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x7];                                       // 0x00F1(0x0007) MISSED OFFSET
	struct FEQSParametrizedQueryExecutionRequest       EQSRequest_69;                                            // 0x00F8(0x0048) (Edit)
	bool                                               bUpdateBBOnFail_69;                                       // 0x0140(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData02[0x17];                                      // 0x0141(0x0017) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.BTTask_RunEQSQuery"));
		
		return ptr;
	}

};


// Class AIModule.BTTask_SetTagCooldown
// 0x0010 (0x0080 - 0x0070)
class BTTask_SetTagCooldown : public BTTaskNode
{
public:
	struct FGameplayTag                                CooldownTag_69;                                           // 0x0070(0x0004) (Edit)
	bool                                               bAddToExistingDuration_69;                                // 0x0074(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0075(0x0003) MISSED OFFSET
	float                                              CooldownDuration_69;                                      // 0x0078(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x4];                                       // 0x007C(0x0004) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.BTTask_SetTagCooldown"));
		
		return ptr;
	}

};


// Class AIModule.BTTask_Wait
// 0x0008 (0x0078 - 0x0070)
class BTTask_Wait : public BTTaskNode
{
public:
	float                                              WaitTime_69;                                              // 0x0070(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	float                                              RandomDeviation_69;                                       // 0x0074(0x0004) (Edit, ZeroConstructor, IsPlainOldData)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.BTTask_Wait"));
		
		return ptr;
	}

};


// Class AIModule.BTTask_WaitBlackboardTime
// 0x0028 (0x00A0 - 0x0078)
class BTTask_WaitBlackboardTime : public BTTask_Wait
{
public:
	struct FBlackboardKeySelector                      BlackboardKey_69;                                         // 0x0078(0x0028) (Edit)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.BTTask_WaitBlackboardTime"));
		
		return ptr;
	}

};


// Class AIModule.AIBlueprintHelperLibrary
// 0x0000 (0x0028 - 0x0028)
class AIBlueprintHelperLibrary : public BlueprintFunctionLibrary
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.AIBlueprintHelperLibrary"));
		
		return ptr;
	}


	void STATIC_UnlockAIResourcesWithAnimation(class AnimInstance* AnimInstance_69, bool bUnlockMovement_69, bool UnlockAILogic_69);
	class Pawn* STATIC_SpawnAIFromClass(class Object_32759* WorldContextObject_69, class Pawn* PawnClass_69, class BehaviorTree* BehaviorTree_69, const struct FVector& Location_69, const struct FRotator& Rotation_69, bool bNoCollisionFail_69, class Actor_32759* Owner_69);
	void STATIC_SimpleMoveToLocation(class Controller* Controller_69, const struct FVector& Goal_69);
	void STATIC_SimpleMoveToActor(class Controller* Controller_69, class Actor_32759* Goal_69);
	void STATIC_SendAIMessage(class Pawn* Target_69, const struct FName& message_69, class Object_32759* MessageSource_69, bool bSuccess_69);
	void STATIC_LockAIResourcesWithAnimation(class AnimInstance* AnimInstance_69, bool bLockMovement_69, bool LockAILogic_69);
	bool STATIC_IsValidAIRotation(const struct FRotator& Rotation_69);
	bool STATIC_IsValidAILocation(const struct FVector& Location_69);
	bool STATIC_IsValidAIDirection(const struct FVector& DirectionVector_69);
	int STATIC_GetNextNavLinkIndex(class Controller* Controller_69);
	TArray<struct FVector> STATIC_GetCurrentPathPoints(class Controller* Controller_69);
	int STATIC_GetCurrentPathIndex(class Controller* Controller_69);
	class NavigationPath* STATIC_GetCurrentPath(class Controller* Controller_69);
	class BlackboardComponent* STATIC_GetBlackboard(class Actor_32759* Target_69);
	class AIController* STATIC_GetAIController(class Actor_32759* ControlledActor_69);
	class AIAsyncTaskBlueprintProxy* STATIC_CreateMoveToProxyObject(class Object_32759* WorldContextObject_69, class Pawn* Pawn_69, const struct FVector& Destination_69, class Actor_32759* TargetActor_69, float AcceptanceRadius_69, bool bStopOnOverlap_69);
};


// Class AIModule.AIDataProvider
// 0x0000 (0x0028 - 0x0028)
class AIDataProvider : public Object_32759
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.AIDataProvider"));
		
		return ptr;
	}

};


// Class AIModule.AIDataProvider_QueryParams
// 0x0010 (0x0038 - 0x0028)
class AIDataProvider_QueryParams : public AIDataProvider
{
public:
	struct FName                                       ParamName_69;                                             // 0x0028(0x0008) (Edit, ZeroConstructor, IsPlainOldData)
	float                                              FloatValue_69;                                            // 0x002C(0x0004) (ZeroConstructor, IsPlainOldData)
	int                                                IntValue_69;                                              // 0x0030(0x0004) (ZeroConstructor, IsPlainOldData)
	bool                                               BoolValue_69;                                             // 0x0034(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0035(0x0003) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.AIDataProvider_QueryParams"));
		
		return ptr;
	}

};


// Class AIModule.AIDataProvider_Random
// 0x0010 (0x0048 - 0x0038)
class AIDataProvider_Random : public AIDataProvider_QueryParams
{
public:
	float                                              min_69;                                                   // 0x0038(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	float                                              max_69;                                                   // 0x003C(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      bInteger_69 : 1;                                          // 0x0040(0x0001) (Edit)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0041(0x0007) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.AIDataProvider_Random"));
		
		return ptr;
	}

};


// Class AIModule.DetourCrowdAIController
// 0x0000 (0x03B0 - 0x03B0)
class DetourCrowdAIController : public AIController
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.DetourCrowdAIController"));
		
		return ptr;
	}

};


// Class AIModule.EnvQueryContext_BlueprintBase
// 0x0008 (0x0030 - 0x0028)
class EnvQueryContext_BlueprintBase : public EnvQueryContext
{
public:
	unsigned char                                      UnknownData00[0x8];                                       // 0x0028(0x0008) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.EnvQueryContext_BlueprintBase"));
		
		return ptr;
	}


	void ProvideSingleLocation(class Object_32759* QuerierObject_69, class Actor_32759* QuerierActor_69, struct FVector* ResultingLocation_69);
	void ProvideSingleActor(class Object_32759* QuerierObject_69, class Actor_32759* QuerierActor_69, class Actor_32759** ResultingActor_69);
	void ProvideLocationsSet(class Object_32759* QuerierObject_69, class Actor_32759* QuerierActor_69, TArray<struct FVector>* ResultingLocationSet_69);
	void ProvideActorsSet(class Object_32759* QuerierObject_69, class Actor_32759* QuerierActor_69, TArray<class Actor_32759*>* ResultingActorsSet_69);
};


// Class AIModule.EnvQueryContext_Item
// 0x0000 (0x0028 - 0x0028)
class EnvQueryContext_Item : public EnvQueryContext
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.EnvQueryContext_Item"));
		
		return ptr;
	}

};


// Class AIModule.EnvQueryContext_Querier
// 0x0000 (0x0028 - 0x0028)
class EnvQueryContext_Querier : public EnvQueryContext
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.EnvQueryContext_Querier"));
		
		return ptr;
	}

};


// Class AIModule.EnvQuery
// 0x0018 (0x0048 - 0x0030)
class EnvQuery : public DataAsset
{
public:
	struct FName                                       QueryName_69;                                             // 0x0030(0x0008) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0034(0x0004) MISSED OFFSET
	TArray<class EnvQueryOption*>                      Options_69;                                               // 0x0038(0x0010) (ZeroConstructor)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.EnvQuery"));
		
		return ptr;
	}

};


// Class AIModule.EnvQueryDebugHelpers
// 0x0000 (0x0028 - 0x0028)
class EnvQueryDebugHelpers : public Object_32759
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.EnvQueryDebugHelpers"));
		
		return ptr;
	}

};


// Class AIModule.EnvQueryGenerator
// 0x0020 (0x0050 - 0x0030)
class EnvQueryGenerator : public EnvQueryNode
{
public:
	struct FString                                     OptionName_69;                                            // 0x0030(0x0010) (Edit, ZeroConstructor, DisableEditOnInstance)
	class EnvQueryItemType*                            ItemType_69;                                              // 0x0040(0x0008) (ZeroConstructor)
	unsigned char                                      bAutoSortTests_69 : 1;                                    // 0x0048(0x0001) (Edit, DisableEditOnInstance)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0049(0x0007) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.EnvQueryGenerator"));
		
		return ptr;
	}

};


// Class AIModule.EnvQueryInstanceBlueprintWrapper
// 0x0050 (0x0078 - 0x0028)
class EnvQueryInstanceBlueprintWrapper : public Object_32759
{
public:
	unsigned char                                      UnknownData00[0x8];                                       // 0x0028(0x0008) MISSED OFFSET
	int                                                QueryID_69;                                               // 0x0030(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x24];                                      // 0x0034(0x0024) MISSED OFFSET
	class EnvQueryItemType*                            ItemType_69;                                              // 0x0058(0x0008) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
	int                                                OptionIndex_69;                                           // 0x0060(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData02[0x4];                                       // 0x0064(0x0004) MISSED OFFSET
	unsigned char                                      UnknownData03[0x10];                                      // 0x0064(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty AIModule.EnvQueryInstanceBlueprintWrapper.OnQueryFinishedEvent_69

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.EnvQueryInstanceBlueprintWrapper"));
		
		return ptr;
	}


	void SetNamedParam(const struct FName& ParamName_69, float Value_69);
	TArray<struct FVector> GetResultsAsLocations();
	TArray<class Actor_32759*> GetResultsAsActors();
	bool GetQueryResultsAsLocations(TArray<struct FVector>* ResultLocations_69);
	bool GetQueryResultsAsActors(TArray<class Actor_32759*>* ResultActors_69);
	float GetItemScore(int ItemIndex_69);
	void EQSQueryDoneSignature__DelegateSignature(class EnvQueryInstanceBlueprintWrapper* QueryInstance_69, TEnumAsByte<EEnvQueryStatus> QueryStatus_69);
};


// Class AIModule.EnvQueryManager
// 0x0120 (0x0158 - 0x0038)
class EnvQueryManager : public AISubsystem
{
public:
	unsigned char                                      UnknownData00[0x70];                                      // 0x0038(0x0070) MISSED OFFSET
	TArray<struct FEnvQueryInstanceCache>              InstanceCache_69;                                         // 0x00A8(0x0010) (ZeroConstructor, Transient)
	TArray<class EnvQueryContext*>                     LocalContexts_69;                                         // 0x00B8(0x0010) (ZeroConstructor, Transient)
	TArray<class EnvQueryInstanceBlueprintWrapper*>    GCShieldedWrappers_69;                                    // 0x00C8(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData01[0x54];                                      // 0x00D8(0x0054) MISSED OFFSET
	float                                              MaxAllowedTestingTime_69;                                 // 0x012C(0x0004) (ZeroConstructor, Config, IsPlainOldData)
	bool                                               bTestQueriesUsingBreadth_69;                              // 0x0130(0x0001) (ZeroConstructor, Config, IsPlainOldData)
	unsigned char                                      UnknownData02[0x3];                                       // 0x0131(0x0003) MISSED OFFSET
	int                                                QueryCountWarningThreshold_69;                            // 0x0134(0x0004) (ZeroConstructor, Config, IsPlainOldData)
	double                                             QueryCountWarningInterval_69;                             // 0x0138(0x0008) (ZeroConstructor, Config, IsPlainOldData)
	double                                             ExecutionTimeWarningSeconds_69;                           // 0x0140(0x0008) (ZeroConstructor, Config, IsPlainOldData)
	double                                             HandlingResultTimeWarningSeconds_69;                      // 0x0148(0x0008) (ZeroConstructor, Config, IsPlainOldData)
	double                                             GenerationTimeWarningSeconds_69;                          // 0x0150(0x0008) (ZeroConstructor, Config, IsPlainOldData)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.EnvQueryManager"));
		
		return ptr;
	}


	class EnvQueryInstanceBlueprintWrapper* STATIC_RunEQSQuery(class Object_32759* WorldContextObject_69, class EnvQuery* QueryTemplate_69, class Object_32759* Querier_69, TEnumAsByte<EEnvQueryRunMode> RunMode_69, class EnvQueryInstanceBlueprintWrapper* WrapperClass_69);
};


// Class AIModule.EnvQueryOption
// 0x0018 (0x0040 - 0x0028)
class EnvQueryOption : public Object_32759
{
public:
	class EnvQueryGenerator*                           Generator_69;                                             // 0x0028(0x0008) (ZeroConstructor)
	TArray<class EnvQueryTest*>                        Tests_69;                                                 // 0x0030(0x0010) (ZeroConstructor)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.EnvQueryOption"));
		
		return ptr;
	}

};


// Class AIModule.EQSRenderingComponent
// 0x0040 (0x05C0 - 0x0580)
class EQSRenderingComponent : public DebugDrawComponent
{
public:
	unsigned char                                      UnknownData00[0x40];                                      // 0x0580(0x0040) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.EQSRenderingComponent"));
		
		return ptr;
	}

};


// Class AIModule.EQSTestingPawn
// 0x00A0 (0x06B0 - 0x0610)
class EQSTestingPawn : public Character
{
public:
	unsigned char                                      UnknownData00[0x8];                                       // 0x0610(0x0008) MISSED OFFSET
	class EnvQuery*                                    QueryTemplate_69;                                         // 0x0618(0x0008) (Edit, ZeroConstructor)
	TArray<struct FEnvNamedValue>                      QueryParams_69;                                           // 0x0620(0x0010) (ZeroConstructor)
	TArray<struct FAIDynamicParam>                     QueryConfig_69;                                           // 0x0630(0x0010) (Edit, ZeroConstructor)
	float                                              TimeLimitPerStep_69;                                      // 0x0640(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	int                                                StepToDebugDraw_69;                                       // 0x0644(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	EEnvQueryHightlightMode                            HighlightMode_69;                                         // 0x0648(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x3];                                       // 0x0649(0x0003) MISSED OFFSET
	unsigned char                                      bDrawLabels_69 : 1;                                       // 0x064C(0x0001) (Edit)
	unsigned char                                      bDrawFailedItems_69 : 1;                                  // 0x064C(0x0001) (Edit)
	unsigned char                                      bReRunQueryOnlyOnFinishedMove_69 : 1;                     // 0x064C(0x0001) (Edit)
	unsigned char                                      bShouldBeVisibleInGame_69 : 1;                            // 0x064C(0x0001) (Edit)
	unsigned char                                      bTickDuringGame_69 : 1;                                   // 0x064C(0x0001) (Edit)
	unsigned char                                      UnknownData02[0x3];                                       // 0x064D(0x0003) MISSED OFFSET
	TEnumAsByte<EEnvQueryRunMode>                      QueryingMode_69;                                          // 0x0650(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData03[0x7];                                       // 0x0651(0x0007) MISSED OFFSET
	struct FNavAgentProperties                         NavAgentProperties_69;                                    // 0x0658(0x0030) (Edit)
	unsigned char                                      UnknownData04[0x28];                                      // 0x0688(0x0028) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.EQSTestingPawn"));
		
		return ptr;
	}

};


// Class AIModule.EnvQueryGenerator_ActorsOfClass
// 0x0080 (0x00D0 - 0x0050)
class EnvQueryGenerator_ActorsOfClass : public EnvQueryGenerator
{
public:
	class Actor_32759*                                 SearchedActorClass_69;                                    // 0x0050(0x0008) (Edit, ZeroConstructor, DisableEditOnInstance)
	struct FAIDataProviderBoolValue                    GenerateOnlyActorsInRadius_69;                            // 0x0058(0x0038) (Edit, DisableEditOnInstance)
	struct FAIDataProviderFloatValue                   SearchRadius_69;                                          // 0x0090(0x0038) (Edit, DisableEditOnInstance)
	class EnvQueryContext*                             SearchCenter_69;                                          // 0x00C8(0x0008) (Edit, ZeroConstructor)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.EnvQueryGenerator_ActorsOfClass"));
		
		return ptr;
	}

};


// Class AIModule.EnvQueryGenerator_BlueprintBase
// 0x0038 (0x0088 - 0x0050)
class EnvQueryGenerator_BlueprintBase : public EnvQueryGenerator
{
public:
	struct FText                                       GeneratorsActionDescription_69;                           // 0x0050(0x0018) (Edit)
	class EnvQueryContext*                             Context_69;                                               // 0x0068(0x0008) (Edit, ZeroConstructor)
	class EnvQueryItemType*                            GeneratedItemType_69;                                     // 0x0070(0x0008) (Edit, ZeroConstructor, DisableEditOnInstance)
	unsigned char                                      UnknownData00[0x10];                                      // 0x0078(0x0010) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.EnvQueryGenerator_BlueprintBase"));
		
		return ptr;
	}


	class Object_32759* GetQuerier();
	void DoItemGenerationFromActors(TArray<class Actor_32759*> ContextActors_69);
	void DoItemGeneration(TArray<struct FVector> ContextLocations_69);
	void AddGeneratedVector(const struct FVector& GeneratedVector_69);
	void AddGeneratedActor(class Actor_32759* GeneratedActor_69);
};


// Class AIModule.EnvQueryGenerator_Composite
// 0x0020 (0x0070 - 0x0050)
class EnvQueryGenerator_Composite : public EnvQueryGenerator
{
public:
	TArray<class EnvQueryGenerator*>                   Generators_69;                                            // 0x0050(0x0010) (Edit, ExportObject, ZeroConstructor, DisableEditOnInstance)
	unsigned char                                      bAllowDifferentItemTypes_69 : 1;                          // 0x0060(0x0001) (Edit, DisableEditOnInstance)
	unsigned char                                      bHasMatchingItemType_69 : 1;                              // 0x0060(0x0001)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0061(0x0007) MISSED OFFSET
	class EnvQueryItemType*                            ForcedItemType_69;                                        // 0x0068(0x0008) (Edit, ZeroConstructor, DisableEditOnInstance)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.EnvQueryGenerator_Composite"));
		
		return ptr;
	}

};


// Class AIModule.EnvQueryGenerator_ProjectedPoints
// 0x0038 (0x0088 - 0x0050)
class EnvQueryGenerator_ProjectedPoints : public EnvQueryGenerator
{
public:
	struct FEnvTraceData                               ProjectionData_69;                                        // 0x0050(0x0038) (Edit, DisableEditOnInstance)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.EnvQueryGenerator_ProjectedPoints"));
		
		return ptr;
	}

};


// Class AIModule.EnvQueryGenerator_Cone
// 0x00F0 (0x0178 - 0x0088)
class EnvQueryGenerator_Cone : public EnvQueryGenerator_ProjectedPoints
{
public:
	struct FAIDataProviderFloatValue                   AlignedPointsDistance_69;                                 // 0x0088(0x0038) (Edit, DisableEditOnInstance)
	struct FAIDataProviderFloatValue                   ConeDegrees_69;                                           // 0x00C0(0x0038) (Edit, DisableEditOnInstance)
	struct FAIDataProviderFloatValue                   AngleStep_69;                                             // 0x00F8(0x0038) (Edit, DisableEditOnInstance)
	struct FAIDataProviderFloatValue                   Range_69;                                                 // 0x0130(0x0038) (Edit, DisableEditOnInstance)
	class EnvQueryContext*                             CenterActor_69;                                           // 0x0168(0x0008) (Edit, ZeroConstructor)
	unsigned char                                      bIncludeContextLocation_69 : 1;                           // 0x0170(0x0001) (Edit)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0171(0x0007) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.EnvQueryGenerator_Cone"));
		
		return ptr;
	}

};


// Class AIModule.EnvQueryGenerator_CurrentLocation
// 0x0008 (0x0058 - 0x0050)
class EnvQueryGenerator_CurrentLocation : public EnvQueryGenerator
{
public:
	class EnvQueryContext*                             QueryContext_69;                                          // 0x0050(0x0008) (Edit, ZeroConstructor, DisableEditOnInstance)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.EnvQueryGenerator_CurrentLocation"));
		
		return ptr;
	}

};


// Class AIModule.EnvQueryGenerator_Donut
// 0x0150 (0x01D8 - 0x0088)
class EnvQueryGenerator_Donut : public EnvQueryGenerator_ProjectedPoints
{
public:
	struct FAIDataProviderFloatValue                   InnerRadius_69;                                           // 0x0088(0x0038) (Edit, DisableEditOnInstance)
	struct FAIDataProviderFloatValue                   OuterRadius_69;                                           // 0x00C0(0x0038) (Edit, DisableEditOnInstance)
	struct FAIDataProviderIntValue                     NumberOfRings_69;                                         // 0x00F8(0x0038) (Edit, DisableEditOnInstance)
	struct FAIDataProviderIntValue                     PointsPerRing_69;                                         // 0x0130(0x0038) (Edit, DisableEditOnInstance)
	struct FEnvDirection                               ArcDirection_69;                                          // 0x0168(0x0020) (Edit, DisableEditOnInstance)
	struct FAIDataProviderFloatValue                   ArcAngle_69;                                              // 0x0188(0x0038) (Edit, DisableEditOnInstance)
	bool                                               bUseSpiralPattern_69;                                     // 0x01C0(0x0001) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x01C1(0x0007) MISSED OFFSET
	class EnvQueryContext*                             Center_69;                                                // 0x01C8(0x0008) (Edit, ZeroConstructor)
	unsigned char                                      bDefineArc_69 : 1;                                        // 0x01D0(0x0001) (Edit)
	unsigned char                                      UnknownData01[0x7];                                       // 0x01D1(0x0007) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.EnvQueryGenerator_Donut"));
		
		return ptr;
	}

};


// Class AIModule.EnvQueryGenerator_OnCircle
// 0x0198 (0x0220 - 0x0088)
class EnvQueryGenerator_OnCircle : public EnvQueryGenerator_ProjectedPoints
{
public:
	struct FAIDataProviderFloatValue                   CircleRadius_69;                                          // 0x0088(0x0038) (Edit, DisableEditOnInstance)
	struct FAIDataProviderFloatValue                   SpaceBetween_69;                                          // 0x00C0(0x0038) (Edit, DisableEditOnInstance)
	struct FAIDataProviderIntValue                     NumberOfPoints_69;                                        // 0x00F8(0x0038) (Edit, DisableEditOnInstance)
	EPointOnCircleSpacingMethod                        PointOnCircleSpacingMethod_69;                            // 0x0130(0x0001) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0131(0x0007) MISSED OFFSET
	struct FEnvDirection                               ArcDirection_69;                                          // 0x0138(0x0020) (Edit, DisableEditOnInstance)
	struct FAIDataProviderFloatValue                   ArcAngle_69;                                              // 0x0158(0x0038) (Edit, DisableEditOnInstance)
	float                                              AngleRadians_69;                                          // 0x0190(0x0004) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x4];                                       // 0x0194(0x0004) MISSED OFFSET
	class EnvQueryContext*                             CircleCenter_69;                                          // 0x0198(0x0008) (Edit, ZeroConstructor)
	bool                                               bIgnoreAnyContextActorsWhenGeneratingCircle_69;           // 0x01A0(0x0001) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData02[0x7];                                       // 0x01A1(0x0007) MISSED OFFSET
	struct FAIDataProviderFloatValue                   CircleCenterZOffset_69;                                   // 0x01A8(0x0038) (Edit)
	struct FEnvTraceData                               TraceData_69;                                             // 0x01E0(0x0038) (Edit)
	unsigned char                                      bDefineArc_69 : 1;                                        // 0x0218(0x0001) (Edit)
	unsigned char                                      UnknownData03[0x7];                                       // 0x0219(0x0007) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.EnvQueryGenerator_OnCircle"));
		
		return ptr;
	}

};


// Class AIModule.EnvQueryGenerator_SimpleGrid
// 0x0078 (0x0100 - 0x0088)
class EnvQueryGenerator_SimpleGrid : public EnvQueryGenerator_ProjectedPoints
{
public:
	struct FAIDataProviderFloatValue                   GridSize_69;                                              // 0x0088(0x0038) (Edit, DisableEditOnInstance)
	struct FAIDataProviderFloatValue                   SpaceBetween_69;                                          // 0x00C0(0x0038) (Edit, DisableEditOnInstance)
	class EnvQueryContext*                             GenerateAround_69;                                        // 0x00F8(0x0008) (Edit, ZeroConstructor, DisableEditOnInstance)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.EnvQueryGenerator_SimpleGrid"));
		
		return ptr;
	}

};


// Class AIModule.EnvQueryGenerator_PathingGrid
// 0x0078 (0x0178 - 0x0100)
class EnvQueryGenerator_PathingGrid : public EnvQueryGenerator_SimpleGrid
{
public:
	struct FAIDataProviderBoolValue                    PathToItem_69;                                            // 0x0100(0x0038) (Edit, DisableEditOnInstance)
	class NavigationQueryFilter*                       NavigationFilter_69;                                      // 0x0138(0x0008) (Edit, ZeroConstructor, DisableEditOnInstance)
	struct FAIDataProviderFloatValue                   ScanRangeMultiplier_69;                                   // 0x0140(0x0038) (Edit, DisableEditOnInstance)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.EnvQueryGenerator_PathingGrid"));
		
		return ptr;
	}

};


// Class AIModule.EnvQueryGenerator_PerceivedActors
// 0x0058 (0x00A8 - 0x0050)
class EnvQueryGenerator_PerceivedActors : public EnvQueryGenerator
{
public:
	class Actor_32759*                                 AllowedActorClass_69;                                     // 0x0050(0x0008) (Edit, ZeroConstructor, DisableEditOnInstance)
	struct FAIDataProviderFloatValue                   SearchRadius_69;                                          // 0x0058(0x0038) (Edit, DisableEditOnInstance)
	class EnvQueryContext*                             ListenerContext_69;                                       // 0x0090(0x0008) (Edit, ZeroConstructor)
	class AISense*                                     SenseToUse_69;                                            // 0x0098(0x0008) (Edit, ZeroConstructor)
	bool                                               bIncludeKnownActors_69;                                   // 0x00A0(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x00A1(0x0007) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.EnvQueryGenerator_PerceivedActors"));
		
		return ptr;
	}

};


// Class AIModule.EnvQueryItemType
// 0x0008 (0x0030 - 0x0028)
class EnvQueryItemType : public Object_32759
{
public:
	unsigned char                                      UnknownData00[0x8];                                       // 0x0028(0x0008) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.EnvQueryItemType"));
		
		return ptr;
	}

};


// Class AIModule.EnvQueryItemType_VectorBase
// 0x0000 (0x0030 - 0x0030)
class EnvQueryItemType_VectorBase : public EnvQueryItemType
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.EnvQueryItemType_VectorBase"));
		
		return ptr;
	}

};


// Class AIModule.EnvQueryItemType_ActorBase
// 0x0000 (0x0030 - 0x0030)
class EnvQueryItemType_ActorBase : public EnvQueryItemType_VectorBase
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.EnvQueryItemType_ActorBase"));
		
		return ptr;
	}

};


// Class AIModule.EnvQueryItemType_Actor
// 0x0000 (0x0030 - 0x0030)
class EnvQueryItemType_Actor : public EnvQueryItemType_ActorBase
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.EnvQueryItemType_Actor"));
		
		return ptr;
	}

};


// Class AIModule.EnvQueryItemType_Direction
// 0x0000 (0x0030 - 0x0030)
class EnvQueryItemType_Direction : public EnvQueryItemType_VectorBase
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.EnvQueryItemType_Direction"));
		
		return ptr;
	}

};


// Class AIModule.EnvQueryItemType_Point
// 0x0000 (0x0030 - 0x0030)
class EnvQueryItemType_Point : public EnvQueryItemType_VectorBase
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.EnvQueryItemType_Point"));
		
		return ptr;
	}

};


// Class AIModule.EnvQueryTest_Distance
// 0x0010 (0x0208 - 0x01F8)
class EnvQueryTest_Distance : public EnvQueryTest
{
public:
	TEnumAsByte<EEnvTestDistance>                      TestMode_69;                                              // 0x01F8(0x0001) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x01F9(0x0007) MISSED OFFSET
	class EnvQueryContext*                             DistanceTo_69;                                            // 0x0200(0x0008) (Edit, ZeroConstructor, DisableEditOnInstance)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.EnvQueryTest_Distance"));
		
		return ptr;
	}

};


// Class AIModule.EnvQueryTest_Dot
// 0x0048 (0x0240 - 0x01F8)
class EnvQueryTest_Dot : public EnvQueryTest
{
public:
	struct FEnvDirection                               LineA_69;                                                 // 0x01F8(0x0020) (Edit, DisableEditOnInstance)
	struct FEnvDirection                               LineB_69;                                                 // 0x0218(0x0020) (Edit, DisableEditOnInstance)
	EEnvTestDot                                        TestMode_69;                                              // 0x0238(0x0001) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	bool                                               bAbsoluteValue_69;                                        // 0x0239(0x0001) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData00[0x6];                                       // 0x023A(0x0006) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.EnvQueryTest_Dot"));
		
		return ptr;
	}

};


// Class AIModule.EnvQueryTest_GameplayTags
// 0x0070 (0x0268 - 0x01F8)
class EnvQueryTest_GameplayTags : public EnvQueryTest
{
public:
	struct FGameplayTagQuery                           TagQueryToMatch_69;                                       // 0x01F8(0x0048) (Edit)
	bool                                               bRejectIncompatibleItems_69;                              // 0x0240(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	bool                                               bUpdatedToUseQuery_69;                                    // 0x0241(0x0001) (ZeroConstructor, IsPlainOldData)
	EGameplayContainerMatchType                        TagsToMatch_69;                                           // 0x0242(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x5];                                       // 0x0243(0x0005) MISSED OFFSET
	struct FGameplayTagContainer                       GameplayTags_69;                                          // 0x0248(0x0020)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.EnvQueryTest_GameplayTags"));
		
		return ptr;
	}

};


// Class AIModule.EnvQueryTest_Overlap
// 0x0030 (0x0228 - 0x01F8)
class EnvQueryTest_Overlap : public EnvQueryTest
{
public:
	struct FEnvOverlapData                             OverlapData_69;                                           // 0x01F8(0x0030) (Edit, DisableEditOnInstance)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.EnvQueryTest_Overlap"));
		
		return ptr;
	}

};


// Class AIModule.EnvQueryTest_Pathfinding
// 0x0088 (0x0280 - 0x01F8)
class EnvQueryTest_Pathfinding : public EnvQueryTest
{
public:
	TEnumAsByte<EEnvTestPathfinding>                   TestMode_69;                                              // 0x01F8(0x0001) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x01F9(0x0007) MISSED OFFSET
	class EnvQueryContext*                             Context_69;                                               // 0x0200(0x0008) (Edit, ZeroConstructor, DisableEditOnInstance)
	struct FAIDataProviderBoolValue                    PathFromContext_69;                                       // 0x0208(0x0038) (Edit, DisableEditOnInstance)
	struct FAIDataProviderBoolValue                    SkipUnreachable_69;                                       // 0x0240(0x0038) (Edit, DisableEditOnInstance)
	class NavigationQueryFilter*                       FilterClass_69;                                           // 0x0278(0x0008) (Edit, ZeroConstructor, DisableEditOnInstance)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.EnvQueryTest_Pathfinding"));
		
		return ptr;
	}

};


// Class AIModule.EnvQueryTest_PathfindingBatch
// 0x0038 (0x02B8 - 0x0280)
class EnvQueryTest_PathfindingBatch : public EnvQueryTest_Pathfinding
{
public:
	struct FAIDataProviderFloatValue                   ScanRangeMultiplier_69;                                   // 0x0280(0x0038) (Edit, DisableEditOnInstance)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.EnvQueryTest_PathfindingBatch"));
		
		return ptr;
	}

};


// Class AIModule.EnvQueryTest_Project
// 0x0038 (0x0230 - 0x01F8)
class EnvQueryTest_Project : public EnvQueryTest
{
public:
	struct FEnvTraceData                               ProjectionData_69;                                        // 0x01F8(0x0038) (Edit, DisableEditOnInstance)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.EnvQueryTest_Project"));
		
		return ptr;
	}

};


// Class AIModule.EnvQueryTest_Random
// 0x0000 (0x01F8 - 0x01F8)
class EnvQueryTest_Random : public EnvQueryTest
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.EnvQueryTest_Random"));
		
		return ptr;
	}

};


// Class AIModule.EnvQueryTest_Trace
// 0x00E8 (0x02E0 - 0x01F8)
class EnvQueryTest_Trace : public EnvQueryTest
{
public:
	struct FEnvTraceData                               TraceData_69;                                             // 0x01F8(0x0038) (Edit, DisableEditOnInstance)
	struct FAIDataProviderBoolValue                    TraceFromContext_69;                                      // 0x0230(0x0038) (Edit, DisableEditOnInstance)
	struct FAIDataProviderFloatValue                   ItemHeightOffset_69;                                      // 0x0268(0x0038) (Edit, DisableEditOnInstance)
	struct FAIDataProviderFloatValue                   ContextHeightOffset_69;                                   // 0x02A0(0x0038) (Edit, DisableEditOnInstance)
	class EnvQueryContext*                             Context_69;                                               // 0x02D8(0x0008) (Edit, ZeroConstructor, DisableEditOnInstance)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.EnvQueryTest_Trace"));
		
		return ptr;
	}

};


// Class AIModule.EnvQueryTest_Volume
// 0x0018 (0x0210 - 0x01F8)
class EnvQueryTest_Volume : public EnvQueryTest
{
public:
	class EnvQueryContext*                             VolumeContext_69;                                         // 0x01F8(0x0008) (Edit, ZeroConstructor)
	class Volume*                                      VolumeClass_69;                                           // 0x0200(0x0008) (Edit, ZeroConstructor)
	unsigned char                                      bDoComplexVolumeTest_69 : 1;                              // 0x0208(0x0001) (Edit)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0209(0x0007) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.EnvQueryTest_Volume"));
		
		return ptr;
	}

};


// Class AIModule.GridPathAIController
// 0x0000 (0x03B0 - 0x03B0)
class GridPathAIController : public AIController
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.GridPathAIController"));
		
		return ptr;
	}

};


// Class AIModule.AIHotSpotManager
// 0x0000 (0x0028 - 0x0028)
class AIHotSpotManager : public Object_32759
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.AIHotSpotManager"));
		
		return ptr;
	}

};


// Class AIModule.PathFollowingComponent
// 0x0218 (0x02B8 - 0x00A0)
class PathFollowingComponent : public ActorComponent
{
public:
	unsigned char                                      UnknownData00[0x38];                                      // 0x00A0(0x0038) MISSED OFFSET
	class NavMovementComponent*                        MovementComp_69;                                          // 0x00D8(0x0008) (ExportObject, ZeroConstructor, Transient, InstancedReference)
	unsigned char                                      UnknownData01[0x8];                                       // 0x00E0(0x0008) MISSED OFFSET
	class NavigationData*                              MyNavData_69;                                             // 0x00E8(0x0008) (ZeroConstructor, Transient)
	unsigned char                                      UnknownData02[0x1C8];                                     // 0x00F0(0x01C8) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.PathFollowingComponent"));
		
		return ptr;
	}


	void OnNavDataRegistered(class NavigationData* NavData_69);
	void OnActorBump(class Actor_32759* SelfActor_69, class Actor_32759* OtherActor_69, const struct FVector& NormalImpulse_69, const struct FHitResult& Hit_69);
	struct FVector GetPathDestination();
	TEnumAsByte<EPathFollowingAction> GetPathActionType();
};


// Class AIModule.CrowdFollowingComponent
// 0x0050 (0x0308 - 0x02B8)
class CrowdFollowingComponent : public PathFollowingComponent
{
public:
	unsigned char                                      UnknownData00[0x18];                                      // 0x02B8(0x0018) MISSED OFFSET
	struct FVector                                     CrowdAgentMoveDirection_69;                               // 0x02D0(0x0018) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x20];                                      // 0x02E8(0x0020) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.CrowdFollowingComponent"));
		
		return ptr;
	}


	void SuspendCrowdSteering(bool bSuspend_69);
};


// Class AIModule.CrowdManager
// 0x00C8 (0x00F0 - 0x0028)
class CrowdManager : public CrowdManagerBase
{
public:
	class NavigationData*                              MyNavData_69;                                             // 0x0028(0x0008) (ZeroConstructor, Transient)
	TArray<struct FCrowdAvoidanceConfig>               AvoidanceConfig_69;                                       // 0x0030(0x0010) (Edit, ZeroConstructor, Config)
	TArray<struct FCrowdAvoidanceSamplingPattern>      SamplingPatterns_69;                                      // 0x0040(0x0010) (Edit, ZeroConstructor, Config)
	int                                                MaxAgents_69;                                             // 0x0050(0x0004) (Edit, ZeroConstructor, Config, IsPlainOldData)
	float                                              MaxAgentRadius_69;                                        // 0x0054(0x0004) (Edit, ZeroConstructor, Config, IsPlainOldData)
	int                                                MaxAvoidedAgents_69;                                      // 0x0058(0x0004) (Edit, ZeroConstructor, Config, IsPlainOldData)
	int                                                MaxAvoidedWalls_69;                                       // 0x005C(0x0004) (Edit, ZeroConstructor, Config, IsPlainOldData)
	float                                              NavmeshCheckInterval_69;                                  // 0x0060(0x0004) (Edit, ZeroConstructor, Config, IsPlainOldData)
	float                                              PathOptimizationInterval_69;                              // 0x0064(0x0004) (Edit, ZeroConstructor, Config, IsPlainOldData)
	float                                              SeparationDirClamp_69;                                    // 0x0068(0x0004) (Edit, ZeroConstructor, Config, IsPlainOldData)
	float                                              PathOffsetRadiusMultiplier_69;                            // 0x006C(0x0004) (Edit, ZeroConstructor, Config, IsPlainOldData)
	unsigned char                                      UnknownData00 : 4;                                        // 0x0070(0x0001)
	unsigned char                                      bResolveCollisions_69 : 1;                                // 0x0070(0x0001) (Edit, Config)
	unsigned char                                      UnknownData01[0x7F];                                      // 0x0071(0x007F) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.CrowdManager"));
		
		return ptr;
	}

};


// Class AIModule.GridPathFollowingComponent
// 0x0030 (0x02E8 - 0x02B8)
class GridPathFollowingComponent : public PathFollowingComponent
{
public:
	class NavLocalGridManager*                         GridManager_69;                                           // 0x02B8(0x0008) (ZeroConstructor, Transient)
	unsigned char                                      UnknownData00[0x28];                                      // 0x02C0(0x0028) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.GridPathFollowingComponent"));
		
		return ptr;
	}

};


// Class AIModule.NavFilter_AIControllerDefault
// 0x0000 (0x0048 - 0x0048)
class NavFilter_AIControllerDefault : public NavigationQueryFilter
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.NavFilter_AIControllerDefault"));
		
		return ptr;
	}

};


// Class AIModule.NavLinkProxy
// 0x0050 (0x02D8 - 0x0288)
class NavLinkProxy : public Actor_32759
{
public:
	unsigned char                                      UnknownData00[0x10];                                      // 0x0288(0x0010) MISSED OFFSET
	TArray<struct FNavigationLink>                     PointLinks_69;                                            // 0x0298(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
	TArray<struct FNavigationSegmentLink>              SegmentLinks_69;                                          // 0x02A8(0x0010) (ZeroConstructor)
	class NavLinkCustomComponent*                      SmartLinkComp_69;                                         // 0x02B8(0x0008) (Edit, ExportObject, ZeroConstructor, EditConst, InstancedReference)
	bool                                               bSmartLinkIsRelevant_69;                                  // 0x02C0(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x7];                                       // 0x02C1(0x0007) MISSED OFFSET
	unsigned char                                      UnknownData02[0x10];                                      // 0x02C1(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty AIModule.NavLinkProxy.OnSmartLinkReached_69

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.NavLinkProxy"));
		
		return ptr;
	}


	void SetSmartLinkEnabled(bool bEnabled_69);
	void ResumePathFollowing(class Actor_32759* Agent_69);
	void ReceiveSmartLinkReached(class Actor_32759* Agent_69, const struct FVector& Destination_69);
	bool IsSmartLinkEnabled();
	bool HasMovingAgents();
};


// Class AIModule.NavLocalGridManager
// 0x0030 (0x0058 - 0x0028)
class NavLocalGridManager : public Object_32759
{
public:
	unsigned char                                      UnknownData00[0x30];                                      // 0x0028(0x0030) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.NavLocalGridManager"));
		
		return ptr;
	}


	bool STATIC_SetLocalNavigationGridDensity(class Object_32759* WorldContextObject_69, float CellSize_69);
	void STATIC_RemoveLocalNavigationGrid(class Object_32759* WorldContextObject_69, int GridId_69, bool bRebuildGrids_69);
	bool STATIC_FindLocalNavigationGridPath(class Object_32759* WorldContextObject_69, const struct FVector& Start_69, const struct FVector& End_69, TArray<struct FVector>* PathPoints_69);
	int STATIC_AddLocalNavigationGridForPoints(class Object_32759* WorldContextObject_69, TArray<struct FVector> Locations_69, int Radius2D_69, float Height_69, bool bRebuildGrids_69);
	int STATIC_AddLocalNavigationGridForPoint(class Object_32759* WorldContextObject_69, const struct FVector& Location_69, int Radius2D_69, float Height_69, bool bRebuildGrids_69);
	int STATIC_AddLocalNavigationGridForCapsule(class Object_32759* WorldContextObject_69, const struct FVector& Location_69, float CapsuleRadius_69, float CapsuleHalfHeight_69, int Radius2D_69, float Height_69, bool bRebuildGrids_69);
	int STATIC_AddLocalNavigationGridForBox(class Object_32759* WorldContextObject_69, const struct FVector& Location_69, const struct FVector& Extent_69, const struct FRotator& Rotation_69, int Radius2D_69, float Height_69, bool bRebuildGrids_69);
};


// Class AIModule.PathFollowingManager
// 0x0000 (0x0028 - 0x0028)
class PathFollowingManager : public Object_32759
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.PathFollowingManager"));
		
		return ptr;
	}

};


// Class AIModule.AIPerceptionComponent
// 0x00D8 (0x0178 - 0x00A0)
class AIPerceptionComponent : public ActorComponent
{
public:
	TArray<class AISenseConfig*>                       SensesConfig_69;                                          // 0x00A0(0x0010) (Edit, ExportObject, ZeroConstructor, DisableEditOnInstance)
	class AISense*                                     DominantSense_69;                                         // 0x00B0(0x0008) (Edit, ZeroConstructor, DisableEditOnInstance)
	unsigned char                                      UnknownData00[0x8];                                       // 0x00B8(0x0008) MISSED OFFSET
	class AIController*                                AIOwner_69;                                               // 0x00C0(0x0008) (ZeroConstructor, Transient)
	unsigned char                                      UnknownData01[0x80];                                      // 0x00C8(0x0080) MISSED OFFSET
	unsigned char                                      UnknownData02[0x10];                                      // 0x00C8(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty AIModule.AIPerceptionComponent.OnPerceptionUpdated_69
	unsigned char                                      UnknownData03[0x10];                                      // 0x0158(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty AIModule.AIPerceptionComponent.OnTargetPerceptionUpdated_69
	unsigned char                                      UnknownData04[0x10];                                      // 0x0168(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty AIModule.AIPerceptionComponent.OnTargetPerceptionInfoUpdated_69

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.AIPerceptionComponent"));
		
		return ptr;
	}


	void SetSenseEnabled(class AISense* SenseClass_69, bool bEnable_69);
	void RequestStimuliListenerUpdate();
	void OnOwnerEndPlay(class Actor_32759* Actor_69, TEnumAsByte<EEndPlayReason> EndPlayReason_69);
	void GetPerceivedHostileActorsBySense(class AISense* SenseToUse_69, TArray<class Actor_32759*>* OutActors_69);
	void GetPerceivedHostileActors(TArray<class Actor_32759*>* OutActors_69);
	void GetPerceivedActors(class AISense* SenseToUse_69, TArray<class Actor_32759*>* OutActors_69);
	void GetKnownPerceivedActors(class AISense* SenseToUse_69, TArray<class Actor_32759*>* OutActors_69);
	void GetCurrentlyPerceivedActors(class AISense* SenseToUse_69, TArray<class Actor_32759*>* OutActors_69);
	bool GetActorsPerception(class Actor_32759* Actor_69, struct FActorPerceptionBlueprintInfo* Info_69);
	void ForgetAll();
};


// Class AIModule.AIPerceptionListenerInterface
// 0x0000 (0x0028 - 0x0028)
class AIPerceptionListenerInterface : public Interface
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.AIPerceptionListenerInterface"));
		
		return ptr;
	}

};


// Class AIModule.AIPerceptionStimuliSourceComponent
// 0x0018 (0x00B8 - 0x00A0)
class AIPerceptionStimuliSourceComponent : public ActorComponent
{
public:
	unsigned char                                      bAutoRegisterAsSource_69 : 1;                             // 0x00A0(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, Config)
	unsigned char                                      UnknownData00[0x7];                                       // 0x00A1(0x0007) MISSED OFFSET
	TArray<class AISense*>                             RegisterAsSourceForSenses_69;                             // 0x00A8(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.AIPerceptionStimuliSourceComponent"));
		
		return ptr;
	}


	void UnregisterFromSense(class AISense* SenseClass_69);
	void UnregisterFromPerceptionSystem();
	void RegisterWithPerceptionSystem();
	void RegisterForSense(class AISense* SenseClass_69);
};


// Class AIModule.AIPerceptionSystem
// 0x00F0 (0x0128 - 0x0038)
class AIPerceptionSystem : public AISubsystem
{
public:
	unsigned char                                      UnknownData00[0x50];                                      // 0x0038(0x0050) MISSED OFFSET
	TArray<class AISense*>                             Senses_69;                                                // 0x0088(0x0010) (ZeroConstructor)
	float                                              PerceptionAgingRate_69;                                   // 0x0098(0x0004) (Edit, ZeroConstructor, Config, IsPlainOldData)
	unsigned char                                      UnknownData01[0x8C];                                      // 0x009C(0x008C) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.AIPerceptionSystem"));
		
		return ptr;
	}


	void STATIC_ReportPerceptionEvent(class Object_32759* WorldContextObject_69, class AISenseEvent* PerceptionEvent_69);
	void ReportEvent(class AISenseEvent* PerceptionEvent_69);
	bool STATIC_RegisterPerceptionStimuliSource(class Object_32759* WorldContextObject_69, class AISense* Sense_69, class Actor_32759* Target_69);
	void OnPerceptionStimuliSourceEndPlay(class Actor_32759* Actor_69, TEnumAsByte<EEndPlayReason> EndPlayReason_69);
	class AISense* STATIC_GetSenseClassForStimulus(class Object_32759* WorldContextObject_69, const struct FAIStimulus& Stimulus_69);
};


// Class AIModule.AISense
// 0x0058 (0x0080 - 0x0028)
class AISense : public Object_32759
{
public:
	float                                              DefaultExpirationAge_69;                                  // 0x0028(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, Config, EditConst, IsPlainOldData)
	EAISenseNotifyType                                 NotifyType_69;                                            // 0x002C(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, Config, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x002D(0x0003) MISSED OFFSET
	unsigned char                                      bWantsNewPawnNotification_69 : 1;                         // 0x0030(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, Config, DisableEditOnInstance)
	unsigned char                                      bAutoRegisterAllPawnsAsSources_69 : 1;                    // 0x0030(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, Config, DisableEditOnInstance)
	unsigned char                                      UnknownData01[0x7];                                       // 0x0031(0x0007) MISSED OFFSET
	class AIPerceptionSystem*                          PerceptionSystemInstance_69;                              // 0x0038(0x0008) (ZeroConstructor)
	unsigned char                                      UnknownData02[0x40];                                      // 0x0040(0x0040) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.AISense"));
		
		return ptr;
	}

};


// Class AIModule.AISenseConfig_Damage
// 0x0008 (0x0050 - 0x0048)
class AISenseConfig_Damage : public AISenseConfig
{
public:
	class AISense_Damage*                              Implementation_69;                                        // 0x0048(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, Config, DisableEditOnInstance, NoClear)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.AISenseConfig_Damage"));
		
		return ptr;
	}

};


// Class AIModule.AISense_Blueprint
// 0x0028 (0x00A8 - 0x0080)
class AISense_Blueprint : public AISense
{
public:
	class UserDefinedStruct*                           ListenerDataType_69;                                      // 0x0080(0x0008) (Edit, BlueprintVisible, ZeroConstructor)
	TArray<class AIPerceptionComponent*>               ListenerContainer_69;                                     // 0x0088(0x0010) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor)
	TArray<class AISenseEvent*>                        UnprocessedEvents_69;                                     // 0x0098(0x0010) (ZeroConstructor)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.AISense_Blueprint"));
		
		return ptr;
	}


	float OnUpdate(TArray<class AISenseEvent*> EventsToProcess_69);
	void OnListenerUpdated(class Actor_32759* ActorListener_69, class AIPerceptionComponent* PerceptionComponent_69);
	void OnListenerUnregistered(class Actor_32759* ActorListener_69, class AIPerceptionComponent* PerceptionComponent_69);
	void OnListenerRegistered(class Actor_32759* ActorListener_69, class AIPerceptionComponent* PerceptionComponent_69);
	void K2_OnNewPawn(class Pawn* NewPawn_69);
	void GetAllListenerComponents(TArray<class AIPerceptionComponent*>* ListenerComponents_69);
	void GetAllListenerActors(TArray<class Actor_32759*>* ListenerActors_69);
};


// Class AIModule.AISense_Damage
// 0x0010 (0x0090 - 0x0080)
class AISense_Damage : public AISense
{
public:
	TArray<struct FAIDamageEvent>                      RegisteredEvents_69;                                      // 0x0080(0x0010) (ZeroConstructor)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.AISense_Damage"));
		
		return ptr;
	}


	void STATIC_ReportDamageEvent(class Object_32759* WorldContextObject_69, class Actor_32759* DamagedActor_69, class Actor_32759* Instigator_69, float DamageAmount_69, const struct FVector& EventLocation_69, const struct FVector& HitLocation_69, const struct FName& tag_69);
};


// Class AIModule.AISense_Hearing
// 0x0068 (0x00E8 - 0x0080)
class AISense_Hearing : public AISense
{
public:
	TArray<struct FAINoiseEvent>                       NoiseEvents_69;                                           // 0x0080(0x0010) (ZeroConstructor)
	float                                              SpeedOfSoundSq_69;                                        // 0x0090(0x0004) (ZeroConstructor, Config, IsPlainOldData)
	unsigned char                                      UnknownData00[0x54];                                      // 0x0094(0x0054) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.AISense_Hearing"));
		
		return ptr;
	}


	void STATIC_ReportNoiseEvent(class Object_32759* WorldContextObject_69, const struct FVector& NoiseLocation_69, float Loudness_69, class Actor_32759* Instigator_69, float MaxRange_69, const struct FName& tag_69);
};


// Class AIModule.AISense_Prediction
// 0x0010 (0x0090 - 0x0080)
class AISense_Prediction : public AISense
{
public:
	TArray<struct FAIPredictionEvent>                  RegisteredEvents_69;                                      // 0x0080(0x0010) (ZeroConstructor)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.AISense_Prediction"));
		
		return ptr;
	}


	void STATIC_RequestPawnPredictionEvent(class Pawn* Requestor_69, class Actor_32759* PredictedActor_69, float PredictionTime_69);
	void STATIC_RequestControllerPredictionEvent(class AIController* Requestor_69, class Actor_32759* PredictedActor_69, float PredictionTime_69);
};


// Class AIModule.AISense_Sight
// 0x00F0 (0x0170 - 0x0080)
class AISense_Sight : public AISense
{
public:
	unsigned char                                      UnknownData00[0xC8];                                      // 0x0080(0x00C8) MISSED OFFSET
	int                                                MaxTracesPerTick_69;                                      // 0x0148(0x0004) (Edit, ZeroConstructor, Config, DisableEditOnInstance, IsPlainOldData)
	int                                                MinQueriesPerTimeSliceCheck_69;                           // 0x014C(0x0004) (Edit, ZeroConstructor, Config, DisableEditOnInstance, IsPlainOldData)
	double                                             MaxTimeSlicePerTick_69;                                   // 0x0150(0x0008) (Edit, ZeroConstructor, Config, DisableEditOnInstance, IsPlainOldData)
	float                                              HighImportanceQueryDistanceThreshold_69;                  // 0x0158(0x0004) (Edit, ZeroConstructor, Config, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData01[0x4];                                       // 0x015C(0x0004) MISSED OFFSET
	float                                              MaxQueryImportance_69;                                    // 0x0160(0x0004) (Edit, ZeroConstructor, Config, DisableEditOnInstance, IsPlainOldData)
	float                                              SightLimitQueryImportance_69;                             // 0x0164(0x0004) (Edit, ZeroConstructor, Config, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData02[0x8];                                       // 0x0168(0x0008) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.AISense_Sight"));
		
		return ptr;
	}

};


// Class AIModule.AISense_Team
// 0x0010 (0x0090 - 0x0080)
class AISense_Team : public AISense
{
public:
	TArray<struct FAITeamStimulusEvent>                RegisteredEvents_69;                                      // 0x0080(0x0010) (ZeroConstructor)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.AISense_Team"));
		
		return ptr;
	}

};


// Class AIModule.AISense_Touch
// 0x0010 (0x0090 - 0x0080)
class AISense_Touch : public AISense
{
public:
	TArray<struct FAITouchEvent>                       RegisteredEvents_69;                                      // 0x0080(0x0010) (ZeroConstructor)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.AISense_Touch"));
		
		return ptr;
	}


	void STATIC_ReportTouchEvent(class Object_32759* WorldContextObject_69, class Actor_32759* TouchReceiver_69, class Actor_32759* OtherActor_69, const struct FVector& Location_69);
};


// Class AIModule.AISightTargetInterface
// 0x0000 (0x0028 - 0x0028)
class AISightTargetInterface : public Interface
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.AISightTargetInterface"));
		
		return ptr;
	}

};


// Class AIModule.PawnSensingComponent
// 0x0048 (0x00E8 - 0x00A0)
class PawnSensingComponent : public ActorComponent
{
public:
	float                                              HearingThreshold_69;                                      // 0x00A0(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              LOSHearingThreshold_69;                                   // 0x00A4(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              SightRadius_69;                                           // 0x00A8(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              SensingInterval_69;                                       // 0x00AC(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              HearingMaxSoundAge_69;                                    // 0x00B0(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      bEnableSensingUpdates_69 : 1;                             // 0x00B4(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly)
	unsigned char                                      bOnlySensePlayers_69 : 1;                                 // 0x00B4(0x0001) (Edit, BlueprintVisible)
	unsigned char                                      bSeePawns_69 : 1;                                         // 0x00B4(0x0001) (Edit, BlueprintVisible)
	unsigned char                                      bHearNoises_69 : 1;                                       // 0x00B4(0x0001) (Edit, BlueprintVisible)
	unsigned char                                      UnknownData00[0xB];                                       // 0x00B5(0x000B) MISSED OFFSET
	unsigned char                                      UnknownData01[0x10];                                      // 0x00B5(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty AIModule.PawnSensingComponent.OnSeePawn_69
	unsigned char                                      UnknownData02[0x10];                                      // 0x00D0(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty AIModule.PawnSensingComponent.OnHearNoise_69
	float                                              PeripheralVisionAngle_69;                                 // 0x00E0(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              PeripheralVisionCosine_69;                                // 0x00E4(0x0004) (ZeroConstructor, IsPlainOldData)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.PawnSensingComponent"));
		
		return ptr;
	}


	void SetSensingUpdatesEnabled(bool bEnabled_69);
	void SetSensingInterval(float NewSensingInterval_69);
	void SetPeripheralVisionAngle(float NewPeripheralVisionAngle_69);
	void SeePawnDelegate__DelegateSignature(class Pawn* Pawn_69);
	void HearNoiseDelegate__DelegateSignature(class Pawn* Instigator_69, const struct FVector& Location_69, float Volume_69);
	float GetPeripheralVisionCosine();
	float GetPeripheralVisionAngle();
};


// Class AIModule.AITask_LockLogic
// 0x0000 (0x0068 - 0x0068)
class AITask_LockLogic : public AITask
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.AITask_LockLogic"));
		
		return ptr;
	}

};


// Class AIModule.AITask_RunEQS
// 0x0078 (0x00E0 - 0x0068)
class AITask_RunEQS : public AITask
{
public:
	unsigned char                                      UnknownData00[0x78];                                      // 0x0068(0x0078) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.AITask_RunEQS"));
		
		return ptr;
	}


	class AITask_RunEQS* STATIC_RunEQS(class AIController* Controller_69, class EnvQuery* QueryTemplate_69);
};


// Class AIModule.VisualLoggerExtension
// 0x0000 (0x0028 - 0x0028)
class VisualLoggerExtension : public Object_32759
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AIModule.VisualLoggerExtension"));
		
		return ptr;
	}

};


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

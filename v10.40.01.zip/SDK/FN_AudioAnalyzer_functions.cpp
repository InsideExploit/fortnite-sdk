// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Functions
//---------------------------------------------------------------------------

// Function AudioAnalyzer.AudioAnalyzer.StopAnalyzing
// (Final, BlueprintCosmetic, Native, Public, BlueprintCallable)
// Parameters:
// class Object_32759*            WorldContextObject_69          (ConstParm, Parm, ZeroConstructor)

void AudioAnalyzer::StopAnalyzing(class Object_32759* WorldContextObject_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioAnalyzer.AudioAnalyzer.StopAnalyzing"));

	AudioAnalyzer_StopAnalyzing_Params params;
	params.WorldContextObject_69 = WorldContextObject_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AudioAnalyzer.AudioAnalyzer.StartAnalyzing
// (Final, BlueprintCosmetic, Native, Public, BlueprintCallable)
// Parameters:
// class Object_32759*            WorldContextObject_69          (ConstParm, Parm, ZeroConstructor)
// class AudioBus*                AudioBusToAnalyze_69           (Parm, ZeroConstructor)

void AudioAnalyzer::StartAnalyzing(class Object_32759* WorldContextObject_69, class AudioBus* AudioBusToAnalyze_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioAnalyzer.AudioAnalyzer.StartAnalyzing"));

	AudioAnalyzer_StartAnalyzing_Params params;
	params.WorldContextObject_69 = WorldContextObject_69;
	params.AudioBusToAnalyze_69 = AudioBusToAnalyze_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

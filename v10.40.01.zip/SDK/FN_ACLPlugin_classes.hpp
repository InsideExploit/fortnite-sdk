#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Classes
//---------------------------------------------------------------------------

// Class ACLPlugin.AnimationCompressionLibraryDatabase
// 0x0138 (0x0160 - 0x0028)
class AnimationCompressionLibraryDatabase : public Object_32759
{
public:
	TArray<unsigned char>                              CookedCompressedBytes_69;                                 // 0x0028(0x0010) (ZeroConstructor)
	TArray<uint64_t>                                   CookedAnimSequenceMappings_69;                            // 0x0038(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData00[0x110];                                     // 0x0048(0x0110) MISSED OFFSET
	uint32_t                                           MaxStreamRequestSizeKB_69;                                // 0x0158(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x4];                                       // 0x015C(0x0004) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class ACLPlugin.AnimationCompressionLibraryDatabase"));
		
		return ptr;
	}


	void STATIC_SetVisualFidelity(class Object_32759* WorldContextObject_69, const struct FLatentActionInfo& LatentInfo_69, class AnimationCompressionLibraryDatabase* DatabaseAsset_69, EACLVisualFidelity VisualFidelity_69, EACLVisualFidelityChangeResult* Result_69);
	EACLVisualFidelity STATIC_GetVisualFidelity(class AnimationCompressionLibraryDatabase* DatabaseAsset_69);
};


// Class ACLPlugin.AnimBoneCompressionCodec_ACLBase
// 0x0000 (0x0038 - 0x0038)
class AnimBoneCompressionCodec_ACLBase : public AnimBoneCompressionCodec
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class ACLPlugin.AnimBoneCompressionCodec_ACLBase"));
		
		return ptr;
	}

};


// Class ACLPlugin.AnimBoneCompressionCodec_ACL
// 0x0008 (0x0040 - 0x0038)
class AnimBoneCompressionCodec_ACL : public AnimBoneCompressionCodec_ACLBase
{
public:
	class AnimBoneCompressionCodec*                    SafetyFallbackCodec_69;                                   // 0x0038(0x0008) (Edit, ExportObject, ZeroConstructor, InstancedReference)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class ACLPlugin.AnimBoneCompressionCodec_ACL"));
		
		return ptr;
	}

};


// Class ACLPlugin.AnimBoneCompressionCodec_ACLCustom
// 0x0000 (0x0038 - 0x0038)
class AnimBoneCompressionCodec_ACLCustom : public AnimBoneCompressionCodec_ACLBase
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class ACLPlugin.AnimBoneCompressionCodec_ACLCustom"));
		
		return ptr;
	}

};


// Class ACLPlugin.AnimBoneCompressionCodec_ACLDatabase
// 0x0008 (0x0040 - 0x0038)
class AnimBoneCompressionCodec_ACLDatabase : public AnimBoneCompressionCodec_ACLBase
{
public:
	class AnimationCompressionLibraryDatabase*         DatabaseAsset_69;                                         // 0x0038(0x0008) (Edit, ZeroConstructor)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class ACLPlugin.AnimBoneCompressionCodec_ACLDatabase"));
		
		return ptr;
	}

};


// Class ACLPlugin.AnimBoneCompressionCodec_ACLSafe
// 0x0000 (0x0038 - 0x0038)
class AnimBoneCompressionCodec_ACLSafe : public AnimBoneCompressionCodec_ACLBase
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class ACLPlugin.AnimBoneCompressionCodec_ACLSafe"));
		
		return ptr;
	}

};


// Class ACLPlugin.AnimCurveCompressionCodec_ACL
// 0x0000 (0x0028 - 0x0028)
class AnimCurveCompressionCodec_ACL : public AnimCurveCompressionCodec
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class ACLPlugin.AnimCurveCompressionCodec_ACL"));
		
		return ptr;
	}

};


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

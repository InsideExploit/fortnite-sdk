#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Script Structs
//---------------------------------------------------------------------------

// UserDefinedStruct CharacterPartMidArrayStruct.CharacterPartMidArrayStruct
// 0x0018
struct FCharacterPartMidArrayStruct
{
	TEnumAsByte<EFortCustomPartType>                   PartType_5_EBDFFF5740627902CC51DD966B8EE419_2097153;      // 0x0000(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0001(0x0007) MISSED OFFSET
	TArray<class MaterialInstanceDynamic*>             MID_7_A0D19AC74319389A5DF2019166F976F0_2097153;           // 0x0008(0x0010) (Edit, BlueprintVisible)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

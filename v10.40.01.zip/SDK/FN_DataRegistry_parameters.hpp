#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function DataRegistry.DataRegistrySubsystem.NotEqual_DataRegistryType
struct DataRegistrySubsystem_NotEqual_DataRegistryType_Params
{
	struct FDataRegistryType                           A_69;                                                     // (Parm, ZeroConstructor)
	struct FDataRegistryType                           B_69;                                                     // (Parm, ZeroConstructor)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function DataRegistry.DataRegistrySubsystem.NotEqual_DataRegistryId
struct DataRegistrySubsystem_NotEqual_DataRegistryId_Params
{
	struct FDataRegistryId                             A_69;                                                     // (Parm, ZeroConstructor)
	struct FDataRegistryId                             B_69;                                                     // (Parm, ZeroConstructor)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function DataRegistry.DataRegistrySubsystem.IsValidDataRegistryType
struct DataRegistrySubsystem_IsValidDataRegistryType_Params
{
	struct FDataRegistryType                           DataRegistryType_69;                                      // (Parm, ZeroConstructor)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function DataRegistry.DataRegistrySubsystem.IsValidDataRegistryId
struct DataRegistrySubsystem_IsValidDataRegistryId_Params
{
	struct FDataRegistryId                             DataRegistryId_69;                                        // (Parm, ZeroConstructor)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function DataRegistry.DataRegistrySubsystem.GetCachedItemFromLookupBP
struct DataRegistrySubsystem_GetCachedItemFromLookupBP_Params
{
	struct FDataRegistryId                             ItemId_69;                                                // (Parm, ZeroConstructor)
	struct FDataRegistryLookup                         ResolvedLookup_69;                                        // (ConstParm, Parm, OutParm, ReferenceParm)
	struct FTableRowBase                               OutItem_69;                                               // (Parm, OutParm)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function DataRegistry.DataRegistrySubsystem.GetCachedItemBP
struct DataRegistrySubsystem_GetCachedItemBP_Params
{
	struct FDataRegistryId                             ItemId_69;                                                // (Parm, ZeroConstructor)
	struct FTableRowBase                               OutItem_69;                                               // (Parm, OutParm, ReferenceParm)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function DataRegistry.DataRegistrySubsystem.FindCachedItemBP
struct DataRegistrySubsystem_FindCachedItemBP_Params
{
	struct FDataRegistryId                             ItemId_69;                                                // (Parm, ZeroConstructor)
	EDataRegistrySubsystemGetItemResult                OutResult_69;                                             // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	struct FTableRowBase                               OutItem_69;                                               // (Parm, OutParm)
};

// Function DataRegistry.DataRegistrySubsystem.EvaluateDataRegistryCurve
struct DataRegistrySubsystem_EvaluateDataRegistryCurve_Params
{
	struct FDataRegistryId                             ItemId_69;                                                // (Parm, ZeroConstructor)
	float                                              InputValue_69;                                            // (Parm, ZeroConstructor, IsPlainOldData)
	float                                              DefaultValue_69;                                          // (Parm, ZeroConstructor, IsPlainOldData)
	EDataRegistrySubsystemGetItemResult                OutResult_69;                                             // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	float                                              OutValue_69;                                              // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
};

// Function DataRegistry.DataRegistrySubsystem.EqualEqual_DataRegistryType
struct DataRegistrySubsystem_EqualEqual_DataRegistryType_Params
{
	struct FDataRegistryType                           A_69;                                                     // (Parm, ZeroConstructor)
	struct FDataRegistryType                           B_69;                                                     // (Parm, ZeroConstructor)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function DataRegistry.DataRegistrySubsystem.EqualEqual_DataRegistryId
struct DataRegistrySubsystem_EqualEqual_DataRegistryId_Params
{
	struct FDataRegistryId                             A_69;                                                     // (Parm, ZeroConstructor)
	struct FDataRegistryId                             B_69;                                                     // (Parm, ZeroConstructor)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function DataRegistry.DataRegistrySubsystem.Conv_DataRegistryTypeToString
struct DataRegistrySubsystem_Conv_DataRegistryTypeToString_Params
{
	struct FDataRegistryType                           DataRegistryType_69;                                      // (Parm, ZeroConstructor)
	struct FString                                     ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function DataRegistry.DataRegistrySubsystem.Conv_DataRegistryIdToString
struct DataRegistrySubsystem_Conv_DataRegistryIdToString_Params
{
	struct FDataRegistryId                             DataRegistryId_69;                                        // (Parm, ZeroConstructor)
	struct FString                                     ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function DataRegistry.DataRegistrySubsystem.AcquireItemBP
struct DataRegistrySubsystem_AcquireItemBP_Params
{
	struct FDataRegistryId                             ItemId_69;                                                // (Parm, ZeroConstructor)
	struct FScriptDelegate                             AcquireCallback_69;                                       // (Parm, ZeroConstructor)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

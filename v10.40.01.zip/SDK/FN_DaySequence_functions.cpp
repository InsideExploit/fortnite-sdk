// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Functions
//---------------------------------------------------------------------------

// Function DaySequence.DaySequenceActor.SetTimeOfDay
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// float                          InHours_69                     (Parm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool DaySequenceActor::SetTimeOfDay(float InHours_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DaySequence.DaySequenceActor.SetTimeOfDay"));

	DaySequenceActor_SetTimeOfDay_Params params;
	params.InHours_69 = InHours_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function DaySequence.DaySequenceActor.SetReplicatePlayback
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// bool                           ReplicatePlayback_69           (Parm, ZeroConstructor, IsPlainOldData)

void DaySequenceActor::SetReplicatePlayback(bool ReplicatePlayback_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DaySequence.DaySequenceActor.SetReplicatePlayback"));

	DaySequenceActor_SetReplicatePlayback_Params params;
	params.ReplicatePlayback_69 = ReplicatePlayback_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function DaySequence.DaySequenceActor.SetDaySequence
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// int                            Index_69                       (Parm, ZeroConstructor, IsPlainOldData)
// class DaySequence*             InSequence_69                  (Parm, ZeroConstructor)

void DaySequenceActor::SetDaySequence(int Index_69, class DaySequence* InSequence_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DaySequence.DaySequenceActor.SetDaySequence"));

	DaySequenceActor_SetDaySequence_Params params;
	params.Index_69 = Index_69;
	params.InSequence_69 = InSequence_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function DaySequence.DaySequenceActor.SetBias
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// struct FString                 SequenceKey_69                 (Parm, ZeroConstructor)
// int                            Bias_69                        (Parm, ZeroConstructor, IsPlainOldData)

void DaySequenceActor::SetBias(const struct FString& SequenceKey_69, int Bias_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DaySequence.DaySequenceActor.SetBias"));

	DaySequenceActor_SetBias_Params params;
	params.SequenceKey_69 = SequenceKey_69;
	params.Bias_69 = Bias_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function DaySequence.DaySequenceActor.RemoveDaySequence
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// int                            Index_69                       (Parm, ZeroConstructor, IsPlainOldData)

void DaySequenceActor::RemoveDaySequence(int Index_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DaySequence.DaySequenceActor.RemoveDaySequence"));

	DaySequenceActor_RemoveDaySequence_Params params;
	params.Index_69 = Index_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function DaySequence.DaySequenceActor.Play
// (Final, Native, Public, BlueprintCallable)

void DaySequenceActor::Play()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DaySequence.DaySequenceActor.Play"));

	DaySequenceActor_Play_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function DaySequence.DaySequenceActor.Pause
// (Final, Native, Public, BlueprintCallable)

void DaySequenceActor::Pause()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DaySequence.DaySequenceActor.Pause"));

	DaySequenceActor_Pause_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function DaySequence.DaySequenceActor.NumDaySequences
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// int                            ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int DaySequenceActor::NumDaySequences()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DaySequence.DaySequenceActor.NumDaySequences"));

	DaySequenceActor_NumDaySequences_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function DaySequence.DaySequenceActor.MuteSequence
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// struct FString                 SequenceKey_69                 (Parm, ZeroConstructor)
// bool                           bState_69                      (Parm, ZeroConstructor, IsPlainOldData)

void DaySequenceActor::MuteSequence(const struct FString& SequenceKey_69, bool bState_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DaySequence.DaySequenceActor.MuteSequence"));

	DaySequenceActor_MuteSequence_Params params;
	params.SequenceKey_69 = SequenceKey_69;
	params.bState_69 = bState_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function DaySequence.DaySequenceActor.IsPlaying
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool DaySequenceActor::IsPlaying()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DaySequence.DaySequenceActor.IsPlaying"));

	DaySequenceActor_IsPlaying_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function DaySequence.DaySequenceActor.IsPaused
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool DaySequenceActor::IsPaused()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DaySequence.DaySequenceActor.IsPaused"));

	DaySequenceActor_IsPaused_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function DaySequence.DaySequenceActor.IsMuteSequence
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// struct FString                 SequenceKey_69                 (Parm, ZeroConstructor)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool DaySequenceActor::IsMuteSequence(const struct FString& SequenceKey_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DaySequence.DaySequenceActor.IsMuteSequence"));

	DaySequenceActor_IsMuteSequence_Params params;
	params.SequenceKey_69 = SequenceKey_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function DaySequence.DaySequenceActor.GetTimePerCycle
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// float                          ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

float DaySequenceActor::GetTimePerCycle()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DaySequence.DaySequenceActor.GetTimePerCycle"));

	DaySequenceActor_GetTimePerCycle_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function DaySequence.DaySequenceActor.GetTimeOfDay
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// float                          ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

float DaySequenceActor::GetTimeOfDay()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DaySequence.DaySequenceActor.GetTimeOfDay"));

	DaySequenceActor_GetTimeOfDay_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function DaySequence.DaySequenceActor.GetSequencePlayer
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// class DaySequencePlayer*       ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

class DaySequencePlayer* DaySequenceActor::GetSequencePlayer()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DaySequence.DaySequenceActor.GetSequencePlayer"));

	DaySequenceActor_GetSequencePlayer_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function DaySequence.DaySequenceActor.GetInitialTimeOfDay
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// float                          ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

float DaySequenceActor::GetInitialTimeOfDay()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DaySequence.DaySequenceActor.GetInitialTimeOfDay"));

	DaySequenceActor_GetInitialTimeOfDay_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function DaySequence.DaySequenceActor.GetFirstDaySequence
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// class DaySequence*             ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

class DaySequence* DaySequenceActor::GetFirstDaySequence()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DaySequence.DaySequenceActor.GetFirstDaySequence"));

	DaySequenceActor_GetFirstDaySequence_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function DaySequence.DaySequenceActor.GetDaySequence
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// int                            Index_69                       (Parm, ZeroConstructor, IsPlainOldData)
// class DaySequence*             ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

class DaySequence* DaySequenceActor::GetDaySequence(int Index_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DaySequence.DaySequenceActor.GetDaySequence"));

	DaySequenceActor_GetDaySequence_Params params;
	params.Index_69 = Index_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function DaySequence.DaySequenceActor.GetDayLength
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// float                          ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

float DaySequenceActor::GetDayLength()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DaySequence.DaySequenceActor.GetDayLength"));

	DaySequenceActor_GetDayLength_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function DaySequence.DaySequenceActor.GetBias
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// struct FString                 SequenceKey_69                 (Parm, ZeroConstructor)
// int                            ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int DaySequenceActor::GetBias(const struct FString& SequenceKey_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DaySequence.DaySequenceActor.GetBias"));

	DaySequenceActor_GetBias_Params params;
	params.SequenceKey_69 = SequenceKey_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function DaySequence.DaySequenceActor.AddDaySequence
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// class DaySequence*             InSequence_69                  (Parm, ZeroConstructor)
// int                            ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int DaySequenceActor::AddDaySequence(class DaySequence* InSequence_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DaySequence.DaySequenceActor.AddDaySequence"));

	DaySequenceActor_AddDaySequence_Params params;
	params.InSequence_69 = InSequence_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function DaySequence.DaySequenceDirector.OnCreated
// (Event, Public, BlueprintEvent)

void DaySequenceDirector::OnCreated()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DaySequence.DaySequenceDirector.OnCreated"));

	DaySequenceDirector_OnCreated_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function DaySequence.DaySequenceDirector.GetSequence
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// class MovieSceneSequence*      ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

class MovieSceneSequence* DaySequenceDirector::GetSequence()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DaySequence.DaySequenceDirector.GetSequence"));

	DaySequenceDirector_GetSequence_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function DaySequence.DaySequenceDirector.GetMasterSequenceTime
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FQualifiedFrameTime     ReturnValue_69                 (Parm, OutParm, ReturnParm)

struct FQualifiedFrameTime DaySequenceDirector::GetMasterSequenceTime()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DaySequence.DaySequenceDirector.GetMasterSequenceTime"));

	DaySequenceDirector_GetMasterSequenceTime_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function DaySequence.DaySequenceDirector.GetCurrentTime
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FQualifiedFrameTime     ReturnValue_69                 (Parm, OutParm, ReturnParm)

struct FQualifiedFrameTime DaySequenceDirector::GetCurrentTime()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DaySequence.DaySequenceDirector.GetCurrentTime"));

	DaySequenceDirector_GetCurrentTime_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function DaySequence.DaySequenceDirector.GetBoundObjects
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// struct FMovieSceneObjectBindingID ObjectBinding_69               (Parm)
// TArray<class Object_32759*>    ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

TArray<class Object_32759*> DaySequenceDirector::GetBoundObjects(const struct FMovieSceneObjectBindingID& ObjectBinding_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DaySequence.DaySequenceDirector.GetBoundObjects"));

	DaySequenceDirector_GetBoundObjects_Params params;
	params.ObjectBinding_69 = ObjectBinding_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function DaySequence.DaySequenceDirector.GetBoundObject
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// struct FMovieSceneObjectBindingID ObjectBinding_69               (Parm)
// class Object_32759*            ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

class Object_32759* DaySequenceDirector::GetBoundObject(const struct FMovieSceneObjectBindingID& ObjectBinding_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DaySequence.DaySequenceDirector.GetBoundObject"));

	DaySequenceDirector_GetBoundObject_Params params;
	params.ObjectBinding_69 = ObjectBinding_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function DaySequence.DaySequenceDirector.GetBoundActors
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// struct FMovieSceneObjectBindingID ObjectBinding_69               (Parm)
// TArray<class Actor_32759*>     ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

TArray<class Actor_32759*> DaySequenceDirector::GetBoundActors(const struct FMovieSceneObjectBindingID& ObjectBinding_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DaySequence.DaySequenceDirector.GetBoundActors"));

	DaySequenceDirector_GetBoundActors_Params params;
	params.ObjectBinding_69 = ObjectBinding_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function DaySequence.DaySequenceDirector.GetBoundActor
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// struct FMovieSceneObjectBindingID ObjectBinding_69               (Parm)
// class Actor_32759*             ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

class Actor_32759* DaySequenceDirector::GetBoundActor(const struct FMovieSceneObjectBindingID& ObjectBinding_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DaySequence.DaySequenceDirector.GetBoundActor"));

	DaySequenceDirector_GetBoundActor_Params params;
	params.ObjectBinding_69 = ObjectBinding_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function DaySequence.DaySequencePlayer.CreateDaySequencePlayer
// (Final, Native, Static, Public, HasOutParms, BlueprintCallable)
// Parameters:
// class Object_32759*            WorldContextObject_69          (Parm, ZeroConstructor)
// class DaySequence*             InDaySequence_69               (Parm, ZeroConstructor)
// struct FMovieSceneSequencePlaybackSettings Settings_69                    (Parm)
// class DaySequenceActor*        OutActor_69                    (Parm, OutParm, ZeroConstructor)
// class DaySequencePlayer*       ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

class DaySequencePlayer* DaySequencePlayer::STATIC_CreateDaySequencePlayer(class Object_32759* WorldContextObject_69, class DaySequence* InDaySequence_69, const struct FMovieSceneSequencePlaybackSettings& Settings_69, class DaySequenceActor** OutActor_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DaySequence.DaySequencePlayer.CreateDaySequencePlayer"));

	DaySequencePlayer_CreateDaySequencePlayer_Params params;
	params.WorldContextObject_69 = WorldContextObject_69;
	params.InDaySequence_69 = InDaySequence_69;
	params.Settings_69 = Settings_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (OutActor_69 != nullptr)
		*OutActor_69 = params.OutActor_69;

	return params.ReturnValue_69;
}


// Function DaySequence.DaySequenceSubsystem.GetDaySequenceActor
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// class DaySequenceActor*        ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

class DaySequenceActor* DaySequenceSubsystem::GetDaySequenceActor()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DaySequence.DaySequenceSubsystem.GetDaySequenceActor"));

	DaySequenceSubsystem_GetDaySequenceActor_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

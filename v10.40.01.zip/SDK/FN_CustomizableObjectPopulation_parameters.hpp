#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function CustomizableObjectPopulation.CustomizableObjectPopulation.RegeneratePopulation
struct CustomizableObjectPopulation_RegeneratePopulation_Params
{
	int                                                Seed_69;                                                  // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<class CustomizableObjectInstance*>          OutInstances_69;                                          // (Parm, OutParm, ZeroConstructor)
	int                                                NumInstancesToGenerate_69;                                // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CustomizableObjectPopulation.CustomizableObjectPopulation.GeneratePopulation
struct CustomizableObjectPopulation_GeneratePopulation_Params
{
	TArray<class CustomizableObjectInstance*>          OutInstances_69;                                          // (Parm, OutParm, ZeroConstructor)
	int                                                NumInstancesToGenerate_69;                                // (Parm, ZeroConstructor, IsPlainOldData)
	int                                                ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

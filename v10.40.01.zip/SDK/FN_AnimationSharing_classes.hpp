#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Classes
//---------------------------------------------------------------------------

// Class AnimationSharing.AnimationSharingStateProcessor
// 0x0028 (0x0050 - 0x0028)
class AnimationSharingStateProcessor : public Object_32759
{
public:
	unsigned char                                      UnknownData00[0x28];                                      // 0x0028(0x0028) UNKNOWN PROPERTY: SoftObjectProperty AnimationSharing.AnimationSharingStateProcessor.AnimationStateEnum_69

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AnimationSharing.AnimationSharingStateProcessor"));
		
		return ptr;
	}


	void ProcessActorState(class Actor_32759* InActor_69, unsigned char CurrentState_69, unsigned char OnDemandState_69, int* OutState_69, bool* bShouldProcess_69);
	class Enum* GetAnimationStateEnum();
};


// Class AnimationSharing.AnimSharingStateInstance
// 0x0020 (0x0370 - 0x0350)
class AnimSharingStateInstance : public AnimInstance
{
public:
	float                                              PermutationTimeOffset_69;                                 // 0x0350(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, Transient, DisableEditOnInstance, IsPlainOldData)
	float                                              PlayRate_69;                                              // 0x0354(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, Transient, DisableEditOnInstance, IsPlainOldData)
	bool                                               bStateBool_69;                                            // 0x0358(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, Transient, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0359(0x0007) MISSED OFFSET
	class AnimSharingInstance*                         Instance_69;                                              // 0x0360(0x0008) (ZeroConstructor, Transient)
	unsigned char                                      UnknownData01[0x8];                                       // 0x0368(0x0008) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AnimationSharing.AnimSharingStateInstance"));
		
		return ptr;
	}


	void GetInstancedActors(TArray<class Actor_32759*>* Actors_69);
};


// Class AnimationSharing.AnimSharingTransitionInstance
// 0x0010 (0x0360 - 0x0350)
class AnimSharingTransitionInstance : public AnimInstance
{
public:
	TWeakObjectPtr<class SkeletalMeshComponent>        ToComponent_69;                                           // 0x0350(0x0008) (Edit, BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, Transient, DisableEditOnInstance, InstancedReference, IsPlainOldData)
	float                                              BlendTime_69;                                             // 0x0358(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, Transient, DisableEditOnInstance, IsPlainOldData)
	bool                                               bBlendBool_69;                                            // 0x035C(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, Transient, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x035D(0x0003) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AnimationSharing.AnimSharingTransitionInstance"));
		
		return ptr;
	}

};


// Class AnimationSharing.AnimSharingAdditiveInstance
// 0x0010 (0x0360 - 0x0350)
class AnimSharingAdditiveInstance : public AnimInstance
{
public:
	TWeakObjectPtr<class AnimSequence>                 AdditiveAnimation_69;                                     // 0x0350(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, Transient, DisableEditOnInstance, IsPlainOldData)
	float                                              Alpha_69;                                                 // 0x0358(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, Transient, DisableEditOnInstance, IsPlainOldData)
	bool                                               bStateBool_69;                                            // 0x035C(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, Transient, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x035D(0x0003) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AnimationSharing.AnimSharingAdditiveInstance"));
		
		return ptr;
	}

};


// Class AnimationSharing.AnimSharingInstance
// 0x00F8 (0x0120 - 0x0028)
class AnimSharingInstance : public Object_32759
{
public:
	TArray<class Actor_32759*>                         RegisteredActors_69;                                      // 0x0028(0x0010) (Edit, ZeroConstructor, Transient, EditConst)
	unsigned char                                      UnknownData00[0x50];                                      // 0x0038(0x0050) MISSED OFFSET
	class AnimationSharingStateProcessor*              StateProcessor_69;                                        // 0x0088(0x0008) (Edit, ZeroConstructor, Transient)
	unsigned char                                      UnknownData01[0x38];                                      // 0x0090(0x0038) MISSED OFFSET
	TArray<class AnimSequence*>                        UsedAnimationSequences_69;                                // 0x00C8(0x0010) (Edit, ZeroConstructor, Transient, EditConst)
	unsigned char                                      UnknownData02[0x10];                                      // 0x00D8(0x0010) MISSED OFFSET
	class Enum*                                        StateEnum_69;                                             // 0x00E8(0x0008) (Edit, ZeroConstructor, Transient, EditConst)
	class Actor_32759*                                 SharingActor_69;                                          // 0x00F0(0x0008) (Edit, ZeroConstructor, Transient, EditConst)
	unsigned char                                      UnknownData03[0x28];                                      // 0x00F8(0x0028) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AnimationSharing.AnimSharingInstance"));
		
		return ptr;
	}

};


// Class AnimationSharing.AnimationSharingManager
// 0x0060 (0x0088 - 0x0028)
class AnimationSharingManager : public Object_32759
{
public:
	TArray<class Skeleton*>                            Skeletons_69;                                             // 0x0028(0x0010) (ZeroConstructor, Transient)
	TArray<class AnimSharingInstance*>                 PerSkeletonData_69;                                       // 0x0038(0x0010) (Edit, ZeroConstructor, Transient, EditConst)
	unsigned char                                      UnknownData00[0x40];                                      // 0x0048(0x0040) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AnimationSharing.AnimationSharingManager"));
		
		return ptr;
	}


	void RegisterActorWithSkeletonBP(class Actor_32759* InActor_69, class Skeleton* SharingSkeleton_69);
	class AnimationSharingManager* STATIC_GetAnimationSharingManager(class Object_32759* WorldContextObject_69);
	bool STATIC_CreateAnimationSharingManager(class Object_32759* WorldContextObject_69, class AnimationSharingSetup* Setup_69);
	bool STATIC_AnimationSharingEnabled();
};


// Class AnimationSharing.AnimationSharingSetup
// 0x0020 (0x0048 - 0x0028)
class AnimationSharingSetup : public Object_32759
{
public:
	TArray<struct FPerSkeletonAnimationSharingSetup>   SkeletonSetups_69;                                        // 0x0028(0x0010) (Edit, ZeroConstructor, Config)
	struct FAnimationSharingScalability                ScalabilitySettings_69;                                   // 0x0038(0x0010) (Edit, Config)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AnimationSharing.AnimationSharingSetup"));
		
		return ptr;
	}

};


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

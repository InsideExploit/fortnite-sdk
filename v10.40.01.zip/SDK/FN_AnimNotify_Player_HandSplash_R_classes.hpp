#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Classes
//---------------------------------------------------------------------------

// BlueprintGeneratedClass AnimNotify_Player_HandSplash_R.AnimNotify_Player_HandSplash_R_C
// 0x0000 (0x0038 - 0x0038)
class AnimNotify_Player_HandSplash_R_C : public AnimNotify
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("BlueprintGeneratedClass AnimNotify_Player_HandSplash_R.AnimNotify_Player_HandSplash_R_C"));
		
		return ptr;
	}


	bool Received_Notify(class SkeletalMeshComponent* MeshComp_1, class AnimSequenceBase* Animation_1, const struct FAnimNotifyEventReference& EventReference_1);
};


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Classes
//---------------------------------------------------------------------------

// Class ChromeGameplayRuntime.ChromeWaterBodyComponent
// 0x0008 (0x00A8 - 0x00A0)
class ChromeWaterBodyComponent : public ActorComponent
{
public:
	class MaterialInterface*                           ChromeWaterMaterialInterface_69;                          // 0x00A0(0x0008) (Edit, ZeroConstructor, DisableEditOnInstance)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class ChromeGameplayRuntime.ChromeWaterBodyComponent"));
		
		return ptr;
	}


	void ApplyChromeMaterialToOwner();
};


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Classes
//---------------------------------------------------------------------------

// Class CRDLevelInstanceRuntime.FortAthenaMutator_LevelInstanceDevice
// 0x0008 (0x0338 - 0x0330)
class FortAthenaMutator_LevelInstanceDevice : public FortAthenaMutator
{
public:
	class LevelInstanceGameplayVolume*                 CachedGameplayVolume_69;                                  // 0x0330(0x0008) (ZeroConstructor, Transient)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CRDLevelInstanceRuntime.FortAthenaMutator_LevelInstanceDevice"));
		
		return ptr;
	}

};


// Class CRDLevelInstanceRuntime.LevelInstanceGameplayVolume
// 0x0188 (0x0498 - 0x0310)
class LevelInstanceGameplayVolume : public GameplayVolume
{
public:
	unsigned char                                      UnknownData00[0x8];                                       // 0x0310(0x0008) MISSED OFFSET
	unsigned char                                      UnknownData01[0x10];                                      // 0x0310(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty CRDLevelInstanceRuntime.LevelInstanceGameplayVolume.OnLevelInstanceResolved_69
	unsigned char                                      UnknownData02[0x30];                                      // 0x0328(0x0030) MISSED OFFSET
	unsigned char                                      UnknownData03[0x10];                                      // 0x0328(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty CRDLevelInstanceRuntime.LevelInstanceGameplayVolume.OnDisabledStateChanged_69
	unsigned char                                      UnknownData04[0x10];                                      // 0x0368(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty CRDLevelInstanceRuntime.LevelInstanceGameplayVolume.OnLevelInstanceGuidChanged_69
	unsigned char                                      UnknownData05[0x10];                                      // 0x0378(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty CRDLevelInstanceRuntime.LevelInstanceGameplayVolume.OnLevelInstanceNameChanged_69
	unsigned char                                      UnknownData06[0x10];                                      // 0x0388(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty CRDLevelInstanceRuntime.LevelInstanceGameplayVolume.OnLevelInstanceSizeChanged_69
	unsigned char                                      UnknownData07[0x10];                                      // 0x0398(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty CRDLevelInstanceRuntime.LevelInstanceGameplayVolume.OnLevelInstanceContentCollectionChanged_69
	unsigned char                                      UnknownData08[0x1];                                       // 0x03A8(0x0001) MISSED OFFSET
	bool                                               bEditMode_69;                                             // 0x03A9(0x0001) (Net, ZeroConstructor, Transient, IsPlainOldData)
	bool                                               bDisabled_69;                                             // 0x03AA(0x0001) (Net, ZeroConstructor, Transient, IsPlainOldData)
	ESpatialLoadingState                               LoadingState_69;                                          // 0x03AB(0x0001) (Net, ZeroConstructor, Transient, IsPlainOldData)
	unsigned char                                      UnknownData09[0x4];                                       // 0x03AC(0x0004) MISSED OFFSET
	struct FString                                     LevelInstanceName_69;                                     // 0x03B0(0x0010) (Net, ZeroConstructor, Transient)
	bool                                               bInstanceLoaded_69;                                       // 0x03C0(0x0001) (BlueprintVisible, BlueprintReadOnly, Net, ZeroConstructor, Transient, IsPlainOldData)
	bool                                               bWantsLevelLoaded_69;                                     // 0x03C1(0x0001) (Net, ZeroConstructor, Transient, IsPlainOldData)
	unsigned char                                      UnknownData10[0x1];                                       // 0x03C2(0x0001) MISSED OFFSET
	bool                                               bConvertStructuresToProps_69;                             // 0x03C3(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData11[0x4];                                       // 0x03C4(0x0004) MISSED OFFSET
	class FortMinigame*                                CachedMinigame_69;                                        // 0x03C8(0x0008) (ZeroConstructor, Transient)
	class FortMutatorListComponent*                    MutatorListComponent_69;                                  // 0x03D0(0x0008) (Edit, BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)
	class FortClassTrackerComponent*                   ClassFilterComponent_69;                                  // 0x03D8(0x0008) (Edit, BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)
	unsigned char                                      UnknownData12[0x10];                                      // 0x03E0(0x0010) UNKNOWN PROPERTY: ArrayProperty CRDLevelInstanceRuntime.LevelInstanceGameplayVolume.BlacklistedClasses_69
	unsigned char                                      UnknownData13[0x50];                                      // 0x03F0(0x0050) MISSED OFFSET
	struct FGuid                                       LevelInstanceSaveActorGuid_69;                            // 0x0440(0x0010) (ZeroConstructor, Transient, IsPlainOldData)
	class FortLevelInstanceSaveActor*                  LevelInstanceSaveActor_69;                                // 0x0450(0x0008) (ZeroConstructor, Transient)
	unsigned char                                      UnknownData14[0x40];                                      // 0x0458(0x0040) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CRDLevelInstanceRuntime.LevelInstanceGameplayVolume"));
		
		return ptr;
	}


	void SetWantsLevelLoaded(bool bInWantsLevelLoaded_69);
	void SetReadyForInstantiation(bool bReady_69);
	void SetLevelInstanceName(const struct FString& InName_69);
	void SetLevelInstanceContentCollection();
	void SetLevelInstanceActorGuid(const struct FGuid& InLevelInstanceActorGuid_69);
	void SetEditMode(bool bInEditMode_69);
	void RemoveActorWhenEndPlay(class Actor_32759* Actor_69, TEnumAsByte<EEndPlayReason> EndPlayReason_69);
	void RemoveActorWhenDied(class Actor_32759* DamagedActor_69, float Damage_69, class Controller* InstigatedBy_69, class Actor_32759* DamageCauser_69, const struct FVector& HitLocation_69, class PrimitiveComponent* FHitComponent_69, const struct FName& BoneName_69, const struct FVector& Momentum_69);
	void OnVolumeChanged();
	void OnRep_IsDisabled();
	void OnRep_InstanceLoaded();
	void OnRep_EditMode();
	void OnMinigameStateChanged(class FortMinigame* Minigame_69, EFortMinigameState MinigameState_69);
	void LevelInstanceSizeChanged(class Actor_32759* InstigatorActor_69);
	void LevelInstanceNameChanged(const struct FString& Name_69);
	void LevelInstanceContentCollectionChanged(class Actor_32759* InstigatorActor_69);
	void LevelInstanceContentChanged(class Actor_32759* InstigatorActor_69);
	void LevelInstanceBeingDestroyed();
	bool IsPreviewActor();
	bool IsInEditMode();
	bool IsDisabled();
	void InstantiateFromLevelInstanceSaveActor();
	void HandleActorHealthChanged(class Actor_32759* Actor_69, float NewHealth_69);
	struct FString GetLevelInstanceName();
	class FortLevelInstanceSaveActor* CreateLevelInstanceSaveActor();
	void CheckForOverlappingVolumes();
};


// Class CRDLevelInstanceRuntime.LevelInstanceItemListComponent
// 0x0000 (0x0128 - 0x0128)
class LevelInstanceItemListComponent : public FortMinigameItemContainerComponent
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CRDLevelInstanceRuntime.LevelInstanceItemListComponent"));
		
		return ptr;
	}

};


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

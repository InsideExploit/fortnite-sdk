// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Functions
//---------------------------------------------------------------------------

// Function Constraints.ConstraintsScriptingLibrary.RemoveConstraint
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// class World*                   InWorld_69                     (Parm, ZeroConstructor)
// int                            InIndex_69                     (Parm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool ConstraintsScriptingLibrary::STATIC_RemoveConstraint(class World* InWorld_69, int InIndex_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function Constraints.ConstraintsScriptingLibrary.RemoveConstraint"));

	ConstraintsScriptingLibrary_RemoveConstraint_Params params;
	params.InWorld_69 = InWorld_69;
	params.InIndex_69 = InIndex_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function Constraints.ConstraintsScriptingLibrary.GetManager
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// class World*                   InWorld_69                     (Parm, ZeroConstructor)
// class ConstraintsManager*      ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

class ConstraintsManager* ConstraintsScriptingLibrary::STATIC_GetManager(class World* InWorld_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function Constraints.ConstraintsScriptingLibrary.GetManager"));

	ConstraintsScriptingLibrary_GetManager_Params params;
	params.InWorld_69 = InWorld_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function Constraints.ConstraintsScriptingLibrary.CreateTransformableComponentHandle
// (Final, Native, Static, Public, HasOutParms, BlueprintCallable)
// Parameters:
// class World*                   InWorld_69                     (Parm, ZeroConstructor)
// class SceneComponent*          InSceneComponent_69            (Parm, ZeroConstructor, InstancedReference)
// struct FName                   InSocketName_69                (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
// class TransformableComponentHandle* ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

class TransformableComponentHandle* ConstraintsScriptingLibrary::STATIC_CreateTransformableComponentHandle(class World* InWorld_69, class SceneComponent* InSceneComponent_69, const struct FName& InSocketName_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function Constraints.ConstraintsScriptingLibrary.CreateTransformableComponentHandle"));

	ConstraintsScriptingLibrary_CreateTransformableComponentHandle_Params params;
	params.InWorld_69 = InWorld_69;
	params.InSceneComponent_69 = InSceneComponent_69;
	params.InSocketName_69 = InSocketName_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function Constraints.ConstraintsScriptingLibrary.CreateFromType
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// class World*                   InWorld_69                     (Parm, ZeroConstructor)
// ETransformConstraintType       InType_69                      (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// class TickableTransformConstraint* ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

class TickableTransformConstraint* ConstraintsScriptingLibrary::STATIC_CreateFromType(class World* InWorld_69, ETransformConstraintType InType_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function Constraints.ConstraintsScriptingLibrary.CreateFromType"));

	ConstraintsScriptingLibrary_CreateFromType_Params params;
	params.InWorld_69 = InWorld_69;
	params.InType_69 = InType_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function Constraints.ConstraintsScriptingLibrary.AddConstraint
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// class World*                   InWorld_69                     (Parm, ZeroConstructor)
// class TransformableHandle*     InParentHandle_69              (Parm, ZeroConstructor)
// class TransformableHandle*     InChildHandle_69               (Parm, ZeroConstructor)
// class TickableTransformConstraint* InConstraint_69                (Parm, ZeroConstructor)
// bool                           bMaintainOffset_69             (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool ConstraintsScriptingLibrary::STATIC_AddConstraint(class World* InWorld_69, class TransformableHandle* InParentHandle_69, class TransformableHandle* InChildHandle_69, class TickableTransformConstraint* InConstraint_69, bool bMaintainOffset_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function Constraints.ConstraintsScriptingLibrary.AddConstraint"));

	ConstraintsScriptingLibrary_AddConstraint_Params params;
	params.InWorld_69 = InWorld_69;
	params.InParentHandle_69 = InParentHandle_69;
	params.InChildHandle_69 = InChildHandle_69;
	params.InConstraint_69 = InConstraint_69;
	params.bMaintainOffset_69 = bMaintainOffset_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

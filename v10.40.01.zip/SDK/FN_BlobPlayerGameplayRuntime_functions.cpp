// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Functions
//---------------------------------------------------------------------------

// Function BlobPlayerGameplayRuntime.BlobGameplayAbility_Keybind.SetActionDisplayActive
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// bool                           bWillDisplayActive_69          (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void BlobGameplayAbility_Keybind::SetActionDisplayActive(bool bWillDisplayActive_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function BlobPlayerGameplayRuntime.BlobGameplayAbility_Keybind.SetActionDisplayActive"));

	BlobGameplayAbility_Keybind_SetActionDisplayActive_Params params;
	params.bWillDisplayActive_69 = bWillDisplayActive_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function BlobPlayerGameplayRuntime.FortBlobPlayerBlueprintLibrary.CheckForResumeTeleport
// (Final, BlueprintAuthorityOnly, Native, Static, Private, HasOutParms, BlueprintCallable)
// Parameters:
// class FortPlayerPawn*          TargetPawn_69                  (Parm, ZeroConstructor)
// bool                           bForceCrouch_69                (Parm, OutParm, ZeroConstructor, IsPlainOldData)
// float                          UnburrowLaunchXYSpeed_69       (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// float                          UnburrowLaunchZSpeed_69        (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// float                          ExitHorizontalOffset_69        (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// float                          ExitUpVerticalOffset_69        (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// float                          ExitDownVerticalOffset_69      (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void FortBlobPlayerBlueprintLibrary::STATIC_CheckForResumeTeleport(class FortPlayerPawn* TargetPawn_69, float UnburrowLaunchXYSpeed_69, float UnburrowLaunchZSpeed_69, float ExitHorizontalOffset_69, float ExitUpVerticalOffset_69, float ExitDownVerticalOffset_69, bool* bForceCrouch_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function BlobPlayerGameplayRuntime.FortBlobPlayerBlueprintLibrary.CheckForResumeTeleport"));

	FortBlobPlayerBlueprintLibrary_CheckForResumeTeleport_Params params;
	params.TargetPawn_69 = TargetPawn_69;
	params.UnburrowLaunchXYSpeed_69 = UnburrowLaunchXYSpeed_69;
	params.UnburrowLaunchZSpeed_69 = UnburrowLaunchZSpeed_69;
	params.ExitHorizontalOffset_69 = ExitHorizontalOffset_69;
	params.ExitUpVerticalOffset_69 = ExitUpVerticalOffset_69;
	params.ExitDownVerticalOffset_69 = ExitDownVerticalOffset_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (bForceCrouch_69 != nullptr)
		*bForceCrouch_69 = params.bForceCrouch_69;
}


// Function BlobPlayerGameplayRuntime.FortBlobPlayerBlueprintLibrary.BlobLog
// (Final, Native, Static, Private, BlueprintCallable)
// Parameters:
// class Object_32759*            WorldContextObject_69          (Parm, ZeroConstructor)
// struct FString                 InString_69                    (Parm, ZeroConstructor)
// bool                           bLogInShipping_69              (Parm, ZeroConstructor, IsPlainOldData)

void FortBlobPlayerBlueprintLibrary::STATIC_BlobLog(class Object_32759* WorldContextObject_69, const struct FString& InString_69, bool bLogInShipping_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function BlobPlayerGameplayRuntime.FortBlobPlayerBlueprintLibrary.BlobLog"));

	FortBlobPlayerBlueprintLibrary_BlobLog_Params params;
	params.WorldContextObject_69 = WorldContextObject_69;
	params.InString_69 = InString_69;
	params.bLogInShipping_69 = bLogInShipping_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function BlobPlayerGameplayRuntime.FortPawnComponent_BlobPlayer.RecoverFromSpecialMeshSetting
// (Final, BlueprintAuthorityOnly, Native, Public, BlueprintCallable)

void FortPawnComponent_BlobPlayer::RecoverFromSpecialMeshSetting()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function BlobPlayerGameplayRuntime.FortPawnComponent_BlobPlayer.RecoverFromSpecialMeshSetting"));

	FortPawnComponent_BlobPlayer_RecoverFromSpecialMeshSetting_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function BlobPlayerGameplayRuntime.FortPawnComponent_BlobPlayer.OnRep_MeshSetting
// (Final, Native, Protected)

void FortPawnComponent_BlobPlayer::OnRep_MeshSetting()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function BlobPlayerGameplayRuntime.FortPawnComponent_BlobPlayer.OnRep_MeshSetting"));

	FortPawnComponent_BlobPlayer_OnRep_MeshSetting_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function BlobPlayerGameplayRuntime.FortPawnComponent_BlobPlayer.HandleFinishedCharacterCustomization
// (Final, Native, Protected)
// Parameters:
// class FortPlayerPawn*          Pawn_69                        (Parm, ZeroConstructor)

void FortPawnComponent_BlobPlayer::HandleFinishedCharacterCustomization(class FortPlayerPawn* Pawn_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function BlobPlayerGameplayRuntime.FortPawnComponent_BlobPlayer.HandleFinishedCharacterCustomization"));

	FortPawnComponent_BlobPlayer_HandleFinishedCharacterCustomization_Params params;
	params.Pawn_69 = Pawn_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function BlobPlayerGameplayRuntime.FortPawnComponent_BlobPlayer.ApplySpecialMeshSetting
// (Final, BlueprintAuthorityOnly, Native, Public, HasOutParms, BlueprintCallable)
// Parameters:
// class AnimInstance*            BlobAnimInstance_69            (ConstParm, Parm, ZeroConstructor)
// class SkeletalMesh*            BlobSkeletalMesh_69            (Parm, ZeroConstructor)
// TArray<class MaterialInterface*> BlobMeshMaterials_69           (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)

void FortPawnComponent_BlobPlayer::ApplySpecialMeshSetting(class AnimInstance* BlobAnimInstance_69, class SkeletalMesh* BlobSkeletalMesh_69, TArray<class MaterialInterface*> BlobMeshMaterials_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function BlobPlayerGameplayRuntime.FortPawnComponent_BlobPlayer.ApplySpecialMeshSetting"));

	FortPawnComponent_BlobPlayer_ApplySpecialMeshSetting_Params params;
	params.BlobAnimInstance_69 = BlobAnimInstance_69;
	params.BlobSkeletalMesh_69 = BlobSkeletalMesh_69;
	params.BlobMeshMaterials_69 = BlobMeshMaterials_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Classes
//---------------------------------------------------------------------------

// Class AudioWidgets.AudioMeter
// 0x0538 (0x0680 - 0x0148)
class AudioMeter : public Widget
{
public:
	TArray<struct FMeterChannelInfo>                   MeterChannelInfo_69;                                      // 0x0148(0x0010) (Edit, ZeroConstructor)
	struct FScriptDelegate                             MeterChannelInfoDelegate_69;                              // 0x0158(0x0010) (ZeroConstructor, InstancedReference)
	unsigned char                                      UnknownData00[0xC];                                       // 0x0164(0x000C) MISSED OFFSET
	struct FAudioMeterStyle                            WidgetStyle_69;                                           // 0x0170(0x0480) (Edit, BlueprintVisible)
	TEnumAsByte<EOrientation>                          Orientation_69;                                           // 0x05F0(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x3];                                       // 0x05F1(0x0003) MISSED OFFSET
	struct FLinearColor                                BackgroundColor_69;                                       // 0x05F4(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	struct FLinearColor                                MeterBackgroundColor_69;                                  // 0x0604(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	struct FLinearColor                                MeterValueColor_69;                                       // 0x0614(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	struct FLinearColor                                MeterPeakColor_69;                                        // 0x0624(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	struct FLinearColor                                MeterClippingColor_69;                                    // 0x0634(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	struct FLinearColor                                MeterScaleColor_69;                                       // 0x0644(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	struct FLinearColor                                MeterScaleLabelColor_69;                                  // 0x0654(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData02[0x1C];                                      // 0x0664(0x001C) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AudioWidgets.AudioMeter"));
		
		return ptr;
	}


	void SetMeterValueColor(const struct FLinearColor& InValue_69);
	void SetMeterScaleLabelColor(const struct FLinearColor& InValue_69);
	void SetMeterScaleColor(const struct FLinearColor& InValue_69);
	void SetMeterPeakColor(const struct FLinearColor& InValue_69);
	void SetMeterClippingColor(const struct FLinearColor& InValue_69);
	void SetMeterChannelInfo(TArray<struct FMeterChannelInfo> InMeterChannelInfo_69);
	void SetMeterBackgroundColor(const struct FLinearColor& InValue_69);
	void SetBackgroundColor(const struct FLinearColor& InValue_69);
	TArray<struct FMeterChannelInfo> GetMeterChannelInfo__DelegateSignature();
	TArray<struct FMeterChannelInfo> GetMeterChannelInfo();
};


// Class AudioWidgets.AudioRadialSlider
// 0x0208 (0x0350 - 0x0148)
class AudioRadialSlider : public Widget
{
public:
	float                                              Value_69;                                                 // 0x0148(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	struct FScriptDelegate                             ValueDelegate_69;                                         // 0x014C(0x0010) (ZeroConstructor, InstancedReference)
	TEnumAsByte<EAudioRadialSliderLayout>              WidgetLayout_69;                                          // 0x0158(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0159(0x0003) MISSED OFFSET
	struct FLinearColor                                CenterBackgroundColor_69;                                 // 0x015C(0x0010) (Edit, ZeroConstructor, IsPlainOldData)
	struct FLinearColor                                SliderProgressColor_69;                                   // 0x016C(0x0010) (Edit, ZeroConstructor, IsPlainOldData)
	struct FLinearColor                                SliderBarColor_69;                                        // 0x017C(0x0010) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x4];                                       // 0x018C(0x0004) MISSED OFFSET
	struct FVector2D                                   HandStartEndRatio_69;                                     // 0x0190(0x0010) (Edit, ZeroConstructor, IsPlainOldData)
	struct FText                                       UnitsText_69;                                             // 0x01A0(0x0018) (Edit)
	struct FLinearColor                                TextLabelBackgroundColor_69;                              // 0x01B8(0x0010) (Edit, ZeroConstructor, IsPlainOldData)
	bool                                               ShowLabelOnlyOnHover_69;                                  // 0x01C8(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	bool                                               ShowUnitsText_69;                                         // 0x01C9(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	bool                                               IsUnitsTextReadOnly_69;                                   // 0x01CA(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	bool                                               IsValueTextReadOnly_69;                                   // 0x01CB(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	float                                              SliderThickness_69;                                       // 0x01CC(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	struct FVector2D                                   OutputRange_69;                                           // 0x01D0(0x0010) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData02[0x10];                                      // 0x01E0(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty AudioWidgets.AudioRadialSlider.OnValueChanged_69
	unsigned char                                      UnknownData03[0x160];                                     // 0x01F0(0x0160) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AudioWidgets.AudioRadialSlider"));
		
		return ptr;
	}


	void SetWidgetLayout(TEnumAsByte<EAudioRadialSliderLayout> InLayout_69);
	void SetValueTextReadOnly(bool bIsReadOnly_69);
	void SetUnitsTextReadOnly(bool bIsReadOnly_69);
	void SetUnitsText(const struct FText& Units_69);
	void SetTextLabelBackgroundColor(const struct FSlateColor& InColor_69);
	void SetSliderThickness(float InThickness_69);
	void SetSliderProgressColor(const struct FLinearColor& InValue_69);
	void SetSliderBarColor(const struct FLinearColor& InValue_69);
	void SetShowUnitsText(bool bShowUnitsText_69);
	void SetShowLabelOnlyOnHover(bool bShowLabelOnlyOnHover_69);
	void SetOutputRange(const struct FVector2D& InOutputRange_69);
	void SetHandStartEndRatio(const struct FVector2D& InHandStartEndRatio_69);
	void SetCenterBackgroundColor(const struct FLinearColor& InValue_69);
};


// Class AudioWidgets.AudioVolumeRadialSlider
// 0x0000 (0x0350 - 0x0350)
class AudioVolumeRadialSlider : public AudioRadialSlider
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AudioWidgets.AudioVolumeRadialSlider"));
		
		return ptr;
	}

};


// Class AudioWidgets.AudioFrequencyRadialSlider
// 0x0000 (0x0350 - 0x0350)
class AudioFrequencyRadialSlider : public AudioRadialSlider
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AudioWidgets.AudioFrequencyRadialSlider"));
		
		return ptr;
	}

};


// Class AudioWidgets.AudioSliderBase
// 0x07B8 (0x0900 - 0x0148)
class AudioSliderBase : public Widget
{
public:
	float                                              Value_69;                                                 // 0x0148(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x014C(0x0004) MISSED OFFSET
	struct FText                                       UnitsText_69;                                             // 0x0150(0x0018) (Edit)
	struct FLinearColor                                TextLabelBackgroundColor_69;                              // 0x0168(0x0010) (Edit, ZeroConstructor, IsPlainOldData)
	struct FScriptDelegate                             TextLabelBackgroundColorDelegate_69;                      // 0x0178(0x0010) (ZeroConstructor, InstancedReference)
	bool                                               ShowLabelOnlyOnHover_69;                                  // 0x0184(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	bool                                               ShowUnitsText_69;                                         // 0x0185(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	bool                                               IsUnitsTextReadOnly_69;                                   // 0x0186(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	bool                                               IsValueTextReadOnly_69;                                   // 0x0187(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	struct FScriptDelegate                             ValueDelegate_69;                                         // 0x0188(0x0010) (ZeroConstructor, InstancedReference)
	struct FLinearColor                                SliderBackgroundColor_69;                                 // 0x0194(0x0010) (Edit, ZeroConstructor, IsPlainOldData)
	struct FScriptDelegate                             SliderBackgroundColorDelegate_69;                         // 0x01A4(0x0010) (ZeroConstructor, InstancedReference)
	struct FLinearColor                                SliderBarColor_69;                                        // 0x01B0(0x0010) (Edit, ZeroConstructor, IsPlainOldData)
	struct FScriptDelegate                             SliderBarColorDelegate_69;                                // 0x01C0(0x0010) (ZeroConstructor, InstancedReference)
	struct FLinearColor                                SliderThumbColor_69;                                      // 0x01CC(0x0010) (Edit, ZeroConstructor, IsPlainOldData)
	struct FScriptDelegate                             SliderThumbColorDelegate_69;                              // 0x01DC(0x0010) (ZeroConstructor, InstancedReference)
	struct FLinearColor                                WidgetBackgroundColor_69;                                 // 0x01E8(0x0010) (Edit, ZeroConstructor, IsPlainOldData)
	struct FScriptDelegate                             WidgetBackgroundColorDelegate_69;                         // 0x01F8(0x0010) (ZeroConstructor, InstancedReference)
	TEnumAsByte<EOrientation>                          Orientation_69;                                           // 0x0204(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x3];                                       // 0x0205(0x0003) MISSED OFFSET
	unsigned char                                      UnknownData02[0x10];                                      // 0x0205(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty AudioWidgets.AudioSliderBase.OnValueChanged_69
	unsigned char                                      UnknownData03[0x6E8];                                     // 0x0218(0x06E8) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AudioWidgets.AudioSliderBase"));
		
		return ptr;
	}


	void SetWidgetBackgroundColor(const struct FLinearColor& InValue_69);
	void SetValueTextReadOnly(bool bIsReadOnly_69);
	void SetUnitsTextReadOnly(bool bIsReadOnly_69);
	void SetUnitsText(const struct FText& Units_69);
	void SetTextLabelBackgroundColor(const struct FSlateColor& InColor_69);
	void SetSliderThumbColor(const struct FLinearColor& InValue_69);
	void SetSliderBarColor(const struct FLinearColor& InValue_69);
	void SetSliderBackgroundColor(const struct FLinearColor& InValue_69);
	void SetShowUnitsText(bool bShowUnitsText_69);
	void SetShowLabelOnlyOnHover(bool bShowLabelOnlyOnHover_69);
	float GetOutputValue(float LinValue_69);
	float GetLinValue(float OutputValue_69);
};


// Class AudioWidgets.AudioSlider
// 0x0010 (0x0910 - 0x0900)
class AudioSlider : public AudioSliderBase
{
public:
	TWeakObjectPtr<class CurveFloat>                   LinToOutputCurve_69;                                      // 0x0900(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	TWeakObjectPtr<class CurveFloat>                   OutputToLinCurve_69;                                      // 0x0908(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AudioWidgets.AudioSlider"));
		
		return ptr;
	}

};


// Class AudioWidgets.AudioVolumeSlider
// 0x0000 (0x0910 - 0x0910)
class AudioVolumeSlider : public AudioSlider
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AudioWidgets.AudioVolumeSlider"));
		
		return ptr;
	}

};


// Class AudioWidgets.AudioFrequencySlider
// 0x0010 (0x0910 - 0x0900)
class AudioFrequencySlider : public AudioSliderBase
{
public:
	struct FVector2D                                   OutputRange_69;                                           // 0x0900(0x0010) (Edit, ZeroConstructor, IsPlainOldData)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AudioWidgets.AudioFrequencySlider"));
		
		return ptr;
	}

};


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Enums
//---------------------------------------------------------------------------

// Enum CrewUI.EBattlePassCrewContentState
enum class EBattlePassCrewContentState : uint8_t
{
	BattlePass                     = 0,
	Crew                           = 1,
	CrewSubscribed                 = 2,
	EBattlePassCrewContentState_MAX = 3
};


// Enum CrewUI.EFortProgressiveContentInterfaceCloseReason
enum class EFortProgressiveContentInterfaceCloseReason : uint8_t
{
	Normal                         = 0,
	SubscriptionPurchased          = 1,
	EFortProgressiveContentInterfaceCloseReason_MAX = 2
};


// Enum CrewUI.EFortProgressiveContentType
enum class EFortProgressiveContentType : uint8_t
{
	ProgressiveTableOfContentsScreen = 0,
	ProgressiveItemScreen          = 1,
	EFortProgressiveContentType_MAX = 2
};


// Enum CrewUI.EBattlePassPurchaseButtonCurrencyType
enum class EBattlePassPurchaseButtonCurrencyType : uint8_t
{
	None                           = 0,
	Mtx                            = 1,
	RealMoney                      = 2,
	EBattlePassPurchaseButtonCurrencyType_MAX = 3
};


// Enum CrewUI.EBattlePassPurchaseState
enum class EBattlePassPurchaseState : uint8_t
{
	Purchase                       = 0,
	Confirm                        = 1,
	EBattlePassPurchaseState_MAX   = 2
};


// Enum CrewUI.ECrewPurchaseButtonState
enum class ECrewPurchaseButtonState : uint8_t
{
	None                           = 0,
	Purchase                       = 1,
	Rejoin                         = 2,
	ECrewPurchaseButtonState_MAX   = 3
};



//---------------------------------------------------------------------------
//Script Structs
//---------------------------------------------------------------------------

// ScriptStruct CrewUI.CrewSubscriptionContentTabData
// 0x0020
struct FCrewSubscriptionContentTabData
{
	struct FText                                       TabName_69;                                               // 0x0000(0x0018) (Edit, BlueprintVisible, BlueprintReadOnly)
	ESubscriptionContentTab                            TabType_69;                                               // 0x0018(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0019(0x0007) MISSED OFFSET
};

// ScriptStruct CrewUI.FortProgressiveVariant
// 0x0068
struct FFortProgressiveVariant
{
	TArray<struct FCosmeticVariantInfo>                DefaultVariantPreviewOverrides_69;                        // 0x0000(0x0010) (Edit, ZeroConstructor)
	unsigned char                                      UnknownData00[0x28];                                      // 0x0010(0x0028) UNKNOWN PROPERTY: SoftObjectProperty CrewUI.FortProgressiveVariant.TileMaterial_69
	bool                                               bHidden_69;                                               // 0x0038(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	bool                                               bAllowPreviewStyles_69;                                   // 0x0039(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x6];                                       // 0x003A(0x0006) MISSED OFFSET
	unsigned char                                      UnknownData02[0x28];                                      // 0x003A(0x0028) UNKNOWN PROPERTY: SoftObjectProperty CrewUI.FortProgressiveVariant.VariantToken_69
};

// ScriptStruct CrewUI.FortProgressiveStageOverrideDisplayData
// 0x0058
struct FFortProgressiveStageOverrideDisplayData
{
	TArray<struct FCosmeticVariantInfo>                DefaultVariantPreviewOverrides_69;                        // 0x0000(0x0010) (Edit, ZeroConstructor)
	struct FText                                       DisplayName_69;                                           // 0x0010(0x0018) (Edit)
	unsigned char                                      UnknownData00[0x28];                                      // 0x0028(0x0028) UNKNOWN PROPERTY: SoftObjectProperty CrewUI.FortProgressiveStageOverrideDisplayData.TileMaterial_69
	bool                                               bAllowPreviewStyles_69;                                   // 0x0050(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x7];                                       // 0x0051(0x0007) MISSED OFFSET
};

// ScriptStruct CrewUI.FortProgressiveUIStage
// 0x0070
struct FFortProgressiveUIStage
{
	TArray<struct FFortProgressiveVariant>             Variants_69;                                              // 0x0000(0x0010) (Edit, ZeroConstructor)
	bool                                               bUseOverrideDisplayData_69;                               // 0x0010(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0011(0x0007) MISSED OFFSET
	struct FFortProgressiveStageOverrideDisplayData    OverrideDisplayData_69;                                   // 0x0018(0x0058) (Edit)
};

// ScriptStruct CrewUI.FortProgressiveSet
// 0x0060
struct FFortProgressiveSet
{
	struct FString                                     FulfillmentId_69;                                         // 0x0000(0x0010) (Edit, ZeroConstructor)
	struct FText                                       SetName_69;                                               // 0x0010(0x0018) (Edit)
	unsigned char                                      UnknownData00[0x28];                                      // 0x0028(0x0028) UNKNOWN PROPERTY: SoftObjectProperty CrewUI.FortProgressiveSet.TileMaterial_69
	TArray<struct FFortProgressiveUIStage>             Stages_69;                                                // 0x0050(0x0010) (Edit, ZeroConstructor)
};

// ScriptStruct CrewUI.FortProgressiveSetVariantData
// 0x0018
struct FFortProgressiveSetVariantData
{
	class FortVariantTokenType*                        VariantToken_69;                                          // 0x0000(0x0008) (ZeroConstructor, Transient)
	unsigned char                                      UnknownData00[0x10];                                      // 0x0008(0x0010) MISSED OFFSET
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

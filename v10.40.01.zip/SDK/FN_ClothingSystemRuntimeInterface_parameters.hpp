#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function ClothingSystemRuntimeInterface.ClothingSimulationInteractor.SetNumSubsteps
struct ClothingSimulationInteractor_SetNumSubsteps_Params
{
	int                                                NumSubsteps_69;                                           // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function ClothingSystemRuntimeInterface.ClothingSimulationInteractor.SetNumIterations
struct ClothingSimulationInteractor_SetNumIterations_Params
{
	int                                                NumIterations_69;                                         // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function ClothingSystemRuntimeInterface.ClothingSimulationInteractor.SetMaxNumIterations
struct ClothingSimulationInteractor_SetMaxNumIterations_Params
{
	int                                                MaxNumIterations_69;                                      // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function ClothingSystemRuntimeInterface.ClothingSimulationInteractor.SetAnimDriveSpringStiffness
struct ClothingSimulationInteractor_SetAnimDriveSpringStiffness_Params
{
	float                                              InStiffness_69;                                           // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function ClothingSystemRuntimeInterface.ClothingSimulationInteractor.PhysicsAssetUpdated
struct ClothingSimulationInteractor_PhysicsAssetUpdated_Params
{
};

// Function ClothingSystemRuntimeInterface.ClothingSimulationInteractor.GetSimulationTime
struct ClothingSimulationInteractor_GetSimulationTime_Params
{
	float                                              ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function ClothingSystemRuntimeInterface.ClothingSimulationInteractor.GetNumSubsteps
struct ClothingSimulationInteractor_GetNumSubsteps_Params
{
	int                                                ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function ClothingSystemRuntimeInterface.ClothingSimulationInteractor.GetNumKinematicParticles
struct ClothingSimulationInteractor_GetNumKinematicParticles_Params
{
	int                                                ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function ClothingSystemRuntimeInterface.ClothingSimulationInteractor.GetNumIterations
struct ClothingSimulationInteractor_GetNumIterations_Params
{
	int                                                ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function ClothingSystemRuntimeInterface.ClothingSimulationInteractor.GetNumDynamicParticles
struct ClothingSimulationInteractor_GetNumDynamicParticles_Params
{
	int                                                ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function ClothingSystemRuntimeInterface.ClothingSimulationInteractor.GetNumCloths
struct ClothingSimulationInteractor_GetNumCloths_Params
{
	int                                                ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function ClothingSystemRuntimeInterface.ClothingSimulationInteractor.GetClothingInteractor
struct ClothingSimulationInteractor_GetClothingInteractor_Params
{
	struct FString                                     ClothingAssetName_69;                                     // (Parm, ZeroConstructor)
	class ClothingInteractor*                          ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function ClothingSystemRuntimeInterface.ClothingSimulationInteractor.EnableGravityOverride
struct ClothingSimulationInteractor_EnableGravityOverride_Params
{
	struct FVector                                     InVector_69;                                              // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
};

// Function ClothingSystemRuntimeInterface.ClothingSimulationInteractor.DisableGravityOverride
struct ClothingSimulationInteractor_DisableGravityOverride_Params
{
};

// Function ClothingSystemRuntimeInterface.ClothingSimulationInteractor.ClothConfigUpdated
struct ClothingSimulationInteractor_ClothConfigUpdated_Params
{
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

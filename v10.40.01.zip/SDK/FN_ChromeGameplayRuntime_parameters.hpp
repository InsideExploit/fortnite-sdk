#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function ChromeGameplayRuntime.ChromeWaterBodyComponent.ApplyChromeMaterialToOwner
struct ChromeWaterBodyComponent_ApplyChromeMaterialToOwner_Params
{
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

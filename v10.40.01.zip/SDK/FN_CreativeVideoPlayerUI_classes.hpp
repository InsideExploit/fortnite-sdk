#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Classes
//---------------------------------------------------------------------------

// Class CreativeVideoPlayerUI.CreativeVideoPlayerFullScreenWidget
// 0x0068 (0x0410 - 0x03A8)
class CreativeVideoPlayerFullScreenWidget : public CommonActivatableWidget
{
public:
	unsigned char                                      UnknownData00[0x18];                                      // 0x03A8(0x0018) MISSED OFFSET
	class SoundSourceBus*                              SourceBus_69;                                             // 0x03C0(0x0008) (Edit, ZeroConstructor)
	class SoundClass*                                  SoundClass_69;                                            // 0x03C8(0x0008) (Edit, ZeroConstructor)
	struct FDataTableRowHandle                         HoldToSkipAction_69;                                      // 0x03D0(0x0010) (Edit, DisableEditOnInstance)
	class CommonButtonLegacy*                          Button_Skip_69;                                           // 0x03E0(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	float                                              SkipButtonTimeout_69;                                     // 0x03E8(0x0004) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	float                                              LastInteractionTime_69;                                   // 0x03EC(0x0004) (ZeroConstructor, Transient, IsPlainOldData)
	bool                                               bControlsVisible_69;                                      // 0x03F0(0x0001) (ZeroConstructor, Transient, IsPlainOldData)
	unsigned char                                      UnknownData01[0xF];                                       // 0x03F1(0x000F) MISSED OFFSET
	class AudioComponent*                              SoundComponent_69;                                        // 0x0400(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	unsigned char                                      UnknownData02[0x8];                                       // 0x0408(0x0008) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CreativeVideoPlayerUI.CreativeVideoPlayerFullScreenWidget"));
		
		return ptr;
	}


	void OnSkipButtonActionProgress(float HeldPercent_69);
	void OnSkipButtonActionComplete();
};


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

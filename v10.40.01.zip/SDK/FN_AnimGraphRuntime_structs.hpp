#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Enums
//---------------------------------------------------------------------------

// Enum AnimGraphRuntime.EBoneModificationMode
enum class EBoneModificationMode : uint8_t
{
	BMM_Ignore                     = 0,
	BMM_Replace                    = 1,
	BMM_Additive                   = 2,
	BMM_MAX                        = 3
};


// Enum AnimGraphRuntime.ERefPoseType
enum class ERefPoseType : uint8_t
{
	EIT_LocalSpace                 = 0,
	EIT_Additive                   = 1,
	EIT_MAX                        = 2
};


// Enum AnimGraphRuntime.EEasingFuncType
enum class EEasingFuncType : uint8_t
{
	Linear                         = 0,
	Sinusoidal                     = 1,
	Cubic                          = 2,
	QuadraticInOut                 = 3,
	CubicInOut                     = 4,
	HermiteCubic                   = 5,
	QuarticInOut                   = 6,
	QuinticInOut                   = 7,
	CircularIn                     = 8,
	CircularOut                    = 9,
	CircularInOut                  = 10,
	ExpIn                          = 11,
	ExpOut                         = 12,
	ExpInOut                       = 13,
	CustomCurve                    = 14,
	EEasingFuncType_MAX            = 15
};


// Enum AnimGraphRuntime.ERotationComponent
enum class ERotationComponent : uint8_t
{
	EulerX                         = 0,
	EulerY                         = 1,
	EulerZ                         = 2,
	QuaternionAngle                = 3,
	SwingAngle                     = 4,
	TwistAngle                     = 5,
	ERotationComponent_MAX         = 6
};


// Enum AnimGraphRuntime.EBlendListTransitionType
enum class EBlendListTransitionType : uint8_t
{
	StandardBlend                  = 0,
	Inertialization                = 1,
	EBlendListTransitionType_MAX   = 2
};


// Enum AnimGraphRuntime.EAnimFunctionCallSite
enum class EAnimFunctionCallSite : uint8_t
{
	OnInitialize                   = 0,
	OnUpdate                       = 1,
	OnBecomeRelevant               = 2,
	OnEvaluate                     = 3,
	OnInitializePostRecursion      = 4,
	OnUpdatePostRecursion          = 5,
	OnBecomeRelevantPostRecursion  = 6,
	OnEvaluatePostRecursion        = 7,
	OnStartedBlendingOut           = 8,
	OnStartedBlendingIn            = 9,
	OnFinishedBlendingOut          = 10,
	OnFinishedBlendingIn           = 11,
	EAnimFunctionCallSite_MAX      = 12
};


// Enum AnimGraphRuntime.ELayeredBoneBlendMode
enum class ELayeredBoneBlendMode : uint8_t
{
	BranchFilter                   = 0,
	BlendMask                      = 1,
	ELayeredBoneBlendMode_MAX      = 2
};


// Enum AnimGraphRuntime.EModifyCurveApplyMode
enum class EModifyCurveApplyMode : uint8_t
{
	Add                            = 0,
	Scale                          = 1,
	Blend                          = 2,
	WeightedMovingAverage          = 3,
	RemapCurve                     = 4,
	EModifyCurveApplyMode_MAX      = 5
};


// Enum AnimGraphRuntime.EPoseDriverType
enum class EPoseDriverType : uint8_t
{
	SwingAndTwist                  = 0,
	SwingOnly                      = 1,
	Translation                    = 2,
	EPoseDriverType_MAX            = 3
};


// Enum AnimGraphRuntime.EPoseDriverSource
enum class EPoseDriverSource : uint8_t
{
	Rotation                       = 0,
	Translation                    = 1,
	EPoseDriverSource_MAX          = 2
};


// Enum AnimGraphRuntime.EPoseDriverOutput
enum class EPoseDriverOutput : uint8_t
{
	DrivePoses                     = 0,
	DriveCurves                    = 1,
	EPoseDriverOutput_MAX          = 2
};


// Enum AnimGraphRuntime.ESnapshotSourceMode
enum class ESnapshotSourceMode : uint8_t
{
	NamedSnapshot                  = 0,
	SnapshotPin                    = 1,
	ESnapshotSourceMode_MAX        = 2
};


// Enum AnimGraphRuntime.ESequenceEvalReinit
enum class ESequenceEvalReinit : uint8_t
{
	NoReset                        = 0,
	StartPosition                  = 1,
	ExplicitTime                   = 2,
	ESequenceEvalReinit_MAX        = 3
};


// Enum AnimGraphRuntime.ESwapRootBone
enum class ESwapRootBone : uint8_t
{
	SwapRootBone_Component         = 0,
	SwapRootBone_Actor             = 1,
	SwapRootBone_None              = 2,
	SwapRootBone_MAX               = 3
};


// Enum AnimGraphRuntime.AnimPhysAngularConstraintType
enum class EAnimPhysAngularConstraintType : uint8_t
{
	Angular                        = 0,
	Cone                           = 1,
	AnimPhysAngularConstraintType_MAX = 2
};


// Enum AnimGraphRuntime.AnimPhysLinearConstraintType
enum class EAnimPhysLinearConstraintType : uint8_t
{
	Free                           = 0,
	Limited                        = 1,
	AnimPhysLinearConstraintType_MAX = 2
};


// Enum AnimGraphRuntime.AnimPhysSimSpaceType
enum class EAnimPhysSimSpaceType : uint8_t
{
	Component                      = 0,
	Actor                          = 1,
	World                          = 2,
	RootRelative                   = 3,
	BoneRelative                   = 4,
	AnimPhysSimSpaceType_MAX       = 5
};


// Enum AnimGraphRuntime.ESphericalLimitType
enum class ESphericalLimitType : uint8_t
{
	Inner                          = 0,
	Outer                          = 1,
	ESphericalLimitType_MAX        = 2
};


// Enum AnimGraphRuntime.EDrivenBoneModificationMode
enum class EDrivenBoneModificationMode : uint8_t
{
	AddToInput                     = 0,
	ReplaceComponent               = 1,
	AddToRefPose                   = 2,
	EDrivenBoneModificationMode_MAX = 3
};


// Enum AnimGraphRuntime.EDrivenDestinationMode
enum class EDrivenDestinationMode : uint8_t
{
	Bone                           = 0,
	MorphTarget                    = 1,
	MaterialParameter              = 2,
	EDrivenDestinationMode_MAX     = 3
};


// Enum AnimGraphRuntime.EConstraintOffsetOption
enum class EConstraintOffsetOption : uint8_t
{
	None                           = 0,
	Offset_RefPose                 = 1,
	EConstraintOffsetOption_MAX    = 2
};


// Enum AnimGraphRuntime.CopyBoneDeltaMode
enum class ECopyBoneDeltaMode : uint8_t
{
	Accumulate                     = 0,
	Copy                           = 1,
	CopyBoneDeltaMode_MAX          = 2
};


// Enum AnimGraphRuntime.EInterpolationBlend
enum class EInterpolationBlend : uint8_t
{
	Linear                         = 0,
	Cubic                          = 1,
	Sinusoidal                     = 2,
	EaseInOutExponent2             = 3,
	EaseInOutExponent3             = 4,
	EaseInOutExponent4             = 5,
	EaseInOutExponent5             = 6,
	MAX                            = 7
};


// Enum AnimGraphRuntime.ESimulationSpace
enum class ESimulationSpace : uint8_t
{
	ComponentSpace                 = 0,
	WorldSpace                     = 1,
	BaseBoneSpace                  = 2,
	ESimulationSpace_MAX           = 3
};


// Enum AnimGraphRuntime.ESimulationTiming
enum class ESimulationTiming : uint8_t
{
	Default                        = 0,
	Synchronous                    = 1,
	Deferred                       = 2,
	ESimulationTiming_MAX          = 3
};


// Enum AnimGraphRuntime.EScaleChainInitialLength
enum class EScaleChainInitialLength : uint8_t
{
	FixedDefaultLengthValue        = 0,
	Distance                       = 1,
	ChainLength                    = 2,
	EScaleChainInitialLength_MAX   = 3
};


// Enum AnimGraphRuntime.ESplineBoneAxis
enum class ESplineBoneAxis : uint8_t
{
	None                           = 0,
	X                              = 1,
	Y                              = 2,
	Z                              = 3,
	ESplineBoneAxis_MAX            = 4
};


// Enum AnimGraphRuntime.EWarpingEvaluationMode
enum class EWarpingEvaluationMode : uint8_t
{
	Manual                         = 0,
	Graph                          = 1,
	EWarpingEvaluationMode_MAX     = 2
};


// Enum AnimGraphRuntime.EWarpingVectorMode
enum class EWarpingVectorMode : uint8_t
{
	ComponentSpaceVector           = 0,
	ActorSpaceVector               = 1,
	WorldSpaceVector               = 2,
	IKFootRootLocalSpaceVector     = 3,
	EWarpingVectorMode_MAX         = 4
};


// Enum AnimGraphRuntime.ERBFSolverType
enum class ERBFSolverType : uint8_t
{
	Additive                       = 0,
	Interpolative                  = 1,
	ERBFSolverType_MAX             = 2
};


// Enum AnimGraphRuntime.ERBFFunctionType
enum class ERBFFunctionType : uint8_t
{
	Gaussian                       = 0,
	Exponential                    = 1,
	Linear                         = 2,
	Cubic                          = 3,
	Quintic                        = 4,
	DefaultFunction                = 5,
	ERBFFunctionType_MAX           = 6
};


// Enum AnimGraphRuntime.ERBFDistanceMethod
enum class ERBFDistanceMethod : uint8_t
{
	Euclidean                      = 0,
	Quaternion                     = 1,
	SwingAngle                     = 2,
	TwistAngle                     = 3,
	DefaultMethod                  = 4,
	ERBFDistanceMethod_MAX         = 5
};


// Enum AnimGraphRuntime.ERBFNormalizeMethod
enum class ERBFNormalizeMethod : uint8_t
{
	OnlyNormalizeAboveOne          = 0,
	AlwaysNormalize                = 1,
	NormalizeWithinMedian          = 2,
	NoNormalization                = 3,
	ERBFNormalizeMethod_MAX        = 4
};



//---------------------------------------------------------------------------
//Script Structs
//---------------------------------------------------------------------------

// ScriptStruct AnimGraphRuntime.AnimationStateMachineReference
// 0x0000 (0x0010 - 0x0010)
struct FAnimationStateMachineReference : public FAnimNodeReference
{

};

// ScriptStruct AnimGraphRuntime.AnimationStateResultReference
// 0x0000 (0x0010 - 0x0010)
struct FAnimationStateResultReference : public FAnimNodeReference
{

};

// ScriptStruct AnimGraphRuntime.PositionHistory
// 0x0030
struct FPositionHistory
{
	TArray<struct FVector>                             Positions_69;                                             // 0x0000(0x0010) (Edit, ZeroConstructor)
	float                                              Range_69;                                                 // 0x0010(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x1C];                                      // 0x0014(0x001C) MISSED OFFSET
};

// ScriptStruct AnimGraphRuntime.LinkedAnimGraphReference
// 0x0000 (0x0010 - 0x0010)
struct FLinkedAnimGraphReference : public FAnimNodeReference
{

};

// ScriptStruct AnimGraphRuntime.SequenceEvaluatorReference
// 0x0000 (0x0010 - 0x0010)
struct FSequenceEvaluatorReference : public FAnimNodeReference
{

};

// ScriptStruct AnimGraphRuntime.SequencePlayerReference
// 0x0000 (0x0010 - 0x0010)
struct FSequencePlayerReference : public FAnimNodeReference
{

};

// ScriptStruct AnimGraphRuntime.SkeletalControlReference
// 0x0000 (0x0010 - 0x0010)
struct FSkeletalControlReference : public FAnimNodeReference
{

};

// ScriptStruct AnimGraphRuntime.AnimNode_SkeletalControlBase
// 0x00B8 (0x00C8 - 0x0010)
struct FAnimNode_SkeletalControlBase : public FAnimNode_Base
{
	struct FComponentSpacePoseLink                     ComponentPose_69;                                         // 0x0010(0x0010) (Edit, BlueprintVisible)
	int                                                LODThreshold_69;                                          // 0x0020(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              ActualAlpha_69;                                           // 0x0024(0x0004) (ZeroConstructor, Transient, IsPlainOldData)
	EAnimAlphaInputType                                AlphaInputType_69;                                        // 0x0028(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bAlphaBoolEnabled_69;                                     // 0x0029(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x2];                                       // 0x002A(0x0002) MISSED OFFSET
	float                                              Alpha_69;                                                 // 0x002C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FInputScaleBias                             AlphaScaleBias_69;                                        // 0x0030(0x0008) (Edit, BlueprintVisible)
	struct FInputAlphaBoolBlend                        AlphaBoolBlend_69;                                        // 0x0038(0x0048) (Edit, BlueprintVisible)
	struct FName                                       AlphaCurveName_69;                                        // 0x0080(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FInputScaleBiasClamp                        AlphaScaleBiasClamp_69;                                   // 0x0084(0x0030) (Edit, BlueprintVisible)
	unsigned char                                      UnknownData01[0x14];                                      // 0x00B4(0x0014) MISSED OFFSET
};

// ScriptStruct AnimGraphRuntime.RandomPlayerSequenceEntry
// 0x0050
struct FRandomPlayerSequenceEntry
{
	class AnimSequence*                                Sequence_69;                                              // 0x0000(0x0008) (Edit, BlueprintVisible, ZeroConstructor)
	float                                              ChanceToPlay_69;                                          // 0x0008(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                MinLoopCount_69;                                          // 0x000C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                MaxLoopCount_69;                                          // 0x0010(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              MinPlayrate_69;                                           // 0x0014(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              MaxPlayrate_69;                                           // 0x0018(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x001C(0x0004) MISSED OFFSET
	struct FAlphaBlend                                 BlendIn_69;                                               // 0x0020(0x0030) (Edit)
};

// ScriptStruct AnimGraphRuntime.AnimNode_RandomPlayer
// 0x0068 (0x0078 - 0x0010)
struct FAnimNode_RandomPlayer : public FAnimNode_Base
{
	TArray<struct FRandomPlayerSequenceEntry>          Entries_69;                                               // 0x0010(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	unsigned char                                      UnknownData00[0x50];                                      // 0x0020(0x0050) MISSED OFFSET
	bool                                               bShuffleMode_69;                                          // 0x0070(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x7];                                       // 0x0071(0x0007) MISSED OFFSET
};

// ScriptStruct AnimGraphRuntime.AnimNode_LookAt
// 0x0178 (0x0240 - 0x00C8)
struct FAnimNode_LookAt : public FAnimNode_SkeletalControlBase
{
	struct FBoneReference                              BoneToModify_69;                                          // 0x00C8(0x000C) (Edit)
	unsigned char                                      UnknownData00[0xC];                                       // 0x00D4(0x000C) MISSED OFFSET
	struct FBoneSocketTarget                           LookAtTarget_69;                                          // 0x00E0(0x0080) (Edit)
	struct FVector                                     LookAtLocation_69;                                        // 0x0160(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FAxis                                       LookAt_Axis_69;                                           // 0x0178(0x0020) (Edit)
	bool                                               bUseLookUpAxis_69;                                        // 0x0198(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<EInterpolationBlend>                   InterpolationType_69;                                     // 0x0199(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x6];                                       // 0x019A(0x0006) MISSED OFFSET
	struct FAxis                                       LookUp_Axis_69;                                           // 0x01A0(0x0020) (Edit)
	float                                              LookAtClamp_69;                                           // 0x01C0(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              InterpolationTime_69;                                     // 0x01C4(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              InterpolationTriggerThreashold_69;                        // 0x01C8(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData02[0x74];                                      // 0x01CC(0x0074) MISSED OFFSET
};

// ScriptStruct AnimGraphRuntime.AnimNode_BlendSpaceGraphBase
// 0x0050 (0x0060 - 0x0010)
struct FAnimNode_BlendSpaceGraphBase : public FAnimNode_Base
{
	float                                              X_69;                                                     // 0x0010(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              Y_69;                                                     // 0x0014(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FName                                       GroupName_69;                                             // 0x0018(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<EAnimGroupRole>                        GroupRole_69;                                             // 0x001C(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x001D(0x0003) MISSED OFFSET
	class BlendSpace*                                  BlendSpace_69;                                            // 0x0020(0x0008) (ZeroConstructor)
	TArray<struct FPoseLink>                           SamplePoseLinks_69;                                       // 0x0028(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData01[0x28];                                      // 0x0038(0x0028) MISSED OFFSET
};

// ScriptStruct AnimGraphRuntime.AnimNode_BlendSpaceGraph
// 0x0000 (0x0060 - 0x0060)
struct FAnimNode_BlendSpaceGraph : public FAnimNode_BlendSpaceGraphBase
{

};

// ScriptStruct AnimGraphRuntime.AnimNode_BlendSpaceSampleResult
// 0x0000 (0x0020 - 0x0020)
struct FAnimNode_BlendSpaceSampleResult : public FAnimNode_Root
{

};

// ScriptStruct AnimGraphRuntime.AnimNode_ModifyBone
// 0x0060 (0x0128 - 0x00C8)
struct FAnimNode_ModifyBone : public FAnimNode_SkeletalControlBase
{
	struct FBoneReference                              BoneToModify_69;                                          // 0x00C8(0x000C) (Edit)
	unsigned char                                      UnknownData00[0x4];                                       // 0x00D4(0x0004) MISSED OFFSET
	struct FVector                                     Translation_69;                                           // 0x00D8(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FRotator                                    Rotation_69;                                              // 0x00F0(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FVector                                     Scale_69;                                                 // 0x0108(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<EBoneModificationMode>                 TranslationMode_69;                                       // 0x0120(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<EBoneModificationMode>                 RotationMode_69;                                          // 0x0121(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<EBoneModificationMode>                 ScaleMode_69;                                             // 0x0122(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<EBoneControlSpace>                     TranslationSpace_69;                                      // 0x0123(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<EBoneControlSpace>                     RotationSpace_69;                                         // 0x0124(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<EBoneControlSpace>                     ScaleSpace_69;                                            // 0x0125(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x2];                                       // 0x0126(0x0002) MISSED OFFSET
};

// ScriptStruct AnimGraphRuntime.AnimNode_RefPose
// 0x0000 (0x0010 - 0x0010)
struct FAnimNode_RefPose : public FAnimNode_Base
{

};

// ScriptStruct AnimGraphRuntime.AnimNode_MeshSpaceRefPose
// 0x0000 (0x0010 - 0x0010)
struct FAnimNode_MeshSpaceRefPose : public FAnimNode_Base
{

};

// ScriptStruct AnimGraphRuntime.AnimNode_RotationMultiplier
// 0x0020 (0x00E8 - 0x00C8)
struct FAnimNode_RotationMultiplier : public FAnimNode_SkeletalControlBase
{
	struct FBoneReference                              TargetBone_69;                                            // 0x00C8(0x000C) (Edit)
	struct FBoneReference                              SourceBone_69;                                            // 0x00D4(0x000C) (Edit)
	float                                              Multiplier_69;                                            // 0x00E0(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<EBoneAxis>                             RotationAxisToRefer_69;                                   // 0x00E4(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	bool                                               bIsAdditive_69;                                           // 0x00E5(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x2];                                       // 0x00E6(0x0002) MISSED OFFSET
};

// ScriptStruct AnimGraphRuntime.RotationRetargetingInfo
// 0x01A0
struct FRotationRetargetingInfo
{
	bool                                               bEnabled_69;                                              // 0x0000(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0xF];                                       // 0x0001(0x000F) MISSED OFFSET
	struct FCoreUObject_FTransform                     Source_69;                                                // 0x0010(0x0060) (Edit, IsPlainOldData)
	struct FCoreUObject_FTransform                     Target_69;                                                // 0x0070(0x0060) (Edit, IsPlainOldData)
	ERotationComponent                                 RotationComponent_69;                                     // 0x00D0(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x7];                                       // 0x00D1(0x0007) MISSED OFFSET
	struct FVector                                     TwistAxis_69;                                             // 0x00D8(0x0018) (Edit, ZeroConstructor, IsPlainOldData)
	bool                                               bUseAbsoluteAngle_69;                                     // 0x00F0(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData02[0x3];                                       // 0x00F1(0x0003) MISSED OFFSET
	float                                              SourceMinimum_69;                                         // 0x00F4(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	float                                              SourceMaximum_69;                                         // 0x00F8(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	float                                              TargetMinimum_69;                                         // 0x00FC(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	float                                              TargetMaximum_69;                                         // 0x0100(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	EEasingFuncType                                    EasingType_69;                                            // 0x0104(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData03[0x3];                                       // 0x0105(0x0003) MISSED OFFSET
	struct FRuntimeFloatCurve                          CustomCurve_69;                                           // 0x0108(0x0088) (Edit)
	bool                                               bFlipEasing_69;                                           // 0x0190(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData04[0x3];                                       // 0x0191(0x0003) MISSED OFFSET
	float                                              EasingWeight_69;                                          // 0x0194(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	bool                                               bClamp_69;                                                // 0x0198(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData05[0x7];                                       // 0x0199(0x0007) MISSED OFFSET
};

// ScriptStruct AnimGraphRuntime.AnimNode_BlendSpacePlayerBase
// 0x0030 (0x0068 - 0x0038)
struct FAnimNode_BlendSpacePlayerBase : public FAnimNode_AssetPlayerBase
{
	unsigned char                                      UnknownData00[0x28];                                      // 0x0038(0x0028) MISSED OFFSET
	class BlendSpace*                                  PreviousBlendSpace_69;                                    // 0x0060(0x0008) (ZeroConstructor, Transient)
};

// ScriptStruct AnimGraphRuntime.AnimNode_BlendSpacePlayer
// 0x0000 (0x0068 - 0x0068)
struct FAnimNode_BlendSpacePlayer : public FAnimNode_BlendSpacePlayerBase
{

};

// ScriptStruct AnimGraphRuntime.AnimNode_AimOffsetLookAt
// 0x0158 (0x01C0 - 0x0068)
struct FAnimNode_AimOffsetLookAt : public FAnimNode_BlendSpacePlayer
{
	unsigned char                                      UnknownData00[0xC8];                                      // 0x0068(0x00C8) MISSED OFFSET
	struct FPoseLink                                   BasePose_69;                                              // 0x0130(0x0010) (Edit, BlueprintVisible)
	int                                                LODThreshold_69;                                          // 0x0140(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FName                                       SourceSocketName_69;                                      // 0x0144(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FName                                       PivotSocketName_69;                                       // 0x0148(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x4];                                       // 0x014C(0x0004) MISSED OFFSET
	struct FVector                                     LookAtLocation_69;                                        // 0x0150(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FVector                                     SocketAxis_69;                                            // 0x0168(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              Alpha_69;                                                 // 0x0180(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData02[0x3C];                                      // 0x0184(0x003C) MISSED OFFSET
};

// ScriptStruct AnimGraphRuntime.AnimNode_ApplyAdditive
// 0x00B8 (0x00C8 - 0x0010)
struct FAnimNode_ApplyAdditive : public FAnimNode_Base
{
	struct FPoseLink                                   Base_69;                                                  // 0x0010(0x0010) (Edit, BlueprintVisible)
	struct FPoseLink                                   Additive_69;                                              // 0x0020(0x0010) (Edit, BlueprintVisible)
	float                                              Alpha_69;                                                 // 0x0030(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FInputScaleBias                             AlphaScaleBias_69;                                        // 0x0034(0x0008) (Edit, BlueprintVisible)
	int                                                LODThreshold_69;                                          // 0x003C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FInputAlphaBoolBlend                        AlphaBoolBlend_69;                                        // 0x0040(0x0048) (Edit, BlueprintVisible)
	struct FName                                       AlphaCurveName_69;                                        // 0x0088(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FInputScaleBiasClamp                        AlphaScaleBiasClamp_69;                                   // 0x008C(0x0030) (Edit, BlueprintVisible)
	unsigned char                                      UnknownData00[0x4];                                       // 0x00BC(0x0004) MISSED OFFSET
	EAnimAlphaInputType                                AlphaInputType_69;                                        // 0x00C0(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bAlphaBoolEnabled_69;                                     // 0x00C1(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x6];                                       // 0x00C2(0x0006) MISSED OFFSET
};

// ScriptStruct AnimGraphRuntime.BlendBoneByChannelEntry
// 0x001C
struct FBlendBoneByChannelEntry
{
	struct FBoneReference                              SourceBone_69;                                            // 0x0000(0x000C) (Edit)
	struct FBoneReference                              TargetBone_69;                                            // 0x000C(0x000C) (Edit)
	bool                                               bBlendTranslation_69;                                     // 0x0018(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	bool                                               bBlendRotation_69;                                        // 0x0019(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	bool                                               bBlendScale_69;                                           // 0x001A(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x1];                                       // 0x001B(0x0001) MISSED OFFSET
};

// ScriptStruct AnimGraphRuntime.AnimNode_BlendBoneByChannel
// 0x0058 (0x0068 - 0x0010)
struct FAnimNode_BlendBoneByChannel : public FAnimNode_Base
{
	struct FPoseLink                                   A_69;                                                     // 0x0010(0x0010) (Edit, BlueprintVisible)
	struct FPoseLink                                   B_69;                                                     // 0x0020(0x0010) (Edit, BlueprintVisible)
	TArray<struct FBlendBoneByChannelEntry>            BoneDefinitions_69;                                       // 0x0030(0x0010) (Edit, ZeroConstructor)
	unsigned char                                      UnknownData00[0x10];                                      // 0x0040(0x0010) MISSED OFFSET
	float                                              Alpha_69;                                                 // 0x0050(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x4];                                       // 0x0054(0x0004) MISSED OFFSET
	struct FInputScaleBias                             AlphaScaleBias_69;                                        // 0x0058(0x0008) (Edit, BlueprintVisible)
	TEnumAsByte<EBoneControlSpace>                     TransformsSpace_69;                                       // 0x0060(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData02[0x7];                                       // 0x0061(0x0007) MISSED OFFSET
};

// ScriptStruct AnimGraphRuntime.AnimNode_BlendListBase
// 0x0038 (0x0048 - 0x0010)
struct FAnimNode_BlendListBase : public FAnimNode_Base
{
	TArray<struct FPoseLink>                           BlendPose_69;                                             // 0x0010(0x0010) (Edit, EditFixedSize, ZeroConstructor)
	unsigned char                                      UnknownData00[0x28];                                      // 0x0020(0x0028) MISSED OFFSET
};

// ScriptStruct AnimGraphRuntime.AnimNode_BlendListByBool
// 0x0000 (0x0048 - 0x0048)
struct FAnimNode_BlendListByBool : public FAnimNode_BlendListBase
{

};

// ScriptStruct AnimGraphRuntime.AnimNode_BlendListByEnum
// 0x0000 (0x0048 - 0x0048)
struct FAnimNode_BlendListByEnum : public FAnimNode_BlendListBase
{

};

// ScriptStruct AnimGraphRuntime.AnimNode_BlendListByInt
// 0x0000 (0x0048 - 0x0048)
struct FAnimNode_BlendListByInt : public FAnimNode_BlendListBase
{

};

// ScriptStruct AnimGraphRuntime.AnimNode_BlendSpaceEvaluator
// 0x0008 (0x0070 - 0x0068)
struct FAnimNode_BlendSpaceEvaluator : public FAnimNode_BlendSpacePlayer
{
	float                                              NormalizedTime_69;                                        // 0x0068(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bTeleportToNormalizedTime_69;                             // 0x006C(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x006D(0x0003) MISSED OFFSET
};

// ScriptStruct AnimGraphRuntime.AnimNode_BlendSpacePlayer_Standalone
// 0x0028 (0x0090 - 0x0068)
struct FAnimNode_BlendSpacePlayer_Standalone : public FAnimNode_BlendSpacePlayerBase
{
	struct FName                                       GroupName_69;                                             // 0x0068(0x0008) (Edit, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<EAnimGroupRole>                        GroupRole_69;                                             // 0x006C(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	EAnimSyncMethod                                    Method_69;                                                // 0x006D(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	bool                                               bIgnoreForRelevancyTest_69;                               // 0x006E(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x1];                                       // 0x006F(0x0001) MISSED OFFSET
	float                                              X_69;                                                     // 0x0070(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	float                                              Y_69;                                                     // 0x0074(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	float                                              PlayRate_69;                                              // 0x0078(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	bool                                               bLoop_69;                                                 // 0x007C(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	bool                                               bResetPlayTimeWhenBlendSpaceChanges_69;                   // 0x007D(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x2];                                       // 0x007E(0x0002) MISSED OFFSET
	float                                              StartPosition_69;                                         // 0x0080(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData02[0x4];                                       // 0x0084(0x0004) MISSED OFFSET
	class BlendSpace*                                  BlendSpace_69;                                            // 0x0088(0x0008) (Edit, ZeroConstructor)
};

// ScriptStruct AnimGraphRuntime.AnimNode_CallFunction
// 0x0028 (0x0038 - 0x0010)
struct FAnimNode_CallFunction : public FAnimNode_Base
{
	struct FPoseLink                                   Source_69;                                                // 0x0010(0x0010) (Edit)
	unsigned char                                      UnknownData00[0x14];                                      // 0x0020(0x0014) MISSED OFFSET
	EAnimFunctionCallSite                              CallSite_69;                                              // 0x0034(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x3];                                       // 0x0020(0x0003) FIX WRONG TYPE SIZE OF PREVIOUS PROPERTY
};

// ScriptStruct AnimGraphRuntime.AnimNode_CopyPoseFromMesh
// 0x01C0 (0x01D0 - 0x0010)
struct FAnimNode_CopyPoseFromMesh : public FAnimNode_Base
{
	TWeakObjectPtr<class SkeletalMeshComponent>        SourceMeshComponent_69;                                   // 0x0010(0x0008) (BlueprintVisible, ExportObject, ZeroConstructor, Transient, InstancedReference, IsPlainOldData)
	unsigned char                                      bUseAttachedParent_69 : 1;                                // 0x0018(0x0001) (Edit, BlueprintVisible)
	unsigned char                                      bCopyCurves_69 : 1;                                       // 0x0018(0x0001) (Edit, BlueprintVisible)
	bool                                               bCopyCustomAttributes_69;                                 // 0x0019(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      bUseMeshPose_69 : 1;                                      // 0x001A(0x0001) (Edit, BlueprintVisible)
	unsigned char                                      UnknownData00[0x1];                                       // 0x001B(0x0001) MISSED OFFSET
	struct FName                                       RootBoneToCopy_69;                                        // 0x001C(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x1B0];                                     // 0x0020(0x01B0) MISSED OFFSET
};

// ScriptStruct AnimGraphRuntime.AnimNode_CurveSource
// 0x0028 (0x0038 - 0x0010)
struct FAnimNode_CurveSource : public FAnimNode_Base
{
	struct FPoseLink                                   SourcePose_69;                                            // 0x0010(0x0010) (Edit, BlueprintVisible)
	struct FName                                       SourceBinding_69;                                         // 0x0020(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              Alpha_69;                                                 // 0x0024(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	TScriptInterface<class CurveSourceInterface>       CurveSource_69;                                           // 0x0028(0x0010) (ZeroConstructor, Transient, IsPlainOldData)
};

// ScriptStruct AnimGraphRuntime.AnimNode_LayeredBoneBlend
// 0x00D0 (0x00E0 - 0x0010)
struct FAnimNode_LayeredBoneBlend : public FAnimNode_Base
{
	struct FPoseLink                                   BasePose_69;                                              // 0x0010(0x0010) (Edit, BlueprintVisible)
	TArray<struct FPoseLink>                           BlendPoses_69;                                            // 0x0020(0x0010) (Edit, BlueprintVisible, EditFixedSize, ZeroConstructor)
	ELayeredBoneBlendMode                              BlendMode_69;                                             // 0x0030(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0031(0x0007) MISSED OFFSET
	TArray<class BlendProfile*>                        BlendMasks_69;                                            // 0x0038(0x0010) (Edit, EditFixedSize, ZeroConstructor)
	TArray<struct FInputBlendPose>                     LayerSetup_69;                                            // 0x0048(0x0010) (Edit, EditFixedSize, ZeroConstructor)
	TArray<float>                                      BlendWeights_69;                                          // 0x0058(0x0010) (Edit, BlueprintVisible, EditFixedSize, ZeroConstructor)
	bool                                               bMeshSpaceRotationBlend_69;                               // 0x0068(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bMeshSpaceScaleBlend_69;                                  // 0x0069(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<ECurveBlendOption>                     CurveBlendOption_69;                                      // 0x006A(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bBlendRootMotionBasedOnRootBone_69;                       // 0x006B(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x4];                                       // 0x006C(0x0004) MISSED OFFSET
	int                                                LODThreshold_69;                                          // 0x0070(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData02[0x4];                                       // 0x0074(0x0004) MISSED OFFSET
	TArray<struct FPerBoneBlendWeight>                 PerBoneBlendWeights_69;                                   // 0x0078(0x0010) (ZeroConstructor)
	struct FGuid                                       SkeletonGuid_69;                                          // 0x0088(0x0010) (ZeroConstructor, IsPlainOldData)
	struct FGuid                                       VirtualBoneGuid_69;                                       // 0x0098(0x0010) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData03[0x38];                                      // 0x00A8(0x0038) MISSED OFFSET
};

// ScriptStruct AnimGraphRuntime.AnimNode_MakeDynamicAdditive
// 0x0028 (0x0038 - 0x0010)
struct FAnimNode_MakeDynamicAdditive : public FAnimNode_Base
{
	struct FPoseLink                                   Base_69;                                                  // 0x0010(0x0010) (Edit, BlueprintVisible)
	struct FPoseLink                                   Additive_69;                                              // 0x0020(0x0010) (Edit, BlueprintVisible)
	bool                                               bMeshSpaceAdditive_69;                                    // 0x0030(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0031(0x0007) MISSED OFFSET
};

// ScriptStruct AnimGraphRuntime.AnimNode_MirrorBase
// 0x0038 (0x0048 - 0x0010)
struct FAnimNode_MirrorBase : public FAnimNode_Base
{
	struct FPoseLink                                   Source_69;                                                // 0x0010(0x0010) (Edit)
	unsigned char                                      UnknownData00[0x28];                                      // 0x0020(0x0028) MISSED OFFSET
};

// ScriptStruct AnimGraphRuntime.AnimNode_Mirror
// 0x0000 (0x0048 - 0x0048)
struct FAnimNode_Mirror : public FAnimNode_MirrorBase
{

};

// ScriptStruct AnimGraphRuntime.AnimNode_Mirror_Standalone
// 0x0018 (0x0060 - 0x0048)
struct FAnimNode_Mirror_Standalone : public FAnimNode_MirrorBase
{
	bool                                               bMirror_69;                                               // 0x0048(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0049(0x0007) MISSED OFFSET
	class MirrorDataTable*                             MirrorDataTable_69;                                       // 0x0050(0x0008) (Edit, ZeroConstructor)
	float                                              BlendTime_69;                                             // 0x0058(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	bool                                               bResetChild_69;                                           // 0x005C(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	bool                                               bBoneMirroring_69;                                        // 0x005D(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	bool                                               bCurveMirroring_69;                                       // 0x005E(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	bool                                               bAttributeMirroring_69;                                   // 0x005F(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct AnimGraphRuntime.AnimNode_ModifyCurve
// 0x00F0 (0x0100 - 0x0010)
struct FAnimNode_ModifyCurve : public FAnimNode_Base
{
	struct FPoseLink                                   SourcePose_69;                                            // 0x0010(0x0010) (Edit, BlueprintVisible, EditFixedSize)
	TMap<struct FName, float>                          CurveMap_69;                                              // 0x0020(0x0050) (Edit, BlueprintVisible, EditFixedSize)
	TArray<float>                                      CurveValues_69;                                           // 0x0070(0x0010) (Edit, BlueprintVisible, EditFixedSize, ZeroConstructor)
	TArray<struct FName>                               CurveNames_69;                                            // 0x0080(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData00[0x64];                                      // 0x0090(0x0064) MISSED OFFSET
	float                                              Alpha_69;                                                 // 0x00F4(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	EModifyCurveApplyMode                              ApplyMode_69;                                             // 0x00F8(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x7];                                       // 0x00F9(0x0007) MISSED OFFSET
};

// ScriptStruct AnimGraphRuntime.AnimNode_MultiWayBlend
// 0x0040 (0x0050 - 0x0010)
struct FAnimNode_MultiWayBlend : public FAnimNode_Base
{
	TArray<struct FPoseLink>                           Poses_69;                                                 // 0x0010(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	TArray<float>                                      DesiredAlphas_69;                                         // 0x0020(0x0010) (Edit, BlueprintVisible, EditFixedSize, ZeroConstructor)
	unsigned char                                      UnknownData00[0x10];                                      // 0x0030(0x0010) MISSED OFFSET
	struct FInputScaleBias                             AlphaScaleBias_69;                                        // 0x0040(0x0008) (Edit, BlueprintVisible)
	bool                                               bAdditiveNode_69;                                         // 0x0048(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bNormalizeAlpha_69;                                       // 0x0049(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x6];                                       // 0x004A(0x0006) MISSED OFFSET
};

// ScriptStruct AnimGraphRuntime.AnimNode_PoseHandler
// 0x0058 (0x0090 - 0x0038)
struct FAnimNode_PoseHandler : public FAnimNode_AssetPlayerBase
{
	class PoseAsset*                                   PoseAsset_69;                                             // 0x0038(0x0008) (Edit, BlueprintVisible, ZeroConstructor)
	unsigned char                                      UnknownData00[0x50];                                      // 0x0040(0x0050) MISSED OFFSET
};

// ScriptStruct AnimGraphRuntime.AnimNode_PoseBlendNode
// 0x0020 (0x00B0 - 0x0090)
struct FAnimNode_PoseBlendNode : public FAnimNode_PoseHandler
{
	struct FPoseLink                                   SourcePose_69;                                            // 0x0090(0x0010) (Edit, BlueprintVisible, EditFixedSize)
	EAlphaBlendOption                                  BlendOption_69;                                           // 0x00A0(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x00A1(0x0007) MISSED OFFSET
	class CurveFloat*                                  CustomCurve_69;                                           // 0x00A8(0x0008) (Edit, ZeroConstructor)
};

// ScriptStruct AnimGraphRuntime.AnimNode_PoseByName
// 0x0010 (0x00A0 - 0x0090)
struct FAnimNode_PoseByName : public FAnimNode_PoseHandler
{
	struct FName                                       PoseName_69;                                              // 0x0090(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              PoseWeight_69;                                            // 0x0094(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x8];                                       // 0x0098(0x0008) MISSED OFFSET
};

// ScriptStruct AnimGraphRuntime.PoseDriverTransform
// 0x0030
struct FPoseDriverTransform
{
	struct FVector                                     TargetTranslation_69;                                     // 0x0000(0x0018) (Edit, ZeroConstructor, IsPlainOldData)
	struct FRotator                                    TargetRotation_69;                                        // 0x0018(0x0018) (Edit, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct AnimGraphRuntime.PoseDriverTarget
// 0x00C0
struct FPoseDriverTarget
{
	TArray<struct FPoseDriverTransform>                BoneTransforms_69;                                        // 0x0000(0x0010) (Edit, ZeroConstructor)
	struct FRotator                                    TargetRotation_69;                                        // 0x0010(0x0018) (Edit, ZeroConstructor, IsPlainOldData)
	float                                              TargetScale_69;                                           // 0x0028(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	ERBFDistanceMethod                                 DistanceMethod_69;                                        // 0x002C(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	ERBFFunctionType                                   FunctionType_69;                                          // 0x002D(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	bool                                               bApplyCustomCurve_69;                                     // 0x002E(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x1];                                       // 0x002F(0x0001) MISSED OFFSET
	struct FRichCurve                                  CustomCurve_69;                                           // 0x0030(0x0080) (Edit)
	struct FName                                       DrivenName_69;                                            // 0x00B0(0x0008) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x8];                                       // 0x00B4(0x0008) MISSED OFFSET
	bool                                               bIsHidden_69;                                             // 0x00BC(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData02[0x3];                                       // 0x00BD(0x0003) MISSED OFFSET
};

// ScriptStruct AnimGraphRuntime.RBFParams
// 0x0038
struct FRBFParams
{
	int                                                TargetDimensions_69;                                      // 0x0000(0x0004) (ZeroConstructor, IsPlainOldData)
	ERBFSolverType                                     SolverType_69;                                            // 0x0004(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0005(0x0003) MISSED OFFSET
	float                                              Radius_69;                                                // 0x0008(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bAutomaticRadius_69;                                      // 0x000C(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	ERBFFunctionType                                   Function_69;                                              // 0x000D(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	ERBFDistanceMethod                                 DistanceMethod_69;                                        // 0x000E(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<EBoneAxis>                             TwistAxis_69;                                             // 0x000F(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              WeightThreshold_69;                                       // 0x0010(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	ERBFNormalizeMethod                                NormalizeMethod_69;                                       // 0x0014(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x3];                                       // 0x0015(0x0003) MISSED OFFSET
	struct FVector                                     MedianReference_69;                                       // 0x0018(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              MedianMin_69;                                             // 0x0030(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              MedianMax_69;                                             // 0x0034(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct AnimGraphRuntime.AnimNode_PoseDriver
// 0x00F0 (0x0180 - 0x0090)
struct FAnimNode_PoseDriver : public FAnimNode_PoseHandler
{
	struct FPoseLink                                   SourcePose_69;                                            // 0x0090(0x0010) (Edit, BlueprintVisible, EditFixedSize)
	TArray<struct FBoneReference>                      SourceBones_69;                                           // 0x00A0(0x0010) (Edit, ZeroConstructor)
	TArray<struct FBoneReference>                      OnlyDriveBones_69;                                        // 0x00B0(0x0010) (Edit, ZeroConstructor)
	TArray<struct FPoseDriverTarget>                   PoseTargets_69;                                           // 0x00C0(0x0010) (Edit, ZeroConstructor)
	unsigned char                                      UnknownData00[0x30];                                      // 0x00D0(0x0030) MISSED OFFSET
	struct FBoneReference                              EvalSpaceBone_69;                                         // 0x0100(0x000C) (Edit)
	bool                                               bEvalFromRefPose_69;                                      // 0x010C(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x3];                                       // 0x010D(0x0003) MISSED OFFSET
	struct FRBFParams                                  RBFParams_69;                                             // 0x0110(0x0038) (Edit)
	EPoseDriverSource                                  DriveSource_69;                                           // 0x0148(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	EPoseDriverOutput                                  DriveOutput_69;                                           // 0x0149(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      bOnlyDriveSelectedBones_69 : 1;                           // 0x014A(0x0001) (Edit)
	unsigned char                                      UnknownData02[0x1];                                       // 0x014B(0x0001) MISSED OFFSET
	int                                                LODThreshold_69;                                          // 0x014C(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData03[0x30];                                      // 0x0150(0x0030) MISSED OFFSET
};

// ScriptStruct AnimGraphRuntime.AnimNode_PoseSnapshot
// 0x0070 (0x0080 - 0x0010)
struct FAnimNode_PoseSnapshot : public FAnimNode_Base
{
	struct FName                                       SnapshotName_69;                                          // 0x0010(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0014(0x0004) MISSED OFFSET
	struct FPoseSnapshot                               Snapshot_69;                                              // 0x0018(0x0030) (Edit, BlueprintVisible)
	ESnapshotSourceMode                                Mode_69;                                                  // 0x0048(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x37];                                      // 0x0049(0x0037) MISSED OFFSET
};

// ScriptStruct AnimGraphRuntime.AnimNode_RotateRootBone
// 0x0098 (0x00A8 - 0x0010)
struct FAnimNode_RotateRootBone : public FAnimNode_Base
{
	struct FPoseLink                                   BasePose_69;                                              // 0x0010(0x0010) (Edit, BlueprintVisible)
	float                                              Pitch_69;                                                 // 0x0020(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              Yaw_69;                                                   // 0x0024(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FInputScaleBiasClamp                        PitchScaleBiasClamp_69;                                   // 0x0028(0x0030) (Edit, BlueprintVisible)
	struct FInputScaleBiasClamp                        YawScaleBiasClamp_69;                                     // 0x0058(0x0030) (Edit, BlueprintVisible)
	struct FRotator                                    MeshToComponent_69;                                       // 0x0088(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x8];                                       // 0x00A0(0x0008) MISSED OFFSET
};

// ScriptStruct AnimGraphRuntime.AnimNode_RotationOffsetBlendSpace
// 0x00A8 (0x0110 - 0x0068)
struct FAnimNode_RotationOffsetBlendSpace : public FAnimNode_BlendSpacePlayer
{
	struct FPoseLink                                   BasePose_69;                                              // 0x0068(0x0010) (Edit, BlueprintVisible)
	int                                                LODThreshold_69;                                          // 0x0078(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              Alpha_69;                                                 // 0x007C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FInputScaleBias                             AlphaScaleBias_69;                                        // 0x0080(0x0008) (Edit, BlueprintVisible)
	struct FInputAlphaBoolBlend                        AlphaBoolBlend_69;                                        // 0x0088(0x0048) (Edit, BlueprintVisible)
	struct FName                                       AlphaCurveName_69;                                        // 0x00D0(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FInputScaleBiasClamp                        AlphaScaleBiasClamp_69;                                   // 0x00D4(0x0030) (Edit, BlueprintVisible)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0104(0x0004) MISSED OFFSET
	EAnimAlphaInputType                                AlphaInputType_69;                                        // 0x0108(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bAlphaBoolEnabled_69;                                     // 0x0109(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x6];                                       // 0x010A(0x0006) MISSED OFFSET
};

// ScriptStruct AnimGraphRuntime.AnimNode_RotationOffsetBlendSpaceGraph
// 0x00A8 (0x0108 - 0x0060)
struct FAnimNode_RotationOffsetBlendSpaceGraph : public FAnimNode_BlendSpaceGraphBase
{
	struct FPoseLink                                   BasePose_69;                                              // 0x0060(0x0010) (Edit, BlueprintVisible)
	int                                                LODThreshold_69;                                          // 0x0070(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              Alpha_69;                                                 // 0x0074(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FInputScaleBias                             AlphaScaleBias_69;                                        // 0x0078(0x0008) (Edit, BlueprintVisible)
	struct FInputAlphaBoolBlend                        AlphaBoolBlend_69;                                        // 0x0080(0x0048) (Edit, BlueprintVisible)
	struct FName                                       AlphaCurveName_69;                                        // 0x00C8(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FInputScaleBiasClamp                        AlphaScaleBiasClamp_69;                                   // 0x00CC(0x0030) (Edit, BlueprintVisible)
	unsigned char                                      UnknownData00[0x4];                                       // 0x00FC(0x0004) MISSED OFFSET
	EAnimAlphaInputType                                AlphaInputType_69;                                        // 0x0100(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bAlphaBoolEnabled_69;                                     // 0x0101(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x6];                                       // 0x0102(0x0006) MISSED OFFSET
};

// ScriptStruct AnimGraphRuntime.AnimNode_SequenceEvaluatorBase
// 0x0008 (0x0040 - 0x0038)
struct FAnimNode_SequenceEvaluatorBase : public FAnimNode_AssetPlayerBase
{
	unsigned char                                      UnknownData00[0x8];                                       // 0x0038(0x0008) MISSED OFFSET
};

// ScriptStruct AnimGraphRuntime.AnimNode_SequenceEvaluator
// 0x0000 (0x0040 - 0x0040)
struct FAnimNode_SequenceEvaluator : public FAnimNode_SequenceEvaluatorBase
{

};

// ScriptStruct AnimGraphRuntime.AnimNode_SequenceEvaluator_Standalone
// 0x0020 (0x0060 - 0x0040)
struct FAnimNode_SequenceEvaluator_Standalone : public FAnimNode_SequenceEvaluatorBase
{
	struct FName                                       GroupName_69;                                             // 0x0040(0x0008) (Edit, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<EAnimGroupRole>                        GroupRole_69;                                             // 0x0044(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	EAnimSyncMethod                                    Method_69;                                                // 0x0045(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	bool                                               bIgnoreForRelevancyTest_69;                               // 0x0046(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x1];                                       // 0x0047(0x0001) MISSED OFFSET
	class AnimSequenceBase*                            Sequence_69;                                              // 0x0048(0x0008) (Edit, ZeroConstructor)
	float                                              ExplicitTime_69;                                          // 0x0050(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	bool                                               bShouldLoop_69;                                           // 0x0054(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	bool                                               bTeleportToExplicitTime_69;                               // 0x0055(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<ESequenceEvalReinit>                   ReinitializationBehavior_69;                              // 0x0056(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x1];                                       // 0x0057(0x0001) MISSED OFFSET
	float                                              StartPosition_69;                                         // 0x0058(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData02[0x4];                                       // 0x005C(0x0004) MISSED OFFSET
};

// ScriptStruct AnimGraphRuntime.AnimNode_Slot
// 0x0038 (0x0048 - 0x0010)
struct FAnimNode_Slot : public FAnimNode_Base
{
	struct FPoseLink                                   Source_69;                                                // 0x0010(0x0010) (Edit, BlueprintVisible)
	struct FName                                       SlotName_69;                                              // 0x0020(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bAlwaysUpdateSourcePose_69;                               // 0x0024(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x23];                                      // 0x0025(0x0023) MISSED OFFSET
};

// ScriptStruct AnimGraphRuntime.AnimNode_Sync
// 0x0018 (0x0028 - 0x0010)
struct FAnimNode_Sync : public FAnimNode_Base
{
	struct FPoseLink                                   Source_69;                                                // 0x0010(0x0010) (Edit)
	struct FName                                       GroupName_69;                                             // 0x0020(0x0008) (Edit, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<EAnimGroupRole>                        GroupRole_69;                                             // 0x0024(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0025(0x0003) MISSED OFFSET
};

// ScriptStruct AnimGraphRuntime.AnimNode_TwoWayBlend
// 0x00B0 (0x00C0 - 0x0010)
struct FAnimNode_TwoWayBlend : public FAnimNode_Base
{
	struct FPoseLink                                   A_69;                                                     // 0x0010(0x0010) (Edit, BlueprintVisible)
	struct FPoseLink                                   B_69;                                                     // 0x0020(0x0010) (Edit, BlueprintVisible)
	EAnimAlphaInputType                                AlphaInputType_69;                                        // 0x0030(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      bAlphaBoolEnabled_69 : 1;                                 // 0x0031(0x0001) (Edit, BlueprintVisible)
	unsigned char                                      UnknownData00 : 2;                                        // 0x0031(0x0001)
	unsigned char                                      bResetChildOnActivation_69 : 1;                           // 0x0031(0x0001) (Edit)
	unsigned char                                      UnknownData01[0x2];                                       // 0x0032(0x0002) MISSED OFFSET
	float                                              Alpha_69;                                                 // 0x0034(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FInputScaleBias                             AlphaScaleBias_69;                                        // 0x0038(0x0008) (Edit, BlueprintVisible)
	struct FInputAlphaBoolBlend                        AlphaBoolBlend_69;                                        // 0x0040(0x0048) (Edit, BlueprintVisible)
	struct FName                                       AlphaCurveName_69;                                        // 0x0088(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FInputScaleBiasClamp                        AlphaScaleBiasClamp_69;                                   // 0x008C(0x0030) (Edit, BlueprintVisible)
	unsigned char                                      UnknownData02[0x4];                                       // 0x00BC(0x0004) MISSED OFFSET
};

// ScriptStruct AnimGraphRuntime.AnimSequencerInstanceProxy
// 0x0400 (0x0C80 - 0x0880)
struct FAnimSequencerInstanceProxy : public FAnimInstanceProxy
{
	unsigned char                                      UnknownData00[0x400];                                     // 0x0880(0x0400) MISSED OFFSET
};

// ScriptStruct AnimGraphRuntime.AnimPhysConstraintSetup
// 0x0088
struct FAnimPhysConstraintSetup
{
	EAnimPhysLinearConstraintType                      LinearXLimitType_69;                                      // 0x0000(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	EAnimPhysLinearConstraintType                      LinearYLimitType_69;                                      // 0x0001(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	EAnimPhysLinearConstraintType                      LinearZLimitType_69;                                      // 0x0002(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x5];                                       // 0x0003(0x0005) MISSED OFFSET
	struct FVector                                     LinearAxesMin_69;                                         // 0x0008(0x0018) (Edit, ZeroConstructor, IsPlainOldData)
	struct FVector                                     LinearAxesMax_69;                                         // 0x0020(0x0018) (Edit, ZeroConstructor, IsPlainOldData)
	EAnimPhysAngularConstraintType                     AngularConstraintType_69;                                 // 0x0038(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	EAnimPhysTwistAxis                                 TwistAxis_69;                                             // 0x0039(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	EAnimPhysTwistAxis                                 AngularTargetAxis_69;                                     // 0x003A(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x1];                                       // 0x003B(0x0001) MISSED OFFSET
	float                                              ConeAngle_69;                                             // 0x003C(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	struct FVector                                     AngularLimitsMin_69;                                      // 0x0040(0x0018) (Edit, ZeroConstructor, IsPlainOldData)
	struct FVector                                     AngularLimitsMax_69;                                      // 0x0058(0x0018) (Edit, ZeroConstructor, IsPlainOldData)
	struct FVector                                     AngularTarget_69;                                         // 0x0070(0x0018) (Edit, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct AnimGraphRuntime.AnimPhysPlanarLimit
// 0x0070
struct FAnimPhysPlanarLimit
{
	struct FBoneReference                              DrivingBone_69;                                           // 0x0000(0x000C) (Edit)
	unsigned char                                      UnknownData00[0x4];                                       // 0x000C(0x0004) MISSED OFFSET
	struct FCoreUObject_FTransform                     PlaneTransform_69;                                        // 0x0010(0x0060) (Edit, IsPlainOldData)
};

// ScriptStruct AnimGraphRuntime.AnimPhysSphericalLimit
// 0x0030
struct FAnimPhysSphericalLimit
{
	struct FBoneReference                              DrivingBone_69;                                           // 0x0000(0x000C) (Edit)
	unsigned char                                      UnknownData00[0x4];                                       // 0x000C(0x0004) MISSED OFFSET
	struct FVector                                     SphereLocalOffset_69;                                     // 0x0010(0x0018) (Edit, ZeroConstructor, IsPlainOldData)
	float                                              LimitRadius_69;                                           // 0x0028(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	ESphericalLimitType                                LimitType_69;                                             // 0x002C(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x3];                                       // 0x002D(0x0003) MISSED OFFSET
};

// ScriptStruct AnimGraphRuntime.AnimPhysBodyDefinition
// 0x00D0
struct FAnimPhysBodyDefinition
{
	struct FBoneReference                              BoundBone_69;                                             // 0x0000(0x000C) (Edit, EditConst)
	unsigned char                                      UnknownData00[0x4];                                       // 0x000C(0x0004) MISSED OFFSET
	struct FVector                                     BoxExtents_69;                                            // 0x0010(0x0018) (Edit, ZeroConstructor, IsPlainOldData)
	struct FVector                                     LocalJointOffset_69;                                      // 0x0028(0x0018) (Edit, ZeroConstructor, IsPlainOldData)
	struct FAnimPhysConstraintSetup                    ConstraintSetup_69;                                       // 0x0040(0x0088) (Edit)
	EAnimPhysCollisionType                             CollisionType_69;                                         // 0x00C8(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x3];                                       // 0x00C9(0x0003) MISSED OFFSET
	float                                              SphereCollisionRadius_69;                                 // 0x00CC(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct AnimGraphRuntime.AnimNode_AnimDynamics
// 0x0448 (0x0510 - 0x00C8)
struct FAnimNode_AnimDynamics : public FAnimNode_SkeletalControlBase
{
	float                                              LinearDampingOverride_69;                                 // 0x00C8(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              AngularDampingOverride_69;                                // 0x00CC(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0xC0];                                      // 0x00D0(0x00C0) MISSED OFFSET
	struct FBoneReference                              RelativeSpaceBone_69;                                     // 0x0190(0x000C) (Edit)
	struct FBoneReference                              BoundBone_69;                                             // 0x019C(0x000C) (Edit)
	struct FBoneReference                              ChainEnd_69;                                              // 0x01A8(0x000C) (Edit)
	unsigned char                                      UnknownData01[0x4];                                       // 0x01B4(0x0004) MISSED OFFSET
	TArray<struct FAnimPhysBodyDefinition>             PhysicsBodyDefinitions_69;                                // 0x01B8(0x0010) (Edit, EditFixedSize, ZeroConstructor)
	float                                              GravityScale_69;                                          // 0x01C8(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData02[0x4];                                       // 0x01CC(0x0004) MISSED OFFSET
	struct FVector                                     GravityOverride_69;                                       // 0x01D0(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              LinearSpringConstant_69;                                  // 0x01E8(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              AngularSpringConstant_69;                                 // 0x01EC(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              WindScale_69;                                             // 0x01F0(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData03[0x4];                                       // 0x01F4(0x0004) MISSED OFFSET
	struct FVector                                     ComponentLinearAccScale_69;                               // 0x01F8(0x0018) (Edit, ZeroConstructor, IsPlainOldData)
	struct FVector                                     ComponentLinearVelScale_69;                               // 0x0210(0x0018) (Edit, ZeroConstructor, IsPlainOldData)
	struct FVector                                     ComponentAppliedLinearAccClamp_69;                        // 0x0228(0x0018) (Edit, ZeroConstructor, IsPlainOldData)
	float                                              AngularBiasOverride_69;                                   // 0x0240(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                NumSolverIterationsPreUpdate_69;                          // 0x0244(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	int                                                NumSolverIterationsPostUpdate_69;                         // 0x0248(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData04[0x4];                                       // 0x024C(0x0004) MISSED OFFSET
	TArray<struct FAnimPhysSphericalLimit>             SphericalLimits_69;                                       // 0x0250(0x0010) (Edit, ZeroConstructor)
	struct FVector                                     ExternalForce_69;                                         // 0x0260(0x0018) (Edit, ZeroConstructor, IsPlainOldData)
	TArray<struct FAnimPhysPlanarLimit>                PlanarLimits_69;                                          // 0x0278(0x0010) (Edit, ZeroConstructor)
	EAnimPhysSimSpaceType                              SimulationSpace_69;                                       // 0x0288(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData05[0x2];                                       // 0x0289(0x0002) MISSED OFFSET
	unsigned char                                      bUseSphericalLimits_69 : 1;                               // 0x028B(0x0001) (Edit)
	unsigned char                                      bUsePlanarLimit_69 : 1;                                   // 0x028B(0x0001) (Edit)
	unsigned char                                      bDoUpdate_69 : 1;                                         // 0x028B(0x0001) (Edit)
	unsigned char                                      bDoEval_69 : 1;                                           // 0x028B(0x0001) (Edit)
	unsigned char                                      bOverrideLinearDamping_69 : 1;                            // 0x028B(0x0001) (Edit)
	unsigned char                                      bOverrideAngularBias_69 : 1;                              // 0x028B(0x0001) (Edit)
	unsigned char                                      bOverrideAngularDamping_69 : 1;                           // 0x028B(0x0001) (Edit)
	unsigned char                                      bEnableWind_69 : 1;                                       // 0x028B(0x0001) (Edit)
	unsigned char                                      UnknownData06 : 1;                                        // 0x028C(0x0001)
	unsigned char                                      bUseGravityOverride_69 : 1;                               // 0x028C(0x0001) (Edit, BlueprintVisible)
	unsigned char                                      bGravityOverrideInSimSpace_69 : 1;                        // 0x028C(0x0001) (Edit)
	unsigned char                                      bLinearSpring_69 : 1;                                     // 0x028C(0x0001) (Edit)
	unsigned char                                      bAngularSpring_69 : 1;                                    // 0x028C(0x0001) (Edit)
	unsigned char                                      bChain_69 : 1;                                            // 0x028C(0x0001) (Edit)
	unsigned char                                      UnknownData07[0x3];                                       // 0x028D(0x0003) MISSED OFFSET
	struct FRotationRetargetingInfo                    RetargetingSettings_69;                                   // 0x0290(0x01A0) (Edit)
	unsigned char                                      UnknownData08[0xE0];                                      // 0x0430(0x00E0) MISSED OFFSET
};

// ScriptStruct AnimGraphRuntime.AngularRangeLimit
// 0x0040
struct FAngularRangeLimit
{
	struct FVector                                     LimitMin_69;                                              // 0x0000(0x0018) (Edit, ZeroConstructor, IsPlainOldData)
	struct FVector                                     LimitMax_69;                                              // 0x0018(0x0018) (Edit, ZeroConstructor, IsPlainOldData)
	struct FBoneReference                              bone_69;                                                  // 0x0030(0x000C) (Edit)
	unsigned char                                      UnknownData00[0x4];                                       // 0x003C(0x0004) MISSED OFFSET
};

// ScriptStruct AnimGraphRuntime.AnimNode_ApplyLimits
// 0x0020 (0x00E8 - 0x00C8)
struct FAnimNode_ApplyLimits : public FAnimNode_SkeletalControlBase
{
	TArray<struct FAngularRangeLimit>                  AngularRangeLimits_69;                                    // 0x00C8(0x0010) (Edit, ZeroConstructor)
	TArray<struct FVector>                             AngularOffsets_69;                                        // 0x00D8(0x0010) (Edit, BlueprintVisible, EditFixedSize, ZeroConstructor)
};

// ScriptStruct AnimGraphRuntime.AnimNode_BoneDrivenController
// 0x0048 (0x0110 - 0x00C8)
struct FAnimNode_BoneDrivenController : public FAnimNode_SkeletalControlBase
{
	struct FBoneReference                              SourceBone_69;                                            // 0x00C8(0x000C) (Edit)
	unsigned char                                      UnknownData00[0x4];                                       // 0x00D4(0x0004) MISSED OFFSET
	class CurveFloat*                                  DrivingCurve_69;                                          // 0x00D8(0x0008) (Edit, ZeroConstructor)
	float                                              Multiplier_69;                                            // 0x00E0(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	float                                              RangeMin_69;                                              // 0x00E4(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	float                                              RangeMax_69;                                              // 0x00E8(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	float                                              RemappedMin_69;                                           // 0x00EC(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	float                                              RemappedMax_69;                                           // 0x00F0(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	struct FName                                       ParameterName_69;                                         // 0x00F4(0x0008) (Edit, ZeroConstructor, IsPlainOldData)
	struct FBoneReference                              TargetBone_69;                                            // 0x00F8(0x000C) (Edit)
	EDrivenDestinationMode                             DestinationMode_69;                                       // 0x0104(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	EDrivenBoneModificationMode                        ModificationMode_69;                                      // 0x0105(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<EComponentType>                        SourceComponent_69;                                       // 0x0106(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      bUseRange_69 : 1;                                         // 0x0107(0x0001) (Edit)
	unsigned char                                      bAffectTargetTranslationX_69 : 1;                         // 0x0107(0x0001) (Edit)
	unsigned char                                      bAffectTargetTranslationY_69 : 1;                         // 0x0107(0x0001) (Edit)
	unsigned char                                      bAffectTargetTranslationZ_69 : 1;                         // 0x0107(0x0001) (Edit)
	unsigned char                                      bAffectTargetRotationX_69 : 1;                            // 0x0107(0x0001) (Edit)
	unsigned char                                      bAffectTargetRotationY_69 : 1;                            // 0x0107(0x0001) (Edit)
	unsigned char                                      bAffectTargetRotationZ_69 : 1;                            // 0x0107(0x0001) (Edit)
	unsigned char                                      bAffectTargetScaleX_69 : 1;                               // 0x0107(0x0001) (Edit)
	unsigned char                                      bAffectTargetScaleY_69 : 1;                               // 0x0108(0x0001) (Edit)
	unsigned char                                      bAffectTargetScaleZ_69 : 1;                               // 0x0108(0x0001) (Edit)
	unsigned char                                      UnknownData01[0x7];                                       // 0x0109(0x0007) MISSED OFFSET
};

// ScriptStruct AnimGraphRuntime.AnimNode_CCDIK
// 0x00E8 (0x01B0 - 0x00C8)
struct FAnimNode_CCDIK : public FAnimNode_SkeletalControlBase
{
	struct FVector                                     EffectorLocation_69;                                      // 0x00C8(0x0018) (Edit, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<EBoneControlSpace>                     EffectorLocationSpace_69;                                 // 0x00E0(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0xF];                                       // 0x00E1(0x000F) MISSED OFFSET
	struct FBoneSocketTarget                           EffectorTarget_69;                                        // 0x00F0(0x0080) (Edit)
	struct FBoneReference                              TipBone_69;                                               // 0x0170(0x000C) (Edit)
	struct FBoneReference                              RootBone_69;                                              // 0x017C(0x000C) (Edit)
	float                                              Precision_69;                                             // 0x0188(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	int                                                MaxIterations_69;                                         // 0x018C(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	bool                                               bStartFromTail_69;                                        // 0x0190(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	bool                                               bEnableRotationLimit_69;                                  // 0x0191(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x6];                                       // 0x0192(0x0006) MISSED OFFSET
	TArray<float>                                      RotationLimitPerJoints_69;                                // 0x0198(0x0010) (Edit, EditFixedSize, ZeroConstructor)
	unsigned char                                      UnknownData02[0x8];                                       // 0x01A8(0x0008) MISSED OFFSET
};

// ScriptStruct AnimGraphRuntime.Constraint
// 0x0018
struct FConstraint
{
	struct FBoneReference                              TargetBone_69;                                            // 0x0000(0x000C) (Edit)
	EConstraintOffsetOption                            OffsetOption_69;                                          // 0x000C(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	ETransformConstraintType                           TransformType_69;                                         // 0x000D(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	struct FFilterOptionPerAxis                        PerAxis_69;                                               // 0x000E(0x0003) (Edit)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0011(0x0007) MISSED OFFSET
};

// ScriptStruct AnimGraphRuntime.AnimNode_Constraint
// 0x0040 (0x0108 - 0x00C8)
struct FAnimNode_Constraint : public FAnimNode_SkeletalControlBase
{
	struct FBoneReference                              BoneToModify_69;                                          // 0x00C8(0x000C) (Edit)
	unsigned char                                      UnknownData00[0x4];                                       // 0x00D4(0x0004) MISSED OFFSET
	TArray<struct FConstraint>                         ConstraintSetup_69;                                       // 0x00D8(0x0010) (Edit, ZeroConstructor)
	TArray<float>                                      ConstraintWeights_69;                                     // 0x00E8(0x0010) (Edit, EditFixedSize, ZeroConstructor)
	unsigned char                                      UnknownData01[0x10];                                      // 0x00F8(0x0010) MISSED OFFSET
};

// ScriptStruct AnimGraphRuntime.AnimNode_CopyBone
// 0x0020 (0x00E8 - 0x00C8)
struct FAnimNode_CopyBone : public FAnimNode_SkeletalControlBase
{
	struct FBoneReference                              SourceBone_69;                                            // 0x00C8(0x000C) (Edit)
	struct FBoneReference                              TargetBone_69;                                            // 0x00D4(0x000C) (Edit)
	bool                                               bCopyTranslation_69;                                      // 0x00E0(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bCopyRotation_69;                                         // 0x00E1(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bCopyScale_69;                                            // 0x00E2(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<EBoneControlSpace>                     ControlSpace_69;                                          // 0x00E3(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x00E4(0x0004) MISSED OFFSET
};

// ScriptStruct AnimGraphRuntime.AnimNode_CopyBoneDelta
// 0x0028 (0x00F0 - 0x00C8)
struct FAnimNode_CopyBoneDelta : public FAnimNode_SkeletalControlBase
{
	struct FBoneReference                              SourceBone_69;                                            // 0x00C8(0x000C) (Edit)
	struct FBoneReference                              TargetBone_69;                                            // 0x00D4(0x000C) (Edit)
	bool                                               bCopyTranslation_69;                                      // 0x00E0(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bCopyRotation_69;                                         // 0x00E1(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bCopyScale_69;                                            // 0x00E2(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	ECopyBoneDeltaMode                                 CopyMode_69;                                              // 0x00E3(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	float                                              TranslationMultiplier_69;                                 // 0x00E4(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              RotationMultiplier_69;                                    // 0x00E8(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              ScaleMultiplier_69;                                       // 0x00EC(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct AnimGraphRuntime.AnimNode_Fabrik
// 0x0118 (0x01E0 - 0x00C8)
struct FAnimNode_Fabrik : public FAnimNode_SkeletalControlBase
{
	unsigned char                                      UnknownData00[0x8];                                       // 0x00C8(0x0008) MISSED OFFSET
	struct FCoreUObject_FTransform                     EffectorTransform_69;                                     // 0x00D0(0x0060) (Edit, BlueprintVisible, IsPlainOldData)
	struct FBoneSocketTarget                           EffectorTarget_69;                                        // 0x0130(0x0080) (Edit)
	struct FBoneReference                              TipBone_69;                                               // 0x01B0(0x000C) (Edit)
	struct FBoneReference                              RootBone_69;                                              // 0x01BC(0x000C) (Edit)
	float                                              Precision_69;                                             // 0x01C8(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	int                                                MaxIterations_69;                                         // 0x01CC(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<EBoneControlSpace>                     EffectorTransformSpace_69;                                // 0x01D0(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<EBoneRotationSource>                   EffectorRotationSource_69;                                // 0x01D1(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0xE];                                       // 0x01D2(0x000E) MISSED OFFSET
};

// ScriptStruct AnimGraphRuntime.AnimNode_HandIKRetargeting
// 0x0048 (0x0110 - 0x00C8)
struct FAnimNode_HandIKRetargeting : public FAnimNode_SkeletalControlBase
{
	struct FBoneReference                              RightHandFK_69;                                           // 0x00C8(0x000C) (Edit)
	struct FBoneReference                              LeftHandFK_69;                                            // 0x00D4(0x000C) (Edit)
	struct FBoneReference                              RightHandIK_69;                                           // 0x00E0(0x000C) (Edit)
	struct FBoneReference                              LeftHandIK_69;                                            // 0x00EC(0x000C) (Edit)
	TArray<struct FBoneReference>                      IKBonesToMove_69;                                         // 0x00F8(0x0010) (Edit, ZeroConstructor)
	float                                              HandFKWeight_69;                                          // 0x0108(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x010C(0x0004) MISSED OFFSET
};

// ScriptStruct AnimGraphRuntime.IKChainLink
// 0x0070
struct FIKChainLink
{
	unsigned char                                      UnknownData00[0x70];                                      // 0x0000(0x0070) MISSED OFFSET
};

// ScriptStruct AnimGraphRuntime.IKChain
// 0x0048
struct FIKChain
{
	unsigned char                                      UnknownData00[0x48];                                      // 0x0000(0x0048) MISSED OFFSET
};

// ScriptStruct AnimGraphRuntime.AnimLegIKDefinition
// 0x0024
struct FAnimLegIKDefinition
{
	struct FBoneReference                              IKFootBone_69;                                            // 0x0000(0x000C) (Edit)
	struct FBoneReference                              FKFootBone_69;                                            // 0x000C(0x000C) (Edit)
	int                                                NumBonesInLimb_69;                                        // 0x0018(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	float                                              MinRotationAngle_69;                                      // 0x001C(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<EAxis>                                 FootBoneForwardAxis_69;                                   // 0x0020(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<EAxis>                                 HingeRotationAxis_69;                                     // 0x0021(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	bool                                               bEnableRotationLimit_69;                                  // 0x0022(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	bool                                               bEnableKneeTwistCorrection_69;                            // 0x0023(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct AnimGraphRuntime.AnimLegIKData
// 0x00E0
struct FAnimLegIKData
{
	unsigned char                                      UnknownData00[0xE0];                                      // 0x0000(0x00E0) MISSED OFFSET
};

// ScriptStruct AnimGraphRuntime.AnimNode_LegIK
// 0x0030 (0x00F8 - 0x00C8)
struct FAnimNode_LegIK : public FAnimNode_SkeletalControlBase
{
	float                                              ReachPrecision_69;                                        // 0x00C8(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	int                                                MaxIterations_69;                                         // 0x00CC(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	TArray<struct FAnimLegIKDefinition>                LegsDefinition_69;                                        // 0x00D0(0x0010) (Edit, ZeroConstructor)
	unsigned char                                      UnknownData00[0x18];                                      // 0x00E0(0x0018) MISSED OFFSET
};

// ScriptStruct AnimGraphRuntime.AnimNode_ObserveBone
// 0x0058 (0x0120 - 0x00C8)
struct FAnimNode_ObserveBone : public FAnimNode_SkeletalControlBase
{
	struct FBoneReference                              BoneToObserve_69;                                         // 0x00C8(0x000C) (Edit)
	TEnumAsByte<EBoneControlSpace>                     DisplaySpace_69;                                          // 0x00D4(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	bool                                               bRelativeToRefPose_69;                                    // 0x00D5(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x2];                                       // 0x00D6(0x0002) MISSED OFFSET
	struct FVector                                     Translation_69;                                           // 0x00D8(0x0018) (ZeroConstructor, IsPlainOldData)
	struct FRotator                                    Rotation_69;                                              // 0x00F0(0x0018) (ZeroConstructor, IsPlainOldData)
	struct FVector                                     Scale_69;                                                 // 0x0108(0x0018) (ZeroConstructor, IsPlainOldData)
};

// ScriptStruct AnimGraphRuntime.AnimNode_ResetRoot
// 0x0010 (0x00D8 - 0x00C8)
struct FAnimNode_ResetRoot : public FAnimNode_SkeletalControlBase
{
	unsigned char                                      UnknownData00[0x10];                                      // 0x00C8(0x0010) MISSED OFFSET
};

// ScriptStruct AnimGraphRuntime.SimSpaceSettings
// 0x0068
struct FSimSpaceSettings
{
	float                                              MasterAlpha_69;                                           // 0x0000(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              VelocityScaleZ_69;                                        // 0x0004(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              MaxLinearVelocity_69;                                     // 0x0008(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              MaxAngularVelocity_69;                                    // 0x000C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              MaxLinearAcceleration_69;                                 // 0x0010(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              MaxAngularAcceleration_69;                                // 0x0014(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              ExternalLinearDrag_69;                                    // 0x0018(0x0004) (ZeroConstructor, Deprecated, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x001C(0x0004) MISSED OFFSET
	struct FVector                                     ExternalLinearDragV_69;                                   // 0x0020(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FVector                                     ExternalLinearVelocity_69;                                // 0x0038(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FVector                                     ExternalAngularVelocity_69;                               // 0x0050(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct AnimGraphRuntime.AnimNode_RigidBody
// 0x08C8 (0x0990 - 0x00C8)
struct FAnimNode_RigidBody : public FAnimNode_SkeletalControlBase
{
	class PhysicsAsset*                                OverridePhysicsAsset_69;                                  // 0x00C8(0x0008) (Edit, ZeroConstructor)
	unsigned char                                      UnknownData00[0x128];                                     // 0x00D0(0x0128) MISSED OFFSET
	struct FVector                                     OverrideWorldGravity_69;                                  // 0x01F8(0x0018) (Edit, ZeroConstructor, IsPlainOldData)
	struct FVector                                     ExternalForce_69;                                         // 0x0210(0x0018) (Edit, ZeroConstructor, IsPlainOldData)
	struct FVector                                     ComponentLinearAccScale_69;                               // 0x0228(0x0018) (Edit, ZeroConstructor, IsPlainOldData)
	struct FVector                                     ComponentLinearVelScale_69;                               // 0x0240(0x0018) (Edit, ZeroConstructor, IsPlainOldData)
	struct FVector                                     ComponentAppliedLinearAccClamp_69;                        // 0x0258(0x0018) (Edit, ZeroConstructor, IsPlainOldData)
	struct FSimSpaceSettings                           SimSpaceSettings_69;                                      // 0x0270(0x0068) (Edit)
	float                                              CachedBoundsScale_69;                                     // 0x02D8(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	struct FBoneReference                              BaseBoneRef_69;                                           // 0x02DC(0x000C) (Edit)
	TEnumAsByte<ECollisionChannel>                     OverlapChannel_69;                                        // 0x02E8(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	ESimulationSpace                                   SimulationSpace_69;                                       // 0x02E9(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	bool                                               bForceDisableCollisionBetweenConstraintBodies_69;         // 0x02EA(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	bool                                               bUseExternalClothCollision_69;                            // 0x02EB(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x1];                                       // 0x02EC(0x0001) MISSED OFFSET
	unsigned char                                      bEnableWorldGeometry_69 : 1;                              // 0x02ED(0x0001) (Edit)
	unsigned char                                      bOverrideWorldGravity_69 : 1;                             // 0x02ED(0x0001) (Edit)
	unsigned char                                      bTransferBoneVelocities_69 : 1;                           // 0x02ED(0x0001) (Edit)
	unsigned char                                      bFreezeIncomingPoseOnStart_69 : 1;                        // 0x02ED(0x0001) (Edit)
	unsigned char                                      bClampLinearTranslationLimitToRefPose_69 : 1;             // 0x02ED(0x0001) (Edit)
	unsigned char                                      UnknownData02[0x2];                                       // 0x02EE(0x0002) MISSED OFFSET
	float                                              WorldSpaceMinimumScale_69;                                // 0x02F0(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	float                                              EvaluationResetTime_69;                                   // 0x02F4(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData03[0x1];                                       // 0x02F8(0x0001) MISSED OFFSET
	ESimulationTiming                                  SimulationTiming_69;                                      // 0x02F9(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData04[0x696];                                     // 0x02FA(0x0696) MISSED OFFSET
};

// ScriptStruct AnimGraphRuntime.AnimNode_ScaleChainLength
// 0x0070 (0x0080 - 0x0010)
struct FAnimNode_ScaleChainLength : public FAnimNode_Base
{
	struct FPoseLink                                   InputPose_69;                                             // 0x0010(0x0010) (Edit)
	float                                              DefaultChainLength_69;                                    // 0x0020(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FBoneReference                              ChainStartBone_69;                                        // 0x0024(0x000C) (Edit)
	struct FBoneReference                              ChainEndBone_69;                                          // 0x0030(0x000C) (Edit)
	unsigned char                                      UnknownData00[0x4];                                       // 0x003C(0x0004) MISSED OFFSET
	struct FVector                                     TargetLocation_69;                                        // 0x0040(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              Alpha_69;                                                 // 0x0058(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x4];                                       // 0x005C(0x0004) MISSED OFFSET
	struct FInputScaleBias                             AlphaScaleBias_69;                                        // 0x0060(0x0008) (Edit)
	EScaleChainInitialLength                           ChainInitialLength_69;                                    // 0x0068(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData02[0x17];                                      // 0x0069(0x0017) MISSED OFFSET
};

// ScriptStruct AnimGraphRuntime.SplineIKCachedBoneData
// 0x0010
struct FSplineIKCachedBoneData
{
	struct FBoneReference                              bone_69;                                                  // 0x0000(0x000C)
	int                                                RefSkeletonIndex_69;                                      // 0x000C(0x0004) (ZeroConstructor, IsPlainOldData)
};

// ScriptStruct AnimGraphRuntime.AnimNode_SplineIK
// 0x01A0 (0x0268 - 0x00C8)
struct FAnimNode_SplineIK : public FAnimNode_SkeletalControlBase
{
	struct FBoneReference                              StartBone_69;                                             // 0x00C8(0x000C) (Edit)
	struct FBoneReference                              EndBone_69;                                               // 0x00D4(0x000C) (Edit)
	ESplineBoneAxis                                    BoneAxis_69;                                              // 0x00E0(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	bool                                               bAutoCalculateSpline_69;                                  // 0x00E1(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x2];                                       // 0x00E2(0x0002) MISSED OFFSET
	int                                                PointCount_69;                                            // 0x00E4(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	TArray<struct FCoreUObject_FTransform>             ControlPoints_69;                                         // 0x00E8(0x0010) (Edit, BlueprintVisible, EditFixedSize, ZeroConstructor)
	float                                              Roll_69;                                                  // 0x00F8(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              TwistStart_69;                                            // 0x00FC(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              TwistEnd_69;                                              // 0x0100(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x4];                                       // 0x0104(0x0004) MISSED OFFSET
	struct FAlphaBlend                                 TwistBlend_69;                                            // 0x0108(0x0030) (Edit)
	float                                              Stretch_69;                                               // 0x0138(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              Offset_69;                                                // 0x013C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData02[0x128];                                     // 0x0140(0x0128) MISSED OFFSET
};

// ScriptStruct AnimGraphRuntime.AnimNode_SpringBone
// 0x0090 (0x0158 - 0x00C8)
struct FAnimNode_SpringBone : public FAnimNode_SkeletalControlBase
{
	struct FBoneReference                              SpringBone_69;                                            // 0x00C8(0x000C) (Edit)
	float                                              MaxDisplacement_69;                                       // 0x00D4(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              SpringStiffness_69;                                       // 0x00D8(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	float                                              SpringDamping_69;                                         // 0x00DC(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	float                                              ErrorResetThresh_69;                                      // 0x00E0(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x70];                                      // 0x00E4(0x0070) MISSED OFFSET
	unsigned char                                      bLimitDisplacement_69 : 1;                                // 0x0154(0x0001) (Edit)
	unsigned char                                      bTranslateX_69 : 1;                                       // 0x0154(0x0001) (Edit)
	unsigned char                                      bTranslateY_69 : 1;                                       // 0x0154(0x0001) (Edit)
	unsigned char                                      bTranslateZ_69 : 1;                                       // 0x0154(0x0001) (Edit)
	unsigned char                                      bRotateX_69 : 1;                                          // 0x0154(0x0001) (Edit)
	unsigned char                                      bRotateY_69 : 1;                                          // 0x0154(0x0001) (Edit)
	unsigned char                                      bRotateZ_69 : 1;                                          // 0x0154(0x0001) (Edit)
	unsigned char                                      UnknownData01[0x3];                                       // 0x0155(0x0003) MISSED OFFSET
};

// ScriptStruct AnimGraphRuntime.RotationLimit
// 0x0030
struct FRotationLimit
{
	struct FVector                                     LimitMin_69;                                              // 0x0000(0x0018) (Edit, ZeroConstructor, IsPlainOldData)
	struct FVector                                     LimitMax_69;                                              // 0x0018(0x0018) (Edit, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct AnimGraphRuntime.AnimNode_Trail
// 0x01D8 (0x02A0 - 0x00C8)
struct FAnimNode_Trail : public FAnimNode_SkeletalControlBase
{
	unsigned char                                      UnknownData00[0x68];                                      // 0x00C8(0x0068) MISSED OFFSET
	struct FBoneReference                              TrailBone_69;                                             // 0x0130(0x000C) (Edit)
	int                                                ChainLength_69;                                           // 0x013C(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<EAxis>                                 ChainBoneAxis_69;                                         // 0x0140(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      bInvertChainBoneAxis_69 : 1;                              // 0x0141(0x0001) (Edit)
	unsigned char                                      bLimitStretch_69 : 1;                                     // 0x0141(0x0001) (Edit)
	unsigned char                                      bLimitRotation_69 : 1;                                    // 0x0141(0x0001) (Edit)
	unsigned char                                      bUsePlanarLimit_69 : 1;                                   // 0x0141(0x0001) (Edit)
	unsigned char                                      bActorSpaceFakeVel_69 : 1;                                // 0x0141(0x0001) (Edit)
	unsigned char                                      bReorientParentToChild_69 : 1;                            // 0x0141(0x0001) (Edit)
	unsigned char                                      UnknownData01[0x2];                                       // 0x0142(0x0002) MISSED OFFSET
	float                                              MaxDeltaTime_69;                                          // 0x0144(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	float                                              RelaxationSpeedScale_69;                                  // 0x0148(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData02[0x4];                                       // 0x014C(0x0004) MISSED OFFSET
	struct FRuntimeFloatCurve                          TrailRelaxationSpeed_69;                                  // 0x0150(0x0088) (Edit)
	struct FInputScaleBiasClamp                        RelaxationSpeedScaleInputProcessor_69;                    // 0x01D8(0x0030) (Edit, BlueprintVisible)
	TArray<struct FRotationLimit>                      RotationLimits_69;                                        // 0x0208(0x0010) (Edit, EditFixedSize, ZeroConstructor)
	TArray<struct FVector>                             RotationOffsets_69;                                       // 0x0218(0x0010) (Edit, BlueprintVisible, EditFixedSize, ZeroConstructor)
	TArray<struct FAnimPhysPlanarLimit>                PlanarLimits_69;                                          // 0x0228(0x0010) (Edit, ZeroConstructor)
	float                                              StretchLimit_69;                                          // 0x0238(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData03[0x4];                                       // 0x023C(0x0004) MISSED OFFSET
	struct FVector                                     FakeVelocity_69;                                          // 0x0240(0x0018) (Edit, ZeroConstructor, IsPlainOldData)
	struct FBoneReference                              BaseJoint_69;                                             // 0x0258(0x000C) (Edit)
	float                                              LastBoneRotationAnimAlphaBlend_69;                        // 0x0264(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData04[0x38];                                      // 0x0268(0x0038) MISSED OFFSET
};

// ScriptStruct AnimGraphRuntime.ReferenceBoneFrame
// 0x0030
struct FReferenceBoneFrame
{
	struct FBoneReference                              bone_69;                                                  // 0x0000(0x000C) (Edit)
	unsigned char                                      UnknownData00[0x4];                                       // 0x000C(0x0004) MISSED OFFSET
	struct FAxis                                       Axis_69;                                                  // 0x0010(0x0020) (Edit)
};

// ScriptStruct AnimGraphRuntime.AnimNode_TwistCorrectiveNode
// 0x00A0 (0x0168 - 0x00C8)
struct FAnimNode_TwistCorrectiveNode : public FAnimNode_SkeletalControlBase
{
	struct FReferenceBoneFrame                         BaseFrame_69;                                             // 0x00C8(0x0030) (Edit)
	struct FReferenceBoneFrame                         TwistFrame_69;                                            // 0x00F8(0x0030) (Edit)
	struct FAxis                                       TwistPlaneNormalAxis_69;                                  // 0x0128(0x0020) (Edit)
	float                                              RangeMax_69;                                              // 0x0148(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	float                                              RemappedMin_69;                                           // 0x014C(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	float                                              RemappedMax_69;                                           // 0x0150(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	struct FAnimCurveParam                             Curve_69;                                                 // 0x0154(0x0008) (Edit)
	unsigned char                                      UnknownData00[0xC];                                       // 0x015C(0x000C) MISSED OFFSET
};

// ScriptStruct AnimGraphRuntime.AnimNode_TwoBoneIK
// 0x0188 (0x0250 - 0x00C8)
struct FAnimNode_TwoBoneIK : public FAnimNode_SkeletalControlBase
{
	struct FBoneReference                              IKBone_69;                                                // 0x00C8(0x000C) (Edit)
	float                                              StartStretchRatio_69;                                     // 0x00D4(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	float                                              MaxStretchScale_69;                                       // 0x00D8(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x00DC(0x0004) MISSED OFFSET
	struct FVector                                     EffectorLocation_69;                                      // 0x00E0(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x8];                                       // 0x00F8(0x0008) MISSED OFFSET
	struct FBoneSocketTarget                           EffectorTarget_69;                                        // 0x0100(0x0080) (Edit)
	struct FVector                                     JointTargetLocation_69;                                   // 0x0180(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData02[0x8];                                       // 0x0198(0x0008) MISSED OFFSET
	struct FBoneSocketTarget                           JointTarget_69;                                           // 0x01A0(0x0080) (Edit)
	struct FAxis                                       TwistAxis_69;                                             // 0x0220(0x0020) (Edit)
	TEnumAsByte<EBoneControlSpace>                     EffectorLocationSpace_69;                                 // 0x0240(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<EBoneControlSpace>                     JointTargetLocationSpace_69;                              // 0x0241(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      bAllowStretching_69 : 1;                                  // 0x0242(0x0001) (Edit)
	unsigned char                                      bTakeRotationFromEffectorSpace_69 : 1;                    // 0x0242(0x0001) (Edit)
	unsigned char                                      bMaintainEffectorRelRot_69 : 1;                           // 0x0242(0x0001) (Edit)
	unsigned char                                      bAllowTwist_69 : 1;                                       // 0x0242(0x0001) (Edit)
	unsigned char                                      UnknownData03[0xD];                                       // 0x0243(0x000D) MISSED OFFSET
};

// ScriptStruct AnimGraphRuntime.IKFootPelvisPullDownSolver
// 0x0070
struct FIKFootPelvisPullDownSolver
{
	struct FVectorRK4SpringInterpolator                PelvisAdjustmentInterp_69;                                // 0x0000(0x0008) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x58];                                      // 0x0008(0x0058) MISSED OFFSET
	float                                              PelvisAdjustmentInterpAlpha_69;                           // 0x0060(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	float                                              PelvisAdjustmentMaxDistance_69;                           // 0x0064(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	float                                              PelvisAdjustmentErrorTolerance_69;                        // 0x0068(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	int                                                PelvisAdjustmentMaxIter_69;                               // 0x006C(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct AnimGraphRuntime.WarpingVectorValue
// 0x0020
struct FWarpingVectorValue
{
	EWarpingVectorMode                                 Mode_69;                                                  // 0x0000(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0001(0x0007) MISSED OFFSET
	struct FVector                                     Value_69;                                                 // 0x0008(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct AnimGraphRuntime.RBFEntry
// 0x0010
struct FRBFEntry
{
	TArray<float>                                      Values_69;                                                // 0x0000(0x0010) (Edit, ZeroConstructor)
};

// ScriptStruct AnimGraphRuntime.RBFTarget
// 0x0090 (0x00A0 - 0x0010)
struct FRBFTarget : public FRBFEntry
{
	float                                              ScaleFactor_69;                                           // 0x0010(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	bool                                               bApplyCustomCurve_69;                                     // 0x0014(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0015(0x0003) MISSED OFFSET
	struct FRichCurve                                  CustomCurve_69;                                           // 0x0018(0x0080) (Edit)
	ERBFDistanceMethod                                 DistanceMethod_69;                                        // 0x0098(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	ERBFFunctionType                                   FunctionType_69;                                          // 0x0099(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x6];                                       // 0x009A(0x0006) MISSED OFFSET
};

// ScriptStruct AnimGraphRuntime.AnimNode_StateResult
// 0x0000 (0x0020 - 0x0020)
struct FAnimNode_StateResult : public FAnimNode_Root
{

};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function DeploymentConsole.DeploymentConsoleComponent.SpawnAircrafts
struct DeploymentConsoleComponent_SpawnAircrafts_Params
{
	bool                                               bSpawnAircraftForEachTeam_69;                             // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	TArray<struct FDeploymentConsoleAircraftData>      ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function DeploymentConsole.DeploymentConsoleComponent.SpawnAircraft
struct DeploymentConsoleComponent_SpawnAircraft_Params
{
	int                                                FlightIndex_69;                                           // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	class FortAthenaAircraft*                          ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function DeploymentConsole.DeploymentConsoleComponent.SetupTeamSpawnPoints
struct DeploymentConsoleComponent_SetupTeamSpawnPoints_Params
{
	bool                                               bGroupTeams_69;                                           // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function DeploymentConsole.DeploymentConsoleComponent.SetAircraftLock
struct DeploymentConsoleComponent_SetAircraftLock_Params
{
	bool                                               bIsLocked_69;                                             // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function DeploymentConsole.DeploymentConsoleComponent.SetAircraftDropZone
struct DeploymentConsoleComponent_SetAircraftDropZone_Params
{
	struct FBox2D                                      InDropZone_69;                                            // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
};

// Function DeploymentConsole.DeploymentConsoleComponent.RetrievePlayerSpawnLocation
struct DeploymentConsoleComponent_RetrievePlayerSpawnLocation_Params
{
	bool                                               bIsGameInProgress_69;                                     // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bGroupTeams_69;                                           // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	unsigned char                                      InTeam_69;                                                // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	struct FVector2D                                   ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function DeploymentConsole.DeploymentConsoleComponent.MoveBoxTo
struct DeploymentConsoleComponent_MoveBoxTo_Params
{
	struct FBox2D                                      InBox_69;                                                 // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
	struct FVector2D                                   VectorToMoveTo_69;                                        // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
	struct FBox2D                                      ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function DeploymentConsole.DeploymentConsoleComponent.InitializeFlightPath
struct DeploymentConsoleComponent_InitializeFlightPath_Params
{
	class FortGameStateAthena*                         GSA_69;                                                   // (Parm, ZeroConstructor)
	struct FAircraftFlightConstructionInfo             FlightPathConstructionInfo_69;                            // (ConstParm, Parm, OutParm, ReferenceParm)
};

// Function DeploymentConsole.DeploymentConsoleComponent.GetTeamSpawnData
struct DeploymentConsoleComponent_GetTeamSpawnData_Params
{
	TArray<struct FDeploymentConsoleTeamData>          ReturnValue_69;                                           // (ConstParm, Parm, OutParm, ZeroConstructor, ReturnParm, ReferenceParm)
};

// Function DeploymentConsole.DeploymentConsoleComponent.GetSpawnPoints
struct DeploymentConsoleComponent_GetSpawnPoints_Params
{
	TArray<struct FVector2D>                           ReturnValue_69;                                           // (ConstParm, Parm, OutParm, ZeroConstructor, ReturnParm, ReferenceParm)
};

// Function DeploymentConsole.DeploymentConsoleComponent.GetMinigameTeamsWithPlayers
struct DeploymentConsoleComponent_GetMinigameTeamsWithPlayers_Params
{
	class FortMinigame*                                InMinigame_69;                                            // (ConstParm, Parm, ZeroConstructor)
	TArray<unsigned char>                              ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function DeploymentConsole.DeploymentConsoleComponent.GetMapInfo
struct DeploymentConsoleComponent_GetMapInfo_Params
{
	class FortAthenaMapInfo*                           ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function DeploymentConsole.DeploymentConsoleComponent.GetDefaultFlightPathConstructionInfo
struct DeploymentConsoleComponent_GetDefaultFlightPathConstructionInfo_Params
{
	class FortGameStateAthena*                         GameStateAthena_69;                                       // (ConstParm, Parm, ZeroConstructor)
	EAirCraftBehavior                                  AirCraftBehavior_69;                                      // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	struct FAircraftFlightConstructionInfo             ReturnValue_69;                                           // (Parm, OutParm, ReturnParm)
};

// Function DeploymentConsole.DeploymentConsoleComponent.GetCachedAircraftSpawnZone
struct DeploymentConsoleComponent_GetCachedAircraftSpawnZone_Params
{
	struct FBox2D                                      ReturnValue_69;                                           // (ConstParm, Parm, OutParm, ZeroConstructor, ReturnParm, ReferenceParm, IsPlainOldData)
};

// Function DeploymentConsole.DeploymentConsoleComponent.ForcePlayerEnterAircraft
struct DeploymentConsoleComponent_ForcePlayerEnterAircraft_Params
{
	class FortPlayerControllerAthena*                  InController_69;                                          // (Parm, ZeroConstructor)
	class FortAthenaAircraft*                          InAircraft_69;                                            // (Parm, ZeroConstructor)
};

// Function DeploymentConsole.DeploymentConsoleComponent.ConstructInventoryOnController
struct DeploymentConsoleComponent_ConstructInventoryOnController_Params
{
	class FortPlayerControllerAthena*                  InController_69;                                          // (Parm, ZeroConstructor)
};

// Function DeploymentConsole.DeploymentConsoleComponent.ClearFlightInfos
struct DeploymentConsoleComponent_ClearFlightInfos_Params
{
};

// Function DeploymentConsole.DeploymentConsoleComponent.CalculateSpawnRotationFromLocation
struct DeploymentConsoleComponent_CalculateSpawnRotationFromLocation_Params
{
	struct FVector                                     InSpawnLocation_69;                                       // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
	struct FRotator                                    ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function DeploymentConsole.DeploymentConsoleComponent.AdjustLocationToValidHeight
struct DeploymentConsoleComponent_AdjustLocationToValidHeight_Params
{
	struct FVector                                     RespawnLocation_69;                                       // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
	struct FVector                                     ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

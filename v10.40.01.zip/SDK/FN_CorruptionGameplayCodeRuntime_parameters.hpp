#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function CorruptionGameplayCodeRuntime.WarEffortFundingLibrary.WriteTextToBuffer
struct WarEffortFundingLibrary_WriteTextToBuffer_Params
{
	struct FText                                       Text_69;                                                  // (ConstParm, Parm, OutParm, ReferenceParm)
	struct FString                                     ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function CorruptionGameplayCodeRuntime.WarEffortFundingLibrary.IsOption2ChoiceWinner
struct WarEffortFundingLibrary_IsOption2ChoiceWinner_Params
{
	struct FWarEffortFundingMetadata                   MetaData_69;                                              // (ConstParm, Parm, OutParm, ReferenceParm)
	int                                                ChoiceIndex_69;                                           // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CorruptionGameplayCodeRuntime.WarEffortFundingLibrary.IsOption1ChoiceWinner
struct WarEffortFundingLibrary_IsOption1ChoiceWinner_Params
{
	struct FWarEffortFundingMetadata                   MetaData_69;                                              // (ConstParm, Parm, OutParm, ReferenceParm)
	int                                                ChoiceIndex_69;                                           // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CorruptionGameplayCodeRuntime.WarEffortFundingLibrary.IsIndexFunded
struct WarEffortFundingLibrary_IsIndexFunded_Params
{
	struct FWarEffortFundingMetadata                   MetaData_69;                                              // (ConstParm, Parm, OutParm, ReferenceParm)
	int                                                Index_69;                                                 // (Parm, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<EWarEffortFundingStationType>          StationType_69;                                           // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CorruptionGameplayCodeRuntime.WarEffortFundingLibrary.GetIndexFundedPercent
struct WarEffortFundingLibrary_GetIndexFundedPercent_Params
{
	struct FWarEffortFundingMetadata                   MetaData_69;                                              // (ConstParm, Parm, OutParm, ReferenceParm)
	int                                                Index_69;                                                 // (Parm, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<EWarEffortFundingStationType>          StationType_69;                                           // (Parm, ZeroConstructor, IsPlainOldData)
	float                                              ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CorruptionGameplayCodeRuntime.WarEffortFundingLibrary.DoesChoiceHaveWinner
struct WarEffortFundingLibrary_DoesChoiceHaveWinner_Params
{
	struct FWarEffortFundingMetadata                   MetaData_69;                                              // (ConstParm, Parm, OutParm, ReferenceParm)
	int                                                ChoiceIndex_69;                                           // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CorruptionGameplayCodeRuntime.WarEffortFundingLibrary.AdjustDonation
struct WarEffortFundingLibrary_AdjustDonation_Params
{
	int                                                DonationAmount_69;                                        // (Parm, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<EWarEffortFundingStationType>          StationType_69;                                           // (Parm, ZeroConstructor, IsPlainOldData)
	int                                                ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CorruptionGameplayCodeRuntime.CorruptionCoverageMap.UpdateCorruptionCoverageMap
struct CorruptionCoverageMap_UpdateCorruptionCoverageMap_Params
{
	class Object_32759*                                WorldContextObject_69;                                    // (Parm, ZeroConstructor)
	class TextureRenderTarget2D*                       CorruptionRenderTarget_69;                                // (Parm, ZeroConstructor)
	struct FVector                                     InTopLeftWorldCoordinate_69;                              // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
	struct FVector                                     InBottomRightWorldCoordinate_69;                          // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
	float                                              CoverageThreshold_69;                                     // (Parm, ZeroConstructor, IsPlainOldData)
	float                                              DebugDrawDuration_69;                                     // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CorruptionGameplayCodeRuntime.CorruptionCoverageMap.IsLocationCorrupted
struct CorruptionCoverageMap_IsLocationCorrupted_Params
{
	struct FVector                                     Location_69;                                              // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
	float                                              Padding_69;                                               // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CorruptionGameplayCodeRuntime.CubeMovementStaticPath.EditorGetCorruptionGenerationData
struct CubeMovementStaticPath_EditorGetCorruptionGenerationData_Params
{
	struct FCubeMovement_CorruptionGenerationData      OutData_69;                                               // (Parm, OutParm)
};

// Function CorruptionGameplayCodeRuntime.CubeMovementStaticPath.ClearAllGeneratedSplinesAndLockedData
struct CubeMovementStaticPath_ClearAllGeneratedSplinesAndLockedData_Params
{
};

// Function CorruptionGameplayCodeRuntime.FortAthenaMutator_WarEffort.SetTryBeforeYouBuyItemState
struct FortAthenaMutator_WarEffort_SetTryBeforeYouBuyItemState_Params
{
	struct FGameplayTag                                ItemFundingTag_69;                                        // (Parm)
	bool                                               bIsActive_69;                                             // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function CorruptionGameplayCodeRuntime.FortAthenaMutator_WarEffort.SetItemFundedState
struct FortAthenaMutator_WarEffort_SetItemFundedState_Params
{
	struct FGameplayTag                                ItemFundingTag_69;                                        // (Parm)
	bool                                               bIsActive_69;                                             // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function CorruptionGameplayCodeRuntime.FortAthenaMutator_WarEffort.SetItemFundedPercent
struct FortAthenaMutator_WarEffort_SetItemFundedPercent_Params
{
	struct FGameplayTag                                ItemFundingTag_69;                                        // (Parm)
	float                                              FundingPercent_69;                                        // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function CorruptionGameplayCodeRuntime.FortAthenaMutator_WarEffort.SetItemFundedAmount
struct FortAthenaMutator_WarEffort_SetItemFundedAmount_Params
{
	struct FGameplayTag                                ItemFundingTag_69;                                        // (Parm)
	int64_t                                            CurrentFundingAmount_69;                                  // (Parm, ZeroConstructor, IsPlainOldData)
	int64_t                                            TargetFundingAmount_69;                                   // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function CorruptionGameplayCodeRuntime.FortAthenaMutator_WarEffort.SetFundingManagerReady
struct FortAthenaMutator_WarEffort_SetFundingManagerReady_Params
{
	bool                                               bIsReady_69;                                              // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function CorruptionGameplayCodeRuntime.FortAthenaMutator_WarEffort.OnRep_PreloadedItemList
struct FortAthenaMutator_WarEffort_OnRep_PreloadedItemList_Params
{
};

// Function CorruptionGameplayCodeRuntime.WarEffortMeshActor.OnRep_CurrentFundingData
struct WarEffortMeshActor_OnRep_CurrentFundingData_Params
{
};

// Function CorruptionGameplayCodeRuntime.WarEffortMeshActor.OnRep_ActiveTryBeforeYouBuyItems
struct WarEffortMeshActor_OnRep_ActiveTryBeforeYouBuyItems_Params
{
};

// Function CorruptionGameplayCodeRuntime.WarEffortMeshActor.OnRep_ActiveFundedItems
struct WarEffortMeshActor_OnRep_ActiveFundedItems_Params
{
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

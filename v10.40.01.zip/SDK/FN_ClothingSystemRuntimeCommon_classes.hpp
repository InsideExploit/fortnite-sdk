#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Classes
//---------------------------------------------------------------------------

// Class ClothingSystemRuntimeCommon.ClothConfigCommon
// 0x0000 (0x0028 - 0x0028)
class ClothConfigCommon : public ClothConfigBase
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class ClothingSystemRuntimeCommon.ClothConfigCommon"));
		
		return ptr;
	}

};


// Class ClothingSystemRuntimeCommon.ClothSharedConfigCommon
// 0x0000 (0x0028 - 0x0028)
class ClothSharedConfigCommon : public ClothConfigCommon
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class ClothingSystemRuntimeCommon.ClothSharedConfigCommon"));
		
		return ptr;
	}

};


// Class ClothingSystemRuntimeCommon.ClothingAssetCustomData
// 0x0000 (0x0028 - 0x0028)
class ClothingAssetCustomData : public Object_32759
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class ClothingSystemRuntimeCommon.ClothingAssetCustomData"));
		
		return ptr;
	}

};


// Class ClothingSystemRuntimeCommon.ClothingAssetCommon
// 0x00A8 (0x00F0 - 0x0048)
class ClothingAssetCommon : public ClothingAssetBase
{
public:
	class PhysicsAsset*                                PhysicsAsset_69;                                          // 0x0048(0x0008) (Edit, ZeroConstructor)
	TMap<struct FName, class ClothConfigBase*>         ClothConfigs_69;                                          // 0x0050(0x0050) (Edit, BlueprintVisible, ExportObject, BlueprintReadOnly, EditFixedSize, EditConst)
	TArray<struct FClothLODDataCommon>                 LodData_69;                                               // 0x00A0(0x0010) (ZeroConstructor)
	TArray<int>                                        LodMap_69;                                                // 0x00B0(0x0010) (ZeroConstructor)
	TArray<struct FName>                               UsedBoneNames_69;                                         // 0x00C0(0x0010) (ZeroConstructor)
	TArray<int>                                        UsedBoneIndices_69;                                       // 0x00D0(0x0010) (ZeroConstructor)
	int                                                ReferenceBoneIndex_69;                                    // 0x00E0(0x0004) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x00E4(0x0004) MISSED OFFSET
	class ClothingAssetCustomData*                     CustomData_69;                                            // 0x00E8(0x0008) (ZeroConstructor)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class ClothingSystemRuntimeCommon.ClothingAssetCommon"));
		
		return ptr;
	}

};


// Class ClothingSystemRuntimeCommon.ClothLODDataCommon_Legacy
// 0x0140 (0x0168 - 0x0028)
class ClothLODDataCommon_Legacy : public Object_32759
{
public:
	class ClothPhysicalMeshDataBase_Legacy*            PhysicalMeshData_69;                                      // 0x0028(0x0008) (ZeroConstructor, Deprecated)
	struct FClothPhysicalMeshData                      ClothPhysicalMeshData_69;                                 // 0x0030(0x00D8)
	struct FClothCollisionData                         CollisionData_69;                                         // 0x0108(0x0040)
	unsigned char                                      UnknownData00[0x20];                                      // 0x0148(0x0020) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class ClothingSystemRuntimeCommon.ClothLODDataCommon_Legacy"));
		
		return ptr;
	}

};


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

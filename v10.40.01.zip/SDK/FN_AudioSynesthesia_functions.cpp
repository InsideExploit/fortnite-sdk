// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Functions
//---------------------------------------------------------------------------

// Function AudioSynesthesia.ConstantQNRT.GetNormalizedChannelConstantQAtTime
// (Final, Native, Public, HasOutParms, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// float                          InSeconds_69                   (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// int                            InChannel_69                   (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// TArray<float>                  OutConstantQ_69                (Parm, OutParm, ZeroConstructor)

void ConstantQNRT::GetNormalizedChannelConstantQAtTime(float InSeconds_69, int InChannel_69, TArray<float>* OutConstantQ_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioSynesthesia.ConstantQNRT.GetNormalizedChannelConstantQAtTime"));

	ConstantQNRT_GetNormalizedChannelConstantQAtTime_Params params;
	params.InSeconds_69 = InSeconds_69;
	params.InChannel_69 = InChannel_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (OutConstantQ_69 != nullptr)
		*OutConstantQ_69 = params.OutConstantQ_69;
}


// Function AudioSynesthesia.ConstantQNRT.GetChannelConstantQAtTime
// (Final, Native, Public, HasOutParms, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// float                          InSeconds_69                   (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// int                            InChannel_69                   (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// TArray<float>                  OutConstantQ_69                (Parm, OutParm, ZeroConstructor)

void ConstantQNRT::GetChannelConstantQAtTime(float InSeconds_69, int InChannel_69, TArray<float>* OutConstantQ_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioSynesthesia.ConstantQNRT.GetChannelConstantQAtTime"));

	ConstantQNRT_GetChannelConstantQAtTime_Params params;
	params.InSeconds_69 = InSeconds_69;
	params.InChannel_69 = InChannel_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (OutConstantQ_69 != nullptr)
		*OutConstantQ_69 = params.OutConstantQ_69;
}


// Function AudioSynesthesia.LoudnessNRT.GetNormalizedLoudnessAtTime
// (Final, Native, Public, HasOutParms, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// float                          InSeconds_69                   (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// float                          OutLoudness_69                 (Parm, OutParm, ZeroConstructor, IsPlainOldData)

void LoudnessNRT::GetNormalizedLoudnessAtTime(float InSeconds_69, float* OutLoudness_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioSynesthesia.LoudnessNRT.GetNormalizedLoudnessAtTime"));

	LoudnessNRT_GetNormalizedLoudnessAtTime_Params params;
	params.InSeconds_69 = InSeconds_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (OutLoudness_69 != nullptr)
		*OutLoudness_69 = params.OutLoudness_69;
}


// Function AudioSynesthesia.LoudnessNRT.GetNormalizedChannelLoudnessAtTime
// (Final, Native, Public, HasOutParms, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// float                          InSeconds_69                   (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// int                            InChannel_69                   (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// float                          OutLoudness_69                 (Parm, OutParm, ZeroConstructor, IsPlainOldData)

void LoudnessNRT::GetNormalizedChannelLoudnessAtTime(float InSeconds_69, int InChannel_69, float* OutLoudness_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioSynesthesia.LoudnessNRT.GetNormalizedChannelLoudnessAtTime"));

	LoudnessNRT_GetNormalizedChannelLoudnessAtTime_Params params;
	params.InSeconds_69 = InSeconds_69;
	params.InChannel_69 = InChannel_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (OutLoudness_69 != nullptr)
		*OutLoudness_69 = params.OutLoudness_69;
}


// Function AudioSynesthesia.LoudnessNRT.GetLoudnessAtTime
// (Final, Native, Public, HasOutParms, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// float                          InSeconds_69                   (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// float                          OutLoudness_69                 (Parm, OutParm, ZeroConstructor, IsPlainOldData)

void LoudnessNRT::GetLoudnessAtTime(float InSeconds_69, float* OutLoudness_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioSynesthesia.LoudnessNRT.GetLoudnessAtTime"));

	LoudnessNRT_GetLoudnessAtTime_Params params;
	params.InSeconds_69 = InSeconds_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (OutLoudness_69 != nullptr)
		*OutLoudness_69 = params.OutLoudness_69;
}


// Function AudioSynesthesia.LoudnessNRT.GetChannelLoudnessAtTime
// (Final, Native, Public, HasOutParms, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// float                          InSeconds_69                   (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// int                            InChannel_69                   (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// float                          OutLoudness_69                 (Parm, OutParm, ZeroConstructor, IsPlainOldData)

void LoudnessNRT::GetChannelLoudnessAtTime(float InSeconds_69, int InChannel_69, float* OutLoudness_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioSynesthesia.LoudnessNRT.GetChannelLoudnessAtTime"));

	LoudnessNRT_GetChannelLoudnessAtTime_Params params;
	params.InSeconds_69 = InSeconds_69;
	params.InChannel_69 = InChannel_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (OutLoudness_69 != nullptr)
		*OutLoudness_69 = params.OutLoudness_69;
}


// Function AudioSynesthesia.OnsetNRT.GetNormalizedChannelOnsetsBetweenTimes
// (Final, Native, Public, HasOutParms, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// float                          InStartSeconds_69              (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// float                          InEndSeconds_69                (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// int                            InChannel_69                   (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// TArray<float>                  OutOnsetTimestamps_69          (Parm, OutParm, ZeroConstructor)
// TArray<float>                  OutOnsetStrengths_69           (Parm, OutParm, ZeroConstructor)

void OnsetNRT::GetNormalizedChannelOnsetsBetweenTimes(float InStartSeconds_69, float InEndSeconds_69, int InChannel_69, TArray<float>* OutOnsetTimestamps_69, TArray<float>* OutOnsetStrengths_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioSynesthesia.OnsetNRT.GetNormalizedChannelOnsetsBetweenTimes"));

	OnsetNRT_GetNormalizedChannelOnsetsBetweenTimes_Params params;
	params.InStartSeconds_69 = InStartSeconds_69;
	params.InEndSeconds_69 = InEndSeconds_69;
	params.InChannel_69 = InChannel_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (OutOnsetTimestamps_69 != nullptr)
		*OutOnsetTimestamps_69 = params.OutOnsetTimestamps_69;
	if (OutOnsetStrengths_69 != nullptr)
		*OutOnsetStrengths_69 = params.OutOnsetStrengths_69;
}


// Function AudioSynesthesia.OnsetNRT.GetChannelOnsetsBetweenTimes
// (Final, Native, Public, HasOutParms, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// float                          InStartSeconds_69              (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// float                          InEndSeconds_69                (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// int                            InChannel_69                   (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// TArray<float>                  OutOnsetTimestamps_69          (Parm, OutParm, ZeroConstructor)
// TArray<float>                  OutOnsetStrengths_69           (Parm, OutParm, ZeroConstructor)

void OnsetNRT::GetChannelOnsetsBetweenTimes(float InStartSeconds_69, float InEndSeconds_69, int InChannel_69, TArray<float>* OutOnsetTimestamps_69, TArray<float>* OutOnsetStrengths_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioSynesthesia.OnsetNRT.GetChannelOnsetsBetweenTimes"));

	OnsetNRT_GetChannelOnsetsBetweenTimes_Params params;
	params.InStartSeconds_69 = InStartSeconds_69;
	params.InEndSeconds_69 = InEndSeconds_69;
	params.InChannel_69 = InChannel_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (OutOnsetTimestamps_69 != nullptr)
		*OutOnsetTimestamps_69 = params.OutOnsetTimestamps_69;
	if (OutOnsetStrengths_69 != nullptr)
		*OutOnsetStrengths_69 = params.OutOnsetStrengths_69;
}


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

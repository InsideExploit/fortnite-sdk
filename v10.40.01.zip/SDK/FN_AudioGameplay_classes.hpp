#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Classes
//---------------------------------------------------------------------------

// Class AudioGameplay.AudioGameplayComponent
// 0x0008 (0x00A8 - 0x00A0)
class AudioGameplayComponent : public ActorComponent
{
public:
	unsigned char                                      UnknownData00[0x8];                                       // 0x00A0(0x0008) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AudioGameplay.AudioGameplayComponent"));
		
		return ptr;
	}

};


// Class AudioGameplay.AudioGameplayCondition
// 0x0000 (0x0028 - 0x0028)
class AudioGameplayCondition : public Interface
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AudioGameplay.AudioGameplayCondition"));
		
		return ptr;
	}


	bool ConditionMet_Position(const struct FVector& Position_69);
	bool ConditionMet();
};


// Class AudioGameplay.AudioGameplayVolumeInteraction
// 0x0000 (0x0028 - 0x0028)
class AudioGameplayVolumeInteraction : public Interface
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AudioGameplay.AudioGameplayVolumeInteraction"));
		
		return ptr;
	}


	void OnListenerExit();
	void OnListenerEnter();
};


// Class AudioGameplay.AudioRequirementPreset
// 0x0048 (0x0078 - 0x0030)
class AudioRequirementPreset : public DataAsset
{
public:
	struct FGameplayTagQuery                           Query_69;                                                 // 0x0030(0x0048) (Edit, BlueprintVisible)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AudioGameplay.AudioRequirementPreset"));
		
		return ptr;
	}

};


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

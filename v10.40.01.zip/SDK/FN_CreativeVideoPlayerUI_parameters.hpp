#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function CreativeVideoPlayerUI.CreativeVideoPlayerFullScreenWidget.OnSkipButtonActionProgress
struct CreativeVideoPlayerFullScreenWidget_OnSkipButtonActionProgress_Params
{
	float                                              HeldPercent_69;                                           // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function CreativeVideoPlayerUI.CreativeVideoPlayerFullScreenWidget.OnSkipButtonActionComplete
struct CreativeVideoPlayerFullScreenWidget_OnSkipButtonActionComplete_Params
{
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Functions
//---------------------------------------------------------------------------

// Function AnimNotifyState_HolsterWeapon.AnimNotifyState_HolsterWeapon_C.Received_NotifyEnd
// (Event, Public, HasOutParms, BlueprintCallable, BlueprintEvent, Const)
// Parameters:
// class SkeletalMeshComponent*   MeshComp_1                     (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, InstancedReference)
// class AnimSequenceBase*        Animation_1                    (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor)
// struct FAnimNotifyEventReference EventReference_1               (ConstParm, BlueprintVisible, BlueprintReadOnly, Parm, OutParm, ReferenceParm)
// bool                           ReturnValue_1                  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool AnimNotifyState_HolsterWeapon_C::Received_NotifyEnd(class SkeletalMeshComponent* MeshComp_1, class AnimSequenceBase* Animation_1, const struct FAnimNotifyEventReference& EventReference_1)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AnimNotifyState_HolsterWeapon.AnimNotifyState_HolsterWeapon_C.Received_NotifyEnd"));

	AnimNotifyState_HolsterWeapon_C_Received_NotifyEnd_Params params;
	params.MeshComp_1 = MeshComp_1;
	params.Animation_1 = Animation_1;
	params.EventReference_1 = EventReference_1;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_1;
}


// Function AnimNotifyState_HolsterWeapon.AnimNotifyState_HolsterWeapon_C.Received_NotifyBegin
// (Event, Public, HasOutParms, BlueprintCallable, BlueprintEvent, Const)
// Parameters:
// class SkeletalMeshComponent*   MeshComp_1                     (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, InstancedReference)
// class AnimSequenceBase*        Animation_1                    (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor)
// float                          TotalDuration_1                (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
// struct FAnimNotifyEventReference EventReference_1               (ConstParm, BlueprintVisible, BlueprintReadOnly, Parm, OutParm, ReferenceParm)
// bool                           ReturnValue_1                  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool AnimNotifyState_HolsterWeapon_C::Received_NotifyBegin(class SkeletalMeshComponent* MeshComp_1, class AnimSequenceBase* Animation_1, float TotalDuration_1, const struct FAnimNotifyEventReference& EventReference_1)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AnimNotifyState_HolsterWeapon.AnimNotifyState_HolsterWeapon_C.Received_NotifyBegin"));

	AnimNotifyState_HolsterWeapon_C_Received_NotifyBegin_Params params;
	params.MeshComp_1 = MeshComp_1;
	params.Animation_1 = Animation_1;
	params.TotalDuration_1 = TotalDuration_1;
	params.EventReference_1 = EventReference_1;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_1;
}


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

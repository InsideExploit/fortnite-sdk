#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function AdvancedWidgets.RadialSlider.SetValueTags
struct RadialSlider_SetValueTags_Params
{
	TArray<float>                                      InValueTags_69;                                           // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
};

// Function AdvancedWidgets.RadialSlider.SetValue
struct RadialSlider_SetValue_Params
{
	float                                              InValue_69;                                               // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function AdvancedWidgets.RadialSlider.SetUseVerticalDrag
struct RadialSlider_SetUseVerticalDrag_Params
{
	bool                                               InUseVerticalDrag_69;                                     // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function AdvancedWidgets.RadialSlider.SetStepSize
struct RadialSlider_SetStepSize_Params
{
	float                                              InValue_69;                                               // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function AdvancedWidgets.RadialSlider.SetSliderRange
struct RadialSlider_SetSliderRange_Params
{
	struct FRuntimeFloatCurve                          InSliderRange_69;                                         // (ConstParm, Parm, OutParm, ReferenceParm)
};

// Function AdvancedWidgets.RadialSlider.SetSliderProgressColor
struct RadialSlider_SetSliderProgressColor_Params
{
	struct FLinearColor                                InValue_69;                                               // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function AdvancedWidgets.RadialSlider.SetSliderHandleStartAngle
struct RadialSlider_SetSliderHandleStartAngle_Params
{
	float                                              InValue_69;                                               // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function AdvancedWidgets.RadialSlider.SetSliderHandleEndAngle
struct RadialSlider_SetSliderHandleEndAngle_Params
{
	float                                              InValue_69;                                               // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function AdvancedWidgets.RadialSlider.SetSliderHandleColor
struct RadialSlider_SetSliderHandleColor_Params
{
	struct FLinearColor                                InValue_69;                                               // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function AdvancedWidgets.RadialSlider.SetSliderBarColor
struct RadialSlider_SetSliderBarColor_Params
{
	struct FLinearColor                                InValue_69;                                               // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function AdvancedWidgets.RadialSlider.SetShowSliderHandle
struct RadialSlider_SetShowSliderHandle_Params
{
	bool                                               InShowSliderHandle_69;                                    // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function AdvancedWidgets.RadialSlider.SetShowSliderHand
struct RadialSlider_SetShowSliderHand_Params
{
	bool                                               InShowSliderHand_69;                                      // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function AdvancedWidgets.RadialSlider.SetLocked
struct RadialSlider_SetLocked_Params
{
	bool                                               InValue_69;                                               // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function AdvancedWidgets.RadialSlider.SetHandStartEndRatio
struct RadialSlider_SetHandStartEndRatio_Params
{
	struct FVector2D                                   InValue_69;                                               // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function AdvancedWidgets.RadialSlider.SetCustomDefaultValue
struct RadialSlider_SetCustomDefaultValue_Params
{
	float                                              InValue_69;                                               // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function AdvancedWidgets.RadialSlider.SetCenterBackgroundColor
struct RadialSlider_SetCenterBackgroundColor_Params
{
	struct FLinearColor                                InValue_69;                                               // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function AdvancedWidgets.RadialSlider.SetAngularOffset
struct RadialSlider_SetAngularOffset_Params
{
	float                                              InValue_69;                                               // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function AdvancedWidgets.RadialSlider.GetValue
struct RadialSlider_GetValue_Params
{
	float                                              ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AdvancedWidgets.RadialSlider.GetNormalizedSliderHandlePosition
struct RadialSlider_GetNormalizedSliderHandlePosition_Params
{
	float                                              ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AdvancedWidgets.RadialSlider.GetCustomDefaultValue
struct RadialSlider_GetCustomDefaultValue_Params
{
	float                                              ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

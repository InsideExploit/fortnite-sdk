#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Classes
//---------------------------------------------------------------------------

// Class AnimationBudgetAllocator.AnimationBudgetBlueprintLibrary
// 0x0000 (0x0028 - 0x0028)
class AnimationBudgetBlueprintLibrary : public BlueprintFunctionLibrary
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AnimationBudgetAllocator.AnimationBudgetBlueprintLibrary"));
		
		return ptr;
	}


	void STATIC_SetAnimationBudgetParameters(class Object_32759* WorldContextObject_69, const struct FAnimationBudgetAllocatorParameters& InParameters_69);
	void STATIC_EnableAnimationBudget(class Object_32759* WorldContextObject_69, bool bEnabled_69);
};


// Class AnimationBudgetAllocator.SkeletalMeshComponentBudgeted
// 0x0030 (0x0F40 - 0x0F10)
class SkeletalMeshComponentBudgeted : public SkeletalMeshComponent
{
public:
	unsigned char                                      UnknownData00[0x20];                                      // 0x0F10(0x0020) MISSED OFFSET
	unsigned char                                      bAutoRegisterWithBudgetAllocator_69 : 1;                  // 0x0F30(0x0001) (Edit, BlueprintVisible)
	unsigned char                                      bAutoCalculateSignificance_69 : 1;                        // 0x0F30(0x0001) (Edit)
	unsigned char                                      bShouldUseActorRenderedFlag_69 : 1;                       // 0x0F30(0x0001) (Edit)
	unsigned char                                      UnknownData01[0xF];                                       // 0x0F31(0x000F) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AnimationBudgetAllocator.SkeletalMeshComponentBudgeted"));
		
		return ptr;
	}


	void SetAutoRegisterWithBudgetAllocator(bool bInAutoRegisterWithBudgetAllocator_69);
};


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

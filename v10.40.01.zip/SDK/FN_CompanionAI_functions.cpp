// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Functions
//---------------------------------------------------------------------------

// Function CompanionAI.companion_ai.WaitForEntityMovement_L_Nentity_M_Nfloat_R
// (Public, HasOutParms, BlueprintCallable)
// Parameters:
// class task_t_*                 __verse_0xC1E81372_CallingTask (ExportObject, Parm, ZeroConstructor, InstancedReference)
// int64_t                        __verse_0xA3A00DDB_CallerResumeState (Parm, ZeroConstructor, IsPlainOldData)
// int64_t                        __verse_0x2AC0E4D8_CallerCancelState (Parm, ZeroConstructor, IsPlainOldData)
// struct Ftuple_Lentity_Mfloat_R __verse_0xB2CDDD72_Argument    (Parm)
// class task_t_*                 RetVal                         (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)

class task_t_* companion_ai::WaitForEntityMovement_L_Nentity_M_Nfloat_R(class task_t_* __verse_0xC1E81372_CallingTask, int64_t __verse_0xA3A00DDB_CallerResumeState, int64_t __verse_0x2AC0E4D8_CallerCancelState, const struct Ftuple_Lentity_Mfloat_R& __verse_0xB2CDDD72_Argument)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CompanionAI.companion_ai.WaitForEntityMovement_L_Nentity_M_Nfloat_R"));

	companion_ai_WaitForEntityMovement_L_Nentity_M_Nfloat_R_Params params;
	params.__verse_0xC1E81372_CallingTask = __verse_0xC1E81372_CallingTask;
	params.__verse_0xA3A00DDB_CallerResumeState = __verse_0xA3A00DDB_CallerResumeState;
	params.__verse_0x2AC0E4D8_CallerCancelState = __verse_0x2AC0E4D8_CallerCancelState;
	params.__verse_0xB2CDDD72_Argument = __verse_0xB2CDDD72_Argument;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.RetVal;
}


// Function CompanionAI.companion_ai.WaitForDamage
// (Public, HasOutParms, BlueprintCallable)
// Parameters:
// class task_t_*                 __verse_0xC1E81372_CallingTask (ExportObject, Parm, ZeroConstructor, InstancedReference)
// int64_t                        __verse_0xA3A00DDB_CallerResumeState (Parm, ZeroConstructor, IsPlainOldData)
// int64_t                        __verse_0x2AC0E4D8_CallerCancelState (Parm, ZeroConstructor, IsPlainOldData)
// struct FCompanionAI_Ftuple_L_R __verse_0xB2CDDD72_Argument    (Parm)
// class task_t_*                 RetVal                         (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)

class task_t_* companion_ai::WaitForDamage(class task_t_* __verse_0xC1E81372_CallingTask, int64_t __verse_0xA3A00DDB_CallerResumeState, int64_t __verse_0x2AC0E4D8_CallerCancelState, const struct FCompanionAI_Ftuple_L_R& __verse_0xB2CDDD72_Argument)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CompanionAI.companion_ai.WaitForDamage"));

	companion_ai_WaitForDamage_Params params;
	params.__verse_0xC1E81372_CallingTask = __verse_0xC1E81372_CallingTask;
	params.__verse_0xA3A00DDB_CallerResumeState = __verse_0xA3A00DDB_CallerResumeState;
	params.__verse_0x2AC0E4D8_CallerCancelState = __verse_0x2AC0E4D8_CallerCancelState;
	params.__verse_0xB2CDDD72_Argument = __verse_0xB2CDDD72_Argument;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.RetVal;
}


// Function CompanionAI.companion_ai.TacticalSprintService
// (Public, HasOutParms, BlueprintCallable)
// Parameters:
// class task_t_*                 __verse_0xC1E81372_CallingTask (ExportObject, Parm, ZeroConstructor, InstancedReference)
// int64_t                        __verse_0xA3A00DDB_CallerResumeState (Parm, ZeroConstructor, IsPlainOldData)
// int64_t                        __verse_0x2AC0E4D8_CallerCancelState (Parm, ZeroConstructor, IsPlainOldData)
// struct FCompanionAI_Ftuple_L_R __verse_0xB2CDDD72_Argument    (Parm)
// class task_t_*                 RetVal                         (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)

class task_t_* companion_ai::TacticalSprintService(class task_t_* __verse_0xC1E81372_CallingTask, int64_t __verse_0xA3A00DDB_CallerResumeState, int64_t __verse_0x2AC0E4D8_CallerCancelState, const struct FCompanionAI_Ftuple_L_R& __verse_0xB2CDDD72_Argument)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CompanionAI.companion_ai.TacticalSprintService"));

	companion_ai_TacticalSprintService_Params params;
	params.__verse_0xC1E81372_CallingTask = __verse_0xC1E81372_CallingTask;
	params.__verse_0xA3A00DDB_CallerResumeState = __verse_0xA3A00DDB_CallerResumeState;
	params.__verse_0x2AC0E4D8_CallerCancelState = __verse_0x2AC0E4D8_CallerCancelState;
	params.__verse_0xB2CDDD72_Argument = __verse_0xB2CDDD72_Argument;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.RetVal;
}


// Function CompanionAI.companion_ai.SprintService
// (Public, HasOutParms, BlueprintCallable)
// Parameters:
// class task_t_*                 __verse_0xC1E81372_CallingTask (ExportObject, Parm, ZeroConstructor, InstancedReference)
// int64_t                        __verse_0xA3A00DDB_CallerResumeState (Parm, ZeroConstructor, IsPlainOldData)
// int64_t                        __verse_0x2AC0E4D8_CallerCancelState (Parm, ZeroConstructor, IsPlainOldData)
// struct FCompanionAI_Ftuple_L_R __verse_0xB2CDDD72_Argument    (Parm)
// class task_t_*                 RetVal                         (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)

class task_t_* companion_ai::SprintService(class task_t_* __verse_0xC1E81372_CallingTask, int64_t __verse_0xA3A00DDB_CallerResumeState, int64_t __verse_0x2AC0E4D8_CallerCancelState, const struct FCompanionAI_Ftuple_L_R& __verse_0xB2CDDD72_Argument)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CompanionAI.companion_ai.SprintService"));

	companion_ai_SprintService_Params params;
	params.__verse_0xC1E81372_CallingTask = __verse_0xC1E81372_CallingTask;
	params.__verse_0xA3A00DDB_CallerResumeState = __verse_0xA3A00DDB_CallerResumeState;
	params.__verse_0x2AC0E4D8_CallerCancelState = __verse_0x2AC0E4D8_CallerCancelState;
	params.__verse_0xB2CDDD72_Argument = __verse_0xB2CDDD72_Argument;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.RetVal;
}


// Function CompanionAI.companion_ai.ShootTargetService_L_Nfloat_R
// (Public, HasOutParms, BlueprintCallable)
// Parameters:
// class task_t_*                 __verse_0xC1E81372_CallingTask (ExportObject, Parm, ZeroConstructor, InstancedReference)
// int64_t                        __verse_0xA3A00DDB_CallerResumeState (Parm, ZeroConstructor, IsPlainOldData)
// int64_t                        __verse_0x2AC0E4D8_CallerCancelState (Parm, ZeroConstructor, IsPlainOldData)
// double                         __verse_0xB2CDDD72_Argument    (Parm, ZeroConstructor, IsPlainOldData)
// class task_t_*                 RetVal                         (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)

class task_t_* companion_ai::ShootTargetService_L_Nfloat_R(class task_t_* __verse_0xC1E81372_CallingTask, int64_t __verse_0xA3A00DDB_CallerResumeState, int64_t __verse_0x2AC0E4D8_CallerCancelState, double __verse_0xB2CDDD72_Argument)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CompanionAI.companion_ai.ShootTargetService_L_Nfloat_R"));

	companion_ai_ShootTargetService_L_Nfloat_R_Params params;
	params.__verse_0xC1E81372_CallingTask = __verse_0xC1E81372_CallingTask;
	params.__verse_0xA3A00DDB_CallerResumeState = __verse_0xA3A00DDB_CallerResumeState;
	params.__verse_0x2AC0E4D8_CallerCancelState = __verse_0x2AC0E4D8_CallerCancelState;
	params.__verse_0xB2CDDD72_Argument = __verse_0xB2CDDD72_Argument;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.RetVal;
}


// Function CompanionAI.companion_ai.SetLeashPosition_L_Nvector3_M_Nfloat_M_Nentity_R
// (Public, HasOutParms, BlueprintCallable)
// Parameters:
// class task_t_*                 __verse_0xC1E81372_CallingTask (ExportObject, Parm, ZeroConstructor, InstancedReference)
// int64_t                        __verse_0xA3A00DDB_CallerResumeState (Parm, ZeroConstructor, IsPlainOldData)
// int64_t                        __verse_0x2AC0E4D8_CallerCancelState (Parm, ZeroConstructor, IsPlainOldData)
// struct Ftuple_Lvector3_Mfloat_Mentity_R __verse_0xB2CDDD72_Argument    (Parm)
// class task_t_*                 RetVal                         (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)

class task_t_* companion_ai::SetLeashPosition_L_Nvector3_M_Nfloat_M_Nentity_R(class task_t_* __verse_0xC1E81372_CallingTask, int64_t __verse_0xA3A00DDB_CallerResumeState, int64_t __verse_0x2AC0E4D8_CallerCancelState, const struct Ftuple_Lvector3_Mfloat_Mentity_R& __verse_0xB2CDDD72_Argument)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CompanionAI.companion_ai.SetLeashPosition_L_Nvector3_M_Nfloat_M_Nentity_R"));

	companion_ai_SetLeashPosition_L_Nvector3_M_Nfloat_M_Nentity_R_Params params;
	params.__verse_0xC1E81372_CallingTask = __verse_0xC1E81372_CallingTask;
	params.__verse_0xA3A00DDB_CallerResumeState = __verse_0xA3A00DDB_CallerResumeState;
	params.__verse_0x2AC0E4D8_CallerCancelState = __verse_0x2AC0E4D8_CallerCancelState;
	params.__verse_0xB2CDDD72_Argument = __verse_0xB2CDDD72_Argument;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.RetVal;
}


// Function CompanionAI.companion_ai.ReviveCommand_L_Nfort__character_R
// (Public, HasOutParms, BlueprintCallable)
// Parameters:
// class task_t_*                 __verse_0xC1E81372_CallingTask (ExportObject, Parm, ZeroConstructor, InstancedReference)
// int64_t                        __verse_0xA3A00DDB_CallerResumeState (Parm, ZeroConstructor, IsPlainOldData)
// int64_t                        __verse_0x2AC0E4D8_CallerCancelState (Parm, ZeroConstructor, IsPlainOldData)
// class Object_32759*            __verse_0xB2CDDD72_Argument    (ExportObject, Parm, ZeroConstructor, InstancedReference)
// class task_t_*                 RetVal                         (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)

class task_t_* companion_ai::ReviveCommand_L_Nfort__character_R(class task_t_* __verse_0xC1E81372_CallingTask, int64_t __verse_0xA3A00DDB_CallerResumeState, int64_t __verse_0x2AC0E4D8_CallerCancelState, class Object_32759* __verse_0xB2CDDD72_Argument)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CompanionAI.companion_ai.ReviveCommand_L_Nfort__character_R"));

	companion_ai_ReviveCommand_L_Nfort__character_R_Params params;
	params.__verse_0xC1E81372_CallingTask = __verse_0xC1E81372_CallingTask;
	params.__verse_0xA3A00DDB_CallerResumeState = __verse_0xA3A00DDB_CallerResumeState;
	params.__verse_0x2AC0E4D8_CallerCancelState = __verse_0x2AC0E4D8_CallerCancelState;
	params.__verse_0xB2CDDD72_Argument = __verse_0xB2CDDD72_Argument;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.RetVal;
}


// Function CompanionAI.companion_ai._L_2fFortnite_2ecom_2fAI_2fCompanionAI_2fcompanion__ai_N_ROnUnconverted
// (Public, HasDefaults, BlueprintCallable)
// Parameters:
// struct FCompanionAI_Ftuple_L_R __verse_0xB2CDDD72_Argument    (Parm)

void companion_ai::_L_2fFortnite_2ecom_2fAI_2fCompanionAI_2fcompanion__ai_N_ROnUnconverted(const struct FCompanionAI_Ftuple_L_R& __verse_0xB2CDDD72_Argument)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CompanionAI.companion_ai._L_2fFortnite_2ecom_2fAI_2fCompanionAI_2fcompanion__ai_N_ROnUnconverted"));

	companion_ai__L_2fFortnite_2ecom_2fAI_2fCompanionAI_2fcompanion__ai_N_ROnUnconverted_Params params;
	params.__verse_0xB2CDDD72_Argument = __verse_0xB2CDDD72_Argument;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CompanionAI.companion_ai._L_2fFortnite_2ecom_2fAI_2fCompanionAI_2fcompanion__ai_N_ROnUnconverted_L_Nany_R_Nvoid
// (Public, HasDefaults, BlueprintCallable)

void companion_ai::_L_2fFortnite_2ecom_2fAI_2fCompanionAI_2fcompanion__ai_N_ROnUnconverted_L_Nany_R_Nvoid()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CompanionAI.companion_ai._L_2fFortnite_2ecom_2fAI_2fCompanionAI_2fcompanion__ai_N_ROnUnconverted_L_Nany_R_Nvoid"));

	companion_ai__L_2fFortnite_2ecom_2fAI_2fCompanionAI_2fcompanion__ai_N_ROnUnconverted_L_Nany_R_Nvoid_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CompanionAI.companion_ai._L_2fFortnite_2ecom_2fAI_2fCompanionAI_2fcompanion__ai_N_ROnConverted
// (Public, HasDefaults, BlueprintCallable)
// Parameters:
// struct FCompanionAI_Ftuple_L_R __verse_0xB2CDDD72_Argument    (Parm)

void companion_ai::_L_2fFortnite_2ecom_2fAI_2fCompanionAI_2fcompanion__ai_N_ROnConverted(const struct FCompanionAI_Ftuple_L_R& __verse_0xB2CDDD72_Argument)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CompanionAI.companion_ai._L_2fFortnite_2ecom_2fAI_2fCompanionAI_2fcompanion__ai_N_ROnConverted"));

	companion_ai__L_2fFortnite_2ecom_2fAI_2fCompanionAI_2fcompanion__ai_N_ROnConverted_Params params;
	params.__verse_0xB2CDDD72_Argument = __verse_0xB2CDDD72_Argument;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CompanionAI.companion_ai._L_2fFortnite_2ecom_2fAI_2fCompanionAI_2fcompanion__ai_N_ROnConverted_L_Nany_R_Nvoid
// (Public, HasDefaults, BlueprintCallable)

void companion_ai::_L_2fFortnite_2ecom_2fAI_2fCompanionAI_2fcompanion__ai_N_ROnConverted_L_Nany_R_Nvoid()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CompanionAI.companion_ai._L_2fFortnite_2ecom_2fAI_2fCompanionAI_2fcompanion__ai_N_ROnConverted_L_Nany_R_Nvoid"));

	companion_ai__L_2fFortnite_2ecom_2fAI_2fCompanionAI_2fcompanion__ai_N_ROnConverted_L_Nany_R_Nvoid_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CompanionAI.companion_ai.OnBegin
// (Public, HasOutParms, BlueprintCallable)
// Parameters:
// class task_t_*                 __verse_0xC1E81372_CallingTask (ExportObject, Parm, ZeroConstructor, InstancedReference)
// int64_t                        __verse_0xA3A00DDB_CallerResumeState (Parm, ZeroConstructor, IsPlainOldData)
// int64_t                        __verse_0x2AC0E4D8_CallerCancelState (Parm, ZeroConstructor, IsPlainOldData)
// struct FCompanionAI_Ftuple_L_R __verse_0xB2CDDD72_Argument    (Parm)
// class task_t_*                 RetVal                         (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)

class task_t_* companion_ai::OnBegin(class task_t_* __verse_0xC1E81372_CallingTask, int64_t __verse_0xA3A00DDB_CallerResumeState, int64_t __verse_0x2AC0E4D8_CallerCancelState, const struct FCompanionAI_Ftuple_L_R& __verse_0xB2CDDD72_Argument)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CompanionAI.companion_ai.OnBegin"));

	companion_ai_OnBegin_Params params;
	params.__verse_0xC1E81372_CallingTask = __verse_0xC1E81372_CallingTask;
	params.__verse_0xA3A00DDB_CallerResumeState = __verse_0xA3A00DDB_CallerResumeState;
	params.__verse_0x2AC0E4D8_CallerCancelState = __verse_0x2AC0E4D8_CallerCancelState;
	params.__verse_0xB2CDDD72_Argument = __verse_0xB2CDDD72_Argument;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.RetVal;
}


// Function CompanionAI.companion_ai.LookAtThreatTask
// (Public, HasOutParms, BlueprintCallable)
// Parameters:
// class task_t_*                 __verse_0xC1E81372_CallingTask (ExportObject, Parm, ZeroConstructor, InstancedReference)
// int64_t                        __verse_0xA3A00DDB_CallerResumeState (Parm, ZeroConstructor, IsPlainOldData)
// int64_t                        __verse_0x2AC0E4D8_CallerCancelState (Parm, ZeroConstructor, IsPlainOldData)
// struct FCompanionAI_Ftuple_L_R __verse_0xB2CDDD72_Argument    (Parm)
// class task_t_*                 RetVal                         (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)

class task_t_* companion_ai::LookAtThreatTask(class task_t_* __verse_0xC1E81372_CallingTask, int64_t __verse_0xA3A00DDB_CallerResumeState, int64_t __verse_0x2AC0E4D8_CallerCancelState, const struct FCompanionAI_Ftuple_L_R& __verse_0xB2CDDD72_Argument)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CompanionAI.companion_ai.LookAtThreatTask"));

	companion_ai_LookAtThreatTask_Params params;
	params.__verse_0xC1E81372_CallingTask = __verse_0xC1E81372_CallingTask;
	params.__verse_0xA3A00DDB_CallerResumeState = __verse_0xA3A00DDB_CallerResumeState;
	params.__verse_0x2AC0E4D8_CallerCancelState = __verse_0x2AC0E4D8_CallerCancelState;
	params.__verse_0xB2CDDD72_Argument = __verse_0xB2CDDD72_Argument;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.RetVal;
}


// Function CompanionAI.companion_ai.LookAtOrAttackTarget
// (Public, HasOutParms, BlueprintCallable)
// Parameters:
// class task_t_*                 __verse_0xC1E81372_CallingTask (ExportObject, Parm, ZeroConstructor, InstancedReference)
// int64_t                        __verse_0xA3A00DDB_CallerResumeState (Parm, ZeroConstructor, IsPlainOldData)
// int64_t                        __verse_0x2AC0E4D8_CallerCancelState (Parm, ZeroConstructor, IsPlainOldData)
// struct FCompanionAI_Ftuple_L_R __verse_0xB2CDDD72_Argument    (Parm)
// class task_t_*                 RetVal                         (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)

class task_t_* companion_ai::LookAtOrAttackTarget(class task_t_* __verse_0xC1E81372_CallingTask, int64_t __verse_0xA3A00DDB_CallerResumeState, int64_t __verse_0x2AC0E4D8_CallerCancelState, const struct FCompanionAI_Ftuple_L_R& __verse_0xB2CDDD72_Argument)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CompanionAI.companion_ai.LookAtOrAttackTarget"));

	companion_ai_LookAtOrAttackTarget_Params params;
	params.__verse_0xC1E81372_CallingTask = __verse_0xC1E81372_CallingTask;
	params.__verse_0xA3A00DDB_CallerResumeState = __verse_0xA3A00DDB_CallerResumeState;
	params.__verse_0x2AC0E4D8_CallerCancelState = __verse_0x2AC0E4D8_CallerCancelState;
	params.__verse_0xB2CDDD72_Argument = __verse_0xB2CDDD72_Argument;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.RetVal;
}


// Function CompanionAI.companion_ai.LookAroundTask_L_Nvector3_M_Nfloat_M_Nfloat_R
// (Public, HasOutParms, BlueprintCallable)
// Parameters:
// class task_t_*                 __verse_0xC1E81372_CallingTask (ExportObject, Parm, ZeroConstructor, InstancedReference)
// int64_t                        __verse_0xA3A00DDB_CallerResumeState (Parm, ZeroConstructor, IsPlainOldData)
// int64_t                        __verse_0x2AC0E4D8_CallerCancelState (Parm, ZeroConstructor, IsPlainOldData)
// struct FCompanionAI_Ftuple_Lvector3_Mfloat_Mfloat_R __verse_0xB2CDDD72_Argument    (Parm)
// class task_t_*                 RetVal                         (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)

class task_t_* companion_ai::LookAroundTask_L_Nvector3_M_Nfloat_M_Nfloat_R(class task_t_* __verse_0xC1E81372_CallingTask, int64_t __verse_0xA3A00DDB_CallerResumeState, int64_t __verse_0x2AC0E4D8_CallerCancelState, const struct FCompanionAI_Ftuple_Lvector3_Mfloat_Mfloat_R& __verse_0xB2CDDD72_Argument)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CompanionAI.companion_ai.LookAroundTask_L_Nvector3_M_Nfloat_M_Nfloat_R"));

	companion_ai_LookAroundTask_L_Nvector3_M_Nfloat_M_Nfloat_R_Params params;
	params.__verse_0xC1E81372_CallingTask = __verse_0xC1E81372_CallingTask;
	params.__verse_0xA3A00DDB_CallerResumeState = __verse_0xA3A00DDB_CallerResumeState;
	params.__verse_0x2AC0E4D8_CallerCancelState = __verse_0x2AC0E4D8_CallerCancelState;
	params.__verse_0xB2CDDD72_Argument = __verse_0xB2CDDD72_Argument;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.RetVal;
}


// Function CompanionAI.companion_ai._L_2fFortnite_2ecom_2fAI_2fCompanionAI_2fcompanion__ai_N_RLogAndDisplayOnScreen_L_N_Kchar_R
// (Public, HasDefaults, BlueprintCallable)

void companion_ai::_L_2fFortnite_2ecom_2fAI_2fCompanionAI_2fcompanion__ai_N_RLogAndDisplayOnScreen_L_N_Kchar_R()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CompanionAI.companion_ai._L_2fFortnite_2ecom_2fAI_2fCompanionAI_2fcompanion__ai_N_RLogAndDisplayOnScreen_L_N_Kchar_R"));

	companion_ai__L_2fFortnite_2ecom_2fAI_2fCompanionAI_2fcompanion__ai_N_RLogAndDisplayOnScreen_L_N_Kchar_R_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CompanionAI.companion_ai.HandleReviveCommand_L_Nping__info_R
// (Public, HasOutParms, BlueprintCallable)
// Parameters:
// class task_t_*                 __verse_0xC1E81372_CallingTask (ExportObject, Parm, ZeroConstructor, InstancedReference)
// int64_t                        __verse_0xA3A00DDB_CallerResumeState (Parm, ZeroConstructor, IsPlainOldData)
// int64_t                        __verse_0x2AC0E4D8_CallerCancelState (Parm, ZeroConstructor, IsPlainOldData)
// struct Fping_info              __verse_0xB2CDDD72_Argument    (Parm)
// class task_t_*                 RetVal                         (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)

class task_t_* companion_ai::HandleReviveCommand_L_Nping__info_R(class task_t_* __verse_0xC1E81372_CallingTask, int64_t __verse_0xA3A00DDB_CallerResumeState, int64_t __verse_0x2AC0E4D8_CallerCancelState, const struct Fping_info& __verse_0xB2CDDD72_Argument)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CompanionAI.companion_ai.HandleReviveCommand_L_Nping__info_R"));

	companion_ai_HandleReviveCommand_L_Nping__info_R_Params params;
	params.__verse_0xC1E81372_CallingTask = __verse_0xC1E81372_CallingTask;
	params.__verse_0xA3A00DDB_CallerResumeState = __verse_0xA3A00DDB_CallerResumeState;
	params.__verse_0x2AC0E4D8_CallerCancelState = __verse_0x2AC0E4D8_CallerCancelState;
	params.__verse_0xB2CDDD72_Argument = __verse_0xB2CDDD72_Argument;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.RetVal;
}


// Function CompanionAI.companion_ai.HandleObstacleTask_L_N_Qentity_R
// (Public, HasOutParms, BlueprintCallable)
// Parameters:
// class task_t_*                 __verse_0xC1E81372_CallingTask (ExportObject, Parm, ZeroConstructor, InstancedReference)
// int64_t                        __verse_0xA3A00DDB_CallerResumeState (Parm, ZeroConstructor, IsPlainOldData)
// int64_t                        __verse_0x2AC0E4D8_CallerCancelState (Parm, ZeroConstructor, IsPlainOldData)
// class task_t_*                 RetVal                         (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)

class task_t_* companion_ai::HandleObstacleTask_L_N_Qentity_R(class task_t_* __verse_0xC1E81372_CallingTask, int64_t __verse_0xA3A00DDB_CallerResumeState, int64_t __verse_0x2AC0E4D8_CallerCancelState)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CompanionAI.companion_ai.HandleObstacleTask_L_N_Qentity_R"));

	companion_ai_HandleObstacleTask_L_N_Qentity_R_Params params;
	params.__verse_0xC1E81372_CallingTask = __verse_0xC1E81372_CallingTask;
	params.__verse_0xA3A00DDB_CallerResumeState = __verse_0xA3A00DDB_CallerResumeState;
	params.__verse_0x2AC0E4D8_CallerCancelState = __verse_0x2AC0E4D8_CallerCancelState;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.RetVal;
}


// Function CompanionAI.companion_ai.HandleNPCCommand_L_Nping__info_R
// (Public, HasOutParms, BlueprintCallable)
// Parameters:
// class task_t_*                 __verse_0xC1E81372_CallingTask (ExportObject, Parm, ZeroConstructor, InstancedReference)
// int64_t                        __verse_0xA3A00DDB_CallerResumeState (Parm, ZeroConstructor, IsPlainOldData)
// int64_t                        __verse_0x2AC0E4D8_CallerCancelState (Parm, ZeroConstructor, IsPlainOldData)
// struct Fping_info              __verse_0xB2CDDD72_Argument    (Parm)
// class task_t_*                 RetVal                         (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)

class task_t_* companion_ai::HandleNPCCommand_L_Nping__info_R(class task_t_* __verse_0xC1E81372_CallingTask, int64_t __verse_0xA3A00DDB_CallerResumeState, int64_t __verse_0x2AC0E4D8_CallerCancelState, const struct Fping_info& __verse_0xB2CDDD72_Argument)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CompanionAI.companion_ai.HandleNPCCommand_L_Nping__info_R"));

	companion_ai_HandleNPCCommand_L_Nping__info_R_Params params;
	params.__verse_0xC1E81372_CallingTask = __verse_0xC1E81372_CallingTask;
	params.__verse_0xA3A00DDB_CallerResumeState = __verse_0xA3A00DDB_CallerResumeState;
	params.__verse_0x2AC0E4D8_CallerCancelState = __verse_0x2AC0E4D8_CallerCancelState;
	params.__verse_0xB2CDDD72_Argument = __verse_0xB2CDDD72_Argument;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.RetVal;
}


// Function CompanionAI.companion_ai.HandleHoldPositionCommand_L_Nping__info_R
// (Public, HasOutParms, BlueprintCallable)
// Parameters:
// class task_t_*                 __verse_0xC1E81372_CallingTask (ExportObject, Parm, ZeroConstructor, InstancedReference)
// int64_t                        __verse_0xA3A00DDB_CallerResumeState (Parm, ZeroConstructor, IsPlainOldData)
// int64_t                        __verse_0x2AC0E4D8_CallerCancelState (Parm, ZeroConstructor, IsPlainOldData)
// struct Fping_info              __verse_0xB2CDDD72_Argument    (Parm)
// class task_t_*                 RetVal                         (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)

class task_t_* companion_ai::HandleHoldPositionCommand_L_Nping__info_R(class task_t_* __verse_0xC1E81372_CallingTask, int64_t __verse_0xA3A00DDB_CallerResumeState, int64_t __verse_0x2AC0E4D8_CallerCancelState, const struct Fping_info& __verse_0xB2CDDD72_Argument)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CompanionAI.companion_ai.HandleHoldPositionCommand_L_Nping__info_R"));

	companion_ai_HandleHoldPositionCommand_L_Nping__info_R_Params params;
	params.__verse_0xC1E81372_CallingTask = __verse_0xC1E81372_CallingTask;
	params.__verse_0xA3A00DDB_CallerResumeState = __verse_0xA3A00DDB_CallerResumeState;
	params.__verse_0x2AC0E4D8_CallerCancelState = __verse_0x2AC0E4D8_CallerCancelState;
	params.__verse_0xB2CDDD72_Argument = __verse_0xB2CDDD72_Argument;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.RetVal;
}


// Function CompanionAI.companion_ai.HandleGoToCommand_L_Nping__info_R
// (Public, HasOutParms, BlueprintCallable)
// Parameters:
// class task_t_*                 __verse_0xC1E81372_CallingTask (ExportObject, Parm, ZeroConstructor, InstancedReference)
// int64_t                        __verse_0xA3A00DDB_CallerResumeState (Parm, ZeroConstructor, IsPlainOldData)
// int64_t                        __verse_0x2AC0E4D8_CallerCancelState (Parm, ZeroConstructor, IsPlainOldData)
// struct Fping_info              __verse_0xB2CDDD72_Argument    (Parm)
// class task_t_*                 RetVal                         (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)

class task_t_* companion_ai::HandleGoToCommand_L_Nping__info_R(class task_t_* __verse_0xC1E81372_CallingTask, int64_t __verse_0xA3A00DDB_CallerResumeState, int64_t __verse_0x2AC0E4D8_CallerCancelState, const struct Fping_info& __verse_0xB2CDDD72_Argument)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CompanionAI.companion_ai.HandleGoToCommand_L_Nping__info_R"));

	companion_ai_HandleGoToCommand_L_Nping__info_R_Params params;
	params.__verse_0xC1E81372_CallingTask = __verse_0xC1E81372_CallingTask;
	params.__verse_0xA3A00DDB_CallerResumeState = __verse_0xA3A00DDB_CallerResumeState;
	params.__verse_0x2AC0E4D8_CallerCancelState = __verse_0x2AC0E4D8_CallerCancelState;
	params.__verse_0xB2CDDD72_Argument = __verse_0xB2CDDD72_Argument;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.RetVal;
}


// Function CompanionAI.companion_ai.HandleGoTo_L_Nping__info_R
// (Public, HasOutParms, BlueprintCallable)
// Parameters:
// class task_t_*                 __verse_0xC1E81372_CallingTask (ExportObject, Parm, ZeroConstructor, InstancedReference)
// int64_t                        __verse_0xA3A00DDB_CallerResumeState (Parm, ZeroConstructor, IsPlainOldData)
// int64_t                        __verse_0x2AC0E4D8_CallerCancelState (Parm, ZeroConstructor, IsPlainOldData)
// struct Fping_info              __verse_0xB2CDDD72_Argument    (Parm)
// class task_t_*                 RetVal                         (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)

class task_t_* companion_ai::HandleGoTo_L_Nping__info_R(class task_t_* __verse_0xC1E81372_CallingTask, int64_t __verse_0xA3A00DDB_CallerResumeState, int64_t __verse_0x2AC0E4D8_CallerCancelState, const struct Fping_info& __verse_0xB2CDDD72_Argument)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CompanionAI.companion_ai.HandleGoTo_L_Nping__info_R"));

	companion_ai_HandleGoTo_L_Nping__info_R_Params params;
	params.__verse_0xC1E81372_CallingTask = __verse_0xC1E81372_CallingTask;
	params.__verse_0xA3A00DDB_CallerResumeState = __verse_0xA3A00DDB_CallerResumeState;
	params.__verse_0x2AC0E4D8_CallerCancelState = __verse_0x2AC0E4D8_CallerCancelState;
	params.__verse_0xB2CDDD72_Argument = __verse_0xB2CDDD72_Argument;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.RetVal;
}


// Function CompanionAI.companion_ai.HandleBackToMeCommand_L_Nping__info_R
// (Public, HasOutParms, BlueprintCallable)
// Parameters:
// class task_t_*                 __verse_0xC1E81372_CallingTask (ExportObject, Parm, ZeroConstructor, InstancedReference)
// int64_t                        __verse_0xA3A00DDB_CallerResumeState (Parm, ZeroConstructor, IsPlainOldData)
// int64_t                        __verse_0x2AC0E4D8_CallerCancelState (Parm, ZeroConstructor, IsPlainOldData)
// struct Fping_info              __verse_0xB2CDDD72_Argument    (Parm)
// class task_t_*                 RetVal                         (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)

class task_t_* companion_ai::HandleBackToMeCommand_L_Nping__info_R(class task_t_* __verse_0xC1E81372_CallingTask, int64_t __verse_0xA3A00DDB_CallerResumeState, int64_t __verse_0x2AC0E4D8_CallerCancelState, const struct Fping_info& __verse_0xB2CDDD72_Argument)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CompanionAI.companion_ai.HandleBackToMeCommand_L_Nping__info_R"));

	companion_ai_HandleBackToMeCommand_L_Nping__info_R_Params params;
	params.__verse_0xC1E81372_CallingTask = __verse_0xC1E81372_CallingTask;
	params.__verse_0xA3A00DDB_CallerResumeState = __verse_0xA3A00DDB_CallerResumeState;
	params.__verse_0x2AC0E4D8_CallerCancelState = __verse_0x2AC0E4D8_CallerCancelState;
	params.__verse_0xB2CDDD72_Argument = __verse_0xB2CDDD72_Argument;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.RetVal;
}


// Function CompanionAI.companion_ai.GoToPositionTask_L_Nvector3_M_N_Qfort__character_M_Nlogic_M_Nnavigation__parameters_R
// (Public, HasOutParms, HasDefaults, BlueprintCallable)
// Parameters:
// class task_t_*                 __verse_0xC1E81372_CallingTask (ExportObject, Parm, ZeroConstructor, InstancedReference)
// int64_t                        __verse_0xA3A00DDB_CallerResumeState (Parm, ZeroConstructor, IsPlainOldData)
// int64_t                        __verse_0x2AC0E4D8_CallerCancelState (Parm, ZeroConstructor, IsPlainOldData)
// struct Ftuple_Lvector3_M_Qfort__character_Mlogic_M_QNavigationParameters_Nnavigation__parameters_20_3d_20_2e_2e_2e_R __verse_0xB2CDDD72_Argument    (Parm)
// class task_t_*                 RetVal                         (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)

class task_t_* companion_ai::GoToPositionTask_L_Nvector3_M_N_Qfort__character_M_Nlogic_M_Nnavigation__parameters_R(class task_t_* __verse_0xC1E81372_CallingTask, int64_t __verse_0xA3A00DDB_CallerResumeState, int64_t __verse_0x2AC0E4D8_CallerCancelState, const struct Ftuple_Lvector3_M_Qfort__character_Mlogic_M_QNavigationParameters_Nnavigation__parameters_20_3d_20_2e_2e_2e_R& __verse_0xB2CDDD72_Argument)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CompanionAI.companion_ai.GoToPositionTask_L_Nvector3_M_N_Qfort__character_M_Nlogic_M_Nnavigation__parameters_R"));

	companion_ai_GoToPositionTask_L_Nvector3_M_N_Qfort__character_M_Nlogic_M_Nnavigation__parameters_R_Params params;
	params.__verse_0xC1E81372_CallingTask = __verse_0xC1E81372_CallingTask;
	params.__verse_0xA3A00DDB_CallerResumeState = __verse_0xA3A00DDB_CallerResumeState;
	params.__verse_0x2AC0E4D8_CallerCancelState = __verse_0x2AC0E4D8_CallerCancelState;
	params.__verse_0xB2CDDD72_Argument = __verse_0xB2CDDD72_Argument;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.RetVal;
}


// Function CompanionAI.companion_ai.GoToAndAttackTask_L_Nthreat__info_R
// (Public, HasOutParms, BlueprintCallable)
// Parameters:
// class task_t_*                 __verse_0xC1E81372_CallingTask (ExportObject, Parm, ZeroConstructor, InstancedReference)
// int64_t                        __verse_0xA3A00DDB_CallerResumeState (Parm, ZeroConstructor, IsPlainOldData)
// int64_t                        __verse_0x2AC0E4D8_CallerCancelState (Parm, ZeroConstructor, IsPlainOldData)
// struct Fthreat_info            __verse_0xB2CDDD72_Argument    (Parm)
// class task_t_*                 RetVal                         (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)

class task_t_* companion_ai::GoToAndAttackTask_L_Nthreat__info_R(class task_t_* __verse_0xC1E81372_CallingTask, int64_t __verse_0xA3A00DDB_CallerResumeState, int64_t __verse_0x2AC0E4D8_CallerCancelState, const struct Fthreat_info& __verse_0xB2CDDD72_Argument)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CompanionAI.companion_ai.GoToAndAttackTask_L_Nthreat__info_R"));

	companion_ai_GoToAndAttackTask_L_Nthreat__info_R_Params params;
	params.__verse_0xC1E81372_CallingTask = __verse_0xC1E81372_CallingTask;
	params.__verse_0xA3A00DDB_CallerResumeState = __verse_0xA3A00DDB_CallerResumeState;
	params.__verse_0x2AC0E4D8_CallerCancelState = __verse_0x2AC0E4D8_CallerCancelState;
	params.__verse_0xB2CDDD72_Argument = __verse_0xB2CDDD72_Argument;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.RetVal;
}


// Function CompanionAI.companion_ai.GetThreat
// (Public, HasOutParms, BlueprintCallable)
// Parameters:
// class task_t_*                 __verse_0xC1E81372_CallingTask (ExportObject, Parm, ZeroConstructor, InstancedReference)
// int64_t                        __verse_0xA3A00DDB_CallerResumeState (Parm, ZeroConstructor, IsPlainOldData)
// int64_t                        __verse_0x2AC0E4D8_CallerCancelState (Parm, ZeroConstructor, IsPlainOldData)
// struct FCompanionAI_Ftuple_L_R __verse_0xB2CDDD72_Argument    (Parm)
// class task_t_*                 RetVal                         (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)

class task_t_* companion_ai::GetThreat(class task_t_* __verse_0xC1E81372_CallingTask, int64_t __verse_0xA3A00DDB_CallerResumeState, int64_t __verse_0x2AC0E4D8_CallerCancelState, const struct FCompanionAI_Ftuple_L_R& __verse_0xB2CDDD72_Argument)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CompanionAI.companion_ai.GetThreat"));

	companion_ai_GetThreat_Params params;
	params.__verse_0xC1E81372_CallingTask = __verse_0xC1E81372_CallingTask;
	params.__verse_0xA3A00DDB_CallerResumeState = __verse_0xA3A00DDB_CallerResumeState;
	params.__verse_0x2AC0E4D8_CallerCancelState = __verse_0x2AC0E4D8_CallerCancelState;
	params.__verse_0xB2CDDD72_Argument = __verse_0xB2CDDD72_Argument;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.RetVal;
}


// Function CompanionAI.companion_ai.GetObstacle
// (Public, HasOutParms, BlueprintCallable)
// Parameters:
// class task_t_*                 __verse_0xC1E81372_CallingTask (ExportObject, Parm, ZeroConstructor, InstancedReference)
// int64_t                        __verse_0xA3A00DDB_CallerResumeState (Parm, ZeroConstructor, IsPlainOldData)
// int64_t                        __verse_0x2AC0E4D8_CallerCancelState (Parm, ZeroConstructor, IsPlainOldData)
// struct FCompanionAI_Ftuple_L_R __verse_0xB2CDDD72_Argument    (Parm)
// class task_t_*                 RetVal                         (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)

class task_t_* companion_ai::GetObstacle(class task_t_* __verse_0xC1E81372_CallingTask, int64_t __verse_0xA3A00DDB_CallerResumeState, int64_t __verse_0x2AC0E4D8_CallerCancelState, const struct FCompanionAI_Ftuple_L_R& __verse_0xB2CDDD72_Argument)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CompanionAI.companion_ai.GetObstacle"));

	companion_ai_GetObstacle_Params params;
	params.__verse_0xC1E81372_CallingTask = __verse_0xC1E81372_CallingTask;
	params.__verse_0xA3A00DDB_CallerResumeState = __verse_0xA3A00DDB_CallerResumeState;
	params.__verse_0x2AC0E4D8_CallerCancelState = __verse_0x2AC0E4D8_CallerCancelState;
	params.__verse_0xB2CDDD72_Argument = __verse_0xB2CDDD72_Argument;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.RetVal;
}


// Function CompanionAI.companion_ai.GetNewThreat
// (Public, HasOutParms, BlueprintCallable)
// Parameters:
// class task_t_*                 __verse_0xC1E81372_CallingTask (ExportObject, Parm, ZeroConstructor, InstancedReference)
// int64_t                        __verse_0xA3A00DDB_CallerResumeState (Parm, ZeroConstructor, IsPlainOldData)
// int64_t                        __verse_0x2AC0E4D8_CallerCancelState (Parm, ZeroConstructor, IsPlainOldData)
// struct FCompanionAI_Ftuple_L_R __verse_0xB2CDDD72_Argument    (Parm)
// class task_t_*                 RetVal                         (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)

class task_t_* companion_ai::GetNewThreat(class task_t_* __verse_0xC1E81372_CallingTask, int64_t __verse_0xA3A00DDB_CallerResumeState, int64_t __verse_0x2AC0E4D8_CallerCancelState, const struct FCompanionAI_Ftuple_L_R& __verse_0xB2CDDD72_Argument)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CompanionAI.companion_ai.GetNewThreat"));

	companion_ai_GetNewThreat_Params params;
	params.__verse_0xC1E81372_CallingTask = __verse_0xC1E81372_CallingTask;
	params.__verse_0xA3A00DDB_CallerResumeState = __verse_0xA3A00DDB_CallerResumeState;
	params.__verse_0x2AC0E4D8_CallerCancelState = __verse_0x2AC0E4D8_CallerCancelState;
	params.__verse_0xB2CDDD72_Argument = __verse_0xB2CDDD72_Argument;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.RetVal;
}


// Function CompanionAI.companion_ai.GetNewTargetPerception_L_N_Qthreat__info_R
// (Public, HasOutParms, BlueprintCallable)
// Parameters:
// class task_t_*                 __verse_0xC1E81372_CallingTask (ExportObject, Parm, ZeroConstructor, InstancedReference)
// int64_t                        __verse_0xA3A00DDB_CallerResumeState (Parm, ZeroConstructor, IsPlainOldData)
// int64_t                        __verse_0x2AC0E4D8_CallerCancelState (Parm, ZeroConstructor, IsPlainOldData)
// class task_t_*                 RetVal                         (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)

class task_t_* companion_ai::GetNewTargetPerception_L_N_Qthreat__info_R(class task_t_* __verse_0xC1E81372_CallingTask, int64_t __verse_0xA3A00DDB_CallerResumeState, int64_t __verse_0x2AC0E4D8_CallerCancelState)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CompanionAI.companion_ai.GetNewTargetPerception_L_N_Qthreat__info_R"));

	companion_ai_GetNewTargetPerception_L_N_Qthreat__info_R_Params params;
	params.__verse_0xC1E81372_CallingTask = __verse_0xC1E81372_CallingTask;
	params.__verse_0xA3A00DDB_CallerResumeState = __verse_0xA3A00DDB_CallerResumeState;
	params.__verse_0x2AC0E4D8_CallerCancelState = __verse_0x2AC0E4D8_CallerCancelState;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.RetVal;
}


// Function CompanionAI.companion_ai.GetNewObstacle
// (Public, HasOutParms, BlueprintCallable)
// Parameters:
// class task_t_*                 __verse_0xC1E81372_CallingTask (ExportObject, Parm, ZeroConstructor, InstancedReference)
// int64_t                        __verse_0xA3A00DDB_CallerResumeState (Parm, ZeroConstructor, IsPlainOldData)
// int64_t                        __verse_0x2AC0E4D8_CallerCancelState (Parm, ZeroConstructor, IsPlainOldData)
// struct FCompanionAI_Ftuple_L_R __verse_0xB2CDDD72_Argument    (Parm)
// class task_t_*                 RetVal                         (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)

class task_t_* companion_ai::GetNewObstacle(class task_t_* __verse_0xC1E81372_CallingTask, int64_t __verse_0xA3A00DDB_CallerResumeState, int64_t __verse_0x2AC0E4D8_CallerCancelState, const struct FCompanionAI_Ftuple_L_R& __verse_0xB2CDDD72_Argument)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CompanionAI.companion_ai.GetNewObstacle"));

	companion_ai_GetNewObstacle_Params params;
	params.__verse_0xC1E81372_CallingTask = __verse_0xC1E81372_CallingTask;
	params.__verse_0xA3A00DDB_CallerResumeState = __verse_0xA3A00DDB_CallerResumeState;
	params.__verse_0x2AC0E4D8_CallerCancelState = __verse_0x2AC0E4D8_CallerCancelState;
	params.__verse_0xB2CDDD72_Argument = __verse_0xB2CDDD72_Argument;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.RetVal;
}


// Function CompanionAI.companion_ai.GameLoop
// (Public, HasOutParms, BlueprintCallable)
// Parameters:
// class task_t_*                 __verse_0xC1E81372_CallingTask (ExportObject, Parm, ZeroConstructor, InstancedReference)
// int64_t                        __verse_0xA3A00DDB_CallerResumeState (Parm, ZeroConstructor, IsPlainOldData)
// int64_t                        __verse_0x2AC0E4D8_CallerCancelState (Parm, ZeroConstructor, IsPlainOldData)
// struct FCompanionAI_Ftuple_L_R __verse_0xB2CDDD72_Argument    (Parm)
// class task_t_*                 RetVal                         (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)

class task_t_* companion_ai::GameLoop(class task_t_* __verse_0xC1E81372_CallingTask, int64_t __verse_0xA3A00DDB_CallerResumeState, int64_t __verse_0x2AC0E4D8_CallerCancelState, const struct FCompanionAI_Ftuple_L_R& __verse_0xB2CDDD72_Argument)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CompanionAI.companion_ai.GameLoop"));

	companion_ai_GameLoop_Params params;
	params.__verse_0xC1E81372_CallingTask = __verse_0xC1E81372_CallingTask;
	params.__verse_0xA3A00DDB_CallerResumeState = __verse_0xA3A00DDB_CallerResumeState;
	params.__verse_0x2AC0E4D8_CallerCancelState = __verse_0x2AC0E4D8_CallerCancelState;
	params.__verse_0xB2CDDD72_Argument = __verse_0xB2CDDD72_Argument;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.RetVal;
}


// Function CompanionAI.companion_ai.DrawSphere_L_Nvector3_M_Nfloat_M_Ncolor_R
// (Public, HasOutParms, BlueprintCallable)
// Parameters:
// class task_t_*                 __verse_0xC1E81372_CallingTask (ExportObject, Parm, ZeroConstructor, InstancedReference)
// int64_t                        __verse_0xA3A00DDB_CallerResumeState (Parm, ZeroConstructor, IsPlainOldData)
// int64_t                        __verse_0x2AC0E4D8_CallerCancelState (Parm, ZeroConstructor, IsPlainOldData)
// struct Ftuple_Lvector3_Mfloat_Mcolor_R __verse_0xB2CDDD72_Argument    (Parm)
// class task_t_*                 RetVal                         (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)

class task_t_* companion_ai::DrawSphere_L_Nvector3_M_Nfloat_M_Ncolor_R(class task_t_* __verse_0xC1E81372_CallingTask, int64_t __verse_0xA3A00DDB_CallerResumeState, int64_t __verse_0x2AC0E4D8_CallerCancelState, const struct Ftuple_Lvector3_Mfloat_Mcolor_R& __verse_0xB2CDDD72_Argument)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CompanionAI.companion_ai.DrawSphere_L_Nvector3_M_Nfloat_M_Ncolor_R"));

	companion_ai_DrawSphere_L_Nvector3_M_Nfloat_M_Ncolor_R_Params params;
	params.__verse_0xC1E81372_CallingTask = __verse_0xC1E81372_CallingTask;
	params.__verse_0xA3A00DDB_CallerResumeState = __verse_0xA3A00DDB_CallerResumeState;
	params.__verse_0x2AC0E4D8_CallerCancelState = __verse_0x2AC0E4D8_CallerCancelState;
	params.__verse_0xB2CDDD72_Argument = __verse_0xB2CDDD72_Argument;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.RetVal;
}


// Function CompanionAI.companion_ai.CrouchUntilHit
// (Public, HasOutParms, BlueprintCallable)
// Parameters:
// class task_t_*                 __verse_0xC1E81372_CallingTask (ExportObject, Parm, ZeroConstructor, InstancedReference)
// int64_t                        __verse_0xA3A00DDB_CallerResumeState (Parm, ZeroConstructor, IsPlainOldData)
// int64_t                        __verse_0x2AC0E4D8_CallerCancelState (Parm, ZeroConstructor, IsPlainOldData)
// struct FCompanionAI_Ftuple_L_R __verse_0xB2CDDD72_Argument    (Parm)
// class task_t_*                 RetVal                         (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)

class task_t_* companion_ai::CrouchUntilHit(class task_t_* __verse_0xC1E81372_CallingTask, int64_t __verse_0xA3A00DDB_CallerResumeState, int64_t __verse_0x2AC0E4D8_CallerCancelState, const struct FCompanionAI_Ftuple_L_R& __verse_0xB2CDDD72_Argument)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CompanionAI.companion_ai.CrouchUntilHit"));

	companion_ai_CrouchUntilHit_Params params;
	params.__verse_0xC1E81372_CallingTask = __verse_0xC1E81372_CallingTask;
	params.__verse_0xA3A00DDB_CallerResumeState = __verse_0xA3A00DDB_CallerResumeState;
	params.__verse_0x2AC0E4D8_CallerCancelState = __verse_0x2AC0E4D8_CallerCancelState;
	params.__verse_0xB2CDDD72_Argument = __verse_0xB2CDDD72_Argument;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.RetVal;
}


// Function CompanionAI.companion_ai.CrouchService
// (Public, HasOutParms, BlueprintCallable)
// Parameters:
// class task_t_*                 __verse_0xC1E81372_CallingTask (ExportObject, Parm, ZeroConstructor, InstancedReference)
// int64_t                        __verse_0xA3A00DDB_CallerResumeState (Parm, ZeroConstructor, IsPlainOldData)
// int64_t                        __verse_0x2AC0E4D8_CallerCancelState (Parm, ZeroConstructor, IsPlainOldData)
// struct FCompanionAI_Ftuple_L_R __verse_0xB2CDDD72_Argument    (Parm)
// class task_t_*                 RetVal                         (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)

class task_t_* companion_ai::CrouchService(class task_t_* __verse_0xC1E81372_CallingTask, int64_t __verse_0xA3A00DDB_CallerResumeState, int64_t __verse_0x2AC0E4D8_CallerCancelState, const struct FCompanionAI_Ftuple_L_R& __verse_0xB2CDDD72_Argument)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CompanionAI.companion_ai.CrouchService"));

	companion_ai_CrouchService_Params params;
	params.__verse_0xC1E81372_CallingTask = __verse_0xC1E81372_CallingTask;
	params.__verse_0xA3A00DDB_CallerResumeState = __verse_0xA3A00DDB_CallerResumeState;
	params.__verse_0x2AC0E4D8_CallerCancelState = __verse_0x2AC0E4D8_CallerCancelState;
	params.__verse_0xB2CDDD72_Argument = __verse_0xB2CDDD72_Argument;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.RetVal;
}


// Function CompanionAI.companion_ai.$InitInstance
// ()

void companion_ai::$InitInstance()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CompanionAI.companion_ai.$InitInstance"));

	companion_ai_$InitInstance_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CompanionAI.companion_ai.$Block
// ()

void companion_ai::$Block()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CompanionAI.companion_ai.$Block"));

	companion_ai_$Block_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CompanionAI.companion_ai.$InitCDO
// (HasDefaults)

void companion_ai::$InitCDO()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CompanionAI.companion_ai.$InitCDO"));

	companion_ai_$InitCDO_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CompanionAI.CompanionAI._L_2fFortnite_2ecom_2fAI_2fCompanionAI_N_RToString_L_Ncommand__type_R
// (Final, Static, Public, HasOutParms, HasDefaults, BlueprintCallable)
// Parameters:
// Ecommand_type                  __verse_0xB2CDDD72_Argument    (Parm, ZeroConstructor, IsPlainOldData)

void CompanionAI::STATIC__L_2fFortnite_2ecom_2fAI_2fCompanionAI_N_RToString_L_Ncommand__type_R(Ecommand_type __verse_0xB2CDDD72_Argument)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CompanionAI.CompanionAI._L_2fFortnite_2ecom_2fAI_2fCompanionAI_N_RToString_L_Ncommand__type_R"));

	CompanionAI__L_2fFortnite_2ecom_2fAI_2fCompanionAI_N_RToString_L_Ncommand__type_R_Params params;
	params.__verse_0xB2CDDD72_Argument = __verse_0xB2CDDD72_Argument;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CompanionAI.CompanionAI._L_2fFortnite_2ecom_2fAI_2fCompanionAI_N_RToString_L_Nentity__type_R
// (Final, Static, Public, HasOutParms, HasDefaults, BlueprintCallable)
// Parameters:
// Eentity_type                   __verse_0xB2CDDD72_Argument    (Parm, ZeroConstructor, IsPlainOldData)

void CompanionAI::STATIC__L_2fFortnite_2ecom_2fAI_2fCompanionAI_N_RToString_L_Nentity__type_R(Eentity_type __verse_0xB2CDDD72_Argument)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CompanionAI.CompanionAI._L_2fFortnite_2ecom_2fAI_2fCompanionAI_N_RToString_L_Nentity__type_R"));

	CompanionAI__L_2fFortnite_2ecom_2fAI_2fCompanionAI_N_RToString_L_Nentity__type_R_Params params;
	params.__verse_0xB2CDDD72_Argument = __verse_0xB2CDDD72_Argument;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CompanionAI.CompanionAI._L_2fFortnite_2ecom_2fAI_2fCompanionAI_N_RGetFortCharacter_L_Nentity_R
// (Final, Native, Static, Public, HasOutParms, BlueprintCallable)
// Parameters:
// class Entity*                  __verse_0xB2CDDD72_Argument    (ExportObject, Parm, ZeroConstructor, InstancedReference)

void CompanionAI::STATIC__L_2fFortnite_2ecom_2fAI_2fCompanionAI_N_RGetFortCharacter_L_Nentity_R(class Entity* __verse_0xB2CDDD72_Argument)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CompanionAI.CompanionAI._L_2fFortnite_2ecom_2fAI_2fCompanionAI_N_RGetFortCharacter_L_Nentity_R"));

	CompanionAI__L_2fFortnite_2ecom_2fAI_2fCompanionAI_N_RGetFortCharacter_L_Nentity_R_Params params;
	params.__verse_0xB2CDDD72_Argument = __verse_0xB2CDDD72_Argument;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CompanionAI.CompanionAI._L_2fFortnite_2ecom_2fAI_2fCompanionAI_N_RCompare_L_Nobstacle__info_M_Nentity_R
// (Final, Native, Static, Public, HasOutParms, BlueprintCallable)
// Parameters:
// struct Ftuple_Lobstacle__info_Mentity_R __verse_0xB2CDDD72_Argument    (Parm)
// bool                           RetVal                         (Parm, OutParm, ReturnParm)

bool CompanionAI::STATIC__L_2fFortnite_2ecom_2fAI_2fCompanionAI_N_RCompare_L_Nobstacle__info_M_Nentity_R(const struct Ftuple_Lobstacle__info_Mentity_R& __verse_0xB2CDDD72_Argument)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CompanionAI.CompanionAI._L_2fFortnite_2ecom_2fAI_2fCompanionAI_N_RCompare_L_Nobstacle__info_M_Nentity_R"));

	CompanionAI__L_2fFortnite_2ecom_2fAI_2fCompanionAI_N_RCompare_L_Nobstacle__info_M_Nentity_R_Params params;
	params.__verse_0xB2CDDD72_Argument = __verse_0xB2CDDD72_Argument;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.RetVal;
}


// Function CompanionAI.CompanionAI.ping_info$Factory
// (Static, HasOutParms)
// Parameters:
// struct Fping_info              RetVal                         (Parm, OutParm, ReturnParm)

struct Fping_info CompanionAI::STATIC_ping_info$Factory()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CompanionAI.CompanionAI.ping_info$Factory"));

	CompanionAI_ping_info$Factory_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.RetVal;
}


// Function CompanionAI.CompanionAI.$InitCDO
// ()

void CompanionAI::$InitCDO()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CompanionAI.CompanionAI.$InitCDO"));

	CompanionAI_$InitCDO_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CompanionAI.fort_br_ai_actions_interface.RunDefaultBehavior
// (Public, HasOutParms, BlueprintCallable)
// Parameters:
// class task_t_*                 __verse_0xC1E81372_CallingTask (ExportObject, Parm, ZeroConstructor, InstancedReference)
// int64_t                        __verse_0xA3A00DDB_CallerResumeState (Parm, ZeroConstructor, IsPlainOldData)
// int64_t                        __verse_0x2AC0E4D8_CallerCancelState (Parm, ZeroConstructor, IsPlainOldData)
// struct FCompanionAI_Ftuple_L_R __verse_0xB2CDDD72_Argument    (Parm)
// class task_t_*                 RetVal                         (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)

class task_t_* fort_br_ai_actions_interface::RunDefaultBehavior(class task_t_* __verse_0xC1E81372_CallingTask, int64_t __verse_0xA3A00DDB_CallerResumeState, int64_t __verse_0x2AC0E4D8_CallerCancelState, const struct FCompanionAI_Ftuple_L_R& __verse_0xB2CDDD72_Argument)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CompanionAI.fort_br_ai_actions_interface.RunDefaultBehavior"));

	fort_br_ai_actions_interface_RunDefaultBehavior_Params params;
	params.__verse_0xC1E81372_CallingTask = __verse_0xC1E81372_CallingTask;
	params.__verse_0xA3A00DDB_CallerResumeState = __verse_0xA3A00DDB_CallerResumeState;
	params.__verse_0x2AC0E4D8_CallerCancelState = __verse_0x2AC0E4D8_CallerCancelState;
	params.__verse_0xB2CDDD72_Argument = __verse_0xB2CDDD72_Argument;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.RetVal;
}


// Function CompanionAI.fort_br_ai_movement_interface._L_2fFortnite_2ecom_2fAI_2fCompanionAI_2ffort__br__ai__movement__interface_N_RSetLeashActor_L_Nentity_R
// (Public, BlueprintCallable)
// Parameters:
// class Entity*                  __verse_0xB2CDDD72_Argument    (ExportObject, Parm, ZeroConstructor, InstancedReference)

void fort_br_ai_movement_interface::_L_2fFortnite_2ecom_2fAI_2fCompanionAI_2ffort__br__ai__movement__interface_N_RSetLeashActor_L_Nentity_R(class Entity* __verse_0xB2CDDD72_Argument)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CompanionAI.fort_br_ai_movement_interface._L_2fFortnite_2ecom_2fAI_2fCompanionAI_2ffort__br__ai__movement__interface_N_RSetLeashActor_L_Nentity_R"));

	fort_br_ai_movement_interface__L_2fFortnite_2ecom_2fAI_2fCompanionAI_2ffort__br__ai__movement__interface_N_RSetLeashActor_L_Nentity_R_Params params;
	params.__verse_0xB2CDDD72_Argument = __verse_0xB2CDDD72_Argument;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CompanionAI.fort_npc_component._L_2fFortnite_2ecom_2fAI_2fCompanionAI_2ffort__br__ai__movement__interface_N_RSetLeashActor_L_Nentity_R
// (Native, Public, BlueprintCallable)
// Parameters:
// class Entity*                  __verse_0xB2CDDD72_Argument    (ExportObject, Parm, ZeroConstructor, InstancedReference)

void fort_npc_component::_L_2fFortnite_2ecom_2fAI_2fCompanionAI_2ffort__br__ai__movement__interface_N_RSetLeashActor_L_Nentity_R(class Entity* __verse_0xB2CDDD72_Argument)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CompanionAI.fort_npc_component._L_2fFortnite_2ecom_2fAI_2fCompanionAI_2ffort__br__ai__movement__interface_N_RSetLeashActor_L_Nentity_R"));

	fort_npc_component__L_2fFortnite_2ecom_2fAI_2fCompanionAI_2ffort__br__ai__movement__interface_N_RSetLeashActor_L_Nentity_R_Params params;
	params.__verse_0xB2CDDD72_Argument = __verse_0xB2CDDD72_Argument;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CompanionAI.fort_npc_component.RunDefaultBehavior
// (Public, HasOutParms, BlueprintCallable)
// Parameters:
// class task_t_*                 __verse_0xC1E81372_CallingTask (ExportObject, Parm, ZeroConstructor, InstancedReference)
// int64_t                        __verse_0xA3A00DDB_CallerResumeState (Parm, ZeroConstructor, IsPlainOldData)
// int64_t                        __verse_0x2AC0E4D8_CallerCancelState (Parm, ZeroConstructor, IsPlainOldData)
// struct FCompanionAI_Ftuple_L_R __verse_0xB2CDDD72_Argument    (Parm)
// class task_t_*                 RetVal                         (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)

class task_t_* fort_npc_component::RunDefaultBehavior(class task_t_* __verse_0xC1E81372_CallingTask, int64_t __verse_0xA3A00DDB_CallerResumeState, int64_t __verse_0x2AC0E4D8_CallerCancelState, const struct FCompanionAI_Ftuple_L_R& __verse_0xB2CDDD72_Argument)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CompanionAI.fort_npc_component.RunDefaultBehavior"));

	fort_npc_component_RunDefaultBehavior_Params params;
	params.__verse_0xC1E81372_CallingTask = __verse_0xC1E81372_CallingTask;
	params.__verse_0xA3A00DDB_CallerResumeState = __verse_0xA3A00DDB_CallerResumeState;
	params.__verse_0x2AC0E4D8_CallerCancelState = __verse_0x2AC0E4D8_CallerCancelState;
	params.__verse_0xB2CDDD72_Argument = __verse_0xB2CDDD72_Argument;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.RetVal;
}


// Function CompanionAI.fort_npc_component.$InitInstance
// ()

void fort_npc_component::$InitInstance()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CompanionAI.fort_npc_component.$InitInstance"));

	fort_npc_component_$InitInstance_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CompanionAI.fort_npc_component.$Block
// ()

void fort_npc_component::$Block()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CompanionAI.fort_npc_component.$Block"));

	fort_npc_component_$Block_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CompanionAI.fort_npc_component.$InitCDO
// ()

void fort_npc_component::$InitCDO()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CompanionAI.fort_npc_component.$InitCDO"));

	fort_npc_component_$InitCDO_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CompanionAI.fort_ping_interface._L_2fFortnite_2ecom_2fAI_2fCompanionAI_2ffort__ping__interface_N_RUnconvertedEvent
// (Public, HasOutParms, BlueprintCallable)
// Parameters:
// struct FCompanionAI_Ftuple_L_R __verse_0xB2CDDD72_Argument    (Parm)
// class Object_32759*            RetVal                         (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)

class Object_32759* fort_ping_interface::_L_2fFortnite_2ecom_2fAI_2fCompanionAI_2ffort__ping__interface_N_RUnconvertedEvent(const struct FCompanionAI_Ftuple_L_R& __verse_0xB2CDDD72_Argument)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CompanionAI.fort_ping_interface._L_2fFortnite_2ecom_2fAI_2fCompanionAI_2ffort__ping__interface_N_RUnconvertedEvent"));

	fort_ping_interface__L_2fFortnite_2ecom_2fAI_2fCompanionAI_2ffort__ping__interface_N_RUnconvertedEvent_Params params;
	params.__verse_0xB2CDDD72_Argument = __verse_0xB2CDDD72_Argument;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.RetVal;
}


// Function CompanionAI.fort_ping_interface.OnNPCCommand
// (Public, HasOutParms, BlueprintCallable)
// Parameters:
// class task_t_*                 __verse_0xC1E81372_CallingTask (ExportObject, Parm, ZeroConstructor, InstancedReference)
// int64_t                        __verse_0xA3A00DDB_CallerResumeState (Parm, ZeroConstructor, IsPlainOldData)
// int64_t                        __verse_0x2AC0E4D8_CallerCancelState (Parm, ZeroConstructor, IsPlainOldData)
// struct FCompanionAI_Ftuple_L_R __verse_0xB2CDDD72_Argument    (Parm)
// class task_t_*                 RetVal                         (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)

class task_t_* fort_ping_interface::OnNPCCommand(class task_t_* __verse_0xC1E81372_CallingTask, int64_t __verse_0xA3A00DDB_CallerResumeState, int64_t __verse_0x2AC0E4D8_CallerCancelState, const struct FCompanionAI_Ftuple_L_R& __verse_0xB2CDDD72_Argument)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CompanionAI.fort_ping_interface.OnNPCCommand"));

	fort_ping_interface_OnNPCCommand_Params params;
	params.__verse_0xC1E81372_CallingTask = __verse_0xC1E81372_CallingTask;
	params.__verse_0xA3A00DDB_CallerResumeState = __verse_0xA3A00DDB_CallerResumeState;
	params.__verse_0x2AC0E4D8_CallerCancelState = __verse_0x2AC0E4D8_CallerCancelState;
	params.__verse_0xB2CDDD72_Argument = __verse_0xB2CDDD72_Argument;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.RetVal;
}


// Function CompanionAI.fort_ping_interface._L_2fFortnite_2ecom_2fAI_2fCompanionAI_2ffort__ping__interface_N_RGetCurrentNPCCommand
// (Public, HasOutParms, BlueprintCallable)
// Parameters:
// struct FCompanionAI_Ftuple_L_R __verse_0xB2CDDD72_Argument    (Parm)

void fort_ping_interface::_L_2fFortnite_2ecom_2fAI_2fCompanionAI_2ffort__ping__interface_N_RGetCurrentNPCCommand(const struct FCompanionAI_Ftuple_L_R& __verse_0xB2CDDD72_Argument)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CompanionAI.fort_ping_interface._L_2fFortnite_2ecom_2fAI_2fCompanionAI_2ffort__ping__interface_N_RGetCurrentNPCCommand"));

	fort_ping_interface__L_2fFortnite_2ecom_2fAI_2fCompanionAI_2ffort__ping__interface_N_RGetCurrentNPCCommand_Params params;
	params.__verse_0xB2CDDD72_Argument = __verse_0xB2CDDD72_Argument;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CompanionAI.fort_ping_interface._L_2fFortnite_2ecom_2fAI_2fCompanionAI_2ffort__ping__interface_N_REnableCommandWheel_L_Nlogic_R
// (Public, BlueprintCallable)
// Parameters:
// bool                           __verse_0xB2CDDD72_Argument    (Parm)

void fort_ping_interface::_L_2fFortnite_2ecom_2fAI_2fCompanionAI_2ffort__ping__interface_N_REnableCommandWheel_L_Nlogic_R(bool __verse_0xB2CDDD72_Argument)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CompanionAI.fort_ping_interface._L_2fFortnite_2ecom_2fAI_2fCompanionAI_2ffort__ping__interface_N_REnableCommandWheel_L_Nlogic_R"));

	fort_ping_interface__L_2fFortnite_2ecom_2fAI_2fCompanionAI_2ffort__ping__interface_N_REnableCommandWheel_L_Nlogic_R_Params params;
	params.__verse_0xB2CDDD72_Argument = __verse_0xB2CDDD72_Argument;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CompanionAI.fort_ping_interface._L_2fFortnite_2ecom_2fAI_2fCompanionAI_2ffort__ping__interface_N_RDeclineNPCCommand_L_Nlogic_R
// (Public, BlueprintCallable)
// Parameters:
// bool                           __verse_0xB2CDDD72_Argument    (Parm)

void fort_ping_interface::_L_2fFortnite_2ecom_2fAI_2fCompanionAI_2ffort__ping__interface_N_RDeclineNPCCommand_L_Nlogic_R(bool __verse_0xB2CDDD72_Argument)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CompanionAI.fort_ping_interface._L_2fFortnite_2ecom_2fAI_2fCompanionAI_2ffort__ping__interface_N_RDeclineNPCCommand_L_Nlogic_R"));

	fort_ping_interface__L_2fFortnite_2ecom_2fAI_2fCompanionAI_2ffort__ping__interface_N_RDeclineNPCCommand_L_Nlogic_R_Params params;
	params.__verse_0xB2CDDD72_Argument = __verse_0xB2CDDD72_Argument;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CompanionAI.fort_ping_interface._L_2fFortnite_2ecom_2fAI_2fCompanionAI_2ffort__ping__interface_N_RConvertedEvent
// (Public, HasOutParms, BlueprintCallable)
// Parameters:
// struct FCompanionAI_Ftuple_L_R __verse_0xB2CDDD72_Argument    (Parm)
// class Object_32759*            RetVal                         (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)

class Object_32759* fort_ping_interface::_L_2fFortnite_2ecom_2fAI_2fCompanionAI_2ffort__ping__interface_N_RConvertedEvent(const struct FCompanionAI_Ftuple_L_R& __verse_0xB2CDDD72_Argument)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CompanionAI.fort_ping_interface._L_2fFortnite_2ecom_2fAI_2fCompanionAI_2ffort__ping__interface_N_RConvertedEvent"));

	fort_ping_interface__L_2fFortnite_2ecom_2fAI_2fCompanionAI_2ffort__ping__interface_N_RConvertedEvent_Params params;
	params.__verse_0xB2CDDD72_Argument = __verse_0xB2CDDD72_Argument;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.RetVal;
}


// Function CompanionAI.fort_ping_interface._L_2fFortnite_2ecom_2fAI_2fCompanionAI_2ffort__ping__interface_N_RAreNPCCommandsEnabled
// (Public, HasOutParms, BlueprintCallable)
// Parameters:
// struct FCompanionAI_Ftuple_L_R __verse_0xB2CDDD72_Argument    (Parm)
// bool                           RetVal                         (Parm, OutParm, ReturnParm)

bool fort_ping_interface::_L_2fFortnite_2ecom_2fAI_2fCompanionAI_2ffort__ping__interface_N_RAreNPCCommandsEnabled(const struct FCompanionAI_Ftuple_L_R& __verse_0xB2CDDD72_Argument)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CompanionAI.fort_ping_interface._L_2fFortnite_2ecom_2fAI_2fCompanionAI_2ffort__ping__interface_N_RAreNPCCommandsEnabled"));

	fort_ping_interface__L_2fFortnite_2ecom_2fAI_2fCompanionAI_2ffort__ping__interface_N_RAreNPCCommandsEnabled_Params params;
	params.__verse_0xB2CDDD72_Argument = __verse_0xB2CDDD72_Argument;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.RetVal;
}


// Function CompanionAI.log_companion_ai.$InitInstance
// ()

void log_companion_ai::$InitInstance()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CompanionAI.log_companion_ai.$InitInstance"));

	log_companion_ai_$InitInstance_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CompanionAI.log_companion_ai.$Block
// ()

void log_companion_ai::$Block()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CompanionAI.log_companion_ai.$Block"));

	log_companion_ai_$Block_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CompanionAI.log_companion_ai.$InitCDO
// ()

void log_companion_ai::$InitCDO()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CompanionAI.log_companion_ai.$InitCDO"));

	log_companion_ai_$InitCDO_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CompanionAI.ping_component._L_2fFortnite_2ecom_2fAI_2fCompanionAI_2ffort__ping__interface_N_RUnconvertedEvent
// (Public, HasOutParms, BlueprintCallable)
// Parameters:
// struct FCompanionAI_Ftuple_L_R __verse_0xB2CDDD72_Argument    (Parm)
// class Object_32759*            RetVal                         (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)

class Object_32759* ping_component::_L_2fFortnite_2ecom_2fAI_2fCompanionAI_2ffort__ping__interface_N_RUnconvertedEvent(const struct FCompanionAI_Ftuple_L_R& __verse_0xB2CDDD72_Argument)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CompanionAI.ping_component._L_2fFortnite_2ecom_2fAI_2fCompanionAI_2ffort__ping__interface_N_RUnconvertedEvent"));

	ping_component__L_2fFortnite_2ecom_2fAI_2fCompanionAI_2ffort__ping__interface_N_RUnconvertedEvent_Params params;
	params.__verse_0xB2CDDD72_Argument = __verse_0xB2CDDD72_Argument;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.RetVal;
}


// Function CompanionAI.ping_component.OnNPCCommand
// (Public, HasOutParms, BlueprintCallable)
// Parameters:
// class task_t_*                 __verse_0xC1E81372_CallingTask (ExportObject, Parm, ZeroConstructor, InstancedReference)
// int64_t                        __verse_0xA3A00DDB_CallerResumeState (Parm, ZeroConstructor, IsPlainOldData)
// int64_t                        __verse_0x2AC0E4D8_CallerCancelState (Parm, ZeroConstructor, IsPlainOldData)
// struct FCompanionAI_Ftuple_L_R __verse_0xB2CDDD72_Argument    (Parm)
// class task_t_*                 RetVal                         (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)

class task_t_* ping_component::OnNPCCommand(class task_t_* __verse_0xC1E81372_CallingTask, int64_t __verse_0xA3A00DDB_CallerResumeState, int64_t __verse_0x2AC0E4D8_CallerCancelState, const struct FCompanionAI_Ftuple_L_R& __verse_0xB2CDDD72_Argument)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CompanionAI.ping_component.OnNPCCommand"));

	ping_component_OnNPCCommand_Params params;
	params.__verse_0xC1E81372_CallingTask = __verse_0xC1E81372_CallingTask;
	params.__verse_0xA3A00DDB_CallerResumeState = __verse_0xA3A00DDB_CallerResumeState;
	params.__verse_0x2AC0E4D8_CallerCancelState = __verse_0x2AC0E4D8_CallerCancelState;
	params.__verse_0xB2CDDD72_Argument = __verse_0xB2CDDD72_Argument;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.RetVal;
}


// Function CompanionAI.ping_component._L_2fFortnite_2ecom_2fAI_2fCompanionAI_2ffort__ping__interface_N_RGetCurrentNPCCommand
// (Native, Public, HasOutParms, BlueprintCallable)
// Parameters:
// struct FCompanionAI_Ftuple_L_R __verse_0xB2CDDD72_Argument    (Parm)

void ping_component::_L_2fFortnite_2ecom_2fAI_2fCompanionAI_2ffort__ping__interface_N_RGetCurrentNPCCommand(const struct FCompanionAI_Ftuple_L_R& __verse_0xB2CDDD72_Argument)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CompanionAI.ping_component._L_2fFortnite_2ecom_2fAI_2fCompanionAI_2ffort__ping__interface_N_RGetCurrentNPCCommand"));

	ping_component__L_2fFortnite_2ecom_2fAI_2fCompanionAI_2ffort__ping__interface_N_RGetCurrentNPCCommand_Params params;
	params.__verse_0xB2CDDD72_Argument = __verse_0xB2CDDD72_Argument;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CompanionAI.ping_component._L_2fFortnite_2ecom_2fAI_2fCompanionAI_2ffort__ping__interface_N_REnableCommandWheel_L_Nlogic_R
// (Native, Public, BlueprintCallable)
// Parameters:
// bool                           __verse_0xB2CDDD72_Argument    (Parm)

void ping_component::_L_2fFortnite_2ecom_2fAI_2fCompanionAI_2ffort__ping__interface_N_REnableCommandWheel_L_Nlogic_R(bool __verse_0xB2CDDD72_Argument)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CompanionAI.ping_component._L_2fFortnite_2ecom_2fAI_2fCompanionAI_2ffort__ping__interface_N_REnableCommandWheel_L_Nlogic_R"));

	ping_component__L_2fFortnite_2ecom_2fAI_2fCompanionAI_2ffort__ping__interface_N_REnableCommandWheel_L_Nlogic_R_Params params;
	params.__verse_0xB2CDDD72_Argument = __verse_0xB2CDDD72_Argument;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CompanionAI.ping_component._L_2fFortnite_2ecom_2fAI_2fCompanionAI_2ffort__ping__interface_N_RDeclineNPCCommand_L_Nlogic_R
// (Native, Public, BlueprintCallable)
// Parameters:
// bool                           __verse_0xB2CDDD72_Argument    (Parm)

void ping_component::_L_2fFortnite_2ecom_2fAI_2fCompanionAI_2ffort__ping__interface_N_RDeclineNPCCommand_L_Nlogic_R(bool __verse_0xB2CDDD72_Argument)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CompanionAI.ping_component._L_2fFortnite_2ecom_2fAI_2fCompanionAI_2ffort__ping__interface_N_RDeclineNPCCommand_L_Nlogic_R"));

	ping_component__L_2fFortnite_2ecom_2fAI_2fCompanionAI_2ffort__ping__interface_N_RDeclineNPCCommand_L_Nlogic_R_Params params;
	params.__verse_0xB2CDDD72_Argument = __verse_0xB2CDDD72_Argument;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CompanionAI.ping_component._L_2fFortnite_2ecom_2fAI_2fCompanionAI_2ffort__ping__interface_N_RConvertedEvent
// (Public, HasOutParms, BlueprintCallable)
// Parameters:
// struct FCompanionAI_Ftuple_L_R __verse_0xB2CDDD72_Argument    (Parm)
// class Object_32759*            RetVal                         (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)

class Object_32759* ping_component::_L_2fFortnite_2ecom_2fAI_2fCompanionAI_2ffort__ping__interface_N_RConvertedEvent(const struct FCompanionAI_Ftuple_L_R& __verse_0xB2CDDD72_Argument)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CompanionAI.ping_component._L_2fFortnite_2ecom_2fAI_2fCompanionAI_2ffort__ping__interface_N_RConvertedEvent"));

	ping_component__L_2fFortnite_2ecom_2fAI_2fCompanionAI_2ffort__ping__interface_N_RConvertedEvent_Params params;
	params.__verse_0xB2CDDD72_Argument = __verse_0xB2CDDD72_Argument;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.RetVal;
}


// Function CompanionAI.ping_component._L_2fFortnite_2ecom_2fAI_2fCompanionAI_2ffort__ping__interface_N_RAreNPCCommandsEnabled
// (Native, Public, HasOutParms, BlueprintCallable)
// Parameters:
// struct FCompanionAI_Ftuple_L_R __verse_0xB2CDDD72_Argument    (Parm)
// bool                           RetVal                         (Parm, OutParm, ReturnParm)

bool ping_component::_L_2fFortnite_2ecom_2fAI_2fCompanionAI_2ffort__ping__interface_N_RAreNPCCommandsEnabled(const struct FCompanionAI_Ftuple_L_R& __verse_0xB2CDDD72_Argument)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CompanionAI.ping_component._L_2fFortnite_2ecom_2fAI_2fCompanionAI_2ffort__ping__interface_N_RAreNPCCommandsEnabled"));

	ping_component__L_2fFortnite_2ecom_2fAI_2fCompanionAI_2ffort__ping__interface_N_RAreNPCCommandsEnabled_Params params;
	params.__verse_0xB2CDDD72_Argument = __verse_0xB2CDDD72_Argument;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.RetVal;
}


// Function CompanionAI.ping_component.$InitInstance
// ()

void ping_component::$InitInstance()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CompanionAI.ping_component.$InitInstance"));

	ping_component_$InitInstance_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CompanionAI.ping_component.$Block
// ()

void ping_component::$Block()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CompanionAI.ping_component.$Block"));

	ping_component_$Block_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CompanionAI.ping_component.$InitCDO
// (HasDefaults)

void ping_component::$InitCDO()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CompanionAI.ping_component.$InitCDO"));

	ping_component_$InitCDO_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CompanionAI.task_companion_ai$CrouchService.Update
// (Public, HasOutParms)
// Parameters:
// int64_t                        RetVal                         (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int64_t task_companion_ai$CrouchService::Update()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CompanionAI.task_companion_ai$CrouchService.Update"));

	task_companion_ai$CrouchService_Update_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.RetVal;
}


// Function CompanionAI.task_companion_ai$CrouchUntilHit.Update
// (Public, HasOutParms)
// Parameters:
// int64_t                        RetVal                         (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int64_t task_companion_ai$CrouchUntilHit::Update()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CompanionAI.task_companion_ai$CrouchUntilHit.Update"));

	task_companion_ai$CrouchUntilHit_Update_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.RetVal;
}


// Function CompanionAI.task_companion_ai$DrawSphere_L_Nvector3_M_Nfloat_M_Ncolor_R.Update
// (Public, HasOutParms)
// Parameters:
// int64_t                        RetVal                         (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int64_t task_companion_ai$DrawSphere_L_Nvector3_M_Nfloat_M_Ncolor_R::Update()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CompanionAI.task_companion_ai$DrawSphere_L_Nvector3_M_Nfloat_M_Ncolor_R.Update"));

	task_companion_ai$DrawSphere_L_Nvector3_M_Nfloat_M_Ncolor_R_Update_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.RetVal;
}


// Function CompanionAI.task_companion_ai$GameLoop.Update
// (Public, HasOutParms)
// Parameters:
// int64_t                        RetVal                         (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int64_t task_companion_ai$GameLoop::Update()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CompanionAI.task_companion_ai$GameLoop.Update"));

	task_companion_ai$GameLoop_Update_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.RetVal;
}


// Function CompanionAI.task_companion_ai$GetNewObstacle.Update
// (Public, HasOutParms)
// Parameters:
// int64_t                        RetVal                         (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int64_t task_companion_ai$GetNewObstacle::Update()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CompanionAI.task_companion_ai$GetNewObstacle.Update"));

	task_companion_ai$GetNewObstacle_Update_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.RetVal;
}


// Function CompanionAI.task_companion_ai$GetNewTargetPerception_L_N_Qthreat__info_R.Update
// (Public, HasOutParms)
// Parameters:
// int64_t                        RetVal                         (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int64_t task_companion_ai$GetNewTargetPerception_L_N_Qthreat__info_R::Update()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CompanionAI.task_companion_ai$GetNewTargetPerception_L_N_Qthreat__info_R.Update"));

	task_companion_ai$GetNewTargetPerception_L_N_Qthreat__info_R_Update_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.RetVal;
}


// Function CompanionAI.task_companion_ai$GetNewThreat.Update
// (Public, HasOutParms)
// Parameters:
// int64_t                        RetVal                         (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int64_t task_companion_ai$GetNewThreat::Update()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CompanionAI.task_companion_ai$GetNewThreat.Update"));

	task_companion_ai$GetNewThreat_Update_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.RetVal;
}


// Function CompanionAI.task_companion_ai$GetObstacle.Update
// (Public, HasOutParms)
// Parameters:
// int64_t                        RetVal                         (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int64_t task_companion_ai$GetObstacle::Update()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CompanionAI.task_companion_ai$GetObstacle.Update"));

	task_companion_ai$GetObstacle_Update_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.RetVal;
}


// Function CompanionAI.task_companion_ai$GetThreat.Update
// (Public, HasOutParms)
// Parameters:
// int64_t                        RetVal                         (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int64_t task_companion_ai$GetThreat::Update()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CompanionAI.task_companion_ai$GetThreat.Update"));

	task_companion_ai$GetThreat_Update_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.RetVal;
}


// Function CompanionAI.task_companion_ai$GoToAndAttackTask_L_Nthreat__info_R.Update
// (Public, HasOutParms)
// Parameters:
// int64_t                        RetVal                         (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int64_t task_companion_ai$GoToAndAttackTask_L_Nthreat__info_R::Update()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CompanionAI.task_companion_ai$GoToAndAttackTask_L_Nthreat__info_R.Update"));

	task_companion_ai$GoToAndAttackTask_L_Nthreat__info_R_Update_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.RetVal;
}


// Function CompanionAI.task_companion_ai$GoToPositionTask_L_Nvector3_M_N_Qfort__character_M_Nlogic_M_Nnavigation__parameters_R.Update
// (Public, HasOutParms, HasDefaults)
// Parameters:
// int64_t                        RetVal                         (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int64_t task_companion_ai$GoToPositionTask_L_Nvector3_M_N_Qfort__character_M_Nlogic_M_Nnavigation__parameters_R::Update()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CompanionAI.task_companion_ai$GoToPositionTask_L_Nvector3_M_N_Qfort__character_M_Nlogic_M_Nnavigation__parameters_R.Update"));

	task_companion_ai$GoToPositionTask_L_Nvector3_M_N_Qfort__character_M_Nlogic_M_Nnavigation__parameters_R_Update_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.RetVal;
}


// Function CompanionAI.task_companion_ai$HandleBackToMeCommand_L_Nping__info_R.Update
// (Public, HasOutParms)
// Parameters:
// int64_t                        RetVal                         (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int64_t task_companion_ai$HandleBackToMeCommand_L_Nping__info_R::Update()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CompanionAI.task_companion_ai$HandleBackToMeCommand_L_Nping__info_R.Update"));

	task_companion_ai$HandleBackToMeCommand_L_Nping__info_R_Update_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.RetVal;
}


// Function CompanionAI.task_companion_ai$HandleGoTo_L_Nping__info_R.Update
// (Public, HasOutParms)
// Parameters:
// int64_t                        RetVal                         (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int64_t task_companion_ai$HandleGoTo_L_Nping__info_R::Update()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CompanionAI.task_companion_ai$HandleGoTo_L_Nping__info_R.Update"));

	task_companion_ai$HandleGoTo_L_Nping__info_R_Update_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.RetVal;
}


// Function CompanionAI.task_companion_ai$HandleGoToCommand_L_Nping__info_R.Update
// (Public, HasOutParms)
// Parameters:
// int64_t                        RetVal                         (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int64_t task_companion_ai$HandleGoToCommand_L_Nping__info_R::Update()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CompanionAI.task_companion_ai$HandleGoToCommand_L_Nping__info_R.Update"));

	task_companion_ai$HandleGoToCommand_L_Nping__info_R_Update_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.RetVal;
}


// Function CompanionAI.task_companion_ai$HandleHoldPositionCommand_L_Nping__info_R.Update
// (Public, HasOutParms)
// Parameters:
// int64_t                        RetVal                         (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int64_t task_companion_ai$HandleHoldPositionCommand_L_Nping__info_R::Update()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CompanionAI.task_companion_ai$HandleHoldPositionCommand_L_Nping__info_R.Update"));

	task_companion_ai$HandleHoldPositionCommand_L_Nping__info_R_Update_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.RetVal;
}


// Function CompanionAI.task_companion_ai$HandleNPCCommand_L_Nping__info_R.Update
// (Public, HasOutParms)
// Parameters:
// int64_t                        RetVal                         (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int64_t task_companion_ai$HandleNPCCommand_L_Nping__info_R::Update()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CompanionAI.task_companion_ai$HandleNPCCommand_L_Nping__info_R.Update"));

	task_companion_ai$HandleNPCCommand_L_Nping__info_R_Update_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.RetVal;
}


// Function CompanionAI.task_companion_ai$HandleObstacleTask_L_N_Qentity_R.Update
// (Public, HasOutParms)
// Parameters:
// int64_t                        RetVal                         (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int64_t task_companion_ai$HandleObstacleTask_L_N_Qentity_R::Update()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CompanionAI.task_companion_ai$HandleObstacleTask_L_N_Qentity_R.Update"));

	task_companion_ai$HandleObstacleTask_L_N_Qentity_R_Update_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.RetVal;
}


// Function CompanionAI.task_companion_ai$HandleReviveCommand_L_Nping__info_R.Update
// (Public, HasOutParms)
// Parameters:
// int64_t                        RetVal                         (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int64_t task_companion_ai$HandleReviveCommand_L_Nping__info_R::Update()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CompanionAI.task_companion_ai$HandleReviveCommand_L_Nping__info_R.Update"));

	task_companion_ai$HandleReviveCommand_L_Nping__info_R_Update_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.RetVal;
}


// Function CompanionAI.task_companion_ai$LookAroundTask_L_Nvector3_M_Nfloat_M_Nfloat_R.Update
// (Public, HasOutParms)
// Parameters:
// int64_t                        RetVal                         (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int64_t task_companion_ai$LookAroundTask_L_Nvector3_M_Nfloat_M_Nfloat_R::Update()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CompanionAI.task_companion_ai$LookAroundTask_L_Nvector3_M_Nfloat_M_Nfloat_R.Update"));

	task_companion_ai$LookAroundTask_L_Nvector3_M_Nfloat_M_Nfloat_R_Update_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.RetVal;
}


// Function CompanionAI.task_companion_ai$LookAtOrAttackTarget.Update
// (Public, HasOutParms)
// Parameters:
// int64_t                        RetVal                         (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int64_t task_companion_ai$LookAtOrAttackTarget::Update()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CompanionAI.task_companion_ai$LookAtOrAttackTarget.Update"));

	task_companion_ai$LookAtOrAttackTarget_Update_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.RetVal;
}


// Function CompanionAI.task_companion_ai$LookAtThreatTask.Update
// (Public, HasOutParms)
// Parameters:
// int64_t                        RetVal                         (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int64_t task_companion_ai$LookAtThreatTask::Update()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CompanionAI.task_companion_ai$LookAtThreatTask.Update"));

	task_companion_ai$LookAtThreatTask_Update_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.RetVal;
}


// Function CompanionAI.task_companion_ai$OnBegin.Update
// (Public, HasOutParms)
// Parameters:
// int64_t                        RetVal                         (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int64_t task_companion_ai$OnBegin::Update()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CompanionAI.task_companion_ai$OnBegin.Update"));

	task_companion_ai$OnBegin_Update_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.RetVal;
}


// Function CompanionAI.task_companion_ai$ReviveCommand_L_Nfort__character_R.Update
// (Public, HasOutParms)
// Parameters:
// int64_t                        RetVal                         (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int64_t task_companion_ai$ReviveCommand_L_Nfort__character_R::Update()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CompanionAI.task_companion_ai$ReviveCommand_L_Nfort__character_R.Update"));

	task_companion_ai$ReviveCommand_L_Nfort__character_R_Update_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.RetVal;
}


// Function CompanionAI.task_companion_ai$SetLeashPosition_L_Nvector3_M_Nfloat_M_Nentity_R.Update
// (Public, HasOutParms)
// Parameters:
// int64_t                        RetVal                         (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int64_t task_companion_ai$SetLeashPosition_L_Nvector3_M_Nfloat_M_Nentity_R::Update()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CompanionAI.task_companion_ai$SetLeashPosition_L_Nvector3_M_Nfloat_M_Nentity_R.Update"));

	task_companion_ai$SetLeashPosition_L_Nvector3_M_Nfloat_M_Nentity_R_Update_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.RetVal;
}


// Function CompanionAI.task_companion_ai$ShootTargetService_L_Nfloat_R.Update
// (Public, HasOutParms)
// Parameters:
// int64_t                        RetVal                         (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int64_t task_companion_ai$ShootTargetService_L_Nfloat_R::Update()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CompanionAI.task_companion_ai$ShootTargetService_L_Nfloat_R.Update"));

	task_companion_ai$ShootTargetService_L_Nfloat_R_Update_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.RetVal;
}


// Function CompanionAI.task_companion_ai$SprintService.Update
// (Public, HasOutParms)
// Parameters:
// int64_t                        RetVal                         (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int64_t task_companion_ai$SprintService::Update()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CompanionAI.task_companion_ai$SprintService.Update"));

	task_companion_ai$SprintService_Update_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.RetVal;
}


// Function CompanionAI.task_companion_ai$TacticalSprintService.Update
// (Public, HasOutParms)
// Parameters:
// int64_t                        RetVal                         (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int64_t task_companion_ai$TacticalSprintService::Update()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CompanionAI.task_companion_ai$TacticalSprintService.Update"));

	task_companion_ai$TacticalSprintService_Update_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.RetVal;
}


// Function CompanionAI.task_companion_ai$WaitForDamage.Update
// (Public, HasOutParms)
// Parameters:
// int64_t                        RetVal                         (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int64_t task_companion_ai$WaitForDamage::Update()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CompanionAI.task_companion_ai$WaitForDamage.Update"));

	task_companion_ai$WaitForDamage_Update_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.RetVal;
}


// Function CompanionAI.task_companion_ai$WaitForEntityMovement_L_Nentity_M_Nfloat_R.Update
// (Public, HasOutParms)
// Parameters:
// int64_t                        RetVal                         (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int64_t task_companion_ai$WaitForEntityMovement_L_Nentity_M_Nfloat_R::Update()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CompanionAI.task_companion_ai$WaitForEntityMovement_L_Nentity_M_Nfloat_R.Update"));

	task_companion_ai$WaitForEntityMovement_L_Nentity_M_Nfloat_R_Update_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.RetVal;
}


// Function CompanionAI.task_fort_br_ai_actions_interface$RunDefaultBehavior.Update
// (Public, HasOutParms)
// Parameters:
// int64_t                        RetVal                         (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int64_t task_fort_br_ai_actions_interface$RunDefaultBehavior::Update()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CompanionAI.task_fort_br_ai_actions_interface$RunDefaultBehavior.Update"));

	task_fort_br_ai_actions_interface$RunDefaultBehavior_Update_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.RetVal;
}


// Function CompanionAI.task_fort_npc_component$RunDefaultBehavior.Update
// (Native, Public, HasOutParms)
// Parameters:
// int64_t                        RetVal                         (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int64_t task_fort_npc_component$RunDefaultBehavior::Update()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CompanionAI.task_fort_npc_component$RunDefaultBehavior.Update"));

	task_fort_npc_component$RunDefaultBehavior_Update_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.RetVal;
}


// Function CompanionAI.task_fort_ping_interface$OnNPCCommand.Update
// (Public, HasOutParms)
// Parameters:
// int64_t                        RetVal                         (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int64_t task_fort_ping_interface$OnNPCCommand::Update()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CompanionAI.task_fort_ping_interface$OnNPCCommand.Update"));

	task_fort_ping_interface$OnNPCCommand_Update_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.RetVal;
}


// Function CompanionAI.task_ping_component$OnNPCCommand.Update
// (Native, Public, HasOutParms)
// Parameters:
// int64_t                        RetVal                         (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int64_t task_ping_component$OnNPCCommand::Update()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CompanionAI.task_ping_component$OnNPCCommand.Update"));

	task_ping_component$OnNPCCommand_Update_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.RetVal;
}


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Classes
//---------------------------------------------------------------------------

// Class AmbientAudio.AmbientAudioComponent
// 0x0030 (0x00D8 - 0x00A8)
class AmbientAudioComponent : public AudioGameplayComponent
{
public:
	unsigned char                                      UnknownData00[0x8];                                       // 0x00A8(0x0008) MISSED OFFSET
	class AmbientAudioDataAsset*                       AmbientAsset_69;                                          // 0x00B0(0x0008) (Edit, BlueprintVisible, ZeroConstructor)
	int                                                Priority_69;                                              // 0x00B8(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              CrossfadeTime_69;                                         // 0x00BC(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FGuid                                       AmbientGuid_69;                                           // 0x00C0(0x0010) (ZeroConstructor, Transient, IsPlainOldData)
	struct FName                                       DisplayName_69;                                           // 0x00D0(0x0008) (ZeroConstructor, Transient, IsPlainOldData)
	unsigned char                                      UnknownData01[0x4];                                       // 0x00D4(0x0004) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AmbientAudio.AmbientAudioComponent"));
		
		return ptr;
	}


	void SetPriority(int InPriority_69);
	void SetCrossfadeTime(float InCrossfadeTime_69);
	void SetAmbientAsset(class AmbientAudioDataAsset* InAmbientAsset_69);
};


// Class AmbientAudio.AmbientAudioDataAsset
// 0x0028 (0x0058 - 0x0030)
class AmbientAudioDataAsset : public DataAsset
{
public:
	TArray<struct FAmbientAudioLoop>                   LoopingSounds_69;                                         // 0x0030(0x0010) (Edit, ZeroConstructor, DisableEditOnInstance)
	TArray<struct FAmbientAudioOneShot>                OneShotSounds_69;                                         // 0x0040(0x0010) (Edit, ZeroConstructor, DisableEditOnInstance)
	float                                              TagCrossfadeTime_69;                                      // 0x0050(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0054(0x0004) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AmbientAudio.AmbientAudioDataAsset"));
		
		return ptr;
	}

};


// Class AmbientAudio.AmbientAudioSubsystem
// 0x0220 (0x0250 - 0x0030)
class AmbientAudioSubsystem : public WorldSubsystem
{
public:
	unsigned char                                      UnknownData00[0x8];                                       // 0x0030(0x0008) MISSED OFFSET
	unsigned char                                      UnknownData01[0x10];                                      // 0x0030(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty AmbientAudio.AmbientAudioSubsystem.OnTagChanged_69
	unsigned char                                      UnknownData02[0x10];                                      // 0x0048(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty AmbientAudio.AmbientAudioSubsystem.OnEntryChanged_69
	TArray<class AmbientAudioComponent*>               AmbientComponents_69;                                     // 0x0058(0x0010) (ExportObject, ZeroConstructor, Transient)
	unsigned char                                      UnknownData03[0x1E8];                                     // 0x0068(0x01E8) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AmbientAudio.AmbientAudioSubsystem"));
		
		return ptr;
	}


	void RemoveGameplayTag(const struct FGameplayTag& GameplayTag_69);
	void RemoveAmbientEntry(const struct FName& AmbientName_69, float CrossfadeOverride_69);
	void AddGameplayTag(const struct FGameplayTag& GameplayTag_69);
	void AddAmbientEntry(const struct FName& AmbientName_69, class AmbientAudioDataAsset* Asset_69, int Priority_69, float CrossfadeTime_69);
};


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

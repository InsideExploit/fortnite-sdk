// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Functions
//---------------------------------------------------------------------------

// Function CommonUI.CommonActionWidget.SetInputActions
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// TArray<struct FDataTableRowHandle> NewInputActions_69             (Parm, ZeroConstructor)

void CommonActionWidget::SetInputActions(TArray<struct FDataTableRowHandle> NewInputActions_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonActionWidget.SetInputActions"));

	CommonActionWidget_SetInputActions_Params params;
	params.NewInputActions_69 = NewInputActions_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUI.CommonActionWidget.SetInputAction
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// struct FDataTableRowHandle     InputActionRow_69              (Parm)

void CommonActionWidget::SetInputAction(const struct FDataTableRowHandle& InputActionRow_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonActionWidget.SetInputAction"));

	CommonActionWidget_SetInputAction_Params params;
	params.InputActionRow_69 = InputActionRow_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUI.CommonActionWidget.SetIconRimBrush
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// struct FSlateBrush             InIconRimBrush_69              (Parm)

void CommonActionWidget::SetIconRimBrush(const struct FSlateBrush& InIconRimBrush_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonActionWidget.SetIconRimBrush"));

	CommonActionWidget_SetIconRimBrush_Params params;
	params.InIconRimBrush_69 = InIconRimBrush_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// DelegateFunction CommonUI.CommonActionWidget.OnInputMethodChanged__DelegateSignature
// (MulticastDelegate, Public, Delegate)
// Parameters:
// bool                           bUsingGamepad_69               (Parm, ZeroConstructor, IsPlainOldData)

void CommonActionWidget::OnInputMethodChanged__DelegateSignature(bool bUsingGamepad_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("DelegateFunction CommonUI.CommonActionWidget.OnInputMethodChanged__DelegateSignature"));

	CommonActionWidget_OnInputMethodChanged__DelegateSignature_Params params;
	params.bUsingGamepad_69 = bUsingGamepad_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUI.CommonActionWidget.IsHeldAction
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool CommonActionWidget::IsHeldAction()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonActionWidget.IsHeldAction"));

	CommonActionWidget_IsHeldAction_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CommonUI.CommonActionWidget.GetIcon
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FSlateBrush             ReturnValue_69                 (Parm, OutParm, ReturnParm)

struct FSlateBrush CommonActionWidget::GetIcon()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonActionWidget.GetIcon"));

	CommonActionWidget_GetIcon_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CommonUI.CommonActionWidget.GetDisplayText
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FText                   ReturnValue_69                 (Parm, OutParm, ReturnParm)

struct FText CommonActionWidget::GetDisplayText()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonActionWidget.GetDisplayText"));

	CommonActionWidget_GetDisplayText_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CommonUI.CommonUserWidget.SetConsumePointerInput
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// bool                           bInConsumePointerInput_69      (Parm, ZeroConstructor, IsPlainOldData)

void CommonUserWidget::SetConsumePointerInput(bool bInConsumePointerInput_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonUserWidget.SetConsumePointerInput"));

	CommonUserWidget_SetConsumePointerInput_Params params;
	params.bInConsumePointerInput_69 = bInConsumePointerInput_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUI.CommonActivatableWidget.SetBindVisibilities
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// ESlateVisibility               OnActivatedVisibility_69       (Parm, ZeroConstructor, IsPlainOldData)
// ESlateVisibility               OnDeactivatedVisibility_69     (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bInAllActive_69                (Parm, ZeroConstructor, IsPlainOldData)

void CommonActivatableWidget::SetBindVisibilities(ESlateVisibility OnActivatedVisibility_69, ESlateVisibility OnDeactivatedVisibility_69, bool bInAllActive_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonActivatableWidget.SetBindVisibilities"));

	CommonActivatableWidget_SetBindVisibilities_Params params;
	params.OnActivatedVisibility_69 = OnActivatedVisibility_69;
	params.OnDeactivatedVisibility_69 = OnDeactivatedVisibility_69;
	params.bInAllActive_69 = bInAllActive_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUI.CommonActivatableWidget.IsActivated
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool CommonActivatableWidget::IsActivated()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonActivatableWidget.IsActivated"));

	CommonActivatableWidget_IsActivated_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CommonUI.CommonActivatableWidget.GetDesiredFocusTarget
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// class Widget*                  ReturnValue_69                 (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)

class Widget* CommonActivatableWidget::GetDesiredFocusTarget()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonActivatableWidget.GetDesiredFocusTarget"));

	CommonActivatableWidget_GetDesiredFocusTarget_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CommonUI.CommonActivatableWidget.DeactivateWidget
// (Final, Native, Public, BlueprintCallable)

void CommonActivatableWidget::DeactivateWidget()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonActivatableWidget.DeactivateWidget"));

	CommonActivatableWidget_DeactivateWidget_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUI.CommonActivatableWidget.BP_OnHandleBackAction
// (Event, Protected, BlueprintEvent)
// Parameters:
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool CommonActivatableWidget::BP_OnHandleBackAction()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonActivatableWidget.BP_OnHandleBackAction"));

	CommonActivatableWidget_BP_OnHandleBackAction_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CommonUI.CommonActivatableWidget.BP_OnDeactivated
// (Event, Protected, BlueprintEvent)

void CommonActivatableWidget::BP_OnDeactivated()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonActivatableWidget.BP_OnDeactivated"));

	CommonActivatableWidget_BP_OnDeactivated_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUI.CommonActivatableWidget.BP_OnActivated
// (Event, Protected, BlueprintEvent)

void CommonActivatableWidget::BP_OnActivated()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonActivatableWidget.BP_OnActivated"));

	CommonActivatableWidget_BP_OnActivated_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUI.CommonActivatableWidget.BP_GetDesiredFocusTarget
// (Event, Protected, BlueprintEvent, Const)
// Parameters:
// class Widget*                  ReturnValue_69                 (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)

class Widget* CommonActivatableWidget::BP_GetDesiredFocusTarget()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonActivatableWidget.BP_GetDesiredFocusTarget"));

	CommonActivatableWidget_BP_GetDesiredFocusTarget_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CommonUI.CommonActivatableWidget.BindVisibilityToActivation
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// class CommonActivatableWidget* ActivatableWidget_69           (Parm, ZeroConstructor, InstancedReference)

void CommonActivatableWidget::BindVisibilityToActivation(class CommonActivatableWidget* ActivatableWidget_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonActivatableWidget.BindVisibilityToActivation"));

	CommonActivatableWidget_BindVisibilityToActivation_Params params;
	params.ActivatableWidget_69 = ActivatableWidget_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUI.CommonActivatableWidget.ActivateWidget
// (Final, Native, Public, BlueprintCallable)

void CommonActivatableWidget::ActivateWidget()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonActivatableWidget.ActivateWidget"));

	CommonActivatableWidget_ActivateWidget_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUI.CommonAnimatedSwitcher.SetDisableTransitionAnimation
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// bool                           bDisableAnimation_69           (Parm, ZeroConstructor, IsPlainOldData)

void CommonAnimatedSwitcher::SetDisableTransitionAnimation(bool bDisableAnimation_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonAnimatedSwitcher.SetDisableTransitionAnimation"));

	CommonAnimatedSwitcher_SetDisableTransitionAnimation_Params params;
	params.bDisableAnimation_69 = bDisableAnimation_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUI.CommonAnimatedSwitcher.IsTransitionPlaying
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool CommonAnimatedSwitcher::IsTransitionPlaying()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonAnimatedSwitcher.IsTransitionPlaying"));

	CommonAnimatedSwitcher_IsTransitionPlaying_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CommonUI.CommonAnimatedSwitcher.IsCurrentlySwitching
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool CommonAnimatedSwitcher::IsCurrentlySwitching()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonAnimatedSwitcher.IsCurrentlySwitching"));

	CommonAnimatedSwitcher_IsCurrentlySwitching_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CommonUI.CommonAnimatedSwitcher.HasWidgets
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool CommonAnimatedSwitcher::HasWidgets()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonAnimatedSwitcher.HasWidgets"));

	CommonAnimatedSwitcher_HasWidgets_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CommonUI.CommonAnimatedSwitcher.ActivatePreviousWidget
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// bool                           bCanWrap_69                    (Parm, ZeroConstructor, IsPlainOldData)

void CommonAnimatedSwitcher::ActivatePreviousWidget(bool bCanWrap_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonAnimatedSwitcher.ActivatePreviousWidget"));

	CommonAnimatedSwitcher_ActivatePreviousWidget_Params params;
	params.bCanWrap_69 = bCanWrap_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUI.CommonAnimatedSwitcher.ActivateNextWidget
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// bool                           bCanWrap_69                    (Parm, ZeroConstructor, IsPlainOldData)

void CommonAnimatedSwitcher::ActivateNextWidget(bool bCanWrap_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonAnimatedSwitcher.ActivateNextWidget"));

	CommonAnimatedSwitcher_ActivateNextWidget_Params params;
	params.bCanWrap_69 = bCanWrap_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUI.CommonBorderStyle.GetBackgroundBrush
// (Final, Native, Public, HasOutParms, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FSlateBrush             Brush_69                       (Parm, OutParm)

void CommonBorderStyle::GetBackgroundBrush(struct FSlateBrush* Brush_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonBorderStyle.GetBackgroundBrush"));

	CommonBorderStyle_GetBackgroundBrush_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (Brush_69 != nullptr)
		*Brush_69 = params.Brush_69;
}


// Function CommonUI.CommonBorder.SetStyle
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// class CommonBorderStyle*       InStyle_69                     (Parm, ZeroConstructor)

void CommonBorder::SetStyle(class CommonBorderStyle* InStyle_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonBorder.SetStyle"));

	CommonBorder_SetStyle_Params params;
	params.InStyle_69 = InStyle_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUI.CommonButtonStyle.GetSelectedTextStyle
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// class CommonTextStyle*         ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

class CommonTextStyle* CommonButtonStyle::GetSelectedTextStyle()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonButtonStyle.GetSelectedTextStyle"));

	CommonButtonStyle_GetSelectedTextStyle_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CommonUI.CommonButtonStyle.GetSelectedPressedBrush
// (Final, Native, Public, HasOutParms, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FSlateBrush             Brush_69                       (Parm, OutParm)

void CommonButtonStyle::GetSelectedPressedBrush(struct FSlateBrush* Brush_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonButtonStyle.GetSelectedPressedBrush"));

	CommonButtonStyle_GetSelectedPressedBrush_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (Brush_69 != nullptr)
		*Brush_69 = params.Brush_69;
}


// Function CommonUI.CommonButtonStyle.GetSelectedHoveredTextStyle
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// class CommonTextStyle*         ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

class CommonTextStyle* CommonButtonStyle::GetSelectedHoveredTextStyle()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonButtonStyle.GetSelectedHoveredTextStyle"));

	CommonButtonStyle_GetSelectedHoveredTextStyle_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CommonUI.CommonButtonStyle.GetSelectedHoveredBrush
// (Final, Native, Public, HasOutParms, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FSlateBrush             Brush_69                       (Parm, OutParm)

void CommonButtonStyle::GetSelectedHoveredBrush(struct FSlateBrush* Brush_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonButtonStyle.GetSelectedHoveredBrush"));

	CommonButtonStyle_GetSelectedHoveredBrush_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (Brush_69 != nullptr)
		*Brush_69 = params.Brush_69;
}


// Function CommonUI.CommonButtonStyle.GetSelectedBaseBrush
// (Final, Native, Public, HasOutParms, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FSlateBrush             Brush_69                       (Parm, OutParm)

void CommonButtonStyle::GetSelectedBaseBrush(struct FSlateBrush* Brush_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonButtonStyle.GetSelectedBaseBrush"));

	CommonButtonStyle_GetSelectedBaseBrush_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (Brush_69 != nullptr)
		*Brush_69 = params.Brush_69;
}


// Function CommonUI.CommonButtonStyle.GetNormalTextStyle
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// class CommonTextStyle*         ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

class CommonTextStyle* CommonButtonStyle::GetNormalTextStyle()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonButtonStyle.GetNormalTextStyle"));

	CommonButtonStyle_GetNormalTextStyle_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CommonUI.CommonButtonStyle.GetNormalPressedBrush
// (Final, Native, Public, HasOutParms, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FSlateBrush             Brush_69                       (Parm, OutParm)

void CommonButtonStyle::GetNormalPressedBrush(struct FSlateBrush* Brush_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonButtonStyle.GetNormalPressedBrush"));

	CommonButtonStyle_GetNormalPressedBrush_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (Brush_69 != nullptr)
		*Brush_69 = params.Brush_69;
}


// Function CommonUI.CommonButtonStyle.GetNormalHoveredTextStyle
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// class CommonTextStyle*         ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

class CommonTextStyle* CommonButtonStyle::GetNormalHoveredTextStyle()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonButtonStyle.GetNormalHoveredTextStyle"));

	CommonButtonStyle_GetNormalHoveredTextStyle_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CommonUI.CommonButtonStyle.GetNormalHoveredBrush
// (Final, Native, Public, HasOutParms, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FSlateBrush             Brush_69                       (Parm, OutParm)

void CommonButtonStyle::GetNormalHoveredBrush(struct FSlateBrush* Brush_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonButtonStyle.GetNormalHoveredBrush"));

	CommonButtonStyle_GetNormalHoveredBrush_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (Brush_69 != nullptr)
		*Brush_69 = params.Brush_69;
}


// Function CommonUI.CommonButtonStyle.GetNormalBaseBrush
// (Final, Native, Public, HasOutParms, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FSlateBrush             Brush_69                       (Parm, OutParm)

void CommonButtonStyle::GetNormalBaseBrush(struct FSlateBrush* Brush_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonButtonStyle.GetNormalBaseBrush"));

	CommonButtonStyle_GetNormalBaseBrush_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (Brush_69 != nullptr)
		*Brush_69 = params.Brush_69;
}


// Function CommonUI.CommonButtonStyle.GetMaterialBrush
// (Final, Native, Public, HasOutParms, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FSlateBrush             Brush_69                       (Parm, OutParm)

void CommonButtonStyle::GetMaterialBrush(struct FSlateBrush* Brush_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonButtonStyle.GetMaterialBrush"));

	CommonButtonStyle_GetMaterialBrush_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (Brush_69 != nullptr)
		*Brush_69 = params.Brush_69;
}


// Function CommonUI.CommonButtonStyle.GetDisabledTextStyle
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// class CommonTextStyle*         ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

class CommonTextStyle* CommonButtonStyle::GetDisabledTextStyle()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonButtonStyle.GetDisabledTextStyle"));

	CommonButtonStyle_GetDisabledTextStyle_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CommonUI.CommonButtonStyle.GetDisabledBrush
// (Final, Native, Public, HasOutParms, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FSlateBrush             Brush_69                       (Parm, OutParm)

void CommonButtonStyle::GetDisabledBrush(struct FSlateBrush* Brush_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonButtonStyle.GetDisabledBrush"));

	CommonButtonStyle_GetDisabledBrush_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (Brush_69 != nullptr)
		*Brush_69 = params.Brush_69;
}


// Function CommonUI.CommonButtonStyle.GetCustomPadding
// (Final, Native, Public, HasOutParms, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FSlateCore_Fmargin      OutCustomPadding_69            (Parm, OutParm, ZeroConstructor, IsPlainOldData)

void CommonButtonStyle::GetCustomPadding(struct FSlateCore_Fmargin* OutCustomPadding_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonButtonStyle.GetCustomPadding"));

	CommonButtonStyle_GetCustomPadding_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (OutCustomPadding_69 != nullptr)
		*OutCustomPadding_69 = params.OutCustomPadding_69;
}


// Function CommonUI.CommonButtonStyle.GetButtonPadding
// (Final, Native, Public, HasOutParms, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FSlateCore_Fmargin      OutButtonPadding_69            (Parm, OutParm, ZeroConstructor, IsPlainOldData)

void CommonButtonStyle::GetButtonPadding(struct FSlateCore_Fmargin* OutButtonPadding_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonButtonStyle.GetButtonPadding"));

	CommonButtonStyle_GetButtonPadding_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (OutButtonPadding_69 != nullptr)
		*OutButtonPadding_69 = params.OutButtonPadding_69;
}


// Function CommonUI.CommonButtonBase.StopDoubleClickPropagation
// (Final, Native, Protected, BlueprintCallable)

void CommonButtonBase::StopDoubleClickPropagation()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonButtonBase.StopDoubleClickPropagation"));

	CommonButtonBase_StopDoubleClickPropagation_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUI.CommonButtonBase.SetTriggeringInputAction
// (Final, Native, Public, HasOutParms, BlueprintCallable)
// Parameters:
// struct FDataTableRowHandle     InputActionRow_69              (ConstParm, Parm, OutParm, ReferenceParm)

void CommonButtonBase::SetTriggeringInputAction(const struct FDataTableRowHandle& InputActionRow_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonButtonBase.SetTriggeringInputAction"));

	CommonButtonBase_SetTriggeringInputAction_Params params;
	params.InputActionRow_69 = InputActionRow_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUI.CommonButtonBase.SetTriggeredInputAction
// (Final, Native, Public, HasOutParms, BlueprintCallable)
// Parameters:
// struct FDataTableRowHandle     InputActionRow_69              (ConstParm, Parm, OutParm, ReferenceParm)

void CommonButtonBase::SetTriggeredInputAction(const struct FDataTableRowHandle& InputActionRow_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonButtonBase.SetTriggeredInputAction"));

	CommonButtonBase_SetTriggeredInputAction_Params params;
	params.InputActionRow_69 = InputActionRow_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUI.CommonButtonBase.SetTouchMethod
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// TEnumAsByte<EButtonTouchMethod> InTouchMethod_69               (Parm, ZeroConstructor, IsPlainOldData)

void CommonButtonBase::SetTouchMethod(TEnumAsByte<EButtonTouchMethod> InTouchMethod_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonButtonBase.SetTouchMethod"));

	CommonButtonBase_SetTouchMethod_Params params;
	params.InTouchMethod_69 = InTouchMethod_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUI.CommonButtonBase.SetStyle
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// class CommonButtonStyle*       InStyle_69                     (Parm, ZeroConstructor)

void CommonButtonBase::SetStyle(class CommonButtonStyle* InStyle_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonButtonBase.SetStyle"));

	CommonButtonBase_SetStyle_Params params;
	params.InStyle_69 = InStyle_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUI.CommonButtonBase.SetShouldUseFallbackDefaultInputAction
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// bool                           bInShouldUseFallbackDefaultInputAction_69 (Parm, ZeroConstructor, IsPlainOldData)

void CommonButtonBase::SetShouldUseFallbackDefaultInputAction(bool bInShouldUseFallbackDefaultInputAction_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonButtonBase.SetShouldUseFallbackDefaultInputAction"));

	CommonButtonBase_SetShouldUseFallbackDefaultInputAction_Params params;
	params.bInShouldUseFallbackDefaultInputAction_69 = bInShouldUseFallbackDefaultInputAction_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUI.CommonButtonBase.SetShouldSelectUponReceivingFocus
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// bool                           bInShouldSelectUponReceivingFocus_69 (Parm, ZeroConstructor, IsPlainOldData)

void CommonButtonBase::SetShouldSelectUponReceivingFocus(bool bInShouldSelectUponReceivingFocus_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonButtonBase.SetShouldSelectUponReceivingFocus"));

	CommonButtonBase_SetShouldSelectUponReceivingFocus_Params params;
	params.bInShouldSelectUponReceivingFocus_69 = bInShouldSelectUponReceivingFocus_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUI.CommonButtonBase.SetSelectedPressedSoundOverride
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// class SoundBase*               sound_69                       (Parm, ZeroConstructor)

void CommonButtonBase::SetSelectedPressedSoundOverride(class SoundBase* sound_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonButtonBase.SetSelectedPressedSoundOverride"));

	CommonButtonBase_SetSelectedPressedSoundOverride_Params params;
	params.sound_69 = sound_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUI.CommonButtonBase.SetSelectedInternal
// (Final, Native, Protected, BlueprintCallable)
// Parameters:
// bool                           bInSelected_69                 (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bAllowSound_69                 (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bBroadcast_69                  (Parm, ZeroConstructor, IsPlainOldData)

void CommonButtonBase::SetSelectedInternal(bool bInSelected_69, bool bAllowSound_69, bool bBroadcast_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonButtonBase.SetSelectedInternal"));

	CommonButtonBase_SetSelectedInternal_Params params;
	params.bInSelected_69 = bInSelected_69;
	params.bAllowSound_69 = bAllowSound_69;
	params.bBroadcast_69 = bBroadcast_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUI.CommonButtonBase.SetSelectedHoveredSoundOverride
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// class SoundBase*               sound_69                       (Parm, ZeroConstructor)

void CommonButtonBase::SetSelectedHoveredSoundOverride(class SoundBase* sound_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonButtonBase.SetSelectedHoveredSoundOverride"));

	CommonButtonBase_SetSelectedHoveredSoundOverride_Params params;
	params.sound_69 = sound_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUI.CommonButtonBase.SetPressMethod
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// TEnumAsByte<EButtonPressMethod> InPressMethod_69               (Parm, ZeroConstructor, IsPlainOldData)

void CommonButtonBase::SetPressMethod(TEnumAsByte<EButtonPressMethod> InPressMethod_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonButtonBase.SetPressMethod"));

	CommonButtonBase_SetPressMethod_Params params;
	params.InPressMethod_69 = InPressMethod_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUI.CommonButtonBase.SetPressedSoundOverride
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// class SoundBase*               sound_69                       (Parm, ZeroConstructor)

void CommonButtonBase::SetPressedSoundOverride(class SoundBase* sound_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonButtonBase.SetPressedSoundOverride"));

	CommonButtonBase_SetPressedSoundOverride_Params params;
	params.sound_69 = sound_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUI.CommonButtonBase.SetMinDimensions
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// int                            InMinWidth_69                  (Parm, ZeroConstructor, IsPlainOldData)
// int                            InMinHeight_69                 (Parm, ZeroConstructor, IsPlainOldData)

void CommonButtonBase::SetMinDimensions(int InMinWidth_69, int InMinHeight_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonButtonBase.SetMinDimensions"));

	CommonButtonBase_SetMinDimensions_Params params;
	params.InMinWidth_69 = InMinWidth_69;
	params.InMinHeight_69 = InMinHeight_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUI.CommonButtonBase.SetLockedPressedSoundOverride
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// class SoundBase*               sound_69                       (Parm, ZeroConstructor)

void CommonButtonBase::SetLockedPressedSoundOverride(class SoundBase* sound_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonButtonBase.SetLockedPressedSoundOverride"));

	CommonButtonBase_SetLockedPressedSoundOverride_Params params;
	params.sound_69 = sound_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUI.CommonButtonBase.SetLockedHoveredSoundOverride
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// class SoundBase*               sound_69                       (Parm, ZeroConstructor)

void CommonButtonBase::SetLockedHoveredSoundOverride(class SoundBase* sound_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonButtonBase.SetLockedHoveredSoundOverride"));

	CommonButtonBase_SetLockedHoveredSoundOverride_Params params;
	params.sound_69 = sound_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUI.CommonButtonBase.SetIsToggleable
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// bool                           bInIsToggleable_69             (Parm, ZeroConstructor, IsPlainOldData)

void CommonButtonBase::SetIsToggleable(bool bInIsToggleable_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonButtonBase.SetIsToggleable"));

	CommonButtonBase_SetIsToggleable_Params params;
	params.bInIsToggleable_69 = bInIsToggleable_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUI.CommonButtonBase.SetIsSelected
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// bool                           InSelected_69                  (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bGiveClickFeedback_69          (Parm, ZeroConstructor, IsPlainOldData)

void CommonButtonBase::SetIsSelected(bool InSelected_69, bool bGiveClickFeedback_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonButtonBase.SetIsSelected"));

	CommonButtonBase_SetIsSelected_Params params;
	params.InSelected_69 = InSelected_69;
	params.bGiveClickFeedback_69 = bGiveClickFeedback_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUI.CommonButtonBase.SetIsSelectable
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// bool                           bInIsSelectable_69             (Parm, ZeroConstructor, IsPlainOldData)

void CommonButtonBase::SetIsSelectable(bool bInIsSelectable_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonButtonBase.SetIsSelectable"));

	CommonButtonBase_SetIsSelectable_Params params;
	params.bInIsSelectable_69 = bInIsSelectable_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUI.CommonButtonBase.SetIsLocked
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// bool                           bInIsLocked_69                 (Parm, ZeroConstructor, IsPlainOldData)

void CommonButtonBase::SetIsLocked(bool bInIsLocked_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonButtonBase.SetIsLocked"));

	CommonButtonBase_SetIsLocked_Params params;
	params.bInIsLocked_69 = bInIsLocked_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUI.CommonButtonBase.SetIsInteractionEnabled
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// bool                           bInIsInteractionEnabled_69     (Parm, ZeroConstructor, IsPlainOldData)

void CommonButtonBase::SetIsInteractionEnabled(bool bInIsInteractionEnabled_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonButtonBase.SetIsInteractionEnabled"));

	CommonButtonBase_SetIsInteractionEnabled_Params params;
	params.bInIsInteractionEnabled_69 = bInIsInteractionEnabled_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUI.CommonButtonBase.SetIsInteractableWhenSelected
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// bool                           bInInteractableWhenSelected_69 (Parm, ZeroConstructor, IsPlainOldData)

void CommonButtonBase::SetIsInteractableWhenSelected(bool bInInteractableWhenSelected_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonButtonBase.SetIsInteractableWhenSelected"));

	CommonButtonBase_SetIsInteractableWhenSelected_Params params;
	params.bInInteractableWhenSelected_69 = bInInteractableWhenSelected_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUI.CommonButtonBase.SetIsFocusable
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// bool                           bInIsFocusable_69              (Parm, ZeroConstructor, IsPlainOldData)

void CommonButtonBase::SetIsFocusable(bool bInIsFocusable_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonButtonBase.SetIsFocusable"));

	CommonButtonBase_SetIsFocusable_Params params;
	params.bInIsFocusable_69 = bInIsFocusable_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUI.CommonButtonBase.SetInputActionProgressMaterial
// (Final, Native, Public, HasOutParms, BlueprintCallable)
// Parameters:
// struct FSlateBrush             InProgressMaterialBrush_69     (ConstParm, Parm, OutParm, ReferenceParm)
// struct FName                   InProgressMaterialParam_69     (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)

void CommonButtonBase::SetInputActionProgressMaterial(const struct FSlateBrush& InProgressMaterialBrush_69, const struct FName& InProgressMaterialParam_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonButtonBase.SetInputActionProgressMaterial"));

	CommonButtonBase_SetInputActionProgressMaterial_Params params;
	params.InProgressMaterialBrush_69 = InProgressMaterialBrush_69;
	params.InProgressMaterialParam_69 = InProgressMaterialParam_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUI.CommonButtonBase.SetHoveredSoundOverride
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// class SoundBase*               sound_69                       (Parm, ZeroConstructor)

void CommonButtonBase::SetHoveredSoundOverride(class SoundBase* sound_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonButtonBase.SetHoveredSoundOverride"));

	CommonButtonBase_SetHoveredSoundOverride_Params params;
	params.sound_69 = sound_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUI.CommonButtonBase.SetHideInputAction
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// bool                           bInHideInputAction_69          (Parm, ZeroConstructor, IsPlainOldData)

void CommonButtonBase::SetHideInputAction(bool bInHideInputAction_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonButtonBase.SetHideInputAction"));

	CommonButtonBase_SetHideInputAction_Params params;
	params.bInHideInputAction_69 = bInHideInputAction_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUI.CommonButtonBase.SetClickMethod
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// TEnumAsByte<EButtonClickMethod> InClickMethod_69               (Parm, ZeroConstructor, IsPlainOldData)

void CommonButtonBase::SetClickMethod(TEnumAsByte<EButtonClickMethod> InClickMethod_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonButtonBase.SetClickMethod"));

	CommonButtonBase_SetClickMethod_Params params;
	params.InClickMethod_69 = InClickMethod_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUI.CommonButtonBase.OnTriggeringInputActionChanged
// (Event, Protected, HasOutParms, BlueprintEvent)
// Parameters:
// struct FDataTableRowHandle     NewTriggeredAction_69          (ConstParm, Parm, OutParm, ReferenceParm)

void CommonButtonBase::OnTriggeringInputActionChanged(const struct FDataTableRowHandle& NewTriggeredAction_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonButtonBase.OnTriggeringInputActionChanged"));

	CommonButtonBase_OnTriggeringInputActionChanged_Params params;
	params.NewTriggeredAction_69 = NewTriggeredAction_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUI.CommonButtonBase.OnTriggeredInputActionChanged
// (Event, Protected, HasOutParms, BlueprintEvent)
// Parameters:
// struct FDataTableRowHandle     NewTriggeredAction_69          (ConstParm, Parm, OutParm, ReferenceParm)

void CommonButtonBase::OnTriggeredInputActionChanged(const struct FDataTableRowHandle& NewTriggeredAction_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonButtonBase.OnTriggeredInputActionChanged"));

	CommonButtonBase_OnTriggeredInputActionChanged_Params params;
	params.NewTriggeredAction_69 = NewTriggeredAction_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUI.CommonButtonBase.OnInputMethodChanged
// (Native, Protected)
// Parameters:
// ECommonInputType               CurrentInputType_69            (Parm, ZeroConstructor, IsPlainOldData)

void CommonButtonBase::OnInputMethodChanged(ECommonInputType CurrentInputType_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonButtonBase.OnInputMethodChanged"));

	CommonButtonBase_OnInputMethodChanged_Params params;
	params.CurrentInputType_69 = CurrentInputType_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUI.CommonButtonBase.OnCurrentTextStyleChanged
// (Event, Protected, BlueprintEvent)

void CommonButtonBase::OnCurrentTextStyleChanged()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonButtonBase.OnCurrentTextStyleChanged"));

	CommonButtonBase_OnCurrentTextStyleChanged_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUI.CommonButtonBase.OnActionProgress
// (Event, Protected, BlueprintEvent)
// Parameters:
// float                          HeldPercent_69                 (Parm, ZeroConstructor, IsPlainOldData)

void CommonButtonBase::OnActionProgress(float HeldPercent_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonButtonBase.OnActionProgress"));

	CommonButtonBase_OnActionProgress_Params params;
	params.HeldPercent_69 = HeldPercent_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUI.CommonButtonBase.OnActionComplete
// (Event, Protected, BlueprintEvent)

void CommonButtonBase::OnActionComplete()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonButtonBase.OnActionComplete"));

	CommonButtonBase_OnActionComplete_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUI.CommonButtonBase.NativeOnActionProgress
// (Native, Protected)
// Parameters:
// float                          HeldPercent_69                 (Parm, ZeroConstructor, IsPlainOldData)

void CommonButtonBase::NativeOnActionProgress(float HeldPercent_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonButtonBase.NativeOnActionProgress"));

	CommonButtonBase_NativeOnActionProgress_Params params;
	params.HeldPercent_69 = HeldPercent_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUI.CommonButtonBase.NativeOnActionComplete
// (Native, Protected)

void CommonButtonBase::NativeOnActionComplete()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonButtonBase.NativeOnActionComplete"));

	CommonButtonBase_NativeOnActionComplete_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUI.CommonButtonBase.IsPressed
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool CommonButtonBase::IsPressed()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonButtonBase.IsPressed"));

	CommonButtonBase_IsPressed_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CommonUI.CommonButtonBase.IsInteractionEnabled
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool CommonButtonBase::IsInteractionEnabled()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonButtonBase.IsInteractionEnabled"));

	CommonButtonBase_IsInteractionEnabled_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CommonUI.CommonButtonBase.HandleTriggeringActionCommited
// (Native, Protected, HasOutParms)
// Parameters:
// bool                           bPassThrough_69                (Parm, OutParm, ZeroConstructor, IsPlainOldData)

void CommonButtonBase::HandleTriggeringActionCommited(bool* bPassThrough_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonButtonBase.HandleTriggeringActionCommited"));

	CommonButtonBase_HandleTriggeringActionCommited_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (bPassThrough_69 != nullptr)
		*bPassThrough_69 = params.bPassThrough_69;
}


// Function CommonUI.CommonButtonBase.HandleFocusReceived
// (Native, Protected)

void CommonButtonBase::HandleFocusReceived()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonButtonBase.HandleFocusReceived"));

	CommonButtonBase_HandleFocusReceived_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUI.CommonButtonBase.HandleFocusLost
// (Native, Protected)

void CommonButtonBase::HandleFocusLost()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonButtonBase.HandleFocusLost"));

	CommonButtonBase_HandleFocusLost_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUI.CommonButtonBase.HandleButtonReleased
// (Final, Native, Protected)

void CommonButtonBase::HandleButtonReleased()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonButtonBase.HandleButtonReleased"));

	CommonButtonBase_HandleButtonReleased_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUI.CommonButtonBase.HandleButtonPressed
// (Final, Native, Protected)

void CommonButtonBase::HandleButtonPressed()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonButtonBase.HandleButtonPressed"));

	CommonButtonBase_HandleButtonPressed_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUI.CommonButtonBase.HandleButtonClicked
// (Final, Native, Protected)

void CommonButtonBase::HandleButtonClicked()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonButtonBase.HandleButtonClicked"));

	CommonButtonBase_HandleButtonClicked_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUI.CommonButtonBase.GetStyle
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// class CommonButtonStyle*       ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

class CommonButtonStyle* CommonButtonBase::GetStyle()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonButtonBase.GetStyle"));

	CommonButtonBase_GetStyle_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CommonUI.CommonButtonBase.GetSingleMaterialStyleMID
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// class MaterialInstanceDynamic* ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

class MaterialInstanceDynamic* CommonButtonBase::GetSingleMaterialStyleMID()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonButtonBase.GetSingleMaterialStyleMID"));

	CommonButtonBase_GetSingleMaterialStyleMID_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CommonUI.CommonButtonBase.GetShouldSelectUponReceivingFocus
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool CommonButtonBase::GetShouldSelectUponReceivingFocus()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonButtonBase.GetShouldSelectUponReceivingFocus"));

	CommonButtonBase_GetShouldSelectUponReceivingFocus_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CommonUI.CommonButtonBase.GetSelected
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool CommonButtonBase::GetSelected()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonButtonBase.GetSelected"));

	CommonButtonBase_GetSelected_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CommonUI.CommonButtonBase.GetLocked
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool CommonButtonBase::GetLocked()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonButtonBase.GetLocked"));

	CommonButtonBase_GetLocked_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CommonUI.CommonButtonBase.GetIsFocusable
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool CommonButtonBase::GetIsFocusable()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonButtonBase.GetIsFocusable"));

	CommonButtonBase_GetIsFocusable_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CommonUI.CommonButtonBase.GetInputAction
// (Final, Native, Public, HasOutParms, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FDataTableRowHandle     InputActionRow_69              (Parm, OutParm)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool CommonButtonBase::GetInputAction(struct FDataTableRowHandle* InputActionRow_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonButtonBase.GetInputAction"));

	CommonButtonBase_GetInputAction_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (InputActionRow_69 != nullptr)
		*InputActionRow_69 = params.InputActionRow_69;

	return params.ReturnValue_69;
}


// Function CommonUI.CommonButtonBase.GetCurrentTextStyleClass
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// class CommonTextStyle*         ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

class CommonTextStyle* CommonButtonBase::GetCurrentTextStyleClass()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonButtonBase.GetCurrentTextStyleClass"));

	CommonButtonBase_GetCurrentTextStyleClass_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CommonUI.CommonButtonBase.GetCurrentTextStyle
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// class CommonTextStyle*         ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

class CommonTextStyle* CommonButtonBase::GetCurrentTextStyle()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonButtonBase.GetCurrentTextStyle"));

	CommonButtonBase_GetCurrentTextStyle_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CommonUI.CommonButtonBase.GetCurrentCustomPadding
// (Final, Native, Public, HasOutParms, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FSlateCore_Fmargin      OutCustomPadding_69            (Parm, OutParm, ZeroConstructor, IsPlainOldData)

void CommonButtonBase::GetCurrentCustomPadding(struct FSlateCore_Fmargin* OutCustomPadding_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonButtonBase.GetCurrentCustomPadding"));

	CommonButtonBase_GetCurrentCustomPadding_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (OutCustomPadding_69 != nullptr)
		*OutCustomPadding_69 = params.OutCustomPadding_69;
}


// Function CommonUI.CommonButtonBase.GetCurrentButtonPadding
// (Final, Native, Public, HasOutParms, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FSlateCore_Fmargin      OutButtonPadding_69            (Parm, OutParm, ZeroConstructor, IsPlainOldData)

void CommonButtonBase::GetCurrentButtonPadding(struct FSlateCore_Fmargin* OutButtonPadding_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonButtonBase.GetCurrentButtonPadding"));

	CommonButtonBase_GetCurrentButtonPadding_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (OutButtonPadding_69 != nullptr)
		*OutButtonPadding_69 = params.OutButtonPadding_69;
}


// Function CommonUI.CommonButtonBase.DisableButtonWithReason
// (Final, Native, Public, HasOutParms, BlueprintCallable)
// Parameters:
// struct FText                   DisabledReason_69              (ConstParm, Parm, OutParm, ReferenceParm)

void CommonButtonBase::DisableButtonWithReason(const struct FText& DisabledReason_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonButtonBase.DisableButtonWithReason"));

	CommonButtonBase_DisableButtonWithReason_Params params;
	params.DisabledReason_69 = DisabledReason_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUI.CommonButtonBase.ClearSelection
// (Final, Native, Public, BlueprintCallable)

void CommonButtonBase::ClearSelection()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonButtonBase.ClearSelection"));

	CommonButtonBase_ClearSelection_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUI.CommonButtonBase.BP_OnUnhovered
// (Event, Protected, BlueprintEvent)

void CommonButtonBase::BP_OnUnhovered()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonButtonBase.BP_OnUnhovered"));

	CommonButtonBase_BP_OnUnhovered_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUI.CommonButtonBase.BP_OnSelected
// (Event, Protected, BlueprintEvent)

void CommonButtonBase::BP_OnSelected()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonButtonBase.BP_OnSelected"));

	CommonButtonBase_BP_OnSelected_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUI.CommonButtonBase.BP_OnReleased
// (Event, Protected, BlueprintEvent)

void CommonButtonBase::BP_OnReleased()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonButtonBase.BP_OnReleased"));

	CommonButtonBase_BP_OnReleased_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUI.CommonButtonBase.BP_OnPressed
// (Event, Protected, BlueprintEvent)

void CommonButtonBase::BP_OnPressed()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonButtonBase.BP_OnPressed"));

	CommonButtonBase_BP_OnPressed_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUI.CommonButtonBase.BP_OnLockedChanged
// (Event, Protected, BlueprintEvent)
// Parameters:
// bool                           bIsLocked_69                   (Parm, ZeroConstructor, IsPlainOldData)

void CommonButtonBase::BP_OnLockedChanged(bool bIsLocked_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonButtonBase.BP_OnLockedChanged"));

	CommonButtonBase_BP_OnLockedChanged_Params params;
	params.bIsLocked_69 = bIsLocked_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUI.CommonButtonBase.BP_OnLockDoubleClicked
// (Event, Protected, BlueprintEvent)

void CommonButtonBase::BP_OnLockDoubleClicked()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonButtonBase.BP_OnLockDoubleClicked"));

	CommonButtonBase_BP_OnLockDoubleClicked_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUI.CommonButtonBase.BP_OnLockClicked
// (Event, Protected, BlueprintEvent)

void CommonButtonBase::BP_OnLockClicked()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonButtonBase.BP_OnLockClicked"));

	CommonButtonBase_BP_OnLockClicked_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUI.CommonButtonBase.BP_OnInputMethodChanged
// (Event, Protected, BlueprintEvent)
// Parameters:
// ECommonInputType               CurrentInputType_69            (Parm, ZeroConstructor, IsPlainOldData)

void CommonButtonBase::BP_OnInputMethodChanged(ECommonInputType CurrentInputType_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonButtonBase.BP_OnInputMethodChanged"));

	CommonButtonBase_BP_OnInputMethodChanged_Params params;
	params.CurrentInputType_69 = CurrentInputType_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUI.CommonButtonBase.BP_OnHovered
// (Event, Protected, BlueprintEvent)

void CommonButtonBase::BP_OnHovered()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonButtonBase.BP_OnHovered"));

	CommonButtonBase_BP_OnHovered_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUI.CommonButtonBase.BP_OnFocusReceived
// (Event, Protected, BlueprintEvent)

void CommonButtonBase::BP_OnFocusReceived()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonButtonBase.BP_OnFocusReceived"));

	CommonButtonBase_BP_OnFocusReceived_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUI.CommonButtonBase.BP_OnFocusLost
// (Event, Protected, BlueprintEvent)

void CommonButtonBase::BP_OnFocusLost()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonButtonBase.BP_OnFocusLost"));

	CommonButtonBase_BP_OnFocusLost_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUI.CommonButtonBase.BP_OnEnabled
// (Event, Protected, BlueprintEvent)

void CommonButtonBase::BP_OnEnabled()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonButtonBase.BP_OnEnabled"));

	CommonButtonBase_BP_OnEnabled_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUI.CommonButtonBase.BP_OnDoubleClicked
// (Event, Protected, BlueprintEvent)

void CommonButtonBase::BP_OnDoubleClicked()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonButtonBase.BP_OnDoubleClicked"));

	CommonButtonBase_BP_OnDoubleClicked_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUI.CommonButtonBase.BP_OnDisabled
// (Event, Protected, BlueprintEvent)

void CommonButtonBase::BP_OnDisabled()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonButtonBase.BP_OnDisabled"));

	CommonButtonBase_BP_OnDisabled_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUI.CommonButtonBase.BP_OnDeselected
// (Event, Protected, BlueprintEvent)

void CommonButtonBase::BP_OnDeselected()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonButtonBase.BP_OnDeselected"));

	CommonButtonBase_BP_OnDeselected_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUI.CommonButtonBase.BP_OnClicked
// (Event, Protected, BlueprintEvent)

void CommonButtonBase::BP_OnClicked()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonButtonBase.BP_OnClicked"));

	CommonButtonBase_BP_OnClicked_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUI.CommonTextBlock.SetWrapTextWidth
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// int                            InWrapTextAt_69                (Parm, ZeroConstructor, IsPlainOldData)

void CommonTextBlock::SetWrapTextWidth(int InWrapTextAt_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonTextBlock.SetWrapTextWidth"));

	CommonTextBlock_SetWrapTextWidth_Params params;
	params.InWrapTextAt_69 = InWrapTextAt_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUI.CommonTextBlock.SetTextCase
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// bool                           bUseAllCaps_69                 (Parm, ZeroConstructor, IsPlainOldData)

void CommonTextBlock::SetTextCase(bool bUseAllCaps_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonTextBlock.SetTextCase"));

	CommonTextBlock_SetTextCase_Params params;
	params.bUseAllCaps_69 = bUseAllCaps_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUI.CommonTextBlock.SetStyle
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// class CommonTextStyle*         InStyle_69                     (Parm, ZeroConstructor)

void CommonTextBlock::SetStyle(class CommonTextStyle* InStyle_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonTextBlock.SetStyle"));

	CommonTextBlock_SetStyle_Params params;
	params.InStyle_69 = InStyle_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUI.CommonTextBlock.SetScrollingEnabled
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// bool                           bInIsScrollingEnabled_69       (Parm, ZeroConstructor, IsPlainOldData)

void CommonTextBlock::SetScrollingEnabled(bool bInIsScrollingEnabled_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonTextBlock.SetScrollingEnabled"));

	CommonTextBlock_SetScrollingEnabled_Params params;
	params.bInIsScrollingEnabled_69 = bInIsScrollingEnabled_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUI.CommonTextBlock.SetMargin
// (Final, Native, Public, HasOutParms, BlueprintCallable)
// Parameters:
// struct FSlateCore_Fmargin      InMargin_69                    (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)

void CommonTextBlock::SetMargin(const struct FSlateCore_Fmargin& InMargin_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonTextBlock.SetMargin"));

	CommonTextBlock_SetMargin_Params params;
	params.InMargin_69 = InMargin_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUI.CommonTextBlock.SetLineHeightPercentage
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// float                          InLineHeightPercentage_69      (Parm, ZeroConstructor, IsPlainOldData)

void CommonTextBlock::SetLineHeightPercentage(float InLineHeightPercentage_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonTextBlock.SetLineHeightPercentage"));

	CommonTextBlock_SetLineHeightPercentage_Params params;
	params.InLineHeightPercentage_69 = InLineHeightPercentage_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUI.CommonTextBlock.ResetScrollState
// (Final, Native, Public, BlueprintCallable)

void CommonTextBlock::ResetScrollState()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonTextBlock.ResetScrollState"));

	CommonTextBlock_ResetScrollState_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUI.CommonTextBlock.GetMargin
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// struct FSlateCore_Fmargin      ReturnValue_69                 (ConstParm, Parm, OutParm, ZeroConstructor, ReturnParm, ReferenceParm, IsPlainOldData)

struct FSlateCore_Fmargin CommonTextBlock::GetMargin()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonTextBlock.GetMargin"));

	CommonTextBlock_GetMargin_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CommonUI.CommonDateTimeTextBlock.SetTimespanValue
// (Final, Native, Public, HasDefaults, BlueprintCallable)
// Parameters:
// struct FTimespan               InTimespan_69                  (ConstParm, Parm, ZeroConstructor)

void CommonDateTimeTextBlock::SetTimespanValue(const struct FTimespan& InTimespan_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonDateTimeTextBlock.SetTimespanValue"));

	CommonDateTimeTextBlock_SetTimespanValue_Params params;
	params.InTimespan_69 = InTimespan_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUI.CommonDateTimeTextBlock.SetDateTimeValue
// (Final, Native, Public, HasDefaults, BlueprintCallable)
// Parameters:
// struct FDateTime               InDateTime_69                  (ConstParm, Parm, ZeroConstructor)
// bool                           bShowAsCountdown_69            (Parm, ZeroConstructor, IsPlainOldData)
// float                          InRefreshDelay_69              (Parm, ZeroConstructor, IsPlainOldData)

void CommonDateTimeTextBlock::SetDateTimeValue(const struct FDateTime& InDateTime_69, bool bShowAsCountdown_69, float InRefreshDelay_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonDateTimeTextBlock.SetDateTimeValue"));

	CommonDateTimeTextBlock_SetDateTimeValue_Params params;
	params.InDateTime_69 = InDateTime_69;
	params.bShowAsCountdown_69 = bShowAsCountdown_69;
	params.InRefreshDelay_69 = InRefreshDelay_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUI.CommonDateTimeTextBlock.SetCountDownCompletionText
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// struct FText                   InCompletionText_69            (ConstParm, Parm)

void CommonDateTimeTextBlock::SetCountDownCompletionText(const struct FText& InCompletionText_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonDateTimeTextBlock.SetCountDownCompletionText"));

	CommonDateTimeTextBlock_SetCountDownCompletionText_Params params;
	params.InCompletionText_69 = InCompletionText_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUI.CommonDateTimeTextBlock.GetDateTime
// (Final, Native, Public, HasDefaults, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FDateTime               ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FDateTime CommonDateTimeTextBlock::GetDateTime()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonDateTimeTextBlock.GetDateTime"));

	CommonDateTimeTextBlock_GetDateTime_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CommonUI.CommonLazyImage.SetMaterialTextureParamName
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// struct FName                   TextureParamName_69            (Parm, ZeroConstructor, IsPlainOldData)

void CommonLazyImage::SetMaterialTextureParamName(const struct FName& TextureParamName_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonLazyImage.SetMaterialTextureParamName"));

	CommonLazyImage_SetMaterialTextureParamName_Params params;
	params.TextureParamName_69 = TextureParamName_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUI.CommonLazyImage.SetBrushFromLazyTexture
// (Final, Native, Public, HasOutParms, BlueprintCallable)
// Parameters:
// bool                           bMatchSize_69                  (Parm, ZeroConstructor, IsPlainOldData)

void CommonLazyImage::SetBrushFromLazyTexture(bool bMatchSize_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonLazyImage.SetBrushFromLazyTexture"));

	CommonLazyImage_SetBrushFromLazyTexture_Params params;
	params.bMatchSize_69 = bMatchSize_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUI.CommonLazyImage.SetBrushFromLazyMaterial
// (Final, Native, Public, HasOutParms, BlueprintCallable)

void CommonLazyImage::SetBrushFromLazyMaterial()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonLazyImage.SetBrushFromLazyMaterial"));

	CommonLazyImage_SetBrushFromLazyMaterial_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUI.CommonLazyImage.SetBrushFromLazyDisplayAsset
// (Final, Native, Public, HasOutParms, BlueprintCallable)
// Parameters:
// bool                           bMatchTextureSize_69           (Parm, ZeroConstructor, IsPlainOldData)

void CommonLazyImage::SetBrushFromLazyDisplayAsset(bool bMatchTextureSize_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonLazyImage.SetBrushFromLazyDisplayAsset"));

	CommonLazyImage_SetBrushFromLazyDisplayAsset_Params params;
	params.bMatchTextureSize_69 = bMatchTextureSize_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUI.CommonLazyImage.IsLoading
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool CommonLazyImage::IsLoading()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonLazyImage.IsLoading"));

	CommonLazyImage_IsLoading_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CommonUI.CommonLazyWidget.SetLazyContent
// (Final, Native, Public, BlueprintCallable)

void CommonLazyWidget::SetLazyContent()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonLazyWidget.SetLazyContent"));

	CommonLazyWidget_SetLazyContent_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUI.CommonLazyWidget.IsLoading
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool CommonLazyWidget::IsLoading()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonLazyWidget.IsLoading"));

	CommonLazyWidget_IsLoading_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CommonUI.CommonLazyWidget.GetContent
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// class UserWidget*              ReturnValue_69                 (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)

class UserWidget* CommonLazyWidget::GetContent()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonLazyWidget.GetContent"));

	CommonLazyWidget_GetContent_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CommonUI.CommonListView.SetEntrySpacing
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// float                          InEntrySpacing_69              (Parm, ZeroConstructor, IsPlainOldData)

void CommonListView::SetEntrySpacing(float InEntrySpacing_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonListView.SetEntrySpacing"));

	CommonListView_SetEntrySpacing_Params params;
	params.InEntrySpacing_69 = InEntrySpacing_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUI.LoadGuardSlot.SetVerticalAlignment
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// TEnumAsByte<EVerticalAlignment> InVerticalAlignment_69         (Parm, ZeroConstructor, IsPlainOldData)

void LoadGuardSlot::SetVerticalAlignment(TEnumAsByte<EVerticalAlignment> InVerticalAlignment_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.LoadGuardSlot.SetVerticalAlignment"));

	LoadGuardSlot_SetVerticalAlignment_Params params;
	params.InVerticalAlignment_69 = InVerticalAlignment_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUI.LoadGuardSlot.SetPadding
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// struct FSlateCore_Fmargin      InPadding_69                   (Parm, ZeroConstructor, IsPlainOldData)

void LoadGuardSlot::SetPadding(const struct FSlateCore_Fmargin& InPadding_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.LoadGuardSlot.SetPadding"));

	LoadGuardSlot_SetPadding_Params params;
	params.InPadding_69 = InPadding_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUI.LoadGuardSlot.SetHorizontalAlignment
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// TEnumAsByte<EHorizontalAlignment> InHorizontalAlignment_69       (Parm, ZeroConstructor, IsPlainOldData)

void LoadGuardSlot::SetHorizontalAlignment(TEnumAsByte<EHorizontalAlignment> InHorizontalAlignment_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.LoadGuardSlot.SetHorizontalAlignment"));

	LoadGuardSlot_SetHorizontalAlignment_Params params;
	params.InHorizontalAlignment_69 = InHorizontalAlignment_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUI.CommonLoadGuard.SetLoadingText
// (Final, Native, Public, HasOutParms, BlueprintCallable)
// Parameters:
// struct FText                   InLoadingText_69               (ConstParm, Parm, OutParm, ReferenceParm)

void CommonLoadGuard::SetLoadingText(const struct FText& InLoadingText_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonLoadGuard.SetLoadingText"));

	CommonLoadGuard_SetLoadingText_Params params;
	params.InLoadingText_69 = InLoadingText_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUI.CommonLoadGuard.SetIsLoading
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// bool                           bInIsLoading_69                (Parm, ZeroConstructor, IsPlainOldData)

void CommonLoadGuard::SetIsLoading(bool bInIsLoading_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonLoadGuard.SetIsLoading"));

	CommonLoadGuard_SetIsLoading_Params params;
	params.bInIsLoading_69 = bInIsLoading_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// DelegateFunction CommonUI.CommonLoadGuard.OnAssetLoaded__DelegateSignature
// (Public, Delegate)
// Parameters:
// class Object_32759*            Object_69                      (Parm, ZeroConstructor)

void CommonLoadGuard::OnAssetLoaded__DelegateSignature(class Object_32759* Object_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("DelegateFunction CommonUI.CommonLoadGuard.OnAssetLoaded__DelegateSignature"));

	CommonLoadGuard_OnAssetLoaded__DelegateSignature_Params params;
	params.Object_69 = Object_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUI.CommonLoadGuard.IsLoading
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool CommonLoadGuard::IsLoading()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonLoadGuard.IsLoading"));

	CommonLoadGuard_IsLoading_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CommonUI.CommonLoadGuard.BP_GuardAndLoadAsset
// (Final, Native, Private, HasOutParms, BlueprintCallable)
// Parameters:
// struct FScriptDelegate         OnAssetLoaded_69               (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)

void CommonLoadGuard::BP_GuardAndLoadAsset(const struct FScriptDelegate& OnAssetLoaded_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonLoadGuard.BP_GuardAndLoadAsset"));

	CommonLoadGuard_BP_GuardAndLoadAsset_Params params;
	params.OnAssetLoaded_69 = OnAssetLoaded_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUI.CommonNumericTextBlock.SetNumericType
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// ECommonNumericType             InNumericType_69               (Parm, ZeroConstructor, IsPlainOldData)

void CommonNumericTextBlock::SetNumericType(ECommonNumericType InNumericType_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonNumericTextBlock.SetNumericType"));

	CommonNumericTextBlock_SetNumericType_Params params;
	params.InNumericType_69 = InNumericType_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUI.CommonNumericTextBlock.SetCurrentValue
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// float                          NewValue_69                    (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void CommonNumericTextBlock::SetCurrentValue(float NewValue_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonNumericTextBlock.SetCurrentValue"));

	CommonNumericTextBlock_SetCurrentValue_Params params;
	params.NewValue_69 = NewValue_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// DelegateFunction CommonUI.CommonNumericTextBlock.OnOutro__DelegateSignature
// (MulticastDelegate, Public, Delegate)
// Parameters:
// class CommonNumericTextBlock*  NumericTextBlock_69            (Parm, ZeroConstructor, InstancedReference)

void CommonNumericTextBlock::OnOutro__DelegateSignature(class CommonNumericTextBlock* NumericTextBlock_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("DelegateFunction CommonUI.CommonNumericTextBlock.OnOutro__DelegateSignature"));

	CommonNumericTextBlock_OnOutro__DelegateSignature_Params params;
	params.NumericTextBlock_69 = NumericTextBlock_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// DelegateFunction CommonUI.CommonNumericTextBlock.OnInterpolationUpdated__DelegateSignature
// (MulticastDelegate, Public, Delegate)
// Parameters:
// class CommonNumericTextBlock*  NumericTextBlock_69            (Parm, ZeroConstructor, InstancedReference)
// float                          LastValue_69                   (Parm, ZeroConstructor, IsPlainOldData)
// float                          NewValue_69                    (Parm, ZeroConstructor, IsPlainOldData)

void CommonNumericTextBlock::OnInterpolationUpdated__DelegateSignature(class CommonNumericTextBlock* NumericTextBlock_69, float LastValue_69, float NewValue_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("DelegateFunction CommonUI.CommonNumericTextBlock.OnInterpolationUpdated__DelegateSignature"));

	CommonNumericTextBlock_OnInterpolationUpdated__DelegateSignature_Params params;
	params.NumericTextBlock_69 = NumericTextBlock_69;
	params.LastValue_69 = LastValue_69;
	params.NewValue_69 = NewValue_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// DelegateFunction CommonUI.CommonNumericTextBlock.OnInterpolationStarted__DelegateSignature
// (MulticastDelegate, Public, Delegate)
// Parameters:
// class CommonNumericTextBlock*  NumericTextBlock_69            (Parm, ZeroConstructor, InstancedReference)

void CommonNumericTextBlock::OnInterpolationStarted__DelegateSignature(class CommonNumericTextBlock* NumericTextBlock_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("DelegateFunction CommonUI.CommonNumericTextBlock.OnInterpolationStarted__DelegateSignature"));

	CommonNumericTextBlock_OnInterpolationStarted__DelegateSignature_Params params;
	params.NumericTextBlock_69 = NumericTextBlock_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// DelegateFunction CommonUI.CommonNumericTextBlock.OnInterpolationEnded__DelegateSignature
// (MulticastDelegate, Public, Delegate)
// Parameters:
// class CommonNumericTextBlock*  NumericTextBlock_69            (Parm, ZeroConstructor, InstancedReference)
// bool                           HadCompleted_69                (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void CommonNumericTextBlock::OnInterpolationEnded__DelegateSignature(class CommonNumericTextBlock* NumericTextBlock_69, bool HadCompleted_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("DelegateFunction CommonUI.CommonNumericTextBlock.OnInterpolationEnded__DelegateSignature"));

	CommonNumericTextBlock_OnInterpolationEnded__DelegateSignature_Params params;
	params.NumericTextBlock_69 = NumericTextBlock_69;
	params.HadCompleted_69 = HadCompleted_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUI.CommonNumericTextBlock.IsInterpolatingNumericValue
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool CommonNumericTextBlock::IsInterpolatingNumericValue()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonNumericTextBlock.IsInterpolatingNumericValue"));

	CommonNumericTextBlock_IsInterpolatingNumericValue_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CommonUI.CommonNumericTextBlock.InterpolateToValue
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// float                          TargetValue_69                 (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// float                          MaximumInterpolationDuration_69 (Parm, ZeroConstructor, IsPlainOldData)
// float                          MinimumChangeRate_69           (Parm, ZeroConstructor, IsPlainOldData)
// float                          OutroOffset_69                 (Parm, ZeroConstructor, IsPlainOldData)

void CommonNumericTextBlock::InterpolateToValue(float TargetValue_69, float MaximumInterpolationDuration_69, float MinimumChangeRate_69, float OutroOffset_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonNumericTextBlock.InterpolateToValue"));

	CommonNumericTextBlock_InterpolateToValue_Params params;
	params.TargetValue_69 = TargetValue_69;
	params.MaximumInterpolationDuration_69 = MaximumInterpolationDuration_69;
	params.MinimumChangeRate_69 = MinimumChangeRate_69;
	params.OutroOffset_69 = OutroOffset_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUI.CommonNumericTextBlock.GetTargetValue
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// float                          ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

float CommonNumericTextBlock::GetTargetValue()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonNumericTextBlock.GetTargetValue"));

	CommonNumericTextBlock_GetTargetValue_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CommonUI.CommonPoolableWidgetInterface.OnReleaseToPool
// (Native, Event, Protected, BlueprintEvent)

void CommonPoolableWidgetInterface::OnReleaseToPool()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonPoolableWidgetInterface.OnReleaseToPool"));

	CommonPoolableWidgetInterface_OnReleaseToPool_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUI.CommonPoolableWidgetInterface.OnAcquireFromPool
// (Native, Event, Protected, BlueprintEvent)

void CommonPoolableWidgetInterface::OnAcquireFromPool()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonPoolableWidgetInterface.OnAcquireFromPool"));

	CommonPoolableWidgetInterface_OnAcquireFromPool_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUI.CommonRichTextBlock.SetScrollingEnabled
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// bool                           bInIsScrollingEnabled_69       (Parm, ZeroConstructor, IsPlainOldData)

void CommonRichTextBlock::SetScrollingEnabled(bool bInIsScrollingEnabled_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonRichTextBlock.SetScrollingEnabled"));

	CommonRichTextBlock_SetScrollingEnabled_Params params;
	params.bInIsScrollingEnabled_69 = bInIsScrollingEnabled_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUI.CommonRotator.ShiftTextRight
// (Final, Native, Public, BlueprintCallable)

void CommonRotator::ShiftTextRight()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonRotator.ShiftTextRight"));

	CommonRotator_ShiftTextRight_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUI.CommonRotator.ShiftTextLeft
// (Final, Native, Public, BlueprintCallable)

void CommonRotator::ShiftTextLeft()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonRotator.ShiftTextLeft"));

	CommonRotator_ShiftTextLeft_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUI.CommonRotator.SetSelectedItem
// (Native, Public, BlueprintCallable)
// Parameters:
// int                            InValue_69                     (Parm, ZeroConstructor, IsPlainOldData)

void CommonRotator::SetSelectedItem(int InValue_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonRotator.SetSelectedItem"));

	CommonRotator_SetSelectedItem_Params params;
	params.InValue_69 = InValue_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUI.CommonRotator.PopulateTextLabels
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// TArray<struct FText>           Labels_69                      (Parm, ZeroConstructor)

void CommonRotator::PopulateTextLabels(TArray<struct FText> Labels_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonRotator.PopulateTextLabels"));

	CommonRotator_PopulateTextLabels_Params params;
	params.Labels_69 = Labels_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUI.CommonRotator.GetSelectedText
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FText                   ReturnValue_69                 (Parm, OutParm, ReturnParm)

struct FText CommonRotator::GetSelectedText()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonRotator.GetSelectedText"));

	CommonRotator_GetSelectedText_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CommonUI.CommonRotator.GetSelectedIndex
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// int                            ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int CommonRotator::GetSelectedIndex()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonRotator.GetSelectedIndex"));

	CommonRotator_GetSelectedIndex_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CommonUI.CommonRotator.BP_OnOptionsPopulated
// (Event, Protected, BlueprintEvent)
// Parameters:
// int                            Count_69                       (Parm, ZeroConstructor, IsPlainOldData)

void CommonRotator::BP_OnOptionsPopulated(int Count_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonRotator.BP_OnOptionsPopulated"));

	CommonRotator_BP_OnOptionsPopulated_Params params;
	params.Count_69 = Count_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUI.CommonRotator.BP_OnOptionSelected
// (Event, Protected, BlueprintEvent)
// Parameters:
// int                            Index_69                       (Parm, ZeroConstructor, IsPlainOldData)

void CommonRotator::BP_OnOptionSelected(int Index_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonRotator.BP_OnOptionSelected"));

	CommonRotator_BP_OnOptionSelected_Params params;
	params.Index_69 = Index_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUI.CommonTabListWidgetBase.SetTabVisibility
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// struct FName                   TabNameID_69                   (Parm, ZeroConstructor, IsPlainOldData)
// ESlateVisibility               NewVisibility_69               (Parm, ZeroConstructor, IsPlainOldData)

void CommonTabListWidgetBase::SetTabVisibility(const struct FName& TabNameID_69, ESlateVisibility NewVisibility_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonTabListWidgetBase.SetTabVisibility"));

	CommonTabListWidgetBase_SetTabVisibility_Params params;
	params.TabNameID_69 = TabNameID_69;
	params.NewVisibility_69 = NewVisibility_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUI.CommonTabListWidgetBase.SetTabInteractionEnabled
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// struct FName                   TabNameID_69                   (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bEnable_69                     (Parm, ZeroConstructor, IsPlainOldData)

void CommonTabListWidgetBase::SetTabInteractionEnabled(const struct FName& TabNameID_69, bool bEnable_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonTabListWidgetBase.SetTabInteractionEnabled"));

	CommonTabListWidgetBase_SetTabInteractionEnabled_Params params;
	params.TabNameID_69 = TabNameID_69;
	params.bEnable_69 = bEnable_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUI.CommonTabListWidgetBase.SetTabEnabled
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// struct FName                   TabNameID_69                   (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bEnable_69                     (Parm, ZeroConstructor, IsPlainOldData)

void CommonTabListWidgetBase::SetTabEnabled(const struct FName& TabNameID_69, bool bEnable_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonTabListWidgetBase.SetTabEnabled"));

	CommonTabListWidgetBase_SetTabEnabled_Params params;
	params.TabNameID_69 = TabNameID_69;
	params.bEnable_69 = bEnable_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUI.CommonTabListWidgetBase.SetListeningForInput
// (Native, Public, BlueprintCallable)
// Parameters:
// bool                           bShouldListen_69               (Parm, ZeroConstructor, IsPlainOldData)

void CommonTabListWidgetBase::SetListeningForInput(bool bShouldListen_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonTabListWidgetBase.SetListeningForInput"));

	CommonTabListWidgetBase_SetListeningForInput_Params params;
	params.bShouldListen_69 = bShouldListen_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUI.CommonTabListWidgetBase.SetLinkedSwitcher
// (Native, Public, BlueprintCallable)
// Parameters:
// class CommonAnimatedSwitcher*  CommonSwitcher_69              (Parm, ZeroConstructor, InstancedReference)

void CommonTabListWidgetBase::SetLinkedSwitcher(class CommonAnimatedSwitcher* CommonSwitcher_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonTabListWidgetBase.SetLinkedSwitcher"));

	CommonTabListWidgetBase_SetLinkedSwitcher_Params params;
	params.CommonSwitcher_69 = CommonSwitcher_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUI.CommonTabListWidgetBase.SelectTabByID
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// struct FName                   TabNameID_69                   (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bSuppressClickFeedback_69      (Parm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool CommonTabListWidgetBase::SelectTabByID(const struct FName& TabNameID_69, bool bSuppressClickFeedback_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonTabListWidgetBase.SelectTabByID"));

	CommonTabListWidgetBase_SelectTabByID_Params params;
	params.TabNameID_69 = TabNameID_69;
	params.bSuppressClickFeedback_69 = bSuppressClickFeedback_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CommonUI.CommonTabListWidgetBase.RemoveTab
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// struct FName                   TabNameID_69                   (Parm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool CommonTabListWidgetBase::RemoveTab(const struct FName& TabNameID_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonTabListWidgetBase.RemoveTab"));

	CommonTabListWidgetBase_RemoveTab_Params params;
	params.TabNameID_69 = TabNameID_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CommonUI.CommonTabListWidgetBase.RemoveAllTabs
// (Final, Native, Public, BlueprintCallable)

void CommonTabListWidgetBase::RemoveAllTabs()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonTabListWidgetBase.RemoveAllTabs"));

	CommonTabListWidgetBase_RemoveAllTabs_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUI.CommonTabListWidgetBase.RegisterTab
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// struct FName                   TabNameID_69                   (Parm, ZeroConstructor, IsPlainOldData)
// class CommonButtonBase*        ButtonWidgetType_69            (Parm, ZeroConstructor)
// class Widget*                  ContentWidget_69               (Parm, ZeroConstructor, InstancedReference)
// int                            TabIndex_69                    (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool CommonTabListWidgetBase::RegisterTab(const struct FName& TabNameID_69, class CommonButtonBase* ButtonWidgetType_69, class Widget* ContentWidget_69, int TabIndex_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonTabListWidgetBase.RegisterTab"));

	CommonTabListWidgetBase_RegisterTab_Params params;
	params.TabNameID_69 = TabNameID_69;
	params.ButtonWidgetType_69 = ButtonWidgetType_69;
	params.ContentWidget_69 = ContentWidget_69;
	params.TabIndex_69 = TabIndex_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// DelegateFunction CommonUI.CommonTabListWidgetBase.OnTabSelected__DelegateSignature
// (MulticastDelegate, Public, Delegate)
// Parameters:
// struct FName                   TabId_69                       (Parm, ZeroConstructor, IsPlainOldData)

void CommonTabListWidgetBase::OnTabSelected__DelegateSignature(const struct FName& TabId_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("DelegateFunction CommonUI.CommonTabListWidgetBase.OnTabSelected__DelegateSignature"));

	CommonTabListWidgetBase_OnTabSelected__DelegateSignature_Params params;
	params.TabId_69 = TabId_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// DelegateFunction CommonUI.CommonTabListWidgetBase.OnTabListRebuilt__DelegateSignature
// (MulticastDelegate, Public, Delegate)

void CommonTabListWidgetBase::OnTabListRebuilt__DelegateSignature()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("DelegateFunction CommonUI.CommonTabListWidgetBase.OnTabListRebuilt__DelegateSignature"));

	CommonTabListWidgetBase_OnTabListRebuilt__DelegateSignature_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// DelegateFunction CommonUI.CommonTabListWidgetBase.OnTabButtonRemoval__DelegateSignature
// (MulticastDelegate, Public, Delegate)
// Parameters:
// struct FName                   TabId_69                       (Parm, ZeroConstructor, IsPlainOldData)
// class CommonButtonBase*        TabButton_69                   (Parm, ZeroConstructor, InstancedReference)

void CommonTabListWidgetBase::OnTabButtonRemoval__DelegateSignature(const struct FName& TabId_69, class CommonButtonBase* TabButton_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("DelegateFunction CommonUI.CommonTabListWidgetBase.OnTabButtonRemoval__DelegateSignature"));

	CommonTabListWidgetBase_OnTabButtonRemoval__DelegateSignature_Params params;
	params.TabId_69 = TabId_69;
	params.TabButton_69 = TabButton_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// DelegateFunction CommonUI.CommonTabListWidgetBase.OnTabButtonCreation__DelegateSignature
// (MulticastDelegate, Public, Delegate)
// Parameters:
// struct FName                   TabId_69                       (Parm, ZeroConstructor, IsPlainOldData)
// class CommonButtonBase*        TabButton_69                   (Parm, ZeroConstructor, InstancedReference)

void CommonTabListWidgetBase::OnTabButtonCreation__DelegateSignature(const struct FName& TabId_69, class CommonButtonBase* TabButton_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("DelegateFunction CommonUI.CommonTabListWidgetBase.OnTabButtonCreation__DelegateSignature"));

	CommonTabListWidgetBase_OnTabButtonCreation__DelegateSignature_Params params;
	params.TabId_69 = TabId_69;
	params.TabButton_69 = TabButton_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUI.CommonTabListWidgetBase.HandleTabRemoval
// (Native, Event, Protected, BlueprintEvent)
// Parameters:
// struct FName                   TabNameID_69                   (Parm, ZeroConstructor, IsPlainOldData)
// class CommonButtonBase*        TabButton_69                   (Parm, ZeroConstructor, InstancedReference)

void CommonTabListWidgetBase::HandleTabRemoval(const struct FName& TabNameID_69, class CommonButtonBase* TabButton_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonTabListWidgetBase.HandleTabRemoval"));

	CommonTabListWidgetBase_HandleTabRemoval_Params params;
	params.TabNameID_69 = TabNameID_69;
	params.TabButton_69 = TabButton_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUI.CommonTabListWidgetBase.HandleTabCreation
// (Native, Event, Protected, BlueprintEvent)
// Parameters:
// struct FName                   TabNameID_69                   (Parm, ZeroConstructor, IsPlainOldData)
// class CommonButtonBase*        TabButton_69                   (Parm, ZeroConstructor, InstancedReference)

void CommonTabListWidgetBase::HandleTabCreation(const struct FName& TabNameID_69, class CommonButtonBase* TabButton_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonTabListWidgetBase.HandleTabCreation"));

	CommonTabListWidgetBase_HandleTabCreation_Params params;
	params.TabNameID_69 = TabNameID_69;
	params.TabButton_69 = TabButton_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUI.CommonTabListWidgetBase.HandleTabButtonSelected
// (Final, Native, Protected)
// Parameters:
// class CommonButtonBase*        SelectedTabButton_69           (Parm, ZeroConstructor, InstancedReference)
// int                            ButtonIndex_69                 (Parm, ZeroConstructor, IsPlainOldData)

void CommonTabListWidgetBase::HandleTabButtonSelected(class CommonButtonBase* SelectedTabButton_69, int ButtonIndex_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonTabListWidgetBase.HandleTabButtonSelected"));

	CommonTabListWidgetBase_HandleTabButtonSelected_Params params;
	params.SelectedTabButton_69 = SelectedTabButton_69;
	params.ButtonIndex_69 = ButtonIndex_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUI.CommonTabListWidgetBase.HandlePreviousTabInputAction
// (Final, Native, Protected, HasOutParms)
// Parameters:
// bool                           bPassThrough_69                (Parm, OutParm, ZeroConstructor, IsPlainOldData)

void CommonTabListWidgetBase::HandlePreviousTabInputAction(bool* bPassThrough_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonTabListWidgetBase.HandlePreviousTabInputAction"));

	CommonTabListWidgetBase_HandlePreviousTabInputAction_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (bPassThrough_69 != nullptr)
		*bPassThrough_69 = params.bPassThrough_69;
}


// Function CommonUI.CommonTabListWidgetBase.HandlePreLinkedSwitcherChanged_BP
// (Event, Protected, BlueprintEvent)

void CommonTabListWidgetBase::HandlePreLinkedSwitcherChanged_BP()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonTabListWidgetBase.HandlePreLinkedSwitcherChanged_BP"));

	CommonTabListWidgetBase_HandlePreLinkedSwitcherChanged_BP_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUI.CommonTabListWidgetBase.HandlePostLinkedSwitcherChanged_BP
// (Event, Protected, BlueprintEvent)

void CommonTabListWidgetBase::HandlePostLinkedSwitcherChanged_BP()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonTabListWidgetBase.HandlePostLinkedSwitcherChanged_BP"));

	CommonTabListWidgetBase_HandlePostLinkedSwitcherChanged_BP_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUI.CommonTabListWidgetBase.HandleNextTabInputAction
// (Final, Native, Protected, HasOutParms)
// Parameters:
// bool                           bPassThrough_69                (Parm, OutParm, ZeroConstructor, IsPlainOldData)

void CommonTabListWidgetBase::HandleNextTabInputAction(bool* bPassThrough_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonTabListWidgetBase.HandleNextTabInputAction"));

	CommonTabListWidgetBase_HandleNextTabInputAction_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (bPassThrough_69 != nullptr)
		*bPassThrough_69 = params.bPassThrough_69;
}


// Function CommonUI.CommonTabListWidgetBase.GetTabIdAtIndex
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// int                            Index_69                       (Parm, ZeroConstructor, IsPlainOldData)
// struct FName                   ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

struct FName CommonTabListWidgetBase::GetTabIdAtIndex(int Index_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonTabListWidgetBase.GetTabIdAtIndex"));

	CommonTabListWidgetBase_GetTabIdAtIndex_Params params;
	params.Index_69 = Index_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CommonUI.CommonTabListWidgetBase.GetTabCount
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// int                            ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int CommonTabListWidgetBase::GetTabCount()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonTabListWidgetBase.GetTabCount"));

	CommonTabListWidgetBase_GetTabCount_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CommonUI.CommonTabListWidgetBase.GetTabButtonBaseByID
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// struct FName                   TabNameID_69                   (Parm, ZeroConstructor, IsPlainOldData)
// class CommonButtonBase*        ReturnValue_69                 (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)

class CommonButtonBase* CommonTabListWidgetBase::GetTabButtonBaseByID(const struct FName& TabNameID_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonTabListWidgetBase.GetTabButtonBaseByID"));

	CommonTabListWidgetBase_GetTabButtonBaseByID_Params params;
	params.TabNameID_69 = TabNameID_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CommonUI.CommonTabListWidgetBase.GetSelectedTabId
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FName                   ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

struct FName CommonTabListWidgetBase::GetSelectedTabId()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonTabListWidgetBase.GetSelectedTabId"));

	CommonTabListWidgetBase_GetSelectedTabId_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CommonUI.CommonTabListWidgetBase.GetLinkedSwitcher
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// class CommonAnimatedSwitcher*  ReturnValue_69                 (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)

class CommonAnimatedSwitcher* CommonTabListWidgetBase::GetLinkedSwitcher()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonTabListWidgetBase.GetLinkedSwitcher"));

	CommonTabListWidgetBase_GetLinkedSwitcher_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CommonUI.CommonTabListWidgetBase.GetActiveTab
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FName                   ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

struct FName CommonTabListWidgetBase::GetActiveTab()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonTabListWidgetBase.GetActiveTab"));

	CommonTabListWidgetBase_GetActiveTab_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CommonUI.CommonTabListWidgetBase.DisableTabWithReason
// (Final, Native, Public, HasOutParms, BlueprintCallable)
// Parameters:
// struct FName                   TabNameID_69                   (Parm, ZeroConstructor, IsPlainOldData)
// struct FText                   Reason_69                      (ConstParm, Parm, OutParm, ReferenceParm)

void CommonTabListWidgetBase::DisableTabWithReason(const struct FName& TabNameID_69, const struct FText& Reason_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonTabListWidgetBase.DisableTabWithReason"));

	CommonTabListWidgetBase_DisableTabWithReason_Params params;
	params.TabNameID_69 = TabNameID_69;
	params.Reason_69 = Reason_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUI.CommonTextStyle.GetStrikeBrush
// (Final, Native, Public, HasOutParms, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FSlateBrush             OutStrikeBrush_69              (Parm, OutParm)

void CommonTextStyle::GetStrikeBrush(struct FSlateBrush* OutStrikeBrush_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonTextStyle.GetStrikeBrush"));

	CommonTextStyle_GetStrikeBrush_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (OutStrikeBrush_69 != nullptr)
		*OutStrikeBrush_69 = params.OutStrikeBrush_69;
}


// Function CommonUI.CommonTextStyle.GetShadowOffset
// (Final, Native, Public, HasOutParms, HasDefaults, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FVector2D               OutShadowOffset_69             (Parm, OutParm, ZeroConstructor, IsPlainOldData)

void CommonTextStyle::GetShadowOffset(struct FVector2D* OutShadowOffset_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonTextStyle.GetShadowOffset"));

	CommonTextStyle_GetShadowOffset_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (OutShadowOffset_69 != nullptr)
		*OutShadowOffset_69 = params.OutShadowOffset_69;
}


// Function CommonUI.CommonTextStyle.GetShadowColor
// (Final, Native, Public, HasOutParms, HasDefaults, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FLinearColor            OutColor_69                    (Parm, OutParm, ZeroConstructor, IsPlainOldData)

void CommonTextStyle::GetShadowColor(struct FLinearColor* OutColor_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonTextStyle.GetShadowColor"));

	CommonTextStyle_GetShadowColor_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (OutColor_69 != nullptr)
		*OutColor_69 = params.OutColor_69;
}


// Function CommonUI.CommonTextStyle.GetMargin
// (Final, Native, Public, HasOutParms, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FSlateCore_Fmargin      OutMargin_69                   (Parm, OutParm, ZeroConstructor, IsPlainOldData)

void CommonTextStyle::GetMargin(struct FSlateCore_Fmargin* OutMargin_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonTextStyle.GetMargin"));

	CommonTextStyle_GetMargin_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (OutMargin_69 != nullptr)
		*OutMargin_69 = params.OutMargin_69;
}


// Function CommonUI.CommonTextStyle.GetLineHeightPercentage
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// float                          ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

float CommonTextStyle::GetLineHeightPercentage()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonTextStyle.GetLineHeightPercentage"));

	CommonTextStyle_GetLineHeightPercentage_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CommonUI.CommonTextStyle.GetFont
// (Final, Native, Public, HasOutParms, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FSlateFontInfo          OutFont_69                     (Parm, OutParm)

void CommonTextStyle::GetFont(struct FSlateFontInfo* OutFont_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonTextStyle.GetFont"));

	CommonTextStyle_GetFont_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (OutFont_69 != nullptr)
		*OutFont_69 = params.OutFont_69;
}


// Function CommonUI.CommonTextStyle.GetColor
// (Final, Native, Public, HasOutParms, HasDefaults, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FLinearColor            OutColor_69                    (Parm, OutParm, ZeroConstructor, IsPlainOldData)

void CommonTextStyle::GetColor(struct FLinearColor* OutColor_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonTextStyle.GetColor"));

	CommonTextStyle_GetColor_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (OutColor_69 != nullptr)
		*OutColor_69 = params.OutColor_69;
}


// Function CommonUI.CommonUILibrary.FindParentWidgetOfType
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// class Widget*                  StartingWidget_69              (Parm, ZeroConstructor, InstancedReference)
// class Widget*                  Type_69                        (Parm, ZeroConstructor)
// class Widget*                  ReturnValue_69                 (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)

class Widget* CommonUILibrary::STATIC_FindParentWidgetOfType(class Widget* StartingWidget_69, class Widget* Type_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonUILibrary.FindParentWidgetOfType"));

	CommonUILibrary_FindParentWidgetOfType_Params params;
	params.StartingWidget_69 = StartingWidget_69;
	params.Type_69 = Type_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CommonUI.CommonUISubsystemBase.GetInputActionButtonIcon
// (Final, Native, Public, HasOutParms, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FDataTableRowHandle     InputActionRowHandle_69        (ConstParm, Parm, OutParm, ReferenceParm)
// ECommonInputType               InputType_69                   (Parm, ZeroConstructor, IsPlainOldData)
// struct FName                   GamepadName_69                 (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
// struct FSlateBrush             ReturnValue_69                 (Parm, OutParm, ReturnParm)

struct FSlateBrush CommonUISubsystemBase::GetInputActionButtonIcon(const struct FDataTableRowHandle& InputActionRowHandle_69, ECommonInputType InputType_69, const struct FName& GamepadName_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonUISubsystemBase.GetInputActionButtonIcon"));

	CommonUISubsystemBase_GetInputActionButtonIcon_Params params;
	params.InputActionRowHandle_69 = InputActionRowHandle_69;
	params.InputType_69 = InputType_69;
	params.GamepadName_69 = GamepadName_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CommonUI.CommonVisibilitySwitcher.SetActiveWidgetIndex
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// int                            Index_69                       (Parm, ZeroConstructor, IsPlainOldData)

void CommonVisibilitySwitcher::SetActiveWidgetIndex(int Index_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonVisibilitySwitcher.SetActiveWidgetIndex"));

	CommonVisibilitySwitcher_SetActiveWidgetIndex_Params params;
	params.Index_69 = Index_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUI.CommonVisibilitySwitcher.SetActiveWidget
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// class Widget*                  Widget_69                      (ConstParm, Parm, ZeroConstructor, InstancedReference)

void CommonVisibilitySwitcher::SetActiveWidget(class Widget* Widget_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonVisibilitySwitcher.SetActiveWidget"));

	CommonVisibilitySwitcher_SetActiveWidget_Params params;
	params.Widget_69 = Widget_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUI.CommonVisibilitySwitcher.IncrementActiveWidgetIndex
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// bool                           bAllowWrapping_69              (Parm, ZeroConstructor, IsPlainOldData)

void CommonVisibilitySwitcher::IncrementActiveWidgetIndex(bool bAllowWrapping_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonVisibilitySwitcher.IncrementActiveWidgetIndex"));

	CommonVisibilitySwitcher_IncrementActiveWidgetIndex_Params params;
	params.bAllowWrapping_69 = bAllowWrapping_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUI.CommonVisibilitySwitcher.GetActiveWidgetIndex
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// int                            ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int CommonVisibilitySwitcher::GetActiveWidgetIndex()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonVisibilitySwitcher.GetActiveWidgetIndex"));

	CommonVisibilitySwitcher_GetActiveWidgetIndex_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CommonUI.CommonVisibilitySwitcher.GetActiveWidget
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// class Widget*                  ReturnValue_69                 (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)

class Widget* CommonVisibilitySwitcher::GetActiveWidget()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonVisibilitySwitcher.GetActiveWidget"));

	CommonVisibilitySwitcher_GetActiveWidget_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CommonUI.CommonVisibilitySwitcher.DecrementActiveWidgetIndex
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// bool                           bAllowWrapping_69              (Parm, ZeroConstructor, IsPlainOldData)

void CommonVisibilitySwitcher::DecrementActiveWidgetIndex(bool bAllowWrapping_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonVisibilitySwitcher.DecrementActiveWidgetIndex"));

	CommonVisibilitySwitcher_DecrementActiveWidgetIndex_Params params;
	params.bAllowWrapping_69 = bAllowWrapping_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUI.CommonVisibilitySwitcher.DeactivateVisibleSlot
// (Final, Native, Public, BlueprintCallable)

void CommonVisibilitySwitcher::DeactivateVisibleSlot()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonVisibilitySwitcher.DeactivateVisibleSlot"));

	CommonVisibilitySwitcher_DeactivateVisibleSlot_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUI.CommonVisibilitySwitcher.ActivateVisibleSlot
// (Final, Native, Public, BlueprintCallable)

void CommonVisibilitySwitcher::ActivateVisibleSlot()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonVisibilitySwitcher.ActivateVisibleSlot"));

	CommonVisibilitySwitcher_ActivateVisibleSlot_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUI.UCommonVisibilityWidgetBase.GetRegisteredPlatforms
// (Final, Native, Static, Protected)
// Parameters:
// TArray<struct FName>           ReturnValue_69                 (ConstParm, Parm, OutParm, ZeroConstructor, ReturnParm, ReferenceParm)

TArray<struct FName> UCommonVisibilityWidgetBase::STATIC_GetRegisteredPlatforms()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.UCommonVisibilityWidgetBase.GetRegisteredPlatforms"));

	UCommonVisibilityWidgetBase_GetRegisteredPlatforms_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CommonUI.CommonWidgetCarousel.SetActiveWidgetIndex
// (Native, Public, BlueprintCallable)
// Parameters:
// int                            Index_69                       (Parm, ZeroConstructor, IsPlainOldData)

void CommonWidgetCarousel::SetActiveWidgetIndex(int Index_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonWidgetCarousel.SetActiveWidgetIndex"));

	CommonWidgetCarousel_SetActiveWidgetIndex_Params params;
	params.Index_69 = Index_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUI.CommonWidgetCarousel.SetActiveWidget
// (Native, Public, BlueprintCallable)
// Parameters:
// class Widget*                  Widget_69                      (Parm, ZeroConstructor, InstancedReference)

void CommonWidgetCarousel::SetActiveWidget(class Widget* Widget_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonWidgetCarousel.SetActiveWidget"));

	CommonWidgetCarousel_SetActiveWidget_Params params;
	params.Widget_69 = Widget_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUI.CommonWidgetCarousel.PreviousPage
// (Final, Native, Public, BlueprintCallable)

void CommonWidgetCarousel::PreviousPage()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonWidgetCarousel.PreviousPage"));

	CommonWidgetCarousel_PreviousPage_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUI.CommonWidgetCarousel.NextPage
// (Final, Native, Public, BlueprintCallable)

void CommonWidgetCarousel::NextPage()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonWidgetCarousel.NextPage"));

	CommonWidgetCarousel_NextPage_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUI.CommonWidgetCarousel.GetWidgetAtIndex
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// int                            Index_69                       (Parm, ZeroConstructor, IsPlainOldData)
// class Widget*                  ReturnValue_69                 (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)

class Widget* CommonWidgetCarousel::GetWidgetAtIndex(int Index_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonWidgetCarousel.GetWidgetAtIndex"));

	CommonWidgetCarousel_GetWidgetAtIndex_Params params;
	params.Index_69 = Index_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CommonUI.CommonWidgetCarousel.GetActiveWidgetIndex
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// int                            ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int CommonWidgetCarousel::GetActiveWidgetIndex()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonWidgetCarousel.GetActiveWidgetIndex"));

	CommonWidgetCarousel_GetActiveWidgetIndex_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CommonUI.CommonWidgetCarousel.EndAutoScrolling
// (Final, Native, Public, BlueprintCallable)

void CommonWidgetCarousel::EndAutoScrolling()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonWidgetCarousel.EndAutoScrolling"));

	CommonWidgetCarousel_EndAutoScrolling_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUI.CommonWidgetCarousel.BeginAutoScrolling
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// float                          ScrollInterval_69              (Parm, ZeroConstructor, IsPlainOldData)

void CommonWidgetCarousel::BeginAutoScrolling(float ScrollInterval_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonWidgetCarousel.BeginAutoScrolling"));

	CommonWidgetCarousel_BeginAutoScrolling_Params params;
	params.ScrollInterval_69 = ScrollInterval_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUI.CommonWidgetCarouselNavBar.SetLinkedCarousel
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// class CommonWidgetCarousel*    CommonCarousel_69              (Parm, ZeroConstructor, InstancedReference)

void CommonWidgetCarouselNavBar::SetLinkedCarousel(class CommonWidgetCarousel* CommonCarousel_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonWidgetCarouselNavBar.SetLinkedCarousel"));

	CommonWidgetCarouselNavBar_SetLinkedCarousel_Params params;
	params.CommonCarousel_69 = CommonCarousel_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUI.CommonWidgetCarouselNavBar.HandlePageChanged
// (Final, Native, Protected)
// Parameters:
// class CommonWidgetCarousel*    CommonCarousel_69              (Parm, ZeroConstructor, InstancedReference)
// int                            PageIndex_69                   (Parm, ZeroConstructor, IsPlainOldData)

void CommonWidgetCarouselNavBar::HandlePageChanged(class CommonWidgetCarousel* CommonCarousel_69, int PageIndex_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonWidgetCarouselNavBar.HandlePageChanged"));

	CommonWidgetCarouselNavBar_HandlePageChanged_Params params;
	params.CommonCarousel_69 = CommonCarousel_69;
	params.PageIndex_69 = PageIndex_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUI.CommonWidgetCarouselNavBar.HandleButtonClicked
// (Final, Native, Protected)
// Parameters:
// class CommonButtonBase*        AssociatedButton_69            (Parm, ZeroConstructor, InstancedReference)
// int                            ButtonIndex_69                 (Parm, ZeroConstructor, IsPlainOldData)

void CommonWidgetCarouselNavBar::HandleButtonClicked(class CommonButtonBase* AssociatedButton_69, int ButtonIndex_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonWidgetCarouselNavBar.HandleButtonClicked"));

	CommonWidgetCarouselNavBar_HandleButtonClicked_Params params;
	params.AssociatedButton_69 = AssociatedButton_69;
	params.ButtonIndex_69 = ButtonIndex_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUI.CommonWidgetGroupBase.RemoveWidget
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// class Widget*                  InWidget_69                    (Parm, ZeroConstructor, InstancedReference)

void CommonWidgetGroupBase::RemoveWidget(class Widget* InWidget_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonWidgetGroupBase.RemoveWidget"));

	CommonWidgetGroupBase_RemoveWidget_Params params;
	params.InWidget_69 = InWidget_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUI.CommonWidgetGroupBase.RemoveAll
// (Final, Native, Public, BlueprintCallable)

void CommonWidgetGroupBase::RemoveAll()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonWidgetGroupBase.RemoveAll"));

	CommonWidgetGroupBase_RemoveAll_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUI.CommonWidgetGroupBase.AddWidget
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// class Widget*                  InWidget_69                    (Parm, ZeroConstructor, InstancedReference)

void CommonWidgetGroupBase::AddWidget(class Widget* InWidget_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonWidgetGroupBase.AddWidget"));

	CommonWidgetGroupBase_AddWidget_Params params;
	params.InWidget_69 = InWidget_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUI.CommonButtonGroupBase.SetSelectionRequired
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// bool                           bRequireSelection_69           (Parm, ZeroConstructor, IsPlainOldData)

void CommonButtonGroupBase::SetSelectionRequired(bool bRequireSelection_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonButtonGroupBase.SetSelectionRequired"));

	CommonButtonGroupBase_SetSelectionRequired_Params params;
	params.bRequireSelection_69 = bRequireSelection_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUI.CommonButtonGroupBase.SelectPreviousButton
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// bool                           bAllowWrap_69                  (Parm, ZeroConstructor, IsPlainOldData)

void CommonButtonGroupBase::SelectPreviousButton(bool bAllowWrap_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonButtonGroupBase.SelectPreviousButton"));

	CommonButtonGroupBase_SelectPreviousButton_Params params;
	params.bAllowWrap_69 = bAllowWrap_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUI.CommonButtonGroupBase.SelectNextButton
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// bool                           bAllowWrap_69                  (Parm, ZeroConstructor, IsPlainOldData)

void CommonButtonGroupBase::SelectNextButton(bool bAllowWrap_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonButtonGroupBase.SelectNextButton"));

	CommonButtonGroupBase_SelectNextButton_Params params;
	params.bAllowWrap_69 = bAllowWrap_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUI.CommonButtonGroupBase.SelectButtonAtIndex
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// int                            ButtonIndex_69                 (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bAllowSound_69                 (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void CommonButtonGroupBase::SelectButtonAtIndex(int ButtonIndex_69, bool bAllowSound_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonButtonGroupBase.SelectButtonAtIndex"));

	CommonButtonGroupBase_SelectButtonAtIndex_Params params;
	params.ButtonIndex_69 = ButtonIndex_69;
	params.bAllowSound_69 = bAllowSound_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUI.CommonButtonGroupBase.OnSelectionStateChangedBase
// (Native, Protected)
// Parameters:
// class CommonButtonBase*        BaseButton_69                  (Parm, ZeroConstructor, InstancedReference)
// bool                           bIsSelected_69                 (Parm, ZeroConstructor, IsPlainOldData)

void CommonButtonGroupBase::OnSelectionStateChangedBase(class CommonButtonBase* BaseButton_69, bool bIsSelected_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonButtonGroupBase.OnSelectionStateChangedBase"));

	CommonButtonGroupBase_OnSelectionStateChangedBase_Params params;
	params.BaseButton_69 = BaseButton_69;
	params.bIsSelected_69 = bIsSelected_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUI.CommonButtonGroupBase.OnHandleButtonBaseDoubleClicked
// (Native, Protected)
// Parameters:
// class CommonButtonBase*        BaseButton_69                  (Parm, ZeroConstructor, InstancedReference)

void CommonButtonGroupBase::OnHandleButtonBaseDoubleClicked(class CommonButtonBase* BaseButton_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonButtonGroupBase.OnHandleButtonBaseDoubleClicked"));

	CommonButtonGroupBase_OnHandleButtonBaseDoubleClicked_Params params;
	params.BaseButton_69 = BaseButton_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUI.CommonButtonGroupBase.OnHandleButtonBaseClicked
// (Native, Protected)
// Parameters:
// class CommonButtonBase*        BaseButton_69                  (Parm, ZeroConstructor, InstancedReference)

void CommonButtonGroupBase::OnHandleButtonBaseClicked(class CommonButtonBase* BaseButton_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonButtonGroupBase.OnHandleButtonBaseClicked"));

	CommonButtonGroupBase_OnHandleButtonBaseClicked_Params params;
	params.BaseButton_69 = BaseButton_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUI.CommonButtonGroupBase.OnButtonBaseUnhovered
// (Native, Protected)
// Parameters:
// class CommonButtonBase*        BaseButton_69                  (Parm, ZeroConstructor, InstancedReference)

void CommonButtonGroupBase::OnButtonBaseUnhovered(class CommonButtonBase* BaseButton_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonButtonGroupBase.OnButtonBaseUnhovered"));

	CommonButtonGroupBase_OnButtonBaseUnhovered_Params params;
	params.BaseButton_69 = BaseButton_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUI.CommonButtonGroupBase.OnButtonBaseHovered
// (Native, Protected)
// Parameters:
// class CommonButtonBase*        BaseButton_69                  (Parm, ZeroConstructor, InstancedReference)

void CommonButtonGroupBase::OnButtonBaseHovered(class CommonButtonBase* BaseButton_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonButtonGroupBase.OnButtonBaseHovered"));

	CommonButtonGroupBase_OnButtonBaseHovered_Params params;
	params.BaseButton_69 = BaseButton_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUI.CommonButtonGroupBase.HasAnyButtons
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool CommonButtonGroupBase::HasAnyButtons()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonButtonGroupBase.HasAnyButtons"));

	CommonButtonGroupBase_HasAnyButtons_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CommonUI.CommonButtonGroupBase.GetSelectedButtonIndex
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// int                            ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int CommonButtonGroupBase::GetSelectedButtonIndex()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonButtonGroupBase.GetSelectedButtonIndex"));

	CommonButtonGroupBase_GetSelectedButtonIndex_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CommonUI.CommonButtonGroupBase.GetSelectedButtonBase
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// class CommonButtonBase*        ReturnValue_69                 (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)

class CommonButtonBase* CommonButtonGroupBase::GetSelectedButtonBase()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonButtonGroupBase.GetSelectedButtonBase"));

	CommonButtonGroupBase_GetSelectedButtonBase_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CommonUI.CommonButtonGroupBase.GetHoveredButtonIndex
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// int                            ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int CommonButtonGroupBase::GetHoveredButtonIndex()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonButtonGroupBase.GetHoveredButtonIndex"));

	CommonButtonGroupBase_GetHoveredButtonIndex_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CommonUI.CommonButtonGroupBase.GetButtonCount
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// int                            ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int CommonButtonGroupBase::GetButtonCount()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonButtonGroupBase.GetButtonCount"));

	CommonButtonGroupBase_GetButtonCount_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CommonUI.CommonButtonGroupBase.GetButtonBaseAtIndex
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// int                            Index_69                       (Parm, ZeroConstructor, IsPlainOldData)
// class CommonButtonBase*        ReturnValue_69                 (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)

class CommonButtonBase* CommonButtonGroupBase::GetButtonBaseAtIndex(int Index_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonButtonGroupBase.GetButtonBaseAtIndex"));

	CommonButtonGroupBase_GetButtonBaseAtIndex_Params params;
	params.Index_69 = Index_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CommonUI.CommonButtonGroupBase.FindButtonIndex
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// class CommonButtonBase*        ButtonToFind_69                (ConstParm, Parm, ZeroConstructor, InstancedReference)
// int                            ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int CommonButtonGroupBase::FindButtonIndex(class CommonButtonBase* ButtonToFind_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonButtonGroupBase.FindButtonIndex"));

	CommonButtonGroupBase_FindButtonIndex_Params params;
	params.ButtonToFind_69 = ButtonToFind_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CommonUI.CommonButtonGroupBase.DeselectAll
// (Final, Native, Public, BlueprintCallable)

void CommonButtonGroupBase::DeselectAll()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonButtonGroupBase.DeselectAll"));

	CommonButtonGroupBase_DeselectAll_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUI.CommonBoundActionBar.SetDisplayOwningPlayerActionsOnly
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// bool                           bShouldOnlyDisplayOwningPlayerActions_69 (Parm, ZeroConstructor, IsPlainOldData)

void CommonBoundActionBar::SetDisplayOwningPlayerActionsOnly(bool bShouldOnlyDisplayOwningPlayerActions_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonBoundActionBar.SetDisplayOwningPlayerActionsOnly"));

	CommonBoundActionBar_SetDisplayOwningPlayerActionsOnly_Params params;
	params.bShouldOnlyDisplayOwningPlayerActions_69 = bShouldOnlyDisplayOwningPlayerActions_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUI.CommonBoundActionButton.OnUpdateInputAction
// (Event, Protected, BlueprintEvent)

void CommonBoundActionButton::OnUpdateInputAction()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonBoundActionButton.OnUpdateInputAction"));

	CommonBoundActionButton_OnUpdateInputAction_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUI.CommonActivatableWidgetContainerBase.SetTransitionDuration
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// float                          Duration_69                    (Parm, ZeroConstructor, IsPlainOldData)

void CommonActivatableWidgetContainerBase::SetTransitionDuration(float Duration_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonActivatableWidgetContainerBase.SetTransitionDuration"));

	CommonActivatableWidgetContainerBase_SetTransitionDuration_Params params;
	params.Duration_69 = Duration_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUI.CommonActivatableWidgetContainerBase.RemoveWidget
// (Final, Native, Private, BlueprintCallable)
// Parameters:
// class CommonActivatableWidget* WidgetToRemove_69              (Parm, ZeroConstructor, InstancedReference)

void CommonActivatableWidgetContainerBase::RemoveWidget(class CommonActivatableWidget* WidgetToRemove_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonActivatableWidgetContainerBase.RemoveWidget"));

	CommonActivatableWidgetContainerBase_RemoveWidget_Params params;
	params.WidgetToRemove_69 = WidgetToRemove_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUI.CommonActivatableWidgetContainerBase.GetTransitionDuration
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// float                          ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

float CommonActivatableWidgetContainerBase::GetTransitionDuration()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonActivatableWidgetContainerBase.GetTransitionDuration"));

	CommonActivatableWidgetContainerBase_GetTransitionDuration_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CommonUI.CommonActivatableWidgetContainerBase.GetActiveWidget
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// class CommonActivatableWidget* ReturnValue_69                 (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)

class CommonActivatableWidget* CommonActivatableWidgetContainerBase::GetActiveWidget()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonActivatableWidgetContainerBase.GetActiveWidget"));

	CommonActivatableWidgetContainerBase_GetActiveWidget_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CommonUI.CommonActivatableWidgetContainerBase.ClearWidgets
// (Final, Native, Public, BlueprintCallable)

void CommonActivatableWidgetContainerBase::ClearWidgets()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonActivatableWidgetContainerBase.ClearWidgets"));

	CommonActivatableWidgetContainerBase_ClearWidgets_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUI.CommonActivatableWidgetContainerBase.BP_AddWidget
// (Final, Native, Private, BlueprintCallable)
// Parameters:
// class CommonActivatableWidget* ActivatableWidgetClass_69      (Parm, ZeroConstructor)
// class CommonActivatableWidget* ReturnValue_69                 (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)

class CommonActivatableWidget* CommonActivatableWidgetContainerBase::BP_AddWidget(class CommonActivatableWidget* ActivatableWidgetClass_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUI.CommonActivatableWidgetContainerBase.BP_AddWidget"));

	CommonActivatableWidgetContainerBase_BP_AddWidget_Params params;
	params.ActivatableWidgetClass_69 = ActivatableWidgetClass_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

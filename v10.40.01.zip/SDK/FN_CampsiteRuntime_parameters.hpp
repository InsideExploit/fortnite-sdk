#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function CampsiteRuntime.AbandonedCampsiteManager.OnGamePhaseStepChanged
struct AbandonedCampsiteManager_OnGamePhaseStepChanged_Params
{
	TScriptInterface<class FortSafeZoneInterface>      SafeZoneInterface_69;                                     // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
	EAthenaGamePhaseStep                               GamePhaseStep_69;                                         // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function CampsiteRuntime.AbandonedCampsitePlacedSpawner.SpawnCampsite
struct AbandonedCampsitePlacedSpawner_SpawnCampsite_Params
{
};

// Function CampsiteRuntime.CampsiteConversationComponent.StartConversation
struct CampsiteConversationComponent_StartConversation_Params
{
	class FortPlayerController*                        InstigatingController_69;                                 // (Parm, ZeroConstructor)
};

// Function CampsiteRuntime.CampsiteFunctionLibraryNative.StoreHealthOnPickupFromProp
struct CampsiteFunctionLibraryNative_StoreHealthOnPickupFromProp_Params
{
	class BuildingProp*                                BuildingProp_69;                                          // (ConstParm, Parm, ZeroConstructor)
	class FortPickup*                                  PickUp_69;                                                // (Parm, ZeroConstructor)
};

// Function CampsiteRuntime.CampsiteFunctionLibraryNative.SetHealthOnPropFromItemEntry
struct CampsiteFunctionLibraryNative_SetHealthOnPropFromItemEntry_Params
{
	struct FFortItemEntry                              FortItem_69;                                              // (ConstParm, Parm, OutParm, ReferenceParm)
	class BuildingProp*                                BuildingProp_69;                                          // (Parm, ZeroConstructor)
};

// Function CampsiteRuntime.CampsiteFunctionLibraryNative.IsItemEntryAvailable
struct CampsiteFunctionLibraryNative_IsItemEntryAvailable_Params
{
	class Object_32759*                                WorldContextObject_69;                                    // (Parm, ZeroConstructor)
	struct FFortItemEntry                              FortItem_69;                                              // (ConstParm, Parm, OutParm, ReferenceParm)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CampsiteRuntime.CampsiteFunctionLibraryNative.IsItemDefinitionAvailable
struct CampsiteFunctionLibraryNative_IsItemDefinitionAvailable_Params
{
	class Object_32759*                                WorldContextObject_69;                                    // (Parm, ZeroConstructor)
	class FortItemDefinition*                          FortItem_69;                                              // (ConstParm, Parm, ZeroConstructor)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CampsiteRuntime.CampsiteFunctionLibraryNative.IsItemAvailable
struct CampsiteFunctionLibraryNative_IsItemAvailable_Params
{
	class Object_32759*                                WorldContextObject_69;                                    // (Parm, ZeroConstructor)
	class FortItem*                                    FortItem_69;                                              // (ConstParm, Parm, ZeroConstructor)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CampsiteRuntime.CampsiteFunctionLibraryNative.GetItemEntryCopyFromWeapon
struct CampsiteFunctionLibraryNative_GetItemEntryCopyFromWeapon_Params
{
	class FortWeapon*                                  Weapon_69;                                                // (ConstParm, Parm, ZeroConstructor)
	struct FFortItemEntry                              ReturnValue_69;                                           // (ConstParm, Parm, OutParm, ReturnParm)
};

// Function CampsiteRuntime.CampsiteImprovementComponent.SetImprovementOwnerSquadId
struct CampsiteImprovementComponent_SetImprovementOwnerSquadId_Params
{
	int                                                SquadId_69;                                               // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function CampsiteRuntime.CampsiteImprovementComponent.RemoveIndicator
struct CampsiteImprovementComponent_RemoveIndicator_Params
{
};

// Function CampsiteRuntime.CampsiteImprovementComponent.OnRep_ImprovementOwnerSquadId
struct CampsiteImprovementComponent_OnRep_ImprovementOwnerSquadId_Params
{
};

// Function CampsiteRuntime.CampsiteImprovementComponent.CreateIndicator
struct CampsiteImprovementComponent_CreateIndicator_Params
{
};

// Function CampsiteRuntime.FortControllerComponent_CampsiteAccountItem.WriteStashedItemFromEntry
struct FortControllerComponent_CampsiteAccountItem_WriteStashedItemFromEntry_Params
{
	class FortPlayerControllerAthena*                  PlayerController_69;                                      // (Parm, ZeroConstructor)
	struct FFortItemEntry                              ItemEntry_69;                                             // (ConstParm, Parm, OutParm, ReferenceParm)
	int                                                StashedItemIndex_69;                                      // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function CampsiteRuntime.FortControllerComponent_CampsiteAccountItem.WriteStashedItem
struct FortControllerComponent_CampsiteAccountItem_WriteStashedItem_Params
{
	class FortPlayerControllerAthena*                  PlayerController_69;                                      // (Parm, ZeroConstructor)
	class FortWorldItem*                               Item_69;                                                  // (ConstParm, Parm, ZeroConstructor)
	int                                                StashedItemIndex_69;                                      // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function CampsiteRuntime.FortControllerComponent_CampsiteAccountItem.SwapStashedItem
struct FortControllerComponent_CampsiteAccountItem_SwapStashedItem_Params
{
	class Actor_32759*                                 SourceActor_69;                                           // (ConstParm, Parm, ZeroConstructor)
	int                                                StashedItemIndex_69;                                      // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CampsiteRuntime.FortControllerComponent_CampsiteAccountItem.StashCurrentlyHeldItemAndRemoveFromInventory
struct FortControllerComponent_CampsiteAccountItem_StashCurrentlyHeldItemAndRemoveFromInventory_Params
{
	int                                                StashedItemIndex_69;                                      // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CampsiteRuntime.FortControllerComponent_CampsiteAccountItem.OnAthenaProfileInitialized
struct FortControllerComponent_CampsiteAccountItem_OnAthenaProfileInitialized_Params
{
};

// Function CampsiteRuntime.FortControllerComponent_CampsiteAccountItem.HasCurrentlyStashedItem
struct FortControllerComponent_CampsiteAccountItem_HasCurrentlyStashedItem_Params
{
	int                                                StashedItemIndex_69;                                      // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CampsiteRuntime.FortControllerComponent_CampsiteAccountItem.GetCurrentlyStashedItemAsItemEntry
struct FortControllerComponent_CampsiteAccountItem_GetCurrentlyStashedItemAsItemEntry_Params
{
	int                                                StashedItemIndex_69;                                      // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	struct FFortItemEntry                              ReturnValue_69;                                           // (Parm, OutParm, ReturnParm)
};

// Function CampsiteRuntime.FortControllerComponent_CampsiteAccountItem.ClearStoredCampsiteLocations
struct FortControllerComponent_CampsiteAccountItem_ClearStoredCampsiteLocations_Params
{
};

// Function CampsiteRuntime.FortControllerComponent_CampsiteAccountItem.ClearStashedItemAndGiveToPlayer
struct FortControllerComponent_CampsiteAccountItem_ClearStashedItemAndGiveToPlayer_Params
{
	class Actor_32759*                                 SourceActor_69;                                           // (ConstParm, Parm, ZeroConstructor)
	int                                                StashedItemIndex_69;                                      // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CampsiteRuntime.FortControllerComponent_CampsiteAccountItem.ClearStashedItem
struct FortControllerComponent_CampsiteAccountItem_ClearStashedItem_Params
{
	int                                                StashedItemIndex_69;                                      // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function CampsiteRuntime.FortControllerComponent_CampsiteAccountItem.CacheAccountItemData
struct FortControllerComponent_CampsiteAccountItem_CacheAccountItemData_Params
{
};

// Function CampsiteRuntime.FortGameStateComponent_Campsite.RegisterPreplacedCampsite
struct FortGameStateComponent_Campsite_RegisterPreplacedCampsite_Params
{
	class AbandonedCampsitePlacedSpawner*              PreplacedCampsiteSpawnPoint_69;                           // (Parm, ZeroConstructor)
};

// Function CampsiteRuntime.FortGameStateComponent_Campsite.RegisterCampsiteLocation
struct FortGameStateComponent_Campsite_RegisterCampsiteLocation_Params
{
	struct FVector                                     NewCampsiteLocation_69;                                   // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
};

// Function CampsiteRuntime.FortGameStateComponent_Campsite.ClaimUnusedBotName
struct FortGameStateComponent_Campsite_ClaimUnusedBotName_Params
{
	struct FString                                     OutBotName_69;                                            // (Parm, OutParm, ZeroConstructor)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

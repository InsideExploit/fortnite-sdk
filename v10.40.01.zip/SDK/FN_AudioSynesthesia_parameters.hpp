#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function AudioSynesthesia.ConstantQNRT.GetNormalizedChannelConstantQAtTime
struct ConstantQNRT_GetNormalizedChannelConstantQAtTime_Params
{
	float                                              InSeconds_69;                                             // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	int                                                InChannel_69;                                             // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	TArray<float>                                      OutConstantQ_69;                                          // (Parm, OutParm, ZeroConstructor)
};

// Function AudioSynesthesia.ConstantQNRT.GetChannelConstantQAtTime
struct ConstantQNRT_GetChannelConstantQAtTime_Params
{
	float                                              InSeconds_69;                                             // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	int                                                InChannel_69;                                             // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	TArray<float>                                      OutConstantQ_69;                                          // (Parm, OutParm, ZeroConstructor)
};

// Function AudioSynesthesia.LoudnessNRT.GetNormalizedLoudnessAtTime
struct LoudnessNRT_GetNormalizedLoudnessAtTime_Params
{
	float                                              InSeconds_69;                                             // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	float                                              OutLoudness_69;                                           // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
};

// Function AudioSynesthesia.LoudnessNRT.GetNormalizedChannelLoudnessAtTime
struct LoudnessNRT_GetNormalizedChannelLoudnessAtTime_Params
{
	float                                              InSeconds_69;                                             // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	int                                                InChannel_69;                                             // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	float                                              OutLoudness_69;                                           // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
};

// Function AudioSynesthesia.LoudnessNRT.GetLoudnessAtTime
struct LoudnessNRT_GetLoudnessAtTime_Params
{
	float                                              InSeconds_69;                                             // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	float                                              OutLoudness_69;                                           // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
};

// Function AudioSynesthesia.LoudnessNRT.GetChannelLoudnessAtTime
struct LoudnessNRT_GetChannelLoudnessAtTime_Params
{
	float                                              InSeconds_69;                                             // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	int                                                InChannel_69;                                             // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	float                                              OutLoudness_69;                                           // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
};

// Function AudioSynesthesia.OnsetNRT.GetNormalizedChannelOnsetsBetweenTimes
struct OnsetNRT_GetNormalizedChannelOnsetsBetweenTimes_Params
{
	float                                              InStartSeconds_69;                                        // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	float                                              InEndSeconds_69;                                          // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	int                                                InChannel_69;                                             // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	TArray<float>                                      OutOnsetTimestamps_69;                                    // (Parm, OutParm, ZeroConstructor)
	TArray<float>                                      OutOnsetStrengths_69;                                     // (Parm, OutParm, ZeroConstructor)
};

// Function AudioSynesthesia.OnsetNRT.GetChannelOnsetsBetweenTimes
struct OnsetNRT_GetChannelOnsetsBetweenTimes_Params
{
	float                                              InStartSeconds_69;                                        // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	float                                              InEndSeconds_69;                                          // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	int                                                InChannel_69;                                             // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	TArray<float>                                      OutOnsetTimestamps_69;                                    // (Parm, OutParm, ZeroConstructor)
	TArray<float>                                      OutOnsetStrengths_69;                                     // (Parm, OutParm, ZeroConstructor)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

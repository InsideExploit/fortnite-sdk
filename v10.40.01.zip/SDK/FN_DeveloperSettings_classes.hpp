#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Classes
//---------------------------------------------------------------------------

// Class DeveloperSettings.PlatformSettings
// 0x0018 (0x0040 - 0x0028)
class PlatformSettings : public Object_32759
{
public:
	unsigned char                                      UnknownData00[0x18];                                      // 0x0028(0x0018) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class DeveloperSettings.PlatformSettings"));
		
		return ptr;
	}

};


// Class DeveloperSettings.DeveloperSettings
// 0x0008 (0x0030 - 0x0028)
class DeveloperSettings : public Object_32759
{
public:
	unsigned char                                      UnknownData00[0x8];                                       // 0x0028(0x0008) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class DeveloperSettings.DeveloperSettings"));
		
		return ptr;
	}

};


// Class DeveloperSettings.DeveloperSettingsBackedByCVars
// 0x0000 (0x0030 - 0x0030)
class DeveloperSettingsBackedByCVars : public DeveloperSettings
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class DeveloperSettings.DeveloperSettingsBackedByCVars"));
		
		return ptr;
	}

};


// Class DeveloperSettings.PlatformSettingsManager
// 0x0058 (0x0080 - 0x0028)
class PlatformSettingsManager : public Object_32759
{
public:
	TMap<class PlatformSettings*, struct FPlatformSettingsInstances> SettingsMap_69;                                           // 0x0028(0x0050) (Transient)
	unsigned char                                      UnknownData00[0x8];                                       // 0x0078(0x0008) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class DeveloperSettings.PlatformSettingsManager"));
		
		return ptr;
	}

};


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

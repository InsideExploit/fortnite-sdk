#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function DLSSBlueprint.DLSSLibrary.SetDLSSSharpness
struct DLSSLibrary_SetDLSSSharpness_Params
{
	float                                              Sharpness_69;                                             // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function DLSSBlueprint.DLSSLibrary.SetDLSSMode
struct DLSSLibrary_SetDLSSMode_Params
{
	EUDLSSMode                                         DLSSMode_69;                                              // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function DLSSBlueprint.DLSSLibrary.QueryDLSSSupport
struct DLSSLibrary_QueryDLSSSupport_Params
{
	EUDLSSSupport                                      ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function DLSSBlueprint.DLSSLibrary.IsDLSSSupported
struct DLSSLibrary_IsDLSSSupported_Params
{
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function DLSSBlueprint.DLSSLibrary.IsDLSSModeSupported
struct DLSSLibrary_IsDLSSModeSupported_Params
{
	EUDLSSMode                                         DLSSMode_69;                                              // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function DLSSBlueprint.DLSSLibrary.GetSupportedDLSSModes
struct DLSSLibrary_GetSupportedDLSSModes_Params
{
	TArray<EUDLSSMode>                                 ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function DLSSBlueprint.DLSSLibrary.GetDLSSSharpness
struct DLSSLibrary_GetDLSSSharpness_Params
{
	float                                              ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function DLSSBlueprint.DLSSLibrary.GetDLSSScreenPercentageRange
struct DLSSLibrary_GetDLSSScreenPercentageRange_Params
{
	float                                              MinScreenPercentage_69;                                   // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	float                                              MaxScreenPercentage_69;                                   // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
};

// Function DLSSBlueprint.DLSSLibrary.GetDLSSModeInformation
struct DLSSLibrary_GetDLSSModeInformation_Params
{
	EUDLSSMode                                         DLSSMode_69;                                              // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector2D                                   ScreenResolution_69;                                      // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bIsSupported_69;                                          // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	float                                              OptimalScreenPercentage_69;                               // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	bool                                               bIsFixedScreenPercentage_69;                              // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	float                                              MinScreenPercentage_69;                                   // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	float                                              MaxScreenPercentage_69;                                   // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	float                                              OptimalSharpness_69;                                      // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
};

// Function DLSSBlueprint.DLSSLibrary.GetDLSSMode
struct DLSSLibrary_GetDLSSMode_Params
{
	EUDLSSMode                                         ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function DLSSBlueprint.DLSSLibrary.GetDLSSMinimumDriverVersion
struct DLSSLibrary_GetDLSSMinimumDriverVersion_Params
{
	int                                                MinDriverVersionMajor_69;                                 // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	int                                                MinDriverVersionMinor_69;                                 // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
};

// Function DLSSBlueprint.DLSSLibrary.GetDefaultDLSSMode
struct DLSSLibrary_GetDefaultDLSSMode_Params
{
	EUDLSSMode                                         ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

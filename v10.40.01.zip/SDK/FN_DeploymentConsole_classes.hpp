#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Classes
//---------------------------------------------------------------------------

// Class DeploymentConsole.DeploymentConsoleComponent
// 0x0198 (0x0238 - 0x00A0)
class DeploymentConsoleComponent : public ActorComponent
{
public:
	unsigned char                                      UnknownData00[0x28];                                      // 0x00A0(0x0028) MISSED OFFSET
	TArray<struct FDeploymentConsoleAircraftData>      Aircrafts_69;                                             // 0x00C8(0x0010) (BlueprintVisible, ZeroConstructor)
	struct FScalableFloat                              RadiusPercentForRespawnMin_69;                            // 0x00D8(0x0028) (Edit, DisableEditOnInstance)
	struct FScalableFloat                              RadiusPercentForRespawnMax_69;                            // 0x0100(0x0028) (Edit, DisableEditOnInstance)
	struct FScalableFloat                              MaxRespawnRadius_69;                                      // 0x0128(0x0028) (Edit, DisableEditOnInstance)
	struct FScalableFloat                              TeamMemberSpread_69;                                      // 0x0150(0x0028) (Edit, DisableEditOnInstance)
	struct FScalableFloat                              TraceForGroundStart_69;                                   // 0x0178(0x0028) (Edit, BlueprintVisible, BlueprintReadOnly, DisableEditOnInstance)
	struct FScalableFloat                              TraceForGroundEnd_69;                                     // 0x01A0(0x0028) (Edit, BlueprintVisible, BlueprintReadOnly, DisableEditOnInstance)
	struct FScalableFloat                              MinHeightFromGround_69;                                   // 0x01C8(0x0028) (Edit, BlueprintVisible, BlueprintReadOnly, DisableEditOnInstance)
	struct FScalableFloat                              MinHeightFromZero_69;                                     // 0x01F0(0x0028) (Edit, BlueprintVisible, BlueprintReadOnly, DisableEditOnInstance)
	TArray<struct FVector2D>                           SpawnPoints_69;                                           // 0x0218(0x0010) (ZeroConstructor, Transient)
	TArray<struct FDeploymentConsoleTeamData>          TeamSpawnData_69;                                         // 0x0228(0x0010) (ZeroConstructor, Transient)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class DeploymentConsole.DeploymentConsoleComponent"));
		
		return ptr;
	}


	TArray<struct FDeploymentConsoleAircraftData> SpawnAircrafts(bool bSpawnAircraftForEachTeam_69);
	class FortAthenaAircraft* SpawnAircraft(int FlightIndex_69);
	void SetupTeamSpawnPoints(bool bGroupTeams_69);
	void SetAircraftLock(bool bIsLocked_69);
	void SetAircraftDropZone(const struct FBox2D& InDropZone_69);
	struct FVector2D RetrievePlayerSpawnLocation(bool bIsGameInProgress_69, bool bGroupTeams_69, unsigned char InTeam_69);
	struct FBox2D STATIC_MoveBoxTo(const struct FBox2D& InBox_69, const struct FVector2D& VectorToMoveTo_69);
	void InitializeFlightPath(class FortGameStateAthena* GSA_69, const struct FAircraftFlightConstructionInfo& FlightPathConstructionInfo_69);
	TArray<struct FDeploymentConsoleTeamData> GetTeamSpawnData();
	TArray<struct FVector2D> GetSpawnPoints();
	TArray<unsigned char> STATIC_GetMinigameTeamsWithPlayers(class FortMinigame* InMinigame_69);
	class FortAthenaMapInfo* GetMapInfo();
	struct FAircraftFlightConstructionInfo GetDefaultFlightPathConstructionInfo(class FortGameStateAthena* GameStateAthena_69, EAirCraftBehavior AirCraftBehavior_69);
	struct FBox2D GetCachedAircraftSpawnZone();
	void STATIC_ForcePlayerEnterAircraft(class FortPlayerControllerAthena* InController_69, class FortAthenaAircraft* InAircraft_69);
	void ConstructInventoryOnController(class FortPlayerControllerAthena* InController_69);
	void ClearFlightInfos();
	struct FRotator CalculateSpawnRotationFromLocation(const struct FVector& InSpawnLocation_69);
	struct FVector AdjustLocationToValidHeight(const struct FVector& RespawnLocation_69);
};


// Class DeploymentConsole.FortAthenaMutator_CR_Respawn
// 0x0000 (0x0330 - 0x0330)
class FortAthenaMutator_CR_Respawn : public FortAthenaMutator
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class DeploymentConsole.FortAthenaMutator_CR_Respawn"));
		
		return ptr;
	}

};


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

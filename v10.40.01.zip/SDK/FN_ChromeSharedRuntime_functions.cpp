// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Functions
//---------------------------------------------------------------------------

// Function ChromeSharedRuntime.ChromeSoundComponentBase.SetupChromeAudio
// (Event, Public, BlueprintEvent)
// Parameters:
// class Actor_32759*             Actor_69                       (ConstParm, Parm, ZeroConstructor)
// bool                           bAdd_69                        (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// ELacklusterChromeType          ChromeType_69                  (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void ChromeSoundComponentBase::SetupChromeAudio(class Actor_32759* Actor_69, bool bAdd_69, ELacklusterChromeType ChromeType_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ChromeSharedRuntime.ChromeSoundComponentBase.SetupChromeAudio"));

	ChromeSoundComponentBase_SetupChromeAudio_Params params;
	params.Actor_69 = Actor_69;
	params.bAdd_69 = bAdd_69;
	params.ChromeType_69 = ChromeType_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ChromeSharedRuntime.FortChromeSubsystem.ShouldDelayASCCreation
// (Final, RequiredAPI, Native, Static, Public, BlueprintCallable, BlueprintPure)
// Parameters:
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool FortChromeSubsystem::STATIC_ShouldDelayASCCreation()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ChromeSharedRuntime.FortChromeSubsystem.ShouldDelayASCCreation"));

	FortChromeSubsystem_ShouldDelayASCCreation_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ChromeSharedRuntime.FortChromeSubsystem.SetupChromeOnActor
// (Event, Protected, BlueprintCallable, BlueprintEvent)
// Parameters:
// class Actor_32759*             Actor_69                       (ConstParm, Parm, ZeroConstructor)

void FortChromeSubsystem::SetupChromeOnActor(class Actor_32759* Actor_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ChromeSharedRuntime.FortChromeSubsystem.SetupChromeOnActor"));

	FortChromeSubsystem_SetupChromeOnActor_Params params;
	params.Actor_69 = Actor_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ChromeSharedRuntime.FortChromeSubsystem.RestoreActorOriginalMaterials
// (Event, Protected, BlueprintEvent)
// Parameters:
// class Actor_32759*             Actor_69                       (ConstParm, Parm, ZeroConstructor)

void FortChromeSubsystem::RestoreActorOriginalMaterials(class Actor_32759* Actor_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ChromeSharedRuntime.FortChromeSubsystem.RestoreActorOriginalMaterials"));

	FortChromeSubsystem_RestoreActorOriginalMaterials_Params params;
	params.Actor_69 = Actor_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ChromeSharedRuntime.FortChromeSubsystem.PawnHitActor
// (Final, Native, Protected, HasOutParms, BlueprintCallable)
// Parameters:
// class FortPlayerPawn*          Pawn_69                        (Parm, ZeroConstructor)
// struct FHitResult              HitResult_69                   (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
// class Actor_32759*             HitActor_69                    (Parm, ZeroConstructor)

void FortChromeSubsystem::PawnHitActor(class FortPlayerPawn* Pawn_69, const struct FHitResult& HitResult_69, class Actor_32759* HitActor_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ChromeSharedRuntime.FortChromeSubsystem.PawnHitActor"));

	FortChromeSubsystem_PawnHitActor_Params params;
	params.Pawn_69 = Pawn_69;
	params.HitResult_69 = HitResult_69;
	params.HitActor_69 = HitActor_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ChromeSharedRuntime.FortChromeSubsystem.OnPlaylistDataReady
// (Final, Native, Protected, HasOutParms)
// Parameters:
// class FortGameStateAthena*     GameState_69                   (Parm, ZeroConstructor)
// class FortPlaylist*            Playlist_69                    (ConstParm, Parm, ZeroConstructor)
// struct FGameplayTagContainer   PlaylistContextTags_69         (ConstParm, Parm, OutParm, ReferenceParm)

void FortChromeSubsystem::OnPlaylistDataReady(class FortGameStateAthena* GameState_69, class FortPlaylist* Playlist_69, const struct FGameplayTagContainer& PlaylistContextTags_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ChromeSharedRuntime.FortChromeSubsystem.OnPlaylistDataReady"));

	FortChromeSubsystem_OnPlaylistDataReady_Params params;
	params.GameState_69 = GameState_69;
	params.Playlist_69 = Playlist_69;
	params.PlaylistContextTags_69 = PlaylistContextTags_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ChromeSharedRuntime.FortChromeSubsystem.NativeSetupChromeOnActor
// (Final, Native, Protected, BlueprintCallable)
// Parameters:
// class Actor_32759*             Actor_69                       (Parm, ZeroConstructor)

void FortChromeSubsystem::NativeSetupChromeOnActor(class Actor_32759* Actor_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ChromeSharedRuntime.FortChromeSubsystem.NativeSetupChromeOnActor"));

	FortChromeSubsystem_NativeSetupChromeOnActor_Params params;
	params.Actor_69 = Actor_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ChromeSharedRuntime.FortChromeSubsystem.NativeHandleVehicleModUpdated
// (Final, Native, Public, HasOutParms)
// Parameters:
// class FortAthenaVehicle*       Vehicle_69                     (ConstParm, Parm, ZeroConstructor)
// struct FGameplayTag            ModTag_69                      (ConstParm, Parm, OutParm, ReferenceParm)

void FortChromeSubsystem::NativeHandleVehicleModUpdated(class FortAthenaVehicle* Vehicle_69, const struct FGameplayTag& ModTag_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ChromeSharedRuntime.FortChromeSubsystem.NativeHandleVehicleModUpdated"));

	FortChromeSubsystem_NativeHandleVehicleModUpdated_Params params;
	params.Vehicle_69 = Vehicle_69;
	params.ModTag_69 = ModTag_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ChromeSharedRuntime.FortChromeSubsystem.NativeHandleContainerSearchedStateChanged
// (Final, Native, Public)
// Parameters:
// class BuildingContainer*       BuildingContainer_69           (Parm, ZeroConstructor)
// bool                           bSearched_69                   (Parm, ZeroConstructor, IsPlainOldData)

void FortChromeSubsystem::NativeHandleContainerSearchedStateChanged(class BuildingContainer* BuildingContainer_69, bool bSearched_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ChromeSharedRuntime.FortChromeSubsystem.NativeHandleContainerSearchedStateChanged"));

	FortChromeSubsystem_NativeHandleContainerSearchedStateChanged_Params params;
	params.BuildingContainer_69 = BuildingContainer_69;
	params.bSearched_69 = bSearched_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ChromeSharedRuntime.FortChromeSubsystem.NativeHandleContainerRandomUpgradeApplied
// (Final, Native, Public, HasOutParms)
// Parameters:
// class BuildingContainer*       BuildingContainer_69           (Parm, ZeroConstructor)
// int                            UpgradeIndex_69                (Parm, ZeroConstructor, IsPlainOldData)
// struct FName                   UpgradeLootTierGroup_69        (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)

void FortChromeSubsystem::NativeHandleContainerRandomUpgradeApplied(class BuildingContainer* BuildingContainer_69, int UpgradeIndex_69, const struct FName& UpgradeLootTierGroup_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ChromeSharedRuntime.FortChromeSubsystem.NativeHandleContainerRandomUpgradeApplied"));

	FortChromeSubsystem_NativeHandleContainerRandomUpgradeApplied_Params params;
	params.BuildingContainer_69 = BuildingContainer_69;
	params.UpgradeIndex_69 = UpgradeIndex_69;
	params.UpgradeLootTierGroup_69 = UpgradeLootTierGroup_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ChromeSharedRuntime.FortChromeSubsystem.NativeHandleContainerMeshSetChanged
// (Final, Native, Public, HasOutParms)
// Parameters:
// class BuildingSMActor*         BuildingSMActor_69             (Parm, ZeroConstructor)
// struct FMeshSet                NewMeshSet_69                  (ConstParm, Parm, OutParm, ReferenceParm)

void FortChromeSubsystem::NativeHandleContainerMeshSetChanged(class BuildingSMActor* BuildingSMActor_69, const struct FMeshSet& NewMeshSet_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ChromeSharedRuntime.FortChromeSubsystem.NativeHandleContainerMeshSetChanged"));

	FortChromeSubsystem_NativeHandleContainerMeshSetChanged_Params params;
	params.BuildingSMActor_69 = BuildingSMActor_69;
	params.NewMeshSet_69 = NewMeshSet_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ChromeSharedRuntime.FortChromeSubsystem.IsActorPhaseable
// (Final, Native, Static, Public, BlueprintCallable, BlueprintPure)
// Parameters:
// class Actor_32759*             Actor_69                       (ConstParm, Parm, ZeroConstructor)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool FortChromeSubsystem::STATIC_IsActorPhaseable(class Actor_32759* Actor_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ChromeSharedRuntime.FortChromeSubsystem.IsActorPhaseable"));

	FortChromeSubsystem_IsActorPhaseable_Params params;
	params.Actor_69 = Actor_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ChromeSharedRuntime.FortChromeSubsystem.IsActorChromable
// (Final, RequiredAPI, Native, Static, Public, BlueprintCallable, BlueprintPure)
// Parameters:
// class Actor_32759*             Actor_69                       (ConstParm, Parm, ZeroConstructor)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool FortChromeSubsystem::STATIC_IsActorChromable(class Actor_32759* Actor_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ChromeSharedRuntime.FortChromeSubsystem.IsActorChromable"));

	FortChromeSubsystem_IsActorChromable_Params params;
	params.Actor_69 = Actor_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ChromeSharedRuntime.FortChromeSubsystem.InitLacklusterFunctionLibrary
// (Event, Protected, BlueprintEvent)

void FortChromeSubsystem::InitLacklusterFunctionLibrary()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ChromeSharedRuntime.FortChromeSubsystem.InitLacklusterFunctionLibrary"));

	FortChromeSubsystem_InitLacklusterFunctionLibrary_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ChromeSharedRuntime.FortChromeSubsystem.GetSharedChromeMID
// (Final, RequiredAPI, Native, Static, Public, HasOutParms, BlueprintCallable)
// Parameters:
// class Actor_32759*             Actor_69                       (Parm, ZeroConstructor)
// class MaterialInterface*       Parent_69                      (Parm, ZeroConstructor)
// TMap<struct FName, class Texture*> NamesToTexturesMap_69          (Parm, OutParm, ReferenceParm)
// class MaterialInstanceDynamic* ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

class MaterialInstanceDynamic* FortChromeSubsystem::STATIC_GetSharedChromeMID(class Actor_32759* Actor_69, class MaterialInterface* Parent_69, TMap<struct FName, class Texture*>* NamesToTexturesMap_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ChromeSharedRuntime.FortChromeSubsystem.GetSharedChromeMID"));

	FortChromeSubsystem_GetSharedChromeMID_Params params;
	params.Actor_69 = Actor_69;
	params.Parent_69 = Parent_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (NamesToTexturesMap_69 != nullptr)
		*NamesToTexturesMap_69 = params.NamesToTexturesMap_69;

	return params.ReturnValue_69;
}


// Function ChromeSharedRuntime.FortChromeSubsystem.GetOverlappingActorsOfClass
// (Final, Native, Public, HasOutParms, BlueprintCallable)
// Parameters:
// class Actor_32759*             Actor_69                       (ConstParm, Parm, ZeroConstructor)
// class Actor_32759*             Class_69                       (ConstParm, Parm, ZeroConstructor)
// TArray<class Actor_32759*>     OutOverlappingActors_69        (Parm, OutParm, ZeroConstructor, ReferenceParm)

void FortChromeSubsystem::GetOverlappingActorsOfClass(class Actor_32759* Actor_69, class Actor_32759* Class_69, TArray<class Actor_32759*>* OutOverlappingActors_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ChromeSharedRuntime.FortChromeSubsystem.GetOverlappingActorsOfClass"));

	FortChromeSubsystem_GetOverlappingActorsOfClass_Params params;
	params.Actor_69 = Actor_69;
	params.Class_69 = Class_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (OutOverlappingActors_69 != nullptr)
		*OutOverlappingActors_69 = params.OutOverlappingActors_69;
}


// Function ChromeSharedRuntime.FortChromeSubsystem.ApplyChromeToActor
// (Event, Protected, BlueprintEvent)
// Parameters:
// class Actor_32759*             Actor_69                       (ConstParm, Parm, ZeroConstructor)

void FortChromeSubsystem::ApplyChromeToActor(class Actor_32759* Actor_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ChromeSharedRuntime.FortChromeSubsystem.ApplyChromeToActor"));

	FortChromeSubsystem_ApplyChromeToActor_Params params;
	params.Actor_69 = Actor_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ChromeSharedRuntime.LacklusterFunctionLibrary.UseNativeFunctions
// (Final, Native, Static, Public, BlueprintCallable, BlueprintPure)
// Parameters:
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool LacklusterFunctionLibrary::STATIC_UseNativeFunctions()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ChromeSharedRuntime.LacklusterFunctionLibrary.UseNativeFunctions"));

	LacklusterFunctionLibrary_UseNativeFunctions_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ChromeSharedRuntime.LacklusterFunctionLibrary.NativeUnbindChromeEvents
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// class Actor_32759*             Actor_69                       (Parm, ZeroConstructor)

void LacklusterFunctionLibrary::STATIC_NativeUnbindChromeEvents(class Actor_32759* Actor_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ChromeSharedRuntime.LacklusterFunctionLibrary.NativeUnbindChromeEvents"));

	LacklusterFunctionLibrary_NativeUnbindChromeEvents_Params params;
	params.Actor_69 = Actor_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ChromeSharedRuntime.LacklusterFunctionLibrary.NativeStopBuildingAudio
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// class BuildingActor*           BuildingActor_69               (ConstParm, Parm, ZeroConstructor)

void LacklusterFunctionLibrary::STATIC_NativeStopBuildingAudio(class BuildingActor* BuildingActor_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ChromeSharedRuntime.LacklusterFunctionLibrary.NativeStopBuildingAudio"));

	LacklusterFunctionLibrary_NativeStopBuildingAudio_Params params;
	params.BuildingActor_69 = BuildingActor_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ChromeSharedRuntime.LacklusterFunctionLibrary.NativeShouldIgnoreMaterial
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// class MaterialInterface*       Material_69                    (Parm, ZeroConstructor)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool LacklusterFunctionLibrary::STATIC_NativeShouldIgnoreMaterial(class MaterialInterface* Material_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ChromeSharedRuntime.LacklusterFunctionLibrary.NativeShouldIgnoreMaterial"));

	LacklusterFunctionLibrary_NativeShouldIgnoreMaterial_Params params;
	params.Material_69 = Material_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ChromeSharedRuntime.LacklusterFunctionLibrary.NativeSetupChromeOnActor
// (Final, Native, Static, Public, HasOutParms, BlueprintCallable)
// Parameters:
// class Actor_32759*             Actor_69                       (Parm, ZeroConstructor)
// ELacklusterActorType           ActorType_69                   (Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
// ELacklusterChromeType          ChromeType_69                  (Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
// TArray<struct FLacklusterMaterialData> ChromeMaterialData_69          (Parm, OutParm, ZeroConstructor, ReferenceParm)
// TArray<struct FLacklusterOriginalMaterialData> OriginalMaterialData_69        (Parm, OutParm, ZeroConstructor, ReferenceParm)
// TMap<struct FName, float>      ContainerMatScalarParamMap_69  (Parm, OutParm, ReferenceParm)
// TMap<struct FName, struct FLinearColor> ContainerMatVectorParamMap_69  (Parm, OutParm, ReferenceParm)

void LacklusterFunctionLibrary::STATIC_NativeSetupChromeOnActor(class Actor_32759* Actor_69, ELacklusterActorType* ActorType_69, ELacklusterChromeType* ChromeType_69, TArray<struct FLacklusterMaterialData>* ChromeMaterialData_69, TArray<struct FLacklusterOriginalMaterialData>* OriginalMaterialData_69, TMap<struct FName, float>* ContainerMatScalarParamMap_69, TMap<struct FName, struct FLinearColor>* ContainerMatVectorParamMap_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ChromeSharedRuntime.LacklusterFunctionLibrary.NativeSetupChromeOnActor"));

	LacklusterFunctionLibrary_NativeSetupChromeOnActor_Params params;
	params.Actor_69 = Actor_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (ActorType_69 != nullptr)
		*ActorType_69 = params.ActorType_69;
	if (ChromeType_69 != nullptr)
		*ChromeType_69 = params.ChromeType_69;
	if (ChromeMaterialData_69 != nullptr)
		*ChromeMaterialData_69 = params.ChromeMaterialData_69;
	if (OriginalMaterialData_69 != nullptr)
		*OriginalMaterialData_69 = params.OriginalMaterialData_69;
	if (ContainerMatScalarParamMap_69 != nullptr)
		*ContainerMatScalarParamMap_69 = params.ContainerMatScalarParamMap_69;
	if (ContainerMatVectorParamMap_69 != nullptr)
		*ContainerMatVectorParamMap_69 = params.ContainerMatVectorParamMap_69;
}


// Function ChromeSharedRuntime.LacklusterFunctionLibrary.NativeSetChromeMaterials
// (Final, Native, Static, Public, HasOutParms, BlueprintCallable)
// Parameters:
// TArray<struct FLacklusterMaterialData> ChromeMaterialStructs_69       (Parm, OutParm, ZeroConstructor, ReferenceParm)
// ELacklusterChromeType          ChromeType_69                  (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void LacklusterFunctionLibrary::STATIC_NativeSetChromeMaterials(ELacklusterChromeType ChromeType_69, TArray<struct FLacklusterMaterialData>* ChromeMaterialStructs_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ChromeSharedRuntime.LacklusterFunctionLibrary.NativeSetChromeMaterials"));

	LacklusterFunctionLibrary_NativeSetChromeMaterials_Params params;
	params.ChromeType_69 = ChromeType_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (ChromeMaterialStructs_69 != nullptr)
		*ChromeMaterialStructs_69 = params.ChromeMaterialStructs_69;
}


// Function ChromeSharedRuntime.LacklusterFunctionLibrary.NativeSetChromeAudio
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// class Actor_32759*             Actor_69                       (Parm, ZeroConstructor)
// bool                           bAdd_69                        (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// ELacklusterChromeType          ChromeType_69                  (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void LacklusterFunctionLibrary::STATIC_NativeSetChromeAudio(class Actor_32759* Actor_69, bool bAdd_69, ELacklusterChromeType ChromeType_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ChromeSharedRuntime.LacklusterFunctionLibrary.NativeSetChromeAudio"));

	LacklusterFunctionLibrary_NativeSetChromeAudio_Params params;
	params.Actor_69 = Actor_69;
	params.bAdd_69 = bAdd_69;
	params.ChromeType_69 = ChromeType_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ChromeSharedRuntime.LacklusterFunctionLibrary.NativeRestoreOriginalMaterials
// (Final, Native, Static, Public, HasOutParms, BlueprintCallable)
// Parameters:
// class Actor_32759*             Actor_69                       (Parm, ZeroConstructor)
// TArray<struct FLacklusterOriginalMaterialData> OriginalMaterialDataArray_69   (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)

void LacklusterFunctionLibrary::STATIC_NativeRestoreOriginalMaterials(class Actor_32759* Actor_69, TArray<struct FLacklusterOriginalMaterialData> OriginalMaterialDataArray_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ChromeSharedRuntime.LacklusterFunctionLibrary.NativeRestoreOriginalMaterials"));

	LacklusterFunctionLibrary_NativeRestoreOriginalMaterials_Params params;
	params.Actor_69 = Actor_69;
	params.OriginalMaterialDataArray_69 = OriginalMaterialDataArray_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ChromeSharedRuntime.LacklusterFunctionLibrary.NativeIsMaskedBlendMode
// (Final, Native, Static, Public, BlueprintCallable, BlueprintPure)
// Parameters:
// class MaterialInterface*       MaterialInterface_69           (ConstParm, Parm, ZeroConstructor)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool LacklusterFunctionLibrary::STATIC_NativeIsMaskedBlendMode(class MaterialInterface* MaterialInterface_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ChromeSharedRuntime.LacklusterFunctionLibrary.NativeIsMaskedBlendMode"));

	LacklusterFunctionLibrary_NativeIsMaskedBlendMode_Params params;
	params.MaterialInterface_69 = MaterialInterface_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ChromeSharedRuntime.LacklusterFunctionLibrary.NativeHandleActorTypeSpecialCases
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// ELacklusterActorType           ActorType_69                   (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// bool                           bIsMaskedMaterial_69           (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// bool                           bIsChonkers_69                 (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// ELacklusterActorType           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

ELacklusterActorType LacklusterFunctionLibrary::STATIC_NativeHandleActorTypeSpecialCases(ELacklusterActorType ActorType_69, bool bIsMaskedMaterial_69, bool bIsChonkers_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ChromeSharedRuntime.LacklusterFunctionLibrary.NativeHandleActorTypeSpecialCases"));

	LacklusterFunctionLibrary_NativeHandleActorTypeSpecialCases_Params params;
	params.ActorType_69 = ActorType_69;
	params.bIsMaskedMaterial_69 = bIsMaskedMaterial_69;
	params.bIsChonkers_69 = bIsChonkers_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ChromeSharedRuntime.LacklusterFunctionLibrary.NativeGetChromeVisualComponent
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// class Actor_32759*             Actor_69                       (Parm, ZeroConstructor)
// bool                           bCreateComponentIfNotFound_69  (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// class ApplyChromeComponent*    ReturnValue_69                 (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)

class ApplyChromeComponent* LacklusterFunctionLibrary::STATIC_NativeGetChromeVisualComponent(class Actor_32759* Actor_69, bool bCreateComponentIfNotFound_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ChromeSharedRuntime.LacklusterFunctionLibrary.NativeGetChromeVisualComponent"));

	LacklusterFunctionLibrary_NativeGetChromeVisualComponent_Params params;
	params.Actor_69 = Actor_69;
	params.bCreateComponentIfNotFound_69 = bCreateComponentIfNotFound_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ChromeSharedRuntime.LacklusterFunctionLibrary.NativeGetChromeTieredChestMaterial
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// class Actor_32759*             Actor_69                       (ConstParm, Parm, ZeroConstructor)
// class MaterialInstance*        ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

class MaterialInstance* LacklusterFunctionLibrary::STATIC_NativeGetChromeTieredChestMaterial(class Actor_32759* Actor_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ChromeSharedRuntime.LacklusterFunctionLibrary.NativeGetChromeTieredChestMaterial"));

	LacklusterFunctionLibrary_NativeGetChromeTieredChestMaterial_Params params;
	params.Actor_69 = Actor_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ChromeSharedRuntime.LacklusterFunctionLibrary.NativeGetChromeSoundComponent
// (Final, Native, Static, Public, BlueprintCallable, BlueprintPure)
// Parameters:
// class Actor_32759*             Actor_69                       (Parm, ZeroConstructor)
// bool                           bCreateComponentIfNotFound_69  (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// class ChromeSoundComponentBase* ReturnValue_69                 (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)

class ChromeSoundComponentBase* LacklusterFunctionLibrary::STATIC_NativeGetChromeSoundComponent(class Actor_32759* Actor_69, bool bCreateComponentIfNotFound_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ChromeSharedRuntime.LacklusterFunctionLibrary.NativeGetChromeSoundComponent"));

	LacklusterFunctionLibrary_NativeGetChromeSoundComponent_Params params;
	params.Actor_69 = Actor_69;
	params.bCreateComponentIfNotFound_69 = bCreateComponentIfNotFound_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ChromeSharedRuntime.LacklusterFunctionLibrary.NativeGetChromeMaterialOverride
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// bool                           bIsMaskedMaterial_69           (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// bool                           bIsChonkers_69                 (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// ELacklusterActorType           ActorType_69                   (Parm, ZeroConstructor, IsPlainOldData)
// class Actor_32759*             Actor_69                       (Parm, ZeroConstructor)
// ELacklusterChromeType          ChromeType_69                  (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// class MaterialInterface*       ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

class MaterialInterface* LacklusterFunctionLibrary::STATIC_NativeGetChromeMaterialOverride(bool bIsMaskedMaterial_69, bool bIsChonkers_69, ELacklusterActorType ActorType_69, class Actor_32759* Actor_69, ELacklusterChromeType ChromeType_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ChromeSharedRuntime.LacklusterFunctionLibrary.NativeGetChromeMaterialOverride"));

	LacklusterFunctionLibrary_NativeGetChromeMaterialOverride_Params params;
	params.bIsMaskedMaterial_69 = bIsMaskedMaterial_69;
	params.bIsChonkers_69 = bIsChonkers_69;
	params.ActorType_69 = ActorType_69;
	params.Actor_69 = Actor_69;
	params.ChromeType_69 = ChromeType_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ChromeSharedRuntime.LacklusterFunctionLibrary.NativeGetChromeChonkerTires
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// class MeshComponent*           MeshComponent_69               (ConstParm, Parm, ZeroConstructor, InstancedReference)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool LacklusterFunctionLibrary::STATIC_NativeGetChromeChonkerTires(class MeshComponent* MeshComponent_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ChromeSharedRuntime.LacklusterFunctionLibrary.NativeGetChromeChonkerTires"));

	LacklusterFunctionLibrary_NativeGetChromeChonkerTires_Params params;
	params.MeshComponent_69 = MeshComponent_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ChromeSharedRuntime.LacklusterFunctionLibrary.NativeGetChromeActorType
// (Final, Native, Static, Public, HasOutParms, BlueprintCallable)
// Parameters:
// class Actor_32759*             Actor_69                       (Parm, ZeroConstructor)
// ELacklusterChromeType          ChromeTypeOut_69               (Parm, OutParm, ZeroConstructor, IsPlainOldData)
// ELacklusterActorType           ActorTypeOut_69                (Parm, OutParm, ZeroConstructor, IsPlainOldData)

void LacklusterFunctionLibrary::STATIC_NativeGetChromeActorType(class Actor_32759* Actor_69, ELacklusterChromeType* ChromeTypeOut_69, ELacklusterActorType* ActorTypeOut_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ChromeSharedRuntime.LacklusterFunctionLibrary.NativeGetChromeActorType"));

	LacklusterFunctionLibrary_NativeGetChromeActorType_Params params;
	params.Actor_69 = Actor_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (ChromeTypeOut_69 != nullptr)
		*ChromeTypeOut_69 = params.ChromeTypeOut_69;
	if (ActorTypeOut_69 != nullptr)
		*ActorTypeOut_69 = params.ActorTypeOut_69;
}


// Function ChromeSharedRuntime.LacklusterFunctionLibrary.NativeFindTexturesFromComponents
// (Final, Native, Static, Public, HasOutParms, BlueprintCallable)
// Parameters:
// ELacklusterActorType           ActorType_69                   (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// class Actor_32759*             Actor_69                       (Parm, ZeroConstructor)
// TArray<struct FLacklusterMaterialData> ChromeMaterialStructs_69       (Parm, OutParm, ZeroConstructor)
// TArray<struct FLacklusterOriginalMaterialData> OriginalMaterialStructs_69     (Parm, OutParm, ZeroConstructor)

void LacklusterFunctionLibrary::STATIC_NativeFindTexturesFromComponents(ELacklusterActorType ActorType_69, class Actor_32759* Actor_69, TArray<struct FLacklusterMaterialData>* ChromeMaterialStructs_69, TArray<struct FLacklusterOriginalMaterialData>* OriginalMaterialStructs_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ChromeSharedRuntime.LacklusterFunctionLibrary.NativeFindTexturesFromComponents"));

	LacklusterFunctionLibrary_NativeFindTexturesFromComponents_Params params;
	params.ActorType_69 = ActorType_69;
	params.Actor_69 = Actor_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (ChromeMaterialStructs_69 != nullptr)
		*ChromeMaterialStructs_69 = params.ChromeMaterialStructs_69;
	if (OriginalMaterialStructs_69 != nullptr)
		*OriginalMaterialStructs_69 = params.OriginalMaterialStructs_69;
}


// Function ChromeSharedRuntime.LacklusterFunctionLibrary.NativeFindSetParameterName
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// ELacklusterTextureGroup        TextureGroup_69                (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// struct FName                   ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

struct FName LacklusterFunctionLibrary::STATIC_NativeFindSetParameterName(ELacklusterTextureGroup TextureGroup_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ChromeSharedRuntime.LacklusterFunctionLibrary.NativeFindSetParameterName"));

	LacklusterFunctionLibrary_NativeFindSetParameterName_Params params;
	params.TextureGroup_69 = TextureGroup_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ChromeSharedRuntime.LacklusterFunctionLibrary.NativeFindGetSetParameters
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// bool                           bIsMaskedMaterial_69           (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// bool                           bIsChonkers_69                 (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// ELacklusterActorType           ActorType_69                   (Parm, ZeroConstructor, IsPlainOldData)
// class MeshComponent*           MeshComponent_69               (Parm, ZeroConstructor, InstancedReference)
// TArray<struct FLacklusterTextureSet> ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

TArray<struct FLacklusterTextureSet> LacklusterFunctionLibrary::STATIC_NativeFindGetSetParameters(bool bIsMaskedMaterial_69, bool bIsChonkers_69, ELacklusterActorType ActorType_69, class MeshComponent* MeshComponent_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ChromeSharedRuntime.LacklusterFunctionLibrary.NativeFindGetSetParameters"));

	LacklusterFunctionLibrary_NativeFindGetSetParameters_Params params;
	params.bIsMaskedMaterial_69 = bIsMaskedMaterial_69;
	params.bIsChonkers_69 = bIsChonkers_69;
	params.ActorType_69 = ActorType_69;
	params.MeshComponent_69 = MeshComponent_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ChromeSharedRuntime.LacklusterFunctionLibrary.NativeExecuteOwnerTypeFunctionality_PreChrome_Container
// (Final, Native, Static, Public, HasOutParms, BlueprintCallable)
// Parameters:
// class Actor_32759*             Actor_69                       (Parm, ZeroConstructor)
// struct FGameplayTagContainer   ContainerTags_69               (ConstParm, Parm, OutParm, ReferenceParm)
// TMap<struct FName, float>      ContainerMatScalarParamMap_69  (Parm, OutParm, ReferenceParm)
// TMap<struct FName, struct FLinearColor> ContainerMatVectorParamMap_69  (Parm, OutParm, ReferenceParm)

void LacklusterFunctionLibrary::STATIC_NativeExecuteOwnerTypeFunctionality_PreChrome_Container(class Actor_32759* Actor_69, const struct FGameplayTagContainer& ContainerTags_69, TMap<struct FName, float>* ContainerMatScalarParamMap_69, TMap<struct FName, struct FLinearColor>* ContainerMatVectorParamMap_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ChromeSharedRuntime.LacklusterFunctionLibrary.NativeExecuteOwnerTypeFunctionality_PreChrome_Container"));

	LacklusterFunctionLibrary_NativeExecuteOwnerTypeFunctionality_PreChrome_Container_Params params;
	params.Actor_69 = Actor_69;
	params.ContainerTags_69 = ContainerTags_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (ContainerMatScalarParamMap_69 != nullptr)
		*ContainerMatScalarParamMap_69 = params.ContainerMatScalarParamMap_69;
	if (ContainerMatVectorParamMap_69 != nullptr)
		*ContainerMatVectorParamMap_69 = params.ContainerMatVectorParamMap_69;
}


// Function ChromeSharedRuntime.LacklusterFunctionLibrary.NativeExecuteOwnerTypeFunctionality_PreChrome
// (Final, Native, Static, Public, HasOutParms, BlueprintCallable)
// Parameters:
// class Actor_32759*             Actor_69                       (Parm, ZeroConstructor)
// ELacklusterActorType           ActorType_69                   (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// struct FGameplayTagContainer   ContainerTags_69               (ConstParm, Parm, OutParm, ReferenceParm)
// TMap<struct FName, float>      ContainerMatScalarParamMap_69  (Parm, OutParm, ReferenceParm)
// TMap<struct FName, struct FLinearColor> ContainerMatVectorParamMap_69  (Parm, OutParm, ReferenceParm)

void LacklusterFunctionLibrary::STATIC_NativeExecuteOwnerTypeFunctionality_PreChrome(class Actor_32759* Actor_69, ELacklusterActorType ActorType_69, const struct FGameplayTagContainer& ContainerTags_69, TMap<struct FName, float>* ContainerMatScalarParamMap_69, TMap<struct FName, struct FLinearColor>* ContainerMatVectorParamMap_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ChromeSharedRuntime.LacklusterFunctionLibrary.NativeExecuteOwnerTypeFunctionality_PreChrome"));

	LacklusterFunctionLibrary_NativeExecuteOwnerTypeFunctionality_PreChrome_Params params;
	params.Actor_69 = Actor_69;
	params.ActorType_69 = ActorType_69;
	params.ContainerTags_69 = ContainerTags_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (ContainerMatScalarParamMap_69 != nullptr)
		*ContainerMatScalarParamMap_69 = params.ContainerMatScalarParamMap_69;
	if (ContainerMatVectorParamMap_69 != nullptr)
		*ContainerMatVectorParamMap_69 = params.ContainerMatVectorParamMap_69;
}


// Function ChromeSharedRuntime.LacklusterFunctionLibrary.NativeExecuteOwnerTypeFunctionality_PostChrome_Vehicle
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// class Actor_32759*             Actor_69                       (Parm, ZeroConstructor)

void LacklusterFunctionLibrary::STATIC_NativeExecuteOwnerTypeFunctionality_PostChrome_Vehicle(class Actor_32759* Actor_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ChromeSharedRuntime.LacklusterFunctionLibrary.NativeExecuteOwnerTypeFunctionality_PostChrome_Vehicle"));

	LacklusterFunctionLibrary_NativeExecuteOwnerTypeFunctionality_PostChrome_Vehicle_Params params;
	params.Actor_69 = Actor_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ChromeSharedRuntime.LacklusterFunctionLibrary.NativeExecuteOwnerTypeFunctionality_PostChrome_Container
// (Final, Native, Static, Public, HasOutParms, BlueprintCallable)
// Parameters:
// class Actor_32759*             Actor_69                       (Parm, ZeroConstructor)
// struct FGameplayTagContainer   ContainerTags_69               (ConstParm, Parm, OutParm, ReferenceParm)
// TMap<struct FName, float>      ContainerMatScalarParamMap_69  (ConstParm, Parm, OutParm, ReferenceParm)
// TMap<struct FName, struct FLinearColor> ContainerMatVectorParamMap_69  (ConstParm, Parm, OutParm, ReferenceParm)

void LacklusterFunctionLibrary::STATIC_NativeExecuteOwnerTypeFunctionality_PostChrome_Container(class Actor_32759* Actor_69, const struct FGameplayTagContainer& ContainerTags_69, TMap<struct FName, float> ContainerMatScalarParamMap_69, TMap<struct FName, struct FLinearColor> ContainerMatVectorParamMap_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ChromeSharedRuntime.LacklusterFunctionLibrary.NativeExecuteOwnerTypeFunctionality_PostChrome_Container"));

	LacklusterFunctionLibrary_NativeExecuteOwnerTypeFunctionality_PostChrome_Container_Params params;
	params.Actor_69 = Actor_69;
	params.ContainerTags_69 = ContainerTags_69;
	params.ContainerMatScalarParamMap_69 = ContainerMatScalarParamMap_69;
	params.ContainerMatVectorParamMap_69 = ContainerMatVectorParamMap_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ChromeSharedRuntime.LacklusterFunctionLibrary.NativeExecuteOwnerTypeFunctionality_PostChrome
// (Final, Native, Static, Public, HasOutParms, BlueprintCallable)
// Parameters:
// class Actor_32759*             Actor_69                       (Parm, ZeroConstructor)
// ELacklusterActorType           ActorType_69                   (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// struct FGameplayTagContainer   ContainerTags_69               (ConstParm, Parm, OutParm, ReferenceParm)
// TMap<struct FName, float>      ContainerMatScalarParamMap_69  (ConstParm, Parm, OutParm, ReferenceParm)
// TMap<struct FName, struct FLinearColor> ContainerMatVectorParamMap_69  (ConstParm, Parm, OutParm, ReferenceParm)

void LacklusterFunctionLibrary::STATIC_NativeExecuteOwnerTypeFunctionality_PostChrome(class Actor_32759* Actor_69, ELacklusterActorType ActorType_69, const struct FGameplayTagContainer& ContainerTags_69, TMap<struct FName, float> ContainerMatScalarParamMap_69, TMap<struct FName, struct FLinearColor> ContainerMatVectorParamMap_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ChromeSharedRuntime.LacklusterFunctionLibrary.NativeExecuteOwnerTypeFunctionality_PostChrome"));

	LacklusterFunctionLibrary_NativeExecuteOwnerTypeFunctionality_PostChrome_Params params;
	params.Actor_69 = Actor_69;
	params.ActorType_69 = ActorType_69;
	params.ContainerTags_69 = ContainerTags_69;
	params.ContainerMatScalarParamMap_69 = ContainerMatScalarParamMap_69;
	params.ContainerMatVectorParamMap_69 = ContainerMatVectorParamMap_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ChromeSharedRuntime.LacklusterFunctionLibrary.NativeExcludeFromChroming
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// class SceneComponent*          Component_69                   (ConstParm, Parm, ZeroConstructor, InstancedReference)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool LacklusterFunctionLibrary::STATIC_NativeExcludeFromChroming(class SceneComponent* Component_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ChromeSharedRuntime.LacklusterFunctionLibrary.NativeExcludeFromChroming"));

	LacklusterFunctionLibrary_NativeExcludeFromChroming_Params params;
	params.Component_69 = Component_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ChromeSharedRuntime.LacklusterFunctionLibrary.NativeDoesActorSupportChromeSoundComponent
// (Final, Native, Static, Public, BlueprintCallable, BlueprintPure)
// Parameters:
// class Actor_32759*             Actor_69                       (Parm, ZeroConstructor)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool LacklusterFunctionLibrary::STATIC_NativeDoesActorSupportChromeSoundComponent(class Actor_32759* Actor_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ChromeSharedRuntime.LacklusterFunctionLibrary.NativeDoesActorSupportChromeSoundComponent"));

	LacklusterFunctionLibrary_NativeDoesActorSupportChromeSoundComponent_Params params;
	params.Actor_69 = Actor_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ChromeSharedRuntime.LacklusterFunctionLibrary.NativeDisableShadowProxyWPO
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// class Actor_32759*             Actor_69                       (Parm, ZeroConstructor)

void LacklusterFunctionLibrary::STATIC_NativeDisableShadowProxyWPO(class Actor_32759* Actor_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ChromeSharedRuntime.LacklusterFunctionLibrary.NativeDisableShadowProxyWPO"));

	LacklusterFunctionLibrary_NativeDisableShadowProxyWPO_Params params;
	params.Actor_69 = Actor_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ChromeSharedRuntime.LacklusterFunctionLibrary.NativeCastToSpecificClasses
// (Final, Native, Static, Public, HasOutParms, BlueprintCallable)
// Parameters:
// class Actor_32759*             Actor_69                       (Parm, ZeroConstructor)
// ELacklusterChromeType          ChromeTypeIn_69                (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// ELacklusterChromeType          ChromeTypeOut_69               (Parm, OutParm, ZeroConstructor, IsPlainOldData)
// ELacklusterActorType           ActorTypeOut_69                (Parm, OutParm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool LacklusterFunctionLibrary::STATIC_NativeCastToSpecificClasses(class Actor_32759* Actor_69, ELacklusterChromeType ChromeTypeIn_69, ELacklusterChromeType* ChromeTypeOut_69, ELacklusterActorType* ActorTypeOut_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ChromeSharedRuntime.LacklusterFunctionLibrary.NativeCastToSpecificClasses"));

	LacklusterFunctionLibrary_NativeCastToSpecificClasses_Params params;
	params.Actor_69 = Actor_69;
	params.ChromeTypeIn_69 = ChromeTypeIn_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (ChromeTypeOut_69 != nullptr)
		*ChromeTypeOut_69 = params.ChromeTypeOut_69;
	if (ActorTypeOut_69 != nullptr)
		*ActorTypeOut_69 = params.ActorTypeOut_69;

	return params.ReturnValue_69;
}


// Function ChromeSharedRuntime.LacklusterFunctionLibrary.NativeCastToParentClasses
// (Final, Native, Static, Public, HasOutParms, BlueprintCallable)
// Parameters:
// class Actor_32759*             Actor_69                       (Parm, ZeroConstructor)
// ELacklusterActorType           ActorTypeOut_69                (Parm, OutParm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool LacklusterFunctionLibrary::STATIC_NativeCastToParentClasses(class Actor_32759* Actor_69, ELacklusterActorType* ActorTypeOut_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ChromeSharedRuntime.LacklusterFunctionLibrary.NativeCastToParentClasses"));

	LacklusterFunctionLibrary_NativeCastToParentClasses_Params params;
	params.Actor_69 = Actor_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (ActorTypeOut_69 != nullptr)
		*ActorTypeOut_69 = params.ActorTypeOut_69;

	return params.ReturnValue_69;
}


// Function ChromeSharedRuntime.LacklusterFunctionLibrary.NativeBindChromeEvents
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// class Actor_32759*             Actor_69                       (Parm, ZeroConstructor)

void LacklusterFunctionLibrary::STATIC_NativeBindChromeEvents(class Actor_32759* Actor_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ChromeSharedRuntime.LacklusterFunctionLibrary.NativeBindChromeEvents"));

	LacklusterFunctionLibrary_NativeBindChromeEvents_Params params;
	params.Actor_69 = Actor_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ChromeSharedRuntime.LacklusterFunctionLibrary.NativeAreWeOverridingAudio
// (Final, Native, Static, Public, BlueprintCallable, BlueprintPure)
// Parameters:
// class Actor_32759*             Actor_69                       (ConstParm, Parm, ZeroConstructor)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool LacklusterFunctionLibrary::STATIC_NativeAreWeOverridingAudio(class Actor_32759* Actor_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ChromeSharedRuntime.LacklusterFunctionLibrary.NativeAreWeOverridingAudio"));

	LacklusterFunctionLibrary_NativeAreWeOverridingAudio_Params params;
	params.Actor_69 = Actor_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ChromeSharedRuntime.LacklusterFunctionLibrary.NativeApplyChromeToActor
// (Final, Native, Static, Public, HasOutParms, BlueprintCallable)
// Parameters:
// class Actor_32759*             Actor_69                       (Parm, ZeroConstructor)
// ELacklusterActorType           ActorType_69                   (Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
// ELacklusterChromeType          ChromeType_69                  (Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
// TArray<struct FLacklusterMaterialData> ChromeMaterialData_69          (Parm, OutParm, ZeroConstructor, ReferenceParm)
// TArray<struct FLacklusterOriginalMaterialData> OriginalMaterialData_69        (Parm, OutParm, ZeroConstructor, ReferenceParm)
// TMap<struct FName, float>      ContainerMatScalarParamMap_69  (Parm, OutParm, ReferenceParm)
// TMap<struct FName, struct FLinearColor> ContainerMatVectorParamMap_69  (Parm, OutParm, ReferenceParm)

void LacklusterFunctionLibrary::STATIC_NativeApplyChromeToActor(class Actor_32759* Actor_69, ELacklusterActorType* ActorType_69, ELacklusterChromeType* ChromeType_69, TArray<struct FLacklusterMaterialData>* ChromeMaterialData_69, TArray<struct FLacklusterOriginalMaterialData>* OriginalMaterialData_69, TMap<struct FName, float>* ContainerMatScalarParamMap_69, TMap<struct FName, struct FLinearColor>* ContainerMatVectorParamMap_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ChromeSharedRuntime.LacklusterFunctionLibrary.NativeApplyChromeToActor"));

	LacklusterFunctionLibrary_NativeApplyChromeToActor_Params params;
	params.Actor_69 = Actor_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (ActorType_69 != nullptr)
		*ActorType_69 = params.ActorType_69;
	if (ChromeType_69 != nullptr)
		*ChromeType_69 = params.ChromeType_69;
	if (ChromeMaterialData_69 != nullptr)
		*ChromeMaterialData_69 = params.ChromeMaterialData_69;
	if (OriginalMaterialData_69 != nullptr)
		*OriginalMaterialData_69 = params.OriginalMaterialData_69;
	if (ContainerMatScalarParamMap_69 != nullptr)
		*ContainerMatScalarParamMap_69 = params.ContainerMatScalarParamMap_69;
	if (ContainerMatVectorParamMap_69 != nullptr)
		*ContainerMatVectorParamMap_69 = params.ContainerMatVectorParamMap_69;
}


// Function ChromeSharedRuntime.LacklusterFunctionLibrary.NativeApplyChromeMaterial
// (Final, Native, Static, Public, HasOutParms, BlueprintCallable)
// Parameters:
// class Actor_32759*             Actor_69                       (Parm, ZeroConstructor)
// TArray<struct FLacklusterMaterialData> ChromeMaterialStructs_69       (Parm, OutParm, ZeroConstructor, ReferenceParm)
// TArray<struct FLacklusterOriginalMaterialData> OriginalMaterialStructs_69     (Parm, OutParm, ZeroConstructor, ReferenceParm)
// ELacklusterChromeType          ChromeType_69                  (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// ELacklusterActorType           OverrideActorType_69           (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void LacklusterFunctionLibrary::STATIC_NativeApplyChromeMaterial(class Actor_32759* Actor_69, ELacklusterChromeType ChromeType_69, ELacklusterActorType OverrideActorType_69, TArray<struct FLacklusterMaterialData>* ChromeMaterialStructs_69, TArray<struct FLacklusterOriginalMaterialData>* OriginalMaterialStructs_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ChromeSharedRuntime.LacklusterFunctionLibrary.NativeApplyChromeMaterial"));

	LacklusterFunctionLibrary_NativeApplyChromeMaterial_Params params;
	params.Actor_69 = Actor_69;
	params.ChromeType_69 = ChromeType_69;
	params.OverrideActorType_69 = OverrideActorType_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (ChromeMaterialStructs_69 != nullptr)
		*ChromeMaterialStructs_69 = params.ChromeMaterialStructs_69;
	if (OriginalMaterialStructs_69 != nullptr)
		*OriginalMaterialStructs_69 = params.OriginalMaterialStructs_69;
}


// Function ChromeSharedRuntime.LacklusterFunctionLibrary.NativeAddTextureData
// (Final, Native, Static, Public, HasOutParms, BlueprintCallable)
// Parameters:
// ELacklusterActorType           ActorType_69                   (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// class Actor_32759*             Actor_69                       (Parm, ZeroConstructor)
// TArray<struct FLacklusterMaterialData> ChromeMaterialStructs_69       (Parm, OutParm, ZeroConstructor)
// TArray<struct FLacklusterOriginalMaterialData> OriginalMaterialStructs_69     (Parm, OutParm, ZeroConstructor)
// int                            MaterialIndex_69               (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// class MaterialInterface*       Material_69                    (Parm, ZeroConstructor)
// class MeshComponent*           MeshComponent_69               (Parm, ZeroConstructor, InstancedReference)

void LacklusterFunctionLibrary::STATIC_NativeAddTextureData(ELacklusterActorType ActorType_69, class Actor_32759* Actor_69, int MaterialIndex_69, class MaterialInterface* Material_69, class MeshComponent* MeshComponent_69, TArray<struct FLacklusterMaterialData>* ChromeMaterialStructs_69, TArray<struct FLacklusterOriginalMaterialData>* OriginalMaterialStructs_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ChromeSharedRuntime.LacklusterFunctionLibrary.NativeAddTextureData"));

	LacklusterFunctionLibrary_NativeAddTextureData_Params params;
	params.ActorType_69 = ActorType_69;
	params.Actor_69 = Actor_69;
	params.MaterialIndex_69 = MaterialIndex_69;
	params.Material_69 = Material_69;
	params.MeshComponent_69 = MeshComponent_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (ChromeMaterialStructs_69 != nullptr)
		*ChromeMaterialStructs_69 = params.ChromeMaterialStructs_69;
	if (OriginalMaterialStructs_69 != nullptr)
		*OriginalMaterialStructs_69 = params.OriginalMaterialStructs_69;
}


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

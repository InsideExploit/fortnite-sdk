#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Classes
//---------------------------------------------------------------------------

// Class CRD_GameStreamRuntime.CreativeGameStreamDeviceComponent
// 0x0010 (0x00B0 - 0x00A0)
class CreativeGameStreamDeviceComponent : public ActorComponent
{
public:
	unsigned char                                      UnknownData00[0x1];                                       // 0x00A0(0x0001) UNKNOWN PROPERTY: MulticastSparseDelegateProperty CRD_GameStreamRuntime.CreativeGameStreamDeviceComponent.OnTriggered_69
	unsigned char                                      UnknownData01[0x3];                                       // 0x00A1(0x0003) MISSED OFFSET
	TWeakObjectPtr<class FortMinigameLogicComponent>   MinigameLogicComponent_69;                                // 0x00A4(0x0008) (ExportObject, ZeroConstructor, Transient, InstancedReference, IsPlainOldData)
	unsigned char                                      UnknownData02[0x4];                                       // 0x00AC(0x0004) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CRD_GameStreamRuntime.CreativeGameStreamDeviceComponent"));
		
		return ptr;
	}


	void RemoveFromEndGameQueue();
	void OnMinigameStateChanged(class FortMinigame* Minigame_69, EFortMinigameState NewMinigameState_69);
	bool IsWithinPublishedPlayspace();
	void Init(class FortMinigameLogicComponent* InMinigameLogicComponent_69);
	void CreativeGameStreamDeviceComponentSignature__DelegateSignature(class CreativeGameStreamDeviceComponent* CreativeGameStreamDeviceComponent_69);
	void AddToEndGameQueue();
};


// Class CRD_GameStreamRuntime.CreativeGameStreamDeviceCoordinatorComponent
// 0x0018 (0x00B8 - 0x00A0)
class CreativeGameStreamDeviceCoordinatorComponent : public PlayspaceComponent
{
public:
	TArray<TWeakObjectPtr<class CreativeGameStreamDeviceComponent>> EndGameCreativeGameStreamDeviceComponentQueue_69;         // 0x00A0(0x0010) (ExportObject, ZeroConstructor, Transient)
	TWeakObjectPtr<class FortMinigame>                 Minigame_69;                                              // 0x00B0(0x0008) (ZeroConstructor, Transient, IsPlainOldData)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CRD_GameStreamRuntime.CreativeGameStreamDeviceCoordinatorComponent"));
		
		return ptr;
	}


	void OnMinigameStateChanged(class FortMinigame* InMinigame_69, EFortMinigameState NewMinigameState_69);
};


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

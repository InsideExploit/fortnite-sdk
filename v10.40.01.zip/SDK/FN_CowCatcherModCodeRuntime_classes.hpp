#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Classes
//---------------------------------------------------------------------------

// Class CowCatcherModCodeRuntime.CowCatcherBarricadeBase
// 0x0008 (0x09D0 - 0x09C8)
class CowCatcherBarricadeBase : public BuildingGameplayActor
{
public:
	unsigned char                                      UnknownData00[0x8];                                       // 0x09C8(0x0008) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CowCatcherModCodeRuntime.CowCatcherBarricadeBase"));
		
		return ptr;
	}


	void OnPlacementBlockedByPawnChanged(bool bBlockedByPawn_69);
	void BeginCheckingForTouchingPawns();
};


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

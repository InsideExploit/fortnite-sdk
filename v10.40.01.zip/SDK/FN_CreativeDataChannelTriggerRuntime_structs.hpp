#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Script Structs
//---------------------------------------------------------------------------

// ScriptStruct CreativeDataChannelTriggerRuntime.CreativeDataChannelEvent
// 0x000C
struct FCreativeDataChannelEvent
{
	struct FName                                       EventName_69;                                             // 0x0000(0x0008) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FName                                       Parameters_69;                                            // 0x0004(0x0008) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FName                                       TriggerCondition_69;                                      // 0x0008(0x0008) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct CreativeDataChannelTriggerRuntime.CreativeDataChannelEvents
// 0x0010
struct FCreativeDataChannelEvents
{
	TArray<struct FCreativeDataChannelEvent>           Events_69;                                                // 0x0000(0x0010) (BlueprintVisible, ZeroConstructor)
};

// ScriptStruct CreativeDataChannelTriggerRuntime.CDCInt
// 0x0004
struct FCDCInt
{
	int                                                Data_69;                                                  // 0x0000(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct CreativeDataChannelTriggerRuntime.CDCLargeInt
// 0x0008
struct FCDCLargeInt
{
	int64_t                                            Data_69;                                                  // 0x0000(0x0008) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct CreativeDataChannelTriggerRuntime.CDCFloatArray
// 0x0010
struct FCDCFloatArray
{
	TArray<float>                                      Data_69;                                                  // 0x0000(0x0010) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
};

// ScriptStruct CreativeDataChannelTriggerRuntime.CDCStringFloatArrayMap
// 0x0050
struct FCDCStringFloatArrayMap
{
	TMap<struct FString, struct FVector>               Data_69;                                                  // 0x0000(0x0050) (BlueprintVisible, BlueprintReadOnly)
};

// ScriptStruct CreativeDataChannelTriggerRuntime.CDCStringStringMap
// 0x00A0
struct FCDCStringStringMap
{
	TMap<struct FString, struct FString>               Data_69;                                                  // 0x0000(0x0050) (BlueprintVisible, BlueprintReadOnly)
	TMap<struct FString, int>                          ExtraData_69;                                             // 0x0050(0x0050) (BlueprintVisible, BlueprintReadOnly)
};

// ScriptStruct CreativeDataChannelTriggerRuntime.CDCStringFloatMap
// 0x0050
struct FCDCStringFloatMap
{
	TMap<struct FString, float>                        Data_69;                                                  // 0x0000(0x0050) (BlueprintVisible, BlueprintReadOnly)
};

// ScriptStruct CreativeDataChannelTriggerRuntime.CDCString
// 0x0010
struct FCDCString
{
	struct FString                                     Data_69;                                                  // 0x0000(0x0010) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
};

// ScriptStruct CreativeDataChannelTriggerRuntime.CDCStringArray
// 0x0018
struct FCDCStringArray
{
	TArray<struct FString>                             Data_69;                                                  // 0x0000(0x0010) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
	int                                                ExtraData_69;                                             // 0x0010(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0014(0x0004) MISSED OFFSET
};

// ScriptStruct CreativeDataChannelTriggerRuntime.CDCStringIntMap
// 0x0050
struct FCDCStringIntMap
{
	TMap<struct FString, int>                          Data_69;                                                  // 0x0000(0x0050) (BlueprintVisible, BlueprintReadOnly)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Classes
//---------------------------------------------------------------------------

// Class DeltaFileSystem.DeltaFileSaveHandlerTestContext
// 0x0008 (0x0030 - 0x0028)
class DeltaFileSaveHandlerTestContext : public Object_32759
{
public:
	class DeltaFileSaveHandler*                        SaveHandler_69;                                           // 0x0028(0x0008) (ZeroConstructor)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class DeltaFileSystem.DeltaFileSaveHandlerTestContext"));
		
		return ptr;
	}

};


// Class DeltaFileSystem.DeltaFile
// 0x0000 (0x0028 - 0x0028)
class DeltaFile : public Interface
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class DeltaFileSystem.DeltaFile"));
		
		return ptr;
	}

};


// Class DeltaFileSystem.DeltaFileApplier
// 0x0000 (0x0028 - 0x0028)
class DeltaFileApplier : public Interface
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class DeltaFileSystem.DeltaFileApplier"));
		
		return ptr;
	}

};


// Class DeltaFileSystem.DeltaComponent
// 0x0010 (0x00B0 - 0x00A0)
class DeltaComponent : public ActorComponent
{
public:
	unsigned char                                      UnknownData00[0x10];                                      // 0x00A0(0x0010) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class DeltaFileSystem.DeltaComponent"));
		
		return ptr;
	}

};


// Class DeltaFileSystem.DeltaFileSaveHandler
// 0x00B0 (0x00D8 - 0x0028)
class DeltaFileSaveHandler : public Object_32759
{
public:
	unsigned char                                      UnknownData00[0xB0];                                      // 0x0028(0x00B0) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class DeltaFileSystem.DeltaFileSaveHandler"));
		
		return ptr;
	}

};


// Class DeltaFileSystem.DeltaFileSubsystem
// 0x00B8 (0x00E8 - 0x0030)
class DeltaFileSubsystem : public EngineSubsystem
{
public:
	TMap<class World*, struct FDeltaTrackingHandles>   WorldToTrackingHandles_69;                                // 0x0030(0x0050) (Transient)
	TMap<struct FName, class Object_32759*>            DeltaFiles_69;                                            // 0x0080(0x0050) (Transient)
	struct FSoftClassPath                              DefaultDeltaFileClass_69;                                 // 0x00D0(0x0018) (ZeroConstructor, Config)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class DeltaFileSystem.DeltaFileSubsystem"));
		
		return ptr;
	}

};


// Class DeltaFileSystem.MapDelta
// 0x00C8 (0x00F0 - 0x0028)
class MapDelta : public Object_32759
{
public:
	unsigned char                                      UnknownData00[0x8];                                       // 0x0028(0x0008) MISSED OFFSET
	struct FString                                     PackageToApplyTo_69;                                      // 0x0030(0x0010) (ZeroConstructor)
	TMap<struct FGuid, struct FAddAction>              AddActions_69;                                            // 0x0040(0x0050)
	TArray<struct FUpdateAction>                       UpdateActions_69;                                         // 0x0090(0x0010) (ZeroConstructor)
	TMap<struct FGuid, struct FDeleteAction>           DeleteActions_69;                                         // 0x00A0(0x0050)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class DeltaFileSystem.MapDelta"));
		
		return ptr;
	}

};


// Class DeltaFileSystem.MapDeltaApplier
// 0x00C8 (0x00F0 - 0x0028)
class MapDeltaApplier : public Object_32759
{
public:
	unsigned char                                      UnknownData00[0xC8];                                      // 0x0028(0x00C8) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class DeltaFileSystem.MapDeltaApplier"));
		
		return ptr;
	}

};


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

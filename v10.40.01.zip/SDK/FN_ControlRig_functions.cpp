// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Functions
//---------------------------------------------------------------------------

// Function ControlRig.ControlRig.SupportsEvent
// (Final, Native, Public, HasOutParms, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FName                   InEventName_69                 (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool ControlRig::SupportsEvent(const struct FName& InEventName_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.ControlRig.SupportsEvent"));

	ControlRig_SupportsEvent_Params params;
	params.InEventName_69 = InEventName_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.ControlRig.SetVariableFromString
// (Final, Native, Public, HasOutParms, BlueprintCallable)
// Parameters:
// struct FName                   InVariableName_69              (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
// struct FString                 InValue_69                     (Parm, ZeroConstructor)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool ControlRig::SetVariableFromString(const struct FName& InVariableName_69, const struct FString& InValue_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.ControlRig.SetVariableFromString"));

	ControlRig_SetVariableFromString_Params params;
	params.InVariableName_69 = InVariableName_69;
	params.InValue_69 = InValue_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.ControlRig.SetInteractionRigClass
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// class ControlRig*              InInteractionRigClass_69       (Parm, ZeroConstructor)

void ControlRig::SetInteractionRigClass(class ControlRig* InInteractionRigClass_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.ControlRig.SetInteractionRigClass"));

	ControlRig_SetInteractionRigClass_Params params;
	params.InInteractionRigClass_69 = InInteractionRigClass_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ControlRig.ControlRig.SetInteractionRig
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// class ControlRig*              InInteractionRig_69            (Parm, ZeroConstructor)

void ControlRig::SetInteractionRig(class ControlRig* InInteractionRig_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.ControlRig.SetInteractionRig"));

	ControlRig_SetInteractionRig_Params params;
	params.InInteractionRig_69 = InInteractionRig_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ControlRig.ControlRig.SetFramesPerSecond
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// float                          InFramesPerSecond_69           (Parm, ZeroConstructor, IsPlainOldData)

void ControlRig::SetFramesPerSecond(float InFramesPerSecond_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.ControlRig.SetFramesPerSecond"));

	ControlRig_SetFramesPerSecond_Params params;
	params.InFramesPerSecond_69 = InFramesPerSecond_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ControlRig.ControlRig.SetDeltaTime
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// float                          InDeltaTime_69                 (Parm, ZeroConstructor, IsPlainOldData)

void ControlRig::SetDeltaTime(float InDeltaTime_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.ControlRig.SetDeltaTime"));

	ControlRig_SetDeltaTime_Params params;
	params.InDeltaTime_69 = InDeltaTime_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ControlRig.ControlRig.SetAbsoluteTime
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// float                          InAbsoluteTime_69              (Parm, ZeroConstructor, IsPlainOldData)
// bool                           InSetDeltaTimeZero_69          (Parm, ZeroConstructor, IsPlainOldData)

void ControlRig::SetAbsoluteTime(float InAbsoluteTime_69, bool InSetDeltaTimeZero_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.ControlRig.SetAbsoluteTime"));

	ControlRig_SetAbsoluteTime_Params params;
	params.InAbsoluteTime_69 = InAbsoluteTime_69;
	params.InSetDeltaTimeZero_69 = InSetDeltaTimeZero_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ControlRig.ControlRig.SetAbsoluteAndDeltaTime
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// float                          InAbsoluteTime_69              (Parm, ZeroConstructor, IsPlainOldData)
// float                          InDeltaTime_69                 (Parm, ZeroConstructor, IsPlainOldData)

void ControlRig::SetAbsoluteAndDeltaTime(float InAbsoluteTime_69, float InDeltaTime_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.ControlRig.SetAbsoluteAndDeltaTime"));

	ControlRig_SetAbsoluteAndDeltaTime_Params params;
	params.InAbsoluteTime_69 = InAbsoluteTime_69;
	params.InDeltaTime_69 = InDeltaTime_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ControlRig.ControlRig.SelectControl
// (Native, Public, HasOutParms, BlueprintCallable)
// Parameters:
// struct FName                   InControlName_69               (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
// bool                           bSelect_69                     (Parm, ZeroConstructor, IsPlainOldData)

void ControlRig::SelectControl(const struct FName& InControlName_69, bool bSelect_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.ControlRig.SelectControl"));

	ControlRig_SelectControl_Params params;
	params.InControlName_69 = InControlName_69;
	params.bSelect_69 = bSelect_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ControlRig.ControlRig.RequestInit
// (Final, Native, Public, BlueprintCallable)

void ControlRig::RequestInit()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.ControlRig.RequestInit"));

	ControlRig_RequestInit_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ControlRig.ControlRig.RequestConstruction
// (Final, Native, Public, BlueprintCallable)

void ControlRig::RequestConstruction()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.ControlRig.RequestConstruction"));

	ControlRig_RequestConstruction_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// SparseDelegateFunction ControlRig.ControlRig.OnControlSelectedBP__DelegateSignature
// (MulticastDelegate, Public, Delegate, HasOutParms)
// Parameters:
// class ControlRig*              Rig_69                         (Parm, ZeroConstructor)
// struct FRigControlElement      Control_69                     (ConstParm, Parm, OutParm, ReferenceParm)
// bool                           bSelected_69                   (Parm, ZeroConstructor, IsPlainOldData)

void ControlRig::OnControlSelectedBP__DelegateSignature(class ControlRig* Rig_69, const struct FRigControlElement& Control_69, bool bSelected_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("SparseDelegateFunction ControlRig.ControlRig.OnControlSelectedBP__DelegateSignature"));

	ControlRig_OnControlSelectedBP__DelegateSignature_Params params;
	params.Rig_69 = Rig_69;
	params.Control_69 = Control_69;
	params.bSelected_69 = bSelected_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ControlRig.ControlRig.IsControlSelected
// (Native, Public, HasOutParms, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FName                   InControlName_69               (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool ControlRig::IsControlSelected(const struct FName& InControlName_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.ControlRig.IsControlSelected"));

	ControlRig_IsControlSelected_Params params;
	params.InControlName_69 = InControlName_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.ControlRig.GetVM
// (Final, Native, Public, BlueprintCallable, BlueprintPure)
// Parameters:
// class RigVM*                   ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

class RigVM* ControlRig::GetVM()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.ControlRig.GetVM"));

	ControlRig_GetVM_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.ControlRig.GetVariableType
// (Final, Native, Public, HasOutParms, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FName                   InVariableName_69              (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
// struct FName                   ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

struct FName ControlRig::GetVariableType(const struct FName& InVariableName_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.ControlRig.GetVariableType"));

	ControlRig_GetVariableType_Params params;
	params.InVariableName_69 = InVariableName_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.ControlRig.GetVariableAsString
// (Final, Native, Public, HasOutParms, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FName                   InVariableName_69              (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
// struct FString                 ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString ControlRig::GetVariableAsString(const struct FName& InVariableName_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.ControlRig.GetVariableAsString"));

	ControlRig_GetVariableAsString_Params params;
	params.InVariableName_69 = InVariableName_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.ControlRig.GetSupportedEvents
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// TArray<struct FName>           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

TArray<struct FName> ControlRig::GetSupportedEvents()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.ControlRig.GetSupportedEvents"));

	ControlRig_GetSupportedEvents_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.ControlRig.GetScriptAccessibleVariables
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// TArray<struct FName>           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

TArray<struct FName> ControlRig::GetScriptAccessibleVariables()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.ControlRig.GetScriptAccessibleVariables"));

	ControlRig_GetScriptAccessibleVariables_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.ControlRig.GetInteractionRigClass
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// class ControlRig*              ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

class ControlRig* ControlRig::GetInteractionRigClass()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.ControlRig.GetInteractionRigClass"));

	ControlRig_GetInteractionRigClass_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.ControlRig.GetInteractionRig
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// class ControlRig*              ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

class ControlRig* ControlRig::GetInteractionRig()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.ControlRig.GetInteractionRig"));

	ControlRig_GetInteractionRig_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.ControlRig.GetHostingActor
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// class Actor_32759*             ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

class Actor_32759* ControlRig::GetHostingActor()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.ControlRig.GetHostingActor"));

	ControlRig_GetHostingActor_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.ControlRig.GetHierarchy
// (Final, Native, Public, BlueprintCallable, BlueprintPure)
// Parameters:
// class RigHierarchy*            ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

class RigHierarchy* ControlRig::GetHierarchy()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.ControlRig.GetHierarchy"));

	ControlRig_GetHierarchy_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.ControlRig.GetEvents
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// TArray<struct FName>           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

TArray<struct FName> ControlRig::GetEvents()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.ControlRig.GetEvents"));

	ControlRig_GetEvents_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.ControlRig.GetCurrentFramesPerSecond
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// float                          ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

float ControlRig::GetCurrentFramesPerSecond()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.ControlRig.GetCurrentFramesPerSecond"));

	ControlRig_GetCurrentFramesPerSecond_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.ControlRig.GetAbsoluteTime
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// float                          ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

float ControlRig::GetAbsoluteTime()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.ControlRig.GetAbsoluteTime"));

	ControlRig_GetAbsoluteTime_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.ControlRig.FindControlRigs
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// class Object_32759*            Outer_69                       (Parm, ZeroConstructor)
// class ControlRig*              OptionalClass_69               (Parm, ZeroConstructor)
// TArray<class ControlRig*>      ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

TArray<class ControlRig*> ControlRig::STATIC_FindControlRigs(class Object_32759* Outer_69, class ControlRig* OptionalClass_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.ControlRig.FindControlRigs"));

	ControlRig_FindControlRigs_Params params;
	params.Outer_69 = Outer_69;
	params.OptionalClass_69 = OptionalClass_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.ControlRig.ExecuteEvent
// (Final, Native, Public, HasOutParms, BlueprintCallable)
// Parameters:
// struct FName                   InEventName_69                 (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool ControlRig::ExecuteEvent(const struct FName& InEventName_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.ControlRig.ExecuteEvent"));

	ControlRig_ExecuteEvent_Params params;
	params.InEventName_69 = InEventName_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.ControlRig.Execute
// (Final, Native, Public, HasOutParms, BlueprintCallable)
// Parameters:
// EControlRigState               State_69                       (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// struct FName                   InEventName_69                 (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool ControlRig::Execute(EControlRigState State_69, const struct FName& InEventName_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.ControlRig.Execute"));

	ControlRig_Execute_Params params;
	params.State_69 = State_69;
	params.InEventName_69 = InEventName_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.ControlRig.CurrentControlSelection
// (Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// TArray<struct FName>           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

TArray<struct FName> ControlRig::CurrentControlSelection()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.ControlRig.CurrentControlSelection"));

	ControlRig_CurrentControlSelection_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.ControlRig.CreateTransformableControlHandle
// (Final, Native, Public, HasOutParms, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// class Object_32759*            Outer_69                       (Parm, ZeroConstructor)
// struct FName                   ControlName_69                 (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
// class TransformableControlHandle_32759* ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

class TransformableControlHandle_32759* ControlRig::CreateTransformableControlHandle(class Object_32759* Outer_69, const struct FName& ControlName_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.ControlRig.CreateTransformableControlHandle"));

	ControlRig_CreateTransformableControlHandle_Params params;
	params.Outer_69 = Outer_69;
	params.ControlName_69 = ControlName_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.ControlRig.ContainsEvent
// (Final, Native, Public, HasOutParms, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FName                   InEventName_69                 (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool ControlRig::ContainsEvent(const struct FName& InEventName_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.ControlRig.ContainsEvent"));

	ControlRig_ContainsEvent_Params params;
	params.InEventName_69 = InEventName_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.ControlRig.ClearControlSelection
// (Native, Public, BlueprintCallable)
// Parameters:
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool ControlRig::ClearControlSelection()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.ControlRig.ClearControlSelection"));

	ControlRig_ClearControlSelection_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.ControlRig.CanExecute
// (Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool ControlRig::CanExecute()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.ControlRig.CanExecute"));

	ControlRig_CanExecute_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.RigHierarchy.UnsetCurveValueByIndex
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// int                            InElementIndex_69              (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bSetupUndo_69                  (Parm, ZeroConstructor, IsPlainOldData)

void RigHierarchy::UnsetCurveValueByIndex(int InElementIndex_69, bool bSetupUndo_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchy.UnsetCurveValueByIndex"));

	RigHierarchy_UnsetCurveValueByIndex_Params params;
	params.InElementIndex_69 = InElementIndex_69;
	params.bSetupUndo_69 = bSetupUndo_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ControlRig.RigHierarchy.UnsetCurveValue
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// struct FRigElementKey          InKey_69                       (Parm)
// bool                           bSetupUndo_69                  (Parm, ZeroConstructor, IsPlainOldData)

void RigHierarchy::UnsetCurveValue(const struct FRigElementKey& InKey_69, bool bSetupUndo_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchy.UnsetCurveValue"));

	RigHierarchy_UnsetCurveValue_Params params;
	params.InKey_69 = InKey_69;
	params.bSetupUndo_69 = bSetupUndo_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ControlRig.RigHierarchy.SwitchToWorldSpace
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// struct FRigElementKey          InChild_69                     (Parm)
// bool                           bInitial_69                    (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bAffectChildren_69             (Parm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool RigHierarchy::SwitchToWorldSpace(const struct FRigElementKey& InChild_69, bool bInitial_69, bool bAffectChildren_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchy.SwitchToWorldSpace"));

	RigHierarchy_SwitchToWorldSpace_Params params;
	params.InChild_69 = InChild_69;
	params.bInitial_69 = bInitial_69;
	params.bAffectChildren_69 = bAffectChildren_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.RigHierarchy.SwitchToParent
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// struct FRigElementKey          InChild_69                     (Parm)
// struct FRigElementKey          InParent_69                    (Parm)
// bool                           bInitial_69                    (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bAffectChildren_69             (Parm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool RigHierarchy::SwitchToParent(const struct FRigElementKey& InChild_69, const struct FRigElementKey& InParent_69, bool bInitial_69, bool bAffectChildren_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchy.SwitchToParent"));

	RigHierarchy_SwitchToParent_Params params;
	params.InChild_69 = InChild_69;
	params.InParent_69 = InParent_69;
	params.bInitial_69 = bInitial_69;
	params.bAffectChildren_69 = bAffectChildren_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.RigHierarchy.SwitchToDefaultParent
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// struct FRigElementKey          InChild_69                     (Parm)
// bool                           bInitial_69                    (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bAffectChildren_69             (Parm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool RigHierarchy::SwitchToDefaultParent(const struct FRigElementKey& InChild_69, bool bInitial_69, bool bAffectChildren_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchy.SwitchToDefaultParent"));

	RigHierarchy_SwitchToDefaultParent_Params params;
	params.InChild_69 = InChild_69;
	params.bInitial_69 = bInitial_69;
	params.bAffectChildren_69 = bAffectChildren_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.RigHierarchy.SortKeys
// (Final, Native, Public, HasOutParms, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// TArray<struct FRigElementKey>  InKeys_69                      (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
// TArray<struct FRigElementKey>  ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

TArray<struct FRigElementKey> RigHierarchy::SortKeys(TArray<struct FRigElementKey> InKeys_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchy.SortKeys"));

	RigHierarchy_SortKeys_Params params;
	params.InKeys_69 = InKeys_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.RigHierarchy.SetVectorMetadata
// (Final, Native, Public, HasDefaults, BlueprintCallable)
// Parameters:
// struct FRigElementKey          InItem_69                      (Parm)
// struct FName                   InMetadataName_69              (Parm, ZeroConstructor, IsPlainOldData)
// struct FVector                 InValue_69                     (Parm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool RigHierarchy::SetVectorMetadata(const struct FRigElementKey& InItem_69, const struct FName& InMetadataName_69, const struct FVector& InValue_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchy.SetVectorMetadata"));

	RigHierarchy_SetVectorMetadata_Params params;
	params.InItem_69 = InItem_69;
	params.InMetadataName_69 = InMetadataName_69;
	params.InValue_69 = InValue_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.RigHierarchy.SetVectorArrayMetadata
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// struct FRigElementKey          InItem_69                      (Parm)
// struct FName                   InMetadataName_69              (Parm, ZeroConstructor, IsPlainOldData)
// TArray<struct FVector>         InValue_69                     (Parm, ZeroConstructor)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool RigHierarchy::SetVectorArrayMetadata(const struct FRigElementKey& InItem_69, const struct FName& InMetadataName_69, TArray<struct FVector> InValue_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchy.SetVectorArrayMetadata"));

	RigHierarchy_SetVectorArrayMetadata_Params params;
	params.InItem_69 = InItem_69;
	params.InMetadataName_69 = InMetadataName_69;
	params.InValue_69 = InValue_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.RigHierarchy.SetTransformMetadata
// (Final, Native, Public, HasDefaults, BlueprintCallable)
// Parameters:
// struct FRigElementKey          InItem_69                      (Parm)
// struct FName                   InMetadataName_69              (Parm, ZeroConstructor, IsPlainOldData)
// struct FCoreUObject_FTransform InValue_69                     (Parm, IsPlainOldData)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool RigHierarchy::SetTransformMetadata(const struct FRigElementKey& InItem_69, const struct FName& InMetadataName_69, const struct FCoreUObject_FTransform& InValue_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchy.SetTransformMetadata"));

	RigHierarchy_SetTransformMetadata_Params params;
	params.InItem_69 = InItem_69;
	params.InMetadataName_69 = InMetadataName_69;
	params.InValue_69 = InValue_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.RigHierarchy.SetTransformArrayMetadata
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// struct FRigElementKey          InItem_69                      (Parm)
// struct FName                   InMetadataName_69              (Parm, ZeroConstructor, IsPlainOldData)
// TArray<struct FCoreUObject_FTransform> InValue_69                     (Parm, ZeroConstructor)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool RigHierarchy::SetTransformArrayMetadata(const struct FRigElementKey& InItem_69, const struct FName& InMetadataName_69, TArray<struct FCoreUObject_FTransform> InValue_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchy.SetTransformArrayMetadata"));

	RigHierarchy_SetTransformArrayMetadata_Params params;
	params.InItem_69 = InItem_69;
	params.InMetadataName_69 = InMetadataName_69;
	params.InValue_69 = InValue_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.RigHierarchy.SetTag
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// struct FRigElementKey          InItem_69                      (Parm)
// struct FName                   InTag_69                       (Parm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool RigHierarchy::SetTag(const struct FRigElementKey& InItem_69, const struct FName& InTag_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchy.SetTag"));

	RigHierarchy_SetTag_Params params;
	params.InItem_69 = InItem_69;
	params.InTag_69 = InTag_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.RigHierarchy.SetRotatorMetadata
// (Final, Native, Public, HasDefaults, BlueprintCallable)
// Parameters:
// struct FRigElementKey          InItem_69                      (Parm)
// struct FName                   InMetadataName_69              (Parm, ZeroConstructor, IsPlainOldData)
// struct FRotator                InValue_69                     (Parm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool RigHierarchy::SetRotatorMetadata(const struct FRigElementKey& InItem_69, const struct FName& InMetadataName_69, const struct FRotator& InValue_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchy.SetRotatorMetadata"));

	RigHierarchy_SetRotatorMetadata_Params params;
	params.InItem_69 = InItem_69;
	params.InMetadataName_69 = InMetadataName_69;
	params.InValue_69 = InValue_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.RigHierarchy.SetRotatorArrayMetadata
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// struct FRigElementKey          InItem_69                      (Parm)
// struct FName                   InMetadataName_69              (Parm, ZeroConstructor, IsPlainOldData)
// TArray<struct FRotator>        InValue_69                     (Parm, ZeroConstructor)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool RigHierarchy::SetRotatorArrayMetadata(const struct FRigElementKey& InItem_69, const struct FName& InMetadataName_69, TArray<struct FRotator> InValue_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchy.SetRotatorArrayMetadata"));

	RigHierarchy_SetRotatorArrayMetadata_Params params;
	params.InItem_69 = InItem_69;
	params.InMetadataName_69 = InMetadataName_69;
	params.InValue_69 = InValue_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.RigHierarchy.SetRigElementKeyMetadata
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// struct FRigElementKey          InItem_69                      (Parm)
// struct FName                   InMetadataName_69              (Parm, ZeroConstructor, IsPlainOldData)
// struct FRigElementKey          InValue_69                     (Parm)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool RigHierarchy::SetRigElementKeyMetadata(const struct FRigElementKey& InItem_69, const struct FName& InMetadataName_69, const struct FRigElementKey& InValue_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchy.SetRigElementKeyMetadata"));

	RigHierarchy_SetRigElementKeyMetadata_Params params;
	params.InItem_69 = InItem_69;
	params.InMetadataName_69 = InMetadataName_69;
	params.InValue_69 = InValue_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.RigHierarchy.SetRigElementKeyArrayMetadata
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// struct FRigElementKey          InItem_69                      (Parm)
// struct FName                   InMetadataName_69              (Parm, ZeroConstructor, IsPlainOldData)
// TArray<struct FRigElementKey>  InValue_69                     (Parm, ZeroConstructor)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool RigHierarchy::SetRigElementKeyArrayMetadata(const struct FRigElementKey& InItem_69, const struct FName& InMetadataName_69, TArray<struct FRigElementKey> InValue_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchy.SetRigElementKeyArrayMetadata"));

	RigHierarchy_SetRigElementKeyArrayMetadata_Params params;
	params.InItem_69 = InItem_69;
	params.InMetadataName_69 = InMetadataName_69;
	params.InValue_69 = InValue_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.RigHierarchy.SetQuatMetadata
// (Final, Native, Public, HasDefaults, BlueprintCallable)
// Parameters:
// struct FRigElementKey          InItem_69                      (Parm)
// struct FName                   InMetadataName_69              (Parm, ZeroConstructor, IsPlainOldData)
// struct FQuat                   InValue_69                     (Parm, IsPlainOldData)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool RigHierarchy::SetQuatMetadata(const struct FRigElementKey& InItem_69, const struct FName& InMetadataName_69, const struct FQuat& InValue_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchy.SetQuatMetadata"));

	RigHierarchy_SetQuatMetadata_Params params;
	params.InItem_69 = InItem_69;
	params.InMetadataName_69 = InMetadataName_69;
	params.InValue_69 = InValue_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.RigHierarchy.SetQuatArrayMetadata
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// struct FRigElementKey          InItem_69                      (Parm)
// struct FName                   InMetadataName_69              (Parm, ZeroConstructor, IsPlainOldData)
// TArray<struct FQuat>           InValue_69                     (Parm, ZeroConstructor)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool RigHierarchy::SetQuatArrayMetadata(const struct FRigElementKey& InItem_69, const struct FName& InMetadataName_69, TArray<struct FQuat> InValue_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchy.SetQuatArrayMetadata"));

	RigHierarchy_SetQuatArrayMetadata_Params params;
	params.InItem_69 = InItem_69;
	params.InMetadataName_69 = InMetadataName_69;
	params.InValue_69 = InValue_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.RigHierarchy.SetPose_ForBlueprint
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// struct FRigPose                InPose_69                      (Parm)

void RigHierarchy::SetPose_ForBlueprint(const struct FRigPose& InPose_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchy.SetPose_ForBlueprint"));

	RigHierarchy_SetPose_ForBlueprint_Params params;
	params.InPose_69 = InPose_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ControlRig.RigHierarchy.SetParentWeightArray
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// struct FRigElementKey          InChild_69                     (Parm)
// TArray<struct FRigElementWeight> InWeights_69                   (Parm, ZeroConstructor)
// bool                           bInitial_69                    (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bAffectChildren_69             (Parm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool RigHierarchy::SetParentWeightArray(const struct FRigElementKey& InChild_69, TArray<struct FRigElementWeight> InWeights_69, bool bInitial_69, bool bAffectChildren_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchy.SetParentWeightArray"));

	RigHierarchy_SetParentWeightArray_Params params;
	params.InChild_69 = InChild_69;
	params.InWeights_69 = InWeights_69;
	params.bInitial_69 = bInitial_69;
	params.bAffectChildren_69 = bAffectChildren_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.RigHierarchy.SetParentWeight
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// struct FRigElementKey          InChild_69                     (Parm)
// struct FRigElementKey          InParent_69                    (Parm)
// struct FRigElementWeight       InWeight_69                    (Parm)
// bool                           bInitial_69                    (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bAffectChildren_69             (Parm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool RigHierarchy::SetParentWeight(const struct FRigElementKey& InChild_69, const struct FRigElementKey& InParent_69, const struct FRigElementWeight& InWeight_69, bool bInitial_69, bool bAffectChildren_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchy.SetParentWeight"));

	RigHierarchy_SetParentWeight_Params params;
	params.InChild_69 = InChild_69;
	params.InParent_69 = InParent_69;
	params.InWeight_69 = InWeight_69;
	params.bInitial_69 = bInitial_69;
	params.bAffectChildren_69 = bAffectChildren_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.RigHierarchy.SetNameMetadata
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// struct FRigElementKey          InItem_69                      (Parm)
// struct FName                   InMetadataName_69              (Parm, ZeroConstructor, IsPlainOldData)
// struct FName                   InValue_69                     (Parm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool RigHierarchy::SetNameMetadata(const struct FRigElementKey& InItem_69, const struct FName& InMetadataName_69, const struct FName& InValue_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchy.SetNameMetadata"));

	RigHierarchy_SetNameMetadata_Params params;
	params.InItem_69 = InItem_69;
	params.InMetadataName_69 = InMetadataName_69;
	params.InValue_69 = InValue_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.RigHierarchy.SetNameArrayMetadata
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// struct FRigElementKey          InItem_69                      (Parm)
// struct FName                   InMetadataName_69              (Parm, ZeroConstructor, IsPlainOldData)
// TArray<struct FName>           InValue_69                     (Parm, ZeroConstructor)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool RigHierarchy::SetNameArrayMetadata(const struct FRigElementKey& InItem_69, const struct FName& InMetadataName_69, TArray<struct FName> InValue_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchy.SetNameArrayMetadata"));

	RigHierarchy_SetNameArrayMetadata_Params params;
	params.InItem_69 = InItem_69;
	params.InMetadataName_69 = InMetadataName_69;
	params.InValue_69 = InValue_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.RigHierarchy.SetLocalTransformByIndex
// (Final, Native, Public, HasDefaults, BlueprintCallable)
// Parameters:
// int                            InElementIndex_69              (Parm, ZeroConstructor, IsPlainOldData)
// struct FCoreUObject_FTransform InTransform_69                 (Parm, IsPlainOldData)
// bool                           bInitial_69                    (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bAffectChildren_69             (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bSetupUndo_69                  (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bPrintPythonCommands_69        (Parm, ZeroConstructor, IsPlainOldData)

void RigHierarchy::SetLocalTransformByIndex(int InElementIndex_69, const struct FCoreUObject_FTransform& InTransform_69, bool bInitial_69, bool bAffectChildren_69, bool bSetupUndo_69, bool bPrintPythonCommands_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchy.SetLocalTransformByIndex"));

	RigHierarchy_SetLocalTransformByIndex_Params params;
	params.InElementIndex_69 = InElementIndex_69;
	params.InTransform_69 = InTransform_69;
	params.bInitial_69 = bInitial_69;
	params.bAffectChildren_69 = bAffectChildren_69;
	params.bSetupUndo_69 = bSetupUndo_69;
	params.bPrintPythonCommands_69 = bPrintPythonCommands_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ControlRig.RigHierarchy.SetLocalTransform
// (Final, Native, Public, HasDefaults, BlueprintCallable)
// Parameters:
// struct FRigElementKey          InKey_69                       (Parm)
// struct FCoreUObject_FTransform InTransform_69                 (Parm, IsPlainOldData)
// bool                           bInitial_69                    (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bAffectChildren_69             (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bSetupUndo_69                  (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bPrintPythonCommands_69        (Parm, ZeroConstructor, IsPlainOldData)

void RigHierarchy::SetLocalTransform(const struct FRigElementKey& InKey_69, const struct FCoreUObject_FTransform& InTransform_69, bool bInitial_69, bool bAffectChildren_69, bool bSetupUndo_69, bool bPrintPythonCommands_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchy.SetLocalTransform"));

	RigHierarchy_SetLocalTransform_Params params;
	params.InKey_69 = InKey_69;
	params.InTransform_69 = InTransform_69;
	params.bInitial_69 = bInitial_69;
	params.bAffectChildren_69 = bAffectChildren_69;
	params.bSetupUndo_69 = bSetupUndo_69;
	params.bPrintPythonCommands_69 = bPrintPythonCommands_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ControlRig.RigHierarchy.SetLinearColorMetadata
// (Final, Native, Public, HasDefaults, BlueprintCallable)
// Parameters:
// struct FRigElementKey          InItem_69                      (Parm)
// struct FName                   InMetadataName_69              (Parm, ZeroConstructor, IsPlainOldData)
// struct FLinearColor            InValue_69                     (Parm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool RigHierarchy::SetLinearColorMetadata(const struct FRigElementKey& InItem_69, const struct FName& InMetadataName_69, const struct FLinearColor& InValue_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchy.SetLinearColorMetadata"));

	RigHierarchy_SetLinearColorMetadata_Params params;
	params.InItem_69 = InItem_69;
	params.InMetadataName_69 = InMetadataName_69;
	params.InValue_69 = InValue_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.RigHierarchy.SetLinearColorArrayMetadata
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// struct FRigElementKey          InItem_69                      (Parm)
// struct FName                   InMetadataName_69              (Parm, ZeroConstructor, IsPlainOldData)
// TArray<struct FLinearColor>    InValue_69                     (Parm, ZeroConstructor)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool RigHierarchy::SetLinearColorArrayMetadata(const struct FRigElementKey& InItem_69, const struct FName& InMetadataName_69, TArray<struct FLinearColor> InValue_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchy.SetLinearColorArrayMetadata"));

	RigHierarchy_SetLinearColorArrayMetadata_Params params;
	params.InItem_69 = InItem_69;
	params.InMetadataName_69 = InMetadataName_69;
	params.InValue_69 = InValue_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.RigHierarchy.SetInt32Metadata
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// struct FRigElementKey          InItem_69                      (Parm)
// struct FName                   InMetadataName_69              (Parm, ZeroConstructor, IsPlainOldData)
// int                            InValue_69                     (Parm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool RigHierarchy::SetInt32Metadata(const struct FRigElementKey& InItem_69, const struct FName& InMetadataName_69, int InValue_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchy.SetInt32Metadata"));

	RigHierarchy_SetInt32Metadata_Params params;
	params.InItem_69 = InItem_69;
	params.InMetadataName_69 = InMetadataName_69;
	params.InValue_69 = InValue_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.RigHierarchy.SetInt32ArrayMetadata
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// struct FRigElementKey          InItem_69                      (Parm)
// struct FName                   InMetadataName_69              (Parm, ZeroConstructor, IsPlainOldData)
// TArray<int>                    InValue_69                     (Parm, ZeroConstructor)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool RigHierarchy::SetInt32ArrayMetadata(const struct FRigElementKey& InItem_69, const struct FName& InMetadataName_69, TArray<int> InValue_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchy.SetInt32ArrayMetadata"));

	RigHierarchy_SetInt32ArrayMetadata_Params params;
	params.InItem_69 = InItem_69;
	params.InMetadataName_69 = InMetadataName_69;
	params.InValue_69 = InValue_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.RigHierarchy.SetGlobalTransformByIndex
// (Final, Native, Public, HasDefaults, BlueprintCallable)
// Parameters:
// int                            InElementIndex_69              (Parm, ZeroConstructor, IsPlainOldData)
// struct FCoreUObject_FTransform InTransform_69                 (Parm, IsPlainOldData)
// bool                           bInitial_69                    (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bAffectChildren_69             (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bSetupUndo_69                  (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bPrintPythonCommand_69         (Parm, ZeroConstructor, IsPlainOldData)

void RigHierarchy::SetGlobalTransformByIndex(int InElementIndex_69, const struct FCoreUObject_FTransform& InTransform_69, bool bInitial_69, bool bAffectChildren_69, bool bSetupUndo_69, bool bPrintPythonCommand_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchy.SetGlobalTransformByIndex"));

	RigHierarchy_SetGlobalTransformByIndex_Params params;
	params.InElementIndex_69 = InElementIndex_69;
	params.InTransform_69 = InTransform_69;
	params.bInitial_69 = bInitial_69;
	params.bAffectChildren_69 = bAffectChildren_69;
	params.bSetupUndo_69 = bSetupUndo_69;
	params.bPrintPythonCommand_69 = bPrintPythonCommand_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ControlRig.RigHierarchy.SetGlobalTransform
// (Final, Native, Public, HasDefaults, BlueprintCallable)
// Parameters:
// struct FRigElementKey          InKey_69                       (Parm)
// struct FCoreUObject_FTransform InTransform_69                 (Parm, IsPlainOldData)
// bool                           bInitial_69                    (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bAffectChildren_69             (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bSetupUndo_69                  (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bPrintPythonCommand_69         (Parm, ZeroConstructor, IsPlainOldData)

void RigHierarchy::SetGlobalTransform(const struct FRigElementKey& InKey_69, const struct FCoreUObject_FTransform& InTransform_69, bool bInitial_69, bool bAffectChildren_69, bool bSetupUndo_69, bool bPrintPythonCommand_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchy.SetGlobalTransform"));

	RigHierarchy_SetGlobalTransform_Params params;
	params.InKey_69 = InKey_69;
	params.InTransform_69 = InTransform_69;
	params.bInitial_69 = bInitial_69;
	params.bAffectChildren_69 = bAffectChildren_69;
	params.bSetupUndo_69 = bSetupUndo_69;
	params.bPrintPythonCommand_69 = bPrintPythonCommand_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ControlRig.RigHierarchy.SetFloatMetadata
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// struct FRigElementKey          InItem_69                      (Parm)
// struct FName                   InMetadataName_69              (Parm, ZeroConstructor, IsPlainOldData)
// float                          InValue_69                     (Parm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool RigHierarchy::SetFloatMetadata(const struct FRigElementKey& InItem_69, const struct FName& InMetadataName_69, float InValue_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchy.SetFloatMetadata"));

	RigHierarchy_SetFloatMetadata_Params params;
	params.InItem_69 = InItem_69;
	params.InMetadataName_69 = InMetadataName_69;
	params.InValue_69 = InValue_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.RigHierarchy.SetFloatArrayMetadata
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// struct FRigElementKey          InItem_69                      (Parm)
// struct FName                   InMetadataName_69              (Parm, ZeroConstructor, IsPlainOldData)
// TArray<float>                  InValue_69                     (Parm, ZeroConstructor)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool RigHierarchy::SetFloatArrayMetadata(const struct FRigElementKey& InItem_69, const struct FName& InMetadataName_69, TArray<float> InValue_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchy.SetFloatArrayMetadata"));

	RigHierarchy_SetFloatArrayMetadata_Params params;
	params.InItem_69 = InItem_69;
	params.InMetadataName_69 = InMetadataName_69;
	params.InValue_69 = InValue_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.RigHierarchy.SetCurveValueByIndex
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// int                            InElementIndex_69              (Parm, ZeroConstructor, IsPlainOldData)
// float                          InValue_69                     (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bSetupUndo_69                  (Parm, ZeroConstructor, IsPlainOldData)

void RigHierarchy::SetCurveValueByIndex(int InElementIndex_69, float InValue_69, bool bSetupUndo_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchy.SetCurveValueByIndex"));

	RigHierarchy_SetCurveValueByIndex_Params params;
	params.InElementIndex_69 = InElementIndex_69;
	params.InValue_69 = InValue_69;
	params.bSetupUndo_69 = bSetupUndo_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ControlRig.RigHierarchy.SetCurveValue
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// struct FRigElementKey          InKey_69                       (Parm)
// float                          InValue_69                     (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bSetupUndo_69                  (Parm, ZeroConstructor, IsPlainOldData)

void RigHierarchy::SetCurveValue(const struct FRigElementKey& InKey_69, float InValue_69, bool bSetupUndo_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchy.SetCurveValue"));

	RigHierarchy_SetCurveValue_Params params;
	params.InKey_69 = InKey_69;
	params.InValue_69 = InValue_69;
	params.bSetupUndo_69 = bSetupUndo_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ControlRig.RigHierarchy.SetControlVisibilityByIndex
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// int                            InElementIndex_69              (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bVisibility_69                 (Parm, ZeroConstructor, IsPlainOldData)

void RigHierarchy::SetControlVisibilityByIndex(int InElementIndex_69, bool bVisibility_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchy.SetControlVisibilityByIndex"));

	RigHierarchy_SetControlVisibilityByIndex_Params params;
	params.InElementIndex_69 = InElementIndex_69;
	params.bVisibility_69 = bVisibility_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ControlRig.RigHierarchy.SetControlVisibility
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// struct FRigElementKey          InKey_69                       (Parm)
// bool                           bVisibility_69                 (Parm, ZeroConstructor, IsPlainOldData)

void RigHierarchy::SetControlVisibility(const struct FRigElementKey& InKey_69, bool bVisibility_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchy.SetControlVisibility"));

	RigHierarchy_SetControlVisibility_Params params;
	params.InKey_69 = InKey_69;
	params.bVisibility_69 = bVisibility_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ControlRig.RigHierarchy.SetControlValueByIndex
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// int                            InElementIndex_69              (Parm, ZeroConstructor, IsPlainOldData)
// struct FRigControlValue        InValue_69                     (Parm)
// ERigControlValueType           InValueType_69                 (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bSetupUndo_69                  (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bPrintPythonCommands_69        (Parm, ZeroConstructor, IsPlainOldData)

void RigHierarchy::SetControlValueByIndex(int InElementIndex_69, const struct FRigControlValue& InValue_69, ERigControlValueType InValueType_69, bool bSetupUndo_69, bool bPrintPythonCommands_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchy.SetControlValueByIndex"));

	RigHierarchy_SetControlValueByIndex_Params params;
	params.InElementIndex_69 = InElementIndex_69;
	params.InValue_69 = InValue_69;
	params.InValueType_69 = InValueType_69;
	params.bSetupUndo_69 = bSetupUndo_69;
	params.bPrintPythonCommands_69 = bPrintPythonCommands_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ControlRig.RigHierarchy.SetControlValue
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// struct FRigElementKey          InKey_69                       (Parm)
// struct FRigControlValue        InValue_69                     (Parm)
// ERigControlValueType           InValueType_69                 (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bSetupUndo_69                  (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bPrintPythonCommands_69        (Parm, ZeroConstructor, IsPlainOldData)

void RigHierarchy::SetControlValue(const struct FRigElementKey& InKey_69, const struct FRigControlValue& InValue_69, ERigControlValueType InValueType_69, bool bSetupUndo_69, bool bPrintPythonCommands_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchy.SetControlValue"));

	RigHierarchy_SetControlValue_Params params;
	params.InKey_69 = InKey_69;
	params.InValue_69 = InValue_69;
	params.InValueType_69 = InValueType_69;
	params.bSetupUndo_69 = bSetupUndo_69;
	params.bPrintPythonCommands_69 = bPrintPythonCommands_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ControlRig.RigHierarchy.SetControlShapeTransformByIndex
// (Final, Native, Public, HasDefaults, BlueprintCallable)
// Parameters:
// int                            InElementIndex_69              (Parm, ZeroConstructor, IsPlainOldData)
// struct FCoreUObject_FTransform InTransform_69                 (Parm, IsPlainOldData)
// bool                           bInitial_69                    (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bSetupUndo_69                  (Parm, ZeroConstructor, IsPlainOldData)

void RigHierarchy::SetControlShapeTransformByIndex(int InElementIndex_69, const struct FCoreUObject_FTransform& InTransform_69, bool bInitial_69, bool bSetupUndo_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchy.SetControlShapeTransformByIndex"));

	RigHierarchy_SetControlShapeTransformByIndex_Params params;
	params.InElementIndex_69 = InElementIndex_69;
	params.InTransform_69 = InTransform_69;
	params.bInitial_69 = bInitial_69;
	params.bSetupUndo_69 = bSetupUndo_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ControlRig.RigHierarchy.SetControlShapeTransform
// (Final, Native, Public, HasDefaults, BlueprintCallable)
// Parameters:
// struct FRigElementKey          InKey_69                       (Parm)
// struct FCoreUObject_FTransform InTransform_69                 (Parm, IsPlainOldData)
// bool                           bInitial_69                    (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bSetupUndo_69                  (Parm, ZeroConstructor, IsPlainOldData)

void RigHierarchy::SetControlShapeTransform(const struct FRigElementKey& InKey_69, const struct FCoreUObject_FTransform& InTransform_69, bool bInitial_69, bool bSetupUndo_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchy.SetControlShapeTransform"));

	RigHierarchy_SetControlShapeTransform_Params params;
	params.InKey_69 = InKey_69;
	params.InTransform_69 = InTransform_69;
	params.bInitial_69 = bInitial_69;
	params.bSetupUndo_69 = bSetupUndo_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ControlRig.RigHierarchy.SetControlSettingsByIndex
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// int                            InElementIndex_69              (Parm, ZeroConstructor, IsPlainOldData)
// struct FRigControlSettings     InSettings_69                  (Parm)
// bool                           bSetupUndo_69                  (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bForce_69                      (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bPrintPythonCommands_69        (Parm, ZeroConstructor, IsPlainOldData)

void RigHierarchy::SetControlSettingsByIndex(int InElementIndex_69, const struct FRigControlSettings& InSettings_69, bool bSetupUndo_69, bool bForce_69, bool bPrintPythonCommands_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchy.SetControlSettingsByIndex"));

	RigHierarchy_SetControlSettingsByIndex_Params params;
	params.InElementIndex_69 = InElementIndex_69;
	params.InSettings_69 = InSettings_69;
	params.bSetupUndo_69 = bSetupUndo_69;
	params.bForce_69 = bForce_69;
	params.bPrintPythonCommands_69 = bPrintPythonCommands_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ControlRig.RigHierarchy.SetControlSettings
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// struct FRigElementKey          InKey_69                       (Parm)
// struct FRigControlSettings     InSettings_69                  (Parm)
// bool                           bSetupUndo_69                  (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bForce_69                      (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bPrintPythonCommands_69        (Parm, ZeroConstructor, IsPlainOldData)

void RigHierarchy::SetControlSettings(const struct FRigElementKey& InKey_69, const struct FRigControlSettings& InSettings_69, bool bSetupUndo_69, bool bForce_69, bool bPrintPythonCommands_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchy.SetControlSettings"));

	RigHierarchy_SetControlSettings_Params params;
	params.InKey_69 = InKey_69;
	params.InSettings_69 = InSettings_69;
	params.bSetupUndo_69 = bSetupUndo_69;
	params.bForce_69 = bForce_69;
	params.bPrintPythonCommands_69 = bPrintPythonCommands_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ControlRig.RigHierarchy.SetControlPreferredRotatorByIndex
// (Final, Native, Public, HasOutParms, HasDefaults, BlueprintCallable)
// Parameters:
// int                            InElementIndex_69              (Parm, ZeroConstructor, IsPlainOldData)
// struct FRotator                InValue_69                     (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
// bool                           bInitial_69                    (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bFixEulerFlips_69              (Parm, ZeroConstructor, IsPlainOldData)

void RigHierarchy::SetControlPreferredRotatorByIndex(int InElementIndex_69, const struct FRotator& InValue_69, bool bInitial_69, bool bFixEulerFlips_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchy.SetControlPreferredRotatorByIndex"));

	RigHierarchy_SetControlPreferredRotatorByIndex_Params params;
	params.InElementIndex_69 = InElementIndex_69;
	params.InValue_69 = InValue_69;
	params.bInitial_69 = bInitial_69;
	params.bFixEulerFlips_69 = bFixEulerFlips_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ControlRig.RigHierarchy.SetControlPreferredRotator
// (Final, Native, Public, HasOutParms, HasDefaults, BlueprintCallable)
// Parameters:
// struct FRigElementKey          InKey_69                       (Parm)
// struct FRotator                InValue_69                     (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
// bool                           bInitial_69                    (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bFixEulerFlips_69              (Parm, ZeroConstructor, IsPlainOldData)

void RigHierarchy::SetControlPreferredRotator(const struct FRigElementKey& InKey_69, const struct FRotator& InValue_69, bool bInitial_69, bool bFixEulerFlips_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchy.SetControlPreferredRotator"));

	RigHierarchy_SetControlPreferredRotator_Params params;
	params.InKey_69 = InKey_69;
	params.InValue_69 = InValue_69;
	params.bInitial_69 = bInitial_69;
	params.bFixEulerFlips_69 = bFixEulerFlips_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ControlRig.RigHierarchy.SetControlOffsetTransformByIndex
// (Final, Native, Public, HasDefaults, BlueprintCallable)
// Parameters:
// int                            InElementIndex_69              (Parm, ZeroConstructor, IsPlainOldData)
// struct FCoreUObject_FTransform InTransform_69                 (Parm, IsPlainOldData)
// bool                           bInitial_69                    (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bAffectChildren_69             (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bSetupUndo_69                  (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bPrintPythonCommands_69        (Parm, ZeroConstructor, IsPlainOldData)

void RigHierarchy::SetControlOffsetTransformByIndex(int InElementIndex_69, const struct FCoreUObject_FTransform& InTransform_69, bool bInitial_69, bool bAffectChildren_69, bool bSetupUndo_69, bool bPrintPythonCommands_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchy.SetControlOffsetTransformByIndex"));

	RigHierarchy_SetControlOffsetTransformByIndex_Params params;
	params.InElementIndex_69 = InElementIndex_69;
	params.InTransform_69 = InTransform_69;
	params.bInitial_69 = bInitial_69;
	params.bAffectChildren_69 = bAffectChildren_69;
	params.bSetupUndo_69 = bSetupUndo_69;
	params.bPrintPythonCommands_69 = bPrintPythonCommands_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ControlRig.RigHierarchy.SetControlOffsetTransform
// (Final, Native, Public, HasDefaults, BlueprintCallable)
// Parameters:
// struct FRigElementKey          InKey_69                       (Parm)
// struct FCoreUObject_FTransform InTransform_69                 (Parm, IsPlainOldData)
// bool                           bInitial_69                    (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bAffectChildren_69             (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bSetupUndo_69                  (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bPrintPythonCommands_69        (Parm, ZeroConstructor, IsPlainOldData)

void RigHierarchy::SetControlOffsetTransform(const struct FRigElementKey& InKey_69, const struct FCoreUObject_FTransform& InTransform_69, bool bInitial_69, bool bAffectChildren_69, bool bSetupUndo_69, bool bPrintPythonCommands_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchy.SetControlOffsetTransform"));

	RigHierarchy_SetControlOffsetTransform_Params params;
	params.InKey_69 = InKey_69;
	params.InTransform_69 = InTransform_69;
	params.bInitial_69 = bInitial_69;
	params.bAffectChildren_69 = bAffectChildren_69;
	params.bSetupUndo_69 = bSetupUndo_69;
	params.bPrintPythonCommands_69 = bPrintPythonCommands_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ControlRig.RigHierarchy.SetBoolMetadata
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// struct FRigElementKey          InItem_69                      (Parm)
// struct FName                   InMetadataName_69              (Parm, ZeroConstructor, IsPlainOldData)
// bool                           InValue_69                     (Parm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool RigHierarchy::SetBoolMetadata(const struct FRigElementKey& InItem_69, const struct FName& InMetadataName_69, bool InValue_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchy.SetBoolMetadata"));

	RigHierarchy_SetBoolMetadata_Params params;
	params.InItem_69 = InItem_69;
	params.InMetadataName_69 = InMetadataName_69;
	params.InValue_69 = InValue_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.RigHierarchy.SetBoolArrayMetadata
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// struct FRigElementKey          InItem_69                      (Parm)
// struct FName                   InMetadataName_69              (Parm, ZeroConstructor, IsPlainOldData)
// TArray<bool>                   InValue_69                     (Parm, ZeroConstructor)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool RigHierarchy::SetBoolArrayMetadata(const struct FRigElementKey& InItem_69, const struct FName& InMetadataName_69, TArray<bool> InValue_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchy.SetBoolArrayMetadata"));

	RigHierarchy_SetBoolArrayMetadata_Params params;
	params.InItem_69 = InItem_69;
	params.InMetadataName_69 = InMetadataName_69;
	params.InValue_69 = InValue_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.RigHierarchy.SendAutoKeyEvent
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// struct FRigElementKey          InElement_69                   (Parm)
// float                          InOffsetInSeconds_69           (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bAsynchronous_69               (Parm, ZeroConstructor, IsPlainOldData)

void RigHierarchy::SendAutoKeyEvent(const struct FRigElementKey& InElement_69, float InOffsetInSeconds_69, bool bAsynchronous_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchy.SendAutoKeyEvent"));

	RigHierarchy_SendAutoKeyEvent_Params params;
	params.InElement_69 = InElement_69;
	params.InOffsetInSeconds_69 = InOffsetInSeconds_69;
	params.bAsynchronous_69 = bAsynchronous_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ControlRig.RigHierarchy.ResetToDefault
// (Final, Native, Public, BlueprintCallable)

void RigHierarchy::ResetToDefault()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchy.ResetToDefault"));

	RigHierarchy_ResetToDefault_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ControlRig.RigHierarchy.ResetPoseToInitial
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// ERigElementType                InTypeFilter_69                (Parm, ZeroConstructor, IsPlainOldData)

void RigHierarchy::ResetPoseToInitial(ERigElementType InTypeFilter_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchy.ResetPoseToInitial"));

	RigHierarchy_ResetPoseToInitial_Params params;
	params.InTypeFilter_69 = InTypeFilter_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ControlRig.RigHierarchy.ResetCurveValues
// (Final, Native, Public, BlueprintCallable)

void RigHierarchy::ResetCurveValues()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchy.ResetCurveValues"));

	RigHierarchy_ResetCurveValues_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ControlRig.RigHierarchy.Reset
// (Final, Native, Public, BlueprintCallable)

void RigHierarchy::Reset()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchy.Reset"));

	RigHierarchy_Reset_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ControlRig.RigHierarchy.RemoveMetadata
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// struct FRigElementKey          InItem_69                      (Parm)
// struct FName                   InMetadataName_69              (Parm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool RigHierarchy::RemoveMetadata(const struct FRigElementKey& InItem_69, const struct FName& InMetadataName_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchy.RemoveMetadata"));

	RigHierarchy_RemoveMetadata_Params params;
	params.InItem_69 = InItem_69;
	params.InMetadataName_69 = InMetadataName_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.RigHierarchy.RemoveAllMetadata
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// struct FRigElementKey          InItem_69                      (Parm)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool RigHierarchy::RemoveAllMetadata(const struct FRigElementKey& InItem_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchy.RemoveAllMetadata"));

	RigHierarchy_RemoveAllMetadata_Params params;
	params.InItem_69 = InItem_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.RigHierarchy.Num
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// int                            ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int RigHierarchy::Num()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchy.Num"));

	RigHierarchy_Num_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.RigHierarchy.MakeControlValueFromVector2D
// (Final, Native, Static, Public, HasDefaults, BlueprintCallable)
// Parameters:
// struct FVector2D               InValue_69                     (Parm, ZeroConstructor, IsPlainOldData)
// struct FRigControlValue        ReturnValue_69                 (Parm, OutParm, ReturnParm)

struct FRigControlValue RigHierarchy::STATIC_MakeControlValueFromVector2D(const struct FVector2D& InValue_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchy.MakeControlValueFromVector2D"));

	RigHierarchy_MakeControlValueFromVector2D_Params params;
	params.InValue_69 = InValue_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.RigHierarchy.MakeControlValueFromVector
// (Final, Native, Static, Public, HasDefaults, BlueprintCallable)
// Parameters:
// struct FVector                 InValue_69                     (Parm, ZeroConstructor, IsPlainOldData)
// struct FRigControlValue        ReturnValue_69                 (Parm, OutParm, ReturnParm)

struct FRigControlValue RigHierarchy::STATIC_MakeControlValueFromVector(const struct FVector& InValue_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchy.MakeControlValueFromVector"));

	RigHierarchy_MakeControlValueFromVector_Params params;
	params.InValue_69 = InValue_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.RigHierarchy.MakeControlValueFromTransformNoScale
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// struct FTransformNoScale       InValue_69                     (Parm)
// struct FRigControlValue        ReturnValue_69                 (Parm, OutParm, ReturnParm)

struct FRigControlValue RigHierarchy::STATIC_MakeControlValueFromTransformNoScale(const struct FTransformNoScale& InValue_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchy.MakeControlValueFromTransformNoScale"));

	RigHierarchy_MakeControlValueFromTransformNoScale_Params params;
	params.InValue_69 = InValue_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.RigHierarchy.MakeControlValueFromTransform
// (Final, Native, Static, Public, HasDefaults, BlueprintCallable)
// Parameters:
// struct FCoreUObject_FTransform InValue_69                     (Parm, IsPlainOldData)
// struct FRigControlValue        ReturnValue_69                 (Parm, OutParm, ReturnParm)

struct FRigControlValue RigHierarchy::STATIC_MakeControlValueFromTransform(const struct FCoreUObject_FTransform& InValue_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchy.MakeControlValueFromTransform"));

	RigHierarchy_MakeControlValueFromTransform_Params params;
	params.InValue_69 = InValue_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.RigHierarchy.MakeControlValueFromRotator
// (Final, Native, Static, Public, HasDefaults, BlueprintCallable)
// Parameters:
// struct FRotator                InValue_69                     (Parm, ZeroConstructor, IsPlainOldData)
// struct FRigControlValue        ReturnValue_69                 (Parm, OutParm, ReturnParm)

struct FRigControlValue RigHierarchy::STATIC_MakeControlValueFromRotator(const struct FRotator& InValue_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchy.MakeControlValueFromRotator"));

	RigHierarchy_MakeControlValueFromRotator_Params params;
	params.InValue_69 = InValue_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.RigHierarchy.MakeControlValueFromInt
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// int                            InValue_69                     (Parm, ZeroConstructor, IsPlainOldData)
// struct FRigControlValue        ReturnValue_69                 (Parm, OutParm, ReturnParm)

struct FRigControlValue RigHierarchy::STATIC_MakeControlValueFromInt(int InValue_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchy.MakeControlValueFromInt"));

	RigHierarchy_MakeControlValueFromInt_Params params;
	params.InValue_69 = InValue_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.RigHierarchy.MakeControlValueFromFloat
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// float                          InValue_69                     (Parm, ZeroConstructor, IsPlainOldData)
// struct FRigControlValue        ReturnValue_69                 (Parm, OutParm, ReturnParm)

struct FRigControlValue RigHierarchy::STATIC_MakeControlValueFromFloat(float InValue_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchy.MakeControlValueFromFloat"));

	RigHierarchy_MakeControlValueFromFloat_Params params;
	params.InValue_69 = InValue_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.RigHierarchy.MakeControlValueFromEulerTransform
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// struct FEulerTransform         InValue_69                     (Parm)
// struct FRigControlValue        ReturnValue_69                 (Parm, OutParm, ReturnParm)

struct FRigControlValue RigHierarchy::STATIC_MakeControlValueFromEulerTransform(const struct FEulerTransform& InValue_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchy.MakeControlValueFromEulerTransform"));

	RigHierarchy_MakeControlValueFromEulerTransform_Params params;
	params.InValue_69 = InValue_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.RigHierarchy.MakeControlValueFromBool
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// bool                           InValue_69                     (Parm, ZeroConstructor, IsPlainOldData)
// struct FRigControlValue        ReturnValue_69                 (Parm, OutParm, ReturnParm)

struct FRigControlValue RigHierarchy::STATIC_MakeControlValueFromBool(bool InValue_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchy.MakeControlValueFromBool"));

	RigHierarchy_MakeControlValueFromBool_Params params;
	params.InValue_69 = InValue_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.RigHierarchy.IsValidIndex
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// int                            InElementIndex_69              (Parm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool RigHierarchy::IsValidIndex(int InElementIndex_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchy.IsValidIndex"));

	RigHierarchy_IsValidIndex_Params params;
	params.InElementIndex_69 = InElementIndex_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.RigHierarchy.IsSelectedByIndex
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// int                            InIndex_69                     (Parm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool RigHierarchy::IsSelectedByIndex(int InIndex_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchy.IsSelectedByIndex"));

	RigHierarchy_IsSelectedByIndex_Params params;
	params.InIndex_69 = InIndex_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.RigHierarchy.IsSelected
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FRigElementKey          InKey_69                       (Parm)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool RigHierarchy::IsSelected(const struct FRigElementKey& InKey_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchy.IsSelected"));

	RigHierarchy_IsSelected_Params params;
	params.InKey_69 = InKey_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.RigHierarchy.IsProcedural
// (Final, Native, Public, HasOutParms, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FRigElementKey          InKey_69                       (ConstParm, Parm, OutParm, ReferenceParm)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool RigHierarchy::IsProcedural(const struct FRigElementKey& InKey_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchy.IsProcedural"));

	RigHierarchy_IsProcedural_Params params;
	params.InKey_69 = InKey_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.RigHierarchy.IsParentedTo
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FRigElementKey          InChild_69                     (Parm)
// struct FRigElementKey          InParent_69                    (Parm)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool RigHierarchy::IsParentedTo(const struct FRigElementKey& InChild_69, const struct FRigElementKey& InParent_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchy.IsParentedTo"));

	RigHierarchy_IsParentedTo_Params params;
	params.InChild_69 = InChild_69;
	params.InParent_69 = InParent_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.RigHierarchy.IsCurveValueSetByIndex
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// int                            InElementIndex_69              (Parm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool RigHierarchy::IsCurveValueSetByIndex(int InElementIndex_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchy.IsCurveValueSetByIndex"));

	RigHierarchy_IsCurveValueSetByIndex_Params params;
	params.InElementIndex_69 = InElementIndex_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.RigHierarchy.IsCurveValueSet
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FRigElementKey          InKey_69                       (Parm)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool RigHierarchy::IsCurveValueSet(const struct FRigElementKey& InKey_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchy.IsCurveValueSet"));

	RigHierarchy_IsCurveValueSet_Params params;
	params.InKey_69 = InKey_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.RigHierarchy.IsControllerAvailable
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool RigHierarchy::IsControllerAvailable()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchy.IsControllerAvailable"));

	RigHierarchy_IsControllerAvailable_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.RigHierarchy.HasTag
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FRigElementKey          InItem_69                      (Parm)
// struct FName                   InTag_69                       (Parm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool RigHierarchy::HasTag(const struct FRigElementKey& InItem_69, const struct FName& InTag_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchy.HasTag"));

	RigHierarchy_HasTag_Params params;
	params.InItem_69 = InItem_69;
	params.InTag_69 = InTag_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.RigHierarchy.GetVectorMetadata
// (Final, Native, Public, HasDefaults, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FRigElementKey          InItem_69                      (Parm)
// struct FName                   InMetadataName_69              (Parm, ZeroConstructor, IsPlainOldData)
// struct FVector                 DefaultValue_69                (Parm, ZeroConstructor, IsPlainOldData)
// struct FVector                 ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

struct FVector RigHierarchy::GetVectorMetadata(const struct FRigElementKey& InItem_69, const struct FName& InMetadataName_69, const struct FVector& DefaultValue_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchy.GetVectorMetadata"));

	RigHierarchy_GetVectorMetadata_Params params;
	params.InItem_69 = InItem_69;
	params.InMetadataName_69 = InMetadataName_69;
	params.DefaultValue_69 = DefaultValue_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.RigHierarchy.GetVectorFromControlValue
// (Final, Native, Static, Public, HasDefaults, BlueprintCallable)
// Parameters:
// struct FRigControlValue        InValue_69                     (Parm)
// struct FVector                 ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

struct FVector RigHierarchy::STATIC_GetVectorFromControlValue(const struct FRigControlValue& InValue_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchy.GetVectorFromControlValue"));

	RigHierarchy_GetVectorFromControlValue_Params params;
	params.InValue_69 = InValue_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.RigHierarchy.GetVectorArrayMetadata
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FRigElementKey          InItem_69                      (Parm)
// struct FName                   InMetadataName_69              (Parm, ZeroConstructor, IsPlainOldData)
// TArray<struct FVector>         ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

TArray<struct FVector> RigHierarchy::GetVectorArrayMetadata(const struct FRigElementKey& InItem_69, const struct FName& InMetadataName_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchy.GetVectorArrayMetadata"));

	RigHierarchy_GetVectorArrayMetadata_Params params;
	params.InItem_69 = InItem_69;
	params.InMetadataName_69 = InMetadataName_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.RigHierarchy.GetVector2DFromControlValue
// (Final, Native, Static, Public, HasDefaults, BlueprintCallable)
// Parameters:
// struct FRigControlValue        InValue_69                     (Parm)
// struct FVector2D               ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

struct FVector2D RigHierarchy::STATIC_GetVector2DFromControlValue(const struct FRigControlValue& InValue_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchy.GetVector2DFromControlValue"));

	RigHierarchy_GetVector2DFromControlValue_Params params;
	params.InValue_69 = InValue_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.RigHierarchy.GetTransformNoScaleFromControlValue
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// struct FRigControlValue        InValue_69                     (Parm)
// struct FTransformNoScale       ReturnValue_69                 (Parm, OutParm, ReturnParm)

struct FTransformNoScale RigHierarchy::STATIC_GetTransformNoScaleFromControlValue(const struct FRigControlValue& InValue_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchy.GetTransformNoScaleFromControlValue"));

	RigHierarchy_GetTransformNoScaleFromControlValue_Params params;
	params.InValue_69 = InValue_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.RigHierarchy.GetTransformMetadata
// (Final, Native, Public, HasDefaults, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FRigElementKey          InItem_69                      (Parm)
// struct FName                   InMetadataName_69              (Parm, ZeroConstructor, IsPlainOldData)
// struct FCoreUObject_FTransform DefaultValue_69                (Parm, IsPlainOldData)
// struct FCoreUObject_FTransform ReturnValue_69                 (Parm, OutParm, ReturnParm, IsPlainOldData)

struct FCoreUObject_FTransform RigHierarchy::GetTransformMetadata(const struct FRigElementKey& InItem_69, const struct FName& InMetadataName_69, const struct FCoreUObject_FTransform& DefaultValue_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchy.GetTransformMetadata"));

	RigHierarchy_GetTransformMetadata_Params params;
	params.InItem_69 = InItem_69;
	params.InMetadataName_69 = InMetadataName_69;
	params.DefaultValue_69 = DefaultValue_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.RigHierarchy.GetTransformFromControlValue
// (Final, Native, Static, Public, HasDefaults, BlueprintCallable)
// Parameters:
// struct FRigControlValue        InValue_69                     (Parm)
// struct FCoreUObject_FTransform ReturnValue_69                 (Parm, OutParm, ReturnParm, IsPlainOldData)

struct FCoreUObject_FTransform RigHierarchy::STATIC_GetTransformFromControlValue(const struct FRigControlValue& InValue_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchy.GetTransformFromControlValue"));

	RigHierarchy_GetTransformFromControlValue_Params params;
	params.InValue_69 = InValue_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.RigHierarchy.GetTransformArrayMetadata
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FRigElementKey          InItem_69                      (Parm)
// struct FName                   InMetadataName_69              (Parm, ZeroConstructor, IsPlainOldData)
// TArray<struct FCoreUObject_FTransform> ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

TArray<struct FCoreUObject_FTransform> RigHierarchy::GetTransformArrayMetadata(const struct FRigElementKey& InItem_69, const struct FName& InMetadataName_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchy.GetTransformArrayMetadata"));

	RigHierarchy_GetTransformArrayMetadata_Params params;
	params.InItem_69 = InItem_69;
	params.InMetadataName_69 = InMetadataName_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.RigHierarchy.GetTags
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FRigElementKey          InItem_69                      (Parm)
// TArray<struct FName>           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

TArray<struct FName> RigHierarchy::GetTags(const struct FRigElementKey& InItem_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchy.GetTags"));

	RigHierarchy_GetTags_Params params;
	params.InItem_69 = InItem_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.RigHierarchy.GetSelectedKeys
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// ERigElementType                InTypeFilter_69                (Parm, ZeroConstructor, IsPlainOldData)
// TArray<struct FRigElementKey>  ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

TArray<struct FRigElementKey> RigHierarchy::GetSelectedKeys(ERigElementType InTypeFilter_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchy.GetSelectedKeys"));

	RigHierarchy_GetSelectedKeys_Params params;
	params.InTypeFilter_69 = InTypeFilter_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.RigHierarchy.GetRotatorMetadata
// (Final, Native, Public, HasDefaults, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FRigElementKey          InItem_69                      (Parm)
// struct FName                   InMetadataName_69              (Parm, ZeroConstructor, IsPlainOldData)
// struct FRotator                DefaultValue_69                (Parm, ZeroConstructor, IsPlainOldData)
// struct FRotator                ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

struct FRotator RigHierarchy::GetRotatorMetadata(const struct FRigElementKey& InItem_69, const struct FName& InMetadataName_69, const struct FRotator& DefaultValue_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchy.GetRotatorMetadata"));

	RigHierarchy_GetRotatorMetadata_Params params;
	params.InItem_69 = InItem_69;
	params.InMetadataName_69 = InMetadataName_69;
	params.DefaultValue_69 = DefaultValue_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.RigHierarchy.GetRotatorFromControlValue
// (Final, Native, Static, Public, HasDefaults, BlueprintCallable)
// Parameters:
// struct FRigControlValue        InValue_69                     (Parm)
// struct FRotator                ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

struct FRotator RigHierarchy::STATIC_GetRotatorFromControlValue(const struct FRigControlValue& InValue_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchy.GetRotatorFromControlValue"));

	RigHierarchy_GetRotatorFromControlValue_Params params;
	params.InValue_69 = InValue_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.RigHierarchy.GetRotatorArrayMetadata
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FRigElementKey          InItem_69                      (Parm)
// struct FName                   InMetadataName_69              (Parm, ZeroConstructor, IsPlainOldData)
// TArray<struct FRotator>        ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

TArray<struct FRotator> RigHierarchy::GetRotatorArrayMetadata(const struct FRigElementKey& InItem_69, const struct FName& InMetadataName_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchy.GetRotatorArrayMetadata"));

	RigHierarchy_GetRotatorArrayMetadata_Params params;
	params.InItem_69 = InItem_69;
	params.InMetadataName_69 = InMetadataName_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.RigHierarchy.GetRigidBodyKeys
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// bool                           bTraverse_69                   (Parm, ZeroConstructor, IsPlainOldData)
// TArray<struct FRigElementKey>  ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

TArray<struct FRigElementKey> RigHierarchy::GetRigidBodyKeys(bool bTraverse_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchy.GetRigidBodyKeys"));

	RigHierarchy_GetRigidBodyKeys_Params params;
	params.bTraverse_69 = bTraverse_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.RigHierarchy.GetRigElementKeyMetadata
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FRigElementKey          InItem_69                      (Parm)
// struct FName                   InMetadataName_69              (Parm, ZeroConstructor, IsPlainOldData)
// struct FRigElementKey          DefaultValue_69                (Parm)
// struct FRigElementKey          ReturnValue_69                 (Parm, OutParm, ReturnParm)

struct FRigElementKey RigHierarchy::GetRigElementKeyMetadata(const struct FRigElementKey& InItem_69, const struct FName& InMetadataName_69, const struct FRigElementKey& DefaultValue_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchy.GetRigElementKeyMetadata"));

	RigHierarchy_GetRigElementKeyMetadata_Params params;
	params.InItem_69 = InItem_69;
	params.InMetadataName_69 = InMetadataName_69;
	params.DefaultValue_69 = DefaultValue_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.RigHierarchy.GetRigElementKeyArrayMetadata
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FRigElementKey          InItem_69                      (Parm)
// struct FName                   InMetadataName_69              (Parm, ZeroConstructor, IsPlainOldData)
// TArray<struct FRigElementKey>  ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

TArray<struct FRigElementKey> RigHierarchy::GetRigElementKeyArrayMetadata(const struct FRigElementKey& InItem_69, const struct FName& InMetadataName_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchy.GetRigElementKeyArrayMetadata"));

	RigHierarchy_GetRigElementKeyArrayMetadata_Params params;
	params.InItem_69 = InItem_69;
	params.InMetadataName_69 = InMetadataName_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.RigHierarchy.GetReferenceKeys
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// bool                           bTraverse_69                   (Parm, ZeroConstructor, IsPlainOldData)
// TArray<struct FRigElementKey>  ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

TArray<struct FRigElementKey> RigHierarchy::GetReferenceKeys(bool bTraverse_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchy.GetReferenceKeys"));

	RigHierarchy_GetReferenceKeys_Params params;
	params.bTraverse_69 = bTraverse_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.RigHierarchy.GetQuatMetadata
// (Final, Native, Public, HasDefaults, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FRigElementKey          InItem_69                      (Parm)
// struct FName                   InMetadataName_69              (Parm, ZeroConstructor, IsPlainOldData)
// struct FQuat                   DefaultValue_69                (Parm, IsPlainOldData)
// struct FQuat                   ReturnValue_69                 (Parm, OutParm, ReturnParm, IsPlainOldData)

struct FQuat RigHierarchy::GetQuatMetadata(const struct FRigElementKey& InItem_69, const struct FName& InMetadataName_69, const struct FQuat& DefaultValue_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchy.GetQuatMetadata"));

	RigHierarchy_GetQuatMetadata_Params params;
	params.InItem_69 = InItem_69;
	params.InMetadataName_69 = InMetadataName_69;
	params.DefaultValue_69 = DefaultValue_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.RigHierarchy.GetQuatArrayMetadata
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FRigElementKey          InItem_69                      (Parm)
// struct FName                   InMetadataName_69              (Parm, ZeroConstructor, IsPlainOldData)
// TArray<struct FQuat>           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

TArray<struct FQuat> RigHierarchy::GetQuatArrayMetadata(const struct FRigElementKey& InItem_69, const struct FName& InMetadataName_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchy.GetQuatArrayMetadata"));

	RigHierarchy_GetQuatArrayMetadata_Params params;
	params.InItem_69 = InItem_69;
	params.InMetadataName_69 = InMetadataName_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.RigHierarchy.GetPreviousParent
// (Final, Native, Public, HasOutParms, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FRigElementKey          InKey_69                       (ConstParm, Parm, OutParm, ReferenceParm)
// struct FRigElementKey          ReturnValue_69                 (Parm, OutParm, ReturnParm)

struct FRigElementKey RigHierarchy::GetPreviousParent(const struct FRigElementKey& InKey_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchy.GetPreviousParent"));

	RigHierarchy_GetPreviousParent_Params params;
	params.InKey_69 = InKey_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.RigHierarchy.GetPreviousName
// (Final, Native, Public, HasOutParms, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FRigElementKey          InKey_69                       (ConstParm, Parm, OutParm, ReferenceParm)
// struct FName                   ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

struct FName RigHierarchy::GetPreviousName(const struct FRigElementKey& InKey_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchy.GetPreviousName"));

	RigHierarchy_GetPreviousName_Params params;
	params.InKey_69 = InKey_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.RigHierarchy.GetPose
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// bool                           bInitial_69                    (Parm, ZeroConstructor, IsPlainOldData)
// struct FRigPose                ReturnValue_69                 (Parm, OutParm, ReturnParm)

struct FRigPose RigHierarchy::GetPose(bool bInitial_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchy.GetPose"));

	RigHierarchy_GetPose_Params params;
	params.bInitial_69 = bInitial_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.RigHierarchy.GetParentWeightArray
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FRigElementKey          InChild_69                     (Parm)
// bool                           bInitial_69                    (Parm, ZeroConstructor, IsPlainOldData)
// TArray<struct FRigElementWeight> ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

TArray<struct FRigElementWeight> RigHierarchy::GetParentWeightArray(const struct FRigElementKey& InChild_69, bool bInitial_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchy.GetParentWeightArray"));

	RigHierarchy_GetParentWeightArray_Params params;
	params.InChild_69 = InChild_69;
	params.bInitial_69 = bInitial_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.RigHierarchy.GetParentWeight
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FRigElementKey          InChild_69                     (Parm)
// struct FRigElementKey          InParent_69                    (Parm)
// bool                           bInitial_69                    (Parm, ZeroConstructor, IsPlainOldData)
// struct FRigElementWeight       ReturnValue_69                 (Parm, OutParm, ReturnParm)

struct FRigElementWeight RigHierarchy::GetParentWeight(const struct FRigElementKey& InChild_69, const struct FRigElementKey& InParent_69, bool bInitial_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchy.GetParentWeight"));

	RigHierarchy_GetParentWeight_Params params;
	params.InChild_69 = InChild_69;
	params.InParent_69 = InParent_69;
	params.bInitial_69 = bInitial_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.RigHierarchy.GetParentTransformByIndex
// (Final, Native, Public, HasDefaults, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// int                            InElementIndex_69              (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bInitial_69                    (Parm, ZeroConstructor, IsPlainOldData)
// struct FCoreUObject_FTransform ReturnValue_69                 (Parm, OutParm, ReturnParm, IsPlainOldData)

struct FCoreUObject_FTransform RigHierarchy::GetParentTransformByIndex(int InElementIndex_69, bool bInitial_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchy.GetParentTransformByIndex"));

	RigHierarchy_GetParentTransformByIndex_Params params;
	params.InElementIndex_69 = InElementIndex_69;
	params.bInitial_69 = bInitial_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.RigHierarchy.GetParentTransform
// (Final, Native, Public, HasDefaults, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FRigElementKey          InKey_69                       (Parm)
// bool                           bInitial_69                    (Parm, ZeroConstructor, IsPlainOldData)
// struct FCoreUObject_FTransform ReturnValue_69                 (Parm, OutParm, ReturnParm, IsPlainOldData)

struct FCoreUObject_FTransform RigHierarchy::GetParentTransform(const struct FRigElementKey& InKey_69, bool bInitial_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchy.GetParentTransform"));

	RigHierarchy_GetParentTransform_Params params;
	params.InKey_69 = InKey_69;
	params.bInitial_69 = bInitial_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.RigHierarchy.GetParents
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FRigElementKey          InKey_69                       (Parm)
// bool                           bRecursive_69                  (Parm, ZeroConstructor, IsPlainOldData)
// TArray<struct FRigElementKey>  ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

TArray<struct FRigElementKey> RigHierarchy::GetParents(const struct FRigElementKey& InKey_69, bool bRecursive_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchy.GetParents"));

	RigHierarchy_GetParents_Params params;
	params.InKey_69 = InKey_69;
	params.bRecursive_69 = bRecursive_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.RigHierarchy.GetNumberOfParents
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FRigElementKey          InKey_69                       (Parm)
// int                            ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int RigHierarchy::GetNumberOfParents(const struct FRigElementKey& InKey_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchy.GetNumberOfParents"));

	RigHierarchy_GetNumberOfParents_Params params;
	params.InKey_69 = InKey_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.RigHierarchy.GetNullKeys
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// bool                           bTraverse_69                   (Parm, ZeroConstructor, IsPlainOldData)
// TArray<struct FRigElementKey>  ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

TArray<struct FRigElementKey> RigHierarchy::GetNullKeys(bool bTraverse_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchy.GetNullKeys"));

	RigHierarchy_GetNullKeys_Params params;
	params.bTraverse_69 = bTraverse_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.RigHierarchy.GetNameMetadata
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FRigElementKey          InItem_69                      (Parm)
// struct FName                   InMetadataName_69              (Parm, ZeroConstructor, IsPlainOldData)
// struct FName                   DefaultValue_69                (Parm, ZeroConstructor, IsPlainOldData)
// struct FName                   ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

struct FName RigHierarchy::GetNameMetadata(const struct FRigElementKey& InItem_69, const struct FName& InMetadataName_69, const struct FName& DefaultValue_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchy.GetNameMetadata"));

	RigHierarchy_GetNameMetadata_Params params;
	params.InItem_69 = InItem_69;
	params.InMetadataName_69 = InMetadataName_69;
	params.DefaultValue_69 = DefaultValue_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.RigHierarchy.GetNameArrayMetadata
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FRigElementKey          InItem_69                      (Parm)
// struct FName                   InMetadataName_69              (Parm, ZeroConstructor, IsPlainOldData)
// TArray<struct FName>           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

TArray<struct FName> RigHierarchy::GetNameArrayMetadata(const struct FRigElementKey& InItem_69, const struct FName& InMetadataName_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchy.GetNameArrayMetadata"));

	RigHierarchy_GetNameArrayMetadata_Params params;
	params.InItem_69 = InItem_69;
	params.InMetadataName_69 = InMetadataName_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.RigHierarchy.GetMetadataType
// (Final, Native, Public, BlueprintCallable, BlueprintPure)
// Parameters:
// struct FRigElementKey          InItem_69                      (Parm)
// struct FName                   InMetadataName_69              (Parm, ZeroConstructor, IsPlainOldData)
// ERigMetadataType               ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

ERigMetadataType RigHierarchy::GetMetadataType(const struct FRigElementKey& InItem_69, const struct FName& InMetadataName_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchy.GetMetadataType"));

	RigHierarchy_GetMetadataType_Params params;
	params.InItem_69 = InItem_69;
	params.InMetadataName_69 = InMetadataName_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.RigHierarchy.GetMetadataNames
// (Final, Native, Public, BlueprintCallable, BlueprintPure)
// Parameters:
// struct FRigElementKey          InItem_69                      (Parm)
// TArray<struct FName>           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

TArray<struct FName> RigHierarchy::GetMetadataNames(const struct FRigElementKey& InItem_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchy.GetMetadataNames"));

	RigHierarchy_GetMetadataNames_Params params;
	params.InItem_69 = InItem_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.RigHierarchy.GetLocalTransformByIndex
// (Final, Native, Public, HasDefaults, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// int                            InElementIndex_69              (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bInitial_69                    (Parm, ZeroConstructor, IsPlainOldData)
// struct FCoreUObject_FTransform ReturnValue_69                 (Parm, OutParm, ReturnParm, IsPlainOldData)

struct FCoreUObject_FTransform RigHierarchy::GetLocalTransformByIndex(int InElementIndex_69, bool bInitial_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchy.GetLocalTransformByIndex"));

	RigHierarchy_GetLocalTransformByIndex_Params params;
	params.InElementIndex_69 = InElementIndex_69;
	params.bInitial_69 = bInitial_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.RigHierarchy.GetLocalTransform
// (Final, Native, Public, HasDefaults, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FRigElementKey          InKey_69                       (Parm)
// bool                           bInitial_69                    (Parm, ZeroConstructor, IsPlainOldData)
// struct FCoreUObject_FTransform ReturnValue_69                 (Parm, OutParm, ReturnParm, IsPlainOldData)

struct FCoreUObject_FTransform RigHierarchy::GetLocalTransform(const struct FRigElementKey& InKey_69, bool bInitial_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchy.GetLocalTransform"));

	RigHierarchy_GetLocalTransform_Params params;
	params.InKey_69 = InKey_69;
	params.bInitial_69 = bInitial_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.RigHierarchy.GetLocalControlShapeTransformByIndex
// (Final, Native, Public, HasDefaults, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// int                            InElementIndex_69              (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bInitial_69                    (Parm, ZeroConstructor, IsPlainOldData)
// struct FCoreUObject_FTransform ReturnValue_69                 (Parm, OutParm, ReturnParm, IsPlainOldData)

struct FCoreUObject_FTransform RigHierarchy::GetLocalControlShapeTransformByIndex(int InElementIndex_69, bool bInitial_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchy.GetLocalControlShapeTransformByIndex"));

	RigHierarchy_GetLocalControlShapeTransformByIndex_Params params;
	params.InElementIndex_69 = InElementIndex_69;
	params.bInitial_69 = bInitial_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.RigHierarchy.GetLocalControlShapeTransform
// (Final, Native, Public, HasDefaults, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FRigElementKey          InKey_69                       (Parm)
// bool                           bInitial_69                    (Parm, ZeroConstructor, IsPlainOldData)
// struct FCoreUObject_FTransform ReturnValue_69                 (Parm, OutParm, ReturnParm, IsPlainOldData)

struct FCoreUObject_FTransform RigHierarchy::GetLocalControlShapeTransform(const struct FRigElementKey& InKey_69, bool bInitial_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchy.GetLocalControlShapeTransform"));

	RigHierarchy_GetLocalControlShapeTransform_Params params;
	params.InKey_69 = InKey_69;
	params.bInitial_69 = bInitial_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.RigHierarchy.GetLinearColorMetadata
// (Final, Native, Public, HasDefaults, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FRigElementKey          InItem_69                      (Parm)
// struct FName                   InMetadataName_69              (Parm, ZeroConstructor, IsPlainOldData)
// struct FLinearColor            DefaultValue_69                (Parm, ZeroConstructor, IsPlainOldData)
// struct FLinearColor            ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

struct FLinearColor RigHierarchy::GetLinearColorMetadata(const struct FRigElementKey& InItem_69, const struct FName& InMetadataName_69, const struct FLinearColor& DefaultValue_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchy.GetLinearColorMetadata"));

	RigHierarchy_GetLinearColorMetadata_Params params;
	params.InItem_69 = InItem_69;
	params.InMetadataName_69 = InMetadataName_69;
	params.DefaultValue_69 = DefaultValue_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.RigHierarchy.GetLinearColorArrayMetadata
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FRigElementKey          InItem_69                      (Parm)
// struct FName                   InMetadataName_69              (Parm, ZeroConstructor, IsPlainOldData)
// TArray<struct FLinearColor>    ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

TArray<struct FLinearColor> RigHierarchy::GetLinearColorArrayMetadata(const struct FRigElementKey& InItem_69, const struct FName& InMetadataName_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchy.GetLinearColorArrayMetadata"));

	RigHierarchy_GetLinearColorArrayMetadata_Params params;
	params.InItem_69 = InItem_69;
	params.InMetadataName_69 = InMetadataName_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.RigHierarchy.GetKeys
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// TArray<int>                    InElementIndices_69            (ConstParm, Parm, ZeroConstructor)
// TArray<struct FRigElementKey>  ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

TArray<struct FRigElementKey> RigHierarchy::GetKeys(TArray<int> InElementIndices_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchy.GetKeys"));

	RigHierarchy_GetKeys_Params params;
	params.InElementIndices_69 = InElementIndices_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.RigHierarchy.GetKey
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// int                            InElementIndex_69              (Parm, ZeroConstructor, IsPlainOldData)
// struct FRigElementKey          ReturnValue_69                 (Parm, OutParm, ReturnParm)

struct FRigElementKey RigHierarchy::GetKey(int InElementIndex_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchy.GetKey"));

	RigHierarchy_GetKey_Params params;
	params.InElementIndex_69 = InElementIndex_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.RigHierarchy.GetIntFromControlValue
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// struct FRigControlValue        InValue_69                     (Parm)
// int                            ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int RigHierarchy::STATIC_GetIntFromControlValue(const struct FRigControlValue& InValue_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchy.GetIntFromControlValue"));

	RigHierarchy_GetIntFromControlValue_Params params;
	params.InValue_69 = InValue_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.RigHierarchy.GetInt32Metadata
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FRigElementKey          InItem_69                      (Parm)
// struct FName                   InMetadataName_69              (Parm, ZeroConstructor, IsPlainOldData)
// int                            DefaultValue_69                (Parm, ZeroConstructor, IsPlainOldData)
// int                            ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int RigHierarchy::GetInt32Metadata(const struct FRigElementKey& InItem_69, const struct FName& InMetadataName_69, int DefaultValue_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchy.GetInt32Metadata"));

	RigHierarchy_GetInt32Metadata_Params params;
	params.InItem_69 = InItem_69;
	params.InMetadataName_69 = InMetadataName_69;
	params.DefaultValue_69 = DefaultValue_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.RigHierarchy.GetInt32ArrayMetadata
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FRigElementKey          InItem_69                      (Parm)
// struct FName                   InMetadataName_69              (Parm, ZeroConstructor, IsPlainOldData)
// TArray<int>                    ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

TArray<int> RigHierarchy::GetInt32ArrayMetadata(const struct FRigElementKey& InItem_69, const struct FName& InMetadataName_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchy.GetInt32ArrayMetadata"));

	RigHierarchy_GetInt32ArrayMetadata_Params params;
	params.InItem_69 = InItem_69;
	params.InMetadataName_69 = InMetadataName_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.RigHierarchy.GetIndex_ForBlueprint
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FRigElementKey          InKey_69                       (Parm)
// int                            ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int RigHierarchy::GetIndex_ForBlueprint(const struct FRigElementKey& InKey_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchy.GetIndex_ForBlueprint"));

	RigHierarchy_GetIndex_ForBlueprint_Params params;
	params.InKey_69 = InKey_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.RigHierarchy.GetGlobalTransformByIndex
// (Final, Native, Public, HasDefaults, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// int                            InElementIndex_69              (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bInitial_69                    (Parm, ZeroConstructor, IsPlainOldData)
// struct FCoreUObject_FTransform ReturnValue_69                 (Parm, OutParm, ReturnParm, IsPlainOldData)

struct FCoreUObject_FTransform RigHierarchy::GetGlobalTransformByIndex(int InElementIndex_69, bool bInitial_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchy.GetGlobalTransformByIndex"));

	RigHierarchy_GetGlobalTransformByIndex_Params params;
	params.InElementIndex_69 = InElementIndex_69;
	params.bInitial_69 = bInitial_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.RigHierarchy.GetGlobalTransform
// (Final, Native, Public, HasDefaults, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FRigElementKey          InKey_69                       (Parm)
// bool                           bInitial_69                    (Parm, ZeroConstructor, IsPlainOldData)
// struct FCoreUObject_FTransform ReturnValue_69                 (Parm, OutParm, ReturnParm, IsPlainOldData)

struct FCoreUObject_FTransform RigHierarchy::GetGlobalTransform(const struct FRigElementKey& InKey_69, bool bInitial_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchy.GetGlobalTransform"));

	RigHierarchy_GetGlobalTransform_Params params;
	params.InKey_69 = InKey_69;
	params.bInitial_69 = bInitial_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.RigHierarchy.GetGlobalControlShapeTransformByIndex
// (Final, Native, Public, HasDefaults, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// int                            InElementIndex_69              (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bInitial_69                    (Parm, ZeroConstructor, IsPlainOldData)
// struct FCoreUObject_FTransform ReturnValue_69                 (Parm, OutParm, ReturnParm, IsPlainOldData)

struct FCoreUObject_FTransform RigHierarchy::GetGlobalControlShapeTransformByIndex(int InElementIndex_69, bool bInitial_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchy.GetGlobalControlShapeTransformByIndex"));

	RigHierarchy_GetGlobalControlShapeTransformByIndex_Params params;
	params.InElementIndex_69 = InElementIndex_69;
	params.bInitial_69 = bInitial_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.RigHierarchy.GetGlobalControlShapeTransform
// (Final, Native, Public, HasDefaults, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FRigElementKey          InKey_69                       (Parm)
// bool                           bInitial_69                    (Parm, ZeroConstructor, IsPlainOldData)
// struct FCoreUObject_FTransform ReturnValue_69                 (Parm, OutParm, ReturnParm, IsPlainOldData)

struct FCoreUObject_FTransform RigHierarchy::GetGlobalControlShapeTransform(const struct FRigElementKey& InKey_69, bool bInitial_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchy.GetGlobalControlShapeTransform"));

	RigHierarchy_GetGlobalControlShapeTransform_Params params;
	params.InKey_69 = InKey_69;
	params.bInitial_69 = bInitial_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.RigHierarchy.GetGlobalControlOffsetTransformByIndex
// (Final, Native, Public, HasDefaults, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// int                            InElementIndex_69              (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bInitial_69                    (Parm, ZeroConstructor, IsPlainOldData)
// struct FCoreUObject_FTransform ReturnValue_69                 (Parm, OutParm, ReturnParm, IsPlainOldData)

struct FCoreUObject_FTransform RigHierarchy::GetGlobalControlOffsetTransformByIndex(int InElementIndex_69, bool bInitial_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchy.GetGlobalControlOffsetTransformByIndex"));

	RigHierarchy_GetGlobalControlOffsetTransformByIndex_Params params;
	params.InElementIndex_69 = InElementIndex_69;
	params.bInitial_69 = bInitial_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.RigHierarchy.GetGlobalControlOffsetTransform
// (Final, Native, Public, HasDefaults, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FRigElementKey          InKey_69                       (Parm)
// bool                           bInitial_69                    (Parm, ZeroConstructor, IsPlainOldData)
// struct FCoreUObject_FTransform ReturnValue_69                 (Parm, OutParm, ReturnParm, IsPlainOldData)

struct FCoreUObject_FTransform RigHierarchy::GetGlobalControlOffsetTransform(const struct FRigElementKey& InKey_69, bool bInitial_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchy.GetGlobalControlOffsetTransform"));

	RigHierarchy_GetGlobalControlOffsetTransform_Params params;
	params.InKey_69 = InKey_69;
	params.bInitial_69 = bInitial_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.RigHierarchy.GetFloatMetadata
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FRigElementKey          InItem_69                      (Parm)
// struct FName                   InMetadataName_69              (Parm, ZeroConstructor, IsPlainOldData)
// float                          DefaultValue_69                (Parm, ZeroConstructor, IsPlainOldData)
// float                          ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

float RigHierarchy::GetFloatMetadata(const struct FRigElementKey& InItem_69, const struct FName& InMetadataName_69, float DefaultValue_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchy.GetFloatMetadata"));

	RigHierarchy_GetFloatMetadata_Params params;
	params.InItem_69 = InItem_69;
	params.InMetadataName_69 = InMetadataName_69;
	params.DefaultValue_69 = DefaultValue_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.RigHierarchy.GetFloatFromControlValue
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// struct FRigControlValue        InValue_69                     (Parm)
// float                          ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

float RigHierarchy::STATIC_GetFloatFromControlValue(const struct FRigControlValue& InValue_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchy.GetFloatFromControlValue"));

	RigHierarchy_GetFloatFromControlValue_Params params;
	params.InValue_69 = InValue_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.RigHierarchy.GetFloatArrayMetadata
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FRigElementKey          InItem_69                      (Parm)
// struct FName                   InMetadataName_69              (Parm, ZeroConstructor, IsPlainOldData)
// TArray<float>                  ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

TArray<float> RigHierarchy::GetFloatArrayMetadata(const struct FRigElementKey& InItem_69, const struct FName& InMetadataName_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchy.GetFloatArrayMetadata"));

	RigHierarchy_GetFloatArrayMetadata_Params params;
	params.InItem_69 = InItem_69;
	params.InMetadataName_69 = InMetadataName_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.RigHierarchy.GetFirstParent
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FRigElementKey          InKey_69                       (Parm)
// struct FRigElementKey          ReturnValue_69                 (Parm, OutParm, ReturnParm)

struct FRigElementKey RigHierarchy::GetFirstParent(const struct FRigElementKey& InKey_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchy.GetFirstParent"));

	RigHierarchy_GetFirstParent_Params params;
	params.InKey_69 = InKey_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.RigHierarchy.GetEulerTransformFromControlValue
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// struct FRigControlValue        InValue_69                     (Parm)
// struct FEulerTransform         ReturnValue_69                 (Parm, OutParm, ReturnParm)

struct FEulerTransform RigHierarchy::STATIC_GetEulerTransformFromControlValue(const struct FRigControlValue& InValue_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchy.GetEulerTransformFromControlValue"));

	RigHierarchy_GetEulerTransformFromControlValue_Params params;
	params.InValue_69 = InValue_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.RigHierarchy.GetDefaultParent
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FRigElementKey          InKey_69                       (Parm)
// struct FRigElementKey          ReturnValue_69                 (Parm, OutParm, ReturnParm)

struct FRigElementKey RigHierarchy::GetDefaultParent(const struct FRigElementKey& InKey_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchy.GetDefaultParent"));

	RigHierarchy_GetDefaultParent_Params params;
	params.InKey_69 = InKey_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.RigHierarchy.GetCurveValueByIndex
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// int                            InElementIndex_69              (Parm, ZeroConstructor, IsPlainOldData)
// float                          ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

float RigHierarchy::GetCurveValueByIndex(int InElementIndex_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchy.GetCurveValueByIndex"));

	RigHierarchy_GetCurveValueByIndex_Params params;
	params.InElementIndex_69 = InElementIndex_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.RigHierarchy.GetCurveValue
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FRigElementKey          InKey_69                       (Parm)
// float                          ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

float RigHierarchy::GetCurveValue(const struct FRigElementKey& InKey_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchy.GetCurveValue"));

	RigHierarchy_GetCurveValue_Params params;
	params.InKey_69 = InKey_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.RigHierarchy.GetCurveKeys
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// TArray<struct FRigElementKey>  ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

TArray<struct FRigElementKey> RigHierarchy::GetCurveKeys()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchy.GetCurveKeys"));

	RigHierarchy_GetCurveKeys_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.RigHierarchy.GetControlValueByIndex
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// int                            InElementIndex_69              (Parm, ZeroConstructor, IsPlainOldData)
// ERigControlValueType           InValueType_69                 (Parm, ZeroConstructor, IsPlainOldData)
// struct FRigControlValue        ReturnValue_69                 (Parm, OutParm, ReturnParm)

struct FRigControlValue RigHierarchy::GetControlValueByIndex(int InElementIndex_69, ERigControlValueType InValueType_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchy.GetControlValueByIndex"));

	RigHierarchy_GetControlValueByIndex_Params params;
	params.InElementIndex_69 = InElementIndex_69;
	params.InValueType_69 = InValueType_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.RigHierarchy.GetControlValue
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FRigElementKey          InKey_69                       (Parm)
// ERigControlValueType           InValueType_69                 (Parm, ZeroConstructor, IsPlainOldData)
// struct FRigControlValue        ReturnValue_69                 (Parm, OutParm, ReturnParm)

struct FRigControlValue RigHierarchy::GetControlValue(const struct FRigElementKey& InKey_69, ERigControlValueType InValueType_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchy.GetControlValue"));

	RigHierarchy_GetControlValue_Params params;
	params.InKey_69 = InKey_69;
	params.InValueType_69 = InValueType_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.RigHierarchy.GetControlPreferredRotatorByIndex
// (Final, Native, Public, HasDefaults, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// int                            InElementIndex_69              (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bInitial_69                    (Parm, ZeroConstructor, IsPlainOldData)
// struct FRotator                ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

struct FRotator RigHierarchy::GetControlPreferredRotatorByIndex(int InElementIndex_69, bool bInitial_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchy.GetControlPreferredRotatorByIndex"));

	RigHierarchy_GetControlPreferredRotatorByIndex_Params params;
	params.InElementIndex_69 = InElementIndex_69;
	params.bInitial_69 = bInitial_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.RigHierarchy.GetControlPreferredRotator
// (Final, Native, Public, HasDefaults, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FRigElementKey          InKey_69                       (Parm)
// bool                           bInitial_69                    (Parm, ZeroConstructor, IsPlainOldData)
// struct FRotator                ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

struct FRotator RigHierarchy::GetControlPreferredRotator(const struct FRigElementKey& InKey_69, bool bInitial_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchy.GetControlPreferredRotator"));

	RigHierarchy_GetControlPreferredRotator_Params params;
	params.InKey_69 = InKey_69;
	params.bInitial_69 = bInitial_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.RigHierarchy.GetController
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// bool                           bCreateIfNeeded_69             (Parm, ZeroConstructor, IsPlainOldData)
// class RigHierarchyController*  ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

class RigHierarchyController* RigHierarchy::GetController(bool bCreateIfNeeded_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchy.GetController"));

	RigHierarchy_GetController_Params params;
	params.bCreateIfNeeded_69 = bCreateIfNeeded_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.RigHierarchy.GetControlKeys
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// bool                           bTraverse_69                   (Parm, ZeroConstructor, IsPlainOldData)
// TArray<struct FRigElementKey>  ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

TArray<struct FRigElementKey> RigHierarchy::GetControlKeys(bool bTraverse_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchy.GetControlKeys"));

	RigHierarchy_GetControlKeys_Params params;
	params.bTraverse_69 = bTraverse_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.RigHierarchy.GetChildren
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FRigElementKey          InKey_69                       (Parm)
// bool                           bRecursive_69                  (Parm, ZeroConstructor, IsPlainOldData)
// TArray<struct FRigElementKey>  ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

TArray<struct FRigElementKey> RigHierarchy::GetChildren(const struct FRigElementKey& InKey_69, bool bRecursive_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchy.GetChildren"));

	RigHierarchy_GetChildren_Params params;
	params.InKey_69 = InKey_69;
	params.bRecursive_69 = bRecursive_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.RigHierarchy.GetBoolMetadata
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FRigElementKey          InItem_69                      (Parm)
// struct FName                   InMetadataName_69              (Parm, ZeroConstructor, IsPlainOldData)
// bool                           DefaultValue_69                (Parm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool RigHierarchy::GetBoolMetadata(const struct FRigElementKey& InItem_69, const struct FName& InMetadataName_69, bool DefaultValue_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchy.GetBoolMetadata"));

	RigHierarchy_GetBoolMetadata_Params params;
	params.InItem_69 = InItem_69;
	params.InMetadataName_69 = InMetadataName_69;
	params.DefaultValue_69 = DefaultValue_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.RigHierarchy.GetBoolArrayMetadata
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FRigElementKey          InItem_69                      (Parm)
// struct FName                   InMetadataName_69              (Parm, ZeroConstructor, IsPlainOldData)
// TArray<bool>                   ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

TArray<bool> RigHierarchy::GetBoolArrayMetadata(const struct FRigElementKey& InItem_69, const struct FName& InMetadataName_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchy.GetBoolArrayMetadata"));

	RigHierarchy_GetBoolArrayMetadata_Params params;
	params.InItem_69 = InItem_69;
	params.InMetadataName_69 = InMetadataName_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.RigHierarchy.GetBoneKeys
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// bool                           bTraverse_69                   (Parm, ZeroConstructor, IsPlainOldData)
// TArray<struct FRigElementKey>  ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

TArray<struct FRigElementKey> RigHierarchy::GetBoneKeys(bool bTraverse_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchy.GetBoneKeys"));

	RigHierarchy_GetBoneKeys_Params params;
	params.bTraverse_69 = bTraverse_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.RigHierarchy.GetAllKeys_ForBlueprint
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// bool                           bTraverse_69                   (Parm, ZeroConstructor, IsPlainOldData)
// TArray<struct FRigElementKey>  ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

TArray<struct FRigElementKey> RigHierarchy::GetAllKeys_ForBlueprint(bool bTraverse_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchy.GetAllKeys_ForBlueprint"));

	RigHierarchy_GetAllKeys_ForBlueprint_Params params;
	params.bTraverse_69 = bTraverse_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.RigHierarchy.FindNull_ForBlueprintOnly
// (Final, Native, Private, HasOutParms, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FRigElementKey          InKey_69                       (ConstParm, Parm, OutParm, ReferenceParm)
// struct FRigNullElement         ReturnValue_69                 (Parm, OutParm, ReturnParm)

struct FRigNullElement RigHierarchy::FindNull_ForBlueprintOnly(const struct FRigElementKey& InKey_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchy.FindNull_ForBlueprintOnly"));

	RigHierarchy_FindNull_ForBlueprintOnly_Params params;
	params.InKey_69 = InKey_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.RigHierarchy.FindControl_ForBlueprintOnly
// (Final, Native, Private, HasOutParms, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FRigElementKey          InKey_69                       (ConstParm, Parm, OutParm, ReferenceParm)
// struct FRigControlElement      ReturnValue_69                 (Parm, OutParm, ReturnParm)

struct FRigControlElement RigHierarchy::FindControl_ForBlueprintOnly(const struct FRigElementKey& InKey_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchy.FindControl_ForBlueprintOnly"));

	RigHierarchy_FindControl_ForBlueprintOnly_Params params;
	params.InKey_69 = InKey_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.RigHierarchy.FindBone_ForBlueprintOnly
// (Final, Native, Private, HasOutParms, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FRigElementKey          InKey_69                       (ConstParm, Parm, OutParm, ReferenceParm)
// struct FRigBoneElement         ReturnValue_69                 (Parm, OutParm, ReturnParm)

struct FRigBoneElement RigHierarchy::FindBone_ForBlueprintOnly(const struct FRigElementKey& InKey_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchy.FindBone_ForBlueprintOnly"));

	RigHierarchy_FindBone_ForBlueprintOnly_Params params;
	params.InKey_69 = InKey_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.RigHierarchy.CopyPose
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// class RigHierarchy*            InHierarchy_69                 (Parm, ZeroConstructor)
// bool                           bCurrent_69                    (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bInitial_69                    (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bWeights_69                    (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bMatchPoseInGlobalIfNeeded_69  (Parm, ZeroConstructor, IsPlainOldData)

void RigHierarchy::CopyPose(class RigHierarchy* InHierarchy_69, bool bCurrent_69, bool bInitial_69, bool bWeights_69, bool bMatchPoseInGlobalIfNeeded_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchy.CopyPose"));

	RigHierarchy_CopyPose_Params params;
	params.InHierarchy_69 = InHierarchy_69;
	params.bCurrent_69 = bCurrent_69;
	params.bInitial_69 = bInitial_69;
	params.bWeights_69 = bWeights_69;
	params.bMatchPoseInGlobalIfNeeded_69 = bMatchPoseInGlobalIfNeeded_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ControlRig.RigHierarchy.CopyHierarchy
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// class RigHierarchy*            InHierarchy_69                 (Parm, ZeroConstructor)

void RigHierarchy::CopyHierarchy(class RigHierarchy* InHierarchy_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchy.CopyHierarchy"));

	RigHierarchy_CopyHierarchy_Params params;
	params.InHierarchy_69 = InHierarchy_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ControlRig.RigHierarchy.Contains_ForBlueprint
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FRigElementKey          InKey_69                       (Parm)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool RigHierarchy::Contains_ForBlueprint(const struct FRigElementKey& InKey_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchy.Contains_ForBlueprint"));

	RigHierarchy_Contains_ForBlueprint_Params params;
	params.InKey_69 = InKey_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.ControlRigComponent.Update
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// float                          DeltaTime_69                   (Parm, ZeroConstructor, IsPlainOldData)

void ControlRigComponent::Update(float DeltaTime_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.ControlRigComponent.Update"));

	ControlRigComponent_Update_Params params;
	params.DeltaTime_69 = DeltaTime_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ControlRig.ControlRigComponent.SetObjectBinding
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// class Object_32759*            InObjectToBind_69              (Parm, ZeroConstructor)

void ControlRigComponent::SetObjectBinding(class Object_32759* InObjectToBind_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.ControlRigComponent.SetObjectBinding"));

	ControlRigComponent_SetObjectBinding_Params params;
	params.InObjectToBind_69 = InObjectToBind_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ControlRig.ControlRigComponent.SetMappedElements
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// TArray<struct FControlRigComponentMappedElement> NewMappedElements_69           (Parm, ZeroConstructor)

void ControlRigComponent::SetMappedElements(TArray<struct FControlRigComponentMappedElement> NewMappedElements_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.ControlRigComponent.SetMappedElements"));

	ControlRigComponent_SetMappedElements_Params params;
	params.NewMappedElements_69 = NewMappedElements_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ControlRig.ControlRigComponent.SetInitialSpaceTransform
// (Final, Native, Public, HasDefaults, BlueprintCallable)
// Parameters:
// struct FName                   SpaceName_69                   (Parm, ZeroConstructor, IsPlainOldData)
// struct FCoreUObject_FTransform InitialTransform_69            (Parm, IsPlainOldData)
// EControlRigComponentSpace      Space_69                       (Parm, ZeroConstructor, IsPlainOldData)

void ControlRigComponent::SetInitialSpaceTransform(const struct FName& SpaceName_69, const struct FCoreUObject_FTransform& InitialTransform_69, EControlRigComponentSpace Space_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.ControlRigComponent.SetInitialSpaceTransform"));

	ControlRigComponent_SetInitialSpaceTransform_Params params;
	params.SpaceName_69 = SpaceName_69;
	params.InitialTransform_69 = InitialTransform_69;
	params.Space_69 = Space_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ControlRig.ControlRigComponent.SetInitialBoneTransform
// (Final, Native, Public, HasDefaults, BlueprintCallable)
// Parameters:
// struct FName                   BoneName_69                    (Parm, ZeroConstructor, IsPlainOldData)
// struct FCoreUObject_FTransform InitialTransform_69            (Parm, IsPlainOldData)
// EControlRigComponentSpace      Space_69                       (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bPropagateToChildren_69        (Parm, ZeroConstructor, IsPlainOldData)

void ControlRigComponent::SetInitialBoneTransform(const struct FName& BoneName_69, const struct FCoreUObject_FTransform& InitialTransform_69, EControlRigComponentSpace Space_69, bool bPropagateToChildren_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.ControlRigComponent.SetInitialBoneTransform"));

	ControlRigComponent_SetInitialBoneTransform_Params params;
	params.BoneName_69 = BoneName_69;
	params.InitialTransform_69 = InitialTransform_69;
	params.Space_69 = Space_69;
	params.bPropagateToChildren_69 = bPropagateToChildren_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ControlRig.ControlRigComponent.SetControlVector2D
// (Final, Native, Public, HasDefaults, BlueprintCallable)
// Parameters:
// struct FName                   ControlName_69                 (Parm, ZeroConstructor, IsPlainOldData)
// struct FVector2D               Value_69                       (Parm, ZeroConstructor, IsPlainOldData)

void ControlRigComponent::SetControlVector2D(const struct FName& ControlName_69, const struct FVector2D& Value_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.ControlRigComponent.SetControlVector2D"));

	ControlRigComponent_SetControlVector2D_Params params;
	params.ControlName_69 = ControlName_69;
	params.Value_69 = Value_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ControlRig.ControlRigComponent.SetControlTransform
// (Final, Native, Public, HasDefaults, BlueprintCallable)
// Parameters:
// struct FName                   ControlName_69                 (Parm, ZeroConstructor, IsPlainOldData)
// struct FCoreUObject_FTransform Value_69                       (Parm, IsPlainOldData)
// EControlRigComponentSpace      Space_69                       (Parm, ZeroConstructor, IsPlainOldData)

void ControlRigComponent::SetControlTransform(const struct FName& ControlName_69, const struct FCoreUObject_FTransform& Value_69, EControlRigComponentSpace Space_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.ControlRigComponent.SetControlTransform"));

	ControlRigComponent_SetControlTransform_Params params;
	params.ControlName_69 = ControlName_69;
	params.Value_69 = Value_69;
	params.Space_69 = Space_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ControlRig.ControlRigComponent.SetControlScale
// (Final, Native, Public, HasDefaults, BlueprintCallable)
// Parameters:
// struct FName                   ControlName_69                 (Parm, ZeroConstructor, IsPlainOldData)
// struct FVector                 Value_69                       (Parm, ZeroConstructor, IsPlainOldData)
// EControlRigComponentSpace      Space_69                       (Parm, ZeroConstructor, IsPlainOldData)

void ControlRigComponent::SetControlScale(const struct FName& ControlName_69, const struct FVector& Value_69, EControlRigComponentSpace Space_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.ControlRigComponent.SetControlScale"));

	ControlRigComponent_SetControlScale_Params params;
	params.ControlName_69 = ControlName_69;
	params.Value_69 = Value_69;
	params.Space_69 = Space_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ControlRig.ControlRigComponent.SetControlRotator
// (Final, Native, Public, HasDefaults, BlueprintCallable)
// Parameters:
// struct FName                   ControlName_69                 (Parm, ZeroConstructor, IsPlainOldData)
// struct FRotator                Value_69                       (Parm, ZeroConstructor, IsPlainOldData)
// EControlRigComponentSpace      Space_69                       (Parm, ZeroConstructor, IsPlainOldData)

void ControlRigComponent::SetControlRotator(const struct FName& ControlName_69, const struct FRotator& Value_69, EControlRigComponentSpace Space_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.ControlRigComponent.SetControlRotator"));

	ControlRigComponent_SetControlRotator_Params params;
	params.ControlName_69 = ControlName_69;
	params.Value_69 = Value_69;
	params.Space_69 = Space_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ControlRig.ControlRigComponent.SetControlRigClass
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// class ControlRig*              InControlRigClass_69           (Parm, ZeroConstructor)

void ControlRigComponent::SetControlRigClass(class ControlRig* InControlRigClass_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.ControlRigComponent.SetControlRigClass"));

	ControlRigComponent_SetControlRigClass_Params params;
	params.InControlRigClass_69 = InControlRigClass_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ControlRig.ControlRigComponent.SetControlPosition
// (Final, Native, Public, HasDefaults, BlueprintCallable)
// Parameters:
// struct FName                   ControlName_69                 (Parm, ZeroConstructor, IsPlainOldData)
// struct FVector                 Value_69                       (Parm, ZeroConstructor, IsPlainOldData)
// EControlRigComponentSpace      Space_69                       (Parm, ZeroConstructor, IsPlainOldData)

void ControlRigComponent::SetControlPosition(const struct FName& ControlName_69, const struct FVector& Value_69, EControlRigComponentSpace Space_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.ControlRigComponent.SetControlPosition"));

	ControlRigComponent_SetControlPosition_Params params;
	params.ControlName_69 = ControlName_69;
	params.Value_69 = Value_69;
	params.Space_69 = Space_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ControlRig.ControlRigComponent.SetControlOffset
// (Final, Native, Public, HasDefaults, BlueprintCallable)
// Parameters:
// struct FName                   ControlName_69                 (Parm, ZeroConstructor, IsPlainOldData)
// struct FCoreUObject_FTransform OffsetTransform_69             (Parm, IsPlainOldData)
// EControlRigComponentSpace      Space_69                       (Parm, ZeroConstructor, IsPlainOldData)

void ControlRigComponent::SetControlOffset(const struct FName& ControlName_69, const struct FCoreUObject_FTransform& OffsetTransform_69, EControlRigComponentSpace Space_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.ControlRigComponent.SetControlOffset"));

	ControlRigComponent_SetControlOffset_Params params;
	params.ControlName_69 = ControlName_69;
	params.OffsetTransform_69 = OffsetTransform_69;
	params.Space_69 = Space_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ControlRig.ControlRigComponent.SetControlInt
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// struct FName                   ControlName_69                 (Parm, ZeroConstructor, IsPlainOldData)
// int                            Value_69                       (Parm, ZeroConstructor, IsPlainOldData)

void ControlRigComponent::SetControlInt(const struct FName& ControlName_69, int Value_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.ControlRigComponent.SetControlInt"));

	ControlRigComponent_SetControlInt_Params params;
	params.ControlName_69 = ControlName_69;
	params.Value_69 = Value_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ControlRig.ControlRigComponent.SetControlFloat
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// struct FName                   ControlName_69                 (Parm, ZeroConstructor, IsPlainOldData)
// float                          Value_69                       (Parm, ZeroConstructor, IsPlainOldData)

void ControlRigComponent::SetControlFloat(const struct FName& ControlName_69, float Value_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.ControlRigComponent.SetControlFloat"));

	ControlRigComponent_SetControlFloat_Params params;
	params.ControlName_69 = ControlName_69;
	params.Value_69 = Value_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ControlRig.ControlRigComponent.SetControlBool
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// struct FName                   ControlName_69                 (Parm, ZeroConstructor, IsPlainOldData)
// bool                           Value_69                       (Parm, ZeroConstructor, IsPlainOldData)

void ControlRigComponent::SetControlBool(const struct FName& ControlName_69, bool Value_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.ControlRigComponent.SetControlBool"));

	ControlRigComponent_SetControlBool_Params params;
	params.ControlName_69 = ControlName_69;
	params.Value_69 = Value_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ControlRig.ControlRigComponent.SetBoneTransform
// (Final, Native, Public, HasDefaults, BlueprintCallable)
// Parameters:
// struct FName                   BoneName_69                    (Parm, ZeroConstructor, IsPlainOldData)
// struct FCoreUObject_FTransform Transform_69                   (Parm, IsPlainOldData)
// EControlRigComponentSpace      Space_69                       (Parm, ZeroConstructor, IsPlainOldData)
// float                          Weight_69                      (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bPropagateToChildren_69        (Parm, ZeroConstructor, IsPlainOldData)

void ControlRigComponent::SetBoneTransform(const struct FName& BoneName_69, const struct FCoreUObject_FTransform& Transform_69, EControlRigComponentSpace Space_69, float Weight_69, bool bPropagateToChildren_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.ControlRigComponent.SetBoneTransform"));

	ControlRigComponent_SetBoneTransform_Params params;
	params.BoneName_69 = BoneName_69;
	params.Transform_69 = Transform_69;
	params.Space_69 = Space_69;
	params.Weight_69 = Weight_69;
	params.bPropagateToChildren_69 = bPropagateToChildren_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ControlRig.ControlRigComponent.SetBoneInitialTransformsFromSkeletalMesh
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// class SkeletalMesh*            InSkeletalMesh_69              (Parm, ZeroConstructor)

void ControlRigComponent::SetBoneInitialTransformsFromSkeletalMesh(class SkeletalMesh* InSkeletalMesh_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.ControlRigComponent.SetBoneInitialTransformsFromSkeletalMesh"));

	ControlRigComponent_SetBoneInitialTransformsFromSkeletalMesh_Params params;
	params.InSkeletalMesh_69 = InSkeletalMesh_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ControlRig.ControlRigComponent.OnPreInitialize
// (Native, Event, Public, BlueprintEvent)
// Parameters:
// class ControlRigComponent*     Component_69                   (Parm, ZeroConstructor, InstancedReference)

void ControlRigComponent::OnPreInitialize(class ControlRigComponent* Component_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.ControlRigComponent.OnPreInitialize"));

	ControlRigComponent_OnPreInitialize_Params params;
	params.Component_69 = Component_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ControlRig.ControlRigComponent.OnPreForwardsSolve
// (Native, Event, Public, BlueprintEvent)
// Parameters:
// class ControlRigComponent*     Component_69                   (Parm, ZeroConstructor, InstancedReference)

void ControlRigComponent::OnPreForwardsSolve(class ControlRigComponent* Component_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.ControlRigComponent.OnPreForwardsSolve"));

	ControlRigComponent_OnPreForwardsSolve_Params params;
	params.Component_69 = Component_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ControlRig.ControlRigComponent.OnPreConstruction
// (Native, Event, Public, BlueprintEvent)
// Parameters:
// class ControlRigComponent*     Component_69                   (Parm, ZeroConstructor, InstancedReference)

void ControlRigComponent::OnPreConstruction(class ControlRigComponent* Component_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.ControlRigComponent.OnPreConstruction"));

	ControlRigComponent_OnPreConstruction_Params params;
	params.Component_69 = Component_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ControlRig.ControlRigComponent.OnPostInitialize
// (Native, Event, Public, BlueprintEvent)
// Parameters:
// class ControlRigComponent*     Component_69                   (Parm, ZeroConstructor, InstancedReference)

void ControlRigComponent::OnPostInitialize(class ControlRigComponent* Component_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.ControlRigComponent.OnPostInitialize"));

	ControlRigComponent_OnPostInitialize_Params params;
	params.Component_69 = Component_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ControlRig.ControlRigComponent.OnPostForwardsSolve
// (Native, Event, Public, BlueprintEvent)
// Parameters:
// class ControlRigComponent*     Component_69                   (Parm, ZeroConstructor, InstancedReference)

void ControlRigComponent::OnPostForwardsSolve(class ControlRigComponent* Component_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.ControlRigComponent.OnPostForwardsSolve"));

	ControlRigComponent_OnPostForwardsSolve_Params params;
	params.Component_69 = Component_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ControlRig.ControlRigComponent.OnPostConstruction
// (Native, Event, Public, BlueprintEvent)
// Parameters:
// class ControlRigComponent*     Component_69                   (Parm, ZeroConstructor, InstancedReference)

void ControlRigComponent::OnPostConstruction(class ControlRigComponent* Component_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.ControlRigComponent.OnPostConstruction"));

	ControlRigComponent_OnPostConstruction_Params params;
	params.Component_69 = Component_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ControlRig.ControlRigComponent.Initialize
// (Final, Native, Public, BlueprintCallable)

void ControlRigComponent::Initialize()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.ControlRigComponent.Initialize"));

	ControlRigComponent_Initialize_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ControlRig.ControlRigComponent.GetSpaceTransform
// (Final, Native, Public, HasDefaults, BlueprintCallable, BlueprintPure)
// Parameters:
// struct FName                   SpaceName_69                   (Parm, ZeroConstructor, IsPlainOldData)
// EControlRigComponentSpace      Space_69                       (Parm, ZeroConstructor, IsPlainOldData)
// struct FCoreUObject_FTransform ReturnValue_69                 (Parm, OutParm, ReturnParm, IsPlainOldData)

struct FCoreUObject_FTransform ControlRigComponent::GetSpaceTransform(const struct FName& SpaceName_69, EControlRigComponentSpace Space_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.ControlRigComponent.GetSpaceTransform"));

	ControlRigComponent_GetSpaceTransform_Params params;
	params.SpaceName_69 = SpaceName_69;
	params.Space_69 = Space_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.ControlRigComponent.GetInitialSpaceTransform
// (Final, Native, Public, HasDefaults, BlueprintCallable, BlueprintPure)
// Parameters:
// struct FName                   SpaceName_69                   (Parm, ZeroConstructor, IsPlainOldData)
// EControlRigComponentSpace      Space_69                       (Parm, ZeroConstructor, IsPlainOldData)
// struct FCoreUObject_FTransform ReturnValue_69                 (Parm, OutParm, ReturnParm, IsPlainOldData)

struct FCoreUObject_FTransform ControlRigComponent::GetInitialSpaceTransform(const struct FName& SpaceName_69, EControlRigComponentSpace Space_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.ControlRigComponent.GetInitialSpaceTransform"));

	ControlRigComponent_GetInitialSpaceTransform_Params params;
	params.SpaceName_69 = SpaceName_69;
	params.Space_69 = Space_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.ControlRigComponent.GetInitialBoneTransform
// (Final, Native, Public, HasDefaults, BlueprintCallable, BlueprintPure)
// Parameters:
// struct FName                   BoneName_69                    (Parm, ZeroConstructor, IsPlainOldData)
// EControlRigComponentSpace      Space_69                       (Parm, ZeroConstructor, IsPlainOldData)
// struct FCoreUObject_FTransform ReturnValue_69                 (Parm, OutParm, ReturnParm, IsPlainOldData)

struct FCoreUObject_FTransform ControlRigComponent::GetInitialBoneTransform(const struct FName& BoneName_69, EControlRigComponentSpace Space_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.ControlRigComponent.GetInitialBoneTransform"));

	ControlRigComponent_GetInitialBoneTransform_Params params;
	params.BoneName_69 = BoneName_69;
	params.Space_69 = Space_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.ControlRigComponent.GetElementNames
// (Final, Native, Public, BlueprintCallable, BlueprintPure)
// Parameters:
// ERigElementType                ElementType_69                 (Parm, ZeroConstructor, IsPlainOldData)
// TArray<struct FName>           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

TArray<struct FName> ControlRigComponent::GetElementNames(ERigElementType ElementType_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.ControlRigComponent.GetElementNames"));

	ControlRigComponent_GetElementNames_Params params;
	params.ElementType_69 = ElementType_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.ControlRigComponent.GetControlVector2D
// (Final, Native, Public, HasDefaults, BlueprintCallable, BlueprintPure)
// Parameters:
// struct FName                   ControlName_69                 (Parm, ZeroConstructor, IsPlainOldData)
// struct FVector2D               ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

struct FVector2D ControlRigComponent::GetControlVector2D(const struct FName& ControlName_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.ControlRigComponent.GetControlVector2D"));

	ControlRigComponent_GetControlVector2D_Params params;
	params.ControlName_69 = ControlName_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.ControlRigComponent.GetControlTransform
// (Final, Native, Public, HasDefaults, BlueprintCallable, BlueprintPure)
// Parameters:
// struct FName                   ControlName_69                 (Parm, ZeroConstructor, IsPlainOldData)
// EControlRigComponentSpace      Space_69                       (Parm, ZeroConstructor, IsPlainOldData)
// struct FCoreUObject_FTransform ReturnValue_69                 (Parm, OutParm, ReturnParm, IsPlainOldData)

struct FCoreUObject_FTransform ControlRigComponent::GetControlTransform(const struct FName& ControlName_69, EControlRigComponentSpace Space_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.ControlRigComponent.GetControlTransform"));

	ControlRigComponent_GetControlTransform_Params params;
	params.ControlName_69 = ControlName_69;
	params.Space_69 = Space_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.ControlRigComponent.GetControlScale
// (Final, Native, Public, HasDefaults, BlueprintCallable, BlueprintPure)
// Parameters:
// struct FName                   ControlName_69                 (Parm, ZeroConstructor, IsPlainOldData)
// EControlRigComponentSpace      Space_69                       (Parm, ZeroConstructor, IsPlainOldData)
// struct FVector                 ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

struct FVector ControlRigComponent::GetControlScale(const struct FName& ControlName_69, EControlRigComponentSpace Space_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.ControlRigComponent.GetControlScale"));

	ControlRigComponent_GetControlScale_Params params;
	params.ControlName_69 = ControlName_69;
	params.Space_69 = Space_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.ControlRigComponent.GetControlRotator
// (Final, Native, Public, HasDefaults, BlueprintCallable, BlueprintPure)
// Parameters:
// struct FName                   ControlName_69                 (Parm, ZeroConstructor, IsPlainOldData)
// EControlRigComponentSpace      Space_69                       (Parm, ZeroConstructor, IsPlainOldData)
// struct FRotator                ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

struct FRotator ControlRigComponent::GetControlRotator(const struct FName& ControlName_69, EControlRigComponentSpace Space_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.ControlRigComponent.GetControlRotator"));

	ControlRigComponent_GetControlRotator_Params params;
	params.ControlName_69 = ControlName_69;
	params.Space_69 = Space_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.ControlRigComponent.GetControlRig
// (Final, Native, Public, BlueprintCallable, BlueprintPure)
// Parameters:
// class ControlRig*              ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

class ControlRig* ControlRigComponent::GetControlRig()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.ControlRigComponent.GetControlRig"));

	ControlRigComponent_GetControlRig_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.ControlRigComponent.GetControlPosition
// (Final, Native, Public, HasDefaults, BlueprintCallable, BlueprintPure)
// Parameters:
// struct FName                   ControlName_69                 (Parm, ZeroConstructor, IsPlainOldData)
// EControlRigComponentSpace      Space_69                       (Parm, ZeroConstructor, IsPlainOldData)
// struct FVector                 ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

struct FVector ControlRigComponent::GetControlPosition(const struct FName& ControlName_69, EControlRigComponentSpace Space_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.ControlRigComponent.GetControlPosition"));

	ControlRigComponent_GetControlPosition_Params params;
	params.ControlName_69 = ControlName_69;
	params.Space_69 = Space_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.ControlRigComponent.GetControlOffset
// (Final, Native, Public, HasDefaults, BlueprintCallable)
// Parameters:
// struct FName                   ControlName_69                 (Parm, ZeroConstructor, IsPlainOldData)
// EControlRigComponentSpace      Space_69                       (Parm, ZeroConstructor, IsPlainOldData)
// struct FCoreUObject_FTransform ReturnValue_69                 (Parm, OutParm, ReturnParm, IsPlainOldData)

struct FCoreUObject_FTransform ControlRigComponent::GetControlOffset(const struct FName& ControlName_69, EControlRigComponentSpace Space_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.ControlRigComponent.GetControlOffset"));

	ControlRigComponent_GetControlOffset_Params params;
	params.ControlName_69 = ControlName_69;
	params.Space_69 = Space_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.ControlRigComponent.GetControlInt
// (Final, Native, Public, BlueprintCallable, BlueprintPure)
// Parameters:
// struct FName                   ControlName_69                 (Parm, ZeroConstructor, IsPlainOldData)
// int                            ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int ControlRigComponent::GetControlInt(const struct FName& ControlName_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.ControlRigComponent.GetControlInt"));

	ControlRigComponent_GetControlInt_Params params;
	params.ControlName_69 = ControlName_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.ControlRigComponent.GetControlFloat
// (Final, Native, Public, BlueprintCallable, BlueprintPure)
// Parameters:
// struct FName                   ControlName_69                 (Parm, ZeroConstructor, IsPlainOldData)
// float                          ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

float ControlRigComponent::GetControlFloat(const struct FName& ControlName_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.ControlRigComponent.GetControlFloat"));

	ControlRigComponent_GetControlFloat_Params params;
	params.ControlName_69 = ControlName_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.ControlRigComponent.GetControlBool
// (Final, Native, Public, BlueprintCallable, BlueprintPure)
// Parameters:
// struct FName                   ControlName_69                 (Parm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool ControlRigComponent::GetControlBool(const struct FName& ControlName_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.ControlRigComponent.GetControlBool"));

	ControlRigComponent_GetControlBool_Params params;
	params.ControlName_69 = ControlName_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.ControlRigComponent.GetBoneTransform
// (Final, Native, Public, HasDefaults, BlueprintCallable, BlueprintPure)
// Parameters:
// struct FName                   BoneName_69                    (Parm, ZeroConstructor, IsPlainOldData)
// EControlRigComponentSpace      Space_69                       (Parm, ZeroConstructor, IsPlainOldData)
// struct FCoreUObject_FTransform ReturnValue_69                 (Parm, OutParm, ReturnParm, IsPlainOldData)

struct FCoreUObject_FTransform ControlRigComponent::GetBoneTransform(const struct FName& BoneName_69, EControlRigComponentSpace Space_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.ControlRigComponent.GetBoneTransform"));

	ControlRigComponent_GetBoneTransform_Params params;
	params.BoneName_69 = BoneName_69;
	params.Space_69 = Space_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.ControlRigComponent.GetAbsoluteTime
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// float                          ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

float ControlRigComponent::GetAbsoluteTime()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.ControlRigComponent.GetAbsoluteTime"));

	ControlRigComponent_GetAbsoluteTime_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.ControlRigComponent.DoesElementExist
// (Final, Native, Public, BlueprintCallable, BlueprintPure)
// Parameters:
// struct FName                   Name_69                        (Parm, ZeroConstructor, IsPlainOldData)
// ERigElementType                ElementType_69                 (Parm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool ControlRigComponent::DoesElementExist(const struct FName& Name_69, ERigElementType ElementType_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.ControlRigComponent.DoesElementExist"));

	ControlRigComponent_DoesElementExist_Params params;
	params.Name_69 = Name_69;
	params.ElementType_69 = ElementType_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.ControlRigComponent.ClearMappedElements
// (Final, Native, Public, BlueprintCallable)

void ControlRigComponent::ClearMappedElements()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.ControlRigComponent.ClearMappedElements"));

	ControlRigComponent_ClearMappedElements_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ControlRig.ControlRigComponent.CanExecute
// (Final, Native, Public, BlueprintCallable, BlueprintPure)
// Parameters:
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool ControlRigComponent::CanExecute()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.ControlRigComponent.CanExecute"));

	ControlRigComponent_CanExecute_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.ControlRigComponent.AddMappedSkeletalMesh
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// class SkeletalMeshComponent*   SkeletalMeshComponent_69       (Parm, ZeroConstructor, InstancedReference)
// TArray<struct FControlRigComponentMappedBone> Bones_69                       (Parm, ZeroConstructor)
// TArray<struct FControlRigComponentMappedCurve> Curves_69                      (Parm, ZeroConstructor)

void ControlRigComponent::AddMappedSkeletalMesh(class SkeletalMeshComponent* SkeletalMeshComponent_69, TArray<struct FControlRigComponentMappedBone> Bones_69, TArray<struct FControlRigComponentMappedCurve> Curves_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.ControlRigComponent.AddMappedSkeletalMesh"));

	ControlRigComponent_AddMappedSkeletalMesh_Params params;
	params.SkeletalMeshComponent_69 = SkeletalMeshComponent_69;
	params.Bones_69 = Bones_69;
	params.Curves_69 = Curves_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ControlRig.ControlRigComponent.AddMappedElements
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// TArray<struct FControlRigComponentMappedElement> NewMappedElements_69           (Parm, ZeroConstructor)

void ControlRigComponent::AddMappedElements(TArray<struct FControlRigComponentMappedElement> NewMappedElements_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.ControlRigComponent.AddMappedElements"));

	ControlRigComponent_AddMappedElements_Params params;
	params.NewMappedElements_69 = NewMappedElements_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ControlRig.ControlRigComponent.AddMappedComponents
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// TArray<struct FControlRigComponentMappedComponent> Components_69                  (Parm, ZeroConstructor)

void ControlRigComponent::AddMappedComponents(TArray<struct FControlRigComponentMappedComponent> Components_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.ControlRigComponent.AddMappedComponents"));

	ControlRigComponent_AddMappedComponents_Params params;
	params.Components_69 = Components_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ControlRig.ControlRigComponent.AddMappedCompleteSkeletalMesh
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// class SkeletalMeshComponent*   SkeletalMeshComponent_69       (Parm, ZeroConstructor, InstancedReference)

void ControlRigComponent::AddMappedCompleteSkeletalMesh(class SkeletalMeshComponent* SkeletalMeshComponent_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.ControlRigComponent.AddMappedCompleteSkeletalMesh"));

	ControlRigComponent_AddMappedCompleteSkeletalMesh_Params params;
	params.SkeletalMeshComponent_69 = SkeletalMeshComponent_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ControlRig.ControlRigControlActor_32759.Refresh
// (Final, Native, Public, BlueprintCallable)

void ControlRigControlActor_32759::Refresh()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.ControlRigControlActor_32759.Refresh"));

	ControlRigControlActor_32759_Refresh_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ControlRig.ControlRigControlActor_32759.Clear
// (Final, Native, Public, BlueprintCallable)

void ControlRigControlActor_32759::Clear()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.ControlRigControlActor_32759.Clear"));

	ControlRigControlActor_32759_Clear_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ControlRig.ControlRigShapeActor.SetSelected
// (Native, Public, BlueprintCallable)
// Parameters:
// bool                           bInSelected_69                 (Parm, ZeroConstructor, IsPlainOldData)

void ControlRigShapeActor::SetSelected(bool bInSelected_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.ControlRigShapeActor.SetSelected"));

	ControlRigShapeActor_SetSelected_Params params;
	params.bInSelected_69 = bInSelected_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ControlRig.ControlRigShapeActor.SetSelectable
// (Native, Public, BlueprintCallable)
// Parameters:
// bool                           bInSelectable_69               (Parm, ZeroConstructor, IsPlainOldData)

void ControlRigShapeActor::SetSelectable(bool bInSelectable_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.ControlRigShapeActor.SetSelectable"));

	ControlRigShapeActor_SetSelectable_Params params;
	params.bInSelectable_69 = bInSelectable_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ControlRig.ControlRigShapeActor.SetHovered
// (Native, Public, BlueprintCallable)
// Parameters:
// bool                           bInHovered_69                  (Parm, ZeroConstructor, IsPlainOldData)

void ControlRigShapeActor::SetHovered(bool bInHovered_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.ControlRigShapeActor.SetHovered"));

	ControlRigShapeActor_SetHovered_Params params;
	params.bInHovered_69 = bInHovered_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ControlRig.ControlRigShapeActor.SetGlobalTransform
// (Final, Native, Public, HasOutParms, HasDefaults, BlueprintCallable)
// Parameters:
// struct FCoreUObject_FTransform InTransform_69                 (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)

void ControlRigShapeActor::SetGlobalTransform(const struct FCoreUObject_FTransform& InTransform_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.ControlRigShapeActor.SetGlobalTransform"));

	ControlRigShapeActor_SetGlobalTransform_Params params;
	params.InTransform_69 = InTransform_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ControlRig.ControlRigShapeActor.SetEnabled
// (Native, Public, BlueprintCallable)
// Parameters:
// bool                           bInEnabled_69                  (Parm, ZeroConstructor, IsPlainOldData)

void ControlRigShapeActor::SetEnabled(bool bInEnabled_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.ControlRigShapeActor.SetEnabled"));

	ControlRigShapeActor_SetEnabled_Params params;
	params.bInEnabled_69 = bInEnabled_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ControlRig.ControlRigShapeActor.OnTransformChanged
// (Event, Public, HasOutParms, HasDefaults, BlueprintEvent)
// Parameters:
// struct FCoreUObject_FTransform NewTransform_69                (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)

void ControlRigShapeActor::OnTransformChanged(const struct FCoreUObject_FTransform& NewTransform_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.ControlRigShapeActor.OnTransformChanged"));

	ControlRigShapeActor_OnTransformChanged_Params params;
	params.NewTransform_69 = NewTransform_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ControlRig.ControlRigShapeActor.OnSelectionChanged
// (Event, Public, BlueprintEvent)
// Parameters:
// bool                           bIsSelected_69                 (Parm, ZeroConstructor, IsPlainOldData)

void ControlRigShapeActor::OnSelectionChanged(bool bIsSelected_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.ControlRigShapeActor.OnSelectionChanged"));

	ControlRigShapeActor_OnSelectionChanged_Params params;
	params.bIsSelected_69 = bIsSelected_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ControlRig.ControlRigShapeActor.OnManipulatingChanged
// (Event, Public, BlueprintEvent)
// Parameters:
// bool                           bIsManipulating_69             (Parm, ZeroConstructor, IsPlainOldData)

void ControlRigShapeActor::OnManipulatingChanged(bool bIsManipulating_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.ControlRigShapeActor.OnManipulatingChanged"));

	ControlRigShapeActor_OnManipulatingChanged_Params params;
	params.bIsManipulating_69 = bIsManipulating_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ControlRig.ControlRigShapeActor.OnHoveredChanged
// (Event, Public, BlueprintEvent)
// Parameters:
// bool                           bIsSelected_69                 (Parm, ZeroConstructor, IsPlainOldData)

void ControlRigShapeActor::OnHoveredChanged(bool bIsSelected_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.ControlRigShapeActor.OnHoveredChanged"));

	ControlRigShapeActor_OnHoveredChanged_Params params;
	params.bIsSelected_69 = bIsSelected_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ControlRig.ControlRigShapeActor.OnEnabledChanged
// (Event, Public, BlueprintEvent)
// Parameters:
// bool                           bIsEnabled_69                  (Parm, ZeroConstructor, IsPlainOldData)

void ControlRigShapeActor::OnEnabledChanged(bool bIsEnabled_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.ControlRigShapeActor.OnEnabledChanged"));

	ControlRigShapeActor_OnEnabledChanged_Params params;
	params.bIsEnabled_69 = bIsEnabled_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ControlRig.ControlRigShapeActor.IsSelectedInEditor
// (Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool ControlRigShapeActor::IsSelectedInEditor()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.ControlRigShapeActor.IsSelectedInEditor"));

	ControlRigShapeActor_IsSelectedInEditor_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.ControlRigShapeActor.IsHovered
// (Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool ControlRigShapeActor::IsHovered()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.ControlRigShapeActor.IsHovered"));

	ControlRigShapeActor_IsHovered_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.ControlRigShapeActor.IsEnabled
// (Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool ControlRigShapeActor::IsEnabled()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.ControlRigShapeActor.IsEnabled"));

	ControlRigShapeActor_IsEnabled_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.ControlRigShapeActor.GetGlobalTransform
// (Final, Native, Public, HasDefaults, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FCoreUObject_FTransform ReturnValue_69                 (Parm, OutParm, ReturnParm, IsPlainOldData)

struct FCoreUObject_FTransform ControlRigShapeActor::GetGlobalTransform()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.ControlRigShapeActor.GetGlobalTransform"));

	ControlRigShapeActor_GetGlobalTransform_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.RigHierarchyController.SetSelection
// (Final, Native, Public, HasOutParms, BlueprintCallable)
// Parameters:
// TArray<struct FRigElementKey>  InKeys_69                      (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
// bool                           bPrintPythonCommand_69         (Parm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool RigHierarchyController::SetSelection(TArray<struct FRigElementKey> InKeys_69, bool bPrintPythonCommand_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchyController.SetSelection"));

	RigHierarchyController_SetSelection_Params params;
	params.InKeys_69 = InKeys_69;
	params.bPrintPythonCommand_69 = bPrintPythonCommand_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.RigHierarchyController.SetParent
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// struct FRigElementKey          InChild_69                     (Parm)
// struct FRigElementKey          InParent_69                    (Parm)
// bool                           bMaintainGlobalTransform_69    (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bSetupUndo_69                  (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bPrintPythonCommand_69         (Parm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool RigHierarchyController::SetParent(const struct FRigElementKey& InChild_69, const struct FRigElementKey& InParent_69, bool bMaintainGlobalTransform_69, bool bSetupUndo_69, bool bPrintPythonCommand_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchyController.SetParent"));

	RigHierarchyController_SetParent_Params params;
	params.InChild_69 = InChild_69;
	params.InParent_69 = InParent_69;
	params.bMaintainGlobalTransform_69 = bMaintainGlobalTransform_69;
	params.bSetupUndo_69 = bSetupUndo_69;
	params.bPrintPythonCommand_69 = bPrintPythonCommand_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.RigHierarchyController.SetHierarchy
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// class RigHierarchy*            InHierarchy_69                 (Parm, ZeroConstructor)

void RigHierarchyController::SetHierarchy(class RigHierarchy* InHierarchy_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchyController.SetHierarchy"));

	RigHierarchyController_SetHierarchy_Params params;
	params.InHierarchy_69 = InHierarchy_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ControlRig.RigHierarchyController.SetDisplayName
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// struct FRigElementKey          InControl_69                   (Parm)
// struct FName                   InDisplayName_69               (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bRenameElement_69              (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bSetupUndo_69                  (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bPrintPythonCommand_69         (Parm, ZeroConstructor, IsPlainOldData)
// struct FName                   ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

struct FName RigHierarchyController::SetDisplayName(const struct FRigElementKey& InControl_69, const struct FName& InDisplayName_69, bool bRenameElement_69, bool bSetupUndo_69, bool bPrintPythonCommand_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchyController.SetDisplayName"));

	RigHierarchyController_SetDisplayName_Params params;
	params.InControl_69 = InControl_69;
	params.InDisplayName_69 = InDisplayName_69;
	params.bRenameElement_69 = bRenameElement_69;
	params.bSetupUndo_69 = bSetupUndo_69;
	params.bPrintPythonCommand_69 = bPrintPythonCommand_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.RigHierarchyController.SetControlSettings
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FRigElementKey          InKey_69                       (Parm)
// struct FRigControlSettings     InSettings_69                  (Parm)
// bool                           bSetupUndo_69                  (Parm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool RigHierarchyController::SetControlSettings(const struct FRigElementKey& InKey_69, const struct FRigControlSettings& InSettings_69, bool bSetupUndo_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchyController.SetControlSettings"));

	RigHierarchyController_SetControlSettings_Params params;
	params.InKey_69 = InKey_69;
	params.InSettings_69 = InSettings_69;
	params.bSetupUndo_69 = bSetupUndo_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.RigHierarchyController.SelectElement
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// struct FRigElementKey          InKey_69                       (Parm)
// bool                           bSelect_69                     (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bClearSelection_69             (Parm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool RigHierarchyController::SelectElement(const struct FRigElementKey& InKey_69, bool bSelect_69, bool bClearSelection_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchyController.SelectElement"));

	RigHierarchyController_SelectElement_Params params;
	params.InKey_69 = InKey_69;
	params.bSelect_69 = bSelect_69;
	params.bClearSelection_69 = bClearSelection_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.RigHierarchyController.RenameElement
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// struct FRigElementKey          InElement_69                   (Parm)
// struct FName                   InName_69                      (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bSetupUndo_69                  (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bPrintPythonCommand_69         (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bClearSelection_69             (Parm, ZeroConstructor, IsPlainOldData)
// struct FRigElementKey          ReturnValue_69                 (Parm, OutParm, ReturnParm)

struct FRigElementKey RigHierarchyController::RenameElement(const struct FRigElementKey& InElement_69, const struct FName& InName_69, bool bSetupUndo_69, bool bPrintPythonCommand_69, bool bClearSelection_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchyController.RenameElement"));

	RigHierarchyController_RenameElement_Params params;
	params.InElement_69 = InElement_69;
	params.InName_69 = InName_69;
	params.bSetupUndo_69 = bSetupUndo_69;
	params.bPrintPythonCommand_69 = bPrintPythonCommand_69;
	params.bClearSelection_69 = bClearSelection_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.RigHierarchyController.RemoveParent
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// struct FRigElementKey          InChild_69                     (Parm)
// struct FRigElementKey          InParent_69                    (Parm)
// bool                           bMaintainGlobalTransform_69    (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bSetupUndo_69                  (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bPrintPythonCommand_69         (Parm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool RigHierarchyController::RemoveParent(const struct FRigElementKey& InChild_69, const struct FRigElementKey& InParent_69, bool bMaintainGlobalTransform_69, bool bSetupUndo_69, bool bPrintPythonCommand_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchyController.RemoveParent"));

	RigHierarchyController_RemoveParent_Params params;
	params.InChild_69 = InChild_69;
	params.InParent_69 = InParent_69;
	params.bMaintainGlobalTransform_69 = bMaintainGlobalTransform_69;
	params.bSetupUndo_69 = bSetupUndo_69;
	params.bPrintPythonCommand_69 = bPrintPythonCommand_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.RigHierarchyController.RemoveElement
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// struct FRigElementKey          InElement_69                   (Parm)
// bool                           bSetupUndo_69                  (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bPrintPythonCommand_69         (Parm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool RigHierarchyController::RemoveElement(const struct FRigElementKey& InElement_69, bool bSetupUndo_69, bool bPrintPythonCommand_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchyController.RemoveElement"));

	RigHierarchyController_RemoveElement_Params params;
	params.InElement_69 = InElement_69;
	params.bSetupUndo_69 = bSetupUndo_69;
	params.bPrintPythonCommand_69 = bPrintPythonCommand_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.RigHierarchyController.RemoveAllParents
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// struct FRigElementKey          InChild_69                     (Parm)
// bool                           bMaintainGlobalTransform_69    (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bSetupUndo_69                  (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bPrintPythonCommand_69         (Parm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool RigHierarchyController::RemoveAllParents(const struct FRigElementKey& InChild_69, bool bMaintainGlobalTransform_69, bool bSetupUndo_69, bool bPrintPythonCommand_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchyController.RemoveAllParents"));

	RigHierarchyController_RemoveAllParents_Params params;
	params.InChild_69 = InChild_69;
	params.bMaintainGlobalTransform_69 = bMaintainGlobalTransform_69;
	params.bSetupUndo_69 = bSetupUndo_69;
	params.bPrintPythonCommand_69 = bPrintPythonCommand_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.RigHierarchyController.MirrorElements
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// TArray<struct FRigElementKey>  InKeys_69                      (Parm, ZeroConstructor)
// struct FRigMirrorSettings      InSettings_69                  (Parm)
// bool                           bSelectNewElements_69          (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bSetupUndo_69                  (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bPrintPythonCommands_69        (Parm, ZeroConstructor, IsPlainOldData)
// TArray<struct FRigElementKey>  ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

TArray<struct FRigElementKey> RigHierarchyController::MirrorElements(TArray<struct FRigElementKey> InKeys_69, const struct FRigMirrorSettings& InSettings_69, bool bSelectNewElements_69, bool bSetupUndo_69, bool bPrintPythonCommands_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchyController.MirrorElements"));

	RigHierarchyController_MirrorElements_Params params;
	params.InKeys_69 = InKeys_69;
	params.InSettings_69 = InSettings_69;
	params.bSelectNewElements_69 = bSelectNewElements_69;
	params.bSetupUndo_69 = bSetupUndo_69;
	params.bPrintPythonCommands_69 = bPrintPythonCommands_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.RigHierarchyController.ImportFromText
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// struct FString                 InContent_69                   (Parm, ZeroConstructor)
// bool                           bReplaceExistingElements_69    (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bSelectNewElements_69          (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bSetupUndo_69                  (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bPrintPythonCommands_69        (Parm, ZeroConstructor, IsPlainOldData)
// TArray<struct FRigElementKey>  ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

TArray<struct FRigElementKey> RigHierarchyController::ImportFromText(const struct FString& InContent_69, bool bReplaceExistingElements_69, bool bSelectNewElements_69, bool bSetupUndo_69, bool bPrintPythonCommands_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchyController.ImportFromText"));

	RigHierarchyController_ImportFromText_Params params;
	params.InContent_69 = InContent_69;
	params.bReplaceExistingElements_69 = bReplaceExistingElements_69;
	params.bSelectNewElements_69 = bSelectNewElements_69;
	params.bSetupUndo_69 = bSetupUndo_69;
	params.bPrintPythonCommands_69 = bPrintPythonCommands_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.RigHierarchyController.ImportCurves
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// class Skeleton*                InSkeleton_69                  (Parm, ZeroConstructor)
// struct FName                   InNameSpace_69                 (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bSelectCurves_69               (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bSetupUndo_69                  (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bPrintPythonCommand_69         (Parm, ZeroConstructor, IsPlainOldData)
// TArray<struct FRigElementKey>  ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

TArray<struct FRigElementKey> RigHierarchyController::ImportCurves(class Skeleton* InSkeleton_69, const struct FName& InNameSpace_69, bool bSelectCurves_69, bool bSetupUndo_69, bool bPrintPythonCommand_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchyController.ImportCurves"));

	RigHierarchyController_ImportCurves_Params params;
	params.InSkeleton_69 = InSkeleton_69;
	params.InNameSpace_69 = InNameSpace_69;
	params.bSelectCurves_69 = bSelectCurves_69;
	params.bSetupUndo_69 = bSetupUndo_69;
	params.bPrintPythonCommand_69 = bPrintPythonCommand_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.RigHierarchyController.ImportBones
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// class Skeleton*                InSkeleton_69                  (Parm, ZeroConstructor)
// struct FName                   InNameSpace_69                 (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bReplaceExistingBones_69       (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bRemoveObsoleteBones_69        (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bSelectBones_69                (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bSetupUndo_69                  (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bPrintPythonCommand_69         (Parm, ZeroConstructor, IsPlainOldData)
// TArray<struct FRigElementKey>  ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

TArray<struct FRigElementKey> RigHierarchyController::ImportBones(class Skeleton* InSkeleton_69, const struct FName& InNameSpace_69, bool bReplaceExistingBones_69, bool bRemoveObsoleteBones_69, bool bSelectBones_69, bool bSetupUndo_69, bool bPrintPythonCommand_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchyController.ImportBones"));

	RigHierarchyController_ImportBones_Params params;
	params.InSkeleton_69 = InSkeleton_69;
	params.InNameSpace_69 = InNameSpace_69;
	params.bReplaceExistingBones_69 = bReplaceExistingBones_69;
	params.bRemoveObsoleteBones_69 = bRemoveObsoleteBones_69;
	params.bSelectBones_69 = bSelectBones_69;
	params.bSetupUndo_69 = bSetupUndo_69;
	params.bPrintPythonCommand_69 = bPrintPythonCommand_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.RigHierarchyController.GetHierarchy
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// class RigHierarchy*            ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

class RigHierarchy* RigHierarchyController::GetHierarchy()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchyController.GetHierarchy"));

	RigHierarchyController_GetHierarchy_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.RigHierarchyController.GetControlSettings
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FRigElementKey          InKey_69                       (Parm)
// struct FRigControlSettings     ReturnValue_69                 (Parm, OutParm, ReturnParm)

struct FRigControlSettings RigHierarchyController::GetControlSettings(const struct FRigElementKey& InKey_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchyController.GetControlSettings"));

	RigHierarchyController_GetControlSettings_Params params;
	params.InKey_69 = InKey_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.RigHierarchyController.ExportToText
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// TArray<struct FRigElementKey>  InKeys_69                      (Parm, ZeroConstructor)
// struct FString                 ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString RigHierarchyController::ExportToText(TArray<struct FRigElementKey> InKeys_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchyController.ExportToText"));

	RigHierarchyController_ExportToText_Params params;
	params.InKeys_69 = InKeys_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.RigHierarchyController.ExportSelectionToText
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FString                 ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString RigHierarchyController::ExportSelectionToText()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchyController.ExportSelectionToText"));

	RigHierarchyController_ExportSelectionToText_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.RigHierarchyController.DuplicateElements
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// TArray<struct FRigElementKey>  InKeys_69                      (Parm, ZeroConstructor)
// bool                           bSelectNewElements_69          (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bSetupUndo_69                  (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bPrintPythonCommands_69        (Parm, ZeroConstructor, IsPlainOldData)
// TArray<struct FRigElementKey>  ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

TArray<struct FRigElementKey> RigHierarchyController::DuplicateElements(TArray<struct FRigElementKey> InKeys_69, bool bSelectNewElements_69, bool bSetupUndo_69, bool bPrintPythonCommands_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchyController.DuplicateElements"));

	RigHierarchyController_DuplicateElements_Params params;
	params.InKeys_69 = InKeys_69;
	params.bSelectNewElements_69 = bSelectNewElements_69;
	params.bSetupUndo_69 = bSetupUndo_69;
	params.bPrintPythonCommands_69 = bPrintPythonCommands_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.RigHierarchyController.DeselectElement
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// struct FRigElementKey          InKey_69                       (Parm)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool RigHierarchyController::DeselectElement(const struct FRigElementKey& InKey_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchyController.DeselectElement"));

	RigHierarchyController_DeselectElement_Params params;
	params.InKey_69 = InKey_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.RigHierarchyController.ClearSelection
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool RigHierarchyController::ClearSelection()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchyController.ClearSelection"));

	RigHierarchyController_ClearSelection_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.RigHierarchyController.AddRigidBody
// (Final, Native, Public, HasDefaults, BlueprintCallable)
// Parameters:
// struct FName                   InName_69                      (Parm, ZeroConstructor, IsPlainOldData)
// struct FRigElementKey          InParent_69                    (Parm)
// struct FRigRigidBodySettings   InSettings_69                  (Parm)
// struct FCoreUObject_FTransform InLocalTransform_69            (Parm, IsPlainOldData)
// bool                           bSetupUndo_69                  (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bPrintPythonCommand_69         (Parm, ZeroConstructor, IsPlainOldData)
// struct FRigElementKey          ReturnValue_69                 (Parm, OutParm, ReturnParm)

struct FRigElementKey RigHierarchyController::AddRigidBody(const struct FName& InName_69, const struct FRigElementKey& InParent_69, const struct FRigRigidBodySettings& InSettings_69, const struct FCoreUObject_FTransform& InLocalTransform_69, bool bSetupUndo_69, bool bPrintPythonCommand_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchyController.AddRigidBody"));

	RigHierarchyController_AddRigidBody_Params params;
	params.InName_69 = InName_69;
	params.InParent_69 = InParent_69;
	params.InSettings_69 = InSettings_69;
	params.InLocalTransform_69 = InLocalTransform_69;
	params.bSetupUndo_69 = bSetupUndo_69;
	params.bPrintPythonCommand_69 = bPrintPythonCommand_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.RigHierarchyController.AddParent
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// struct FRigElementKey          InChild_69                     (Parm)
// struct FRigElementKey          InParent_69                    (Parm)
// float                          InWeight_69                    (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bMaintainGlobalTransform_69    (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bSetupUndo_69                  (Parm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool RigHierarchyController::AddParent(const struct FRigElementKey& InChild_69, const struct FRigElementKey& InParent_69, float InWeight_69, bool bMaintainGlobalTransform_69, bool bSetupUndo_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchyController.AddParent"));

	RigHierarchyController_AddParent_Params params;
	params.InChild_69 = InChild_69;
	params.InParent_69 = InParent_69;
	params.InWeight_69 = InWeight_69;
	params.bMaintainGlobalTransform_69 = bMaintainGlobalTransform_69;
	params.bSetupUndo_69 = bSetupUndo_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.RigHierarchyController.AddNull
// (Final, Native, Public, HasDefaults, BlueprintCallable)
// Parameters:
// struct FName                   InName_69                      (Parm, ZeroConstructor, IsPlainOldData)
// struct FRigElementKey          InParent_69                    (Parm)
// struct FCoreUObject_FTransform InTransform_69                 (Parm, IsPlainOldData)
// bool                           bTransformInGlobal_69          (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bSetupUndo_69                  (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bPrintPythonCommand_69         (Parm, ZeroConstructor, IsPlainOldData)
// struct FRigElementKey          ReturnValue_69                 (Parm, OutParm, ReturnParm)

struct FRigElementKey RigHierarchyController::AddNull(const struct FName& InName_69, const struct FRigElementKey& InParent_69, const struct FCoreUObject_FTransform& InTransform_69, bool bTransformInGlobal_69, bool bSetupUndo_69, bool bPrintPythonCommand_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchyController.AddNull"));

	RigHierarchyController_AddNull_Params params;
	params.InName_69 = InName_69;
	params.InParent_69 = InParent_69;
	params.InTransform_69 = InTransform_69;
	params.bTransformInGlobal_69 = bTransformInGlobal_69;
	params.bSetupUndo_69 = bSetupUndo_69;
	params.bPrintPythonCommand_69 = bPrintPythonCommand_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.RigHierarchyController.AddCurve
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// struct FName                   InName_69                      (Parm, ZeroConstructor, IsPlainOldData)
// float                          InValue_69                     (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bSetupUndo_69                  (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bPrintPythonCommand_69         (Parm, ZeroConstructor, IsPlainOldData)
// struct FRigElementKey          ReturnValue_69                 (Parm, OutParm, ReturnParm)

struct FRigElementKey RigHierarchyController::AddCurve(const struct FName& InName_69, float InValue_69, bool bSetupUndo_69, bool bPrintPythonCommand_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchyController.AddCurve"));

	RigHierarchyController_AddCurve_Params params;
	params.InName_69 = InName_69;
	params.InValue_69 = InValue_69;
	params.bSetupUndo_69 = bSetupUndo_69;
	params.bPrintPythonCommand_69 = bPrintPythonCommand_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.RigHierarchyController.AddControl_ForBlueprint
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// struct FName                   InName_69                      (Parm, ZeroConstructor, IsPlainOldData)
// struct FRigElementKey          InParent_69                    (Parm)
// struct FRigControlSettings     InSettings_69                  (Parm)
// struct FRigControlValue        InValue_69                     (Parm)
// bool                           bSetupUndo_69                  (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bPrintPythonCommand_69         (Parm, ZeroConstructor, IsPlainOldData)
// struct FRigElementKey          ReturnValue_69                 (Parm, OutParm, ReturnParm)

struct FRigElementKey RigHierarchyController::AddControl_ForBlueprint(const struct FName& InName_69, const struct FRigElementKey& InParent_69, const struct FRigControlSettings& InSettings_69, const struct FRigControlValue& InValue_69, bool bSetupUndo_69, bool bPrintPythonCommand_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchyController.AddControl_ForBlueprint"));

	RigHierarchyController_AddControl_ForBlueprint_Params params;
	params.InName_69 = InName_69;
	params.InParent_69 = InParent_69;
	params.InSettings_69 = InSettings_69;
	params.InValue_69 = InValue_69;
	params.bSetupUndo_69 = bSetupUndo_69;
	params.bPrintPythonCommand_69 = bPrintPythonCommand_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.RigHierarchyController.AddBone
// (Final, Native, Public, HasDefaults, BlueprintCallable)
// Parameters:
// struct FName                   InName_69                      (Parm, ZeroConstructor, IsPlainOldData)
// struct FRigElementKey          InParent_69                    (Parm)
// struct FCoreUObject_FTransform InTransform_69                 (Parm, IsPlainOldData)
// bool                           bTransformInGlobal_69          (Parm, ZeroConstructor, IsPlainOldData)
// ERigBoneType                   InBoneType_69                  (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bSetupUndo_69                  (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bPrintPythonCommand_69         (Parm, ZeroConstructor, IsPlainOldData)
// struct FRigElementKey          ReturnValue_69                 (Parm, OutParm, ReturnParm)

struct FRigElementKey RigHierarchyController::AddBone(const struct FName& InName_69, const struct FRigElementKey& InParent_69, const struct FCoreUObject_FTransform& InTransform_69, bool bTransformInGlobal_69, ERigBoneType InBoneType_69, bool bSetupUndo_69, bool bPrintPythonCommand_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchyController.AddBone"));

	RigHierarchyController_AddBone_Params params;
	params.InName_69 = InName_69;
	params.InParent_69 = InParent_69;
	params.InTransform_69 = InTransform_69;
	params.bTransformInGlobal_69 = bTransformInGlobal_69;
	params.InBoneType_69 = InBoneType_69;
	params.bSetupUndo_69 = bSetupUndo_69;
	params.bPrintPythonCommand_69 = bPrintPythonCommand_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.RigHierarchyController.AddAnimationChannel_ForBlueprint
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// struct FName                   InName_69                      (Parm, ZeroConstructor, IsPlainOldData)
// struct FRigElementKey          InParentControl_69             (Parm)
// struct FRigControlSettings     InSettings_69                  (Parm)
// bool                           bSetupUndo_69                  (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bPrintPythonCommand_69         (Parm, ZeroConstructor, IsPlainOldData)
// struct FRigElementKey          ReturnValue_69                 (Parm, OutParm, ReturnParm)

struct FRigElementKey RigHierarchyController::AddAnimationChannel_ForBlueprint(const struct FName& InName_69, const struct FRigElementKey& InParentControl_69, const struct FRigControlSettings& InSettings_69, bool bSetupUndo_69, bool bPrintPythonCommand_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.RigHierarchyController.AddAnimationChannel_ForBlueprint"));

	RigHierarchyController_AddAnimationChannel_ForBlueprint_Params params;
	params.InName_69 = InName_69;
	params.InParentControl_69 = InParentControl_69;
	params.InSettings_69 = InSettings_69;
	params.bSetupUndo_69 = bSetupUndo_69;
	params.bPrintPythonCommand_69 = bPrintPythonCommand_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.ControlRigPoseAsset.SelectControls
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// class ControlRig*              InControlRig_69                (Parm, ZeroConstructor)
// bool                           bDoMirror_69                   (Parm, ZeroConstructor, IsPlainOldData)

void ControlRigPoseAsset::SelectControls(class ControlRig* InControlRig_69, bool bDoMirror_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.ControlRigPoseAsset.SelectControls"));

	ControlRigPoseAsset_SelectControls_Params params;
	params.InControlRig_69 = InControlRig_69;
	params.bDoMirror_69 = bDoMirror_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ControlRig.ControlRigPoseAsset.SavePose
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// class ControlRig*              InControlRig_69                (Parm, ZeroConstructor)
// bool                           bUseAll_69                     (Parm, ZeroConstructor, IsPlainOldData)

void ControlRigPoseAsset::SavePose(class ControlRig* InControlRig_69, bool bUseAll_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.ControlRigPoseAsset.SavePose"));

	ControlRigPoseAsset_SavePose_Params params;
	params.InControlRig_69 = InControlRig_69;
	params.bUseAll_69 = bUseAll_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ControlRig.ControlRigPoseAsset.ReplaceControlName
// (Final, Native, Public, HasOutParms, BlueprintCallable)
// Parameters:
// struct FName                   CurrentName_69                 (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
// struct FName                   NewName_69                     (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)

void ControlRigPoseAsset::ReplaceControlName(const struct FName& CurrentName_69, const struct FName& NewName_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.ControlRigPoseAsset.ReplaceControlName"));

	ControlRigPoseAsset_ReplaceControlName_Params params;
	params.CurrentName_69 = CurrentName_69;
	params.NewName_69 = NewName_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ControlRig.ControlRigPoseAsset.PastePose
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// class ControlRig*              InControlRig_69                (Parm, ZeroConstructor)
// bool                           bDoKey_69                      (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bDoMirror_69                   (Parm, ZeroConstructor, IsPlainOldData)

void ControlRigPoseAsset::PastePose(class ControlRig* InControlRig_69, bool bDoKey_69, bool bDoMirror_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.ControlRigPoseAsset.PastePose"));

	ControlRigPoseAsset_PastePose_Params params;
	params.InControlRig_69 = InControlRig_69;
	params.bDoKey_69 = bDoKey_69;
	params.bDoMirror_69 = bDoMirror_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ControlRig.ControlRigPoseAsset.GetCurrentPose
// (Final, Native, Public, HasOutParms, BlueprintCallable)
// Parameters:
// class ControlRig*              InControlRig_69                (Parm, ZeroConstructor)
// struct FControlRigControlPose  OutPose_69                     (Parm, OutParm)

void ControlRigPoseAsset::GetCurrentPose(class ControlRig* InControlRig_69, struct FControlRigControlPose* OutPose_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.ControlRigPoseAsset.GetCurrentPose"));

	ControlRigPoseAsset_GetCurrentPose_Params params;
	params.InControlRig_69 = InControlRig_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (OutPose_69 != nullptr)
		*OutPose_69 = params.OutPose_69;
}


// Function ControlRig.ControlRigPoseAsset.GetControlNames
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// TArray<struct FName>           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

TArray<struct FName> ControlRigPoseAsset::GetControlNames()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.ControlRigPoseAsset.GetControlNames"));

	ControlRigPoseAsset_GetControlNames_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.ControlRigPoseAsset.DoesMirrorMatch
// (Final, Native, Public, HasOutParms, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// class ControlRig*              ControlRig_69                  (Parm, ZeroConstructor)
// struct FName                   ControlName_69                 (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool ControlRigPoseAsset::DoesMirrorMatch(class ControlRig* ControlRig_69, const struct FName& ControlName_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.ControlRigPoseAsset.DoesMirrorMatch"));

	ControlRigPoseAsset_DoesMirrorMatch_Params params;
	params.ControlRig_69 = ControlRig_69;
	params.ControlName_69 = ControlName_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.ControlRigWorkflowOptions.EnsureAtLeastOneRigElementSelected
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool ControlRigWorkflowOptions::EnsureAtLeastOneRigElementSelected()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.ControlRigWorkflowOptions.EnsureAtLeastOneRigElementSelected"));

	ControlRigWorkflowOptions_EnsureAtLeastOneRigElementSelected_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ControlRig.ControlRigTransformWorkflowOptions.ProvideWorkflows
// (Final, Native, Public)
// Parameters:
// class Object_32759*            InSubject_69                   (ConstParm, Parm, ZeroConstructor)
// TArray<struct FRigVMUserWorkflow> ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

TArray<struct FRigVMUserWorkflow> ControlRigTransformWorkflowOptions::ProvideWorkflows(class Object_32759* InSubject_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ControlRig.ControlRigTransformWorkflowOptions.ProvideWorkflows"));

	ControlRigTransformWorkflowOptions_ProvideWorkflows_Params params;
	params.InSubject_69 = InSubject_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Enums
//---------------------------------------------------------------------------

// Enum ChromeSharedRuntime.ELacklusterActorType
enum class ELacklusterActorType : uint8_t
{
	Undefined                      = 0,
	GenericChrome                  = 1,
	BuildingRoof                   = 2,
	BuildingWall                   = 3,
	BuildingPropWall               = 4,
	BuildingCorner                 = 5,
	BuildingFloor                  = 6,
	BuildingProp                   = 7,
	BuildingDeco                   = 8,
	BuildingPillar                 = 9,
	ParentTreeApollo               = 10,
	ParentTreeApolloTrunk          = 11,
	StaticMeshActor                = 12,
	ArtemisHedgeParent             = 13,
	ArtemisHedgeParentMasked       = 14,
	PropPlantShrubParent           = 15,
	TieredChestAthena              = 16,
	TieredAmmoAthena               = 17,
	FenceChainlinkParent           = 18,
	BigBush                        = 19,
	AI                             = 20,
	AI_Grandma                     = 21,
	Cornfield                      = 22,
	Valet                          = 23,
	ValetChonkers                  = 24,
	Vehicle                        = 25,
	AI_Avian                       = 26,
	BuildingProp_TwoSided          = 27,
	Prop_FortressBaseMaterial      = 28,
	BuildingProp_TwoSided_Masked   = 29,
	BuildingActor                  = 30,
	Jungle                         = 31,
	InteractableProp               = 32,
	HeraldsFortress                = 33,
	HeraldsFortressCrystals        = 34,
	ChromeDirectionalLaunchpad     = 35,
	SearchLights                   = 36,
	AI_Shark                       = 37,
	Buildable                      = 38,
	IceCreamTruck                  = 39,
	ELacklusterActorType_MAX       = 40
};


// Enum ChromeSharedRuntime.ELacklusterChromeType
enum class ELacklusterChromeType : uint8_t
{
	Chrome                         = 0,
	ChromePhaseable                = 1,
	ChromePhaseableMasked          = 2,
	ChromeGeneric                  = 3,
	ChromePetrified                = 4,
	ELacklusterChromeType_MAX      = 5
};


// Enum ChromeSharedRuntime.ELacklusterTextureGroup
enum class ELacklusterTextureGroup : uint8_t
{
	Normals                        = 0,
	Normals_4layer_2nd             = 1,
	Normals_4layer_3rd             = 2,
	Normals_4layer_4th             = 3,
	Diffuse                        = 4,
	Diffuse_4layer_2nd             = 5,
	Diffuse_4layer_3rd             = 6,
	Diffuse_4Layer_4th             = 7,
	OpacityMask                    = 8,
	Emissive                       = 9,
	Specular                       = 10,
	GmapOrEmissiveOrLights         = 11,
	VertexPaint_Color              = 12,
	VertexPaint_RGBMask            = 13,
	VertexPaint_Normal             = 14,
	ELacklusterTextureGroup_MAX    = 15
};



//---------------------------------------------------------------------------
//Script Structs
//---------------------------------------------------------------------------

// ScriptStruct ChromeSharedRuntime.FortChromeComponentData
// 0x0070
struct FFortChromeComponentData
{
	unsigned char                                      UnknownData00[0x28];                                      // 0x0000(0x0028) UNKNOWN PROPERTY: SoftClassProperty ChromeSharedRuntime.FortChromeComponentData.ChromeComponent_69
	struct FGameplayTagQuery                           ChromeTagQuery_69;                                        // 0x0028(0x0048) (Edit, DisableEditOnInstance)
};

// ScriptStruct ChromeSharedRuntime.LacklusterMaterialData
// 0x0068
struct FLacklusterMaterialData
{
	class MeshComponent*                               MeshComponent_69;                                         // 0x0000(0x0008) (Edit, BlueprintVisible, ExportObject, ZeroConstructor, DisableEditOnInstance, InstancedReference)
	TMap<struct FName, class Texture*>                 SetTexture_69;                                            // 0x0008(0x0050) (Edit, BlueprintVisible, DisableEditOnInstance)
	int                                                MaterialIndex_69;                                         // 0x0058(0x0004) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	bool                                               bIsMaskedMaterial_69;                                     // 0x005C(0x0001) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	bool                                               bIsChonkers_69;                                           // 0x005D(0x0001) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	ELacklusterActorType                               ActorType_69;                                             // 0x005E(0x0001) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData00[0x1];                                       // 0x005F(0x0001) MISSED OFFSET
	class Actor_32759*                                 Actor_69;                                                 // 0x0060(0x0008) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance)
};

// ScriptStruct ChromeSharedRuntime.LacklusterOriginalMaterialData
// 0x0020
struct FLacklusterOriginalMaterialData
{
	class MeshComponent*                               MeshComponent_69;                                         // 0x0000(0x0008) (Edit, BlueprintVisible, ExportObject, ZeroConstructor, DisableEditOnInstance, InstancedReference)
	class MaterialInterface*                           Material_69;                                              // 0x0008(0x0008) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance)
	int                                                MaterialIndex_69;                                         // 0x0010(0x0004) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0014(0x0004) MISSED OFFSET
	class Actor_32759*                                 Actor_69;                                                 // 0x0018(0x0008) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance)
};

// ScriptStruct ChromeSharedRuntime.ClassToActorType
// 0x0010
struct FClassToActorType
{
	class Object_32759*                                Class_69;                                                 // 0x0000(0x0008) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance)
	ELacklusterActorType                               ActorType_69;                                             // 0x0008(0x0001) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0009(0x0007) MISSED OFFSET
};

// ScriptStruct ChromeSharedRuntime.ChromeTypeToMaterial
// 0x0058
struct FChromeTypeToMaterial
{
	class MaterialInterface*                           MaterialForAllTypes_69;                                   // 0x0000(0x0008) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance)
	TMap<ELacklusterChromeType, class MaterialInterface*> ChromeTypeToMaterial_69;                                  // 0x0008(0x0050) (Edit, BlueprintVisible, DisableEditOnInstance)
};

// ScriptStruct ChromeSharedRuntime.LacklusterTextureSet
// 0x0008
struct FLacklusterTextureSet
{
	struct FName                                       GetParameter_69;                                          // 0x0000(0x0008) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	ELacklusterTextureGroup                            TextureGroup_69;                                          // 0x0004(0x0001) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0005(0x0003) MISSED OFFSET
};

// ScriptStruct ChromeSharedRuntime.ChromeTextureSetArray
// 0x0010
struct FChromeTextureSetArray
{
	TArray<struct FLacklusterTextureSet>               TextureSets_69;                                           // 0x0000(0x0010) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance)
};

// ScriptStruct ChromeSharedRuntime.TagQueryToChromeTypeOverride
// 0x0050
struct FTagQueryToChromeTypeOverride
{
	struct FGameplayTagQuery                           TagQuery_69;                                              // 0x0000(0x0048) (Edit, BlueprintVisible, DisableEditOnInstance)
	ELacklusterChromeType                              ChromeType_69;                                            // 0x0048(0x0001) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0049(0x0007) MISSED OFFSET
};

// ScriptStruct ChromeSharedRuntime.LacklusterMaterialsAndTypes
// 0x00D0
struct FLacklusterMaterialsAndTypes
{
	ELacklusterActorType                               ActorType_69;                                             // 0x0000(0x0001) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	ELacklusterChromeType                              ChromeType_69;                                            // 0x0001(0x0001) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x6];                                       // 0x0002(0x0006) MISSED OFFSET
	TArray<struct FLacklusterMaterialData>             ChromeMaterialData_69;                                    // 0x0008(0x0010) (BlueprintVisible, ZeroConstructor)
	TArray<struct FLacklusterOriginalMaterialData>     OriginalMaterialData_69;                                  // 0x0018(0x0010) (BlueprintVisible, ZeroConstructor)
	TMap<struct FName, float>                          ContainerMatScalarParamMap_69;                            // 0x0028(0x0050) (BlueprintVisible)
	TMap<struct FName, struct FLinearColor>            ContainerMatVectorParamMap_69;                            // 0x0078(0x0050) (BlueprintVisible)
	unsigned char                                      UnknownData01[0x8];                                       // 0x00C8(0x0008) MISSED OFFSET
};

// ScriptStruct ChromeSharedRuntime.LacklusterData
// 0x0360
struct FLacklusterData
{
	unsigned char                                      UnknownData00[0x28];                                      // 0x0000(0x0028) UNKNOWN PROPERTY: SoftClassProperty ChromeSharedRuntime.LacklusterData.ApplyChromeClassPath_69
	unsigned char                                      UnknownData01[0x28];                                      // 0x0028(0x0028) UNKNOWN PROPERTY: SoftClassProperty ChromeSharedRuntime.LacklusterData.ChromeAudioClassPath_69
	TArray<struct FString>                             MaterialsToIgnore_69;                                     // 0x0050(0x0010) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance)
	TMap<ELacklusterTextureGroup, struct FName>        SetParameterNames_69;                                     // 0x0060(0x0050) (Edit, BlueprintVisible, DisableEditOnInstance)
	TArray<struct FClassToActorType>                   ClassesToActorTypes_69;                                   // 0x00B0(0x0010) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance)
	TMap<ELacklusterActorType, struct FChromeTypeToMaterial> ChromeMaterialOverrides_69;                               // 0x00C0(0x0050) (Edit, BlueprintVisible, DisableEditOnInstance)
	TMap<ELacklusterActorType, struct FChromeTextureSetArray> ActorToTextures_69;                                       // 0x0110(0x0050) (Edit, BlueprintVisible, DisableEditOnInstance)
	TArray<struct FTagQueryToChromeTypeOverride>       TagQueryToChromeTypeOverrides_69;                         // 0x0160(0x0010) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance)
	TMap<struct FName, ELacklusterActorType>           TagToActorTypes_69;                                       // 0x0170(0x0050) (Edit, BlueprintVisible, DisableEditOnInstance)
	class MaterialInstance*                            GenericChromeMaterial_69;                                 // 0x01C0(0x0008) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance)
	struct FGameplayTagContainer                       NoAnimChestMaterialTags_69;                               // 0x01C8(0x0020) (Edit, BlueprintVisible, DisableEditOnInstance)
	class MaterialInstance*                            ChromeAnimChestMaterial_69;                               // 0x01E8(0x0008) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance)
	class MaterialInstance*                            ChromeNoAnimChestMaterial_69;                             // 0x01F0(0x0008) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance)
	TMap<class Actor_32759*, bool>                     BuildingChromeApplied_69;                                 // 0x01F8(0x0050) (Edit, BlueprintVisible, DisableEditOnInstance)
	class SoundBase*                                   BuildingSMActorHitSound_69;                               // 0x0248(0x0008) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance)
	class SoundBase*                                   BuildingSMActorPropDeathSound_69;                         // 0x0250(0x0008) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance)
	class SoundBase*                                   BuildingSMActorNonPropDeathSound_69;                      // 0x0258(0x0008) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance)
	class SoundBase*                                   BuildingSMActorPropChromedSound_69;                       // 0x0260(0x0008) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance)
	class SoundBase*                                   BuildingSMActorNonPropChromedSound_69;                    // 0x0268(0x0008) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance)
	unsigned char                                      UnknownData02[0x8];                                       // 0x0270(0x0008) UNKNOWN PROPERTY: ClassPtrProperty ChromeSharedRuntime.LacklusterData.TieredChestClass_69
	unsigned char                                      UnknownData03[0x8];                                       // 0x0278(0x0008) UNKNOWN PROPERTY: ClassPtrProperty ChromeSharedRuntime.LacklusterData.TieredChestParentClass_69
	TMap<class Actor_32759*, class ActorComponent*>    ChromeSoundComponents_69;                                 // 0x0280(0x0050) (Edit, BlueprintVisible, ExportObject, DisableEditOnInstance)
	class StaticMeshComponent*                         ShadowProxyMeshComponentClass_69;                         // 0x02D0(0x0008) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance)
	TMap<class Actor_32759*, struct FLacklusterMaterialsAndTypes> MaterialsAndTypes_69;                                     // 0x02D8(0x0050) (BlueprintVisible)
	struct FGameplayTag                                OffroadTireTag_69;                                        // 0x0328(0x0004) (Edit, BlueprintVisible, DisableEditOnInstance)
	unsigned char                                      UnknownData04[0x4];                                       // 0x032C(0x0004) MISSED OFFSET
	struct FGameplayTagContainer                       ContainerTags_69;                                         // 0x0330(0x0020) (Edit, BlueprintVisible, DisableEditOnInstance)
	class FortChromeSubsystem*                         ChromeSubsystemClass_69;                                  // 0x0350(0x0008) (Edit, ZeroConstructor, DisableEditOnInstance)
	bool                                               bIsInitialized_69;                                        // 0x0358(0x0001) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData05[0x7];                                       // 0x0359(0x0007) MISSED OFFSET
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Functions
//---------------------------------------------------------------------------

// Function AutomationUtils.AutomationUtilsBlueprintLibrary.TakeGameplayAutomationScreenshot
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// struct FString                 ScreenshotName_69              (ConstParm, Parm, ZeroConstructor)
// float                          MaxGlobalError_69              (Parm, ZeroConstructor, IsPlainOldData)
// float                          MaxLocalError_69               (Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 MapNameOverride_69             (Parm, ZeroConstructor)

void AutomationUtilsBlueprintLibrary::STATIC_TakeGameplayAutomationScreenshot(const struct FString& ScreenshotName_69, float MaxGlobalError_69, float MaxLocalError_69, const struct FString& MapNameOverride_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AutomationUtils.AutomationUtilsBlueprintLibrary.TakeGameplayAutomationScreenshot"));

	AutomationUtilsBlueprintLibrary_TakeGameplayAutomationScreenshot_Params params;
	params.ScreenshotName_69 = ScreenshotName_69;
	params.MaxGlobalError_69 = MaxGlobalError_69;
	params.MaxLocalError_69 = MaxLocalError_69;
	params.MapNameOverride_69 = MapNameOverride_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function CampsiteUI.CampsiteMarkerInfoBase.SetPlayerState
struct CampsiteMarkerInfoBase_SetPlayerState_Params
{
	class FortPlayerStateAthena*                       InPlayerState_69;                                         // (Parm, ZeroConstructor)
};

// Function CampsiteUI.CampsiteMarkerInfoBase.OnSetPlayerState
struct CampsiteMarkerInfoBase_OnSetPlayerState_Params
{
	class FortPlayerStateAthena*                       PSA_69;                                                   // (Parm, ZeroConstructor)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

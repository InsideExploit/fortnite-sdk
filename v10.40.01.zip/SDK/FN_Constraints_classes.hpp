#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Classes
//---------------------------------------------------------------------------

// Class Constraints.TransformableHandle
// 0x0018 (0x0040 - 0x0028)
class TransformableHandle : public Object_32759
{
public:
	unsigned char                                      UnknownData00[0x18];                                      // 0x0028(0x0018) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class Constraints.TransformableHandle"));
		
		return ptr;
	}

};


// Class Constraints.ConstraintsActor
// 0x0008 (0x0290 - 0x0288)
class ConstraintsActor : public Actor_32759
{
public:
	class ConstraintsManager*                          ConstraintsManager_69;                                    // 0x0288(0x0008) (ZeroConstructor)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class Constraints.ConstraintsActor"));
		
		return ptr;
	}

};


// Class Constraints.TickableConstraint
// 0x0048 (0x0070 - 0x0028)
class TickableConstraint : public Object_32759
{
public:
	struct FConstraintTickFunction                     ConstraintTick_69;                                        // 0x0028(0x0040)
	bool                                               Active_69;                                                // 0x0068(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0069(0x0007) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class Constraints.TickableConstraint"));
		
		return ptr;
	}

};


// Class Constraints.ConstraintsManager
// 0x0020 (0x0048 - 0x0028)
class ConstraintsManager : public Object_32759
{
public:
	unsigned char                                      UnknownData00[0x1];                                       // 0x0028(0x0001) UNKNOWN PROPERTY: MulticastSparseDelegateProperty Constraints.ConstraintsManager.OnConstraintAdded_BP_69
	unsigned char                                      UnknownData01[0x1];                                       // 0x0029(0x0001) UNKNOWN PROPERTY: MulticastSparseDelegateProperty Constraints.ConstraintsManager.OnConstraintRemoved_BP_69
	unsigned char                                      UnknownData02[0xE];                                       // 0x002A(0x000E) MISSED OFFSET
	TArray<class TickableConstraint*>                  Constraints_69;                                           // 0x0038(0x0010) (ZeroConstructor)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class Constraints.ConstraintsManager"));
		
		return ptr;
	}

};


// Class Constraints.ConstraintsScriptingLibrary
// 0x0000 (0x0028 - 0x0028)
class ConstraintsScriptingLibrary : public BlueprintFunctionLibrary
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class Constraints.ConstraintsScriptingLibrary"));
		
		return ptr;
	}


	bool STATIC_RemoveConstraint(class World* InWorld_69, int InIndex_69);
	class ConstraintsManager* STATIC_GetManager(class World* InWorld_69);
	class TransformableComponentHandle* STATIC_CreateTransformableComponentHandle(class World* InWorld_69, class SceneComponent* InSceneComponent_69, const struct FName& InSocketName_69);
	class TickableTransformConstraint* STATIC_CreateFromType(class World* InWorld_69, ETransformConstraintType InType_69);
	bool STATIC_AddConstraint(class World* InWorld_69, class TransformableHandle* InParentHandle_69, class TransformableHandle* InChildHandle_69, class TickableTransformConstraint* InConstraint_69, bool bMaintainOffset_69);
};


// Class Constraints.TransformableComponentHandle
// 0x0010 (0x0050 - 0x0040)
class TransformableComponentHandle : public TransformableHandle
{
public:
	TWeakObjectPtr<class SceneComponent>               Component_69;                                             // 0x0040(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference, IsPlainOldData)
	struct FName                                       SocketName_69;                                            // 0x0048(0x0008) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x004C(0x0004) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class Constraints.TransformableComponentHandle"));
		
		return ptr;
	}

};


// Class Constraints.TickableTransformConstraint
// 0x0020 (0x0090 - 0x0070)
class TickableTransformConstraint : public TickableConstraint
{
public:
	class TransformableHandle*                         ParentTRSHandle_69;                                       // 0x0070(0x0008) (BlueprintVisible, ZeroConstructor)
	class TransformableHandle*                         ChildTRSHandle_69;                                        // 0x0078(0x0008) (BlueprintVisible, ZeroConstructor)
	bool                                               bMaintainOffset_69;                                       // 0x0080(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0081(0x0003) MISSED OFFSET
	float                                              Weight_69;                                                // 0x0084(0x0004) (ZeroConstructor, IsPlainOldData)
	bool                                               bDynamicOffset_69;                                        // 0x0088(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	ETransformConstraintType                           Type_69;                                                  // 0x0089(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x6];                                       // 0x008A(0x0006) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class Constraints.TickableTransformConstraint"));
		
		return ptr;
	}

};


// Class Constraints.TickableTranslationConstraint
// 0x0020 (0x00B0 - 0x0090)
class TickableTranslationConstraint : public TickableTransformConstraint
{
public:
	unsigned char                                      UnknownData00[0x8];                                       // 0x0090(0x0008) MISSED OFFSET
	struct FVector                                     OffsetTranslation_69;                                     // 0x0098(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class Constraints.TickableTranslationConstraint"));
		
		return ptr;
	}

};


// Class Constraints.TickableRotationConstraint
// 0x0030 (0x00C0 - 0x0090)
class TickableRotationConstraint : public TickableTransformConstraint
{
public:
	unsigned char                                      UnknownData00[0x10];                                      // 0x0090(0x0010) MISSED OFFSET
	struct FQuat                                       OffsetRotation_69;                                        // 0x00A0(0x0020) (Edit, BlueprintVisible, IsPlainOldData)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class Constraints.TickableRotationConstraint"));
		
		return ptr;
	}

};


// Class Constraints.TickableScaleConstraint
// 0x0018 (0x00A8 - 0x0090)
class TickableScaleConstraint : public TickableTransformConstraint
{
public:
	struct FVector                                     OffsetScale_69;                                           // 0x0090(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class Constraints.TickableScaleConstraint"));
		
		return ptr;
	}

};


// Class Constraints.TickableParentConstraint
// 0x0080 (0x0110 - 0x0090)
class TickableParentConstraint : public TickableTransformConstraint
{
public:
	unsigned char                                      UnknownData00[0x10];                                      // 0x0090(0x0010) MISSED OFFSET
	struct FCoreUObject_FTransform                     OffsetTransform_69;                                       // 0x00A0(0x0060) (Edit, BlueprintVisible, IsPlainOldData)
	bool                                               bScaling_69;                                              // 0x0100(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0xF];                                       // 0x0101(0x000F) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class Constraints.TickableParentConstraint"));
		
		return ptr;
	}

};


// Class Constraints.TickableLookAtConstraint
// 0x0018 (0x00A8 - 0x0090)
class TickableLookAtConstraint : public TickableTransformConstraint
{
public:
	struct FVector                                     Axis_69;                                                  // 0x0090(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class Constraints.TickableLookAtConstraint"));
		
		return ptr;
	}

};


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

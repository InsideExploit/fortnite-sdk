// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Functions
//---------------------------------------------------------------------------

// Function AssetTags.AssetTagsSubsystem.GetCollectionsContainingAssetPtr
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// class Object_32759*            AssetPtr_69                    (ConstParm, Parm, ZeroConstructor)
// TArray<struct FName>           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

TArray<struct FName> AssetTagsSubsystem::GetCollectionsContainingAssetPtr(class Object_32759* AssetPtr_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AssetTags.AssetTagsSubsystem.GetCollectionsContainingAssetPtr"));

	AssetTagsSubsystem_GetCollectionsContainingAssetPtr_Params params;
	params.AssetPtr_69 = AssetPtr_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AssetTags.AssetTagsSubsystem.GetCollectionsContainingAssetData
// (Final, Native, Public, HasOutParms, HasDefaults, BlueprintCallable)
// Parameters:
// struct FAssetData              AssetData_69                   (ConstParm, Parm, OutParm, ReferenceParm)
// TArray<struct FName>           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

TArray<struct FName> AssetTagsSubsystem::GetCollectionsContainingAssetData(const struct FAssetData& AssetData_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AssetTags.AssetTagsSubsystem.GetCollectionsContainingAssetData"));

	AssetTagsSubsystem_GetCollectionsContainingAssetData_Params params;
	params.AssetData_69 = AssetData_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AssetTags.AssetTagsSubsystem.GetCollectionsContainingAsset
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// struct FName                   AssetPathName_69               (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// TArray<struct FName>           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

TArray<struct FName> AssetTagsSubsystem::GetCollectionsContainingAsset(const struct FName& AssetPathName_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AssetTags.AssetTagsSubsystem.GetCollectionsContainingAsset"));

	AssetTagsSubsystem_GetCollectionsContainingAsset_Params params;
	params.AssetPathName_69 = AssetPathName_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AssetTags.AssetTagsSubsystem.GetCollections
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// TArray<struct FName>           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

TArray<struct FName> AssetTagsSubsystem::GetCollections()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AssetTags.AssetTagsSubsystem.GetCollections"));

	AssetTagsSubsystem_GetCollections_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AssetTags.AssetTagsSubsystem.GetAssetsInCollection
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// struct FName                   Name_69                        (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// TArray<struct FAssetData>      ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

TArray<struct FAssetData> AssetTagsSubsystem::GetAssetsInCollection(const struct FName& Name_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AssetTags.AssetTagsSubsystem.GetAssetsInCollection"));

	AssetTagsSubsystem_GetAssetsInCollection_Params params;
	params.Name_69 = Name_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AssetTags.AssetTagsSubsystem.CollectionExists
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// struct FName                   Name_69                        (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool AssetTagsSubsystem::CollectionExists(const struct FName& Name_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AssetTags.AssetTagsSubsystem.CollectionExists"));

	AssetTagsSubsystem_CollectionExists_Params params;
	params.Name_69 = Name_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Classes
//---------------------------------------------------------------------------

// Class ClothingSystemRuntimeInterface.ClothConfigBase
// 0x0000 (0x0028 - 0x0028)
class ClothConfigBase : public Object_32759
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class ClothingSystemRuntimeInterface.ClothConfigBase"));
		
		return ptr;
	}

};


// Class ClothingSystemRuntimeInterface.ClothingSimulationFactory
// 0x0000 (0x0028 - 0x0028)
class ClothingSimulationFactory : public Object_32759
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class ClothingSystemRuntimeInterface.ClothingSimulationFactory"));
		
		return ptr;
	}

};


// Class ClothingSystemRuntimeInterface.ClothingInteractor
// 0x0008 (0x0030 - 0x0028)
class ClothingInteractor : public Object_32759
{
public:
	unsigned char                                      UnknownData00[0x8];                                       // 0x0028(0x0008) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class ClothingSystemRuntimeInterface.ClothingInteractor"));
		
		return ptr;
	}

};


// Class ClothingSystemRuntimeInterface.ClothingSimulationInteractor
// 0x0068 (0x0090 - 0x0028)
class ClothingSimulationInteractor : public Object_32759
{
public:
	TMap<struct FName, class ClothingInteractor*>      ClothingInteractors_69;                                   // 0x0028(0x0050)
	unsigned char                                      UnknownData00[0x18];                                      // 0x0078(0x0018) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class ClothingSystemRuntimeInterface.ClothingSimulationInteractor"));
		
		return ptr;
	}


	void SetNumSubsteps(int NumSubsteps_69);
	void SetNumIterations(int NumIterations_69);
	void SetMaxNumIterations(int MaxNumIterations_69);
	void SetAnimDriveSpringStiffness(float InStiffness_69);
	void PhysicsAssetUpdated();
	float GetSimulationTime();
	int GetNumSubsteps();
	int GetNumKinematicParticles();
	int GetNumIterations();
	int GetNumDynamicParticles();
	int GetNumCloths();
	class ClothingInteractor* GetClothingInteractor(const struct FString& ClothingAssetName_69);
	void EnableGravityOverride(const struct FVector& InVector_69);
	void DisableGravityOverride();
	void ClothConfigUpdated();
};


// Class ClothingSystemRuntimeInterface.ClothingAssetBase
// 0x0020 (0x0048 - 0x0028)
class ClothingAssetBase : public Object_32759
{
public:
	struct FString                                     ImportedFilePath_69;                                      // 0x0028(0x0010) (Edit, ZeroConstructor, EditConst)
	struct FGuid                                       AssetGuid_69;                                             // 0x0038(0x0010) (ZeroConstructor, IsPlainOldData)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class ClothingSystemRuntimeInterface.ClothingAssetBase"));
		
		return ptr;
	}

};


// Class ClothingSystemRuntimeInterface.ClothSharedSimConfigBase
// 0x0000 (0x0028 - 0x0028)
class ClothSharedSimConfigBase : public Object_32759
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class ClothingSystemRuntimeInterface.ClothSharedSimConfigBase"));
		
		return ptr;
	}

};


// Class ClothingSystemRuntimeInterface.ClothPhysicalMeshDataBase_Legacy
// 0x00B8 (0x00E0 - 0x0028)
class ClothPhysicalMeshDataBase_Legacy : public Object_32759
{
public:
	TArray<struct FVector3f>                           Vertices_69;                                              // 0x0028(0x0010) (ZeroConstructor)
	TArray<struct FVector3f>                           Normals_69;                                               // 0x0038(0x0010) (ZeroConstructor)
	TArray<uint32_t>                                   Indices_69;                                               // 0x0048(0x0010) (ZeroConstructor)
	TArray<float>                                      InverseMasses_69;                                         // 0x0058(0x0010) (ZeroConstructor)
	TArray<struct FClothVertBoneData>                  BoneData_69;                                              // 0x0068(0x0010) (ZeroConstructor)
	int                                                NumFixedVerts_69;                                         // 0x0078(0x0004) (ZeroConstructor, IsPlainOldData)
	int                                                MaxBoneWeights_69;                                        // 0x007C(0x0004) (ZeroConstructor, IsPlainOldData)
	TArray<uint32_t>                                   SelfCollisionIndices_69;                                  // 0x0080(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData00[0x50];                                      // 0x0090(0x0050) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class ClothingSystemRuntimeInterface.ClothPhysicalMeshDataBase_Legacy"));
		
		return ptr;
	}

};


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Functions
//---------------------------------------------------------------------------

// Function AIPatrolPath.AIPatrolPathComponent.SyncSharedUserOptions
// (Final, Native, Public, HasOutParms, BlueprintCallable)
// Parameters:
// class AIPatrolPathComponent*   CopyToAIPatrolPathComp_69      (Parm, ZeroConstructor, InstancedReference)
// TMap<struct FString, struct FString> UserOptionValues_69            (ConstParm, Parm, OutParm, ReferenceParm)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool AIPatrolPathComponent::SyncSharedUserOptions(class AIPatrolPathComponent* CopyToAIPatrolPathComp_69, TMap<struct FString, struct FString> UserOptionValues_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIPatrolPath.AIPatrolPathComponent.SyncSharedUserOptions"));

	AIPatrolPathComponent_SyncSharedUserOptions_Params params;
	params.CopyToAIPatrolPathComp_69 = CopyToAIPatrolPathComp_69;
	params.UserOptionValues_69 = UserOptionValues_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AIPatrolPath.AIPatrolPathComponent.ShouldRenderPath
// (Event, Protected, BlueprintCallable, BlueprintEvent)
// Parameters:
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool AIPatrolPathComponent::ShouldRenderPath()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIPatrolPath.AIPatrolPathComponent.ShouldRenderPath"));

	AIPatrolPathComponent_ShouldRenderPath_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AIPatrolPath.AIPatrolPathComponent.SetRenderPath
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// bool                           bRenderPath_69                 (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void AIPatrolPathComponent::SetRenderPath(bool bRenderPath_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIPatrolPath.AIPatrolPathComponent.SetRenderPath"));

	AIPatrolPathComponent_SetRenderPath_Params params;
	params.bRenderPath_69 = bRenderPath_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AIPatrolPath.AIPatrolPathComponent.SetPatrolPathGroup
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// EFortCreativePatrolPathGroup   PatrolPathGroup_69             (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void AIPatrolPathComponent::SetPatrolPathGroup(EFortCreativePatrolPathGroup PatrolPathGroup_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIPatrolPath.AIPatrolPathComponent.SetPatrolPathGroup"));

	AIPatrolPathComponent_SetPatrolPathGroup_Params params;
	params.PatrolPathGroup_69 = PatrolPathGroup_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AIPatrolPath.AIPatrolPathComponent.SetPatrolPathEnabled
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// bool                           bIsEnabled_69                  (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void AIPatrolPathComponent::SetPatrolPathEnabled(bool bIsEnabled_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIPatrolPath.AIPatrolPathComponent.SetPatrolPathEnabled"));

	AIPatrolPathComponent_SetPatrolPathEnabled_Params params;
	params.bIsEnabled_69 = bIsEnabled_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AIPatrolPath.AIPatrolPathComponent.SetPatrollingMode
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// EPatrollingMode                NewMode_69                     (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void AIPatrolPathComponent::SetPatrollingMode(EPatrollingMode NewMode_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIPatrolPath.AIPatrolPathComponent.SetPatrollingMode"));

	AIPatrolPathComponent_SetPatrollingMode_Params params;
	params.NewMode_69 = NewMode_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AIPatrolPath.AIPatrolPathComponent.RequestRenderPath
// (Final, Native, Public, BlueprintCallable)

void AIPatrolPathComponent::RequestRenderPath()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIPatrolPath.AIPatrolPathComponent.RequestRenderPath"));

	AIPatrolPathComponent_RequestRenderPath_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AIPatrolPath.AIPatrolPathComponent.RenderToNextPoint
// (Final, Native, Public, BlueprintCallable)

void AIPatrolPathComponent::RenderToNextPoint()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIPatrolPath.AIPatrolPathComponent.RenderToNextPoint"));

	AIPatrolPathComponent_RenderToNextPoint_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AIPatrolPath.AIPatrolPathComponent.RenderToNextAndPreviousPoint
// (Final, Native, Public, BlueprintCallable)

void AIPatrolPathComponent::RenderToNextAndPreviousPoint()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIPatrolPath.AIPatrolPathComponent.RenderToNextAndPreviousPoint"));

	AIPatrolPathComponent_RenderToNextAndPreviousPoint_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AIPatrolPath.AIPatrolPathComponent.RemovePoint
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool AIPatrolPathComponent::RemovePoint()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIPatrolPath.AIPatrolPathComponent.RemovePoint"));

	AIPatrolPathComponent_RemovePoint_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AIPatrolPath.AIPatrolPathComponent.PatrolPointReached
// (Final, Native, Private)
// Parameters:
// class FortAthenaPatrolPoint*   PathPoint_69                   (Parm, ZeroConstructor)
// class AIController*            Instigator_69                  (Parm, ZeroConstructor)

void AIPatrolPathComponent::PatrolPointReached(class FortAthenaPatrolPoint* PathPoint_69, class AIController* Instigator_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIPatrolPath.AIPatrolPathComponent.PatrolPointReached"));

	AIPatrolPathComponent_PatrolPointReached_Params params;
	params.PathPoint_69 = PathPoint_69;
	params.Instigator_69 = Instigator_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AIPatrolPath.AIPatrolPathComponent.PatrolPointFailedToReach
// (Final, Native, Private)
// Parameters:
// class FortAthenaPatrolPoint*   PathPoint_69                   (Parm, ZeroConstructor)
// class AIController*            Instigator_69                  (Parm, ZeroConstructor)

void AIPatrolPathComponent::PatrolPointFailedToReach(class FortAthenaPatrolPoint* PathPoint_69, class AIController* Instigator_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIPatrolPath.AIPatrolPathComponent.PatrolPointFailedToReach"));

	AIPatrolPathComponent_PatrolPointFailedToReach_Params params;
	params.PathPoint_69 = PathPoint_69;
	params.Instigator_69 = Instigator_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AIPatrolPath.AIPatrolPathComponent.PatrolPathStopped
// (Final, Native, Private)
// Parameters:
// class AIController*            Instigator_69                  (Parm, ZeroConstructor)

void AIPatrolPathComponent::PatrolPathStopped(class AIController* Instigator_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIPatrolPath.AIPatrolPathComponent.PatrolPathStopped"));

	AIPatrolPathComponent_PatrolPathStopped_Params params;
	params.Instigator_69 = Instigator_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AIPatrolPath.AIPatrolPathComponent.PatrolPathStarted
// (Final, Native, Private)
// Parameters:
// class AIController*            Instigator_69                  (Parm, ZeroConstructor)

void AIPatrolPathComponent::PatrolPathStarted(class AIController* Instigator_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIPatrolPath.AIPatrolPathComponent.PatrolPathStarted"));

	AIPatrolPathComponent_PatrolPathStarted_Params params;
	params.Instigator_69 = Instigator_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AIPatrolPath.AIPatrolPathComponent.OnPatrolPathGroupsMerged
// (Event, Public, BlueprintEvent)

void AIPatrolPathComponent::OnPatrolPathGroupsMerged()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIPatrolPath.AIPatrolPathComponent.OnPatrolPathGroupsMerged"));

	AIPatrolPathComponent_OnPatrolPathGroupsMerged_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AIPatrolPath.AIPatrolPathComponent.OnPatrolPathActorAssigned
// (Event, Public, BlueprintEvent)

void AIPatrolPathComponent::OnPatrolPathActorAssigned()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIPatrolPath.AIPatrolPathComponent.OnPatrolPathActorAssigned"));

	AIPatrolPathComponent_OnPatrolPathActorAssigned_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AIPatrolPath.AIPatrolPathComponent.OnPathExtremitiesChanged
// (Event, Public, BlueprintEvent)
// Parameters:
// bool                           bIsStart_69                    (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// bool                           bIsEnd_69                      (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void AIPatrolPathComponent::OnPathExtremitiesChanged(bool bIsStart_69, bool bIsEnd_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIPatrolPath.AIPatrolPathComponent.OnPathExtremitiesChanged"));

	AIPatrolPathComponent_OnPathExtremitiesChanged_Params params;
	params.bIsStart_69 = bIsStart_69;
	params.bIsEnd_69 = bIsEnd_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AIPatrolPath.AIPatrolPathComponent.HasValidPatrolPath
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool AIPatrolPathComponent::HasValidPatrolPath()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIPatrolPath.AIPatrolPathComponent.HasValidPatrolPath"));

	AIPatrolPathComponent_HasValidPatrolPath_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AIPatrolPath.AIPatrolPathComponent.GetPatrolPathPointIndex
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// int                            ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int AIPatrolPathComponent::GetPatrolPathPointIndex()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIPatrolPath.AIPatrolPathComponent.GetPatrolPathPointIndex"));

	AIPatrolPathComponent_GetPatrolPathPointIndex_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AIPatrolPath.AIPatrolPathComponent.GetPatrolPathPoint
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// int                            InPatrolPathIndex_69           (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// int                            InPatrolPathPointIndex_69      (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// class AIPatrolPathComponent*   ReturnValue_69                 (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)

class AIPatrolPathComponent* AIPatrolPathComponent::GetPatrolPathPoint(int InPatrolPathIndex_69, int InPatrolPathPointIndex_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIPatrolPath.AIPatrolPathComponent.GetPatrolPathPoint"));

	AIPatrolPathComponent_GetPatrolPathPoint_Params params;
	params.InPatrolPathIndex_69 = InPatrolPathIndex_69;
	params.InPatrolPathPointIndex_69 = InPatrolPathPointIndex_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AIPatrolPath.AIPatrolPathComponent.GetPatrolPathIndex
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// int                            ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int AIPatrolPathComponent::GetPatrolPathIndex()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIPatrolPath.AIPatrolPathComponent.GetPatrolPathIndex"));

	AIPatrolPathComponent_GetPatrolPathIndex_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AIPatrolPath.AIPatrolPathComponent.GetPatrolFilterOptions
// (Event, Public, BlueprintEvent)
// Parameters:
// class NavigationQueryFilter*   ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

class NavigationQueryFilter* AIPatrolPathComponent::GetPatrolFilterOptions()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIPatrolPath.AIPatrolPathComponent.GetPatrolFilterOptions"));

	AIPatrolPathComponent_GetPatrolFilterOptions_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AIPatrolPath.AIPatrolPathComponent.GetNextAvailablePatrolPathIndex
// (Final, Native, Public, HasOutParms, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// int                            NextAvailableIndex_69          (Parm, OutParm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool AIPatrolPathComponent::GetNextAvailablePatrolPathIndex(int* NextAvailableIndex_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIPatrolPath.AIPatrolPathComponent.GetNextAvailablePatrolPathIndex"));

	AIPatrolPathComponent_GetNextAvailablePatrolPathIndex_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (NextAvailableIndex_69 != nullptr)
		*NextAvailableIndex_69 = params.NextAvailableIndex_69;

	return params.ReturnValue_69;
}


// Function AIPatrolPath.AIPatrolPathComponent.GetLinkedPatrolPoints
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// TArray<class AIPatrolPathComponent*> ReturnValue_69                 (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm)

TArray<class AIPatrolPathComponent*> AIPatrolPathComponent::GetLinkedPatrolPoints()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIPatrolPath.AIPatrolPathComponent.GetLinkedPatrolPoints"));

	AIPatrolPathComponent_GetLinkedPatrolPoints_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AIPatrolPath.AIPatrolPathComponent.GeneratePathPoints
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// EFortCreativePatrolPathGroup   PatrolPathGroup_69             (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void AIPatrolPathComponent::GeneratePathPoints(EFortCreativePatrolPathGroup PatrolPathGroup_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIPatrolPath.AIPatrolPathComponent.GeneratePathPoints"));

	AIPatrolPathComponent_GeneratePathPoints_Params params;
	params.PatrolPathGroup_69 = PatrolPathGroup_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AIPatrolPath.AIPatrolPathComponent.CanNextPointBeReached
// (Final, Native, Protected, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool AIPatrolPathComponent::CanNextPointBeReached()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIPatrolPath.AIPatrolPathComponent.CanNextPointBeReached"));

	AIPatrolPathComponent_CanNextPointBeReached_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

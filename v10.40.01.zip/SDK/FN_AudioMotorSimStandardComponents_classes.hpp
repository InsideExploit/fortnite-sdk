#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Classes
//---------------------------------------------------------------------------

// Class AudioMotorSimStandardComponents.BoostMotorSimComponent
// 0x00A8 (0x0150 - 0x00A8)
class BoostMotorSimComponent : public AudioMotorSimComponent
{
public:
	float                                              ThrottleScale_69;                                         // 0x00A8(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	float                                              InterpExp_69;                                             // 0x00AC(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	float                                              InterpTime_69;                                            // 0x00B0(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	bool                                               ScaleThrottleWithBoostStrength_69;                        // 0x00B4(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	bool                                               bModifyPitch_69;                                          // 0x00B5(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x2];                                       // 0x00B6(0x0002) MISSED OFFSET
	float                                              PitchModifierInterpSpeed_69;                              // 0x00B8(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x4];                                       // 0x00BC(0x0004) MISSED OFFSET
	struct FRuntimeFloatCurve                          BoostToPitchCurve_69;                                     // 0x00C0(0x0088) (Edit)
	unsigned char                                      UnknownData02[0x8];                                       // 0x0148(0x0008) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AudioMotorSimStandardComponents.BoostMotorSimComponent"));
		
		return ptr;
	}

};


// Class AudioMotorSimStandardComponents.MotorPhysicsSimComponent
// 0x0060 (0x0108 - 0x00A8)
class MotorPhysicsSimComponent : public AudioMotorSimComponent
{
public:
	float                                              Weight_69;                                                // 0x00A8(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              EngineTorque_69;                                          // 0x00AC(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              BrakingHorsePower_69;                                     // 0x00B0(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x00B4(0x0004) MISSED OFFSET
	TArray<float>                                      GearRatios_69;                                            // 0x00B8(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	float                                              ClutchedGearRatio_69;                                     // 0x00C8(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bUseInfiniteGears_69;                                     // 0x00CC(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bAlwaysDownshiftToZerothGear_69;                          // 0x00CD(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x2];                                       // 0x00CE(0x0002) MISSED OFFSET
	float                                              InfiniteGearRatio_69;                                     // 0x00D0(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              UpShiftMaxRpm_69;                                         // 0x00D4(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              DownShiftStartRpm_69;                                     // 0x00D8(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              ClutchedForceModifier_69;                                 // 0x00DC(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              EngineGearRatio_69;                                       // 0x00E0(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              EngineFriction_69;                                        // 0x00E4(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              GroundFriction_69;                                        // 0x00E8(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              WindResistancePerVelocity_69;                             // 0x00EC(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              ThrottleInterpolationTime_69;                             // 0x00F0(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              RpmInterpSpeed_69;                                        // 0x00F4(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData02[0x10];                                      // 0x00F8(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty AudioMotorSimStandardComponents.MotorPhysicsSimComponent.OnGearChangedEvent_69

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AudioMotorSimStandardComponents.MotorPhysicsSimComponent"));
		
		return ptr;
	}

};


// Class AudioMotorSimStandardComponents.ResistanceMotorSimComponent
// 0x0090 (0x0138 - 0x00A8)
class ResistanceMotorSimComponent : public AudioMotorSimComponent
{
public:
	float                                              UpSpeedMaxFriction_69;                                    // 0x00A8(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	float                                              MinSpeed_69;                                              // 0x00AC(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	struct FRuntimeFloatCurve                          SideSpeedFrictionCurve_69;                                // 0x00B0(0x0088) (Edit)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AudioMotorSimStandardComponents.ResistanceMotorSimComponent"));
		
		return ptr;
	}

};


// Class AudioMotorSimStandardComponents.ReverseMotorSimComponent
// 0x0008 (0x00B0 - 0x00A8)
class ReverseMotorSimComponent : public AudioMotorSimComponent
{
public:
	float                                              ReverseEngineResistanceModifier_69;                       // 0x00A8(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x00AC(0x0004) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AudioMotorSimStandardComponents.ReverseMotorSimComponent"));
		
		return ptr;
	}

};


// Class AudioMotorSimStandardComponents.RevLimiterMotorSimComponent
// 0x0020 (0x00C8 - 0x00A8)
class RevLimiterMotorSimComponent : public AudioMotorSimComponent
{
public:
	float                                              LimitTime_69;                                             // 0x00A8(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              DecelScale_69;                                            // 0x00AC(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              AirMaxThrottleTime_69;                                    // 0x00B0(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              SideSpeedThreshold_69;                                    // 0x00B4(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              LimiterMaxRpm_69;                                         // 0x00B8(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0xC];                                       // 0x00BC(0x000C) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AudioMotorSimStandardComponents.RevLimiterMotorSimComponent"));
		
		return ptr;
	}

};


// Class AudioMotorSimStandardComponents.RpmCurveMotorSimComponent
// 0x0018 (0x00C0 - 0x00A8)
class RpmCurveMotorSimComponent : public AudioMotorSimComponent
{
public:
	TArray<struct FMotorSimGearCurve>                  Gears_69;                                                 // 0x00A8(0x0010) (Edit, ZeroConstructor)
	float                                              InterpSpeed_69;                                           // 0x00B8(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x00BC(0x0004) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AudioMotorSimStandardComponents.RpmCurveMotorSimComponent"));
		
		return ptr;
	}

};


// Class AudioMotorSimStandardComponents.ThrottleStateMotorSimComponent
// 0x0040 (0x00E8 - 0x00A8)
class ThrottleStateMotorSimComponent : public AudioMotorSimComponent
{
public:
	unsigned char                                      UnknownData00[0x10];                                      // 0x00A8(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty AudioMotorSimStandardComponents.ThrottleStateMotorSimComponent.OnThrottleEngaged_69
	unsigned char                                      UnknownData01[0x10];                                      // 0x00B8(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty AudioMotorSimStandardComponents.ThrottleStateMotorSimComponent.OnThrottleReleased_69
	unsigned char                                      UnknownData02[0x10];                                      // 0x00C8(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty AudioMotorSimStandardComponents.ThrottleStateMotorSimComponent.OnEngineBlowoff_69
	float                                              BlowoffMinThrottleTime_69;                                // 0x00D8(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData03[0xC];                                       // 0x00DC(0x000C) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AudioMotorSimStandardComponents.ThrottleStateMotorSimComponent"));
		
		return ptr;
	}

};


// Class AudioMotorSimStandardComponents.VelocitySyncMotorSimComponent
// 0x00A8 (0x0150 - 0x00A8)
class VelocitySyncMotorSimComponent : public AudioMotorSimComponent
{
public:
	float                                              NoThrottleTime_69;                                        // 0x00A8(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              SpeedThreshold_69;                                        // 0x00AC(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FRuntimeFloatCurve                          SpeedToRpmCurve_69;                                       // 0x00B0(0x0088) (Edit)
	float                                              InterpSpeed_69;                                           // 0x0138(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              InterpTime_69;                                            // 0x013C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              FirstGearThrottleThreshold_69;                            // 0x0140(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0xC];                                       // 0x0144(0x000C) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AudioMotorSimStandardComponents.VelocitySyncMotorSimComponent"));
		
		return ptr;
	}

};


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

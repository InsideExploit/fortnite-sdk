// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Functions
//---------------------------------------------------------------------------

// Function CreativeRoyaleRuntime.CreativeRoyalePlayspaceComponent_LoadingScreen.OnPlotLoadComplete
// (Final, Native, Private)

void CreativeRoyalePlayspaceComponent_LoadingScreen::OnPlotLoadComplete()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CreativeRoyaleRuntime.CreativeRoyalePlayspaceComponent_LoadingScreen.OnPlotLoadComplete"));

	CreativeRoyalePlayspaceComponent_LoadingScreen_OnPlotLoadComplete_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CreativeRoyaleRuntime.CreativeRoyalePlayspaceComponent_LoadingScreen.OnPlayspaceUserAdded
// (Final, Native, Private, HasOutParms)
// Parameters:
// struct FPlayspaceUser          AddedUser_69                   (Parm, OutParm)

void CreativeRoyalePlayspaceComponent_LoadingScreen::OnPlayspaceUserAdded(struct FPlayspaceUser* AddedUser_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CreativeRoyaleRuntime.CreativeRoyalePlayspaceComponent_LoadingScreen.OnPlayspaceUserAdded"));

	CreativeRoyalePlayspaceComponent_LoadingScreen_OnPlayspaceUserAdded_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (AddedUser_69 != nullptr)
		*AddedUser_69 = params.AddedUser_69;
}


// Function CreativeRoyaleRuntime.CreativeRoyalePlayspaceComponent_LoadingScreen.OnMinigameStateChanged
// (Final, Native, Private)
// Parameters:
// class FortMinigame*            Minigame_69                    (Parm, ZeroConstructor)
// EFortMinigameState             MinigameState_69               (Parm, ZeroConstructor, IsPlainOldData)

void CreativeRoyalePlayspaceComponent_LoadingScreen::OnMinigameStateChanged(class FortMinigame* Minigame_69, EFortMinigameState MinigameState_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CreativeRoyaleRuntime.CreativeRoyalePlayspaceComponent_LoadingScreen.OnMinigameStateChanged"));

	CreativeRoyalePlayspaceComponent_LoadingScreen_OnMinigameStateChanged_Params params;
	params.Minigame_69 = Minigame_69;
	params.MinigameState_69 = MinigameState_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CreativeRoyaleRuntime.AthenaAIServicePlayerBots_CreativeRoyale.OnPlayerJoiningInProgress
// (Final, Native, Protected)
// Parameters:
// class FortPlayerState*         FortPlayerState_69             (ConstParm, Parm, ZeroConstructor)

void AthenaAIServicePlayerBots_CreativeRoyale::OnPlayerJoiningInProgress(class FortPlayerState* FortPlayerState_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CreativeRoyaleRuntime.AthenaAIServicePlayerBots_CreativeRoyale.OnPlayerJoiningInProgress"));

	AthenaAIServicePlayerBots_CreativeRoyale_OnPlayerJoiningInProgress_Params params;
	params.FortPlayerState_69 = FortPlayerState_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CreativeRoyaleRuntime.CreativeRoyaleRootPlayspace.TeleportPlayersToPlayerStarts
// (Final, Native, Protected)

void CreativeRoyaleRootPlayspace::TeleportPlayersToPlayerStarts()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CreativeRoyaleRuntime.CreativeRoyaleRootPlayspace.TeleportPlayersToPlayerStarts"));

	CreativeRoyaleRootPlayspace_TeleportPlayersToPlayerStarts_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CreativeRoyaleRuntime.CreativeRoyaleRootPlayspace.OnRep_bHasPlotLoaded
// (Final, Native, Private)

void CreativeRoyaleRootPlayspace::OnRep_bHasPlotLoaded()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CreativeRoyaleRuntime.CreativeRoyaleRootPlayspace.OnRep_bHasPlotLoaded"));

	CreativeRoyaleRootPlayspace_OnRep_bHasPlotLoaded_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CreativeRoyaleRuntime.CreativeRoyaleRootPlayspace.OnPlotLoadComplete
// (Final, Native, Private)

void CreativeRoyaleRootPlayspace::OnPlotLoadComplete()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CreativeRoyaleRuntime.CreativeRoyaleRootPlayspace.OnPlotLoadComplete"));

	CreativeRoyaleRootPlayspace_OnPlotLoadComplete_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CreativeRoyaleRuntime.CreativeRoyaleRootPlayspace.Cheat_LoadEditorIsland
// (Final, Native, Protected)

void CreativeRoyaleRootPlayspace::Cheat_LoadEditorIsland()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CreativeRoyaleRuntime.CreativeRoyaleRootPlayspace.Cheat_LoadEditorIsland"));

	CreativeRoyaleRootPlayspace_Cheat_LoadEditorIsland_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CreativeRoyaleRuntime.CreativeRoyaleRootPlayspace.BuildDataRegistryResolverScope_Implementation
// (Native, Public, HasOutParms, Const)
// Parameters:
// TArray<struct FName>           InOutResolverScopes_69         (Parm, OutParm, ZeroConstructor)
// int                            InOutPriority_69               (Parm, OutParm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool CreativeRoyaleRootPlayspace::BuildDataRegistryResolverScope_Implementation(TArray<struct FName>* InOutResolverScopes_69, int* InOutPriority_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CreativeRoyaleRuntime.CreativeRoyaleRootPlayspace.BuildDataRegistryResolverScope_Implementation"));

	CreativeRoyaleRootPlayspace_BuildDataRegistryResolverScope_Implementation_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (InOutResolverScopes_69 != nullptr)
		*InOutResolverScopes_69 = params.InOutResolverScopes_69;
	if (InOutPriority_69 != nullptr)
		*InOutPriority_69 = params.InOutPriority_69;

	return params.ReturnValue_69;
}


// Function CreativeRoyaleRuntime.FortCheatManager_CreativeRoyale.TeleportToPlotAferLoad
// (Final, Native, Protected, Const)

void FortCheatManager_CreativeRoyale::TeleportToPlotAferLoad()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CreativeRoyaleRuntime.FortCheatManager_CreativeRoyale.TeleportToPlotAferLoad"));

	FortCheatManager_CreativeRoyale_TeleportToPlotAferLoad_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CreativeRoyaleRuntime.FortCheatManager_CreativeRoyale.CreativeRoyaleTeleportToEditZone
// (Final, Exec, Native, Public, Const)

void FortCheatManager_CreativeRoyale::CreativeRoyaleTeleportToEditZone()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CreativeRoyaleRuntime.FortCheatManager_CreativeRoyale.CreativeRoyaleTeleportToEditZone"));

	FortCheatManager_CreativeRoyale_CreativeRoyaleTeleportToEditZone_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CreativeRoyaleRuntime.FortCheatManager_CreativeRoyale.CreativeRoyaleResetIslandFile
// (Final, Exec, Native, Public, Const)

void FortCheatManager_CreativeRoyale::CreativeRoyaleResetIslandFile()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CreativeRoyaleRuntime.FortCheatManager_CreativeRoyale.CreativeRoyaleResetIslandFile"));

	FortCheatManager_CreativeRoyale_CreativeRoyaleResetIslandFile_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CreativeRoyaleRuntime.FortCheatManager_CreativeRoyale.CreativeRoyaleLoadEditPlot
// (Final, Exec, Native, Public, Const)

void FortCheatManager_CreativeRoyale::CreativeRoyaleLoadEditPlot()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CreativeRoyaleRuntime.FortCheatManager_CreativeRoyale.CreativeRoyaleLoadEditPlot"));

	FortCheatManager_CreativeRoyale_CreativeRoyaleLoadEditPlot_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CreativeRoyaleRuntime.FortProjectEditComponent_CreativeRoyale.OnPlayerLoggedIn
// (Final, Native, Protected)
// Parameters:
// class PlayerController*        PlayerController_69            (Parm, ZeroConstructor)

void FortProjectEditComponent_CreativeRoyale::OnPlayerLoggedIn(class PlayerController* PlayerController_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CreativeRoyaleRuntime.FortProjectEditComponent_CreativeRoyale.OnPlayerLoggedIn"));

	FortProjectEditComponent_CreativeRoyale_OnPlayerLoggedIn_Params params;
	params.PlayerController_69 = PlayerController_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CreativeRoyaleRuntime.FortProjectEditComponent_CreativeRoyale.LoadPlotFromProject
// (Final, Native, Protected)

void FortProjectEditComponent_CreativeRoyale::LoadPlotFromProject()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CreativeRoyaleRuntime.FortProjectEditComponent_CreativeRoyale.LoadPlotFromProject"));

	FortProjectEditComponent_CreativeRoyale_LoadPlotFromProject_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Classes
//---------------------------------------------------------------------------

// BlueprintGeneratedClass AudioParameterComponent.AudioParameterComponent_C
// 0x0018 (0x00B8 - 0x00A0)
class AudioParameterComponent_C : public ActorComponent
{
public:
	TArray<struct FAudioParameter>                     Parameters_2097153;                                       // 0x00A0(0x0010) (Edit, BlueprintVisible, DisableEditOnInstance)
	class AudioParameterComponent_C*                   RootParameterComponent_2097153;                           // 0x00B0(0x0008) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, InstancedReference)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("BlueprintGeneratedClass AudioParameterComponent.AudioParameterComponent_C"));
		
		return ptr;
	}


	void UpdateRootParameterComponent();
	void GetParameters(TArray<struct FAudioParameter>* Parameters_1);
	void SetIntParameterInternal(const struct FName& Name_1, int Value_1);
	void SetBoolParameterInternal(const struct FName& Name_1, bool Value_1);
	void SetFloatParameterInternal(const struct FName& Name_1, double Value_1);
	void GetRootParameterComponent(class AudioParameterComponent_C** Component_1);
	void FindOrAddGetIndex(const struct FName& Name_1, int* Index_1);
	void SetIntParameter(const struct FName& Name_1, int Value_1);
	void SetBoolParameter(const struct FName& Name_1, bool Value_1);
	void SetFloatParameter(const struct FName& Name_1, double Value_1);
};


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function AudioAnalyzer.AudioAnalyzer.StopAnalyzing
struct AudioAnalyzer_StopAnalyzing_Params
{
	class Object_32759*                                WorldContextObject_69;                                    // (ConstParm, Parm, ZeroConstructor)
};

// Function AudioAnalyzer.AudioAnalyzer.StartAnalyzing
struct AudioAnalyzer_StartAnalyzing_Params
{
	class Object_32759*                                WorldContextObject_69;                                    // (ConstParm, Parm, ZeroConstructor)
	class AudioBus*                                    AudioBusToAnalyze_69;                                     // (Parm, ZeroConstructor)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

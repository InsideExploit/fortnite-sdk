#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Enums
//---------------------------------------------------------------------------

// Enum CraftingRuntime.ECraftingObjectState
enum class ECraftingObjectState : uint8_t
{
	Invalid                        = 0,
	Idle                           = 1,
	Crafting                       = 2,
	Ready                          = 3,
	OverCrafting                   = 4,
	Resetting                      = 5,
	TotalStates                    = 6,
	ECraftingObjectState_MAX       = 7
};


// Enum CraftingRuntime.ECraftingIngredientReqError
enum class ECraftingIngredientReqError : uint8_t
{
	None                           = 0,
	NoItem                         = 1,
	NotEnough                      = 2,
	ECraftingIngredientReqError_MAX = 3
};



//---------------------------------------------------------------------------
//Script Structs
//---------------------------------------------------------------------------

// ScriptStruct CraftingRuntime.CraftingObjectRepStateData
// 0x0008
struct FCraftingObjectRepStateData
{
	ECraftingObjectState                               CraftingObjectState_69;                                   // 0x0000(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0001(0x0003) MISSED OFFSET
	float                                              StateChangeServerTime_69;                                 // 0x0004(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct CraftingRuntime.CraftingResult
// 0x0018
struct FCraftingResult
{
	struct FName                                       ResultLootTierKey_69;                                     // 0x0000(0x0008) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0004(0x0004) MISSED OFFSET
	TArray<struct FItemAndCount>                       Results_69;                                               // 0x0008(0x0010) (ZeroConstructor)
};

// ScriptStruct CraftingRuntime.CraftingIngredientRequirement
// 0x0028
struct FCraftingIngredientRequirement
{
	struct FGameplayTagContainer                       IngredientTags_69;                                        // 0x0000(0x0020) (Edit, BlueprintVisible, BlueprintReadOnly)
	int                                                Count_69;                                                 // 0x0020(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0024(0x0004) MISSED OFFSET
};

// ScriptStruct CraftingRuntime.CraftingIngredientQueryState
// 0x0030
struct FCraftingIngredientQueryState
{
	struct FCraftingIngredientRequirement              Requirement_69;                                           // 0x0000(0x0028) (Edit, BlueprintVisible, BlueprintReadOnly)
	int                                                Owned_69;                                                 // 0x0028(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                Missing_69;                                               // 0x002C(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct CraftingRuntime.CraftingUpgradeRule
// 0x0088
struct FCraftingUpgradeRule
{
	struct FGameplayTagRequirements                    SourceItemTags_69;                                        // 0x0000(0x0040) (Edit, BlueprintVisible, BlueprintReadOnly)
	struct FGameplayTagRequirements                    TargetItemTags_69;                                        // 0x0040(0x0040) (Edit, BlueprintVisible, BlueprintReadOnly)
	unsigned char                                      UpgradeFlags_69;                                          // 0x0080(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0081(0x0007) MISSED OFFSET
};

// ScriptStruct CraftingRuntime.CraftingFormula
// 0x0078 (0x0080 - 0x0008)
struct FCraftingFormula : public FTableRowBase
{
	struct FText                                       DisplayName_69;                                           // 0x0008(0x0018) (Edit, BlueprintVisible, BlueprintReadOnly)
	unsigned char                                      bEnabled_69 : 1;                                          // 0x0020(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly)
	unsigned char                                      bAlwaysKnownFormula_69 : 1;                               // 0x0020(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly)
	unsigned char                                      bInstantlyConsumeIngredients_69 : 1;                      // 0x0020(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0021(0x0003) MISSED OFFSET
	struct FGameplayTag                                SourceObjectTag_69;                                       // 0x0024(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly)
	struct FGameplayTag                                CategoryTag_69;                                           // 0x0028(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly)
	unsigned char                                      UnknownData01[0x4];                                       // 0x002C(0x0004) MISSED OFFSET
	TArray<struct FCraftingIngredientRequirement>      RequiredIngredients_69;                                   // 0x0030(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
	struct FName                                       ResultLootTierKey_69;                                     // 0x0040(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData02[0x4];                                       // 0x0044(0x0004) MISSED OFFSET
	unsigned char                                      UnknownData03[0x28];                                      // 0x0044(0x0028) UNKNOWN PROPERTY: SoftClassProperty CraftingRuntime.CraftingFormula.WhileCraftingAbility_69
	TArray<struct FCraftingUpgradeRule>                UpgradeRules_69;                                          // 0x0070(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
};

// ScriptStruct CraftingRuntime.CraftingIngredientUIData
// 0x0040 (0x0048 - 0x0008)
struct FCraftingIngredientUIData : public FTableRowBase
{
	struct FGameplayTagContainer                       IngredientTags_69;                                        // 0x0008(0x0020) (Edit, BlueprintVisible)
	unsigned char                                      UnknownData00[0x10];                                      // 0x0028(0x0010) UNKNOWN PROPERTY: ArrayProperty CraftingRuntime.CraftingIngredientUIData.ItemDefs_69
	unsigned char                                      UnknownData01[0x10];                                      // 0x0038(0x0010) UNKNOWN PROPERTY: ArrayProperty CraftingRuntime.CraftingIngredientUIData.Icons_69
};

// ScriptStruct CraftingRuntime.CraftingMessage
// 0x0008
struct FCraftingMessage
{
	class Actor_32759*                                 CraftingObject_69;                                        // 0x0000(0x0008) (ZeroConstructor)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Enums
//---------------------------------------------------------------------------

// Enum CommonConversationRuntime.EConversationChoiceType
enum class EConversationChoiceType : uint8_t
{
	ServerOnly                     = 0,
	UserChoiceAvailable            = 1,
	UserChoiceUnavailable          = 2,
	EConversationChoiceType_MAX    = 3
};


// Enum CommonConversationRuntime.EConversationTaskResultType
enum class EConversationTaskResultType : uint8_t
{
	Invalid                        = 0,
	AbortConversation              = 1,
	AdvanceConversation            = 2,
	AdvanceConversationWithChoice  = 3,
	PauseConversationAndSendClientChoices = 4,
	ReturnToLastClientChoice       = 5,
	ReturnToCurrentClientChoice    = 6,
	ReturnToConversationStart      = 7,
	EConversationTaskResultType_MAX = 8
};


// Enum CommonConversationRuntime.EConversationRequirementResult
enum class EConversationRequirementResult : uint8_t
{
	Passed                         = 0,
	FailedButVisible               = 1,
	FailedAndHidden                = 2,
	EConversationRequirementResult_MAX = 3
};



//---------------------------------------------------------------------------
//Script Structs
//---------------------------------------------------------------------------

// ScriptStruct CommonConversationRuntime.ConversationNodeParameterPair
// 0x0020
struct FConversationNodeParameterPair
{
	struct FString                                     Name_69;                                                  // 0x0000(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     Value_69;                                                 // 0x0010(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
};

// ScriptStruct CommonConversationRuntime.ClientConversationMessage
// 0x0048
struct FClientConversationMessage
{
	struct FGameplayTag                                SpeakerID_69;                                             // 0x0000(0x0004) (BlueprintVisible)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0004(0x0004) MISSED OFFSET
	struct FText                                       ParticipantDisplayName_69;                                // 0x0008(0x0018) (BlueprintVisible)
	struct FText                                       Text_69;                                                  // 0x0020(0x0018) (BlueprintVisible)
	TArray<struct FConversationNodeParameterPair>      MetadataParameters_69;                                    // 0x0038(0x0010) (BlueprintVisible, ZeroConstructor)
};

// ScriptStruct CommonConversationRuntime.ConversationParticipantEntry
// 0x0010
struct FConversationParticipantEntry
{
	class Actor_32759*                                 Actor_69;                                                 // 0x0000(0x0008) (BlueprintVisible, ZeroConstructor)
	struct FGameplayTag                                ParticipantID_69;                                         // 0x0008(0x0004) (BlueprintVisible)
	unsigned char                                      UnknownData00[0x4];                                       // 0x000C(0x0004) MISSED OFFSET
};

// ScriptStruct CommonConversationRuntime.ConversationParticipants
// 0x0010
struct FConversationParticipants
{
	TArray<struct FConversationParticipantEntry>       List_69;                                                  // 0x0000(0x0010) (BlueprintVisible, ZeroConstructor)
};

// ScriptStruct CommonConversationRuntime.ConversationNodeHandle
// 0x0010
struct FConversationNodeHandle
{
	struct FGuid                                       NodeGUID_69;                                              // 0x0000(0x0010) (Edit, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct CommonConversationRuntime.ConversationChoiceReference
// 0x0020
struct FConversationChoiceReference
{
	struct FConversationNodeHandle                     NodeReference_69;                                         // 0x0000(0x0010) (BlueprintVisible)
	TArray<struct FConversationNodeParameterPair>      NodeParameters_69;                                        // 0x0010(0x0010) (BlueprintVisible, ZeroConstructor)
};

// ScriptStruct CommonConversationRuntime.ClientConversationOptionEntry
// 0x0070
struct FClientConversationOptionEntry
{
	struct FText                                       ChoiceText_69;                                            // 0x0000(0x0018) (BlueprintVisible)
	struct FGameplayTagContainer                       ChoiceTags_69;                                            // 0x0018(0x0020) (BlueprintVisible)
	EConversationChoiceType                            ChoiceType_69;                                            // 0x0038(0x0001) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0039(0x0007) MISSED OFFSET
	struct FConversationChoiceReference                ChoiceReference_69;                                       // 0x0040(0x0020) (BlueprintVisible)
	TArray<struct FConversationNodeParameterPair>      ExtraData_69;                                             // 0x0060(0x0010) (BlueprintVisible, ZeroConstructor)
};

// ScriptStruct CommonConversationRuntime.ClientConversationMessagePayload
// 0x0078
struct FClientConversationMessagePayload
{
	struct FClientConversationMessage                  message_69;                                               // 0x0000(0x0048) (BlueprintVisible)
	struct FConversationParticipants                   Participants_69;                                          // 0x0048(0x0010) (BlueprintVisible)
	struct FConversationNodeHandle                     CurrentNode_69;                                           // 0x0058(0x0010) (BlueprintVisible)
	TArray<struct FClientConversationOptionEntry>      Options_69;                                               // 0x0068(0x0010) (BlueprintVisible, ZeroConstructor)
};

// ScriptStruct CommonConversationRuntime.AdvanceConversationRequest
// 0x0030
struct FAdvanceConversationRequest
{
	struct FConversationChoiceReference                Choice_69;                                                // 0x0000(0x0020) (BlueprintVisible)
	TArray<struct FConversationNodeParameterPair>      UserParameters_69;                                        // 0x0020(0x0010) (BlueprintVisible, ZeroConstructor)
};

// ScriptStruct CommonConversationRuntime.ConversationContext
// 0x0038
struct FConversationContext
{
	class ConversationRegistry*                        ConversationRegistry_69;                                  // 0x0000(0x0008) (ZeroConstructor)
	class ConversationInstance*                        ActiveConversation_69;                                    // 0x0008(0x0008) (ZeroConstructor)
	class ConversationParticipantComponent*            ClientParticipant_69;                                     // 0x0010(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	class ConversationTaskNode*                        TaskBeingConsidered_69;                                   // 0x0018(0x0008) (ZeroConstructor)
	TArray<struct FConversationNodeHandle>             ReturnScopeStack_69;                                      // 0x0020(0x0010) (ZeroConstructor)
	bool                                               bServer_69;                                               // 0x0030(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0031(0x0007) MISSED OFFSET
};

// ScriptStruct CommonConversationRuntime.ConversationTaskResult
// 0x0080
struct FConversationTaskResult
{
	EConversationTaskResultType                        Type_69;                                                  // 0x0000(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0001(0x0007) MISSED OFFSET
	struct FAdvanceConversationRequest                 AdvanceToChoice_69;                                       // 0x0008(0x0030)
	struct FClientConversationMessage                  message_69;                                               // 0x0038(0x0048)
};

// ScriptStruct CommonConversationRuntime.ConversationEntryList
// 0x0018
struct FConversationEntryList
{
	struct FGameplayTag                                EntryTag_69;                                              // 0x0000(0x0004)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0004(0x0004) MISSED OFFSET
	TArray<struct FGuid>                               DestinationList_69;                                       // 0x0008(0x0010) (ZeroConstructor)
};

// ScriptStruct CommonConversationRuntime.CommonDialogueBankParticipant
// 0x0030
struct FCommonDialogueBankParticipant
{
	struct FText                                       FallbackName_69;                                          // 0x0000(0x0018)
	struct FGameplayTag                                ParticipantName_69;                                       // 0x0018(0x0004) (Edit)
	struct FLinearColor                                NodeTint_69;                                              // 0x001C(0x0010) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x002C(0x0004) MISSED OFFSET
};

// ScriptStruct CommonConversationRuntime.NetSerializeScriptStructCache_ConvVersion
// 0x0060
struct FNetSerializeScriptStructCache_ConvVersion
{
	TMap<class ScriptStruct*, int>                     ScriptStructsToIndex_69;                                  // 0x0000(0x0050)
	TArray<class ScriptStruct*>                        IndexToScriptStructs_69;                                  // 0x0050(0x0010) (ZeroConstructor)
};

// ScriptStruct CommonConversationRuntime.ConversationChoiceData
// 0x0008
struct FConversationChoiceData
{
	unsigned char                                      UnknownData00[0x8];                                       // 0x0000(0x0008) MISSED OFFSET
};

// ScriptStruct CommonConversationRuntime.ConversationChoiceDataHandle
// 0x0020
struct FConversationChoiceDataHandle
{
	unsigned char                                      UnknownData00[0x20];                                      // 0x0000(0x0020) MISSED OFFSET
};

// ScriptStruct CommonConversationRuntime.ConversationBranchPoint
// 0x0080
struct FConversationBranchPoint
{
	TArray<struct FConversationNodeHandle>             ReturnScopeStack_69;                                      // 0x0000(0x0010) (ZeroConstructor)
	struct FClientConversationOptionEntry              ClientChoice_69;                                          // 0x0010(0x0070)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Classes
//---------------------------------------------------------------------------

// Class AssetRegistry.AssetRegistryHelpers
// 0x0000 (0x0028 - 0x0028)
class AssetRegistryHelpers : public Object_32759
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AssetRegistry.AssetRegistryHelpers"));
		
		return ptr;
	}


	struct FSoftObjectPath STATIC_ToSoftObjectPath(const struct FAssetData& InAssetData_69);
	struct FARFilter STATIC_SetFilterTagsAndValues(const struct FARFilter& InFilter_69, TArray<struct FTagAndValue> InTagsAndValues_69);
	bool STATIC_IsValid(const struct FAssetData& InAssetData_69);
	bool STATIC_IsUAsset(const struct FAssetData& InAssetData_69);
	bool STATIC_IsRedirector(const struct FAssetData& InAssetData_69);
	bool STATIC_IsAssetLoaded(const struct FAssetData& InAssetData_69);
	bool STATIC_GetTagValue(const struct FAssetData& InAssetData_69, const struct FName& InTagName_69, struct FString* OutTagValue_69);
	struct FString STATIC_GetFullName(const struct FAssetData& InAssetData_69);
	struct FString STATIC_GetExportTextName(const struct FAssetData& InAssetData_69);
	class Object_32759* STATIC_GetClass(const struct FAssetData& InAssetData_69);
	TScriptInterface<class AssetRegistry> STATIC_GetAssetRegistry();
	class Object_32759* STATIC_GetAsset(const struct FAssetData& InAssetData_69);
	struct FAssetData STATIC_CreateAssetData(class Object_32759* InAsset_69, bool bAllowBlueprintClass_69);
};


// Class AssetRegistry.AssetRegistry
// 0x0000 (0x0028 - 0x0028)
class AssetRegistry : public Interface
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AssetRegistry.AssetRegistry"));
		
		return ptr;
	}


	void WaitForPackage(const struct FString& PackageName_69);
	void WaitForCompletion();
	void UseFilterToExcludeAssets(const struct FARFilter& Filter_69, TArray<struct FAssetData>* AssetDataList_69);
	void SearchAllAssets(bool bSynchronousSearch_69);
	void ScanPathsSynchronous(TArray<struct FString> InPaths_69, bool bForceRescan_69, bool bIgnoreDenyListScanFilters_69);
	void ScanModifiedAssetFiles(TArray<struct FString> InFilePaths_69);
	void ScanFilesSynchronous(TArray<struct FString> InFilePaths_69, bool bForceRescan_69);
	void RunAssetsThroughFilter(const struct FARFilter& Filter_69, TArray<struct FAssetData>* AssetDataList_69);
	void PrioritizeSearchPath(const struct FString& PathToPrioritize_69);
	bool K2_GetReferencers(const struct FName& PackageName_69, const struct FAssetRegistryDependencyOptions& ReferenceOptions_69, TArray<struct FName>* OutReferencers_69);
	bool K2_GetDependencies(const struct FName& PackageName_69, const struct FAssetRegistryDependencyOptions& DependencyOptions_69, TArray<struct FName>* OutDependencies_69);
	bool IsSearchAsync();
	bool IsSearchAllAssets();
	bool IsLoadingAssets();
	bool HasAssets(const struct FName& PackagePath_69, bool bRecursive_69);
	void GetSubPaths(const struct FString& InBasePath_69, bool bInRecurse_69, TArray<struct FString>* OutPathList_69);
	bool GetAssetsByPaths(TArray<struct FName> PackagePaths_69, bool bRecursive_69, bool bIncludeOnlyOnDiskAssets_69, TArray<struct FAssetData>* OutAssetData_69);
	bool GetAssetsByPath(const struct FName& PackagePath_69, bool bRecursive_69, bool bIncludeOnlyOnDiskAssets_69, TArray<struct FAssetData>* OutAssetData_69);
	bool GetAssetsByPackageName(const struct FName& PackageName_69, bool bIncludeOnlyOnDiskAssets_69, TArray<struct FAssetData>* OutAssetData_69);
	bool GetAssetsByClass(const struct FTopLevelAssetPath& ClassPathName_69, bool bSearchSubClasses_69, TArray<struct FAssetData>* OutAssetData_69);
	bool GetAssets(const struct FARFilter& Filter_69, TArray<struct FAssetData>* OutAssetData_69);
	struct FAssetData GetAssetByObjectPath(const struct FName& ObjectPath_69, bool bIncludeOnlyOnDiskAssets_69);
	void GetAllCachedPaths(TArray<struct FString>* OutPathList_69);
	bool GetAllAssets(bool bIncludeOnlyOnDiskAssets_69, TArray<struct FAssetData>* OutAssetData_69);
};


// Class AssetRegistry.AssetRegistryImpl
// 0x0998 (0x09C0 - 0x0028)
class AssetRegistryImpl : public Object_32759
{
public:
	unsigned char                                      UnknownData00[0x998];                                     // 0x0028(0x0998) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AssetRegistry.AssetRegistryImpl"));
		
		return ptr;
	}

};


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

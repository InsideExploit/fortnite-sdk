#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function AmbientAudio.AmbientAudioComponent.SetPriority
struct AmbientAudioComponent_SetPriority_Params
{
	int                                                InPriority_69;                                            // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function AmbientAudio.AmbientAudioComponent.SetCrossfadeTime
struct AmbientAudioComponent_SetCrossfadeTime_Params
{
	float                                              InCrossfadeTime_69;                                       // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function AmbientAudio.AmbientAudioComponent.SetAmbientAsset
struct AmbientAudioComponent_SetAmbientAsset_Params
{
	class AmbientAudioDataAsset*                       InAmbientAsset_69;                                        // (Parm, ZeroConstructor)
};

// Function AmbientAudio.AmbientAudioSubsystem.RemoveGameplayTag
struct AmbientAudioSubsystem_RemoveGameplayTag_Params
{
	struct FGameplayTag                                GameplayTag_69;                                           // (Parm)
};

// Function AmbientAudio.AmbientAudioSubsystem.RemoveAmbientEntry
struct AmbientAudioSubsystem_RemoveAmbientEntry_Params
{
	struct FName                                       AmbientName_69;                                           // (Parm, ZeroConstructor, IsPlainOldData)
	float                                              CrossfadeOverride_69;                                     // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function AmbientAudio.AmbientAudioSubsystem.AddGameplayTag
struct AmbientAudioSubsystem_AddGameplayTag_Params
{
	struct FGameplayTag                                GameplayTag_69;                                           // (Parm)
};

// Function AmbientAudio.AmbientAudioSubsystem.AddAmbientEntry
struct AmbientAudioSubsystem_AddAmbientEntry_Params
{
	struct FName                                       AmbientName_69;                                           // (Parm, ZeroConstructor, IsPlainOldData)
	class AmbientAudioDataAsset*                       Asset_69;                                                 // (Parm, ZeroConstructor)
	int                                                Priority_69;                                              // (Parm, ZeroConstructor, IsPlainOldData)
	float                                              CrossfadeTime_69;                                         // (Parm, ZeroConstructor, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

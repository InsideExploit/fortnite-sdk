// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Functions
//---------------------------------------------------------------------------

// Function ChaosCloth.ChaosClothingInteractor.SetWind
// (Final, Native, Public, HasDefaults, BlueprintCallable)
// Parameters:
// struct FVector2D               Drag_69                        (Parm, ZeroConstructor, IsPlainOldData)
// struct FVector2D               Lift_69                        (Parm, ZeroConstructor, IsPlainOldData)
// float                          AirDensity_69                  (Parm, ZeroConstructor, IsPlainOldData)
// struct FVector                 WindVelocity_69                (Parm, ZeroConstructor, IsPlainOldData)

void ChaosClothingInteractor::SetWind(const struct FVector2D& Drag_69, const struct FVector2D& Lift_69, float AirDensity_69, const struct FVector& WindVelocity_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ChaosCloth.ChaosClothingInteractor.SetWind"));

	ChaosClothingInteractor_SetWind_Params params;
	params.Drag_69 = Drag_69;
	params.Lift_69 = Lift_69;
	params.AirDensity_69 = AirDensity_69;
	params.WindVelocity_69 = WindVelocity_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ChaosCloth.ChaosClothingInteractor.SetVelocityScale
// (Final, Native, Public, HasDefaults, BlueprintCallable)
// Parameters:
// struct FVector                 LinearVelocityScale_69         (Parm, ZeroConstructor, IsPlainOldData)
// float                          AngularVelocityScale_69        (Parm, ZeroConstructor, IsPlainOldData)
// float                          FictitiousAngularScale_69      (Parm, ZeroConstructor, IsPlainOldData)

void ChaosClothingInteractor::SetVelocityScale(const struct FVector& LinearVelocityScale_69, float AngularVelocityScale_69, float FictitiousAngularScale_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ChaosCloth.ChaosClothingInteractor.SetVelocityScale"));

	ChaosClothingInteractor_SetVelocityScale_Params params;
	params.LinearVelocityScale_69 = LinearVelocityScale_69;
	params.AngularVelocityScale_69 = AngularVelocityScale_69;
	params.FictitiousAngularScale_69 = FictitiousAngularScale_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ChaosCloth.ChaosClothingInteractor.SetPressure
// (Final, Native, Public, HasDefaults, BlueprintCallable)
// Parameters:
// struct FVector2D               Pressure_69                    (Parm, ZeroConstructor, IsPlainOldData)

void ChaosClothingInteractor::SetPressure(const struct FVector2D& Pressure_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ChaosCloth.ChaosClothingInteractor.SetPressure"));

	ChaosClothingInteractor_SetPressure_Params params;
	params.Pressure_69 = Pressure_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ChaosCloth.ChaosClothingInteractor.SetMaterialLinear
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// float                          EdgeStiffness_69               (Parm, ZeroConstructor, IsPlainOldData)
// float                          BendingStiffness_69            (Parm, ZeroConstructor, IsPlainOldData)
// float                          AreaStiffness_69               (Parm, ZeroConstructor, IsPlainOldData)

void ChaosClothingInteractor::SetMaterialLinear(float EdgeStiffness_69, float BendingStiffness_69, float AreaStiffness_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ChaosCloth.ChaosClothingInteractor.SetMaterialLinear"));

	ChaosClothingInteractor_SetMaterialLinear_Params params;
	params.EdgeStiffness_69 = EdgeStiffness_69;
	params.BendingStiffness_69 = BendingStiffness_69;
	params.AreaStiffness_69 = AreaStiffness_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ChaosCloth.ChaosClothingInteractor.SetMaterial
// (Final, Native, Public, HasDefaults, BlueprintCallable)
// Parameters:
// struct FVector2D               EdgeStiffness_69               (Parm, ZeroConstructor, IsPlainOldData)
// struct FVector2D               BendingStiffness_69            (Parm, ZeroConstructor, IsPlainOldData)
// struct FVector2D               AreaStiffness_69               (Parm, ZeroConstructor, IsPlainOldData)

void ChaosClothingInteractor::SetMaterial(const struct FVector2D& EdgeStiffness_69, const struct FVector2D& BendingStiffness_69, const struct FVector2D& AreaStiffness_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ChaosCloth.ChaosClothingInteractor.SetMaterial"));

	ChaosClothingInteractor_SetMaterial_Params params;
	params.EdgeStiffness_69 = EdgeStiffness_69;
	params.BendingStiffness_69 = BendingStiffness_69;
	params.AreaStiffness_69 = AreaStiffness_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ChaosCloth.ChaosClothingInteractor.SetLongRangeAttachmentLinear
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// float                          TetherStiffness_69             (Parm, ZeroConstructor, IsPlainOldData)
// float                          TetherScale_69                 (Parm, ZeroConstructor, IsPlainOldData)

void ChaosClothingInteractor::SetLongRangeAttachmentLinear(float TetherStiffness_69, float TetherScale_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ChaosCloth.ChaosClothingInteractor.SetLongRangeAttachmentLinear"));

	ChaosClothingInteractor_SetLongRangeAttachmentLinear_Params params;
	params.TetherStiffness_69 = TetherStiffness_69;
	params.TetherScale_69 = TetherScale_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ChaosCloth.ChaosClothingInteractor.SetLongRangeAttachment
// (Final, Native, Public, HasDefaults, BlueprintCallable)
// Parameters:
// struct FVector2D               TetherStiffness_69             (Parm, ZeroConstructor, IsPlainOldData)
// struct FVector2D               TetherScale_69                 (Parm, ZeroConstructor, IsPlainOldData)

void ChaosClothingInteractor::SetLongRangeAttachment(const struct FVector2D& TetherStiffness_69, const struct FVector2D& TetherScale_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ChaosCloth.ChaosClothingInteractor.SetLongRangeAttachment"));

	ChaosClothingInteractor_SetLongRangeAttachment_Params params;
	params.TetherStiffness_69 = TetherStiffness_69;
	params.TetherScale_69 = TetherScale_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ChaosCloth.ChaosClothingInteractor.SetGravity
// (Final, Native, Public, HasDefaults, BlueprintCallable)
// Parameters:
// float                          GravityScale_69                (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bIsGravityOverridden_69        (Parm, ZeroConstructor, IsPlainOldData)
// struct FVector                 GravityOverride_69             (Parm, ZeroConstructor, IsPlainOldData)

void ChaosClothingInteractor::SetGravity(float GravityScale_69, bool bIsGravityOverridden_69, const struct FVector& GravityOverride_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ChaosCloth.ChaosClothingInteractor.SetGravity"));

	ChaosClothingInteractor_SetGravity_Params params;
	params.GravityScale_69 = GravityScale_69;
	params.bIsGravityOverridden_69 = bIsGravityOverridden_69;
	params.GravityOverride_69 = GravityOverride_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ChaosCloth.ChaosClothingInteractor.SetDamping
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// float                          DampingCoefficient_69          (Parm, ZeroConstructor, IsPlainOldData)
// float                          LocalDampingCoefficient_69     (Parm, ZeroConstructor, IsPlainOldData)

void ChaosClothingInteractor::SetDamping(float DampingCoefficient_69, float LocalDampingCoefficient_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ChaosCloth.ChaosClothingInteractor.SetDamping"));

	ChaosClothingInteractor_SetDamping_Params params;
	params.DampingCoefficient_69 = DampingCoefficient_69;
	params.LocalDampingCoefficient_69 = LocalDampingCoefficient_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ChaosCloth.ChaosClothingInteractor.SetCollision
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// float                          CollisionThickness_69          (Parm, ZeroConstructor, IsPlainOldData)
// float                          FrictionCoefficient_69         (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bUseCCD_69                     (Parm, ZeroConstructor, IsPlainOldData)
// float                          SelfCollisionThickness_69      (Parm, ZeroConstructor, IsPlainOldData)

void ChaosClothingInteractor::SetCollision(float CollisionThickness_69, float FrictionCoefficient_69, bool bUseCCD_69, float SelfCollisionThickness_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ChaosCloth.ChaosClothingInteractor.SetCollision"));

	ChaosClothingInteractor_SetCollision_Params params;
	params.CollisionThickness_69 = CollisionThickness_69;
	params.FrictionCoefficient_69 = FrictionCoefficient_69;
	params.bUseCCD_69 = bUseCCD_69;
	params.SelfCollisionThickness_69 = SelfCollisionThickness_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ChaosCloth.ChaosClothingInteractor.SetBackstop
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// bool                           bEnabled_69                    (Parm, ZeroConstructor, IsPlainOldData)

void ChaosClothingInteractor::SetBackstop(bool bEnabled_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ChaosCloth.ChaosClothingInteractor.SetBackstop"));

	ChaosClothingInteractor_SetBackstop_Params params;
	params.bEnabled_69 = bEnabled_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ChaosCloth.ChaosClothingInteractor.SetAnimDriveLinear
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// float                          AnimDriveStiffness_69          (Parm, ZeroConstructor, IsPlainOldData)

void ChaosClothingInteractor::SetAnimDriveLinear(float AnimDriveStiffness_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ChaosCloth.ChaosClothingInteractor.SetAnimDriveLinear"));

	ChaosClothingInteractor_SetAnimDriveLinear_Params params;
	params.AnimDriveStiffness_69 = AnimDriveStiffness_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ChaosCloth.ChaosClothingInteractor.SetAnimDrive
// (Final, Native, Public, HasDefaults, BlueprintCallable)
// Parameters:
// struct FVector2D               AnimDriveStiffness_69          (Parm, ZeroConstructor, IsPlainOldData)
// struct FVector2D               AnimDriveDamping_69            (Parm, ZeroConstructor, IsPlainOldData)

void ChaosClothingInteractor::SetAnimDrive(const struct FVector2D& AnimDriveStiffness_69, const struct FVector2D& AnimDriveDamping_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ChaosCloth.ChaosClothingInteractor.SetAnimDrive"));

	ChaosClothingInteractor_SetAnimDrive_Params params;
	params.AnimDriveStiffness_69 = AnimDriveStiffness_69;
	params.AnimDriveDamping_69 = AnimDriveDamping_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ChaosCloth.ChaosClothingInteractor.SetAerodynamics
// (Final, Native, Public, HasDefaults, BlueprintCallable)
// Parameters:
// float                          DragCoefficient_69             (Parm, ZeroConstructor, IsPlainOldData)
// float                          LiftCoefficient_69             (Parm, ZeroConstructor, IsPlainOldData)
// struct FVector                 WindVelocity_69                (Parm, ZeroConstructor, IsPlainOldData)

void ChaosClothingInteractor::SetAerodynamics(float DragCoefficient_69, float LiftCoefficient_69, const struct FVector& WindVelocity_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ChaosCloth.ChaosClothingInteractor.SetAerodynamics"));

	ChaosClothingInteractor_SetAerodynamics_Params params;
	params.DragCoefficient_69 = DragCoefficient_69;
	params.LiftCoefficient_69 = LiftCoefficient_69;
	params.WindVelocity_69 = WindVelocity_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ChaosCloth.ChaosClothingInteractor.ResetAndTeleport
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// bool                           bReset_69                      (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bTeleport_69                   (Parm, ZeroConstructor, IsPlainOldData)

void ChaosClothingInteractor::ResetAndTeleport(bool bReset_69, bool bTeleport_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ChaosCloth.ChaosClothingInteractor.ResetAndTeleport"));

	ChaosClothingInteractor_ResetAndTeleport_Params params;
	params.bReset_69 = bReset_69;
	params.bTeleport_69 = bTeleport_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

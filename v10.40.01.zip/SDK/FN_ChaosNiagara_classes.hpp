#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Classes
//---------------------------------------------------------------------------

// Class ChaosNiagara.NiagaraDataInterfaceChaosDestruction
// 0x0310 (0x0348 - 0x0038)
class NiagaraDataInterfaceChaosDestruction : public NiagaraDataInterface
{
public:
	unsigned char                                      UnknownData00[0x50];                                      // 0x0038(0x0050) UNKNOWN PROPERTY: SetProperty ChaosNiagara.NiagaraDataInterfaceChaosDestruction.ChaosSolverActorSet_69
	EDataSourceTypeEnum                                DataSourceType_69;                                        // 0x0088(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x3];                                       // 0x0089(0x0003) MISSED OFFSET
	int                                                DataProcessFrequency_69;                                  // 0x008C(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	int                                                MaxNumberOfDataEntriesToSpawn_69;                         // 0x0090(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	bool                                               DoSpawn_69;                                               // 0x0094(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData02[0x3];                                       // 0x0095(0x0003) MISSED OFFSET
	struct FVector2D                                   SpawnMultiplierMinMax_69;                                 // 0x0098(0x0010) (Edit, ZeroConstructor, IsPlainOldData)
	float                                              SpawnChance_69;                                           // 0x00A8(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData03[0x4];                                       // 0x00AC(0x0004) MISSED OFFSET
	struct FVector2D                                   ImpulseToSpawnMinMax_69;                                  // 0x00B0(0x0010) (Edit, ZeroConstructor, IsPlainOldData)
	struct FVector2D                                   SpeedToSpawnMinMax_69;                                    // 0x00C0(0x0010) (Edit, ZeroConstructor, IsPlainOldData)
	struct FVector2D                                   MassToSpawnMinMax_69;                                     // 0x00D0(0x0010) (Edit, ZeroConstructor, IsPlainOldData)
	struct FVector2D                                   ExtentMinToSpawnMinMax_69;                                // 0x00E0(0x0010) (Edit, ZeroConstructor, IsPlainOldData)
	struct FVector2D                                   ExtentMaxToSpawnMinMax_69;                                // 0x00F0(0x0010) (Edit, ZeroConstructor, IsPlainOldData)
	struct FVector2D                                   VolumeToSpawnMinMax_69;                                   // 0x0100(0x0010) (Edit, ZeroConstructor, IsPlainOldData)
	struct FVector2D                                   SolverTimeToSpawnMinMax_69;                               // 0x0110(0x0010) (Edit, ZeroConstructor, IsPlainOldData)
	int                                                SurfaceTypeToSpawn_69;                                    // 0x0120(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	ELocationFilteringModeEnum                         LocationFilteringMode_69;                                 // 0x0124(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	ELocationXToSpawnEnum                              LocationXToSpawn_69;                                      // 0x0125(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData04[0x2];                                       // 0x0126(0x0002) MISSED OFFSET
	struct FVector2D                                   LocationXToSpawnMinMax_69;                                // 0x0128(0x0010) (Edit, ZeroConstructor, IsPlainOldData)
	ELocationYToSpawnEnum                              LocationYToSpawn_69;                                      // 0x0138(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData05[0x7];                                       // 0x0139(0x0007) MISSED OFFSET
	struct FVector2D                                   LocationYToSpawnMinMax_69;                                // 0x0140(0x0010) (Edit, ZeroConstructor, IsPlainOldData)
	ELocationZToSpawnEnum                              LocationZToSpawn_69;                                      // 0x0150(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData06[0x7];                                       // 0x0151(0x0007) MISSED OFFSET
	struct FVector2D                                   LocationZToSpawnMinMax_69;                                // 0x0158(0x0010) (Edit, ZeroConstructor, IsPlainOldData)
	float                                              TrailMinSpeedToSpawn_69;                                  // 0x0168(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	EDataSortTypeEnum                                  DataSortingType_69;                                       // 0x016C(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	bool                                               bGetExternalCollisionData_69;                             // 0x016D(0x0001) (Edit, ZeroConstructor, EditConst, IsPlainOldData)
	bool                                               DoSpatialHash_69;                                         // 0x016E(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData07[0x1];                                       // 0x016F(0x0001) MISSED OFFSET
	struct FVector                                     SpatialHashVolumeMin_69;                                  // 0x0170(0x0018) (Edit, ZeroConstructor, IsPlainOldData)
	struct FVector                                     SpatialHashVolumeMax_69;                                  // 0x0188(0x0018) (Edit, ZeroConstructor, IsPlainOldData)
	struct FVector                                     SpatialHashVolumeCellSize_69;                             // 0x01A0(0x0018) (Edit, ZeroConstructor, IsPlainOldData)
	int                                                MaxDataPerCell_69;                                        // 0x01B8(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	bool                                               bApplyMaterialsFilter_69;                                 // 0x01BC(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData08[0x3];                                       // 0x01BD(0x0003) MISSED OFFSET
	unsigned char                                      UnknownData09[0x50];                                      // 0x01BD(0x0050) UNKNOWN PROPERTY: SetProperty ChaosNiagara.NiagaraDataInterfaceChaosDestruction.ChaosBreakingMaterialSet_69
	bool                                               bGetExternalBreakingData_69;                              // 0x0210(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	bool                                               bGetExternalTrailingData_69;                              // 0x0211(0x0001) (Edit, ZeroConstructor, EditConst, IsPlainOldData)
	unsigned char                                      UnknownData10[0x6];                                       // 0x0212(0x0006) MISSED OFFSET
	struct FVector2D                                   RandomPositionMagnitudeMinMax_69;                         // 0x0218(0x0010) (Edit, ZeroConstructor, IsPlainOldData)
	float                                              InheritedVelocityMultiplier_69;                           // 0x0228(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	ERandomVelocityGenerationTypeEnum                  RandomVelocityGenerationType_69;                          // 0x022C(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData11[0x3];                                       // 0x022D(0x0003) MISSED OFFSET
	struct FVector2D                                   RandomVelocityMagnitudeMinMax_69;                         // 0x0230(0x0010) (Edit, ZeroConstructor, IsPlainOldData)
	float                                              SpreadAngleMax_69;                                        // 0x0240(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData12[0x4];                                       // 0x0244(0x0004) MISSED OFFSET
	struct FVector                                     VelocityOffsetMin_69;                                     // 0x0248(0x0018) (Edit, ZeroConstructor, IsPlainOldData)
	struct FVector                                     VelocityOffsetMax_69;                                     // 0x0260(0x0018) (Edit, ZeroConstructor, IsPlainOldData)
	struct FVector2D                                   FinalVelocityMagnitudeMinMax_69;                          // 0x0278(0x0010) (Edit, ZeroConstructor, IsPlainOldData)
	float                                              MaxLatency_69;                                            // 0x0288(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	EDebugTypeEnum                                     DebugType_69;                                             // 0x028C(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData13[0x3];                                       // 0x028D(0x0003) MISSED OFFSET
	int                                                LastSpawnedPointID_69;                                    // 0x0290(0x0004) (ZeroConstructor, IsPlainOldData)
	float                                              LastSpawnTime_69;                                         // 0x0294(0x0004) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData14[0x10];                                      // 0x0298(0x0010) MISSED OFFSET
	float                                              SolverTime_69;                                            // 0x02A8(0x0004) (ZeroConstructor, IsPlainOldData)
	float                                              TimeStampOfLastProcessedData_69;                          // 0x02AC(0x0004) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData15[0x98];                                      // 0x02B0(0x0098) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class ChaosNiagara.NiagaraDataInterfaceChaosDestruction"));
		
		return ptr;
	}

};


// Class ChaosNiagara.NiagaraDataInterfaceGeometryCollection
// 0x0008 (0x0040 - 0x0038)
class NiagaraDataInterfaceGeometryCollection : public NiagaraDataInterface
{
public:
	class GeometryCollectionActor*                     GeometryCollectionActor_69;                               // 0x0038(0x0008) (Edit, ZeroConstructor)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class ChaosNiagara.NiagaraDataInterfaceGeometryCollection"));
		
		return ptr;
	}

};


// Class ChaosNiagara.NiagaraDataInterfacePhysicsField
// 0x0000 (0x0038 - 0x0038)
class NiagaraDataInterfacePhysicsField : public NiagaraDataInterface
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class ChaosNiagara.NiagaraDataInterfacePhysicsField"));
		
		return ptr;
	}

};


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

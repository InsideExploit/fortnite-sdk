#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Classes
//---------------------------------------------------------------------------

// Class ChromePlayerUI.ChromePlayerInfoWidget
// 0x0010 (0x02E0 - 0x02D0)
class ChromePlayerInfoWidget : public FortHUDElementWidget
{
public:
	unsigned char                                      UnknownData00[0x10];                                      // 0x02D0(0x0010) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class ChromePlayerUI.ChromePlayerInfoWidget"));
		
		return ptr;
	}


	void OnPlayerStateSet(class FortPlayerStateAthena* InPlayerState_69);
	void OnPlayerDeadStateChanged(class FortPlayerStateAthena* PlayerState_69, bool bIsDead_69);
};


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Functions
//---------------------------------------------------------------------------

// Function AugmentedReality.ARActor.AddARComponent
// (Final, Native, Public, HasOutParms, HasDefaults, BlueprintCallable)
// Parameters:
// class ARComponent*             InComponentClass_69            (Parm, ZeroConstructor)
// struct FGuid                   NativeID_69                    (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
// class ARComponent*             ReturnValue_69                 (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)

class ARComponent* ARActor::AddARComponent(class ARComponent* InComponentClass_69, const struct FGuid& NativeID_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARActor.AddARComponent"));

	ARActor_AddARComponent_Params params;
	params.InComponentClass_69 = InComponentClass_69;
	params.NativeID_69 = NativeID_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AugmentedReality.ARBlueprintLibrary.UnpinComponent
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// class SceneComponent*          ComponentToUnpin_69            (Parm, ZeroConstructor, InstancedReference)

void ARBlueprintLibrary::STATIC_UnpinComponent(class SceneComponent* ComponentToUnpin_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARBlueprintLibrary.UnpinComponent"));

	ARBlueprintLibrary_UnpinComponent_Params params;
	params.ComponentToUnpin_69 = ComponentToUnpin_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AugmentedReality.ARBlueprintLibrary.ToggleARCapture
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// bool                           bOnOff_69                      (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// EARCaptureType                 CaptureType_69                 (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool ARBlueprintLibrary::STATIC_ToggleARCapture(bool bOnOff_69, EARCaptureType CaptureType_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARBlueprintLibrary.ToggleARCapture"));

	ARBlueprintLibrary_ToggleARCapture_Params params;
	params.bOnOff_69 = bOnOff_69;
	params.CaptureType_69 = CaptureType_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AugmentedReality.ARBlueprintLibrary.StopARSession
// (Final, Native, Static, Public, BlueprintCallable)

void ARBlueprintLibrary::STATIC_StopARSession()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARBlueprintLibrary.StopARSession"));

	ARBlueprintLibrary_StopARSession_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AugmentedReality.ARBlueprintLibrary.StartARSession
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// class ARSessionConfig*         SessionConfig_69               (Parm, ZeroConstructor)

void ARBlueprintLibrary::STATIC_StartARSession(class ARSessionConfig* SessionConfig_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARBlueprintLibrary.StartARSession"));

	ARBlueprintLibrary_StartARSession_Params params;
	params.SessionConfig_69 = SessionConfig_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AugmentedReality.ARBlueprintLibrary.SetEnabledXRCamera
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// bool                           bOnOff_69                      (Parm, ZeroConstructor, IsPlainOldData)

void ARBlueprintLibrary::STATIC_SetEnabledXRCamera(bool bOnOff_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARBlueprintLibrary.SetEnabledXRCamera"));

	ARBlueprintLibrary_SetEnabledXRCamera_Params params;
	params.bOnOff_69 = bOnOff_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AugmentedReality.ARBlueprintLibrary.SetARWorldScale
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// float                          InWorldScale_69                (Parm, ZeroConstructor, IsPlainOldData)

void ARBlueprintLibrary::STATIC_SetARWorldScale(float InWorldScale_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARBlueprintLibrary.SetARWorldScale"));

	ARBlueprintLibrary_SetARWorldScale_Params params;
	params.InWorldScale_69 = InWorldScale_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AugmentedReality.ARBlueprintLibrary.SetARWorldOriginLocationAndRotation
// (Final, Native, Static, Public, HasDefaults, BlueprintCallable)
// Parameters:
// struct FVector                 OriginLocation_69              (Parm, ZeroConstructor, IsPlainOldData)
// struct FRotator                OriginRotation_69              (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bIsTransformInWorldSpace_69    (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bMaintainUpDirection_69        (Parm, ZeroConstructor, IsPlainOldData)

void ARBlueprintLibrary::STATIC_SetARWorldOriginLocationAndRotation(const struct FVector& OriginLocation_69, const struct FRotator& OriginRotation_69, bool bIsTransformInWorldSpace_69, bool bMaintainUpDirection_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARBlueprintLibrary.SetARWorldOriginLocationAndRotation"));

	ARBlueprintLibrary_SetARWorldOriginLocationAndRotation_Params params;
	params.OriginLocation_69 = OriginLocation_69;
	params.OriginRotation_69 = OriginRotation_69;
	params.bIsTransformInWorldSpace_69 = bIsTransformInWorldSpace_69;
	params.bMaintainUpDirection_69 = bMaintainUpDirection_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AugmentedReality.ARBlueprintLibrary.SetAlignmentTransform
// (Final, Native, Static, Public, HasOutParms, HasDefaults, BlueprintCallable)
// Parameters:
// struct FCoreUObject_FTransform InAlignmentTransform_69        (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)

void ARBlueprintLibrary::STATIC_SetAlignmentTransform(const struct FCoreUObject_FTransform& InAlignmentTransform_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARBlueprintLibrary.SetAlignmentTransform"));

	ARBlueprintLibrary_SetAlignmentTransform_Params params;
	params.InAlignmentTransform_69 = InAlignmentTransform_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AugmentedReality.ARBlueprintLibrary.SaveARPinToLocalStore
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// struct FName                   InSaveName_69                  (Parm, ZeroConstructor, IsPlainOldData)
// class ARPin*                   InPin_69                       (Parm, ZeroConstructor)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool ARBlueprintLibrary::STATIC_SaveARPinToLocalStore(const struct FName& InSaveName_69, class ARPin* InPin_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARBlueprintLibrary.SaveARPinToLocalStore"));

	ARBlueprintLibrary_SaveARPinToLocalStore_Params params;
	params.InSaveName_69 = InSaveName_69;
	params.InPin_69 = InPin_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AugmentedReality.ARBlueprintLibrary.ResizeXRCamera
// (Final, Native, Static, Public, HasOutParms, HasDefaults, BlueprintCallable)
// Parameters:
// struct FIntPoint               InSize_69                      (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
// struct FIntPoint               ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

struct FIntPoint ARBlueprintLibrary::STATIC_ResizeXRCamera(const struct FIntPoint& InSize_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARBlueprintLibrary.ResizeXRCamera"));

	ARBlueprintLibrary_ResizeXRCamera_Params params;
	params.InSize_69 = InSize_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AugmentedReality.ARBlueprintLibrary.RemovePin
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// class ARPin*                   PinToRemove_69                 (Parm, ZeroConstructor)

void ARBlueprintLibrary::STATIC_RemovePin(class ARPin* PinToRemove_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARBlueprintLibrary.RemovePin"));

	ARBlueprintLibrary_RemovePin_Params params;
	params.PinToRemove_69 = PinToRemove_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AugmentedReality.ARBlueprintLibrary.RemoveARPinFromLocalStore
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// struct FName                   InSaveName_69                  (Parm, ZeroConstructor, IsPlainOldData)

void ARBlueprintLibrary::STATIC_RemoveARPinFromLocalStore(const struct FName& InSaveName_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARBlueprintLibrary.RemoveARPinFromLocalStore"));

	ARBlueprintLibrary_RemoveARPinFromLocalStore_Params params;
	params.InSaveName_69 = InSaveName_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AugmentedReality.ARBlueprintLibrary.RemoveAllARPinsFromLocalStore
// (Final, Native, Static, Public, BlueprintCallable)

void ARBlueprintLibrary::STATIC_RemoveAllARPinsFromLocalStore()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARBlueprintLibrary.RemoveAllARPinsFromLocalStore"));

	ARBlueprintLibrary_RemoveAllARPinsFromLocalStore_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AugmentedReality.ARBlueprintLibrary.PinComponentToTraceResult
// (Final, Native, Static, Public, HasOutParms, BlueprintCallable)
// Parameters:
// class SceneComponent*          ComponentToPin_69              (Parm, ZeroConstructor, InstancedReference)
// struct FARTraceResult          TraceResult_69                 (ConstParm, Parm, OutParm, ReferenceParm)
// struct FName                   DebugName_69                   (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// class ARPin*                   ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

class ARPin* ARBlueprintLibrary::STATIC_PinComponentToTraceResult(class SceneComponent* ComponentToPin_69, const struct FARTraceResult& TraceResult_69, const struct FName& DebugName_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARBlueprintLibrary.PinComponentToTraceResult"));

	ARBlueprintLibrary_PinComponentToTraceResult_Params params;
	params.ComponentToPin_69 = ComponentToPin_69;
	params.TraceResult_69 = TraceResult_69;
	params.DebugName_69 = DebugName_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AugmentedReality.ARBlueprintLibrary.PinComponentToARPin
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// class SceneComponent*          ComponentToPin_69              (Parm, ZeroConstructor, InstancedReference)
// class ARPin*                   Pin_69                         (Parm, ZeroConstructor)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool ARBlueprintLibrary::STATIC_PinComponentToARPin(class SceneComponent* ComponentToPin_69, class ARPin* Pin_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARBlueprintLibrary.PinComponentToARPin"));

	ARBlueprintLibrary_PinComponentToARPin_Params params;
	params.ComponentToPin_69 = ComponentToPin_69;
	params.Pin_69 = Pin_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AugmentedReality.ARBlueprintLibrary.PinComponent
// (Final, Native, Static, Public, HasOutParms, HasDefaults, BlueprintCallable)
// Parameters:
// class SceneComponent*          ComponentToPin_69              (Parm, ZeroConstructor, InstancedReference)
// struct FCoreUObject_FTransform PinToWorldTransform_69         (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
// class ARTrackedGeometry*       TrackedGeometry_69             (Parm, ZeroConstructor)
// struct FName                   DebugName_69                   (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// class ARPin*                   ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

class ARPin* ARBlueprintLibrary::STATIC_PinComponent(class SceneComponent* ComponentToPin_69, const struct FCoreUObject_FTransform& PinToWorldTransform_69, class ARTrackedGeometry* TrackedGeometry_69, const struct FName& DebugName_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARBlueprintLibrary.PinComponent"));

	ARBlueprintLibrary_PinComponent_Params params;
	params.ComponentToPin_69 = ComponentToPin_69;
	params.PinToWorldTransform_69 = PinToWorldTransform_69;
	params.TrackedGeometry_69 = TrackedGeometry_69;
	params.DebugName_69 = DebugName_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AugmentedReality.ARBlueprintLibrary.PauseARSession
// (Final, Native, Static, Public, BlueprintCallable)

void ARBlueprintLibrary::STATIC_PauseARSession()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARBlueprintLibrary.PauseARSession"));

	ARBlueprintLibrary_PauseARSession_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AugmentedReality.ARBlueprintLibrary.LoadARPinsFromLocalStore
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// TMap<struct FName, class ARPin*> ReturnValue_69                 (Parm, OutParm, ReturnParm)

TMap<struct FName, class ARPin*> ARBlueprintLibrary::STATIC_LoadARPinsFromLocalStore()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARBlueprintLibrary.LoadARPinsFromLocalStore"));

	ARBlueprintLibrary_LoadARPinsFromLocalStore_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AugmentedReality.ARBlueprintLibrary.LineTraceTrackedObjects3D
// (Final, Native, Static, Public, HasDefaults, BlueprintCallable)
// Parameters:
// struct FVector                 Start_69                       (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// struct FVector                 End_69                         (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// bool                           bTestFeaturePoints_69          (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bTestGroundPlane_69            (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bTestPlaneExtents_69           (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bTestPlaneBoundaryPolygon_69   (Parm, ZeroConstructor, IsPlainOldData)
// TArray<struct FARTraceResult>  ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

TArray<struct FARTraceResult> ARBlueprintLibrary::STATIC_LineTraceTrackedObjects3D(const struct FVector& Start_69, const struct FVector& End_69, bool bTestFeaturePoints_69, bool bTestGroundPlane_69, bool bTestPlaneExtents_69, bool bTestPlaneBoundaryPolygon_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARBlueprintLibrary.LineTraceTrackedObjects3D"));

	ARBlueprintLibrary_LineTraceTrackedObjects3D_Params params;
	params.Start_69 = Start_69;
	params.End_69 = End_69;
	params.bTestFeaturePoints_69 = bTestFeaturePoints_69;
	params.bTestGroundPlane_69 = bTestGroundPlane_69;
	params.bTestPlaneExtents_69 = bTestPlaneExtents_69;
	params.bTestPlaneBoundaryPolygon_69 = bTestPlaneBoundaryPolygon_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AugmentedReality.ARBlueprintLibrary.LineTraceTrackedObjects
// (Final, Native, Static, Public, HasDefaults, BlueprintCallable)
// Parameters:
// struct FVector2D               ScreenCoord_69                 (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// bool                           bTestFeaturePoints_69          (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bTestGroundPlane_69            (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bTestPlaneExtents_69           (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bTestPlaneBoundaryPolygon_69   (Parm, ZeroConstructor, IsPlainOldData)
// TArray<struct FARTraceResult>  ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

TArray<struct FARTraceResult> ARBlueprintLibrary::STATIC_LineTraceTrackedObjects(const struct FVector2D& ScreenCoord_69, bool bTestFeaturePoints_69, bool bTestGroundPlane_69, bool bTestPlaneExtents_69, bool bTestPlaneBoundaryPolygon_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARBlueprintLibrary.LineTraceTrackedObjects"));

	ARBlueprintLibrary_LineTraceTrackedObjects_Params params;
	params.ScreenCoord_69 = ScreenCoord_69;
	params.bTestFeaturePoints_69 = bTestFeaturePoints_69;
	params.bTestGroundPlane_69 = bTestGroundPlane_69;
	params.bTestPlaneExtents_69 = bTestPlaneExtents_69;
	params.bTestPlaneBoundaryPolygon_69 = bTestPlaneBoundaryPolygon_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AugmentedReality.ARBlueprintLibrary.IsSessionTypeSupported
// (Final, Native, Static, Public, BlueprintCallable, BlueprintPure)
// Parameters:
// EARSessionType                 SessionType_69                 (Parm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool ARBlueprintLibrary::STATIC_IsSessionTypeSupported(EARSessionType SessionType_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARBlueprintLibrary.IsSessionTypeSupported"));

	ARBlueprintLibrary_IsSessionTypeSupported_Params params;
	params.SessionType_69 = SessionType_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AugmentedReality.ARBlueprintLibrary.IsSessionTrackingFeatureSupported
// (Final, Native, Static, Public, BlueprintCallable, BlueprintPure)
// Parameters:
// EARSessionType                 SessionType_69                 (Parm, ZeroConstructor, IsPlainOldData)
// EARSessionTrackingFeature      SessionTrackingFeature_69      (Parm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool ARBlueprintLibrary::STATIC_IsSessionTrackingFeatureSupported(EARSessionType SessionType_69, EARSessionTrackingFeature SessionTrackingFeature_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARBlueprintLibrary.IsSessionTrackingFeatureSupported"));

	ARBlueprintLibrary_IsSessionTrackingFeatureSupported_Params params;
	params.SessionType_69 = SessionType_69;
	params.SessionTrackingFeature_69 = SessionTrackingFeature_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AugmentedReality.ARBlueprintLibrary.IsSceneReconstructionSupported
// (Final, Native, Static, Public, BlueprintCallable, BlueprintPure)
// Parameters:
// EARSessionType                 SessionType_69                 (Parm, ZeroConstructor, IsPlainOldData)
// EARSceneReconstruction         SceneReconstructionMethod_69   (Parm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool ARBlueprintLibrary::STATIC_IsSceneReconstructionSupported(EARSessionType SessionType_69, EARSceneReconstruction SceneReconstructionMethod_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARBlueprintLibrary.IsSceneReconstructionSupported"));

	ARBlueprintLibrary_IsSceneReconstructionSupported_Params params;
	params.SessionType_69 = SessionType_69;
	params.SceneReconstructionMethod_69 = SceneReconstructionMethod_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AugmentedReality.ARBlueprintLibrary.IsARSupported
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool ARBlueprintLibrary::STATIC_IsARSupported()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARBlueprintLibrary.IsARSupported"));

	ARBlueprintLibrary_IsARSupported_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AugmentedReality.ARBlueprintLibrary.IsARPinLocalStoreSupported
// (Final, Native, Static, Public, BlueprintCallable, BlueprintPure)
// Parameters:
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool ARBlueprintLibrary::STATIC_IsARPinLocalStoreSupported()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARBlueprintLibrary.IsARPinLocalStoreSupported"));

	ARBlueprintLibrary_IsARPinLocalStoreSupported_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AugmentedReality.ARBlueprintLibrary.IsARPinLocalStoreReady
// (Final, Native, Static, Public, BlueprintCallable, BlueprintPure)
// Parameters:
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool ARBlueprintLibrary::STATIC_IsARPinLocalStoreReady()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARBlueprintLibrary.IsARPinLocalStoreReady"));

	ARBlueprintLibrary_IsARPinLocalStoreReady_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AugmentedReality.ARBlueprintLibrary.GetWorldMappingStatus
// (Final, Native, Static, Public, BlueprintCallable, BlueprintPure)
// Parameters:
// EARWorldMappingState           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

EARWorldMappingState ARBlueprintLibrary::STATIC_GetWorldMappingStatus()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARBlueprintLibrary.GetWorldMappingStatus"));

	ARBlueprintLibrary_GetWorldMappingStatus_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AugmentedReality.ARBlueprintLibrary.GetTrackingQualityReason
// (Final, Native, Static, Public, BlueprintCallable, BlueprintPure)
// Parameters:
// EARTrackingQualityReason       ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

EARTrackingQualityReason ARBlueprintLibrary::STATIC_GetTrackingQualityReason()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARBlueprintLibrary.GetTrackingQualityReason"));

	ARBlueprintLibrary_GetTrackingQualityReason_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AugmentedReality.ARBlueprintLibrary.GetTrackingQuality
// (Final, Native, Static, Public, BlueprintCallable, BlueprintPure)
// Parameters:
// EARTrackingQuality             ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

EARTrackingQuality ARBlueprintLibrary::STATIC_GetTrackingQuality()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARBlueprintLibrary.GetTrackingQuality"));

	ARBlueprintLibrary_GetTrackingQuality_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AugmentedReality.ARBlueprintLibrary.GetSupportedVideoFormats
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// EARSessionType                 SessionType_69                 (Parm, ZeroConstructor, IsPlainOldData)
// TArray<struct FARVideoFormat>  ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

TArray<struct FARVideoFormat> ARBlueprintLibrary::STATIC_GetSupportedVideoFormats(EARSessionType SessionType_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARBlueprintLibrary.GetSupportedVideoFormats"));

	ARBlueprintLibrary_GetSupportedVideoFormats_Params params;
	params.SessionType_69 = SessionType_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AugmentedReality.ARBlueprintLibrary.GetSessionConfig
// (Final, Native, Static, Public, BlueprintCallable, BlueprintPure)
// Parameters:
// class ARSessionConfig*         ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

class ARSessionConfig* ARBlueprintLibrary::STATIC_GetSessionConfig()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARBlueprintLibrary.GetSessionConfig"));

	ARBlueprintLibrary_GetSessionConfig_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AugmentedReality.ARBlueprintLibrary.GetPointCloud
// (Final, Native, Static, Public, BlueprintCallable, BlueprintPure)
// Parameters:
// TArray<struct FVector>         ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

TArray<struct FVector> ARBlueprintLibrary::STATIC_GetPointCloud()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARBlueprintLibrary.GetPointCloud"));

	ARBlueprintLibrary_GetPointCloud_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AugmentedReality.ARBlueprintLibrary.GetPersonSegmentationImage
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// class ARTexture*               ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

class ARTexture* ARBlueprintLibrary::STATIC_GetPersonSegmentationImage()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARBlueprintLibrary.GetPersonSegmentationImage"));

	ARBlueprintLibrary_GetPersonSegmentationImage_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AugmentedReality.ARBlueprintLibrary.GetPersonSegmentationDepthImage
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// class ARTexture*               ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

class ARTexture* ARBlueprintLibrary::STATIC_GetPersonSegmentationDepthImage()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARBlueprintLibrary.GetPersonSegmentationDepthImage"));

	ARBlueprintLibrary_GetPersonSegmentationDepthImage_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AugmentedReality.ARBlueprintLibrary.GetObjectClassificationAtLocation
// (Final, Native, Static, Public, HasOutParms, HasDefaults, BlueprintCallable)
// Parameters:
// struct FVector                 InWorldLocation_69             (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
// EARObjectClassification        OutClassification_69           (Parm, OutParm, ZeroConstructor, IsPlainOldData)
// struct FVector                 OutClassificationLocation_69   (Parm, OutParm, ZeroConstructor, IsPlainOldData)
// float                          MaxLocationDiff_69             (Parm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool ARBlueprintLibrary::STATIC_GetObjectClassificationAtLocation(const struct FVector& InWorldLocation_69, float MaxLocationDiff_69, EARObjectClassification* OutClassification_69, struct FVector* OutClassificationLocation_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARBlueprintLibrary.GetObjectClassificationAtLocation"));

	ARBlueprintLibrary_GetObjectClassificationAtLocation_Params params;
	params.InWorldLocation_69 = InWorldLocation_69;
	params.MaxLocationDiff_69 = MaxLocationDiff_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (OutClassification_69 != nullptr)
		*OutClassification_69 = params.OutClassification_69;
	if (OutClassificationLocation_69 != nullptr)
		*OutClassificationLocation_69 = params.OutClassificationLocation_69;

	return params.ReturnValue_69;
}


// Function AugmentedReality.ARBlueprintLibrary.GetNumberOfTrackedFacesSupported
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// int                            ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int ARBlueprintLibrary::STATIC_GetNumberOfTrackedFacesSupported()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARBlueprintLibrary.GetNumberOfTrackedFacesSupported"));

	ARBlueprintLibrary_GetNumberOfTrackedFacesSupported_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AugmentedReality.ARBlueprintLibrary.GetCurrentLightEstimate
// (Final, Native, Static, Public, BlueprintCallable, BlueprintPure)
// Parameters:
// class ARLightEstimate*         ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

class ARLightEstimate* ARBlueprintLibrary::STATIC_GetCurrentLightEstimate()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARBlueprintLibrary.GetCurrentLightEstimate"));

	ARBlueprintLibrary_GetCurrentLightEstimate_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AugmentedReality.ARBlueprintLibrary.GetCameraIntrinsics
// (Final, Native, Static, Public, HasOutParms, BlueprintCallable)
// Parameters:
// struct FARCameraIntrinsics     OutCameraIntrinsics_69         (Parm, OutParm)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool ARBlueprintLibrary::STATIC_GetCameraIntrinsics(struct FARCameraIntrinsics* OutCameraIntrinsics_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARBlueprintLibrary.GetCameraIntrinsics"));

	ARBlueprintLibrary_GetCameraIntrinsics_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (OutCameraIntrinsics_69 != nullptr)
		*OutCameraIntrinsics_69 = params.OutCameraIntrinsics_69;

	return params.ReturnValue_69;
}


// Function AugmentedReality.ARBlueprintLibrary.GetCameraImage
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// class ARTextureCameraImage*    ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

class ARTextureCameraImage* ARBlueprintLibrary::STATIC_GetCameraImage()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARBlueprintLibrary.GetCameraImage"));

	ARBlueprintLibrary_GetCameraImage_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AugmentedReality.ARBlueprintLibrary.GetCameraDepth
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// class ARTextureCameraDepth*    ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

class ARTextureCameraDepth* ARBlueprintLibrary::STATIC_GetCameraDepth()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARBlueprintLibrary.GetCameraDepth"));

	ARBlueprintLibrary_GetCameraDepth_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AugmentedReality.ARBlueprintLibrary.GetARWorldScale
// (Final, Native, Static, Public, BlueprintCallable, BlueprintPure)
// Parameters:
// float                          ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

float ARBlueprintLibrary::STATIC_GetARWorldScale()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARBlueprintLibrary.GetARWorldScale"));

	ARBlueprintLibrary_GetARWorldScale_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AugmentedReality.ARBlueprintLibrary.GetARTexture
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// EARTextureType                 TextureType_69                 (Parm, ZeroConstructor, IsPlainOldData)
// class ARTexture*               ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

class ARTexture* ARBlueprintLibrary::STATIC_GetARTexture(EARTextureType TextureType_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARBlueprintLibrary.GetARTexture"));

	ARBlueprintLibrary_GetARTexture_Params params;
	params.TextureType_69 = TextureType_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AugmentedReality.ARBlueprintLibrary.GetARSessionStatus
// (Final, Native, Static, Public, BlueprintCallable, BlueprintPure)
// Parameters:
// struct FARSessionStatus        ReturnValue_69                 (Parm, OutParm, ReturnParm)

struct FARSessionStatus ARBlueprintLibrary::STATIC_GetARSessionStatus()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARBlueprintLibrary.GetARSessionStatus"));

	ARBlueprintLibrary_GetARSessionStatus_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AugmentedReality.ARBlueprintLibrary.GetAllTrackedPoses
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// TArray<class ARTrackedPose*>   ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

TArray<class ARTrackedPose*> ARBlueprintLibrary::STATIC_GetAllTrackedPoses()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARBlueprintLibrary.GetAllTrackedPoses"));

	ARBlueprintLibrary_GetAllTrackedPoses_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AugmentedReality.ARBlueprintLibrary.GetAllTrackedPoints
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// TArray<class ARTrackedPoint*>  ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

TArray<class ARTrackedPoint*> ARBlueprintLibrary::STATIC_GetAllTrackedPoints()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARBlueprintLibrary.GetAllTrackedPoints"));

	ARBlueprintLibrary_GetAllTrackedPoints_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AugmentedReality.ARBlueprintLibrary.GetAllTrackedPlanes
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// TArray<class ARPlaneGeometry*> ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

TArray<class ARPlaneGeometry*> ARBlueprintLibrary::STATIC_GetAllTrackedPlanes()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARBlueprintLibrary.GetAllTrackedPlanes"));

	ARBlueprintLibrary_GetAllTrackedPlanes_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AugmentedReality.ARBlueprintLibrary.GetAllTrackedImages
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// TArray<class ARTrackedImage*>  ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

TArray<class ARTrackedImage*> ARBlueprintLibrary::STATIC_GetAllTrackedImages()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARBlueprintLibrary.GetAllTrackedImages"));

	ARBlueprintLibrary_GetAllTrackedImages_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AugmentedReality.ARBlueprintLibrary.GetAllTrackedEnvironmentCaptureProbes
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// TArray<class AREnvironmentCaptureProbe*> ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

TArray<class AREnvironmentCaptureProbe*> ARBlueprintLibrary::STATIC_GetAllTrackedEnvironmentCaptureProbes()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARBlueprintLibrary.GetAllTrackedEnvironmentCaptureProbes"));

	ARBlueprintLibrary_GetAllTrackedEnvironmentCaptureProbes_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AugmentedReality.ARBlueprintLibrary.GetAllTracked2DPoses
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// TArray<struct FARPose2D>       ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

TArray<struct FARPose2D> ARBlueprintLibrary::STATIC_GetAllTracked2DPoses()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARBlueprintLibrary.GetAllTracked2DPoses"));

	ARBlueprintLibrary_GetAllTracked2DPoses_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AugmentedReality.ARBlueprintLibrary.GetAllPins
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// TArray<class ARPin*>           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

TArray<class ARPin*> ARBlueprintLibrary::STATIC_GetAllPins()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARBlueprintLibrary.GetAllPins"));

	ARBlueprintLibrary_GetAllPins_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AugmentedReality.ARBlueprintLibrary.GetAllGeometriesByClass
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// class ARTrackedGeometry*       GeometryClass_69               (Parm, ZeroConstructor)
// TArray<class ARTrackedGeometry*> ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

TArray<class ARTrackedGeometry*> ARBlueprintLibrary::STATIC_GetAllGeometriesByClass(class ARTrackedGeometry* GeometryClass_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARBlueprintLibrary.GetAllGeometriesByClass"));

	ARBlueprintLibrary_GetAllGeometriesByClass_Params params;
	params.GeometryClass_69 = GeometryClass_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AugmentedReality.ARBlueprintLibrary.GetAllGeometries
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// TArray<class ARTrackedGeometry*> ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

TArray<class ARTrackedGeometry*> ARBlueprintLibrary::STATIC_GetAllGeometries()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARBlueprintLibrary.GetAllGeometries"));

	ARBlueprintLibrary_GetAllGeometries_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AugmentedReality.ARBlueprintLibrary.GetAlignmentTransform
// (Final, Native, Static, Public, HasDefaults, BlueprintCallable, BlueprintPure)
// Parameters:
// struct FCoreUObject_FTransform ReturnValue_69                 (Parm, OutParm, ReturnParm, IsPlainOldData)

struct FCoreUObject_FTransform ARBlueprintLibrary::STATIC_GetAlignmentTransform()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARBlueprintLibrary.GetAlignmentTransform"));

	ARBlueprintLibrary_GetAlignmentTransform_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AugmentedReality.ARBlueprintLibrary.FindTrackedPointsByName
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// struct FString                 PointName_69                   (Parm, ZeroConstructor)
// TArray<class ARTrackedPoint*>  ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

TArray<class ARTrackedPoint*> ARBlueprintLibrary::STATIC_FindTrackedPointsByName(const struct FString& PointName_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARBlueprintLibrary.FindTrackedPointsByName"));

	ARBlueprintLibrary_FindTrackedPointsByName_Params params;
	params.PointName_69 = PointName_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AugmentedReality.ARBlueprintLibrary.DebugDrawTrackedGeometry
// (Final, Native, Static, Public, HasDefaults, BlueprintCallable)
// Parameters:
// class ARTrackedGeometry*       TrackedGeometry_69             (Parm, ZeroConstructor)
// class Object_32759*            WorldContextObject_69          (Parm, ZeroConstructor)
// struct FLinearColor            Color_69                       (Parm, ZeroConstructor, IsPlainOldData)
// float                          OutlineThickness_69            (Parm, ZeroConstructor, IsPlainOldData)
// float                          PersistForSeconds_69           (Parm, ZeroConstructor, IsPlainOldData)

void ARBlueprintLibrary::STATIC_DebugDrawTrackedGeometry(class ARTrackedGeometry* TrackedGeometry_69, class Object_32759* WorldContextObject_69, const struct FLinearColor& Color_69, float OutlineThickness_69, float PersistForSeconds_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARBlueprintLibrary.DebugDrawTrackedGeometry"));

	ARBlueprintLibrary_DebugDrawTrackedGeometry_Params params;
	params.TrackedGeometry_69 = TrackedGeometry_69;
	params.WorldContextObject_69 = WorldContextObject_69;
	params.Color_69 = Color_69;
	params.OutlineThickness_69 = OutlineThickness_69;
	params.PersistForSeconds_69 = PersistForSeconds_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AugmentedReality.ARBlueprintLibrary.DebugDrawPin
// (Final, Native, Static, Public, HasDefaults, BlueprintCallable)
// Parameters:
// class ARPin*                   ARPin_69                       (Parm, ZeroConstructor)
// class Object_32759*            WorldContextObject_69          (Parm, ZeroConstructor)
// struct FLinearColor            Color_69                       (Parm, ZeroConstructor, IsPlainOldData)
// float                          Scale_69                       (Parm, ZeroConstructor, IsPlainOldData)
// float                          PersistForSeconds_69           (Parm, ZeroConstructor, IsPlainOldData)

void ARBlueprintLibrary::STATIC_DebugDrawPin(class ARPin* ARPin_69, class Object_32759* WorldContextObject_69, const struct FLinearColor& Color_69, float Scale_69, float PersistForSeconds_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARBlueprintLibrary.DebugDrawPin"));

	ARBlueprintLibrary_DebugDrawPin_Params params;
	params.ARPin_69 = ARPin_69;
	params.WorldContextObject_69 = WorldContextObject_69;
	params.Color_69 = Color_69;
	params.Scale_69 = Scale_69;
	params.PersistForSeconds_69 = PersistForSeconds_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AugmentedReality.ARBlueprintLibrary.CalculateClosestIntersection
// (Final, Native, Static, Public, HasOutParms, HasDefaults, BlueprintCallable)
// Parameters:
// TArray<struct FVector>         StartPoints_69                 (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
// TArray<struct FVector>         EndPoints_69                   (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
// struct FVector                 ClosestIntersection_69         (Parm, OutParm, ZeroConstructor, IsPlainOldData)

void ARBlueprintLibrary::STATIC_CalculateClosestIntersection(TArray<struct FVector> StartPoints_69, TArray<struct FVector> EndPoints_69, struct FVector* ClosestIntersection_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARBlueprintLibrary.CalculateClosestIntersection"));

	ARBlueprintLibrary_CalculateClosestIntersection_Params params;
	params.StartPoints_69 = StartPoints_69;
	params.EndPoints_69 = EndPoints_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (ClosestIntersection_69 != nullptr)
		*ClosestIntersection_69 = params.ClosestIntersection_69;
}


// Function AugmentedReality.ARBlueprintLibrary.CalculateAlignmentTransform
// (Final, Native, Static, Public, HasOutParms, HasDefaults, BlueprintCallable)
// Parameters:
// struct FCoreUObject_FTransform TransformInFirstCoordinateSystem_69 (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
// struct FCoreUObject_FTransform TransformInSecondCoordinateSystem_69 (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
// struct FCoreUObject_FTransform AlignmentTransform_69          (Parm, OutParm, IsPlainOldData)

void ARBlueprintLibrary::STATIC_CalculateAlignmentTransform(const struct FCoreUObject_FTransform& TransformInFirstCoordinateSystem_69, const struct FCoreUObject_FTransform& TransformInSecondCoordinateSystem_69, struct FCoreUObject_FTransform* AlignmentTransform_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARBlueprintLibrary.CalculateAlignmentTransform"));

	ARBlueprintLibrary_CalculateAlignmentTransform_Params params;
	params.TransformInFirstCoordinateSystem_69 = TransformInFirstCoordinateSystem_69;
	params.TransformInSecondCoordinateSystem_69 = TransformInSecondCoordinateSystem_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (AlignmentTransform_69 != nullptr)
		*AlignmentTransform_69 = params.AlignmentTransform_69;
}


// Function AugmentedReality.ARBlueprintLibrary.AddTrackedPointWithName
// (Final, Native, Static, Public, HasOutParms, HasDefaults, BlueprintCallable)
// Parameters:
// struct FCoreUObject_FTransform WorldTransform_69              (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
// struct FString                 PointName_69                   (Parm, ZeroConstructor)
// bool                           bDeletePointsWithSameName_69   (Parm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool ARBlueprintLibrary::STATIC_AddTrackedPointWithName(const struct FCoreUObject_FTransform& WorldTransform_69, const struct FString& PointName_69, bool bDeletePointsWithSameName_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARBlueprintLibrary.AddTrackedPointWithName"));

	ARBlueprintLibrary_AddTrackedPointWithName_Params params;
	params.WorldTransform_69 = WorldTransform_69;
	params.PointName_69 = PointName_69;
	params.bDeletePointsWithSameName_69 = bDeletePointsWithSameName_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AugmentedReality.ARBlueprintLibrary.AddRuntimeCandidateImage
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// class ARSessionConfig*         SessionConfig_69               (Parm, ZeroConstructor)
// class Texture2D*               CandidateTexture_69            (Parm, ZeroConstructor)
// struct FString                 FriendlyName_69                (Parm, ZeroConstructor)
// float                          PhysicalWidth_69               (Parm, ZeroConstructor, IsPlainOldData)
// class ARCandidateImage*        ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

class ARCandidateImage* ARBlueprintLibrary::STATIC_AddRuntimeCandidateImage(class ARSessionConfig* SessionConfig_69, class Texture2D* CandidateTexture_69, const struct FString& FriendlyName_69, float PhysicalWidth_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARBlueprintLibrary.AddRuntimeCandidateImage"));

	ARBlueprintLibrary_AddRuntimeCandidateImage_Params params;
	params.SessionConfig_69 = SessionConfig_69;
	params.CandidateTexture_69 = CandidateTexture_69;
	params.FriendlyName_69 = FriendlyName_69;
	params.PhysicalWidth_69 = PhysicalWidth_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AugmentedReality.ARBlueprintLibrary.AddManualEnvironmentCaptureProbe
// (Final, Native, Static, Public, HasDefaults, BlueprintCallable)
// Parameters:
// struct FVector                 Location_69                    (Parm, ZeroConstructor, IsPlainOldData)
// struct FVector                 Extent_69                      (Parm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool ARBlueprintLibrary::STATIC_AddManualEnvironmentCaptureProbe(const struct FVector& Location_69, const struct FVector& Extent_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARBlueprintLibrary.AddManualEnvironmentCaptureProbe"));

	ARBlueprintLibrary_AddManualEnvironmentCaptureProbe_Params params;
	params.Location_69 = Location_69;
	params.Extent_69 = Extent_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AugmentedReality.ARTraceResultLibrary_32759.GetTrackedGeometry
// (Final, Native, Static, Public, HasOutParms, BlueprintCallable, BlueprintPure)
// Parameters:
// struct FARTraceResult          TraceResult_69                 (ConstParm, Parm, OutParm, ReferenceParm)
// class ARTrackedGeometry*       ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

class ARTrackedGeometry* ARTraceResultLibrary_32759::STATIC_GetTrackedGeometry(const struct FARTraceResult& TraceResult_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARTraceResultLibrary_32759.GetTrackedGeometry"));

	ARTraceResultLibrary_32759_GetTrackedGeometry_Params params;
	params.TraceResult_69 = TraceResult_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AugmentedReality.ARTraceResultLibrary_32759.GetTraceChannel
// (Final, Native, Static, Public, HasOutParms, BlueprintCallable, BlueprintPure)
// Parameters:
// struct FARTraceResult          TraceResult_69                 (ConstParm, Parm, OutParm, ReferenceParm)
// EARLineTraceChannels           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

EARLineTraceChannels ARTraceResultLibrary_32759::STATIC_GetTraceChannel(const struct FARTraceResult& TraceResult_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARTraceResultLibrary_32759.GetTraceChannel"));

	ARTraceResultLibrary_32759_GetTraceChannel_Params params;
	params.TraceResult_69 = TraceResult_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AugmentedReality.ARTraceResultLibrary_32759.GetLocalTransform
// (Final, Native, Static, Public, HasOutParms, HasDefaults, BlueprintCallable, BlueprintPure)
// Parameters:
// struct FARTraceResult          TraceResult_69                 (ConstParm, Parm, OutParm, ReferenceParm)
// struct FCoreUObject_FTransform ReturnValue_69                 (Parm, OutParm, ReturnParm, IsPlainOldData)

struct FCoreUObject_FTransform ARTraceResultLibrary_32759::STATIC_GetLocalTransform(const struct FARTraceResult& TraceResult_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARTraceResultLibrary_32759.GetLocalTransform"));

	ARTraceResultLibrary_32759_GetLocalTransform_Params params;
	params.TraceResult_69 = TraceResult_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AugmentedReality.ARTraceResultLibrary_32759.GetLocalToWorldTransform
// (Final, Native, Static, Public, HasOutParms, HasDefaults, BlueprintCallable, BlueprintPure)
// Parameters:
// struct FARTraceResult          TraceResult_69                 (ConstParm, Parm, OutParm, ReferenceParm)
// struct FCoreUObject_FTransform ReturnValue_69                 (Parm, OutParm, ReturnParm, IsPlainOldData)

struct FCoreUObject_FTransform ARTraceResultLibrary_32759::STATIC_GetLocalToWorldTransform(const struct FARTraceResult& TraceResult_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARTraceResultLibrary_32759.GetLocalToWorldTransform"));

	ARTraceResultLibrary_32759_GetLocalToWorldTransform_Params params;
	params.TraceResult_69 = TraceResult_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AugmentedReality.ARTraceResultLibrary_32759.GetLocalToTrackingTransform
// (Final, Native, Static, Public, HasOutParms, HasDefaults, BlueprintCallable, BlueprintPure)
// Parameters:
// struct FARTraceResult          TraceResult_69                 (ConstParm, Parm, OutParm, ReferenceParm)
// struct FCoreUObject_FTransform ReturnValue_69                 (Parm, OutParm, ReturnParm, IsPlainOldData)

struct FCoreUObject_FTransform ARTraceResultLibrary_32759::STATIC_GetLocalToTrackingTransform(const struct FARTraceResult& TraceResult_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARTraceResultLibrary_32759.GetLocalToTrackingTransform"));

	ARTraceResultLibrary_32759_GetLocalToTrackingTransform_Params params;
	params.TraceResult_69 = TraceResult_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AugmentedReality.ARTraceResultLibrary_32759.GetDistanceFromCamera
// (Final, Native, Static, Public, HasOutParms, BlueprintCallable, BlueprintPure)
// Parameters:
// struct FARTraceResult          TraceResult_69                 (ConstParm, Parm, OutParm, ReferenceParm)
// float                          ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

float ARTraceResultLibrary_32759::STATIC_GetDistanceFromCamera(const struct FARTraceResult& TraceResult_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARTraceResultLibrary_32759.GetDistanceFromCamera"));

	ARTraceResultLibrary_32759_GetDistanceFromCamera_Params params;
	params.TraceResult_69 = TraceResult_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AugmentedReality.ARSaveWorldAsyncTaskBlueprintProxy.ARSaveWorld
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// class Object_32759*            WorldContextObject_69          (Parm, ZeroConstructor)
// class ARSaveWorldAsyncTaskBlueprintProxy* ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

class ARSaveWorldAsyncTaskBlueprintProxy* ARSaveWorldAsyncTaskBlueprintProxy::STATIC_ARSaveWorld(class Object_32759* WorldContextObject_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARSaveWorldAsyncTaskBlueprintProxy.ARSaveWorld"));

	ARSaveWorldAsyncTaskBlueprintProxy_ARSaveWorld_Params params;
	params.WorldContextObject_69 = WorldContextObject_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AugmentedReality.ARGetCandidateObjectAsyncTaskBlueprintProxy.ARGetCandidateObject
// (Final, Native, Static, Public, HasDefaults, BlueprintCallable)
// Parameters:
// class Object_32759*            WorldContextObject_69          (Parm, ZeroConstructor)
// struct FVector                 Location_69                    (Parm, ZeroConstructor, IsPlainOldData)
// struct FVector                 Extent_69                      (Parm, ZeroConstructor, IsPlainOldData)
// class ARGetCandidateObjectAsyncTaskBlueprintProxy* ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

class ARGetCandidateObjectAsyncTaskBlueprintProxy* ARGetCandidateObjectAsyncTaskBlueprintProxy::STATIC_ARGetCandidateObject(class Object_32759* WorldContextObject_69, const struct FVector& Location_69, const struct FVector& Extent_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARGetCandidateObjectAsyncTaskBlueprintProxy.ARGetCandidateObject"));

	ARGetCandidateObjectAsyncTaskBlueprintProxy_ARGetCandidateObject_Params params;
	params.WorldContextObject_69 = WorldContextObject_69;
	params.Location_69 = Location_69;
	params.Extent_69 = Extent_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AugmentedReality.ARComponent.UpdateVisualization
// (Native, Event, Public, BlueprintCallable, BlueprintEvent)

void ARComponent::UpdateVisualization()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARComponent.UpdateVisualization"));

	ARComponent_UpdateVisualization_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AugmentedReality.ARComponent.SetNativeID
// (Final, Native, Public, HasDefaults, BlueprintCallable)
// Parameters:
// struct FGuid                   NativeID_69                    (Parm, ZeroConstructor, IsPlainOldData)

void ARComponent::SetNativeID(const struct FGuid& NativeID_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARComponent.SetNativeID"));

	ARComponent_SetNativeID_Params params;
	params.NativeID_69 = NativeID_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AugmentedReality.ARComponent.ReceiveRemove
// (Event, Public, BlueprintEvent)

void ARComponent::ReceiveRemove()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARComponent.ReceiveRemove"));

	ARComponent_ReceiveRemove_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AugmentedReality.ARComponent.OnRep_Payload
// (Native, Protected)

void ARComponent::OnRep_Payload()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARComponent.OnRep_Payload"));

	ARComponent_OnRep_Payload_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AugmentedReality.ARComponent.GetMRMesh
// (Final, Native, Public, BlueprintCallable, BlueprintPure)
// Parameters:
// class MRMeshComponent*         ReturnValue_69                 (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)

class MRMeshComponent* ARComponent::GetMRMesh()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARComponent.GetMRMesh"));

	ARComponent_GetMRMesh_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AugmentedReality.ARPlaneComponent.SetPlaneComponentDebugMode
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// EPlaneComponentDebugMode       NewDebugMode_69                (Parm, ZeroConstructor, IsPlainOldData)

void ARPlaneComponent::STATIC_SetPlaneComponentDebugMode(EPlaneComponentDebugMode NewDebugMode_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARPlaneComponent.SetPlaneComponentDebugMode"));

	ARPlaneComponent_SetPlaneComponentDebugMode_Params params;
	params.NewDebugMode_69 = NewDebugMode_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AugmentedReality.ARPlaneComponent.SetObjectClassificationDebugColors
// (Final, Native, Static, Public, HasOutParms, BlueprintCallable)
// Parameters:
// TMap<EARObjectClassification, struct FLinearColor> InColors_69                    (ConstParm, Parm, OutParm, ReferenceParm)

void ARPlaneComponent::STATIC_SetObjectClassificationDebugColors(TMap<EARObjectClassification, struct FLinearColor> InColors_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARPlaneComponent.SetObjectClassificationDebugColors"));

	ARPlaneComponent_SetObjectClassificationDebugColors_Params params;
	params.InColors_69 = InColors_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AugmentedReality.ARPlaneComponent.ServerUpdatePayload
// (Net, NetReliable, Native, Event, Protected, NetServer, NetValidate)
// Parameters:
// struct FARPlaneUpdatePayload   NewPayload_69                  (ConstParm, Parm, ReferenceParm)

void ARPlaneComponent::ServerUpdatePayload(const struct FARPlaneUpdatePayload& NewPayload_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARPlaneComponent.ServerUpdatePayload"));

	ARPlaneComponent_ServerUpdatePayload_Params params;
	params.NewPayload_69 = NewPayload_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AugmentedReality.ARPlaneComponent.ReceiveUpdate
// (Event, Public, HasOutParms, BlueprintEvent)
// Parameters:
// struct FARPlaneUpdatePayload   Payload_69                     (ConstParm, Parm, OutParm, ReferenceParm)

void ARPlaneComponent::ReceiveUpdate(const struct FARPlaneUpdatePayload& Payload_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARPlaneComponent.ReceiveUpdate"));

	ARPlaneComponent_ReceiveUpdate_Params params;
	params.Payload_69 = Payload_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AugmentedReality.ARPlaneComponent.ReceiveAdd
// (Event, Public, HasOutParms, BlueprintEvent)
// Parameters:
// struct FARPlaneUpdatePayload   Payload_69                     (ConstParm, Parm, OutParm, ReferenceParm)

void ARPlaneComponent::ReceiveAdd(const struct FARPlaneUpdatePayload& Payload_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARPlaneComponent.ReceiveAdd"));

	ARPlaneComponent_ReceiveAdd_Params params;
	params.Payload_69 = Payload_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AugmentedReality.ARPlaneComponent.GetObjectClassificationDebugColors
// (Final, Native, Static, Public, BlueprintCallable, BlueprintPure)
// Parameters:
// TMap<EARObjectClassification, struct FLinearColor> ReturnValue_69                 (ConstParm, Parm, OutParm, ReturnParm, ReferenceParm)

TMap<EARObjectClassification, struct FLinearColor> ARPlaneComponent::STATIC_GetObjectClassificationDebugColors()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARPlaneComponent.GetObjectClassificationDebugColors"));

	ARPlaneComponent_GetObjectClassificationDebugColors_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AugmentedReality.ARPointComponent.ServerUpdatePayload
// (Net, NetReliable, Native, Event, Protected, NetServer, NetValidate)
// Parameters:
// struct FARPointUpdatePayload   NewPayload_69                  (ConstParm, Parm, ZeroConstructor, ReferenceParm, IsPlainOldData)

void ARPointComponent::ServerUpdatePayload(const struct FARPointUpdatePayload& NewPayload_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARPointComponent.ServerUpdatePayload"));

	ARPointComponent_ServerUpdatePayload_Params params;
	params.NewPayload_69 = NewPayload_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AugmentedReality.ARPointComponent.ReceiveUpdate
// (Event, Public, HasOutParms, BlueprintEvent)
// Parameters:
// struct FARPointUpdatePayload   Payload_69                     (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)

void ARPointComponent::ReceiveUpdate(const struct FARPointUpdatePayload& Payload_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARPointComponent.ReceiveUpdate"));

	ARPointComponent_ReceiveUpdate_Params params;
	params.Payload_69 = Payload_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AugmentedReality.ARPointComponent.ReceiveAdd
// (Event, Public, HasOutParms, BlueprintEvent)
// Parameters:
// struct FARPointUpdatePayload   Payload_69                     (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)

void ARPointComponent::ReceiveAdd(const struct FARPointUpdatePayload& Payload_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARPointComponent.ReceiveAdd"));

	ARPointComponent_ReceiveAdd_Params params;
	params.Payload_69 = Payload_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AugmentedReality.ARFaceComponent.SetFaceComponentDebugMode
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// EFaceComponentDebugMode        NewDebugMode_69                (Parm, ZeroConstructor, IsPlainOldData)

void ARFaceComponent::STATIC_SetFaceComponentDebugMode(EFaceComponentDebugMode NewDebugMode_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARFaceComponent.SetFaceComponentDebugMode"));

	ARFaceComponent_SetFaceComponentDebugMode_Params params;
	params.NewDebugMode_69 = NewDebugMode_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AugmentedReality.ARFaceComponent.ServerUpdatePayload
// (Net, NetReliable, Native, Event, Protected, NetServer, NetValidate)
// Parameters:
// struct FARFaceUpdatePayload    NewPayload_69                  (ConstParm, Parm, ReferenceParm)

void ARFaceComponent::ServerUpdatePayload(const struct FARFaceUpdatePayload& NewPayload_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARFaceComponent.ServerUpdatePayload"));

	ARFaceComponent_ServerUpdatePayload_Params params;
	params.NewPayload_69 = NewPayload_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AugmentedReality.ARFaceComponent.ReceiveUpdate
// (Event, Public, HasOutParms, BlueprintEvent)
// Parameters:
// struct FARFaceUpdatePayload    Payload_69                     (ConstParm, Parm, OutParm, ReferenceParm)

void ARFaceComponent::ReceiveUpdate(const struct FARFaceUpdatePayload& Payload_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARFaceComponent.ReceiveUpdate"));

	ARFaceComponent_ReceiveUpdate_Params params;
	params.Payload_69 = Payload_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AugmentedReality.ARFaceComponent.ReceiveAdd
// (Event, Public, HasOutParms, BlueprintEvent)
// Parameters:
// struct FARFaceUpdatePayload    Payload_69                     (ConstParm, Parm, OutParm, ReferenceParm)

void ARFaceComponent::ReceiveAdd(const struct FARFaceUpdatePayload& Payload_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARFaceComponent.ReceiveAdd"));

	ARFaceComponent_ReceiveAdd_Params params;
	params.Payload_69 = Payload_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AugmentedReality.ARImageComponent.SetImageComponentDebugMode
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// EImageComponentDebugMode       NewDebugMode_69                (Parm, ZeroConstructor, IsPlainOldData)

void ARImageComponent::STATIC_SetImageComponentDebugMode(EImageComponentDebugMode NewDebugMode_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARImageComponent.SetImageComponentDebugMode"));

	ARImageComponent_SetImageComponentDebugMode_Params params;
	params.NewDebugMode_69 = NewDebugMode_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AugmentedReality.ARImageComponent.ServerUpdatePayload
// (Net, NetReliable, Native, Event, Protected, NetServer, NetValidate)
// Parameters:
// struct FARImageUpdatePayload   NewPayload_69                  (ConstParm, Parm, ReferenceParm)

void ARImageComponent::ServerUpdatePayload(const struct FARImageUpdatePayload& NewPayload_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARImageComponent.ServerUpdatePayload"));

	ARImageComponent_ServerUpdatePayload_Params params;
	params.NewPayload_69 = NewPayload_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AugmentedReality.ARImageComponent.ReceiveUpdate
// (Event, Public, HasOutParms, BlueprintEvent)
// Parameters:
// struct FARImageUpdatePayload   Payload_69                     (ConstParm, Parm, OutParm, ReferenceParm)

void ARImageComponent::ReceiveUpdate(const struct FARImageUpdatePayload& Payload_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARImageComponent.ReceiveUpdate"));

	ARImageComponent_ReceiveUpdate_Params params;
	params.Payload_69 = Payload_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AugmentedReality.ARImageComponent.ReceiveAdd
// (Event, Public, HasOutParms, BlueprintEvent)
// Parameters:
// struct FARImageUpdatePayload   Payload_69                     (ConstParm, Parm, OutParm, ReferenceParm)

void ARImageComponent::ReceiveAdd(const struct FARImageUpdatePayload& Payload_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARImageComponent.ReceiveAdd"));

	ARImageComponent_ReceiveAdd_Params params;
	params.Payload_69 = Payload_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AugmentedReality.ARQRCodeComponent.SetQRCodeComponentDebugMode
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// EQRCodeComponentDebugMode      NewDebugMode_69                (Parm, ZeroConstructor, IsPlainOldData)

void ARQRCodeComponent::STATIC_SetQRCodeComponentDebugMode(EQRCodeComponentDebugMode NewDebugMode_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARQRCodeComponent.SetQRCodeComponentDebugMode"));

	ARQRCodeComponent_SetQRCodeComponentDebugMode_Params params;
	params.NewDebugMode_69 = NewDebugMode_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AugmentedReality.ARQRCodeComponent.ServerUpdatePayload
// (Net, NetReliable, Native, Event, Protected, NetServer, NetValidate)
// Parameters:
// struct FARQRCodeUpdatePayload  NewPayload_69                  (ConstParm, Parm, ReferenceParm)

void ARQRCodeComponent::ServerUpdatePayload(const struct FARQRCodeUpdatePayload& NewPayload_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARQRCodeComponent.ServerUpdatePayload"));

	ARQRCodeComponent_ServerUpdatePayload_Params params;
	params.NewPayload_69 = NewPayload_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AugmentedReality.ARQRCodeComponent.ReceiveUpdate
// (Event, Public, HasOutParms, BlueprintEvent)
// Parameters:
// struct FARQRCodeUpdatePayload  Payload_69                     (ConstParm, Parm, OutParm, ReferenceParm)

void ARQRCodeComponent::ReceiveUpdate(const struct FARQRCodeUpdatePayload& Payload_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARQRCodeComponent.ReceiveUpdate"));

	ARQRCodeComponent_ReceiveUpdate_Params params;
	params.Payload_69 = Payload_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AugmentedReality.ARQRCodeComponent.ReceiveAdd
// (Event, Public, HasOutParms, BlueprintEvent)
// Parameters:
// struct FARQRCodeUpdatePayload  Payload_69                     (ConstParm, Parm, OutParm, ReferenceParm)

void ARQRCodeComponent::ReceiveAdd(const struct FARQRCodeUpdatePayload& Payload_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARQRCodeComponent.ReceiveAdd"));

	ARQRCodeComponent_ReceiveAdd_Params params;
	params.Payload_69 = Payload_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AugmentedReality.ARPoseComponent.SetPoseComponentDebugMode
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// EPoseComponentDebugMode        NewDebugMode_69                (Parm, ZeroConstructor, IsPlainOldData)

void ARPoseComponent::STATIC_SetPoseComponentDebugMode(EPoseComponentDebugMode NewDebugMode_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARPoseComponent.SetPoseComponentDebugMode"));

	ARPoseComponent_SetPoseComponentDebugMode_Params params;
	params.NewDebugMode_69 = NewDebugMode_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AugmentedReality.ARPoseComponent.ServerUpdatePayload
// (Net, NetReliable, Native, Event, Protected, NetServer, NetValidate)
// Parameters:
// struct FARPoseUpdatePayload    NewPayload_69                  (ConstParm, Parm, ReferenceParm)

void ARPoseComponent::ServerUpdatePayload(const struct FARPoseUpdatePayload& NewPayload_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARPoseComponent.ServerUpdatePayload"));

	ARPoseComponent_ServerUpdatePayload_Params params;
	params.NewPayload_69 = NewPayload_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AugmentedReality.ARPoseComponent.ReceiveUpdate
// (Event, Public, HasOutParms, BlueprintEvent)
// Parameters:
// struct FARPoseUpdatePayload    Payload_69                     (ConstParm, Parm, OutParm, ReferenceParm)

void ARPoseComponent::ReceiveUpdate(const struct FARPoseUpdatePayload& Payload_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARPoseComponent.ReceiveUpdate"));

	ARPoseComponent_ReceiveUpdate_Params params;
	params.Payload_69 = Payload_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AugmentedReality.ARPoseComponent.ReceiveAdd
// (Event, Public, HasOutParms, BlueprintEvent)
// Parameters:
// struct FARPoseUpdatePayload    Payload_69                     (ConstParm, Parm, OutParm, ReferenceParm)

void ARPoseComponent::ReceiveAdd(const struct FARPoseUpdatePayload& Payload_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARPoseComponent.ReceiveAdd"));

	ARPoseComponent_ReceiveAdd_Params params;
	params.Payload_69 = Payload_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AugmentedReality.AREnvironmentProbeComponent.ServerUpdatePayload
// (Net, NetReliable, Native, Event, Protected, NetServer, NetValidate)
// Parameters:
// struct FAREnvironmentProbeUpdatePayload NewPayload_69                  (ConstParm, Parm, ReferenceParm)

void AREnvironmentProbeComponent::ServerUpdatePayload(const struct FAREnvironmentProbeUpdatePayload& NewPayload_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.AREnvironmentProbeComponent.ServerUpdatePayload"));

	AREnvironmentProbeComponent_ServerUpdatePayload_Params params;
	params.NewPayload_69 = NewPayload_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AugmentedReality.AREnvironmentProbeComponent.ReceiveUpdate
// (Event, Public, HasOutParms, BlueprintEvent)
// Parameters:
// struct FAREnvironmentProbeUpdatePayload Payload_69                     (ConstParm, Parm, OutParm, ReferenceParm)

void AREnvironmentProbeComponent::ReceiveUpdate(const struct FAREnvironmentProbeUpdatePayload& Payload_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.AREnvironmentProbeComponent.ReceiveUpdate"));

	AREnvironmentProbeComponent_ReceiveUpdate_Params params;
	params.Payload_69 = Payload_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AugmentedReality.AREnvironmentProbeComponent.ReceiveAdd
// (Event, Public, HasOutParms, BlueprintEvent)
// Parameters:
// struct FAREnvironmentProbeUpdatePayload Payload_69                     (ConstParm, Parm, OutParm, ReferenceParm)

void AREnvironmentProbeComponent::ReceiveAdd(const struct FAREnvironmentProbeUpdatePayload& Payload_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.AREnvironmentProbeComponent.ReceiveAdd"));

	AREnvironmentProbeComponent_ReceiveAdd_Params params;
	params.Payload_69 = Payload_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AugmentedReality.ARObjectComponent.ServerUpdatePayload
// (Net, NetReliable, Native, Event, Protected, NetServer, NetValidate)
// Parameters:
// struct FARObjectUpdatePayload  NewPayload_69                  (ConstParm, Parm, ReferenceParm)

void ARObjectComponent::ServerUpdatePayload(const struct FARObjectUpdatePayload& NewPayload_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARObjectComponent.ServerUpdatePayload"));

	ARObjectComponent_ServerUpdatePayload_Params params;
	params.NewPayload_69 = NewPayload_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AugmentedReality.ARObjectComponent.ReceiveUpdate
// (Event, Public, HasOutParms, BlueprintEvent)
// Parameters:
// struct FARObjectUpdatePayload  Payload_69                     (ConstParm, Parm, OutParm, ReferenceParm)

void ARObjectComponent::ReceiveUpdate(const struct FARObjectUpdatePayload& Payload_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARObjectComponent.ReceiveUpdate"));

	ARObjectComponent_ReceiveUpdate_Params params;
	params.Payload_69 = Payload_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AugmentedReality.ARObjectComponent.ReceiveAdd
// (Event, Public, HasOutParms, BlueprintEvent)
// Parameters:
// struct FARObjectUpdatePayload  Payload_69                     (ConstParm, Parm, OutParm, ReferenceParm)

void ARObjectComponent::ReceiveAdd(const struct FARObjectUpdatePayload& Payload_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARObjectComponent.ReceiveAdd"));

	ARObjectComponent_ReceiveAdd_Params params;
	params.Payload_69 = Payload_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AugmentedReality.ARMeshComponent.ServerUpdatePayload
// (Net, NetReliable, Native, Event, Protected, NetServer, NetValidate)
// Parameters:
// struct FARMeshUpdatePayload    NewPayload_69                  (ConstParm, Parm, ReferenceParm)

void ARMeshComponent::ServerUpdatePayload(const struct FARMeshUpdatePayload& NewPayload_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARMeshComponent.ServerUpdatePayload"));

	ARMeshComponent_ServerUpdatePayload_Params params;
	params.NewPayload_69 = NewPayload_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AugmentedReality.ARMeshComponent.ReceiveUpdate
// (Event, Public, HasOutParms, BlueprintEvent)
// Parameters:
// struct FARMeshUpdatePayload    Payload_69                     (ConstParm, Parm, OutParm, ReferenceParm)

void ARMeshComponent::ReceiveUpdate(const struct FARMeshUpdatePayload& Payload_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARMeshComponent.ReceiveUpdate"));

	ARMeshComponent_ReceiveUpdate_Params params;
	params.Payload_69 = Payload_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AugmentedReality.ARMeshComponent.ReceiveAdd
// (Event, Public, HasOutParms, BlueprintEvent)
// Parameters:
// struct FARMeshUpdatePayload    Payload_69                     (ConstParm, Parm, OutParm, ReferenceParm)

void ARMeshComponent::ReceiveAdd(const struct FARMeshUpdatePayload& Payload_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARMeshComponent.ReceiveAdd"));

	ARMeshComponent_ReceiveAdd_Params params;
	params.Payload_69 = Payload_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AugmentedReality.ARGeoAnchorComponent.SetGeoAnchorComponentDebugMode
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// EGeoAnchorComponentDebugMode   NewDebugMode_69                (Parm, ZeroConstructor, IsPlainOldData)

void ARGeoAnchorComponent::STATIC_SetGeoAnchorComponentDebugMode(EGeoAnchorComponentDebugMode NewDebugMode_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARGeoAnchorComponent.SetGeoAnchorComponentDebugMode"));

	ARGeoAnchorComponent_SetGeoAnchorComponentDebugMode_Params params;
	params.NewDebugMode_69 = NewDebugMode_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AugmentedReality.ARGeoAnchorComponent.ServerUpdatePayload
// (Net, NetReliable, Native, Event, Protected, NetServer, NetValidate)
// Parameters:
// struct FARGeoAnchorUpdatePayload NewPayload_69                  (ConstParm, Parm, ReferenceParm)

void ARGeoAnchorComponent::ServerUpdatePayload(const struct FARGeoAnchorUpdatePayload& NewPayload_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARGeoAnchorComponent.ServerUpdatePayload"));

	ARGeoAnchorComponent_ServerUpdatePayload_Params params;
	params.NewPayload_69 = NewPayload_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AugmentedReality.ARGeoAnchorComponent.ReceiveUpdate
// (Event, Public, HasOutParms, BlueprintEvent)
// Parameters:
// struct FARGeoAnchorUpdatePayload Payload_69                     (ConstParm, Parm, OutParm, ReferenceParm)

void ARGeoAnchorComponent::ReceiveUpdate(const struct FARGeoAnchorUpdatePayload& Payload_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARGeoAnchorComponent.ReceiveUpdate"));

	ARGeoAnchorComponent_ReceiveUpdate_Params params;
	params.Payload_69 = Payload_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AugmentedReality.ARGeoAnchorComponent.ReceiveAdd
// (Event, Public, HasOutParms, BlueprintEvent)
// Parameters:
// struct FARGeoAnchorUpdatePayload Payload_69                     (ConstParm, Parm, OutParm, ReferenceParm)

void ARGeoAnchorComponent::ReceiveAdd(const struct FARGeoAnchorUpdatePayload& Payload_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARGeoAnchorComponent.ReceiveAdd"));

	ARGeoAnchorComponent_ReceiveAdd_Params params;
	params.Payload_69 = Payload_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AugmentedReality.ARDependencyHandler.StartARSessionLatent
// (Native, Public, BlueprintCallable)
// Parameters:
// class Object_32759*            WorldContextObject_69          (Parm, ZeroConstructor)
// class ARSessionConfig*         SessionConfig_69               (Parm, ZeroConstructor)
// struct FLatentActionInfo       LatentInfo_69                  (Parm)

void ARDependencyHandler::StartARSessionLatent(class Object_32759* WorldContextObject_69, class ARSessionConfig* SessionConfig_69, const struct FLatentActionInfo& LatentInfo_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARDependencyHandler.StartARSessionLatent"));

	ARDependencyHandler_StartARSessionLatent_Params params;
	params.WorldContextObject_69 = WorldContextObject_69;
	params.SessionConfig_69 = SessionConfig_69;
	params.LatentInfo_69 = LatentInfo_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AugmentedReality.ARDependencyHandler.RequestARSessionPermission
// (Native, Public, HasOutParms, BlueprintCallable)
// Parameters:
// class Object_32759*            WorldContextObject_69          (Parm, ZeroConstructor)
// class ARSessionConfig*         SessionConfig_69               (Parm, ZeroConstructor)
// struct FLatentActionInfo       LatentInfo_69                  (Parm)
// EARServicePermissionRequestResult OutPermissionResult_69         (Parm, OutParm, ZeroConstructor, IsPlainOldData)

void ARDependencyHandler::RequestARSessionPermission(class Object_32759* WorldContextObject_69, class ARSessionConfig* SessionConfig_69, const struct FLatentActionInfo& LatentInfo_69, EARServicePermissionRequestResult* OutPermissionResult_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARDependencyHandler.RequestARSessionPermission"));

	ARDependencyHandler_RequestARSessionPermission_Params params;
	params.WorldContextObject_69 = WorldContextObject_69;
	params.SessionConfig_69 = SessionConfig_69;
	params.LatentInfo_69 = LatentInfo_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (OutPermissionResult_69 != nullptr)
		*OutPermissionResult_69 = params.OutPermissionResult_69;
}


// Function AugmentedReality.ARDependencyHandler.InstallARService
// (Native, Public, HasOutParms, BlueprintCallable)
// Parameters:
// class Object_32759*            WorldContextObject_69          (Parm, ZeroConstructor)
// struct FLatentActionInfo       LatentInfo_69                  (Parm)
// EARServiceInstallRequestResult OutInstallResult_69            (Parm, OutParm, ZeroConstructor, IsPlainOldData)

void ARDependencyHandler::InstallARService(class Object_32759* WorldContextObject_69, const struct FLatentActionInfo& LatentInfo_69, EARServiceInstallRequestResult* OutInstallResult_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARDependencyHandler.InstallARService"));

	ARDependencyHandler_InstallARService_Params params;
	params.WorldContextObject_69 = WorldContextObject_69;
	params.LatentInfo_69 = LatentInfo_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (OutInstallResult_69 != nullptr)
		*OutInstallResult_69 = params.OutInstallResult_69;
}


// Function AugmentedReality.ARDependencyHandler.GetARDependencyHandler
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// class ARDependencyHandler*     ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

class ARDependencyHandler* ARDependencyHandler::STATIC_GetARDependencyHandler()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARDependencyHandler.GetARDependencyHandler"));

	ARDependencyHandler_GetARDependencyHandler_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AugmentedReality.ARDependencyHandler.CheckARServiceAvailability
// (Native, Public, HasOutParms, BlueprintCallable)
// Parameters:
// class Object_32759*            WorldContextObject_69          (Parm, ZeroConstructor)
// struct FLatentActionInfo       LatentInfo_69                  (Parm)
// EARServiceAvailability         OutAvailability_69             (Parm, OutParm, ZeroConstructor, IsPlainOldData)

void ARDependencyHandler::CheckARServiceAvailability(class Object_32759* WorldContextObject_69, const struct FLatentActionInfo& LatentInfo_69, EARServiceAvailability* OutAvailability_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARDependencyHandler.CheckARServiceAvailability"));

	ARDependencyHandler_CheckARServiceAvailability_Params params;
	params.WorldContextObject_69 = WorldContextObject_69;
	params.LatentInfo_69 = LatentInfo_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (OutAvailability_69 != nullptr)
		*OutAvailability_69 = params.OutAvailability_69;
}


// Function AugmentedReality.ARGeoTrackingSupport.GetGeoTrackingSupport
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// class ARGeoTrackingSupport*    ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

class ARGeoTrackingSupport* ARGeoTrackingSupport::STATIC_GetGeoTrackingSupport()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARGeoTrackingSupport.GetGeoTrackingSupport"));

	ARGeoTrackingSupport_GetGeoTrackingSupport_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AugmentedReality.ARGeoTrackingSupport.GetGeoTrackingStateReason
// (Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// EARGeoTrackingStateReason      ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

EARGeoTrackingStateReason ARGeoTrackingSupport::GetGeoTrackingStateReason()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARGeoTrackingSupport.GetGeoTrackingStateReason"));

	ARGeoTrackingSupport_GetGeoTrackingStateReason_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AugmentedReality.ARGeoTrackingSupport.GetGeoTrackingState
// (Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// EARGeoTrackingState            ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

EARGeoTrackingState ARGeoTrackingSupport::GetGeoTrackingState()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARGeoTrackingSupport.GetGeoTrackingState"));

	ARGeoTrackingSupport_GetGeoTrackingState_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AugmentedReality.ARGeoTrackingSupport.GetGeoTrackingAccuracy
// (Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// EARGeoTrackingAccuracy         ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

EARGeoTrackingAccuracy ARGeoTrackingSupport::GetGeoTrackingAccuracy()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARGeoTrackingSupport.GetGeoTrackingAccuracy"));

	ARGeoTrackingSupport_GetGeoTrackingAccuracy_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AugmentedReality.ARGeoTrackingSupport.AddGeoAnchorAtLocationWithAltitude
// (Native, Public, BlueprintCallable)
// Parameters:
// float                          Longitude_69                   (Parm, ZeroConstructor, IsPlainOldData)
// float                          Latitude_69                    (Parm, ZeroConstructor, IsPlainOldData)
// float                          AltitudeMeters_69              (Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 OptionalAnchorName_69          (Parm, ZeroConstructor)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool ARGeoTrackingSupport::AddGeoAnchorAtLocationWithAltitude(float Longitude_69, float Latitude_69, float AltitudeMeters_69, const struct FString& OptionalAnchorName_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARGeoTrackingSupport.AddGeoAnchorAtLocationWithAltitude"));

	ARGeoTrackingSupport_AddGeoAnchorAtLocationWithAltitude_Params params;
	params.Longitude_69 = Longitude_69;
	params.Latitude_69 = Latitude_69;
	params.AltitudeMeters_69 = AltitudeMeters_69;
	params.OptionalAnchorName_69 = OptionalAnchorName_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AugmentedReality.ARGeoTrackingSupport.AddGeoAnchorAtLocation
// (Native, Public, BlueprintCallable)
// Parameters:
// float                          Longitude_69                   (Parm, ZeroConstructor, IsPlainOldData)
// float                          Latitude_69                    (Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 OptionalAnchorName_69          (Parm, ZeroConstructor)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool ARGeoTrackingSupport::AddGeoAnchorAtLocation(float Longitude_69, float Latitude_69, const struct FString& OptionalAnchorName_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARGeoTrackingSupport.AddGeoAnchorAtLocation"));

	ARGeoTrackingSupport_AddGeoAnchorAtLocation_Params params;
	params.Longitude_69 = Longitude_69;
	params.Latitude_69 = Latitude_69;
	params.OptionalAnchorName_69 = OptionalAnchorName_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// DelegateFunction AugmentedReality.CheckGeoTrackingAvailabilityAsyncTaskBlueprintProxy.GeoTrackingAvailabilityDelegate__DelegateSignature
// (MulticastDelegate, Public, Delegate)
// Parameters:
// bool                           bIsAvailable_69                (Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 Error_69                       (Parm, ZeroConstructor)

void CheckGeoTrackingAvailabilityAsyncTaskBlueprintProxy::GeoTrackingAvailabilityDelegate__DelegateSignature(bool bIsAvailable_69, const struct FString& Error_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("DelegateFunction AugmentedReality.CheckGeoTrackingAvailabilityAsyncTaskBlueprintProxy.GeoTrackingAvailabilityDelegate__DelegateSignature"));

	CheckGeoTrackingAvailabilityAsyncTaskBlueprintProxy_GeoTrackingAvailabilityDelegate__DelegateSignature_Params params;
	params.bIsAvailable_69 = bIsAvailable_69;
	params.Error_69 = Error_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AugmentedReality.CheckGeoTrackingAvailabilityAsyncTaskBlueprintProxy.CheckGeoTrackingAvailabilityAtLocation
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// class Object_32759*            WorldContextObject_69          (Parm, ZeroConstructor)
// float                          Longitude_69                   (Parm, ZeroConstructor, IsPlainOldData)
// float                          Latitude_69                    (Parm, ZeroConstructor, IsPlainOldData)
// class CheckGeoTrackingAvailabilityAsyncTaskBlueprintProxy* ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

class CheckGeoTrackingAvailabilityAsyncTaskBlueprintProxy* CheckGeoTrackingAvailabilityAsyncTaskBlueprintProxy::STATIC_CheckGeoTrackingAvailabilityAtLocation(class Object_32759* WorldContextObject_69, float Longitude_69, float Latitude_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.CheckGeoTrackingAvailabilityAsyncTaskBlueprintProxy.CheckGeoTrackingAvailabilityAtLocation"));

	CheckGeoTrackingAvailabilityAsyncTaskBlueprintProxy_CheckGeoTrackingAvailabilityAtLocation_Params params;
	params.WorldContextObject_69 = WorldContextObject_69;
	params.Longitude_69 = Longitude_69;
	params.Latitude_69 = Latitude_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AugmentedReality.CheckGeoTrackingAvailabilityAsyncTaskBlueprintProxy.CheckGeoTrackingAvailability
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// class Object_32759*            WorldContextObject_69          (Parm, ZeroConstructor)
// class CheckGeoTrackingAvailabilityAsyncTaskBlueprintProxy* ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

class CheckGeoTrackingAvailabilityAsyncTaskBlueprintProxy* CheckGeoTrackingAvailabilityAsyncTaskBlueprintProxy::STATIC_CheckGeoTrackingAvailability(class Object_32759* WorldContextObject_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.CheckGeoTrackingAvailabilityAsyncTaskBlueprintProxy.CheckGeoTrackingAvailability"));

	CheckGeoTrackingAvailabilityAsyncTaskBlueprintProxy_CheckGeoTrackingAvailability_Params params;
	params.WorldContextObject_69 = WorldContextObject_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// DelegateFunction AugmentedReality.GetGeoLocationAsyncTaskBlueprintProxy.GetGeoLocationDelegate__DelegateSignature
// (MulticastDelegate, Public, Delegate)
// Parameters:
// float                          Longitude_69                   (Parm, ZeroConstructor, IsPlainOldData)
// float                          Latitude_69                    (Parm, ZeroConstructor, IsPlainOldData)
// float                          Altitude_69                    (Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 Error_69                       (Parm, ZeroConstructor)

void GetGeoLocationAsyncTaskBlueprintProxy::GetGeoLocationDelegate__DelegateSignature(float Longitude_69, float Latitude_69, float Altitude_69, const struct FString& Error_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("DelegateFunction AugmentedReality.GetGeoLocationAsyncTaskBlueprintProxy.GetGeoLocationDelegate__DelegateSignature"));

	GetGeoLocationAsyncTaskBlueprintProxy_GetGeoLocationDelegate__DelegateSignature_Params params;
	params.Longitude_69 = Longitude_69;
	params.Latitude_69 = Latitude_69;
	params.Altitude_69 = Altitude_69;
	params.Error_69 = Error_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AugmentedReality.GetGeoLocationAsyncTaskBlueprintProxy.GetGeoLocationAtWorldPosition
// (Final, Native, Static, Public, HasOutParms, HasDefaults, BlueprintCallable)
// Parameters:
// class Object_32759*            WorldContextObject_69          (Parm, ZeroConstructor)
// struct FVector                 WorldPosition_69               (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
// class GetGeoLocationAsyncTaskBlueprintProxy* ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

class GetGeoLocationAsyncTaskBlueprintProxy* GetGeoLocationAsyncTaskBlueprintProxy::STATIC_GetGeoLocationAtWorldPosition(class Object_32759* WorldContextObject_69, const struct FVector& WorldPosition_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.GetGeoLocationAsyncTaskBlueprintProxy.GetGeoLocationAtWorldPosition"));

	GetGeoLocationAsyncTaskBlueprintProxy_GetGeoLocationAtWorldPosition_Params params;
	params.WorldContextObject_69 = WorldContextObject_69;
	params.WorldPosition_69 = WorldPosition_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AugmentedReality.ARLifeCycleComponent.ServerSpawnARActor
// (Final, Net, NetReliable, Native, Event, Private, NetServer, HasDefaults, NetValidate)
// Parameters:
// class Object_32759*            ComponentClass_69              (Parm, ZeroConstructor)
// struct FGuid                   NativeID_69                    (Parm, ZeroConstructor, IsPlainOldData)

void ARLifeCycleComponent::ServerSpawnARActor(class Object_32759* ComponentClass_69, const struct FGuid& NativeID_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARLifeCycleComponent.ServerSpawnARActor"));

	ARLifeCycleComponent_ServerSpawnARActor_Params params;
	params.ComponentClass_69 = ComponentClass_69;
	params.NativeID_69 = NativeID_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AugmentedReality.ARLifeCycleComponent.ServerDestroyARActor
// (Final, Net, NetReliable, Native, Event, Private, NetServer, NetValidate)
// Parameters:
// class ARActor*                 Actor_69                       (Parm, ZeroConstructor)

void ARLifeCycleComponent::ServerDestroyARActor(class ARActor* Actor_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARLifeCycleComponent.ServerDestroyARActor"));

	ARLifeCycleComponent_ServerDestroyARActor_Params params;
	params.Actor_69 = Actor_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// DelegateFunction AugmentedReality.ARLifeCycleComponent.InstanceARActorToBeDestroyedDelegate__DelegateSignature
// (MulticastDelegate, Public, Delegate)
// Parameters:
// class ARActor*                 Actor_69                       (Parm, ZeroConstructor)

void ARLifeCycleComponent::InstanceARActorToBeDestroyedDelegate__DelegateSignature(class ARActor* Actor_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("DelegateFunction AugmentedReality.ARLifeCycleComponent.InstanceARActorToBeDestroyedDelegate__DelegateSignature"));

	ARLifeCycleComponent_InstanceARActorToBeDestroyedDelegate__DelegateSignature_Params params;
	params.Actor_69 = Actor_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// DelegateFunction AugmentedReality.ARLifeCycleComponent.InstanceARActorSpawnedDelegate__DelegateSignature
// (MulticastDelegate, Public, Delegate, HasDefaults)
// Parameters:
// class Object_32759*            ComponentClass_69              (Parm, ZeroConstructor)
// struct FGuid                   NativeID_69                    (Parm, ZeroConstructor, IsPlainOldData)
// class ARActor*                 SpawnedActor_69                (Parm, ZeroConstructor)

void ARLifeCycleComponent::InstanceARActorSpawnedDelegate__DelegateSignature(class Object_32759* ComponentClass_69, const struct FGuid& NativeID_69, class ARActor* SpawnedActor_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("DelegateFunction AugmentedReality.ARLifeCycleComponent.InstanceARActorSpawnedDelegate__DelegateSignature"));

	ARLifeCycleComponent_InstanceARActorSpawnedDelegate__DelegateSignature_Params params;
	params.ComponentClass_69 = ComponentClass_69;
	params.NativeID_69 = NativeID_69;
	params.SpawnedActor_69 = SpawnedActor_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AugmentedReality.ARBasicLightEstimate.GetAmbientIntensityLumens
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// float                          ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

float ARBasicLightEstimate::GetAmbientIntensityLumens()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARBasicLightEstimate.GetAmbientIntensityLumens"));

	ARBasicLightEstimate_GetAmbientIntensityLumens_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AugmentedReality.ARBasicLightEstimate.GetAmbientColorTemperatureKelvin
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// float                          ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

float ARBasicLightEstimate::GetAmbientColorTemperatureKelvin()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARBasicLightEstimate.GetAmbientColorTemperatureKelvin"));

	ARBasicLightEstimate_GetAmbientColorTemperatureKelvin_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AugmentedReality.ARBasicLightEstimate.GetAmbientColor
// (Final, Native, Public, HasDefaults, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FLinearColor            ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

struct FLinearColor ARBasicLightEstimate::GetAmbientColor()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARBasicLightEstimate.GetAmbientColor"));

	ARBasicLightEstimate_GetAmbientColor_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AugmentedReality.ARPin.GetTrackingState
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// EARTrackingState               ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

EARTrackingState ARPin::GetTrackingState()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARPin.GetTrackingState"));

	ARPin_GetTrackingState_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AugmentedReality.ARPin.GetTrackedGeometry
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// class ARTrackedGeometry*       ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

class ARTrackedGeometry* ARPin::GetTrackedGeometry()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARPin.GetTrackedGeometry"));

	ARPin_GetTrackedGeometry_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AugmentedReality.ARPin.GetPinnedComponent
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// class SceneComponent*          ReturnValue_69                 (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)

class SceneComponent* ARPin::GetPinnedComponent()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARPin.GetPinnedComponent"));

	ARPin_GetPinnedComponent_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AugmentedReality.ARPin.GetLocalToWorldTransform
// (Final, Native, Public, HasDefaults, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FCoreUObject_FTransform ReturnValue_69                 (Parm, OutParm, ReturnParm, IsPlainOldData)

struct FCoreUObject_FTransform ARPin::GetLocalToWorldTransform()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARPin.GetLocalToWorldTransform"));

	ARPin_GetLocalToWorldTransform_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AugmentedReality.ARPin.GetLocalToTrackingTransform
// (Final, Native, Public, HasDefaults, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FCoreUObject_FTransform ReturnValue_69                 (Parm, OutParm, ReturnParm, IsPlainOldData)

struct FCoreUObject_FTransform ARPin::GetLocalToTrackingTransform()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARPin.GetLocalToTrackingTransform"));

	ARPin_GetLocalToTrackingTransform_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AugmentedReality.ARPin.GetDebugName
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FName                   ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

struct FName ARPin::GetDebugName()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARPin.GetDebugName"));

	ARPin_GetDebugName_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AugmentedReality.ARPin.DebugDraw
// (Native, Public, HasOutParms, HasDefaults, Const)
// Parameters:
// class World*                   World_69                       (Parm, ZeroConstructor)
// struct FLinearColor            Color_69                       (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
// float                          Scale_69                       (Parm, ZeroConstructor, IsPlainOldData)
// float                          PersistForSeconds_69           (Parm, ZeroConstructor, IsPlainOldData)

void ARPin::DebugDraw(class World* World_69, const struct FLinearColor& Color_69, float Scale_69, float PersistForSeconds_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARPin.DebugDraw"));

	ARPin_DebugDraw_Params params;
	params.World_69 = World_69;
	params.Color_69 = Color_69;
	params.Scale_69 = Scale_69;
	params.PersistForSeconds_69 = PersistForSeconds_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AugmentedReality.ARSessionConfig.ShouldResetTrackedObjects
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool ARSessionConfig::ShouldResetTrackedObjects()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARSessionConfig.ShouldResetTrackedObjects"));

	ARSessionConfig_ShouldResetTrackedObjects_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AugmentedReality.ARSessionConfig.ShouldResetCameraTracking
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool ARSessionConfig::ShouldResetCameraTracking()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARSessionConfig.ShouldResetCameraTracking"));

	ARSessionConfig_ShouldResetCameraTracking_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AugmentedReality.ARSessionConfig.ShouldRenderCameraOverlay
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool ARSessionConfig::ShouldRenderCameraOverlay()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARSessionConfig.ShouldRenderCameraOverlay"));

	ARSessionConfig_ShouldRenderCameraOverlay_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AugmentedReality.ARSessionConfig.ShouldEnableCameraTracking
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool ARSessionConfig::ShouldEnableCameraTracking()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARSessionConfig.ShouldEnableCameraTracking"));

	ARSessionConfig_ShouldEnableCameraTracking_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AugmentedReality.ARSessionConfig.ShouldEnableAutoFocus
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool ARSessionConfig::ShouldEnableAutoFocus()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARSessionConfig.ShouldEnableAutoFocus"));

	ARSessionConfig_ShouldEnableAutoFocus_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AugmentedReality.ARSessionConfig.SetWorldMapData
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// TArray<unsigned char>          WorldMapData_69                (Parm, ZeroConstructor)

void ARSessionConfig::SetWorldMapData(TArray<unsigned char> WorldMapData_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARSessionConfig.SetWorldMapData"));

	ARSessionConfig_SetWorldMapData_Params params;
	params.WorldMapData_69 = WorldMapData_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AugmentedReality.ARSessionConfig.SetSessionTrackingFeatureToEnable
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// EARSessionTrackingFeature      InSessionTrackingFeature_69    (Parm, ZeroConstructor, IsPlainOldData)

void ARSessionConfig::SetSessionTrackingFeatureToEnable(EARSessionTrackingFeature InSessionTrackingFeature_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARSessionConfig.SetSessionTrackingFeatureToEnable"));

	ARSessionConfig_SetSessionTrackingFeatureToEnable_Params params;
	params.InSessionTrackingFeature_69 = InSessionTrackingFeature_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AugmentedReality.ARSessionConfig.SetSceneReconstructionMethod
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// EARSceneReconstruction         InSceneReconstructionMethod_69 (Parm, ZeroConstructor, IsPlainOldData)

void ARSessionConfig::SetSceneReconstructionMethod(EARSceneReconstruction InSceneReconstructionMethod_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARSessionConfig.SetSceneReconstructionMethod"));

	ARSessionConfig_SetSceneReconstructionMethod_Params params;
	params.InSceneReconstructionMethod_69 = InSceneReconstructionMethod_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AugmentedReality.ARSessionConfig.SetResetTrackedObjects
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// bool                           bNewValue_69                   (Parm, ZeroConstructor, IsPlainOldData)

void ARSessionConfig::SetResetTrackedObjects(bool bNewValue_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARSessionConfig.SetResetTrackedObjects"));

	ARSessionConfig_SetResetTrackedObjects_Params params;
	params.bNewValue_69 = bNewValue_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AugmentedReality.ARSessionConfig.SetResetCameraTracking
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// bool                           bNewValue_69                   (Parm, ZeroConstructor, IsPlainOldData)

void ARSessionConfig::SetResetCameraTracking(bool bNewValue_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARSessionConfig.SetResetCameraTracking"));

	ARSessionConfig_SetResetCameraTracking_Params params;
	params.bNewValue_69 = bNewValue_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AugmentedReality.ARSessionConfig.SetFaceTrackingUpdate
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// EARFaceTrackingUpdate          InUpdate_69                    (Parm, ZeroConstructor, IsPlainOldData)

void ARSessionConfig::SetFaceTrackingUpdate(EARFaceTrackingUpdate InUpdate_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARSessionConfig.SetFaceTrackingUpdate"));

	ARSessionConfig_SetFaceTrackingUpdate_Params params;
	params.InUpdate_69 = InUpdate_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AugmentedReality.ARSessionConfig.SetFaceTrackingDirection
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// EARFaceTrackingDirection       InDirection_69                 (Parm, ZeroConstructor, IsPlainOldData)

void ARSessionConfig::SetFaceTrackingDirection(EARFaceTrackingDirection InDirection_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARSessionConfig.SetFaceTrackingDirection"));

	ARSessionConfig_SetFaceTrackingDirection_Params params;
	params.InDirection_69 = InDirection_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AugmentedReality.ARSessionConfig.SetEnableAutoFocus
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// bool                           bNewValue_69                   (Parm, ZeroConstructor, IsPlainOldData)

void ARSessionConfig::SetEnableAutoFocus(bool bNewValue_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARSessionConfig.SetEnableAutoFocus"));

	ARSessionConfig_SetEnableAutoFocus_Params params;
	params.bNewValue_69 = bNewValue_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AugmentedReality.ARSessionConfig.SetDesiredVideoFormat
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// struct FARVideoFormat          NewFormat_69                   (Parm)

void ARSessionConfig::SetDesiredVideoFormat(const struct FARVideoFormat& NewFormat_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARSessionConfig.SetDesiredVideoFormat"));

	ARSessionConfig_SetDesiredVideoFormat_Params params;
	params.NewFormat_69 = NewFormat_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AugmentedReality.ARSessionConfig.SetCandidateObjectList
// (Final, Native, Public, HasOutParms, BlueprintCallable)
// Parameters:
// TArray<class ARCandidateObject*> InCandidateObjects_69          (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)

void ARSessionConfig::SetCandidateObjectList(TArray<class ARCandidateObject*> InCandidateObjects_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARSessionConfig.SetCandidateObjectList"));

	ARSessionConfig_SetCandidateObjectList_Params params;
	params.InCandidateObjects_69 = InCandidateObjects_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AugmentedReality.ARSessionConfig.GetWorldMapData
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// TArray<unsigned char>          ReturnValue_69                 (ConstParm, Parm, OutParm, ZeroConstructor, ReturnParm, ReferenceParm)

TArray<unsigned char> ARSessionConfig::GetWorldMapData()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARSessionConfig.GetWorldMapData"));

	ARSessionConfig_GetWorldMapData_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AugmentedReality.ARSessionConfig.GetWorldAlignment
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// EARWorldAlignment              ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

EARWorldAlignment ARSessionConfig::GetWorldAlignment()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARSessionConfig.GetWorldAlignment"));

	ARSessionConfig_GetWorldAlignment_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AugmentedReality.ARSessionConfig.GetSessionType
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// EARSessionType                 ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

EARSessionType ARSessionConfig::GetSessionType()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARSessionConfig.GetSessionType"));

	ARSessionConfig_GetSessionType_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AugmentedReality.ARSessionConfig.GetSceneReconstructionMethod
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// EARSceneReconstruction         ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

EARSceneReconstruction ARSessionConfig::GetSceneReconstructionMethod()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARSessionConfig.GetSceneReconstructionMethod"));

	ARSessionConfig_GetSceneReconstructionMethod_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AugmentedReality.ARSessionConfig.GetPlaneDetectionMode
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// EARPlaneDetectionMode          ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

EARPlaneDetectionMode ARSessionConfig::GetPlaneDetectionMode()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARSessionConfig.GetPlaneDetectionMode"));

	ARSessionConfig_GetPlaneDetectionMode_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AugmentedReality.ARSessionConfig.GetMaxNumSimultaneousImagesTracked
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// int                            ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int ARSessionConfig::GetMaxNumSimultaneousImagesTracked()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARSessionConfig.GetMaxNumSimultaneousImagesTracked"));

	ARSessionConfig_GetMaxNumSimultaneousImagesTracked_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AugmentedReality.ARSessionConfig.GetLightEstimationMode
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// EARLightEstimationMode         ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

EARLightEstimationMode ARSessionConfig::GetLightEstimationMode()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARSessionConfig.GetLightEstimationMode"));

	ARSessionConfig_GetLightEstimationMode_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AugmentedReality.ARSessionConfig.GetFrameSyncMode
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// EARFrameSyncMode               ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

EARFrameSyncMode ARSessionConfig::GetFrameSyncMode()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARSessionConfig.GetFrameSyncMode"));

	ARSessionConfig_GetFrameSyncMode_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AugmentedReality.ARSessionConfig.GetFaceTrackingUpdate
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// EARFaceTrackingUpdate          ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

EARFaceTrackingUpdate ARSessionConfig::GetFaceTrackingUpdate()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARSessionConfig.GetFaceTrackingUpdate"));

	ARSessionConfig_GetFaceTrackingUpdate_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AugmentedReality.ARSessionConfig.GetFaceTrackingDirection
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// EARFaceTrackingDirection       ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

EARFaceTrackingDirection ARSessionConfig::GetFaceTrackingDirection()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARSessionConfig.GetFaceTrackingDirection"));

	ARSessionConfig_GetFaceTrackingDirection_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AugmentedReality.ARSessionConfig.GetEnvironmentCaptureProbeType
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// EAREnvironmentCaptureProbeType ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

EAREnvironmentCaptureProbeType ARSessionConfig::GetEnvironmentCaptureProbeType()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARSessionConfig.GetEnvironmentCaptureProbeType"));

	ARSessionConfig_GetEnvironmentCaptureProbeType_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AugmentedReality.ARSessionConfig.GetEnabledSessionTrackingFeature
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// EARSessionTrackingFeature      ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

EARSessionTrackingFeature ARSessionConfig::GetEnabledSessionTrackingFeature()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARSessionConfig.GetEnabledSessionTrackingFeature"));

	ARSessionConfig_GetEnabledSessionTrackingFeature_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AugmentedReality.ARSessionConfig.GetDesiredVideoFormat
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FARVideoFormat          ReturnValue_69                 (Parm, OutParm, ReturnParm)

struct FARVideoFormat ARSessionConfig::GetDesiredVideoFormat()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARSessionConfig.GetDesiredVideoFormat"));

	ARSessionConfig_GetDesiredVideoFormat_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AugmentedReality.ARSessionConfig.GetCandidateObjectList
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// TArray<class ARCandidateObject*> ReturnValue_69                 (ConstParm, Parm, OutParm, ZeroConstructor, ReturnParm, ReferenceParm)

TArray<class ARCandidateObject*> ARSessionConfig::GetCandidateObjectList()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARSessionConfig.GetCandidateObjectList"));

	ARSessionConfig_GetCandidateObjectList_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AugmentedReality.ARSessionConfig.GetCandidateImageList
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// TArray<class ARCandidateImage*> ReturnValue_69                 (ConstParm, Parm, OutParm, ZeroConstructor, ReturnParm, ReferenceParm)

TArray<class ARCandidateImage*> ARSessionConfig::GetCandidateImageList()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARSessionConfig.GetCandidateImageList"));

	ARSessionConfig_GetCandidateImageList_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AugmentedReality.ARSessionConfig.AddCandidateObject
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// class ARCandidateObject*       CandidateObject_69             (Parm, ZeroConstructor)

void ARSessionConfig::AddCandidateObject(class ARCandidateObject* CandidateObject_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARSessionConfig.AddCandidateObject"));

	ARSessionConfig_AddCandidateObject_Params params;
	params.CandidateObject_69 = CandidateObject_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AugmentedReality.ARSessionConfig.AddCandidateImage
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// class ARCandidateImage*        NewCandidateImage_69           (Parm, ZeroConstructor)

void ARSessionConfig::AddCandidateImage(class ARCandidateImage* NewCandidateImage_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARSessionConfig.AddCandidateImage"));

	ARSessionConfig_AddCandidateImage_Params params;
	params.NewCandidateImage_69 = NewCandidateImage_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AugmentedReality.ARSharedWorldGameMode.SetPreviewImageData
// (Final, BlueprintAuthorityOnly, Native, Public, BlueprintCallable)
// Parameters:
// TArray<unsigned char>          ImageData_69                   (Parm, ZeroConstructor)

void ARSharedWorldGameMode::SetPreviewImageData(TArray<unsigned char> ImageData_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARSharedWorldGameMode.SetPreviewImageData"));

	ARSharedWorldGameMode_SetPreviewImageData_Params params;
	params.ImageData_69 = ImageData_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AugmentedReality.ARSharedWorldGameMode.SetARWorldSharingIsReady
// (Final, BlueprintAuthorityOnly, Native, Public, BlueprintCallable)

void ARSharedWorldGameMode::SetARWorldSharingIsReady()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARSharedWorldGameMode.SetARWorldSharingIsReady"));

	ARSharedWorldGameMode_SetARWorldSharingIsReady_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AugmentedReality.ARSharedWorldGameMode.SetARSharedWorldData
// (Final, BlueprintAuthorityOnly, Native, Public, BlueprintCallable)
// Parameters:
// TArray<unsigned char>          ARWorldData_69                 (Parm, ZeroConstructor)

void ARSharedWorldGameMode::SetARSharedWorldData(TArray<unsigned char> ARWorldData_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARSharedWorldGameMode.SetARSharedWorldData"));

	ARSharedWorldGameMode_SetARSharedWorldData_Params params;
	params.ARWorldData_69 = ARWorldData_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AugmentedReality.ARSharedWorldGameMode.GetARSharedWorldGameState
// (Final, BlueprintAuthorityOnly, Native, Public, BlueprintCallable)
// Parameters:
// class ARSharedWorldGameState*  ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

class ARSharedWorldGameState* ARSharedWorldGameMode::GetARSharedWorldGameState()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARSharedWorldGameMode.GetARSharedWorldGameState"));

	ARSharedWorldGameMode_GetARSharedWorldGameState_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AugmentedReality.ARSharedWorldGameState.K2_OnARWorldMapIsReady
// (Event, Public, BlueprintEvent)

void ARSharedWorldGameState::K2_OnARWorldMapIsReady()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARSharedWorldGameState.K2_OnARWorldMapIsReady"));

	ARSharedWorldGameState_K2_OnARWorldMapIsReady_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AugmentedReality.ARSharedWorldPlayerController.ServerMarkReadyForReceiving
// (Net, NetReliable, Native, Event, Public, NetServer, NetValidate)

void ARSharedWorldPlayerController::ServerMarkReadyForReceiving()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARSharedWorldPlayerController.ServerMarkReadyForReceiving"));

	ARSharedWorldPlayerController_ServerMarkReadyForReceiving_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AugmentedReality.ARSharedWorldPlayerController.ClientUpdatePreviewImageData
// (Net, NetReliable, Native, Event, Public, NetClient, NetValidate)
// Parameters:
// int                            Offset_69                      (Parm, ZeroConstructor, IsPlainOldData)
// TArray<unsigned char>          Buffer_69                      (ConstParm, Parm, ZeroConstructor, ReferenceParm)

void ARSharedWorldPlayerController::ClientUpdatePreviewImageData(int Offset_69, TArray<unsigned char> Buffer_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARSharedWorldPlayerController.ClientUpdatePreviewImageData"));

	ARSharedWorldPlayerController_ClientUpdatePreviewImageData_Params params;
	params.Offset_69 = Offset_69;
	params.Buffer_69 = Buffer_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AugmentedReality.ARSharedWorldPlayerController.ClientUpdateARWorldData
// (Net, NetReliable, Native, Event, Public, NetClient, NetValidate)
// Parameters:
// int                            Offset_69                      (Parm, ZeroConstructor, IsPlainOldData)
// TArray<unsigned char>          Buffer_69                      (ConstParm, Parm, ZeroConstructor, ReferenceParm)

void ARSharedWorldPlayerController::ClientUpdateARWorldData(int Offset_69, TArray<unsigned char> Buffer_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARSharedWorldPlayerController.ClientUpdateARWorldData"));

	ARSharedWorldPlayerController_ClientUpdateARWorldData_Params params;
	params.Offset_69 = Offset_69;
	params.Buffer_69 = Buffer_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AugmentedReality.ARSharedWorldPlayerController.ClientInitSharedWorld
// (Net, NetReliable, Native, Event, Public, NetClient, NetValidate)
// Parameters:
// int                            PreviewImageSize_69            (Parm, ZeroConstructor, IsPlainOldData)
// int                            ARWorldDataSize_69             (Parm, ZeroConstructor, IsPlainOldData)

void ARSharedWorldPlayerController::ClientInitSharedWorld(int PreviewImageSize_69, int ARWorldDataSize_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARSharedWorldPlayerController.ClientInitSharedWorld"));

	ARSharedWorldPlayerController_ClientInitSharedWorld_Params params;
	params.PreviewImageSize_69 = PreviewImageSize_69;
	params.ARWorldDataSize_69 = ARWorldDataSize_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AugmentedReality.ARSkyLight.SetEnvironmentCaptureProbe
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// class AREnvironmentCaptureProbe* InCaptureProbe_69              (Parm, ZeroConstructor)

void ARSkyLight::SetEnvironmentCaptureProbe(class AREnvironmentCaptureProbe* InCaptureProbe_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARSkyLight.SetEnvironmentCaptureProbe"));

	ARSkyLight_SetEnvironmentCaptureProbe_Params params;
	params.InCaptureProbe_69 = InCaptureProbe_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AugmentedReality.ARTrackedGeometry.IsTracked
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool ARTrackedGeometry::IsTracked()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARTrackedGeometry.IsTracked"));

	ARTrackedGeometry_IsTracked_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AugmentedReality.ARTrackedGeometry.HasSpatialMeshUsageFlag
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// EARSpatialMeshUsageFlags       InFlag_69                      (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool ARTrackedGeometry::HasSpatialMeshUsageFlag(EARSpatialMeshUsageFlags InFlag_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARTrackedGeometry.HasSpatialMeshUsageFlag"));

	ARTrackedGeometry_HasSpatialMeshUsageFlag_Params params;
	params.InFlag_69 = InFlag_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AugmentedReality.ARTrackedGeometry.GetUnderlyingMesh
// (Final, Native, Public, BlueprintCallable, BlueprintPure)
// Parameters:
// class MRMeshComponent*         ReturnValue_69                 (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)

class MRMeshComponent* ARTrackedGeometry::GetUnderlyingMesh()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARTrackedGeometry.GetUnderlyingMesh"));

	ARTrackedGeometry_GetUnderlyingMesh_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AugmentedReality.ARTrackedGeometry.GetTrackingState
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// EARTrackingState               ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

EARTrackingState ARTrackedGeometry::GetTrackingState()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARTrackedGeometry.GetTrackingState"));

	ARTrackedGeometry_GetTrackingState_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AugmentedReality.ARTrackedGeometry.GetObjectClassification
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// EARObjectClassification        ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

EARObjectClassification ARTrackedGeometry::GetObjectClassification()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARTrackedGeometry.GetObjectClassification"));

	ARTrackedGeometry_GetObjectClassification_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AugmentedReality.ARTrackedGeometry.GetName
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FString                 ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString ARTrackedGeometry::GetName()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARTrackedGeometry.GetName"));

	ARTrackedGeometry_GetName_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AugmentedReality.ARTrackedGeometry.GetLocalToWorldTransform
// (Final, Native, Public, HasDefaults, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FCoreUObject_FTransform ReturnValue_69                 (Parm, OutParm, ReturnParm, IsPlainOldData)

struct FCoreUObject_FTransform ARTrackedGeometry::GetLocalToWorldTransform()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARTrackedGeometry.GetLocalToWorldTransform"));

	ARTrackedGeometry_GetLocalToWorldTransform_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AugmentedReality.ARTrackedGeometry.GetLocalToTrackingTransform
// (Final, Native, Public, HasDefaults, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FCoreUObject_FTransform ReturnValue_69                 (Parm, OutParm, ReturnParm, IsPlainOldData)

struct FCoreUObject_FTransform ARTrackedGeometry::GetLocalToTrackingTransform()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARTrackedGeometry.GetLocalToTrackingTransform"));

	ARTrackedGeometry_GetLocalToTrackingTransform_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AugmentedReality.ARTrackedGeometry.GetLastUpdateTimestamp
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// float                          ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

float ARTrackedGeometry::GetLastUpdateTimestamp()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARTrackedGeometry.GetLastUpdateTimestamp"));

	ARTrackedGeometry_GetLastUpdateTimestamp_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AugmentedReality.ARTrackedGeometry.GetLastUpdateFrameNumber
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// int                            ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int ARTrackedGeometry::GetLastUpdateFrameNumber()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARTrackedGeometry.GetLastUpdateFrameNumber"));

	ARTrackedGeometry_GetLastUpdateFrameNumber_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AugmentedReality.ARTrackedGeometry.GetDebugName
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FName                   ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

struct FName ARTrackedGeometry::GetDebugName()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARTrackedGeometry.GetDebugName"));

	ARTrackedGeometry_GetDebugName_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AugmentedReality.ARPlaneGeometry.GetSubsumedBy
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// class ARPlaneGeometry*         ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

class ARPlaneGeometry* ARPlaneGeometry::GetSubsumedBy()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARPlaneGeometry.GetSubsumedBy"));

	ARPlaneGeometry_GetSubsumedBy_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AugmentedReality.ARPlaneGeometry.GetOrientation
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// EARPlaneOrientation            ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

EARPlaneOrientation ARPlaneGeometry::GetOrientation()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARPlaneGeometry.GetOrientation"));

	ARPlaneGeometry_GetOrientation_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AugmentedReality.ARPlaneGeometry.GetExtent
// (Final, Native, Public, HasDefaults, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FVector                 ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

struct FVector ARPlaneGeometry::GetExtent()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARPlaneGeometry.GetExtent"));

	ARPlaneGeometry_GetExtent_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AugmentedReality.ARPlaneGeometry.GetCenter
// (Final, Native, Public, HasDefaults, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FVector                 ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

struct FVector ARPlaneGeometry::GetCenter()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARPlaneGeometry.GetCenter"));

	ARPlaneGeometry_GetCenter_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AugmentedReality.ARPlaneGeometry.GetBoundaryPolygonInLocalSpace
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// TArray<struct FVector>         ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

TArray<struct FVector> ARPlaneGeometry::GetBoundaryPolygonInLocalSpace()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARPlaneGeometry.GetBoundaryPolygonInLocalSpace"));

	ARPlaneGeometry_GetBoundaryPolygonInLocalSpace_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AugmentedReality.ARTrackedImage.GetEstimateSize
// (Final, Native, Public, HasDefaults, BlueprintCallable, BlueprintPure)
// Parameters:
// struct FVector2D               ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

struct FVector2D ARTrackedImage::GetEstimateSize()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARTrackedImage.GetEstimateSize"));

	ARTrackedImage_GetEstimateSize_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AugmentedReality.ARTrackedImage.GetDetectedImage
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// class ARCandidateImage*        ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

class ARCandidateImage* ARTrackedImage::GetDetectedImage()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARTrackedImage.GetDetectedImage"));

	ARTrackedImage_GetDetectedImage_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AugmentedReality.ARFaceGeometry.GetWorldSpaceEyeTransform
// (Final, Native, Public, HasDefaults, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// EAREye                         Eye_69                         (Parm, ZeroConstructor, IsPlainOldData)
// struct FCoreUObject_FTransform ReturnValue_69                 (Parm, OutParm, ReturnParm, IsPlainOldData)

struct FCoreUObject_FTransform ARFaceGeometry::GetWorldSpaceEyeTransform(EAREye Eye_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARFaceGeometry.GetWorldSpaceEyeTransform"));

	ARFaceGeometry_GetWorldSpaceEyeTransform_Params params;
	params.Eye_69 = Eye_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AugmentedReality.ARFaceGeometry.GetLocalSpaceEyeTransform
// (Final, Native, Public, HasDefaults, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// EAREye                         Eye_69                         (Parm, ZeroConstructor, IsPlainOldData)
// struct FCoreUObject_FTransform ReturnValue_69                 (ConstParm, Parm, OutParm, ReturnParm, ReferenceParm, IsPlainOldData)

struct FCoreUObject_FTransform ARFaceGeometry::GetLocalSpaceEyeTransform(EAREye Eye_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARFaceGeometry.GetLocalSpaceEyeTransform"));

	ARFaceGeometry_GetLocalSpaceEyeTransform_Params params;
	params.Eye_69 = Eye_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AugmentedReality.ARFaceGeometry.GetBlendShapeValue
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// EARFaceBlendShape              BlendShape_69                  (Parm, ZeroConstructor, IsPlainOldData)
// float                          ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

float ARFaceGeometry::GetBlendShapeValue(EARFaceBlendShape BlendShape_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARFaceGeometry.GetBlendShapeValue"));

	ARFaceGeometry_GetBlendShapeValue_Params params;
	params.BlendShape_69 = BlendShape_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AugmentedReality.ARFaceGeometry.GetBlendShapes
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// TMap<EARFaceBlendShape, float> ReturnValue_69                 (ConstParm, Parm, OutParm, ReturnParm)

TMap<EARFaceBlendShape, float> ARFaceGeometry::GetBlendShapes()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARFaceGeometry.GetBlendShapes"));

	ARFaceGeometry_GetBlendShapes_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AugmentedReality.AREnvironmentCaptureProbe.GetExtent
// (Final, Native, Public, HasDefaults, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FVector                 ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

struct FVector AREnvironmentCaptureProbe::GetExtent()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.AREnvironmentCaptureProbe.GetExtent"));

	AREnvironmentCaptureProbe_GetExtent_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AugmentedReality.AREnvironmentCaptureProbe.GetEnvironmentCaptureTexture
// (Final, Native, Public, BlueprintCallable, BlueprintPure)
// Parameters:
// class AREnvironmentCaptureProbeTexture* ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

class AREnvironmentCaptureProbeTexture* AREnvironmentCaptureProbe::GetEnvironmentCaptureTexture()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.AREnvironmentCaptureProbe.GetEnvironmentCaptureTexture"));

	AREnvironmentCaptureProbe_GetEnvironmentCaptureTexture_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AugmentedReality.ARTrackedObject.GetDetectedObject
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// class ARCandidateObject*       ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

class ARCandidateObject* ARTrackedObject::GetDetectedObject()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARTrackedObject.GetDetectedObject"));

	ARTrackedObject_GetDetectedObject_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AugmentedReality.ARTrackedPose.GetTrackedPoseData
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FARPose3D               ReturnValue_69                 (ConstParm, Parm, OutParm, ReturnParm, ReferenceParm)

struct FARPose3D ARTrackedPose::GetTrackedPoseData()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARTrackedPose.GetTrackedPoseData"));

	ARTrackedPose_GetTrackedPoseData_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AugmentedReality.ARMeshGeometry.GetObjectClassificationAtLocation
// (Native, Public, HasOutParms, HasDefaults, BlueprintCallable)
// Parameters:
// struct FVector                 InWorldLocation_69             (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
// EARObjectClassification        OutClassification_69           (Parm, OutParm, ZeroConstructor, IsPlainOldData)
// struct FVector                 OutClassificationLocation_69   (Parm, OutParm, ZeroConstructor, IsPlainOldData)
// float                          MaxLocationDiff_69             (Parm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool ARMeshGeometry::GetObjectClassificationAtLocation(const struct FVector& InWorldLocation_69, float MaxLocationDiff_69, EARObjectClassification* OutClassification_69, struct FVector* OutClassificationLocation_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARMeshGeometry.GetObjectClassificationAtLocation"));

	ARMeshGeometry_GetObjectClassificationAtLocation_Params params;
	params.InWorldLocation_69 = InWorldLocation_69;
	params.MaxLocationDiff_69 = MaxLocationDiff_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (OutClassification_69 != nullptr)
		*OutClassification_69 = params.OutClassification_69;
	if (OutClassificationLocation_69 != nullptr)
		*OutClassificationLocation_69 = params.OutClassificationLocation_69;

	return params.ReturnValue_69;
}


// Function AugmentedReality.ARGeoAnchor.GetLongitude
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// float                          ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

float ARGeoAnchor::GetLongitude()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARGeoAnchor.GetLongitude"));

	ARGeoAnchor_GetLongitude_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AugmentedReality.ARGeoAnchor.GetLatitude
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// float                          ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

float ARGeoAnchor::GetLatitude()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARGeoAnchor.GetLatitude"));

	ARGeoAnchor_GetLatitude_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AugmentedReality.ARGeoAnchor.GetAltitudeSource
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// EARAltitudeSource              ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

EARAltitudeSource ARGeoAnchor::GetAltitudeSource()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARGeoAnchor.GetAltitudeSource"));

	ARGeoAnchor_GetAltitudeSource_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AugmentedReality.ARGeoAnchor.GetAltitudeMeters
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// float                          ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

float ARGeoAnchor::GetAltitudeMeters()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARGeoAnchor.GetAltitudeMeters"));

	ARGeoAnchor_GetAltitudeMeters_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AugmentedReality.ARCandidateImage.GetPhysicalWidth
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// float                          ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

float ARCandidateImage::GetPhysicalWidth()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARCandidateImage.GetPhysicalWidth"));

	ARCandidateImage_GetPhysicalWidth_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AugmentedReality.ARCandidateImage.GetPhysicalHeight
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// float                          ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

float ARCandidateImage::GetPhysicalHeight()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARCandidateImage.GetPhysicalHeight"));

	ARCandidateImage_GetPhysicalHeight_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AugmentedReality.ARCandidateImage.GetOrientation
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// EARCandidateImageOrientation   ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

EARCandidateImageOrientation ARCandidateImage::GetOrientation()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARCandidateImage.GetOrientation"));

	ARCandidateImage_GetOrientation_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AugmentedReality.ARCandidateImage.GetFriendlyName
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FString                 ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString ARCandidateImage::GetFriendlyName()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARCandidateImage.GetFriendlyName"));

	ARCandidateImage_GetFriendlyName_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AugmentedReality.ARCandidateImage.GetCandidateTexture
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// class Texture2D*               ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

class Texture2D* ARCandidateImage::GetCandidateTexture()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARCandidateImage.GetCandidateTexture"));

	ARCandidateImage_GetCandidateTexture_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AugmentedReality.ARCandidateObject.SetFriendlyName
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// struct FString                 NewName_69                     (Parm, ZeroConstructor)

void ARCandidateObject::SetFriendlyName(const struct FString& NewName_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARCandidateObject.SetFriendlyName"));

	ARCandidateObject_SetFriendlyName_Params params;
	params.NewName_69 = NewName_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AugmentedReality.ARCandidateObject.SetCandidateObjectData
// (Final, Native, Public, HasOutParms, BlueprintCallable)
// Parameters:
// TArray<unsigned char>          InCandidateObject_69           (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)

void ARCandidateObject::SetCandidateObjectData(TArray<unsigned char> InCandidateObject_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARCandidateObject.SetCandidateObjectData"));

	ARCandidateObject_SetCandidateObjectData_Params params;
	params.InCandidateObject_69 = InCandidateObject_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AugmentedReality.ARCandidateObject.SetBoundingBox
// (Final, Native, Public, HasOutParms, HasDefaults, BlueprintCallable)
// Parameters:
// struct FBox                    InBoundingBox_69               (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)

void ARCandidateObject::SetBoundingBox(const struct FBox& InBoundingBox_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARCandidateObject.SetBoundingBox"));

	ARCandidateObject_SetBoundingBox_Params params;
	params.InBoundingBox_69 = InBoundingBox_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AugmentedReality.ARCandidateObject.GetFriendlyName
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FString                 ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString ARCandidateObject::GetFriendlyName()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARCandidateObject.GetFriendlyName"));

	ARCandidateObject_GetFriendlyName_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AugmentedReality.ARCandidateObject.GetCandidateObjectData
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// TArray<unsigned char>          ReturnValue_69                 (ConstParm, Parm, OutParm, ZeroConstructor, ReturnParm, ReferenceParm)

TArray<unsigned char> ARCandidateObject::GetCandidateObjectData()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARCandidateObject.GetCandidateObjectData"));

	ARCandidateObject_GetCandidateObjectData_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AugmentedReality.ARCandidateObject.GetBoundingBox
// (Final, Native, Public, HasDefaults, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FBox                    ReturnValue_69                 (ConstParm, Parm, OutParm, ZeroConstructor, ReturnParm, ReferenceParm, IsPlainOldData)

struct FBox ARCandidateObject::GetBoundingBox()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AugmentedReality.ARCandidateObject.GetBoundingBox"));

	ARCandidateObject_GetBoundingBox_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function AssetRegistry.AssetRegistryHelpers.ToSoftObjectPath
struct AssetRegistryHelpers_ToSoftObjectPath_Params
{
	struct FAssetData                                  InAssetData_69;                                           // (ConstParm, Parm, OutParm, ReferenceParm)
	struct FSoftObjectPath                             ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function AssetRegistry.AssetRegistryHelpers.SetFilterTagsAndValues
struct AssetRegistryHelpers_SetFilterTagsAndValues_Params
{
	struct FARFilter                                   InFilter_69;                                              // (ConstParm, Parm, OutParm, ReferenceParm)
	TArray<struct FTagAndValue>                        InTagsAndValues_69;                                       // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	struct FARFilter                                   ReturnValue_69;                                           // (Parm, OutParm, ReturnParm)
};

// Function AssetRegistry.AssetRegistryHelpers.IsValid
struct AssetRegistryHelpers_IsValid_Params
{
	struct FAssetData                                  InAssetData_69;                                           // (ConstParm, Parm, OutParm, ReferenceParm)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AssetRegistry.AssetRegistryHelpers.IsUAsset
struct AssetRegistryHelpers_IsUAsset_Params
{
	struct FAssetData                                  InAssetData_69;                                           // (ConstParm, Parm, OutParm, ReferenceParm)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AssetRegistry.AssetRegistryHelpers.IsRedirector
struct AssetRegistryHelpers_IsRedirector_Params
{
	struct FAssetData                                  InAssetData_69;                                           // (ConstParm, Parm, OutParm, ReferenceParm)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AssetRegistry.AssetRegistryHelpers.IsAssetLoaded
struct AssetRegistryHelpers_IsAssetLoaded_Params
{
	struct FAssetData                                  InAssetData_69;                                           // (ConstParm, Parm, OutParm, ReferenceParm)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AssetRegistry.AssetRegistryHelpers.GetTagValue
struct AssetRegistryHelpers_GetTagValue_Params
{
	struct FAssetData                                  InAssetData_69;                                           // (ConstParm, Parm, OutParm, ReferenceParm)
	struct FName                                       InTagName_69;                                             // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
	struct FString                                     OutTagValue_69;                                           // (Parm, OutParm, ZeroConstructor)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AssetRegistry.AssetRegistryHelpers.GetFullName
struct AssetRegistryHelpers_GetFullName_Params
{
	struct FAssetData                                  InAssetData_69;                                           // (ConstParm, Parm, OutParm, ReferenceParm)
	struct FString                                     ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function AssetRegistry.AssetRegistryHelpers.GetExportTextName
struct AssetRegistryHelpers_GetExportTextName_Params
{
	struct FAssetData                                  InAssetData_69;                                           // (ConstParm, Parm, OutParm, ReferenceParm)
	struct FString                                     ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function AssetRegistry.AssetRegistryHelpers.GetClass
struct AssetRegistryHelpers_GetClass_Params
{
	struct FAssetData                                  InAssetData_69;                                           // (ConstParm, Parm, OutParm, ReferenceParm)
	class Object_32759*                                ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function AssetRegistry.AssetRegistryHelpers.GetAssetRegistry
struct AssetRegistryHelpers_GetAssetRegistry_Params
{
	TScriptInterface<class AssetRegistry>              ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AssetRegistry.AssetRegistryHelpers.GetAsset
struct AssetRegistryHelpers_GetAsset_Params
{
	struct FAssetData                                  InAssetData_69;                                           // (ConstParm, Parm, OutParm, ReferenceParm)
	class Object_32759*                                ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function AssetRegistry.AssetRegistryHelpers.CreateAssetData
struct AssetRegistryHelpers_CreateAssetData_Params
{
	class Object_32759*                                InAsset_69;                                               // (ConstParm, Parm, ZeroConstructor)
	bool                                               bAllowBlueprintClass_69;                                  // (Parm, ZeroConstructor, IsPlainOldData)
	struct FAssetData                                  ReturnValue_69;                                           // (Parm, OutParm, ReturnParm)
};

// Function AssetRegistry.AssetRegistry.WaitForPackage
struct AssetRegistry_WaitForPackage_Params
{
	struct FString                                     PackageName_69;                                           // (Parm, ZeroConstructor)
};

// Function AssetRegistry.AssetRegistry.WaitForCompletion
struct AssetRegistry_WaitForCompletion_Params
{
};

// Function AssetRegistry.AssetRegistry.UseFilterToExcludeAssets
struct AssetRegistry_UseFilterToExcludeAssets_Params
{
	TArray<struct FAssetData>                          AssetDataList_69;                                         // (Parm, OutParm, ZeroConstructor, ReferenceParm)
	struct FARFilter                                   Filter_69;                                                // (ConstParm, Parm, OutParm, ReferenceParm)
};

// Function AssetRegistry.AssetRegistry.SearchAllAssets
struct AssetRegistry_SearchAllAssets_Params
{
	bool                                               bSynchronousSearch_69;                                    // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function AssetRegistry.AssetRegistry.ScanPathsSynchronous
struct AssetRegistry_ScanPathsSynchronous_Params
{
	TArray<struct FString>                             InPaths_69;                                               // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	bool                                               bForceRescan_69;                                          // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bIgnoreDenyListScanFilters_69;                            // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function AssetRegistry.AssetRegistry.ScanModifiedAssetFiles
struct AssetRegistry_ScanModifiedAssetFiles_Params
{
	TArray<struct FString>                             InFilePaths_69;                                           // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
};

// Function AssetRegistry.AssetRegistry.ScanFilesSynchronous
struct AssetRegistry_ScanFilesSynchronous_Params
{
	TArray<struct FString>                             InFilePaths_69;                                           // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	bool                                               bForceRescan_69;                                          // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function AssetRegistry.AssetRegistry.RunAssetsThroughFilter
struct AssetRegistry_RunAssetsThroughFilter_Params
{
	TArray<struct FAssetData>                          AssetDataList_69;                                         // (Parm, OutParm, ZeroConstructor, ReferenceParm)
	struct FARFilter                                   Filter_69;                                                // (ConstParm, Parm, OutParm, ReferenceParm)
};

// Function AssetRegistry.AssetRegistry.PrioritizeSearchPath
struct AssetRegistry_PrioritizeSearchPath_Params
{
	struct FString                                     PathToPrioritize_69;                                      // (Parm, ZeroConstructor)
};

// Function AssetRegistry.AssetRegistry.K2_GetReferencers
struct AssetRegistry_K2_GetReferencers_Params
{
	struct FName                                       PackageName_69;                                           // (Parm, ZeroConstructor, IsPlainOldData)
	struct FAssetRegistryDependencyOptions             ReferenceOptions_69;                                      // (ConstParm, Parm, OutParm, ReferenceParm)
	TArray<struct FName>                               OutReferencers_69;                                        // (Parm, OutParm, ZeroConstructor)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AssetRegistry.AssetRegistry.K2_GetDependencies
struct AssetRegistry_K2_GetDependencies_Params
{
	struct FName                                       PackageName_69;                                           // (Parm, ZeroConstructor, IsPlainOldData)
	struct FAssetRegistryDependencyOptions             DependencyOptions_69;                                     // (ConstParm, Parm, OutParm, ReferenceParm)
	TArray<struct FName>                               OutDependencies_69;                                       // (Parm, OutParm, ZeroConstructor)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AssetRegistry.AssetRegistry.IsSearchAsync
struct AssetRegistry_IsSearchAsync_Params
{
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AssetRegistry.AssetRegistry.IsSearchAllAssets
struct AssetRegistry_IsSearchAllAssets_Params
{
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AssetRegistry.AssetRegistry.IsLoadingAssets
struct AssetRegistry_IsLoadingAssets_Params
{
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AssetRegistry.AssetRegistry.HasAssets
struct AssetRegistry_HasAssets_Params
{
	struct FName                                       PackagePath_69;                                           // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bRecursive_69;                                            // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AssetRegistry.AssetRegistry.GetSubPaths
struct AssetRegistry_GetSubPaths_Params
{
	struct FString                                     InBasePath_69;                                            // (Parm, ZeroConstructor)
	TArray<struct FString>                             OutPathList_69;                                           // (Parm, OutParm, ZeroConstructor)
	bool                                               bInRecurse_69;                                            // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function AssetRegistry.AssetRegistry.GetAssetsByPaths
struct AssetRegistry_GetAssetsByPaths_Params
{
	TArray<struct FName>                               PackagePaths_69;                                          // (Parm, ZeroConstructor)
	TArray<struct FAssetData>                          OutAssetData_69;                                          // (Parm, OutParm, ZeroConstructor)
	bool                                               bRecursive_69;                                            // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bIncludeOnlyOnDiskAssets_69;                              // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AssetRegistry.AssetRegistry.GetAssetsByPath
struct AssetRegistry_GetAssetsByPath_Params
{
	struct FName                                       PackagePath_69;                                           // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<struct FAssetData>                          OutAssetData_69;                                          // (Parm, OutParm, ZeroConstructor)
	bool                                               bRecursive_69;                                            // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bIncludeOnlyOnDiskAssets_69;                              // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AssetRegistry.AssetRegistry.GetAssetsByPackageName
struct AssetRegistry_GetAssetsByPackageName_Params
{
	struct FName                                       PackageName_69;                                           // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<struct FAssetData>                          OutAssetData_69;                                          // (Parm, OutParm, ZeroConstructor)
	bool                                               bIncludeOnlyOnDiskAssets_69;                              // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AssetRegistry.AssetRegistry.GetAssetsByClass
struct AssetRegistry_GetAssetsByClass_Params
{
	struct FTopLevelAssetPath                          ClassPathName_69;                                         // (Parm)
	TArray<struct FAssetData>                          OutAssetData_69;                                          // (Parm, OutParm, ZeroConstructor)
	bool                                               bSearchSubClasses_69;                                     // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AssetRegistry.AssetRegistry.GetAssets
struct AssetRegistry_GetAssets_Params
{
	struct FARFilter                                   Filter_69;                                                // (ConstParm, Parm, OutParm, ReferenceParm)
	TArray<struct FAssetData>                          OutAssetData_69;                                          // (Parm, OutParm, ZeroConstructor)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AssetRegistry.AssetRegistry.GetAssetByObjectPath
struct AssetRegistry_GetAssetByObjectPath_Params
{
	struct FName                                       ObjectPath_69;                                            // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bIncludeOnlyOnDiskAssets_69;                              // (Parm, ZeroConstructor, IsPlainOldData)
	struct FAssetData                                  ReturnValue_69;                                           // (Parm, OutParm, ReturnParm)
};

// Function AssetRegistry.AssetRegistry.GetAllCachedPaths
struct AssetRegistry_GetAllCachedPaths_Params
{
	TArray<struct FString>                             OutPathList_69;                                           // (Parm, OutParm, ZeroConstructor)
};

// Function AssetRegistry.AssetRegistry.GetAllAssets
struct AssetRegistry_GetAllAssets_Params
{
	TArray<struct FAssetData>                          OutAssetData_69;                                          // (Parm, OutParm, ZeroConstructor)
	bool                                               bIncludeOnlyOnDiskAssets_69;                              // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

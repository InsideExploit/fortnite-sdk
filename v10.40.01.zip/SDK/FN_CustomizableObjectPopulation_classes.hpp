#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Classes
//---------------------------------------------------------------------------

// Class CustomizableObjectPopulation.CustomizableObjectPopulation
// 0x0028 (0x0050 - 0x0028)
class CustomizableObjectPopulation : public Object_32759
{
public:
	struct FString                                     Name_69;                                                  // 0x0028(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
	TArray<struct FClassWeightPair>                    ClassWeights_69;                                          // 0x0038(0x0010) (Edit, ZeroConstructor)
	class CustomizableObjectPopulationGenerator*       Generator_69;                                             // 0x0048(0x0008) (ZeroConstructor)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CustomizableObjectPopulation.CustomizableObjectPopulation"));
		
		return ptr;
	}


	bool RegeneratePopulation(int Seed_69, int NumInstancesToGenerate_69, TArray<class CustomizableObjectInstance*>* OutInstances_69);
	int GeneratePopulation(int NumInstancesToGenerate_69, TArray<class CustomizableObjectInstance*>* OutInstances_69);
};


// Class CustomizableObjectPopulation.CustomizableObjectPopulationClass
// 0x0068 (0x0090 - 0x0028)
class CustomizableObjectPopulationClass : public Object_32759
{
public:
	struct FString                                     Name_69;                                                  // 0x0028(0x0010) (Edit, ZeroConstructor)
	class CustomizableObject*                          CustomizableObject_69;                                    // 0x0038(0x0008) (Edit, ZeroConstructor)
	TArray<struct FString>                             Allowlist_69;                                             // 0x0040(0x0010) (Edit, ZeroConstructor)
	TArray<struct FString>                             Blocklist_69;                                             // 0x0050(0x0010) (Edit, ZeroConstructor)
	TArray<struct FCustomizableObjectPopulationCharacteristic> Characteristics_69;                                       // 0x0060(0x0010) (Edit, ZeroConstructor)
	TArray<struct FString>                             Tags_69;                                                  // 0x0070(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData00[0x10];                                      // 0x0080(0x0010) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CustomizableObjectPopulation.CustomizableObjectPopulationClass"));
		
		return ptr;
	}

};


// Class CustomizableObjectPopulation.CustomizableObjectPopulationGenerator
// 0x0020 (0x0048 - 0x0028)
class CustomizableObjectPopulationGenerator : public Object_32759
{
public:
	TArray<class CustomizableObject*>                  PopulationObjects_69;                                     // 0x0028(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData00[0x10];                                      // 0x0038(0x0010) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CustomizableObjectPopulation.CustomizableObjectPopulationGenerator"));
		
		return ptr;
	}

};


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

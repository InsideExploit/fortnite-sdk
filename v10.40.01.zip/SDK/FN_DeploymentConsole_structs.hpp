#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Script Structs
//---------------------------------------------------------------------------

// ScriptStruct DeploymentConsole.DeploymentConsoleAircraftData
// 0x0010
struct FDeploymentConsoleAircraftData
{
	unsigned char                                      Team_69;                                                  // 0x0000(0x0001) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0001(0x0007) MISSED OFFSET
	class FortAthenaAircraft*                          Aircraft_69;                                              // 0x0008(0x0008) (BlueprintVisible, ZeroConstructor)
};

// ScriptStruct DeploymentConsole.DeploymentConsoleTeamData
// 0x0018
struct FDeploymentConsoleTeamData
{
	unsigned char                                      Team_69;                                                  // 0x0000(0x0001) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0001(0x0007) MISSED OFFSET
	TArray<struct FVector2D>                           SpawnLocations_69;                                        // 0x0008(0x0010) (BlueprintVisible, ZeroConstructor)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

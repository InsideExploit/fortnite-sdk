#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Classes
//---------------------------------------------------------------------------

// Class BuildPatchServices.BuildPatchManifest
// 0x00F8 (0x0120 - 0x0028)
class BuildPatchManifest : public Object_32759
{
public:
	unsigned char                                      ManifestFileVersion_69;                                   // 0x0028(0x0001) (ZeroConstructor, IsPlainOldData)
	bool                                               bIsFileData_69;                                           // 0x0029(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x2];                                       // 0x002A(0x0002) MISSED OFFSET
	uint32_t                                           AppID_69;                                                 // 0x002C(0x0004) (ZeroConstructor, IsPlainOldData)
	struct FString                                     AppName_69;                                               // 0x0030(0x0010) (ZeroConstructor)
	struct FString                                     BuildVersion_69;                                          // 0x0040(0x0010) (ZeroConstructor)
	struct FString                                     LaunchExe_69;                                             // 0x0050(0x0010) (ZeroConstructor)
	struct FString                                     LaunchCommand_69;                                         // 0x0060(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData01[0x50];                                      // 0x0070(0x0050) UNKNOWN PROPERTY: SetProperty BuildPatchServices.BuildPatchManifest.PrereqIds_69
	struct FString                                     PrereqName_69;                                            // 0x00C0(0x0010) (ZeroConstructor)
	struct FString                                     PrereqPath_69;                                            // 0x00D0(0x0010) (ZeroConstructor)
	struct FString                                     PrereqArgs_69;                                            // 0x00E0(0x0010) (ZeroConstructor)
	TArray<struct FFileManifestData>                   FileManifestList_69;                                      // 0x00F0(0x0010) (ZeroConstructor)
	TArray<struct FChunkInfoData>                      ChunkList_69;                                             // 0x0100(0x0010) (ZeroConstructor)
	TArray<struct FCustomFieldData>                    CustomFields_69;                                          // 0x0110(0x0010) (ZeroConstructor)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class BuildPatchServices.BuildPatchManifest"));
		
		return ptr;
	}

};


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Script Structs
//---------------------------------------------------------------------------

// ScriptStruct CurveExpression.AnimNode_RemapCurvesFromMesh
// 0x0190 (0x01A0 - 0x0010)
struct FAnimNode_RemapCurvesFromMesh : public FAnimNode_Base
{
	struct FPoseLink                                   SourcePose_69;                                            // 0x0010(0x0010) (Edit, BlueprintVisible, EditFixedSize)
	TWeakObjectPtr<class SkeletalMeshComponent>        SourceMeshComponent_69;                                   // 0x0020(0x0008) (BlueprintVisible, ExportObject, ZeroConstructor, Transient, InstancedReference, IsPlainOldData)
	bool                                               bUseAttachedParent_69;                                    // 0x0028(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0029(0x0007) MISSED OFFSET
	TMap<struct FName, struct FString>                 CurveExpressions_69;                                      // 0x0030(0x0050) (Edit, BlueprintVisible, EditFixedSize)
	bool                                               bExpressionsImmutable_69;                                 // 0x0080(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x11F];                                     // 0x0081(0x011F) MISSED OFFSET
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

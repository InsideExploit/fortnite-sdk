#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Classes
//---------------------------------------------------------------------------

// Class DataDrivenGameplayEventRouter.GameplayEventLegacyBroadcast
// 0x0000 (0x0028 - 0x0028)
class GameplayEventLegacyBroadcast : public Interface
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class DataDrivenGameplayEventRouter.GameplayEventLegacyBroadcast"));
		
		return ptr;
	}

};


// Class DataDrivenGameplayEventRouter.GameplayEventDescriptorLibrary
// 0x0000 (0x0028 - 0x0028)
class GameplayEventDescriptorLibrary : public BlueprintFunctionLibrary
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class DataDrivenGameplayEventRouter.GameplayEventDescriptorLibrary"));
		
		return ptr;
	}


	bool STATIC_BroadcastEvent(const struct FGameplayEventDescriptor& EventDescriptor_69, class Object_32759* EventContext_69, int Event_69, class Object_32759* EventRouterScope_69, class Actor_32759* RouterContextActor_69);
};


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

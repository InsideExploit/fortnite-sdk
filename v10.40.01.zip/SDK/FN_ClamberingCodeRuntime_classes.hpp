#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Classes
//---------------------------------------------------------------------------

// Class ClamberingCodeRuntime.ClamberingAnalytics
// 0x0000 (0x0028 - 0x0028)
class ClamberingAnalytics : public Object_32759
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class ClamberingCodeRuntime.ClamberingAnalytics"));
		
		return ptr;
	}

};


// Class ClamberingCodeRuntime.ClamberingComponent
// 0x0988 (0x0A28 - 0x00A0)
class ClamberingComponent : public FortPawnComponent
{
public:
	unsigned char                                      UnknownData00[0x8];                                       // 0x00A0(0x0008) MISSED OFFSET
	EClamberingState                                   LocalClamberingState_69;                                  // 0x00A8(0x0001) (ZeroConstructor, Transient, IsPlainOldData)
	EClamberingState                                   ReplicatedClamberingState_69;                             // 0x00A9(0x0001) (Net, ZeroConstructor, Transient, IsPlainOldData)
	unsigned char                                      UnknownData01[0x6];                                       // 0x00AA(0x0006) MISSED OFFSET
	struct FClamberingTargetingData                    LockedTargetingData_69;                                   // 0x00B0(0x00D0) (BlueprintVisible, BlueprintReadOnly, Transient)
	struct FReplicatedClamberingTargetingData_SimClient ReplicatedTargetingData_69;                               // 0x0180(0x0038) (Net, Transient)
	unsigned char                                      UnknownData02[0x8];                                       // 0x01B8(0x0008) MISSED OFFSET
	struct FScalableFloat                              ClamberingEnabled_69;                                     // 0x01C0(0x0028) (Edit, Config, DisableEditOnInstance)
	struct FScalableFloat                              ClamberIndicatorEnabled_69;                               // 0x01E8(0x0028) (Edit, Config, DisableEditOnInstance)
	struct FScalableFloat                              ClamberStartMaxFallingDamageFraction_69;                  // 0x0210(0x0028) (Edit, Config, DisableEditOnInstance)
	bool                                               bPerformTargetingWhileWalking_69;                         // 0x0238(0x0001) (Edit, ZeroConstructor, Config, DisableEditOnInstance, IsPlainOldData)
	bool                                               bPerformTargetingWhileSwimming_69;                        // 0x0239(0x0001) (Edit, ZeroConstructor, Config, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData03[0x6];                                       // 0x023A(0x0006) MISSED OFFSET
	struct FScalableFloat                              ServerFailDelay_69;                                       // 0x0240(0x0028) (Edit, Config, DisableEditOnInstance)
	struct FScalableFloat                              ServerValidatePlayerMaxDistance_69;                       // 0x0268(0x0028) (Edit, Config, DisableEditOnInstance)
	struct FClamberingInputConfig                      InputConfig_69;                                           // 0x0290(0x0210) (Edit, BlueprintVisible, BlueprintReadOnly, Config, DisableEditOnInstance)
	struct FClamberingTargetingConfig_Ledge            TargetingConfig_Ledge_69;                                 // 0x04A0(0x02A8) (Edit, BlueprintVisible, BlueprintReadOnly, Config, DisableEditOnInstance)
	struct FClamberingTargetingConfig_Ledge_CachedContextualValues TargetingConfig_Ledge_CachedContextualValues_69;          // 0x0748(0x0008) (ZeroConstructor, Transient, IsPlainOldData)
	struct FClamberingMovementConfig_Ledge             MoveConfig_Ledge_69;                                      // 0x0750(0x0050) (Edit, BlueprintVisible, BlueprintReadOnly, Config, DisableEditOnInstance)
	struct FScalableFloat                              ClamberSyncTargetLedgeOffset_69;                          // 0x07A0(0x0028) (Edit, BlueprintVisible, BlueprintReadOnly, DisableEditOnInstance)
	struct FScalableFloat                              ClamberingMaxAnalyticsEvents_69;                          // 0x07C8(0x0028) (Edit, BlueprintVisible, BlueprintReadOnly, DisableEditOnInstance)
	struct FScalableFloat                              SynchedActionFailDelay_69;                                // 0x07F0(0x0028) (Edit, Config, DisableEditOnInstance)
	bool                                               bTutorialModeEnabled_69;                                  // 0x0818(0x0001) (ZeroConstructor, Transient, IsPlainOldData)
	unsigned char                                      UnknownData04[0x7];                                       // 0x0819(0x0007) MISSED OFFSET
	struct FClamberingTargetingData                    LocalTargetingData_69;                                    // 0x0820(0x00D0) (Transient)
	struct FClamberingTargetingData                    ParallelTargetingData_69;                                 // 0x08F0(0x00D0) (Transient)
	float                                              QueuedInputTimer_69;                                      // 0x09C0(0x0004) (ZeroConstructor, Transient, IsPlainOldData)
	float                                              InputEnabledTimer_69;                                     // 0x09C4(0x0004) (ZeroConstructor, Transient, IsPlainOldData)
	bool                                               bJumpInputPressed_69;                                     // 0x09C8(0x0001) (ZeroConstructor, Transient, IsPlainOldData)
	unsigned char                                      UnknownData05[0x3];                                       // 0x09C9(0x0003) MISSED OFFSET
	float                                              JumpHeldInAirTime_69;                                     // 0x09CC(0x0004) (ZeroConstructor, Transient, IsPlainOldData)
	unsigned char                                      UnknownData06[0x50];                                      // 0x09D0(0x0050) MISSED OFFSET
	struct FGameplayTag                                Tag_DisableClambering_69;                                 // 0x0A20(0x0004) (Edit)
	unsigned char                                      UnknownData07[0x4];                                       // 0x0A24(0x0004) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class ClamberingCodeRuntime.ClamberingComponent"));
		
		return ptr;
	}


	void UnregisterMutatorUpdatedDelegate();
	bool ShouldShowClamberIndicator();
	void SetTutorialModeEnabled(bool bEnabled_69);
	void ServerStartClambering(const struct FReplicatedClamberingTargetingData& InReplicatedTargetingData_69);
	void RegisterMutatorUpdatedDelegate(class Pawn* AffectedPawn_69);
	void OnRep_ReplicatedTargetingData();
	void OnRep_ReplicatedClamberingState();
	void OnPlayerStatePawnSet(class PlayerState* Player_69, class Pawn* NewPawn_69, class Pawn* OldPawn_69);
	void OnMutatorUpdated();
	void NetMulticast_ClamberingLedgeFailed(EClamberingFailedReason FailedReason_69, EClamberingState FailedState_69);
	bool IsTutorialModeEnabled();
	bool IsClamberingEnabled();
	bool IsAutoClamberingEnabled();
	void HandleTargetingDataValid(const struct FClamberingTargetingData& TargetingData_69);
	void HandleTargetingDataInvalid();
	void HandleTargetActorHealthChanged();
	void HandleTargetActorDestroyed(class Actor_32759* Actor_69);
	void HandleOwnerMovementModeChanged(class Character* Character_69, TEnumAsByte<EMovementMode> PreviousMovementMode_69, unsigned char PreviousCustomMode_69);
	void HandleOwnerJumpInput(bool bPressed_69);
	void HandleOwnerDied(class FortPawn* DeadPawn_69);
	void HandleOwnerDBNO();
	void HandleOwnerASCInvalidated();
	void HandleOwnerASCInitialized(class FortAbilitySystemComponent* AbilitySystemComponent_69, class FortPlayerPawn* AffectedPawn_69);
	void HandleClamberingTargetOutOfActivationRange();
	void HandleClamberingTargetInActivationRange();
	void DrawDebugHUD(class HUD_32759* HUD_69, class Canvas* Canvas_69);
	void BP_TutorialModeEnabled();
	void BP_TutorialModeDisabled();
	void BP_IsValidTargetActor(class Actor_32759* TargetActor_69, bool* bIsValidTargetActor_69);
	void BP_HandleSynchedActionStarted(const struct FSynchedActionInfo& SynchedActionInfo_69);
	void BP_HandleClamberingStateChanged(EClamberingState OldClamberingState_69, EClamberingState NewClamberingState_69);
	void BP_CanStartTargeting(bool* bCanStartTargeting_69);
	void BP_CanStartClambering(bool* bCanStartClambering_69);
};


// Class ClamberingCodeRuntime.ClamberingLibrary
// 0x0000 (0x0028 - 0x0028)
class ClamberingLibrary : public BlueprintFunctionLibrary
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class ClamberingCodeRuntime.ClamberingLibrary"));
		
		return ptr;
	}


	bool STATIC_PerformClamberingTargeting(class Character* Character_69, struct FClamberingTargetingData* OutTargetingData_69);
};


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

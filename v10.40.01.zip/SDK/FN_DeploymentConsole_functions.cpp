// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Functions
//---------------------------------------------------------------------------

// Function DeploymentConsole.DeploymentConsoleComponent.SpawnAircrafts
// (Final, BlueprintAuthorityOnly, Native, Public, BlueprintCallable)
// Parameters:
// bool                           bSpawnAircraftForEachTeam_69   (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// TArray<struct FDeploymentConsoleAircraftData> ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

TArray<struct FDeploymentConsoleAircraftData> DeploymentConsoleComponent::SpawnAircrafts(bool bSpawnAircraftForEachTeam_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DeploymentConsole.DeploymentConsoleComponent.SpawnAircrafts"));

	DeploymentConsoleComponent_SpawnAircrafts_Params params;
	params.bSpawnAircraftForEachTeam_69 = bSpawnAircraftForEachTeam_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function DeploymentConsole.DeploymentConsoleComponent.SpawnAircraft
// (Final, BlueprintAuthorityOnly, Native, Public, BlueprintCallable)
// Parameters:
// int                            FlightIndex_69                 (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// class FortAthenaAircraft*      ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

class FortAthenaAircraft* DeploymentConsoleComponent::SpawnAircraft(int FlightIndex_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DeploymentConsole.DeploymentConsoleComponent.SpawnAircraft"));

	DeploymentConsoleComponent_SpawnAircraft_Params params;
	params.FlightIndex_69 = FlightIndex_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function DeploymentConsole.DeploymentConsoleComponent.SetupTeamSpawnPoints
// (Final, BlueprintAuthorityOnly, Native, Public, BlueprintCallable)
// Parameters:
// bool                           bGroupTeams_69                 (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void DeploymentConsoleComponent::SetupTeamSpawnPoints(bool bGroupTeams_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DeploymentConsole.DeploymentConsoleComponent.SetupTeamSpawnPoints"));

	DeploymentConsoleComponent_SetupTeamSpawnPoints_Params params;
	params.bGroupTeams_69 = bGroupTeams_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function DeploymentConsole.DeploymentConsoleComponent.SetAircraftLock
// (Final, BlueprintAuthorityOnly, Native, Public, BlueprintCallable)
// Parameters:
// bool                           bIsLocked_69                   (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void DeploymentConsoleComponent::SetAircraftLock(bool bIsLocked_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DeploymentConsole.DeploymentConsoleComponent.SetAircraftLock"));

	DeploymentConsoleComponent_SetAircraftLock_Params params;
	params.bIsLocked_69 = bIsLocked_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function DeploymentConsole.DeploymentConsoleComponent.SetAircraftDropZone
// (Final, BlueprintAuthorityOnly, Native, Public, HasOutParms, HasDefaults, BlueprintCallable)
// Parameters:
// struct FBox2D                  InDropZone_69                  (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)

void DeploymentConsoleComponent::SetAircraftDropZone(const struct FBox2D& InDropZone_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DeploymentConsole.DeploymentConsoleComponent.SetAircraftDropZone"));

	DeploymentConsoleComponent_SetAircraftDropZone_Params params;
	params.InDropZone_69 = InDropZone_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function DeploymentConsole.DeploymentConsoleComponent.RetrievePlayerSpawnLocation
// (Final, BlueprintAuthorityOnly, Native, Public, HasDefaults, BlueprintCallable)
// Parameters:
// bool                           bIsGameInProgress_69           (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// bool                           bGroupTeams_69                 (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// unsigned char                  InTeam_69                      (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// struct FVector2D               ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

struct FVector2D DeploymentConsoleComponent::RetrievePlayerSpawnLocation(bool bIsGameInProgress_69, bool bGroupTeams_69, unsigned char InTeam_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DeploymentConsole.DeploymentConsoleComponent.RetrievePlayerSpawnLocation"));

	DeploymentConsoleComponent_RetrievePlayerSpawnLocation_Params params;
	params.bIsGameInProgress_69 = bIsGameInProgress_69;
	params.bGroupTeams_69 = bGroupTeams_69;
	params.InTeam_69 = InTeam_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function DeploymentConsole.DeploymentConsoleComponent.MoveBoxTo
// (Final, Native, Static, Public, HasOutParms, HasDefaults, BlueprintCallable, BlueprintPure)
// Parameters:
// struct FBox2D                  InBox_69                       (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
// struct FVector2D               VectorToMoveTo_69              (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
// struct FBox2D                  ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

struct FBox2D DeploymentConsoleComponent::STATIC_MoveBoxTo(const struct FBox2D& InBox_69, const struct FVector2D& VectorToMoveTo_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DeploymentConsole.DeploymentConsoleComponent.MoveBoxTo"));

	DeploymentConsoleComponent_MoveBoxTo_Params params;
	params.InBox_69 = InBox_69;
	params.VectorToMoveTo_69 = VectorToMoveTo_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function DeploymentConsole.DeploymentConsoleComponent.InitializeFlightPath
// (Final, BlueprintAuthorityOnly, Native, Public, HasOutParms, BlueprintCallable)
// Parameters:
// class FortGameStateAthena*     GSA_69                         (Parm, ZeroConstructor)
// struct FAircraftFlightConstructionInfo FlightPathConstructionInfo_69  (ConstParm, Parm, OutParm, ReferenceParm)

void DeploymentConsoleComponent::InitializeFlightPath(class FortGameStateAthena* GSA_69, const struct FAircraftFlightConstructionInfo& FlightPathConstructionInfo_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DeploymentConsole.DeploymentConsoleComponent.InitializeFlightPath"));

	DeploymentConsoleComponent_InitializeFlightPath_Params params;
	params.GSA_69 = GSA_69;
	params.FlightPathConstructionInfo_69 = FlightPathConstructionInfo_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function DeploymentConsole.DeploymentConsoleComponent.GetTeamSpawnData
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// TArray<struct FDeploymentConsoleTeamData> ReturnValue_69                 (ConstParm, Parm, OutParm, ZeroConstructor, ReturnParm, ReferenceParm)

TArray<struct FDeploymentConsoleTeamData> DeploymentConsoleComponent::GetTeamSpawnData()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DeploymentConsole.DeploymentConsoleComponent.GetTeamSpawnData"));

	DeploymentConsoleComponent_GetTeamSpawnData_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function DeploymentConsole.DeploymentConsoleComponent.GetSpawnPoints
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// TArray<struct FVector2D>       ReturnValue_69                 (ConstParm, Parm, OutParm, ZeroConstructor, ReturnParm, ReferenceParm)

TArray<struct FVector2D> DeploymentConsoleComponent::GetSpawnPoints()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DeploymentConsole.DeploymentConsoleComponent.GetSpawnPoints"));

	DeploymentConsoleComponent_GetSpawnPoints_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function DeploymentConsole.DeploymentConsoleComponent.GetMinigameTeamsWithPlayers
// (Final, Native, Static, Public, BlueprintCallable, BlueprintPure)
// Parameters:
// class FortMinigame*            InMinigame_69                  (ConstParm, Parm, ZeroConstructor)
// TArray<unsigned char>          ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

TArray<unsigned char> DeploymentConsoleComponent::STATIC_GetMinigameTeamsWithPlayers(class FortMinigame* InMinigame_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DeploymentConsole.DeploymentConsoleComponent.GetMinigameTeamsWithPlayers"));

	DeploymentConsoleComponent_GetMinigameTeamsWithPlayers_Params params;
	params.InMinigame_69 = InMinigame_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function DeploymentConsole.DeploymentConsoleComponent.GetMapInfo
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// class FortAthenaMapInfo*       ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

class FortAthenaMapInfo* DeploymentConsoleComponent::GetMapInfo()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DeploymentConsole.DeploymentConsoleComponent.GetMapInfo"));

	DeploymentConsoleComponent_GetMapInfo_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function DeploymentConsole.DeploymentConsoleComponent.GetDefaultFlightPathConstructionInfo
// (Final, BlueprintAuthorityOnly, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// class FortGameStateAthena*     GameStateAthena_69             (ConstParm, Parm, ZeroConstructor)
// EAirCraftBehavior              AirCraftBehavior_69            (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// struct FAircraftFlightConstructionInfo ReturnValue_69                 (Parm, OutParm, ReturnParm)

struct FAircraftFlightConstructionInfo DeploymentConsoleComponent::GetDefaultFlightPathConstructionInfo(class FortGameStateAthena* GameStateAthena_69, EAirCraftBehavior AirCraftBehavior_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DeploymentConsole.DeploymentConsoleComponent.GetDefaultFlightPathConstructionInfo"));

	DeploymentConsoleComponent_GetDefaultFlightPathConstructionInfo_Params params;
	params.GameStateAthena_69 = GameStateAthena_69;
	params.AirCraftBehavior_69 = AirCraftBehavior_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function DeploymentConsole.DeploymentConsoleComponent.GetCachedAircraftSpawnZone
// (Final, Native, Public, HasDefaults, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FBox2D                  ReturnValue_69                 (ConstParm, Parm, OutParm, ZeroConstructor, ReturnParm, ReferenceParm, IsPlainOldData)

struct FBox2D DeploymentConsoleComponent::GetCachedAircraftSpawnZone()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DeploymentConsole.DeploymentConsoleComponent.GetCachedAircraftSpawnZone"));

	DeploymentConsoleComponent_GetCachedAircraftSpawnZone_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function DeploymentConsole.DeploymentConsoleComponent.ForcePlayerEnterAircraft
// (Final, BlueprintCosmetic, Native, Static, Public, BlueprintCallable)
// Parameters:
// class FortPlayerControllerAthena* InController_69                (Parm, ZeroConstructor)
// class FortAthenaAircraft*      InAircraft_69                  (Parm, ZeroConstructor)

void DeploymentConsoleComponent::STATIC_ForcePlayerEnterAircraft(class FortPlayerControllerAthena* InController_69, class FortAthenaAircraft* InAircraft_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DeploymentConsole.DeploymentConsoleComponent.ForcePlayerEnterAircraft"));

	DeploymentConsoleComponent_ForcePlayerEnterAircraft_Params params;
	params.InController_69 = InController_69;
	params.InAircraft_69 = InAircraft_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function DeploymentConsole.DeploymentConsoleComponent.ConstructInventoryOnController
// (Final, BlueprintAuthorityOnly, Native, Public, BlueprintCallable)
// Parameters:
// class FortPlayerControllerAthena* InController_69                (Parm, ZeroConstructor)

void DeploymentConsoleComponent::ConstructInventoryOnController(class FortPlayerControllerAthena* InController_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DeploymentConsole.DeploymentConsoleComponent.ConstructInventoryOnController"));

	DeploymentConsoleComponent_ConstructInventoryOnController_Params params;
	params.InController_69 = InController_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function DeploymentConsole.DeploymentConsoleComponent.ClearFlightInfos
// (Final, BlueprintAuthorityOnly, Native, Public, BlueprintCallable, Const)

void DeploymentConsoleComponent::ClearFlightInfos()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DeploymentConsole.DeploymentConsoleComponent.ClearFlightInfos"));

	DeploymentConsoleComponent_ClearFlightInfos_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function DeploymentConsole.DeploymentConsoleComponent.CalculateSpawnRotationFromLocation
// (Final, Native, Public, HasOutParms, HasDefaults, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FVector                 InSpawnLocation_69             (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
// struct FRotator                ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

struct FRotator DeploymentConsoleComponent::CalculateSpawnRotationFromLocation(const struct FVector& InSpawnLocation_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DeploymentConsole.DeploymentConsoleComponent.CalculateSpawnRotationFromLocation"));

	DeploymentConsoleComponent_CalculateSpawnRotationFromLocation_Params params;
	params.InSpawnLocation_69 = InSpawnLocation_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function DeploymentConsole.DeploymentConsoleComponent.AdjustLocationToValidHeight
// (Final, Native, Public, HasOutParms, HasDefaults, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FVector                 RespawnLocation_69             (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
// struct FVector                 ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

struct FVector DeploymentConsoleComponent::AdjustLocationToValidHeight(const struct FVector& RespawnLocation_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function DeploymentConsole.DeploymentConsoleComponent.AdjustLocationToValidHeight"));

	DeploymentConsoleComponent_AdjustLocationToValidHeight_Params params;
	params.RespawnLocation_69 = RespawnLocation_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

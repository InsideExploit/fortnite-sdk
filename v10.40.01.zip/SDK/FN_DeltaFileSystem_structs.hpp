#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Script Structs
//---------------------------------------------------------------------------

// ScriptStruct DeltaFileSystem.DeltaTrackingHandles
// 0x0020
struct FDeltaTrackingHandles
{
	unsigned char                                      UnknownData00[0x10];                                      // 0x0000(0x0010) MISSED OFFSET
	unsigned char                                      UnknownData01[0x10];                                      // 0x0000(0x0010) UNKNOWN PROPERTY: ArrayProperty DeltaFileSystem.DeltaTrackingHandles.AllowedClasses_69
};

// ScriptStruct DeltaFileSystem.DeltaAction
// 0x0020
struct FDeltaAction
{
	struct FGuid                                       ActorGUID_69;                                             // 0x0000(0x0010) (ZeroConstructor, IsPlainOldData)
	struct FDateTime                                   CommitTime_69;                                            // 0x0010(0x0008) (ZeroConstructor)
	uint32_t                                           DataHash_69;                                              // 0x0018(0x0004) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x001C(0x0004) MISSED OFFSET
};

// ScriptStruct DeltaFileSystem.AddAction
// 0x00A0 (0x00C0 - 0x0020)
struct FAddAction : public FDeltaAction
{
	unsigned char                                      UnknownData00[0x28];                                      // 0x0020(0x0028) UNKNOWN PROPERTY: SoftClassProperty DeltaFileSystem.AddAction.ActorClass_69
	struct FString                                     JsonStringObjectForPropertyData_69;                       // 0x0048(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData01[0x8];                                       // 0x0058(0x0008) MISSED OFFSET
	struct FCoreUObject_FTransform                     Transform_69;                                             // 0x0060(0x0060) (IsPlainOldData)
};

// ScriptStruct DeltaFileSystem.UpdateAction
// 0x0010 (0x0030 - 0x0020)
struct FUpdateAction : public FDeltaAction
{
	struct FString                                     JsonStringObjectForPropertyData_69;                       // 0x0020(0x0010) (ZeroConstructor)
};

// ScriptStruct DeltaFileSystem.DeleteAction
// 0x0070 (0x0090 - 0x0020)
struct FDeleteAction : public FDeltaAction
{
	struct FString                                     ActorName_69;                                             // 0x0020(0x0010) (ZeroConstructor)
	struct FCoreUObject_FTransform                     Transform_69;                                             // 0x0030(0x0060) (IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

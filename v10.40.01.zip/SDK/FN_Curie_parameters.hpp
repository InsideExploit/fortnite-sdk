#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function Curie.CurieInterface.OnCurieStateDetached_BP
struct CurieInterface_OnCurieStateDetached_BP_Params
{
	struct FCurieContainerHandle                       CurieContainerHandle_69;                                  // (ConstParm, Parm)
	struct FGameplayTag                                StateTag_69;                                              // (ConstParm, Parm)
};

// Function Curie.CurieInterface.OnCurieStateAttached_BP
struct CurieInterface_OnCurieStateAttached_BP_Params
{
	struct FCurieContainerHandle                       CurieContainerHandle_69;                                  // (ConstParm, Parm)
	struct FGameplayTag                                StateTag_69;                                              // (ConstParm, Parm)
};

// Function Curie.CurieInterface.OnCurieElementInteractEnded_BP
struct CurieInterface_OnCurieElementInteractEnded_BP_Params
{
	struct FCurieContainerHandle                       CurieContainerHandle_69;                                  // (ConstParm, Parm)
	struct FGameplayTag                                ElementTag_69;                                            // (ConstParm, Parm)
	struct FCurieInteractParamsHandle                  InteractParamsHandle_69;                                  // (ConstParm, Parm, OutParm, ReferenceParm)
};

// Function Curie.CurieInterface.OnCurieElementInteractBegun_BP
struct CurieInterface_OnCurieElementInteractBegun_BP_Params
{
	struct FCurieContainerHandle                       CurieContainerHandle_69;                                  // (ConstParm, Parm)
	struct FGameplayTag                                ElementTag_69;                                            // (ConstParm, Parm)
	struct FCurieInteractParamsHandle                  InteractParamsHandle_69;                                  // (ConstParm, Parm, OutParm, ReferenceParm)
};

// Function Curie.CurieInterface.OnCurieElementInteract_BP
struct CurieInterface_OnCurieElementInteract_BP_Params
{
	struct FCurieContainerHandle                       CurieContainerHandle_69;                                  // (ConstParm, Parm)
	struct FGameplayTag                                ElementTag_69;                                            // (ConstParm, Parm)
	struct FCurieInteractParamsHandle                  InteractParamsHandle_69;                                  // (ConstParm, Parm, OutParm, ReferenceParm)
};

// Function Curie.CurieInterface.OnCurieElementDetached_BP
struct CurieInterface_OnCurieElementDetached_BP_Params
{
	struct FCurieContainerHandle                       CurieContainerHandle_69;                                  // (ConstParm, Parm)
	struct FGameplayTag                                ElementTag_69;                                            // (ConstParm, Parm)
};

// Function Curie.CurieInterface.OnCurieElementAttached_BP
struct CurieInterface_OnCurieElementAttached_BP_Params
{
	struct FCurieContainerHandle                       CurieContainerHandle_69;                                  // (ConstParm, Parm)
	struct FGameplayTag                                ElementTag_69;                                            // (ConstParm, Parm)
};

// Function Curie.CurieInterface.OnCurieContainerReparented_BP
struct CurieInterface_OnCurieContainerReparented_BP_Params
{
	struct FCurieContainerHandle                       CurieContainerHandle_69;                                  // (ConstParm, Parm)
};

// Function Curie.CurieInterface.OnCurieContainerReleased_BP
struct CurieInterface_OnCurieContainerReleased_BP_Params
{
	struct FCurieContainerHandle                       CurieContainerHandle_69;                                  // (ConstParm, Parm)
};

// Function Curie.CurieInterface.OnCurieContainerAcquired_BP
struct CurieInterface_OnCurieContainerAcquired_BP_Params
{
	struct FCurieContainerHandle                       CurieContainerHandle_69;                                  // (ConstParm, Parm)
};

// Function Curie.CurieManager.UnbindDelegateForCurieStateDetached
struct CurieManager_UnbindDelegateForCurieStateDetached_Params
{
	class Object_32759*                                CurieOwner_69;                                            // (Parm, ZeroConstructor)
	struct FScriptDelegate                             Delegate_69;                                              // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
};

// Function Curie.CurieManager.UnbindDelegateForCurieStateAttached
struct CurieManager_UnbindDelegateForCurieStateAttached_Params
{
	class Object_32759*                                CurieOwner_69;                                            // (Parm, ZeroConstructor)
	struct FScriptDelegate                             Delegate_69;                                              // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
};

// Function Curie.CurieManager.UnbindDelegateForCurieElementInteract
struct CurieManager_UnbindDelegateForCurieElementInteract_Params
{
	class Object_32759*                                CurieOwner_69;                                            // (Parm, ZeroConstructor)
	struct FScriptDelegate                             Delegate_69;                                              // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
};

// Function Curie.CurieManager.UnbindDelegateForCurieElementEndInteract
struct CurieManager_UnbindDelegateForCurieElementEndInteract_Params
{
	class Object_32759*                                CurieOwner_69;                                            // (Parm, ZeroConstructor)
	struct FScriptDelegate                             Delegate_69;                                              // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
};

// Function Curie.CurieManager.UnbindDelegateForCurieElementDetached
struct CurieManager_UnbindDelegateForCurieElementDetached_Params
{
	class Object_32759*                                CurieOwner_69;                                            // (Parm, ZeroConstructor)
	struct FScriptDelegate                             Delegate_69;                                              // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
};

// Function Curie.CurieManager.UnbindDelegateForCurieElementBeginInteract
struct CurieManager_UnbindDelegateForCurieElementBeginInteract_Params
{
	class Object_32759*                                CurieOwner_69;                                            // (Parm, ZeroConstructor)
	struct FScriptDelegate                             Delegate_69;                                              // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
};

// Function Curie.CurieManager.UnbindDelegateForCurieElementAttached
struct CurieManager_UnbindDelegateForCurieElementAttached_Params
{
	class Object_32759*                                CurieOwner_69;                                            // (Parm, ZeroConstructor)
	struct FScriptDelegate                             Delegate_69;                                              // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
};

// Function Curie.CurieManager.HandleContainerOwnerDestroyed
struct CurieManager_HandleContainerOwnerDestroyed_Params
{
	class Actor_32759*                                 OwnerActor_69;                                            // (Parm, ZeroConstructor)
};

// Function Curie.CurieManager.BindDelegateForCurieStateDetached
struct CurieManager_BindDelegateForCurieStateDetached_Params
{
	class Object_32759*                                CurieOwner_69;                                            // (Parm, ZeroConstructor)
	struct FScriptDelegate                             Delegate_69;                                              // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
};

// Function Curie.CurieManager.BindDelegateForCurieStateAttached
struct CurieManager_BindDelegateForCurieStateAttached_Params
{
	class Object_32759*                                CurieOwner_69;                                            // (Parm, ZeroConstructor)
	struct FScriptDelegate                             Delegate_69;                                              // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
};

// Function Curie.CurieManager.BindDelegateForCurieElementInteract
struct CurieManager_BindDelegateForCurieElementInteract_Params
{
	class Object_32759*                                CurieOwner_69;                                            // (Parm, ZeroConstructor)
	struct FScriptDelegate                             Delegate_69;                                              // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
};

// Function Curie.CurieManager.BindDelegateForCurieElementEndInteract
struct CurieManager_BindDelegateForCurieElementEndInteract_Params
{
	class Object_32759*                                CurieOwner_69;                                            // (Parm, ZeroConstructor)
	struct FScriptDelegate                             Delegate_69;                                              // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
};

// Function Curie.CurieManager.BindDelegateForCurieElementDetached
struct CurieManager_BindDelegateForCurieElementDetached_Params
{
	class Object_32759*                                CurieOwner_69;                                            // (Parm, ZeroConstructor)
	struct FScriptDelegate                             Delegate_69;                                              // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
};

// Function Curie.CurieManager.BindDelegateForCurieElementBeginInteract
struct CurieManager_BindDelegateForCurieElementBeginInteract_Params
{
	class Object_32759*                                CurieOwner_69;                                            // (Parm, ZeroConstructor)
	struct FScriptDelegate                             Delegate_69;                                              // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
};

// Function Curie.CurieManager.BindDelegateForCurieElementAttached
struct CurieManager_BindDelegateForCurieElementAttached_Params
{
	class Object_32759*                                CurieOwner_69;                                            // (Parm, ZeroConstructor)
	struct FScriptDelegate                             Delegate_69;                                              // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

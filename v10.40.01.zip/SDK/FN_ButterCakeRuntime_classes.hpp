#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Classes
//---------------------------------------------------------------------------

// Class ButterCakeRuntime.ButterCakeKismetLibrary
// 0x0000 (0x0028 - 0x0028)
class ButterCakeKismetLibrary : public BlueprintFunctionLibrary
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class ButterCakeRuntime.ButterCakeKismetLibrary"));
		
		return ptr;
	}

};


// Class ButterCakeRuntime.ButterCakeUnstuckComponent
// 0x00D8 (0x0178 - 0x00A0)
class ButterCakeUnstuckComponent : public ActorComponent
{
public:
	unsigned char                                      UnknownData00[0x10];                                      // 0x00A0(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty ButterCakeRuntime.ButterCakeUnstuckComponent.OnBlocked_69
	struct FScalableFloat                              EnsureEnable_69;                                          // 0x00B0(0x0028) (Edit, DisableEditOnInstance)
	struct FScalableFloat                              EventBPEnable_69;                                         // 0x00D8(0x0028) (Edit, DisableEditOnInstance)
	int                                                LocationSampleMaxCount_69;                                // 0x0100(0x0004) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	float                                              LocationSampleDelay_69;                                   // 0x0104(0x0004) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	float                                              DistanceMinToUnstuck_69;                                  // 0x0108(0x0004) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData01[0x4];                                       // 0x010C(0x0004) MISSED OFFSET
	struct FGameplayTagContainer                       PauseUnstuckBehaviorTags_69;                              // 0x0110(0x0020) (Edit, DisableEditOnInstance)
	TArray<struct FVector>                             LocationSamples_69;                                       // 0x0130(0x0010) (ZeroConstructor, Transient)
	TArray<struct FString>                             BTTaskSamples_69;                                         // 0x0140(0x0010) (ZeroConstructor, Transient)
	float                                              DistanceMinToUnstuckSqr_69;                               // 0x0150(0x0004) (ZeroConstructor, Transient, IsPlainOldData)
	unsigned char                                      UnknownData02[0x4];                                       // 0x0154(0x0004) MISSED OFFSET
	class FortAIPawn*                                  CachedOwner_69;                                           // 0x0158(0x0008) (ZeroConstructor, Transient)
	class AbilitySystemComponent_32759*                CachedAbilityComponent_69;                                // 0x0160(0x0008) (ExportObject, ZeroConstructor, Transient, InstancedReference)
	class FortGameStateAthena*                         CachedAthenaGameState_69;                                 // 0x0168(0x0008) (ZeroConstructor, Transient)
	unsigned char                                      UnknownData03[0x8];                                       // 0x0170(0x0008) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class ButterCakeRuntime.ButterCakeUnstuckComponent"));
		
		return ptr;
	}


	void ResetUnstuckLocationSamples();
	void HandleAthenaGamePhaseChanged(EAthenaGamePhase GamePhase_69);
};


// Class ButterCakeRuntime.FortAIAnimInstance_ButterCake
// 0x0070 (0x05F0 - 0x0580)
class FortAIAnimInstance_ButterCake : public FortAIAnimInstance
{
public:
	float                                              StartPosLeftPlantC_69;                                    // 0x0580(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, Transient, IsPlainOldData)
	float                                              LookAtYaw_69;                                             // 0x0584(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, Transient, IsPlainOldData)
	float                                              LookAtPitch_69;                                           // 0x0588(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, Transient, IsPlainOldData)
	bool                                               bIsMoving_69;                                             // 0x058C(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, Transient, IsPlainOldData)
	bool                                               bShouldApplyHostileAdditive_69;                           // 0x058D(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, Transient, IsPlainOldData)
	bool                                               bIsMouthOpen_69;                                          // 0x058E(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, Transient, IsPlainOldData)
	bool                                               bIsLocomotion_69;                                         // 0x058F(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, Transient, IsPlainOldData)
	bool                                               bIsHostile_69;                                            // 0x0590(0x0001) (BlueprintVisible, ZeroConstructor, Transient, IsPlainOldData)
	bool                                               bIsLured_69;                                              // 0x0591(0x0001) (BlueprintVisible, ZeroConstructor, Transient, IsPlainOldData)
	unsigned char                                      UnknownData00[0x2];                                       // 0x0592(0x0002) MISSED OFFSET
	struct FName                                       AimOffsetAlpha_69;                                        // 0x0594(0x0008) (BlueprintVisible, ZeroConstructor, Transient, IsPlainOldData)
	EFortButterCakeFootPhase                           FootPhase_69;                                             // 0x0598(0x0001) (BlueprintVisible, ZeroConstructor, Transient, IsPlainOldData)
	bool                                               bFootPhaseIsRightPlantA_69;                               // 0x0599(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, Transient, IsPlainOldData)
	bool                                               bFootPhaseIsRightPlantB_69;                               // 0x059A(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, Transient, IsPlainOldData)
	bool                                               bFootPhaseIsRightPlantC_69;                               // 0x059B(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, Transient, IsPlainOldData)
	bool                                               bFootPhaseIsLeftPlantA_69;                                // 0x059C(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, Transient, IsPlainOldData)
	bool                                               bFootPhaseIsLeftPlantB_69;                                // 0x059D(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, Transient, IsPlainOldData)
	bool                                               bFootPhaseIsLeftPlantC_69;                                // 0x059E(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, Transient, IsPlainOldData)
	bool                                               bFootPhaseIsHostileRightPass_69;                          // 0x059F(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, Transient, IsPlainOldData)
	bool                                               bFootPhaseIsHostileRightPlant_69;                         // 0x05A0(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, Transient, IsPlainOldData)
	bool                                               bFootPhaseIsHostileLeftPass_69;                           // 0x05A1(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, Transient, IsPlainOldData)
	bool                                               bFootPhaseIsHostileLeftPlant_69;                          // 0x05A2(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, Transient, IsPlainOldData)
	bool                                               bFootPhaseIsBothPlant_69;                                 // 0x05A3(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, Transient, IsPlainOldData)
	bool                                               bFootPhaseIsBothPlantA_69;                                // 0x05A4(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, Transient, IsPlainOldData)
	bool                                               bFootPhaseIsBothPlantB_69;                                // 0x05A5(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, Transient, IsPlainOldData)
	bool                                               bFootPhaseIsBothPlantC_69;                                // 0x05A6(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, Transient, IsPlainOldData)
	bool                                               bFootPhaseIsBothPlantD_69;                                // 0x05A7(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, Transient, IsPlainOldData)
	bool                                               bIsIdleTurn_69;                                           // 0x05A8(0x0001) (BlueprintVisible, ZeroConstructor, Transient, IsPlainOldData)
	bool                                               bIdleTurnRight_69;                                        // 0x05A9(0x0001) (BlueprintVisible, ZeroConstructor, Transient, IsPlainOldData)
	unsigned char                                      UnknownData01[0x2];                                       // 0x05AA(0x0002) MISSED OFFSET
	float                                              RotationDirection_69;                                     // 0x05AC(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, Transient, IsPlainOldData)
	bool                                               bLocomotion_Conduit_IsMovingORIsLocomotion_69;            // 0x05B0(0x0001) (BlueprintVisible, ZeroConstructor, Transient, IsPlainOldData)
	bool                                               bLocomotion_Conduit_NOTIsMovingANDNOTIsLocomotion_69;     // 0x05B1(0x0001) (BlueprintVisible, ZeroConstructor, Transient, IsPlainOldData)
	unsigned char                                      UnknownData02[0x2];                                       // 0x05B2(0x0002) MISSED OFFSET
	float                                              MinLeanAngleDegrees_69;                                   // 0x05B4(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              MaxLeanAngleDegrees_69;                                   // 0x05B8(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              MouthOpenMinCurveValue_69;                                // 0x05BC(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              LocomotionMinCurveValue_69;                               // 0x05C0(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              FootPhaseMinActivateValue_69;                             // 0x05C4(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              FootPhaseActiveStartValue_69;                             // 0x05C8(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              FootPhaseInactiveStartValue_69;                           // 0x05CC(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FName                                       CurveName_DisableHostileAdditive_69;                      // 0x05D0(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FName                                       CurveName_FootPhase_69;                                   // 0x05D4(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FName                                       CurveName_ApplyAimOffset_69;                              // 0x05D8(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FName                                       CurveName_ApplyHostileAimOffset_69;                       // 0x05DC(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FName                                       CurveName_MouthOpen_69;                                   // 0x05E0(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FName                                       CurveName_IsLocomotion_69;                                // 0x05E4(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FName                                       AIE_ButterCake_Berserk_69;                                // 0x05E8(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FName                                       AIE_ButterCake_Lured_69;                                  // 0x05EC(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class ButterCakeRuntime.FortAIAnimInstance_ButterCake"));
		
		return ptr;
	}


	void SetFootPhaseMembers();
	float ComputeLeanAngleByVelocity();
	EFortButterCakeFootPhase ComputeFootPhase();
};


// Class ButterCakeRuntime.FortButterCakeComponent_Telemetry
// 0x0030 (0x0138 - 0x0108)
class FortButterCakeComponent_Telemetry : public FortAIComponent_Telemetry
{
public:
	int                                                ItemsEatenCount_69;                                       // 0x0108(0x0004) (ZeroConstructor, Transient, IsPlainOldData)
	int                                                SneezeCount_69;                                           // 0x010C(0x0004) (ZeroConstructor, Transient, IsPlainOldData)
	int                                                ItemsSneezedCount_69;                                     // 0x0110(0x0004) (ZeroConstructor, Transient, IsPlainOldData)
	int                                                BerserkCount_69;                                          // 0x0114(0x0004) (ZeroConstructor, Transient, IsPlainOldData)
	int                                                PlayerAsBerserkInstigatorCount_69;                        // 0x0118(0x0004) (ZeroConstructor, Transient, IsPlainOldData)
	int                                                BotAsBerserkInstigatorCount_69;                           // 0x011C(0x0004) (ZeroConstructor, Transient, IsPlainOldData)
	int                                                NPCAsBerserkInstigatorCount_69;                           // 0x0120(0x0004) (ZeroConstructor, Transient, IsPlainOldData)
	int                                                AIPawnAsBerserkInstigatorCount_69;                        // 0x0124(0x0004) (ZeroConstructor, Transient, IsPlainOldData)
	int                                                UnknownAsBerserkInstigatorCount_69;                       // 0x0128(0x0004) (ZeroConstructor, Transient, IsPlainOldData)
	int                                                BlowholeUsesCount_69;                                     // 0x012C(0x0004) (ZeroConstructor, Transient, IsPlainOldData)
	int                                                LuredCount_69;                                            // 0x0130(0x0004) (ZeroConstructor, Transient, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0134(0x0004) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class ButterCakeRuntime.FortButterCakeComponent_Telemetry"));
		
		return ptr;
	}


	void OnLured();
	void OnItemsSneezed(int ItemsCount_69);
	void OnItemsEaten(int ItemsCount_69);
	void OnEnterBerserk(class Controller* Instigator_69);
	void OnBlowHoleUsed();
};


// Class ButterCakeRuntime.FortButterCakeControlRig
// 0x00C8 (0x0620 - 0x0558)
class FortButterCakeControlRig : public ControlRig
{
public:
	struct FName                                       PBIKRootBoneName_69;                                      // 0x0558(0x0008) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, Transient, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x055C(0x0004) MISSED OFFSET
	struct FRigElementKeyCollection                    FootCurveCollection_69;                                   // 0x0560(0x0010) (BlueprintVisible, BlueprintReadOnly, Transient)
	struct FRigElementKeyCollection                    FootEffectorBoneCollection_69;                            // 0x0570(0x0010) (BlueprintVisible, BlueprintReadOnly, Transient)
	struct FRigElementKeyCollection                    FootEffectorControlCollection_69;                         // 0x0580(0x0010) (BlueprintVisible, BlueprintReadOnly, Transient)
	struct FRigElementKeyCollection                    FootExcludedBoneCollection_69;                            // 0x0590(0x0010) (BlueprintVisible, BlueprintReadOnly, Transient)
	struct FRigElementKeyCollection                    ChinEffectorBoneCollection_69;                            // 0x05A0(0x0010) (BlueprintVisible, BlueprintReadOnly, Transient)
	struct FRigElementKeyCollection                    ChinExcludedBoneCollection_69;                            // 0x05B0(0x0010) (BlueprintVisible, BlueprintReadOnly, Transient)
	struct FRigElementKeyCollection                    TailEffectorBoneCollection_69;                            // 0x05C0(0x0010) (BlueprintVisible, BlueprintReadOnly, Transient)
	struct FRigElementKey                              TailBaseBoneKey_69;                                       // 0x05D0(0x0008) (BlueprintVisible, BlueprintReadOnly, Transient)
	struct FRigElementKey                              TailTipBoneKey_69;                                        // 0x05D8(0x0008) (BlueprintVisible, BlueprintReadOnly, Transient)
	struct FRigElementKey                              UpperLipBoneKey_69;                                       // 0x05E0(0x0008) (BlueprintVisible, BlueprintReadOnly, Transient)
	struct FRigElementKeyCollection                    GroundHitBoneCollection_69;                               // 0x05E8(0x0010) (BlueprintVisible, Transient)
	TArray<struct FVector>                             GroundHitLocationList_69;                                 // 0x05F8(0x0010) (BlueprintVisible, ZeroConstructor, Transient)
	TArray<struct FVector>                             GroundHitNormalList_69;                                   // 0x0608(0x0010) (BlueprintVisible, ZeroConstructor, Transient)
	int                                                Counter_69;                                               // 0x0618(0x0004) (BlueprintVisible, ZeroConstructor, Transient, IsPlainOldData)
	unsigned char                                      UnknownData01[0x4];                                       // 0x061C(0x0004) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class ButterCakeRuntime.FortButterCakeControlRig"));
		
		return ptr;
	}


	struct FVector GetGroundHitNormalAt(int Index_69);
	struct FVector GetGroundHitLocationAt(int Index_69);
};


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

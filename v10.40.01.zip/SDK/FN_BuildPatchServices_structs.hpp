#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Script Structs
//---------------------------------------------------------------------------

// ScriptStruct BuildPatchServices.SHAHashData
// 0x0014
struct FSHAHashData
{
	unsigned char                                      Hash_69[0x14];                                            // 0x0000(0x0001) (ZeroConstructor, IsPlainOldData)
};

// ScriptStruct BuildPatchServices.ChunkPartData
// 0x0018
struct FChunkPartData
{
	struct FGuid                                       Guid_69;                                                  // 0x0000(0x0010) (ZeroConstructor, IsPlainOldData)
	uint32_t                                           Offset_69;                                                // 0x0010(0x0004) (ZeroConstructor, IsPlainOldData)
	uint32_t                                           Size_69;                                                  // 0x0014(0x0004) (ZeroConstructor, IsPlainOldData)
};

// ScriptStruct BuildPatchServices.FileManifestData
// 0x0068
struct FFileManifestData
{
	struct FString                                     Filename_69;                                              // 0x0000(0x0010) (ZeroConstructor)
	struct FSHAHashData                                FileHash_69;                                              // 0x0010(0x0014)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0024(0x0004) MISSED OFFSET
	TArray<struct FChunkPartData>                      FileChunkParts_69;                                        // 0x0028(0x0010) (ZeroConstructor)
	TArray<struct FString>                             InstallTags_69;                                           // 0x0038(0x0010) (ZeroConstructor)
	bool                                               bIsUnixExecutable_69;                                     // 0x0048(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x7];                                       // 0x0049(0x0007) MISSED OFFSET
	struct FString                                     SymlinkTarget_69;                                         // 0x0050(0x0010) (ZeroConstructor)
	bool                                               bIsReadOnly_69;                                           // 0x0060(0x0001) (ZeroConstructor, IsPlainOldData)
	bool                                               bIsCompressed_69;                                         // 0x0061(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData02[0x6];                                       // 0x0062(0x0006) MISSED OFFSET
};

// ScriptStruct BuildPatchServices.ChunkInfoData
// 0x0040
struct FChunkInfoData
{
	struct FGuid                                       Guid_69;                                                  // 0x0000(0x0010) (ZeroConstructor, IsPlainOldData)
	uint64_t                                           Hash_69;                                                  // 0x0010(0x0008) (ZeroConstructor, IsPlainOldData)
	struct FSHAHashData                                ShaHash_69;                                               // 0x0018(0x0014)
	unsigned char                                      UnknownData00[0x4];                                       // 0x002C(0x0004) MISSED OFFSET
	int64_t                                            FileSize_69;                                              // 0x0030(0x0008) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      GroupNumber_69;                                           // 0x0038(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x7];                                       // 0x0039(0x0007) MISSED OFFSET
};

// ScriptStruct BuildPatchServices.CustomFieldData
// 0x0020
struct FCustomFieldData
{
	struct FString                                     Key_69;                                                   // 0x0000(0x0010) (ZeroConstructor)
	struct FString                                     Value_69;                                                 // 0x0010(0x0010) (ZeroConstructor)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

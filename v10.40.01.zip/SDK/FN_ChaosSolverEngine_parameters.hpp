#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function ChaosSolverEngine.ChaosSolverEngineBlueprintLibrary.ConvertPhysicsCollisionToHitResult
struct ChaosSolverEngineBlueprintLibrary_ConvertPhysicsCollisionToHitResult_Params
{
	struct FChaosPhysicsCollisionInfo                  PhysicsCollision_69;                                      // (ConstParm, Parm, OutParm, ReferenceParm)
	struct FHitResult                                  ReturnValue_69;                                           // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function ChaosSolverEngine.ChaosSolverActor.SetSolverActive
struct ChaosSolverActor_SetSolverActive_Params
{
	bool                                               bActive_69;                                               // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function ChaosSolverEngine.ChaosSolverActor.SetAsCurrentWorldSolver
struct ChaosSolverActor_SetAsCurrentWorldSolver_Params
{
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

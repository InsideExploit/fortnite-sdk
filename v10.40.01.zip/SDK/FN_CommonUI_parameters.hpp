#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function CommonUI.CommonActionWidget.SetInputActions
struct CommonActionWidget_SetInputActions_Params
{
	TArray<struct FDataTableRowHandle>                 NewInputActions_69;                                       // (Parm, ZeroConstructor)
};

// Function CommonUI.CommonActionWidget.SetInputAction
struct CommonActionWidget_SetInputAction_Params
{
	struct FDataTableRowHandle                         InputActionRow_69;                                        // (Parm)
};

// Function CommonUI.CommonActionWidget.SetIconRimBrush
struct CommonActionWidget_SetIconRimBrush_Params
{
	struct FSlateBrush                                 InIconRimBrush_69;                                        // (Parm)
};

// DelegateFunction CommonUI.CommonActionWidget.OnInputMethodChanged__DelegateSignature
struct CommonActionWidget_OnInputMethodChanged__DelegateSignature_Params
{
	bool                                               bUsingGamepad_69;                                         // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function CommonUI.CommonActionWidget.IsHeldAction
struct CommonActionWidget_IsHeldAction_Params
{
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CommonUI.CommonActionWidget.GetIcon
struct CommonActionWidget_GetIcon_Params
{
	struct FSlateBrush                                 ReturnValue_69;                                           // (Parm, OutParm, ReturnParm)
};

// Function CommonUI.CommonActionWidget.GetDisplayText
struct CommonActionWidget_GetDisplayText_Params
{
	struct FText                                       ReturnValue_69;                                           // (Parm, OutParm, ReturnParm)
};

// Function CommonUI.CommonUserWidget.SetConsumePointerInput
struct CommonUserWidget_SetConsumePointerInput_Params
{
	bool                                               bInConsumePointerInput_69;                                // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function CommonUI.CommonActivatableWidget.SetBindVisibilities
struct CommonActivatableWidget_SetBindVisibilities_Params
{
	ESlateVisibility                                   OnActivatedVisibility_69;                                 // (Parm, ZeroConstructor, IsPlainOldData)
	ESlateVisibility                                   OnDeactivatedVisibility_69;                               // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bInAllActive_69;                                          // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function CommonUI.CommonActivatableWidget.IsActivated
struct CommonActivatableWidget_IsActivated_Params
{
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CommonUI.CommonActivatableWidget.GetDesiredFocusTarget
struct CommonActivatableWidget_GetDesiredFocusTarget_Params
{
	class Widget*                                      ReturnValue_69;                                           // (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)
};

// Function CommonUI.CommonActivatableWidget.DeactivateWidget
struct CommonActivatableWidget_DeactivateWidget_Params
{
};

// Function CommonUI.CommonActivatableWidget.BP_OnHandleBackAction
struct CommonActivatableWidget_BP_OnHandleBackAction_Params
{
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CommonUI.CommonActivatableWidget.BP_OnDeactivated
struct CommonActivatableWidget_BP_OnDeactivated_Params
{
};

// Function CommonUI.CommonActivatableWidget.BP_OnActivated
struct CommonActivatableWidget_BP_OnActivated_Params
{
};

// Function CommonUI.CommonActivatableWidget.BP_GetDesiredFocusTarget
struct CommonActivatableWidget_BP_GetDesiredFocusTarget_Params
{
	class Widget*                                      ReturnValue_69;                                           // (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)
};

// Function CommonUI.CommonActivatableWidget.BindVisibilityToActivation
struct CommonActivatableWidget_BindVisibilityToActivation_Params
{
	class CommonActivatableWidget*                     ActivatableWidget_69;                                     // (Parm, ZeroConstructor, InstancedReference)
};

// Function CommonUI.CommonActivatableWidget.ActivateWidget
struct CommonActivatableWidget_ActivateWidget_Params
{
};

// Function CommonUI.CommonAnimatedSwitcher.SetDisableTransitionAnimation
struct CommonAnimatedSwitcher_SetDisableTransitionAnimation_Params
{
	bool                                               bDisableAnimation_69;                                     // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function CommonUI.CommonAnimatedSwitcher.IsTransitionPlaying
struct CommonAnimatedSwitcher_IsTransitionPlaying_Params
{
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CommonUI.CommonAnimatedSwitcher.IsCurrentlySwitching
struct CommonAnimatedSwitcher_IsCurrentlySwitching_Params
{
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CommonUI.CommonAnimatedSwitcher.HasWidgets
struct CommonAnimatedSwitcher_HasWidgets_Params
{
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CommonUI.CommonAnimatedSwitcher.ActivatePreviousWidget
struct CommonAnimatedSwitcher_ActivatePreviousWidget_Params
{
	bool                                               bCanWrap_69;                                              // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function CommonUI.CommonAnimatedSwitcher.ActivateNextWidget
struct CommonAnimatedSwitcher_ActivateNextWidget_Params
{
	bool                                               bCanWrap_69;                                              // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function CommonUI.CommonBorderStyle.GetBackgroundBrush
struct CommonBorderStyle_GetBackgroundBrush_Params
{
	struct FSlateBrush                                 Brush_69;                                                 // (Parm, OutParm)
};

// Function CommonUI.CommonBorder.SetStyle
struct CommonBorder_SetStyle_Params
{
	class CommonBorderStyle*                           InStyle_69;                                               // (Parm, ZeroConstructor)
};

// Function CommonUI.CommonButtonStyle.GetSelectedTextStyle
struct CommonButtonStyle_GetSelectedTextStyle_Params
{
	class CommonTextStyle*                             ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function CommonUI.CommonButtonStyle.GetSelectedPressedBrush
struct CommonButtonStyle_GetSelectedPressedBrush_Params
{
	struct FSlateBrush                                 Brush_69;                                                 // (Parm, OutParm)
};

// Function CommonUI.CommonButtonStyle.GetSelectedHoveredTextStyle
struct CommonButtonStyle_GetSelectedHoveredTextStyle_Params
{
	class CommonTextStyle*                             ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function CommonUI.CommonButtonStyle.GetSelectedHoveredBrush
struct CommonButtonStyle_GetSelectedHoveredBrush_Params
{
	struct FSlateBrush                                 Brush_69;                                                 // (Parm, OutParm)
};

// Function CommonUI.CommonButtonStyle.GetSelectedBaseBrush
struct CommonButtonStyle_GetSelectedBaseBrush_Params
{
	struct FSlateBrush                                 Brush_69;                                                 // (Parm, OutParm)
};

// Function CommonUI.CommonButtonStyle.GetNormalTextStyle
struct CommonButtonStyle_GetNormalTextStyle_Params
{
	class CommonTextStyle*                             ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function CommonUI.CommonButtonStyle.GetNormalPressedBrush
struct CommonButtonStyle_GetNormalPressedBrush_Params
{
	struct FSlateBrush                                 Brush_69;                                                 // (Parm, OutParm)
};

// Function CommonUI.CommonButtonStyle.GetNormalHoveredTextStyle
struct CommonButtonStyle_GetNormalHoveredTextStyle_Params
{
	class CommonTextStyle*                             ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function CommonUI.CommonButtonStyle.GetNormalHoveredBrush
struct CommonButtonStyle_GetNormalHoveredBrush_Params
{
	struct FSlateBrush                                 Brush_69;                                                 // (Parm, OutParm)
};

// Function CommonUI.CommonButtonStyle.GetNormalBaseBrush
struct CommonButtonStyle_GetNormalBaseBrush_Params
{
	struct FSlateBrush                                 Brush_69;                                                 // (Parm, OutParm)
};

// Function CommonUI.CommonButtonStyle.GetMaterialBrush
struct CommonButtonStyle_GetMaterialBrush_Params
{
	struct FSlateBrush                                 Brush_69;                                                 // (Parm, OutParm)
};

// Function CommonUI.CommonButtonStyle.GetDisabledTextStyle
struct CommonButtonStyle_GetDisabledTextStyle_Params
{
	class CommonTextStyle*                             ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function CommonUI.CommonButtonStyle.GetDisabledBrush
struct CommonButtonStyle_GetDisabledBrush_Params
{
	struct FSlateBrush                                 Brush_69;                                                 // (Parm, OutParm)
};

// Function CommonUI.CommonButtonStyle.GetCustomPadding
struct CommonButtonStyle_GetCustomPadding_Params
{
	struct FSlateCore_Fmargin                          OutCustomPadding_69;                                      // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
};

// Function CommonUI.CommonButtonStyle.GetButtonPadding
struct CommonButtonStyle_GetButtonPadding_Params
{
	struct FSlateCore_Fmargin                          OutButtonPadding_69;                                      // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
};

// Function CommonUI.CommonButtonBase.StopDoubleClickPropagation
struct CommonButtonBase_StopDoubleClickPropagation_Params
{
};

// Function CommonUI.CommonButtonBase.SetTriggeringInputAction
struct CommonButtonBase_SetTriggeringInputAction_Params
{
	struct FDataTableRowHandle                         InputActionRow_69;                                        // (ConstParm, Parm, OutParm, ReferenceParm)
};

// Function CommonUI.CommonButtonBase.SetTriggeredInputAction
struct CommonButtonBase_SetTriggeredInputAction_Params
{
	struct FDataTableRowHandle                         InputActionRow_69;                                        // (ConstParm, Parm, OutParm, ReferenceParm)
};

// Function CommonUI.CommonButtonBase.SetTouchMethod
struct CommonButtonBase_SetTouchMethod_Params
{
	TEnumAsByte<EButtonTouchMethod>                    InTouchMethod_69;                                         // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function CommonUI.CommonButtonBase.SetStyle
struct CommonButtonBase_SetStyle_Params
{
	class CommonButtonStyle*                           InStyle_69;                                               // (Parm, ZeroConstructor)
};

// Function CommonUI.CommonButtonBase.SetShouldUseFallbackDefaultInputAction
struct CommonButtonBase_SetShouldUseFallbackDefaultInputAction_Params
{
	bool                                               bInShouldUseFallbackDefaultInputAction_69;                // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function CommonUI.CommonButtonBase.SetShouldSelectUponReceivingFocus
struct CommonButtonBase_SetShouldSelectUponReceivingFocus_Params
{
	bool                                               bInShouldSelectUponReceivingFocus_69;                     // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function CommonUI.CommonButtonBase.SetSelectedPressedSoundOverride
struct CommonButtonBase_SetSelectedPressedSoundOverride_Params
{
	class SoundBase*                                   sound_69;                                                 // (Parm, ZeroConstructor)
};

// Function CommonUI.CommonButtonBase.SetSelectedInternal
struct CommonButtonBase_SetSelectedInternal_Params
{
	bool                                               bInSelected_69;                                           // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bAllowSound_69;                                           // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bBroadcast_69;                                            // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function CommonUI.CommonButtonBase.SetSelectedHoveredSoundOverride
struct CommonButtonBase_SetSelectedHoveredSoundOverride_Params
{
	class SoundBase*                                   sound_69;                                                 // (Parm, ZeroConstructor)
};

// Function CommonUI.CommonButtonBase.SetPressMethod
struct CommonButtonBase_SetPressMethod_Params
{
	TEnumAsByte<EButtonPressMethod>                    InPressMethod_69;                                         // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function CommonUI.CommonButtonBase.SetPressedSoundOverride
struct CommonButtonBase_SetPressedSoundOverride_Params
{
	class SoundBase*                                   sound_69;                                                 // (Parm, ZeroConstructor)
};

// Function CommonUI.CommonButtonBase.SetMinDimensions
struct CommonButtonBase_SetMinDimensions_Params
{
	int                                                InMinWidth_69;                                            // (Parm, ZeroConstructor, IsPlainOldData)
	int                                                InMinHeight_69;                                           // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function CommonUI.CommonButtonBase.SetLockedPressedSoundOverride
struct CommonButtonBase_SetLockedPressedSoundOverride_Params
{
	class SoundBase*                                   sound_69;                                                 // (Parm, ZeroConstructor)
};

// Function CommonUI.CommonButtonBase.SetLockedHoveredSoundOverride
struct CommonButtonBase_SetLockedHoveredSoundOverride_Params
{
	class SoundBase*                                   sound_69;                                                 // (Parm, ZeroConstructor)
};

// Function CommonUI.CommonButtonBase.SetIsToggleable
struct CommonButtonBase_SetIsToggleable_Params
{
	bool                                               bInIsToggleable_69;                                       // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function CommonUI.CommonButtonBase.SetIsSelected
struct CommonButtonBase_SetIsSelected_Params
{
	bool                                               InSelected_69;                                            // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bGiveClickFeedback_69;                                    // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function CommonUI.CommonButtonBase.SetIsSelectable
struct CommonButtonBase_SetIsSelectable_Params
{
	bool                                               bInIsSelectable_69;                                       // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function CommonUI.CommonButtonBase.SetIsLocked
struct CommonButtonBase_SetIsLocked_Params
{
	bool                                               bInIsLocked_69;                                           // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function CommonUI.CommonButtonBase.SetIsInteractionEnabled
struct CommonButtonBase_SetIsInteractionEnabled_Params
{
	bool                                               bInIsInteractionEnabled_69;                               // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function CommonUI.CommonButtonBase.SetIsInteractableWhenSelected
struct CommonButtonBase_SetIsInteractableWhenSelected_Params
{
	bool                                               bInInteractableWhenSelected_69;                           // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function CommonUI.CommonButtonBase.SetIsFocusable
struct CommonButtonBase_SetIsFocusable_Params
{
	bool                                               bInIsFocusable_69;                                        // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function CommonUI.CommonButtonBase.SetInputActionProgressMaterial
struct CommonButtonBase_SetInputActionProgressMaterial_Params
{
	struct FSlateBrush                                 InProgressMaterialBrush_69;                               // (ConstParm, Parm, OutParm, ReferenceParm)
	struct FName                                       InProgressMaterialParam_69;                               // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
};

// Function CommonUI.CommonButtonBase.SetHoveredSoundOverride
struct CommonButtonBase_SetHoveredSoundOverride_Params
{
	class SoundBase*                                   sound_69;                                                 // (Parm, ZeroConstructor)
};

// Function CommonUI.CommonButtonBase.SetHideInputAction
struct CommonButtonBase_SetHideInputAction_Params
{
	bool                                               bInHideInputAction_69;                                    // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function CommonUI.CommonButtonBase.SetClickMethod
struct CommonButtonBase_SetClickMethod_Params
{
	TEnumAsByte<EButtonClickMethod>                    InClickMethod_69;                                         // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function CommonUI.CommonButtonBase.OnTriggeringInputActionChanged
struct CommonButtonBase_OnTriggeringInputActionChanged_Params
{
	struct FDataTableRowHandle                         NewTriggeredAction_69;                                    // (ConstParm, Parm, OutParm, ReferenceParm)
};

// Function CommonUI.CommonButtonBase.OnTriggeredInputActionChanged
struct CommonButtonBase_OnTriggeredInputActionChanged_Params
{
	struct FDataTableRowHandle                         NewTriggeredAction_69;                                    // (ConstParm, Parm, OutParm, ReferenceParm)
};

// Function CommonUI.CommonButtonBase.OnInputMethodChanged
struct CommonButtonBase_OnInputMethodChanged_Params
{
	ECommonInputType                                   CurrentInputType_69;                                      // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function CommonUI.CommonButtonBase.OnCurrentTextStyleChanged
struct CommonButtonBase_OnCurrentTextStyleChanged_Params
{
};

// Function CommonUI.CommonButtonBase.OnActionProgress
struct CommonButtonBase_OnActionProgress_Params
{
	float                                              HeldPercent_69;                                           // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function CommonUI.CommonButtonBase.OnActionComplete
struct CommonButtonBase_OnActionComplete_Params
{
};

// Function CommonUI.CommonButtonBase.NativeOnActionProgress
struct CommonButtonBase_NativeOnActionProgress_Params
{
	float                                              HeldPercent_69;                                           // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function CommonUI.CommonButtonBase.NativeOnActionComplete
struct CommonButtonBase_NativeOnActionComplete_Params
{
};

// Function CommonUI.CommonButtonBase.IsPressed
struct CommonButtonBase_IsPressed_Params
{
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CommonUI.CommonButtonBase.IsInteractionEnabled
struct CommonButtonBase_IsInteractionEnabled_Params
{
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CommonUI.CommonButtonBase.HandleTriggeringActionCommited
struct CommonButtonBase_HandleTriggeringActionCommited_Params
{
	bool                                               bPassThrough_69;                                          // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
};

// Function CommonUI.CommonButtonBase.HandleFocusReceived
struct CommonButtonBase_HandleFocusReceived_Params
{
};

// Function CommonUI.CommonButtonBase.HandleFocusLost
struct CommonButtonBase_HandleFocusLost_Params
{
};

// Function CommonUI.CommonButtonBase.HandleButtonReleased
struct CommonButtonBase_HandleButtonReleased_Params
{
};

// Function CommonUI.CommonButtonBase.HandleButtonPressed
struct CommonButtonBase_HandleButtonPressed_Params
{
};

// Function CommonUI.CommonButtonBase.HandleButtonClicked
struct CommonButtonBase_HandleButtonClicked_Params
{
};

// Function CommonUI.CommonButtonBase.GetStyle
struct CommonButtonBase_GetStyle_Params
{
	class CommonButtonStyle*                           ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function CommonUI.CommonButtonBase.GetSingleMaterialStyleMID
struct CommonButtonBase_GetSingleMaterialStyleMID_Params
{
	class MaterialInstanceDynamic*                     ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function CommonUI.CommonButtonBase.GetShouldSelectUponReceivingFocus
struct CommonButtonBase_GetShouldSelectUponReceivingFocus_Params
{
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CommonUI.CommonButtonBase.GetSelected
struct CommonButtonBase_GetSelected_Params
{
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CommonUI.CommonButtonBase.GetLocked
struct CommonButtonBase_GetLocked_Params
{
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CommonUI.CommonButtonBase.GetIsFocusable
struct CommonButtonBase_GetIsFocusable_Params
{
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CommonUI.CommonButtonBase.GetInputAction
struct CommonButtonBase_GetInputAction_Params
{
	struct FDataTableRowHandle                         InputActionRow_69;                                        // (Parm, OutParm)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CommonUI.CommonButtonBase.GetCurrentTextStyleClass
struct CommonButtonBase_GetCurrentTextStyleClass_Params
{
	class CommonTextStyle*                             ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function CommonUI.CommonButtonBase.GetCurrentTextStyle
struct CommonButtonBase_GetCurrentTextStyle_Params
{
	class CommonTextStyle*                             ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function CommonUI.CommonButtonBase.GetCurrentCustomPadding
struct CommonButtonBase_GetCurrentCustomPadding_Params
{
	struct FSlateCore_Fmargin                          OutCustomPadding_69;                                      // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
};

// Function CommonUI.CommonButtonBase.GetCurrentButtonPadding
struct CommonButtonBase_GetCurrentButtonPadding_Params
{
	struct FSlateCore_Fmargin                          OutButtonPadding_69;                                      // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
};

// Function CommonUI.CommonButtonBase.DisableButtonWithReason
struct CommonButtonBase_DisableButtonWithReason_Params
{
	struct FText                                       DisabledReason_69;                                        // (ConstParm, Parm, OutParm, ReferenceParm)
};

// Function CommonUI.CommonButtonBase.ClearSelection
struct CommonButtonBase_ClearSelection_Params
{
};

// Function CommonUI.CommonButtonBase.BP_OnUnhovered
struct CommonButtonBase_BP_OnUnhovered_Params
{
};

// Function CommonUI.CommonButtonBase.BP_OnSelected
struct CommonButtonBase_BP_OnSelected_Params
{
};

// Function CommonUI.CommonButtonBase.BP_OnReleased
struct CommonButtonBase_BP_OnReleased_Params
{
};

// Function CommonUI.CommonButtonBase.BP_OnPressed
struct CommonButtonBase_BP_OnPressed_Params
{
};

// Function CommonUI.CommonButtonBase.BP_OnLockedChanged
struct CommonButtonBase_BP_OnLockedChanged_Params
{
	bool                                               bIsLocked_69;                                             // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function CommonUI.CommonButtonBase.BP_OnLockDoubleClicked
struct CommonButtonBase_BP_OnLockDoubleClicked_Params
{
};

// Function CommonUI.CommonButtonBase.BP_OnLockClicked
struct CommonButtonBase_BP_OnLockClicked_Params
{
};

// Function CommonUI.CommonButtonBase.BP_OnInputMethodChanged
struct CommonButtonBase_BP_OnInputMethodChanged_Params
{
	ECommonInputType                                   CurrentInputType_69;                                      // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function CommonUI.CommonButtonBase.BP_OnHovered
struct CommonButtonBase_BP_OnHovered_Params
{
};

// Function CommonUI.CommonButtonBase.BP_OnFocusReceived
struct CommonButtonBase_BP_OnFocusReceived_Params
{
};

// Function CommonUI.CommonButtonBase.BP_OnFocusLost
struct CommonButtonBase_BP_OnFocusLost_Params
{
};

// Function CommonUI.CommonButtonBase.BP_OnEnabled
struct CommonButtonBase_BP_OnEnabled_Params
{
};

// Function CommonUI.CommonButtonBase.BP_OnDoubleClicked
struct CommonButtonBase_BP_OnDoubleClicked_Params
{
};

// Function CommonUI.CommonButtonBase.BP_OnDisabled
struct CommonButtonBase_BP_OnDisabled_Params
{
};

// Function CommonUI.CommonButtonBase.BP_OnDeselected
struct CommonButtonBase_BP_OnDeselected_Params
{
};

// Function CommonUI.CommonButtonBase.BP_OnClicked
struct CommonButtonBase_BP_OnClicked_Params
{
};

// Function CommonUI.CommonTextBlock.SetWrapTextWidth
struct CommonTextBlock_SetWrapTextWidth_Params
{
	int                                                InWrapTextAt_69;                                          // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function CommonUI.CommonTextBlock.SetTextCase
struct CommonTextBlock_SetTextCase_Params
{
	bool                                               bUseAllCaps_69;                                           // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function CommonUI.CommonTextBlock.SetStyle
struct CommonTextBlock_SetStyle_Params
{
	class CommonTextStyle*                             InStyle_69;                                               // (Parm, ZeroConstructor)
};

// Function CommonUI.CommonTextBlock.SetScrollingEnabled
struct CommonTextBlock_SetScrollingEnabled_Params
{
	bool                                               bInIsScrollingEnabled_69;                                 // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function CommonUI.CommonTextBlock.SetMargin
struct CommonTextBlock_SetMargin_Params
{
	struct FSlateCore_Fmargin                          InMargin_69;                                              // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
};

// Function CommonUI.CommonTextBlock.SetLineHeightPercentage
struct CommonTextBlock_SetLineHeightPercentage_Params
{
	float                                              InLineHeightPercentage_69;                                // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function CommonUI.CommonTextBlock.ResetScrollState
struct CommonTextBlock_ResetScrollState_Params
{
};

// Function CommonUI.CommonTextBlock.GetMargin
struct CommonTextBlock_GetMargin_Params
{
	struct FSlateCore_Fmargin                          ReturnValue_69;                                           // (ConstParm, Parm, OutParm, ZeroConstructor, ReturnParm, ReferenceParm, IsPlainOldData)
};

// Function CommonUI.CommonDateTimeTextBlock.SetTimespanValue
struct CommonDateTimeTextBlock_SetTimespanValue_Params
{
	struct FTimespan                                   InTimespan_69;                                            // (ConstParm, Parm, ZeroConstructor)
};

// Function CommonUI.CommonDateTimeTextBlock.SetDateTimeValue
struct CommonDateTimeTextBlock_SetDateTimeValue_Params
{
	struct FDateTime                                   InDateTime_69;                                            // (ConstParm, Parm, ZeroConstructor)
	bool                                               bShowAsCountdown_69;                                      // (Parm, ZeroConstructor, IsPlainOldData)
	float                                              InRefreshDelay_69;                                        // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function CommonUI.CommonDateTimeTextBlock.SetCountDownCompletionText
struct CommonDateTimeTextBlock_SetCountDownCompletionText_Params
{
	struct FText                                       InCompletionText_69;                                      // (ConstParm, Parm)
};

// Function CommonUI.CommonDateTimeTextBlock.GetDateTime
struct CommonDateTimeTextBlock_GetDateTime_Params
{
	struct FDateTime                                   ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function CommonUI.CommonLazyImage.SetMaterialTextureParamName
struct CommonLazyImage_SetMaterialTextureParamName_Params
{
	struct FName                                       TextureParamName_69;                                      // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function CommonUI.CommonLazyImage.SetBrushFromLazyTexture
struct CommonLazyImage_SetBrushFromLazyTexture_Params
{
	bool                                               bMatchSize_69;                                            // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function CommonUI.CommonLazyImage.SetBrushFromLazyMaterial
struct CommonLazyImage_SetBrushFromLazyMaterial_Params
{
};

// Function CommonUI.CommonLazyImage.SetBrushFromLazyDisplayAsset
struct CommonLazyImage_SetBrushFromLazyDisplayAsset_Params
{
	bool                                               bMatchTextureSize_69;                                     // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function CommonUI.CommonLazyImage.IsLoading
struct CommonLazyImage_IsLoading_Params
{
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CommonUI.CommonLazyWidget.SetLazyContent
struct CommonLazyWidget_SetLazyContent_Params
{
};

// Function CommonUI.CommonLazyWidget.IsLoading
struct CommonLazyWidget_IsLoading_Params
{
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CommonUI.CommonLazyWidget.GetContent
struct CommonLazyWidget_GetContent_Params
{
	class UserWidget*                                  ReturnValue_69;                                           // (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)
};

// Function CommonUI.CommonListView.SetEntrySpacing
struct CommonListView_SetEntrySpacing_Params
{
	float                                              InEntrySpacing_69;                                        // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function CommonUI.LoadGuardSlot.SetVerticalAlignment
struct LoadGuardSlot_SetVerticalAlignment_Params
{
	TEnumAsByte<EVerticalAlignment>                    InVerticalAlignment_69;                                   // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function CommonUI.LoadGuardSlot.SetPadding
struct LoadGuardSlot_SetPadding_Params
{
	struct FSlateCore_Fmargin                          InPadding_69;                                             // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function CommonUI.LoadGuardSlot.SetHorizontalAlignment
struct LoadGuardSlot_SetHorizontalAlignment_Params
{
	TEnumAsByte<EHorizontalAlignment>                  InHorizontalAlignment_69;                                 // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function CommonUI.CommonLoadGuard.SetLoadingText
struct CommonLoadGuard_SetLoadingText_Params
{
	struct FText                                       InLoadingText_69;                                         // (ConstParm, Parm, OutParm, ReferenceParm)
};

// Function CommonUI.CommonLoadGuard.SetIsLoading
struct CommonLoadGuard_SetIsLoading_Params
{
	bool                                               bInIsLoading_69;                                          // (Parm, ZeroConstructor, IsPlainOldData)
};

// DelegateFunction CommonUI.CommonLoadGuard.OnAssetLoaded__DelegateSignature
struct CommonLoadGuard_OnAssetLoaded__DelegateSignature_Params
{
	class Object_32759*                                Object_69;                                                // (Parm, ZeroConstructor)
};

// Function CommonUI.CommonLoadGuard.IsLoading
struct CommonLoadGuard_IsLoading_Params
{
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CommonUI.CommonLoadGuard.BP_GuardAndLoadAsset
struct CommonLoadGuard_BP_GuardAndLoadAsset_Params
{
	struct FScriptDelegate                             OnAssetLoaded_69;                                         // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
};

// Function CommonUI.CommonNumericTextBlock.SetNumericType
struct CommonNumericTextBlock_SetNumericType_Params
{
	ECommonNumericType                                 InNumericType_69;                                         // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function CommonUI.CommonNumericTextBlock.SetCurrentValue
struct CommonNumericTextBlock_SetCurrentValue_Params
{
	float                                              NewValue_69;                                              // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// DelegateFunction CommonUI.CommonNumericTextBlock.OnOutro__DelegateSignature
struct CommonNumericTextBlock_OnOutro__DelegateSignature_Params
{
	class CommonNumericTextBlock*                      NumericTextBlock_69;                                      // (Parm, ZeroConstructor, InstancedReference)
};

// DelegateFunction CommonUI.CommonNumericTextBlock.OnInterpolationUpdated__DelegateSignature
struct CommonNumericTextBlock_OnInterpolationUpdated__DelegateSignature_Params
{
	class CommonNumericTextBlock*                      NumericTextBlock_69;                                      // (Parm, ZeroConstructor, InstancedReference)
	float                                              LastValue_69;                                             // (Parm, ZeroConstructor, IsPlainOldData)
	float                                              NewValue_69;                                              // (Parm, ZeroConstructor, IsPlainOldData)
};

// DelegateFunction CommonUI.CommonNumericTextBlock.OnInterpolationStarted__DelegateSignature
struct CommonNumericTextBlock_OnInterpolationStarted__DelegateSignature_Params
{
	class CommonNumericTextBlock*                      NumericTextBlock_69;                                      // (Parm, ZeroConstructor, InstancedReference)
};

// DelegateFunction CommonUI.CommonNumericTextBlock.OnInterpolationEnded__DelegateSignature
struct CommonNumericTextBlock_OnInterpolationEnded__DelegateSignature_Params
{
	class CommonNumericTextBlock*                      NumericTextBlock_69;                                      // (Parm, ZeroConstructor, InstancedReference)
	bool                                               HadCompleted_69;                                          // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function CommonUI.CommonNumericTextBlock.IsInterpolatingNumericValue
struct CommonNumericTextBlock_IsInterpolatingNumericValue_Params
{
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CommonUI.CommonNumericTextBlock.InterpolateToValue
struct CommonNumericTextBlock_InterpolateToValue_Params
{
	float                                              TargetValue_69;                                           // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	float                                              MaximumInterpolationDuration_69;                          // (Parm, ZeroConstructor, IsPlainOldData)
	float                                              MinimumChangeRate_69;                                     // (Parm, ZeroConstructor, IsPlainOldData)
	float                                              OutroOffset_69;                                           // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function CommonUI.CommonNumericTextBlock.GetTargetValue
struct CommonNumericTextBlock_GetTargetValue_Params
{
	float                                              ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CommonUI.CommonPoolableWidgetInterface.OnReleaseToPool
struct CommonPoolableWidgetInterface_OnReleaseToPool_Params
{
};

// Function CommonUI.CommonPoolableWidgetInterface.OnAcquireFromPool
struct CommonPoolableWidgetInterface_OnAcquireFromPool_Params
{
};

// Function CommonUI.CommonRichTextBlock.SetScrollingEnabled
struct CommonRichTextBlock_SetScrollingEnabled_Params
{
	bool                                               bInIsScrollingEnabled_69;                                 // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function CommonUI.CommonRotator.ShiftTextRight
struct CommonRotator_ShiftTextRight_Params
{
};

// Function CommonUI.CommonRotator.ShiftTextLeft
struct CommonRotator_ShiftTextLeft_Params
{
};

// Function CommonUI.CommonRotator.SetSelectedItem
struct CommonRotator_SetSelectedItem_Params
{
	int                                                InValue_69;                                               // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function CommonUI.CommonRotator.PopulateTextLabels
struct CommonRotator_PopulateTextLabels_Params
{
	TArray<struct FText>                               Labels_69;                                                // (Parm, ZeroConstructor)
};

// Function CommonUI.CommonRotator.GetSelectedText
struct CommonRotator_GetSelectedText_Params
{
	struct FText                                       ReturnValue_69;                                           // (Parm, OutParm, ReturnParm)
};

// Function CommonUI.CommonRotator.GetSelectedIndex
struct CommonRotator_GetSelectedIndex_Params
{
	int                                                ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CommonUI.CommonRotator.BP_OnOptionsPopulated
struct CommonRotator_BP_OnOptionsPopulated_Params
{
	int                                                Count_69;                                                 // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function CommonUI.CommonRotator.BP_OnOptionSelected
struct CommonRotator_BP_OnOptionSelected_Params
{
	int                                                Index_69;                                                 // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function CommonUI.CommonTabListWidgetBase.SetTabVisibility
struct CommonTabListWidgetBase_SetTabVisibility_Params
{
	struct FName                                       TabNameID_69;                                             // (Parm, ZeroConstructor, IsPlainOldData)
	ESlateVisibility                                   NewVisibility_69;                                         // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function CommonUI.CommonTabListWidgetBase.SetTabInteractionEnabled
struct CommonTabListWidgetBase_SetTabInteractionEnabled_Params
{
	struct FName                                       TabNameID_69;                                             // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bEnable_69;                                               // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function CommonUI.CommonTabListWidgetBase.SetTabEnabled
struct CommonTabListWidgetBase_SetTabEnabled_Params
{
	struct FName                                       TabNameID_69;                                             // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bEnable_69;                                               // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function CommonUI.CommonTabListWidgetBase.SetListeningForInput
struct CommonTabListWidgetBase_SetListeningForInput_Params
{
	bool                                               bShouldListen_69;                                         // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function CommonUI.CommonTabListWidgetBase.SetLinkedSwitcher
struct CommonTabListWidgetBase_SetLinkedSwitcher_Params
{
	class CommonAnimatedSwitcher*                      CommonSwitcher_69;                                        // (Parm, ZeroConstructor, InstancedReference)
};

// Function CommonUI.CommonTabListWidgetBase.SelectTabByID
struct CommonTabListWidgetBase_SelectTabByID_Params
{
	struct FName                                       TabNameID_69;                                             // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bSuppressClickFeedback_69;                                // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CommonUI.CommonTabListWidgetBase.RemoveTab
struct CommonTabListWidgetBase_RemoveTab_Params
{
	struct FName                                       TabNameID_69;                                             // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CommonUI.CommonTabListWidgetBase.RemoveAllTabs
struct CommonTabListWidgetBase_RemoveAllTabs_Params
{
};

// Function CommonUI.CommonTabListWidgetBase.RegisterTab
struct CommonTabListWidgetBase_RegisterTab_Params
{
	struct FName                                       TabNameID_69;                                             // (Parm, ZeroConstructor, IsPlainOldData)
	class CommonButtonBase*                            ButtonWidgetType_69;                                      // (Parm, ZeroConstructor)
	class Widget*                                      ContentWidget_69;                                         // (Parm, ZeroConstructor, InstancedReference)
	int                                                TabIndex_69;                                              // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// DelegateFunction CommonUI.CommonTabListWidgetBase.OnTabSelected__DelegateSignature
struct CommonTabListWidgetBase_OnTabSelected__DelegateSignature_Params
{
	struct FName                                       TabId_69;                                                 // (Parm, ZeroConstructor, IsPlainOldData)
};

// DelegateFunction CommonUI.CommonTabListWidgetBase.OnTabListRebuilt__DelegateSignature
struct CommonTabListWidgetBase_OnTabListRebuilt__DelegateSignature_Params
{
};

// DelegateFunction CommonUI.CommonTabListWidgetBase.OnTabButtonRemoval__DelegateSignature
struct CommonTabListWidgetBase_OnTabButtonRemoval__DelegateSignature_Params
{
	struct FName                                       TabId_69;                                                 // (Parm, ZeroConstructor, IsPlainOldData)
	class CommonButtonBase*                            TabButton_69;                                             // (Parm, ZeroConstructor, InstancedReference)
};

// DelegateFunction CommonUI.CommonTabListWidgetBase.OnTabButtonCreation__DelegateSignature
struct CommonTabListWidgetBase_OnTabButtonCreation__DelegateSignature_Params
{
	struct FName                                       TabId_69;                                                 // (Parm, ZeroConstructor, IsPlainOldData)
	class CommonButtonBase*                            TabButton_69;                                             // (Parm, ZeroConstructor, InstancedReference)
};

// Function CommonUI.CommonTabListWidgetBase.HandleTabRemoval
struct CommonTabListWidgetBase_HandleTabRemoval_Params
{
	struct FName                                       TabNameID_69;                                             // (Parm, ZeroConstructor, IsPlainOldData)
	class CommonButtonBase*                            TabButton_69;                                             // (Parm, ZeroConstructor, InstancedReference)
};

// Function CommonUI.CommonTabListWidgetBase.HandleTabCreation
struct CommonTabListWidgetBase_HandleTabCreation_Params
{
	struct FName                                       TabNameID_69;                                             // (Parm, ZeroConstructor, IsPlainOldData)
	class CommonButtonBase*                            TabButton_69;                                             // (Parm, ZeroConstructor, InstancedReference)
};

// Function CommonUI.CommonTabListWidgetBase.HandleTabButtonSelected
struct CommonTabListWidgetBase_HandleTabButtonSelected_Params
{
	class CommonButtonBase*                            SelectedTabButton_69;                                     // (Parm, ZeroConstructor, InstancedReference)
	int                                                ButtonIndex_69;                                           // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function CommonUI.CommonTabListWidgetBase.HandlePreviousTabInputAction
struct CommonTabListWidgetBase_HandlePreviousTabInputAction_Params
{
	bool                                               bPassThrough_69;                                          // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
};

// Function CommonUI.CommonTabListWidgetBase.HandlePreLinkedSwitcherChanged_BP
struct CommonTabListWidgetBase_HandlePreLinkedSwitcherChanged_BP_Params
{
};

// Function CommonUI.CommonTabListWidgetBase.HandlePostLinkedSwitcherChanged_BP
struct CommonTabListWidgetBase_HandlePostLinkedSwitcherChanged_BP_Params
{
};

// Function CommonUI.CommonTabListWidgetBase.HandleNextTabInputAction
struct CommonTabListWidgetBase_HandleNextTabInputAction_Params
{
	bool                                               bPassThrough_69;                                          // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
};

// Function CommonUI.CommonTabListWidgetBase.GetTabIdAtIndex
struct CommonTabListWidgetBase_GetTabIdAtIndex_Params
{
	int                                                Index_69;                                                 // (Parm, ZeroConstructor, IsPlainOldData)
	struct FName                                       ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CommonUI.CommonTabListWidgetBase.GetTabCount
struct CommonTabListWidgetBase_GetTabCount_Params
{
	int                                                ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CommonUI.CommonTabListWidgetBase.GetTabButtonBaseByID
struct CommonTabListWidgetBase_GetTabButtonBaseByID_Params
{
	struct FName                                       TabNameID_69;                                             // (Parm, ZeroConstructor, IsPlainOldData)
	class CommonButtonBase*                            ReturnValue_69;                                           // (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)
};

// Function CommonUI.CommonTabListWidgetBase.GetSelectedTabId
struct CommonTabListWidgetBase_GetSelectedTabId_Params
{
	struct FName                                       ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CommonUI.CommonTabListWidgetBase.GetLinkedSwitcher
struct CommonTabListWidgetBase_GetLinkedSwitcher_Params
{
	class CommonAnimatedSwitcher*                      ReturnValue_69;                                           // (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)
};

// Function CommonUI.CommonTabListWidgetBase.GetActiveTab
struct CommonTabListWidgetBase_GetActiveTab_Params
{
	struct FName                                       ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CommonUI.CommonTabListWidgetBase.DisableTabWithReason
struct CommonTabListWidgetBase_DisableTabWithReason_Params
{
	struct FName                                       TabNameID_69;                                             // (Parm, ZeroConstructor, IsPlainOldData)
	struct FText                                       Reason_69;                                                // (ConstParm, Parm, OutParm, ReferenceParm)
};

// Function CommonUI.CommonTextStyle.GetStrikeBrush
struct CommonTextStyle_GetStrikeBrush_Params
{
	struct FSlateBrush                                 OutStrikeBrush_69;                                        // (Parm, OutParm)
};

// Function CommonUI.CommonTextStyle.GetShadowOffset
struct CommonTextStyle_GetShadowOffset_Params
{
	struct FVector2D                                   OutShadowOffset_69;                                       // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
};

// Function CommonUI.CommonTextStyle.GetShadowColor
struct CommonTextStyle_GetShadowColor_Params
{
	struct FLinearColor                                OutColor_69;                                              // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
};

// Function CommonUI.CommonTextStyle.GetMargin
struct CommonTextStyle_GetMargin_Params
{
	struct FSlateCore_Fmargin                          OutMargin_69;                                             // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
};

// Function CommonUI.CommonTextStyle.GetLineHeightPercentage
struct CommonTextStyle_GetLineHeightPercentage_Params
{
	float                                              ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CommonUI.CommonTextStyle.GetFont
struct CommonTextStyle_GetFont_Params
{
	struct FSlateFontInfo                              OutFont_69;                                               // (Parm, OutParm)
};

// Function CommonUI.CommonTextStyle.GetColor
struct CommonTextStyle_GetColor_Params
{
	struct FLinearColor                                OutColor_69;                                              // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
};

// Function CommonUI.CommonUILibrary.FindParentWidgetOfType
struct CommonUILibrary_FindParentWidgetOfType_Params
{
	class Widget*                                      StartingWidget_69;                                        // (Parm, ZeroConstructor, InstancedReference)
	class Widget*                                      Type_69;                                                  // (Parm, ZeroConstructor)
	class Widget*                                      ReturnValue_69;                                           // (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)
};

// Function CommonUI.CommonUISubsystemBase.GetInputActionButtonIcon
struct CommonUISubsystemBase_GetInputActionButtonIcon_Params
{
	struct FDataTableRowHandle                         InputActionRowHandle_69;                                  // (ConstParm, Parm, OutParm, ReferenceParm)
	ECommonInputType                                   InputType_69;                                             // (Parm, ZeroConstructor, IsPlainOldData)
	struct FName                                       GamepadName_69;                                           // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
	struct FSlateBrush                                 ReturnValue_69;                                           // (Parm, OutParm, ReturnParm)
};

// Function CommonUI.CommonVisibilitySwitcher.SetActiveWidgetIndex
struct CommonVisibilitySwitcher_SetActiveWidgetIndex_Params
{
	int                                                Index_69;                                                 // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function CommonUI.CommonVisibilitySwitcher.SetActiveWidget
struct CommonVisibilitySwitcher_SetActiveWidget_Params
{
	class Widget*                                      Widget_69;                                                // (ConstParm, Parm, ZeroConstructor, InstancedReference)
};

// Function CommonUI.CommonVisibilitySwitcher.IncrementActiveWidgetIndex
struct CommonVisibilitySwitcher_IncrementActiveWidgetIndex_Params
{
	bool                                               bAllowWrapping_69;                                        // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function CommonUI.CommonVisibilitySwitcher.GetActiveWidgetIndex
struct CommonVisibilitySwitcher_GetActiveWidgetIndex_Params
{
	int                                                ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CommonUI.CommonVisibilitySwitcher.GetActiveWidget
struct CommonVisibilitySwitcher_GetActiveWidget_Params
{
	class Widget*                                      ReturnValue_69;                                           // (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)
};

// Function CommonUI.CommonVisibilitySwitcher.DecrementActiveWidgetIndex
struct CommonVisibilitySwitcher_DecrementActiveWidgetIndex_Params
{
	bool                                               bAllowWrapping_69;                                        // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function CommonUI.CommonVisibilitySwitcher.DeactivateVisibleSlot
struct CommonVisibilitySwitcher_DeactivateVisibleSlot_Params
{
};

// Function CommonUI.CommonVisibilitySwitcher.ActivateVisibleSlot
struct CommonVisibilitySwitcher_ActivateVisibleSlot_Params
{
};

// Function CommonUI.UCommonVisibilityWidgetBase.GetRegisteredPlatforms
struct UCommonVisibilityWidgetBase_GetRegisteredPlatforms_Params
{
	TArray<struct FName>                               ReturnValue_69;                                           // (ConstParm, Parm, OutParm, ZeroConstructor, ReturnParm, ReferenceParm)
};

// Function CommonUI.CommonWidgetCarousel.SetActiveWidgetIndex
struct CommonWidgetCarousel_SetActiveWidgetIndex_Params
{
	int                                                Index_69;                                                 // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function CommonUI.CommonWidgetCarousel.SetActiveWidget
struct CommonWidgetCarousel_SetActiveWidget_Params
{
	class Widget*                                      Widget_69;                                                // (Parm, ZeroConstructor, InstancedReference)
};

// Function CommonUI.CommonWidgetCarousel.PreviousPage
struct CommonWidgetCarousel_PreviousPage_Params
{
};

// Function CommonUI.CommonWidgetCarousel.NextPage
struct CommonWidgetCarousel_NextPage_Params
{
};

// Function CommonUI.CommonWidgetCarousel.GetWidgetAtIndex
struct CommonWidgetCarousel_GetWidgetAtIndex_Params
{
	int                                                Index_69;                                                 // (Parm, ZeroConstructor, IsPlainOldData)
	class Widget*                                      ReturnValue_69;                                           // (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)
};

// Function CommonUI.CommonWidgetCarousel.GetActiveWidgetIndex
struct CommonWidgetCarousel_GetActiveWidgetIndex_Params
{
	int                                                ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CommonUI.CommonWidgetCarousel.EndAutoScrolling
struct CommonWidgetCarousel_EndAutoScrolling_Params
{
};

// Function CommonUI.CommonWidgetCarousel.BeginAutoScrolling
struct CommonWidgetCarousel_BeginAutoScrolling_Params
{
	float                                              ScrollInterval_69;                                        // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function CommonUI.CommonWidgetCarouselNavBar.SetLinkedCarousel
struct CommonWidgetCarouselNavBar_SetLinkedCarousel_Params
{
	class CommonWidgetCarousel*                        CommonCarousel_69;                                        // (Parm, ZeroConstructor, InstancedReference)
};

// Function CommonUI.CommonWidgetCarouselNavBar.HandlePageChanged
struct CommonWidgetCarouselNavBar_HandlePageChanged_Params
{
	class CommonWidgetCarousel*                        CommonCarousel_69;                                        // (Parm, ZeroConstructor, InstancedReference)
	int                                                PageIndex_69;                                             // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function CommonUI.CommonWidgetCarouselNavBar.HandleButtonClicked
struct CommonWidgetCarouselNavBar_HandleButtonClicked_Params
{
	class CommonButtonBase*                            AssociatedButton_69;                                      // (Parm, ZeroConstructor, InstancedReference)
	int                                                ButtonIndex_69;                                           // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function CommonUI.CommonWidgetGroupBase.RemoveWidget
struct CommonWidgetGroupBase_RemoveWidget_Params
{
	class Widget*                                      InWidget_69;                                              // (Parm, ZeroConstructor, InstancedReference)
};

// Function CommonUI.CommonWidgetGroupBase.RemoveAll
struct CommonWidgetGroupBase_RemoveAll_Params
{
};

// Function CommonUI.CommonWidgetGroupBase.AddWidget
struct CommonWidgetGroupBase_AddWidget_Params
{
	class Widget*                                      InWidget_69;                                              // (Parm, ZeroConstructor, InstancedReference)
};

// Function CommonUI.CommonButtonGroupBase.SetSelectionRequired
struct CommonButtonGroupBase_SetSelectionRequired_Params
{
	bool                                               bRequireSelection_69;                                     // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function CommonUI.CommonButtonGroupBase.SelectPreviousButton
struct CommonButtonGroupBase_SelectPreviousButton_Params
{
	bool                                               bAllowWrap_69;                                            // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function CommonUI.CommonButtonGroupBase.SelectNextButton
struct CommonButtonGroupBase_SelectNextButton_Params
{
	bool                                               bAllowWrap_69;                                            // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function CommonUI.CommonButtonGroupBase.SelectButtonAtIndex
struct CommonButtonGroupBase_SelectButtonAtIndex_Params
{
	int                                                ButtonIndex_69;                                           // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bAllowSound_69;                                           // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function CommonUI.CommonButtonGroupBase.OnSelectionStateChangedBase
struct CommonButtonGroupBase_OnSelectionStateChangedBase_Params
{
	class CommonButtonBase*                            BaseButton_69;                                            // (Parm, ZeroConstructor, InstancedReference)
	bool                                               bIsSelected_69;                                           // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function CommonUI.CommonButtonGroupBase.OnHandleButtonBaseDoubleClicked
struct CommonButtonGroupBase_OnHandleButtonBaseDoubleClicked_Params
{
	class CommonButtonBase*                            BaseButton_69;                                            // (Parm, ZeroConstructor, InstancedReference)
};

// Function CommonUI.CommonButtonGroupBase.OnHandleButtonBaseClicked
struct CommonButtonGroupBase_OnHandleButtonBaseClicked_Params
{
	class CommonButtonBase*                            BaseButton_69;                                            // (Parm, ZeroConstructor, InstancedReference)
};

// Function CommonUI.CommonButtonGroupBase.OnButtonBaseUnhovered
struct CommonButtonGroupBase_OnButtonBaseUnhovered_Params
{
	class CommonButtonBase*                            BaseButton_69;                                            // (Parm, ZeroConstructor, InstancedReference)
};

// Function CommonUI.CommonButtonGroupBase.OnButtonBaseHovered
struct CommonButtonGroupBase_OnButtonBaseHovered_Params
{
	class CommonButtonBase*                            BaseButton_69;                                            // (Parm, ZeroConstructor, InstancedReference)
};

// Function CommonUI.CommonButtonGroupBase.HasAnyButtons
struct CommonButtonGroupBase_HasAnyButtons_Params
{
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CommonUI.CommonButtonGroupBase.GetSelectedButtonIndex
struct CommonButtonGroupBase_GetSelectedButtonIndex_Params
{
	int                                                ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CommonUI.CommonButtonGroupBase.GetSelectedButtonBase
struct CommonButtonGroupBase_GetSelectedButtonBase_Params
{
	class CommonButtonBase*                            ReturnValue_69;                                           // (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)
};

// Function CommonUI.CommonButtonGroupBase.GetHoveredButtonIndex
struct CommonButtonGroupBase_GetHoveredButtonIndex_Params
{
	int                                                ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CommonUI.CommonButtonGroupBase.GetButtonCount
struct CommonButtonGroupBase_GetButtonCount_Params
{
	int                                                ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CommonUI.CommonButtonGroupBase.GetButtonBaseAtIndex
struct CommonButtonGroupBase_GetButtonBaseAtIndex_Params
{
	int                                                Index_69;                                                 // (Parm, ZeroConstructor, IsPlainOldData)
	class CommonButtonBase*                            ReturnValue_69;                                           // (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)
};

// Function CommonUI.CommonButtonGroupBase.FindButtonIndex
struct CommonButtonGroupBase_FindButtonIndex_Params
{
	class CommonButtonBase*                            ButtonToFind_69;                                          // (ConstParm, Parm, ZeroConstructor, InstancedReference)
	int                                                ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CommonUI.CommonButtonGroupBase.DeselectAll
struct CommonButtonGroupBase_DeselectAll_Params
{
};

// Function CommonUI.CommonBoundActionBar.SetDisplayOwningPlayerActionsOnly
struct CommonBoundActionBar_SetDisplayOwningPlayerActionsOnly_Params
{
	bool                                               bShouldOnlyDisplayOwningPlayerActions_69;                 // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function CommonUI.CommonBoundActionButton.OnUpdateInputAction
struct CommonBoundActionButton_OnUpdateInputAction_Params
{
};

// Function CommonUI.CommonActivatableWidgetContainerBase.SetTransitionDuration
struct CommonActivatableWidgetContainerBase_SetTransitionDuration_Params
{
	float                                              Duration_69;                                              // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function CommonUI.CommonActivatableWidgetContainerBase.RemoveWidget
struct CommonActivatableWidgetContainerBase_RemoveWidget_Params
{
	class CommonActivatableWidget*                     WidgetToRemove_69;                                        // (Parm, ZeroConstructor, InstancedReference)
};

// Function CommonUI.CommonActivatableWidgetContainerBase.GetTransitionDuration
struct CommonActivatableWidgetContainerBase_GetTransitionDuration_Params
{
	float                                              ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CommonUI.CommonActivatableWidgetContainerBase.GetActiveWidget
struct CommonActivatableWidgetContainerBase_GetActiveWidget_Params
{
	class CommonActivatableWidget*                     ReturnValue_69;                                           // (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)
};

// Function CommonUI.CommonActivatableWidgetContainerBase.ClearWidgets
struct CommonActivatableWidgetContainerBase_ClearWidgets_Params
{
};

// Function CommonUI.CommonActivatableWidgetContainerBase.BP_AddWidget
struct CommonActivatableWidgetContainerBase_BP_AddWidget_Params
{
	class CommonActivatableWidget*                     ActivatableWidgetClass_69;                                // (Parm, ZeroConstructor)
	class CommonActivatableWidget*                     ReturnValue_69;                                           // (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function AudioExtensions.AudioParameterControllerInterface.SetTriggerParameter
struct AudioParameterControllerInterface_SetTriggerParameter_Params
{
	struct FName                                       InName_69;                                                // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function AudioExtensions.AudioParameterControllerInterface.SetStringParameter
struct AudioParameterControllerInterface_SetStringParameter_Params
{
	struct FName                                       InName_69;                                                // (Parm, ZeroConstructor, IsPlainOldData)
	struct FString                                     InValue_69;                                               // (Parm, ZeroConstructor)
};

// Function AudioExtensions.AudioParameterControllerInterface.SetStringArrayParameter
struct AudioParameterControllerInterface_SetStringArrayParameter_Params
{
	struct FName                                       InName_69;                                                // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<struct FString>                             InValue_69;                                               // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
};

// Function AudioExtensions.AudioParameterControllerInterface.SetParameters_Blueprint
struct AudioParameterControllerInterface_SetParameters_Blueprint_Params
{
	TArray<struct FAudioParameter>                     InParameters_69;                                          // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
};

// Function AudioExtensions.AudioParameterControllerInterface.SetObjectParameter
struct AudioParameterControllerInterface_SetObjectParameter_Params
{
	struct FName                                       InName_69;                                                // (Parm, ZeroConstructor, IsPlainOldData)
	class Object_32759*                                InValue_69;                                               // (Parm, ZeroConstructor)
};

// Function AudioExtensions.AudioParameterControllerInterface.SetObjectArrayParameter
struct AudioParameterControllerInterface_SetObjectArrayParameter_Params
{
	struct FName                                       InName_69;                                                // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<class Object_32759*>                        InValue_69;                                               // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
};

// Function AudioExtensions.AudioParameterControllerInterface.SetIntParameter
struct AudioParameterControllerInterface_SetIntParameter_Params
{
	struct FName                                       InName_69;                                                // (Parm, ZeroConstructor, IsPlainOldData)
	int                                                inInt_69;                                                 // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function AudioExtensions.AudioParameterControllerInterface.SetIntArrayParameter
struct AudioParameterControllerInterface_SetIntArrayParameter_Params
{
	struct FName                                       InName_69;                                                // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<int>                                        InValue_69;                                               // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
};

// Function AudioExtensions.AudioParameterControllerInterface.SetFloatParameter
struct AudioParameterControllerInterface_SetFloatParameter_Params
{
	struct FName                                       InName_69;                                                // (Parm, ZeroConstructor, IsPlainOldData)
	float                                              InFloat_69;                                               // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function AudioExtensions.AudioParameterControllerInterface.SetFloatArrayParameter
struct AudioParameterControllerInterface_SetFloatArrayParameter_Params
{
	struct FName                                       InName_69;                                                // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<float>                                      InValue_69;                                               // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
};

// Function AudioExtensions.AudioParameterControllerInterface.SetBoolParameter
struct AudioParameterControllerInterface_SetBoolParameter_Params
{
	struct FName                                       InName_69;                                                // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               InBool_69;                                                // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function AudioExtensions.AudioParameterControllerInterface.SetBoolArrayParameter
struct AudioParameterControllerInterface_SetBoolArrayParameter_Params
{
	struct FName                                       InName_69;                                                // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<bool>                                       InValue_69;                                               // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
};

// Function AudioExtensions.AudioParameterControllerInterface.ResetParameters
struct AudioParameterControllerInterface_ResetParameters_Params
{
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function ChaosCloth.ChaosClothingInteractor.SetWind
struct ChaosClothingInteractor_SetWind_Params
{
	struct FVector2D                                   Drag_69;                                                  // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector2D                                   Lift_69;                                                  // (Parm, ZeroConstructor, IsPlainOldData)
	float                                              AirDensity_69;                                            // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector                                     WindVelocity_69;                                          // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function ChaosCloth.ChaosClothingInteractor.SetVelocityScale
struct ChaosClothingInteractor_SetVelocityScale_Params
{
	struct FVector                                     LinearVelocityScale_69;                                   // (Parm, ZeroConstructor, IsPlainOldData)
	float                                              AngularVelocityScale_69;                                  // (Parm, ZeroConstructor, IsPlainOldData)
	float                                              FictitiousAngularScale_69;                                // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function ChaosCloth.ChaosClothingInteractor.SetPressure
struct ChaosClothingInteractor_SetPressure_Params
{
	struct FVector2D                                   Pressure_69;                                              // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function ChaosCloth.ChaosClothingInteractor.SetMaterialLinear
struct ChaosClothingInteractor_SetMaterialLinear_Params
{
	float                                              EdgeStiffness_69;                                         // (Parm, ZeroConstructor, IsPlainOldData)
	float                                              BendingStiffness_69;                                      // (Parm, ZeroConstructor, IsPlainOldData)
	float                                              AreaStiffness_69;                                         // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function ChaosCloth.ChaosClothingInteractor.SetMaterial
struct ChaosClothingInteractor_SetMaterial_Params
{
	struct FVector2D                                   EdgeStiffness_69;                                         // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector2D                                   BendingStiffness_69;                                      // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector2D                                   AreaStiffness_69;                                         // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function ChaosCloth.ChaosClothingInteractor.SetLongRangeAttachmentLinear
struct ChaosClothingInteractor_SetLongRangeAttachmentLinear_Params
{
	float                                              TetherStiffness_69;                                       // (Parm, ZeroConstructor, IsPlainOldData)
	float                                              TetherScale_69;                                           // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function ChaosCloth.ChaosClothingInteractor.SetLongRangeAttachment
struct ChaosClothingInteractor_SetLongRangeAttachment_Params
{
	struct FVector2D                                   TetherStiffness_69;                                       // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector2D                                   TetherScale_69;                                           // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function ChaosCloth.ChaosClothingInteractor.SetGravity
struct ChaosClothingInteractor_SetGravity_Params
{
	float                                              GravityScale_69;                                          // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bIsGravityOverridden_69;                                  // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector                                     GravityOverride_69;                                       // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function ChaosCloth.ChaosClothingInteractor.SetDamping
struct ChaosClothingInteractor_SetDamping_Params
{
	float                                              DampingCoefficient_69;                                    // (Parm, ZeroConstructor, IsPlainOldData)
	float                                              LocalDampingCoefficient_69;                               // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function ChaosCloth.ChaosClothingInteractor.SetCollision
struct ChaosClothingInteractor_SetCollision_Params
{
	float                                              CollisionThickness_69;                                    // (Parm, ZeroConstructor, IsPlainOldData)
	float                                              FrictionCoefficient_69;                                   // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bUseCCD_69;                                               // (Parm, ZeroConstructor, IsPlainOldData)
	float                                              SelfCollisionThickness_69;                                // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function ChaosCloth.ChaosClothingInteractor.SetBackstop
struct ChaosClothingInteractor_SetBackstop_Params
{
	bool                                               bEnabled_69;                                              // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function ChaosCloth.ChaosClothingInteractor.SetAnimDriveLinear
struct ChaosClothingInteractor_SetAnimDriveLinear_Params
{
	float                                              AnimDriveStiffness_69;                                    // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function ChaosCloth.ChaosClothingInteractor.SetAnimDrive
struct ChaosClothingInteractor_SetAnimDrive_Params
{
	struct FVector2D                                   AnimDriveStiffness_69;                                    // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector2D                                   AnimDriveDamping_69;                                      // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function ChaosCloth.ChaosClothingInteractor.SetAerodynamics
struct ChaosClothingInteractor_SetAerodynamics_Params
{
	float                                              DragCoefficient_69;                                       // (Parm, ZeroConstructor, IsPlainOldData)
	float                                              LiftCoefficient_69;                                       // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector                                     WindVelocity_69;                                          // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function ChaosCloth.ChaosClothingInteractor.ResetAndTeleport
struct ChaosClothingInteractor_ResetAndTeleport_Params
{
	bool                                               bReset_69;                                                // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bTeleport_69;                                             // (Parm, ZeroConstructor, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

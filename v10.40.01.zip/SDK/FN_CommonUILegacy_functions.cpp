// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Functions
//---------------------------------------------------------------------------

// Function CommonUILegacy.CommonActivatablePanelLegacy.SetInputActionHandlerWithProgressPopupMenu
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// struct FDataTableRowHandle     InputActionRow_69              (Parm)
// struct FScriptDelegate         CommitedEvent_69               (Parm, ZeroConstructor)
// struct FScriptDelegate         ProgressEvent_69               (Parm, ZeroConstructor)
// class CommonPopupMenuLegacy*   PopupMenu_69                   (Parm, ZeroConstructor, InstancedReference)

void CommonActivatablePanelLegacy::SetInputActionHandlerWithProgressPopupMenu(const struct FDataTableRowHandle& InputActionRow_69, const struct FScriptDelegate& CommitedEvent_69, const struct FScriptDelegate& ProgressEvent_69, class CommonPopupMenuLegacy* PopupMenu_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUILegacy.CommonActivatablePanelLegacy.SetInputActionHandlerWithProgressPopupMenu"));

	CommonActivatablePanelLegacy_SetInputActionHandlerWithProgressPopupMenu_Params params;
	params.InputActionRow_69 = InputActionRow_69;
	params.CommitedEvent_69 = CommitedEvent_69;
	params.ProgressEvent_69 = ProgressEvent_69;
	params.PopupMenu_69 = PopupMenu_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUILegacy.CommonActivatablePanelLegacy.SetInputActionHandlerWithProgress
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// struct FDataTableRowHandle     InputActionRow_69              (Parm)
// struct FScriptDelegate         CommitedEvent_69               (Parm, ZeroConstructor)
// struct FScriptDelegate         ProgressEvent_69               (Parm, ZeroConstructor)

void CommonActivatablePanelLegacy::SetInputActionHandlerWithProgress(const struct FDataTableRowHandle& InputActionRow_69, const struct FScriptDelegate& CommitedEvent_69, const struct FScriptDelegate& ProgressEvent_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUILegacy.CommonActivatablePanelLegacy.SetInputActionHandlerWithProgress"));

	CommonActivatablePanelLegacy_SetInputActionHandlerWithProgress_Params params;
	params.InputActionRow_69 = InputActionRow_69;
	params.CommitedEvent_69 = CommitedEvent_69;
	params.ProgressEvent_69 = ProgressEvent_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUILegacy.CommonActivatablePanelLegacy.SetInputActionHandlerWithPopupMenu
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// struct FDataTableRowHandle     InputActionRow_69              (Parm)
// struct FScriptDelegate         CommitedEvent_69               (Parm, ZeroConstructor)
// class CommonPopupMenuLegacy*   PopupMenu_69                   (Parm, ZeroConstructor, InstancedReference)

void CommonActivatablePanelLegacy::SetInputActionHandlerWithPopupMenu(const struct FDataTableRowHandle& InputActionRow_69, const struct FScriptDelegate& CommitedEvent_69, class CommonPopupMenuLegacy* PopupMenu_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUILegacy.CommonActivatablePanelLegacy.SetInputActionHandlerWithPopupMenu"));

	CommonActivatablePanelLegacy_SetInputActionHandlerWithPopupMenu_Params params;
	params.InputActionRow_69 = InputActionRow_69;
	params.CommitedEvent_69 = CommitedEvent_69;
	params.PopupMenu_69 = PopupMenu_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUILegacy.CommonActivatablePanelLegacy.SetInputActionHandler
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// struct FDataTableRowHandle     InputActionRow_69              (Parm)
// struct FScriptDelegate         CommitedEvent_69               (Parm, ZeroConstructor)

void CommonActivatablePanelLegacy::SetInputActionHandler(const struct FDataTableRowHandle& InputActionRow_69, const struct FScriptDelegate& CommitedEvent_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUILegacy.CommonActivatablePanelLegacy.SetInputActionHandler"));

	CommonActivatablePanelLegacy_SetInputActionHandler_Params params;
	params.InputActionRow_69 = InputActionRow_69;
	params.CommitedEvent_69 = CommitedEvent_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUILegacy.CommonActivatablePanelLegacy.SetActionHandlerStateWithDisabledCommitEvent
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// class DataTable*               DataTable_69                   (Parm, ZeroConstructor)
// struct FName                   RowName_69                     (Parm, ZeroConstructor, IsPlainOldData)
// EInputActionState              State_69                       (Parm, ZeroConstructor, IsPlainOldData)
// struct FScriptDelegate         DisabledCommitEvent_69         (Parm, ZeroConstructor)

void CommonActivatablePanelLegacy::SetActionHandlerStateWithDisabledCommitEvent(class DataTable* DataTable_69, const struct FName& RowName_69, EInputActionState State_69, const struct FScriptDelegate& DisabledCommitEvent_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUILegacy.CommonActivatablePanelLegacy.SetActionHandlerStateWithDisabledCommitEvent"));

	CommonActivatablePanelLegacy_SetActionHandlerStateWithDisabledCommitEvent_Params params;
	params.DataTable_69 = DataTable_69;
	params.RowName_69 = RowName_69;
	params.State_69 = State_69;
	params.DisabledCommitEvent_69 = DisabledCommitEvent_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUILegacy.CommonActivatablePanelLegacy.SetActionHandlerStateFromHandleWithDisabledCommitEvent
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// struct FDataTableRowHandle     InputActionRow_69              (Parm)
// EInputActionState              State_69                       (Parm, ZeroConstructor, IsPlainOldData)
// struct FScriptDelegate         DisabledCommitEvent_69         (Parm, ZeroConstructor)

void CommonActivatablePanelLegacy::SetActionHandlerStateFromHandleWithDisabledCommitEvent(const struct FDataTableRowHandle& InputActionRow_69, EInputActionState State_69, const struct FScriptDelegate& DisabledCommitEvent_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUILegacy.CommonActivatablePanelLegacy.SetActionHandlerStateFromHandleWithDisabledCommitEvent"));

	CommonActivatablePanelLegacy_SetActionHandlerStateFromHandleWithDisabledCommitEvent_Params params;
	params.InputActionRow_69 = InputActionRow_69;
	params.State_69 = State_69;
	params.DisabledCommitEvent_69 = DisabledCommitEvent_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUILegacy.CommonActivatablePanelLegacy.SetActionHandlerStateFromHandle
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// struct FDataTableRowHandle     InputActionRow_69              (Parm)
// EInputActionState              State_69                       (Parm, ZeroConstructor, IsPlainOldData)

void CommonActivatablePanelLegacy::SetActionHandlerStateFromHandle(const struct FDataTableRowHandle& InputActionRow_69, EInputActionState State_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUILegacy.CommonActivatablePanelLegacy.SetActionHandlerStateFromHandle"));

	CommonActivatablePanelLegacy_SetActionHandlerStateFromHandle_Params params;
	params.InputActionRow_69 = InputActionRow_69;
	params.State_69 = State_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUILegacy.CommonActivatablePanelLegacy.SetActionHandlerState
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// class DataTable*               DataTable_69                   (ConstParm, Parm, ZeroConstructor)
// struct FName                   RowName_69                     (Parm, ZeroConstructor, IsPlainOldData)
// EInputActionState              State_69                       (Parm, ZeroConstructor, IsPlainOldData)

void CommonActivatablePanelLegacy::SetActionHandlerState(class DataTable* DataTable_69, const struct FName& RowName_69, EInputActionState State_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUILegacy.CommonActivatablePanelLegacy.SetActionHandlerState"));

	CommonActivatablePanelLegacy_SetActionHandlerState_Params params;
	params.DataTable_69 = DataTable_69;
	params.RowName_69 = RowName_69;
	params.State_69 = State_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUILegacy.CommonActivatablePanelLegacy.RemoveInputActionHandler
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// struct FDataTableRowHandle     InputActionRow_69              (Parm)

void CommonActivatablePanelLegacy::RemoveInputActionHandler(const struct FDataTableRowHandle& InputActionRow_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUILegacy.CommonActivatablePanelLegacy.RemoveInputActionHandler"));

	CommonActivatablePanelLegacy_RemoveInputActionHandler_Params params;
	params.InputActionRow_69 = InputActionRow_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUILegacy.CommonActivatablePanelLegacy.RemoveAllInputActionHandlers
// (Final, Native, Public, BlueprintCallable)

void CommonActivatablePanelLegacy::RemoveAllInputActionHandlers()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUILegacy.CommonActivatablePanelLegacy.RemoveAllInputActionHandlers"));

	CommonActivatablePanelLegacy_RemoveAllInputActionHandlers_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUILegacy.CommonActivatablePanelLegacy.PopPanel
// (Native, Public, BlueprintCallable)

void CommonActivatablePanelLegacy::PopPanel()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUILegacy.CommonActivatablePanelLegacy.PopPanel"));

	CommonActivatablePanelLegacy_PopPanel_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUILegacy.CommonActivatablePanelLegacy.OnTransitionedBySwitcher
// (Event, Protected, BlueprintEvent)

void CommonActivatablePanelLegacy::OnTransitionedBySwitcher()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUILegacy.CommonActivatablePanelLegacy.OnTransitionedBySwitcher"));

	CommonActivatablePanelLegacy_OnTransitionedBySwitcher_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUILegacy.CommonActivatablePanelLegacy.OnRemovedFromActivationStack
// (Event, Protected, BlueprintEvent)

void CommonActivatablePanelLegacy::OnRemovedFromActivationStack()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUILegacy.CommonActivatablePanelLegacy.OnRemovedFromActivationStack"));

	CommonActivatablePanelLegacy_OnRemovedFromActivationStack_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUILegacy.CommonActivatablePanelLegacy.OnInputModeChanged
// (Event, Protected, BlueprintEvent)
// Parameters:
// bool                           bUsingGamepad_69               (Parm, ZeroConstructor, IsPlainOldData)

void CommonActivatablePanelLegacy::OnInputModeChanged(bool bUsingGamepad_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUILegacy.CommonActivatablePanelLegacy.OnInputModeChanged"));

	CommonActivatablePanelLegacy_OnInputModeChanged_Params params;
	params.bUsingGamepad_69 = bUsingGamepad_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUILegacy.CommonActivatablePanelLegacy.OnBeginOutro
// (Native, Event, Protected, BlueprintEvent)

void CommonActivatablePanelLegacy::OnBeginOutro()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUILegacy.CommonActivatablePanelLegacy.OnBeginOutro"));

	CommonActivatablePanelLegacy_OnBeginOutro_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUILegacy.CommonActivatablePanelLegacy.OnBeginIntro
// (Native, Event, Protected, BlueprintEvent)

void CommonActivatablePanelLegacy::OnBeginIntro()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUILegacy.CommonActivatablePanelLegacy.OnBeginIntro"));

	CommonActivatablePanelLegacy_OnBeginIntro_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUILegacy.CommonActivatablePanelLegacy.OnAddedToActivationStack
// (Event, Protected, BlueprintEvent)

void CommonActivatablePanelLegacy::OnAddedToActivationStack()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUILegacy.CommonActivatablePanelLegacy.OnAddedToActivationStack"));

	CommonActivatablePanelLegacy_OnAddedToActivationStack_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUILegacy.CommonActivatablePanelLegacy.IsIntroed
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool CommonActivatablePanelLegacy::IsIntroed()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUILegacy.CommonActivatablePanelLegacy.IsIntroed"));

	CommonActivatablePanelLegacy_IsIntroed_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CommonUILegacy.CommonActivatablePanelLegacy.IsInActivationStack
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool CommonActivatablePanelLegacy::IsInActivationStack()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUILegacy.CommonActivatablePanelLegacy.IsInActivationStack"));

	CommonActivatablePanelLegacy_IsInActivationStack_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CommonUILegacy.CommonActivatablePanelLegacy.HasInputActionHandler
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FDataTableRowHandle     InputActionRow_69              (Parm)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool CommonActivatablePanelLegacy::HasInputActionHandler(const struct FDataTableRowHandle& InputActionRow_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUILegacy.CommonActivatablePanelLegacy.HasInputActionHandler"));

	CommonActivatablePanelLegacy_HasInputActionHandler_Params params;
	params.InputActionRow_69 = InputActionRow_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CommonUILegacy.CommonActivatablePanelLegacy.GetInputActions
// (Final, Native, Public, HasOutParms, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// TArray<struct FCommonInputActionHandlerData> InputActionDataRows_69         (Parm, OutParm, ZeroConstructor)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool CommonActivatablePanelLegacy::GetInputActions(TArray<struct FCommonInputActionHandlerData>* InputActionDataRows_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUILegacy.CommonActivatablePanelLegacy.GetInputActions"));

	CommonActivatablePanelLegacy_GetInputActions_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (InputActionDataRows_69 != nullptr)
		*InputActionDataRows_69 = params.InputActionDataRows_69;

	return params.ReturnValue_69;
}


// Function CommonUILegacy.CommonActivatablePanelLegacy.EndOutro
// (Final, Native, Protected, BlueprintCallable)

void CommonActivatablePanelLegacy::EndOutro()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUILegacy.CommonActivatablePanelLegacy.EndOutro"));

	CommonActivatablePanelLegacy_EndOutro_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUILegacy.CommonActivatablePanelLegacy.EndIntro
// (Final, Native, Protected, BlueprintCallable)

void CommonActivatablePanelLegacy::EndIntro()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUILegacy.CommonActivatablePanelLegacy.EndIntro"));

	CommonActivatablePanelLegacy_EndIntro_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUILegacy.CommonActivatablePanelLegacy.BeginOutro
// (Final, Native, Public, BlueprintCallable)

void CommonActivatablePanelLegacy::BeginOutro()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUILegacy.CommonActivatablePanelLegacy.BeginOutro"));

	CommonActivatablePanelLegacy_BeginOutro_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUILegacy.CommonActivatablePanelLegacy.BeginIntro
// (Final, Native, Public, BlueprintCallable)

void CommonActivatablePanelLegacy::BeginIntro()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUILegacy.CommonActivatablePanelLegacy.BeginIntro"));

	CommonActivatablePanelLegacy_BeginIntro_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUILegacy.CommonActivatablePanelLegacy.AddInputActionNoHandler
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// class DataTable*               DataTable_69                   (Parm, ZeroConstructor)
// struct FName                   RowName_69                     (Parm, ZeroConstructor, IsPlainOldData)

void CommonActivatablePanelLegacy::AddInputActionNoHandler(class DataTable* DataTable_69, const struct FName& RowName_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUILegacy.CommonActivatablePanelLegacy.AddInputActionNoHandler"));

	CommonActivatablePanelLegacy_AddInputActionNoHandler_Params params;
	params.DataTable_69 = DataTable_69;
	params.RowName_69 = RowName_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUILegacy.CommonActivatablePanelLegacy.AddInputActionHandlerWithProgressPopup
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// class DataTable*               DataTable_69                   (Parm, ZeroConstructor)
// struct FName                   RowName_69                     (Parm, ZeroConstructor, IsPlainOldData)
// struct FScriptDelegate         CommitedEvent_69               (Parm, ZeroConstructor)
// struct FScriptDelegate         ProgressEvent_69               (Parm, ZeroConstructor)
// class CommonPopupMenuLegacy*   PopupMenu_69                   (Parm, ZeroConstructor, InstancedReference)

void CommonActivatablePanelLegacy::AddInputActionHandlerWithProgressPopup(class DataTable* DataTable_69, const struct FName& RowName_69, const struct FScriptDelegate& CommitedEvent_69, const struct FScriptDelegate& ProgressEvent_69, class CommonPopupMenuLegacy* PopupMenu_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUILegacy.CommonActivatablePanelLegacy.AddInputActionHandlerWithProgressPopup"));

	CommonActivatablePanelLegacy_AddInputActionHandlerWithProgressPopup_Params params;
	params.DataTable_69 = DataTable_69;
	params.RowName_69 = RowName_69;
	params.CommitedEvent_69 = CommitedEvent_69;
	params.ProgressEvent_69 = ProgressEvent_69;
	params.PopupMenu_69 = PopupMenu_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUILegacy.CommonActivatablePanelLegacy.AddInputActionHandlerWithProgress
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// class DataTable*               DataTable_69                   (Parm, ZeroConstructor)
// struct FName                   RowName_69                     (Parm, ZeroConstructor, IsPlainOldData)
// struct FScriptDelegate         CommitedEvent_69               (Parm, ZeroConstructor)
// struct FScriptDelegate         ProgressEvent_69               (Parm, ZeroConstructor)

void CommonActivatablePanelLegacy::AddInputActionHandlerWithProgress(class DataTable* DataTable_69, const struct FName& RowName_69, const struct FScriptDelegate& CommitedEvent_69, const struct FScriptDelegate& ProgressEvent_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUILegacy.CommonActivatablePanelLegacy.AddInputActionHandlerWithProgress"));

	CommonActivatablePanelLegacy_AddInputActionHandlerWithProgress_Params params;
	params.DataTable_69 = DataTable_69;
	params.RowName_69 = RowName_69;
	params.CommitedEvent_69 = CommitedEvent_69;
	params.ProgressEvent_69 = ProgressEvent_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUILegacy.CommonActivatablePanelLegacy.AddInputActionHandlerWithPopup
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// class DataTable*               DataTable_69                   (Parm, ZeroConstructor)
// struct FName                   RowName_69                     (Parm, ZeroConstructor, IsPlainOldData)
// struct FScriptDelegate         CommitedEvent_69               (Parm, ZeroConstructor)
// class CommonPopupMenuLegacy*   PopupMenu_69                   (Parm, ZeroConstructor, InstancedReference)

void CommonActivatablePanelLegacy::AddInputActionHandlerWithPopup(class DataTable* DataTable_69, const struct FName& RowName_69, const struct FScriptDelegate& CommitedEvent_69, class CommonPopupMenuLegacy* PopupMenu_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUILegacy.CommonActivatablePanelLegacy.AddInputActionHandlerWithPopup"));

	CommonActivatablePanelLegacy_AddInputActionHandlerWithPopup_Params params;
	params.DataTable_69 = DataTable_69;
	params.RowName_69 = RowName_69;
	params.CommitedEvent_69 = CommitedEvent_69;
	params.PopupMenu_69 = PopupMenu_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUILegacy.CommonActivatablePanelLegacy.AddInputActionHandler
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// class DataTable*               DataTable_69                   (Parm, ZeroConstructor)
// struct FName                   RowName_69                     (Parm, ZeroConstructor, IsPlainOldData)
// struct FScriptDelegate         CommitedEvent_69               (Parm, ZeroConstructor)

void CommonActivatablePanelLegacy::AddInputActionHandler(class DataTable* DataTable_69, const struct FName& RowName_69, const struct FScriptDelegate& CommitedEvent_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUILegacy.CommonActivatablePanelLegacy.AddInputActionHandler"));

	CommonActivatablePanelLegacy_AddInputActionHandler_Params params;
	params.DataTable_69 = DataTable_69;
	params.RowName_69 = RowName_69;
	params.CommitedEvent_69 = CommitedEvent_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUILegacy.CommonButtonGroupLegacy.OnSelectionStateChanged
// (Native, Protected)
// Parameters:
// class CommonButtonLegacy*      BaseButton_69                  (Parm, ZeroConstructor, InstancedReference)
// bool                           bIsSelected_69                 (Parm, ZeroConstructor, IsPlainOldData)

void CommonButtonGroupLegacy::OnSelectionStateChanged(class CommonButtonLegacy* BaseButton_69, bool bIsSelected_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUILegacy.CommonButtonGroupLegacy.OnSelectionStateChanged"));

	CommonButtonGroupLegacy_OnSelectionStateChanged_Params params;
	params.BaseButton_69 = BaseButton_69;
	params.bIsSelected_69 = bIsSelected_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUILegacy.CommonButtonGroupLegacy.OnHandleButtonDoubleClicked
// (Native, Protected)
// Parameters:
// class CommonButtonLegacy*      BaseButton_69                  (Parm, ZeroConstructor, InstancedReference)

void CommonButtonGroupLegacy::OnHandleButtonDoubleClicked(class CommonButtonLegacy* BaseButton_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUILegacy.CommonButtonGroupLegacy.OnHandleButtonDoubleClicked"));

	CommonButtonGroupLegacy_OnHandleButtonDoubleClicked_Params params;
	params.BaseButton_69 = BaseButton_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUILegacy.CommonButtonGroupLegacy.OnHandleButtonClicked
// (Native, Protected)
// Parameters:
// class CommonButtonLegacy*      BaseButton_69                  (Parm, ZeroConstructor, InstancedReference)

void CommonButtonGroupLegacy::OnHandleButtonClicked(class CommonButtonLegacy* BaseButton_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUILegacy.CommonButtonGroupLegacy.OnHandleButtonClicked"));

	CommonButtonGroupLegacy_OnHandleButtonClicked_Params params;
	params.BaseButton_69 = BaseButton_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUILegacy.CommonButtonGroupLegacy.OnButtonUnhovered
// (Native, Protected)
// Parameters:
// class CommonButtonLegacy*      BaseButton_69                  (Parm, ZeroConstructor, InstancedReference)

void CommonButtonGroupLegacy::OnButtonUnhovered(class CommonButtonLegacy* BaseButton_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUILegacy.CommonButtonGroupLegacy.OnButtonUnhovered"));

	CommonButtonGroupLegacy_OnButtonUnhovered_Params params;
	params.BaseButton_69 = BaseButton_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUILegacy.CommonButtonGroupLegacy.OnButtonHovered
// (Native, Protected)
// Parameters:
// class CommonButtonLegacy*      BaseButton_69                  (Parm, ZeroConstructor, InstancedReference)

void CommonButtonGroupLegacy::OnButtonHovered(class CommonButtonLegacy* BaseButton_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUILegacy.CommonButtonGroupLegacy.OnButtonHovered"));

	CommonButtonGroupLegacy_OnButtonHovered_Params params;
	params.BaseButton_69 = BaseButton_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUILegacy.CommonButtonGroupLegacy.HandleOnSelectedButtonChanged
// (Final, Native, Private)
// Parameters:
// class CommonButtonBase*        BaseButton_69                  (Parm, ZeroConstructor, InstancedReference)
// int                            InSelectedButtonIndex_69       (Parm, ZeroConstructor, IsPlainOldData)

void CommonButtonGroupLegacy::HandleOnSelectedButtonChanged(class CommonButtonBase* BaseButton_69, int InSelectedButtonIndex_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUILegacy.CommonButtonGroupLegacy.HandleOnSelectedButtonChanged"));

	CommonButtonGroupLegacy_HandleOnSelectedButtonChanged_Params params;
	params.BaseButton_69 = BaseButton_69;
	params.InSelectedButtonIndex_69 = InSelectedButtonIndex_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUILegacy.CommonButtonGroupLegacy.HandleOnHoveredButtonChanged
// (Final, Native, Private)
// Parameters:
// class CommonButtonBase*        BaseButton_69                  (Parm, ZeroConstructor, InstancedReference)
// int                            InSelectedButtonIndex_69       (Parm, ZeroConstructor, IsPlainOldData)

void CommonButtonGroupLegacy::HandleOnHoveredButtonChanged(class CommonButtonBase* BaseButton_69, int InSelectedButtonIndex_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUILegacy.CommonButtonGroupLegacy.HandleOnHoveredButtonChanged"));

	CommonButtonGroupLegacy_HandleOnHoveredButtonChanged_Params params;
	params.BaseButton_69 = BaseButton_69;
	params.InSelectedButtonIndex_69 = InSelectedButtonIndex_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUILegacy.CommonButtonGroupLegacy.HandleOnButtonDoubleClicked
// (Final, Native, Private)
// Parameters:
// class CommonButtonBase*        BaseButton_69                  (Parm, ZeroConstructor, InstancedReference)
// int                            InSelectedButtonIndex_69       (Parm, ZeroConstructor, IsPlainOldData)

void CommonButtonGroupLegacy::HandleOnButtonDoubleClicked(class CommonButtonBase* BaseButton_69, int InSelectedButtonIndex_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUILegacy.CommonButtonGroupLegacy.HandleOnButtonDoubleClicked"));

	CommonButtonGroupLegacy_HandleOnButtonDoubleClicked_Params params;
	params.BaseButton_69 = BaseButton_69;
	params.InSelectedButtonIndex_69 = InSelectedButtonIndex_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUILegacy.CommonButtonGroupLegacy.HandleOnButtonClicked
// (Final, Native, Private)
// Parameters:
// class CommonButtonBase*        BaseButton_69                  (Parm, ZeroConstructor, InstancedReference)
// int                            InSelectedButtonIndex_69       (Parm, ZeroConstructor, IsPlainOldData)

void CommonButtonGroupLegacy::HandleOnButtonClicked(class CommonButtonBase* BaseButton_69, int InSelectedButtonIndex_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUILegacy.CommonButtonGroupLegacy.HandleOnButtonClicked"));

	CommonButtonGroupLegacy_HandleOnButtonClicked_Params params;
	params.BaseButton_69 = BaseButton_69;
	params.InSelectedButtonIndex_69 = InSelectedButtonIndex_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUILegacy.CommonButtonGroupLegacy.HandleNativeOnSelectedButtonChanged
// (Final, Native, Private)
// Parameters:
// class CommonButtonBase*        BaseButton_69                  (Parm, ZeroConstructor, InstancedReference)
// int                            InSelectedButtonIndex_69       (Parm, ZeroConstructor, IsPlainOldData)

void CommonButtonGroupLegacy::HandleNativeOnSelectedButtonChanged(class CommonButtonBase* BaseButton_69, int InSelectedButtonIndex_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUILegacy.CommonButtonGroupLegacy.HandleNativeOnSelectedButtonChanged"));

	CommonButtonGroupLegacy_HandleNativeOnSelectedButtonChanged_Params params;
	params.BaseButton_69 = BaseButton_69;
	params.InSelectedButtonIndex_69 = InSelectedButtonIndex_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUILegacy.CommonButtonGroupLegacy.HandleNativeOnHoveredButtonChanged
// (Final, Native, Private)
// Parameters:
// class CommonButtonBase*        BaseButton_69                  (Parm, ZeroConstructor, InstancedReference)
// int                            InSelectedButtonIndex_69       (Parm, ZeroConstructor, IsPlainOldData)

void CommonButtonGroupLegacy::HandleNativeOnHoveredButtonChanged(class CommonButtonBase* BaseButton_69, int InSelectedButtonIndex_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUILegacy.CommonButtonGroupLegacy.HandleNativeOnHoveredButtonChanged"));

	CommonButtonGroupLegacy_HandleNativeOnHoveredButtonChanged_Params params;
	params.BaseButton_69 = BaseButton_69;
	params.InSelectedButtonIndex_69 = InSelectedButtonIndex_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUILegacy.CommonButtonGroupLegacy.HandleNativeOnButtonDoubleClicked
// (Final, Native, Private)
// Parameters:
// class CommonButtonBase*        BaseButton_69                  (Parm, ZeroConstructor, InstancedReference)
// int                            InSelectedButtonIndex_69       (Parm, ZeroConstructor, IsPlainOldData)

void CommonButtonGroupLegacy::HandleNativeOnButtonDoubleClicked(class CommonButtonBase* BaseButton_69, int InSelectedButtonIndex_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUILegacy.CommonButtonGroupLegacy.HandleNativeOnButtonDoubleClicked"));

	CommonButtonGroupLegacy_HandleNativeOnButtonDoubleClicked_Params params;
	params.BaseButton_69 = BaseButton_69;
	params.InSelectedButtonIndex_69 = InSelectedButtonIndex_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUILegacy.CommonButtonGroupLegacy.HandleNativeOnButtonClicked
// (Final, Native, Private)
// Parameters:
// class CommonButtonBase*        BaseButton_69                  (Parm, ZeroConstructor, InstancedReference)
// int                            InSelectedButtonIndex_69       (Parm, ZeroConstructor, IsPlainOldData)

void CommonButtonGroupLegacy::HandleNativeOnButtonClicked(class CommonButtonBase* BaseButton_69, int InSelectedButtonIndex_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUILegacy.CommonButtonGroupLegacy.HandleNativeOnButtonClicked"));

	CommonButtonGroupLegacy_HandleNativeOnButtonClicked_Params params;
	params.BaseButton_69 = BaseButton_69;
	params.InSelectedButtonIndex_69 = InSelectedButtonIndex_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUILegacy.CommonButtonGroupLegacy.GetSelectedButton
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// class CommonButtonLegacy*      ReturnValue_69                 (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)

class CommonButtonLegacy* CommonButtonGroupLegacy::GetSelectedButton()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUILegacy.CommonButtonGroupLegacy.GetSelectedButton"));

	CommonButtonGroupLegacy_GetSelectedButton_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CommonUILegacy.CommonButtonGroupLegacy.GetButtonAtIndex
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// int                            Index_69                       (Parm, ZeroConstructor, IsPlainOldData)
// class CommonButtonLegacy*      ReturnValue_69                 (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)

class CommonButtonLegacy* CommonButtonGroupLegacy::GetButtonAtIndex(int Index_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUILegacy.CommonButtonGroupLegacy.GetButtonAtIndex"));

	CommonButtonGroupLegacy_GetButtonAtIndex_Params params;
	params.Index_69 = Index_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CommonUILegacy.CommonButtonGroupLegacy.CreateButtonGroup
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// class Object_32759*            ContextObject_69               (Parm, ZeroConstructor)
// bool                           bInSelectionRequired_69        (Parm, ZeroConstructor, IsPlainOldData)
// class CommonButtonGroupLegacy* ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

class CommonButtonGroupLegacy* CommonButtonGroupLegacy::STATIC_CreateButtonGroup(class Object_32759* ContextObject_69, bool bInSelectionRequired_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUILegacy.CommonButtonGroupLegacy.CreateButtonGroup"));

	CommonButtonGroupLegacy_CreateButtonGroup_Params params;
	params.ContextObject_69 = ContextObject_69;
	params.bInSelectionRequired_69 = bInSelectionRequired_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CommonUILegacy.CommonButtonLegacy.SetTriggeredInputActionLegacy
// (Final, Native, Public, HasOutParms, BlueprintCallable)
// Parameters:
// struct FDataTableRowHandle     InputActionRow_69              (ConstParm, Parm, OutParm, ReferenceParm)
// class CommonActivatablePanelLegacy* OldPanel_69                    (Parm, ZeroConstructor, InstancedReference)

void CommonButtonLegacy::SetTriggeredInputActionLegacy(const struct FDataTableRowHandle& InputActionRow_69, class CommonActivatablePanelLegacy* OldPanel_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUILegacy.CommonButtonLegacy.SetTriggeredInputActionLegacy"));

	CommonButtonLegacy_SetTriggeredInputActionLegacy_Params params;
	params.InputActionRow_69 = InputActionRow_69;
	params.OldPanel_69 = OldPanel_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUILegacy.CommonButtonLegacy.HandleOnSelectedChanged
// (Final, Native, Private)
// Parameters:
// class CommonButtonBase*        Button_69                      (Parm, ZeroConstructor, InstancedReference)
// bool                           InSelected_69                  (Parm, ZeroConstructor, IsPlainOldData)

void CommonButtonLegacy::HandleOnSelectedChanged(class CommonButtonBase* Button_69, bool InSelected_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUILegacy.CommonButtonLegacy.HandleOnSelectedChanged"));

	CommonButtonLegacy_HandleOnSelectedChanged_Params params;
	params.Button_69 = Button_69;
	params.InSelected_69 = InSelected_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUILegacy.CommonButtonLegacy.HandleOnButtonUnhovered
// (Final, Native, Private)
// Parameters:
// class CommonButtonBase*        Button_69                      (Parm, ZeroConstructor, InstancedReference)

void CommonButtonLegacy::HandleOnButtonUnhovered(class CommonButtonBase* Button_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUILegacy.CommonButtonLegacy.HandleOnButtonUnhovered"));

	CommonButtonLegacy_HandleOnButtonUnhovered_Params params;
	params.Button_69 = Button_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUILegacy.CommonButtonLegacy.HandleOnButtonHovered
// (Final, Native, Private)
// Parameters:
// class CommonButtonBase*        Button_69                      (Parm, ZeroConstructor, InstancedReference)

void CommonButtonLegacy::HandleOnButtonHovered(class CommonButtonBase* Button_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUILegacy.CommonButtonLegacy.HandleOnButtonHovered"));

	CommonButtonLegacy_HandleOnButtonHovered_Params params;
	params.Button_69 = Button_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUILegacy.CommonButtonLegacy.HandleOnButtonDoubleClicked
// (Final, Native, Private)
// Parameters:
// class CommonButtonBase*        Button_69                      (Parm, ZeroConstructor, InstancedReference)

void CommonButtonLegacy::HandleOnButtonDoubleClicked(class CommonButtonBase* Button_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUILegacy.CommonButtonLegacy.HandleOnButtonDoubleClicked"));

	CommonButtonLegacy_HandleOnButtonDoubleClicked_Params params;
	params.Button_69 = Button_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUILegacy.CommonButtonLegacy.HandleOnButtonClicked
// (Final, Native, Private)
// Parameters:
// class CommonButtonBase*        Button_69                      (Parm, ZeroConstructor, InstancedReference)

void CommonButtonLegacy::HandleOnButtonClicked(class CommonButtonBase* Button_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUILegacy.CommonButtonLegacy.HandleOnButtonClicked"));

	CommonButtonLegacy_HandleOnButtonClicked_Params params;
	params.Button_69 = Button_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUILegacy.CommonInputManagerLegacy.SuspendStartingOperationProcessing
// (Final, Native, Public, BlueprintCallable)

void CommonInputManagerLegacy::SuspendStartingOperationProcessing()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUILegacy.CommonInputManagerLegacy.SuspendStartingOperationProcessing"));

	CommonInputManagerLegacy_SuspendStartingOperationProcessing_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUILegacy.CommonInputManagerLegacy.StopListeningForExistingHeldAction
// (Final, Native, Public, HasOutParms, BlueprintCallable)
// Parameters:
// struct FDataTableRowHandle     InputActionDataRow_69          (ConstParm, Parm, OutParm, ReferenceParm)
// struct FScriptDelegate         CompleteEvent_69               (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
// struct FScriptDelegate         ProgressEvent_69               (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool CommonInputManagerLegacy::StopListeningForExistingHeldAction(const struct FDataTableRowHandle& InputActionDataRow_69, const struct FScriptDelegate& CompleteEvent_69, const struct FScriptDelegate& ProgressEvent_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUILegacy.CommonInputManagerLegacy.StopListeningForExistingHeldAction"));

	CommonInputManagerLegacy_StopListeningForExistingHeldAction_Params params;
	params.InputActionDataRow_69 = InputActionDataRow_69;
	params.CompleteEvent_69 = CompleteEvent_69;
	params.ProgressEvent_69 = ProgressEvent_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CommonUILegacy.CommonInputManagerLegacy.StartListeningForExistingHeldAction
// (Final, Native, Public, HasOutParms, BlueprintCallable)
// Parameters:
// struct FDataTableRowHandle     InputActionDataRow_69          (ConstParm, Parm, OutParm, ReferenceParm)
// struct FScriptDelegate         CompleteEvent_69               (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
// struct FScriptDelegate         ProgressEvent_69               (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool CommonInputManagerLegacy::StartListeningForExistingHeldAction(const struct FDataTableRowHandle& InputActionDataRow_69, const struct FScriptDelegate& CompleteEvent_69, const struct FScriptDelegate& ProgressEvent_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUILegacy.CommonInputManagerLegacy.StartListeningForExistingHeldAction"));

	CommonInputManagerLegacy_StartListeningForExistingHeldAction_Params params;
	params.InputActionDataRow_69 = InputActionDataRow_69;
	params.CompleteEvent_69 = CompleteEvent_69;
	params.ProgressEvent_69 = ProgressEvent_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CommonUILegacy.CommonInputManagerLegacy.SetGlobalInputHandlerPriorityFilter
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// int                            InFilterPriority_69            (Parm, ZeroConstructor, IsPlainOldData)

void CommonInputManagerLegacy::SetGlobalInputHandlerPriorityFilter(int InFilterPriority_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUILegacy.CommonInputManagerLegacy.SetGlobalInputHandlerPriorityFilter"));

	CommonInputManagerLegacy_SetGlobalInputHandlerPriorityFilter_Params params;
	params.InFilterPriority_69 = InFilterPriority_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUILegacy.CommonInputManagerLegacy.ResumeStartingOperationProcessing
// (Final, Native, Public, BlueprintCallable)

void CommonInputManagerLegacy::ResumeStartingOperationProcessing()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUILegacy.CommonInputManagerLegacy.ResumeStartingOperationProcessing"));

	CommonInputManagerLegacy_ResumeStartingOperationProcessing_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUILegacy.CommonInputManagerLegacy.PushActivatablePanel
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// class CommonActivatablePanelLegacy* ActivatablePanel_69            (Parm, ZeroConstructor, InstancedReference)
// bool                           bIntroPanel_69                 (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bOutroPanelBelow_69            (Parm, ZeroConstructor, IsPlainOldData)

void CommonInputManagerLegacy::PushActivatablePanel(class CommonActivatablePanelLegacy* ActivatablePanel_69, bool bIntroPanel_69, bool bOutroPanelBelow_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUILegacy.CommonInputManagerLegacy.PushActivatablePanel"));

	CommonInputManagerLegacy_PushActivatablePanel_Params params;
	params.ActivatablePanel_69 = ActivatablePanel_69;
	params.bIntroPanel_69 = bIntroPanel_69;
	params.bOutroPanelBelow_69 = bOutroPanelBelow_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUILegacy.CommonInputManagerLegacy.PopActivatablePanel
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// class CommonActivatablePanelLegacy* ActivatablePanel_69            (Parm, ZeroConstructor, InstancedReference)

void CommonInputManagerLegacy::PopActivatablePanel(class CommonActivatablePanelLegacy* ActivatablePanel_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUILegacy.CommonInputManagerLegacy.PopActivatablePanel"));

	CommonInputManagerLegacy_PopActivatablePanel_Params params;
	params.ActivatablePanel_69 = ActivatablePanel_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUILegacy.CommonInputManagerLegacy.IsPanelOnStack
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// class CommonActivatablePanelLegacy* InPanel_69                     (ConstParm, Parm, ZeroConstructor, InstancedReference)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool CommonInputManagerLegacy::IsPanelOnStack(class CommonActivatablePanelLegacy* InPanel_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUILegacy.CommonInputManagerLegacy.IsPanelOnStack"));

	CommonInputManagerLegacy_IsPanelOnStack_Params params;
	params.InPanel_69 = InPanel_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CommonUILegacy.CommonInputManagerLegacy.IsInputSuspended
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool CommonInputManagerLegacy::IsInputSuspended()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUILegacy.CommonInputManagerLegacy.IsInputSuspended"));

	CommonInputManagerLegacy_IsInputSuspended_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CommonUILegacy.CommonInputManagerLegacy.GetTopPanel
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// class CommonActivatablePanelLegacy* ReturnValue_69                 (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)

class CommonActivatablePanelLegacy* CommonInputManagerLegacy::GetTopPanel()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUILegacy.CommonInputManagerLegacy.GetTopPanel"));

	CommonInputManagerLegacy_GetTopPanel_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CommonUILegacy.CommonInputManagerLegacy.GetGlobalInputHandlerPriorityFilter
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// int                            ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int CommonInputManagerLegacy::GetGlobalInputHandlerPriorityFilter()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUILegacy.CommonInputManagerLegacy.GetGlobalInputHandlerPriorityFilter"));

	CommonInputManagerLegacy_GetGlobalInputHandlerPriorityFilter_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CommonUILegacy.CommonInputManagerLegacy.GetAvailableInputActions
// (Final, Native, Public, HasOutParms, BlueprintCallable)
// Parameters:
// TArray<struct FCommonInputActionHandlerData> AvailableInputActions_69       (Parm, OutParm, ZeroConstructor)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool CommonInputManagerLegacy::GetAvailableInputActions(TArray<struct FCommonInputActionHandlerData>* AvailableInputActions_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUILegacy.CommonInputManagerLegacy.GetAvailableInputActions"));

	CommonInputManagerLegacy_GetAvailableInputActions_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (AvailableInputActions_69 != nullptr)
		*AvailableInputActions_69 = params.AvailableInputActions_69;

	return params.ReturnValue_69;
}


// Function CommonUILegacy.CommonInputReflectorLegacy.OnButtonAdded
// (Event, Public, HasOutParms, BlueprintEvent)
// Parameters:
// class CommonButtonLegacy*      AddedButton_69                 (Parm, ZeroConstructor, InstancedReference)
// struct FCommonInputActionHandlerData Data_69                        (ConstParm, Parm, OutParm, ReferenceParm)

void CommonInputReflectorLegacy::OnButtonAdded(class CommonButtonLegacy* AddedButton_69, const struct FCommonInputActionHandlerData& Data_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUILegacy.CommonInputReflectorLegacy.OnButtonAdded"));

	CommonInputReflectorLegacy_OnButtonAdded_Params params;
	params.AddedButton_69 = AddedButton_69;
	params.Data_69 = Data_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUILegacy.CommonPopupButtonLegacy.GetMenuAnchorWidget
// (Final, Native, Private)
// Parameters:
// class UserWidget*              ReturnValue_69                 (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)

class UserWidget* CommonPopupButtonLegacy::GetMenuAnchorWidget()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUILegacy.CommonPopupButtonLegacy.GetMenuAnchorWidget"));

	CommonPopupButtonLegacy_GetMenuAnchorWidget_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CommonUILegacy.CommonPopupMenuLegacy.SetOwningMenuAnchor
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// class MenuAnchor*              MenuAnchor_69                  (ConstParm, Parm, ZeroConstructor, InstancedReference)

void CommonPopupMenuLegacy::SetOwningMenuAnchor(class MenuAnchor* MenuAnchor_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUILegacy.CommonPopupMenuLegacy.SetOwningMenuAnchor"));

	CommonPopupMenuLegacy_SetOwningMenuAnchor_Params params;
	params.MenuAnchor_69 = MenuAnchor_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUILegacy.CommonPopupMenuLegacy.SetContextProvider
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// class Object_32759*            ContextProvidingObject_69      (ConstParm, Parm, ZeroConstructor)

void CommonPopupMenuLegacy::SetContextProvider(class Object_32759* ContextProvidingObject_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUILegacy.CommonPopupMenuLegacy.SetContextProvider"));

	CommonPopupMenuLegacy_SetContextProvider_Params params;
	params.ContextProvidingObject_69 = ContextProvidingObject_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUILegacy.CommonPopupMenuLegacy.RequestClose
// (Final, Native, Protected, BlueprintCallable)

void CommonPopupMenuLegacy::RequestClose()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUILegacy.CommonPopupMenuLegacy.RequestClose"));

	CommonPopupMenuLegacy_RequestClose_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUILegacy.CommonPopupMenuLegacy.OnIsOpenChanged
// (Final, Native, Protected)
// Parameters:
// bool                           IsOpen_69                      (Parm, ZeroConstructor, IsPlainOldData)

void CommonPopupMenuLegacy::OnIsOpenChanged(bool IsOpen_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUILegacy.CommonPopupMenuLegacy.OnIsOpenChanged"));

	CommonPopupMenuLegacy_OnIsOpenChanged_Params params;
	params.IsOpen_69 = IsOpen_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUILegacy.CommonPopupMenuLegacy.HandlePreDifferentContextProviderSet
// (Native, Event, Protected, BlueprintEvent)

void CommonPopupMenuLegacy::HandlePreDifferentContextProviderSet()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUILegacy.CommonPopupMenuLegacy.HandlePreDifferentContextProviderSet"));

	CommonPopupMenuLegacy_HandlePreDifferentContextProviderSet_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUILegacy.CommonPopupMenuLegacy.HandlePostDifferentContextProviderSet
// (Native, Event, Protected, BlueprintEvent)

void CommonPopupMenuLegacy::HandlePostDifferentContextProviderSet()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUILegacy.CommonPopupMenuLegacy.HandlePostDifferentContextProviderSet"));

	CommonPopupMenuLegacy_HandlePostDifferentContextProviderSet_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// DelegateFunction CommonUILegacy.CommonTabListWidgetLegacy.OnTabButtonRemoved__DelegateSignature
// (MulticastDelegate, Public, Delegate)
// Parameters:
// struct FName                   TabId_69                       (Parm, ZeroConstructor, IsPlainOldData)
// class CommonButtonLegacy*      TabButton_69                   (Parm, ZeroConstructor, InstancedReference)

void CommonTabListWidgetLegacy::OnTabButtonRemoved__DelegateSignature(const struct FName& TabId_69, class CommonButtonLegacy* TabButton_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("DelegateFunction CommonUILegacy.CommonTabListWidgetLegacy.OnTabButtonRemoved__DelegateSignature"));

	CommonTabListWidgetLegacy_OnTabButtonRemoved__DelegateSignature_Params params;
	params.TabId_69 = TabId_69;
	params.TabButton_69 = TabButton_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// DelegateFunction CommonUILegacy.CommonTabListWidgetLegacy.OnTabButtonCreated__DelegateSignature
// (MulticastDelegate, Public, Delegate)
// Parameters:
// struct FName                   TabId_69                       (Parm, ZeroConstructor, IsPlainOldData)
// class CommonButtonLegacy*      TabButton_69                   (Parm, ZeroConstructor, InstancedReference)

void CommonTabListWidgetLegacy::OnTabButtonCreated__DelegateSignature(const struct FName& TabId_69, class CommonButtonLegacy* TabButton_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("DelegateFunction CommonUILegacy.CommonTabListWidgetLegacy.OnTabButtonCreated__DelegateSignature"));

	CommonTabListWidgetLegacy_OnTabButtonCreated__DelegateSignature_Params params;
	params.TabId_69 = TabId_69;
	params.TabButton_69 = TabButton_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUILegacy.CommonTabListWidgetLegacy.HandleTabRemoved
// (Native, Event, Protected, BlueprintEvent)
// Parameters:
// struct FName                   TabNameID_69                   (Parm, ZeroConstructor, IsPlainOldData)
// class CommonButtonLegacy*      TabButton_69                   (Parm, ZeroConstructor, InstancedReference)

void CommonTabListWidgetLegacy::HandleTabRemoved(const struct FName& TabNameID_69, class CommonButtonLegacy* TabButton_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUILegacy.CommonTabListWidgetLegacy.HandleTabRemoved"));

	CommonTabListWidgetLegacy_HandleTabRemoved_Params params;
	params.TabNameID_69 = TabNameID_69;
	params.TabButton_69 = TabButton_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUILegacy.CommonTabListWidgetLegacy.HandleTabCreated
// (Native, Event, Protected, BlueprintEvent)
// Parameters:
// struct FName                   TabNameID_69                   (Parm, ZeroConstructor, IsPlainOldData)
// class CommonButtonLegacy*      TabButton_69                   (Parm, ZeroConstructor, InstancedReference)

void CommonTabListWidgetLegacy::HandleTabCreated(const struct FName& TabNameID_69, class CommonButtonLegacy* TabButton_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUILegacy.CommonTabListWidgetLegacy.HandleTabCreated"));

	CommonTabListWidgetLegacy_HandleTabCreated_Params params;
	params.TabNameID_69 = TabNameID_69;
	params.TabButton_69 = TabButton_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUILegacy.CommonTabListWidgetLegacy.HandleOnTabButtonRemoved
// (Final, Native, Private)
// Parameters:
// struct FName                   TabId_69                       (Parm, ZeroConstructor, IsPlainOldData)
// class CommonButtonBase*        TabButton_69                   (Parm, ZeroConstructor, InstancedReference)

void CommonTabListWidgetLegacy::HandleOnTabButtonRemoved(const struct FName& TabId_69, class CommonButtonBase* TabButton_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUILegacy.CommonTabListWidgetLegacy.HandleOnTabButtonRemoved"));

	CommonTabListWidgetLegacy_HandleOnTabButtonRemoved_Params params;
	params.TabId_69 = TabId_69;
	params.TabButton_69 = TabButton_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUILegacy.CommonTabListWidgetLegacy.HandleOnTabButtonCreated
// (Final, Native, Private)
// Parameters:
// struct FName                   TabId_69                       (Parm, ZeroConstructor, IsPlainOldData)
// class CommonButtonBase*        TabButton_69                   (Parm, ZeroConstructor, InstancedReference)

void CommonTabListWidgetLegacy::HandleOnTabButtonCreated(const struct FName& TabId_69, class CommonButtonBase* TabButton_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUILegacy.CommonTabListWidgetLegacy.HandleOnTabButtonCreated"));

	CommonTabListWidgetLegacy_HandleOnTabButtonCreated_Params params;
	params.TabId_69 = TabId_69;
	params.TabButton_69 = TabButton_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUILegacy.CommonTabListWidgetLegacy.GetTabButtonByID
// (Final, Native, Protected, BlueprintCallable)
// Parameters:
// struct FName                   TabNameID_69                   (Parm, ZeroConstructor, IsPlainOldData)
// class CommonButtonLegacy*      ReturnValue_69                 (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)

class CommonButtonLegacy* CommonTabListWidgetLegacy::GetTabButtonByID(const struct FName& TabNameID_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUILegacy.CommonTabListWidgetLegacy.GetTabButtonByID"));

	CommonTabListWidgetLegacy_GetTabButtonByID_Params params;
	params.TabNameID_69 = TabNameID_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// DelegateFunction CommonUILegacy.CommonUISubsystemLegacy.InputSuspensionChanged__DelegateSignature
// (MulticastDelegate, Public, Delegate)
// Parameters:
// bool                           bInputSuspended_69             (Parm, ZeroConstructor, IsPlainOldData)

void CommonUISubsystemLegacy::InputSuspensionChanged__DelegateSignature(bool bInputSuspended_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("DelegateFunction CommonUILegacy.CommonUISubsystemLegacy.InputSuspensionChanged__DelegateSignature"));

	CommonUISubsystemLegacy_InputSuspensionChanged__DelegateSignature_Params params;
	params.bInputSuspended_69 = bInputSuspended_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUILegacy.CommonUISubsystemLegacy.GetInputManager
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// class CommonInputManagerLegacy* ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

class CommonInputManagerLegacy* CommonUISubsystemLegacy::GetInputManager()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUILegacy.CommonUISubsystemLegacy.GetInputManager"));

	CommonUISubsystemLegacy_GetInputManager_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CommonUILegacy.CommonWidgetStackLegacy.PushWidget
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// class Widget*                  InWidget_69                    (Parm, ZeroConstructor, InstancedReference)

void CommonWidgetStackLegacy::PushWidget(class Widget* InWidget_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUILegacy.CommonWidgetStackLegacy.PushWidget"));

	CommonWidgetStackLegacy_PushWidget_Params params;
	params.InWidget_69 = InWidget_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUILegacy.CommonWidgetStackLegacy.PopWidget
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// class Widget*                  ReturnValue_69                 (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)

class Widget* CommonWidgetStackLegacy::PopWidget()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUILegacy.CommonWidgetStackLegacy.PopWidget"));

	CommonWidgetStackLegacy_PopWidget_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// DelegateFunction CommonUILegacy.CommonWidgetStackLegacy.OnActiveWidgetChangedLegacy__DelegateSignature
// (MulticastDelegate, Public, Delegate)
// Parameters:
// class Widget*                  InActiveWidget_69              (Parm, ZeroConstructor, InstancedReference)
// int                            InActiveWidgetIndex_69         (Parm, ZeroConstructor, IsPlainOldData)

void CommonWidgetStackLegacy::OnActiveWidgetChangedLegacy__DelegateSignature(class Widget* InActiveWidget_69, int InActiveWidgetIndex_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("DelegateFunction CommonUILegacy.CommonWidgetStackLegacy.OnActiveWidgetChangedLegacy__DelegateSignature"));

	CommonWidgetStackLegacy_OnActiveWidgetChangedLegacy__DelegateSignature_Params params;
	params.InActiveWidget_69 = InActiveWidget_69;
	params.InActiveWidgetIndex_69 = InActiveWidgetIndex_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUILegacy.CommonWidgetStackLegacy.DeactivateWidget
// (Final, Native, Protected, BlueprintCallable)

void CommonWidgetStackLegacy::DeactivateWidget()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUILegacy.CommonWidgetStackLegacy.DeactivateWidget"));

	CommonWidgetStackLegacy_DeactivateWidget_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUILegacy.CommonWidgetStackLegacy.ActivateWidget
// (Final, Native, Protected, BlueprintCallable)

void CommonWidgetStackLegacy::ActivateWidget()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUILegacy.CommonWidgetStackLegacy.ActivateWidget"));

	CommonWidgetStackLegacy_ActivateWidget_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUILegacy.CommonWidgetSwitcherLegacy.SetActiveWidgetIndex_Advanced
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// int                            Index_69                       (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// bool                           AttemptActivationChange_69     (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void CommonWidgetSwitcherLegacy::SetActiveWidgetIndex_Advanced(int Index_69, bool AttemptActivationChange_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUILegacy.CommonWidgetSwitcherLegacy.SetActiveWidgetIndex_Advanced"));

	CommonWidgetSwitcherLegacy_SetActiveWidgetIndex_Advanced_Params params;
	params.Index_69 = Index_69;
	params.AttemptActivationChange_69 = AttemptActivationChange_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUILegacy.CommonWidgetSwitcherLegacy.SetActiveWidget_Advanced
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// class Widget*                  Widget_69                      (Parm, ZeroConstructor, InstancedReference)
// bool                           AttemptActivationChange_69     (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void CommonWidgetSwitcherLegacy::SetActiveWidget_Advanced(class Widget* Widget_69, bool AttemptActivationChange_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUILegacy.CommonWidgetSwitcherLegacy.SetActiveWidget_Advanced"));

	CommonWidgetSwitcherLegacy_SetActiveWidget_Advanced_Params params;
	params.Widget_69 = Widget_69;
	params.AttemptActivationChange_69 = AttemptActivationChange_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUILegacy.CommonWidgetSwitcherLegacy.HandleActiveWidgetDeactivated
// (Final, Native, Private)
// Parameters:
// class CommonActivatablePanelLegacy* DeactivatedPanel_69            (Parm, ZeroConstructor, InstancedReference)

void CommonWidgetSwitcherLegacy::HandleActiveWidgetDeactivated(class CommonActivatablePanelLegacy* DeactivatedPanel_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUILegacy.CommonWidgetSwitcherLegacy.HandleActiveWidgetDeactivated"));

	CommonWidgetSwitcherLegacy_HandleActiveWidgetDeactivated_Params params;
	params.DeactivatedPanel_69 = DeactivatedPanel_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUILegacy.CommonWidgetSwitcherLegacy.DeactivateWidget
// (Native, Public, BlueprintCallable)

void CommonWidgetSwitcherLegacy::DeactivateWidget()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUILegacy.CommonWidgetSwitcherLegacy.DeactivateWidget"));

	CommonWidgetSwitcherLegacy_DeactivateWidget_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CommonUILegacy.CommonWidgetSwitcherLegacy.ActivateWidget
// (Native, Public, BlueprintCallable)

void CommonWidgetSwitcherLegacy::ActivateWidget()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CommonUILegacy.CommonWidgetSwitcherLegacy.ActivateWidget"));

	CommonWidgetSwitcherLegacy_ActivateWidget_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

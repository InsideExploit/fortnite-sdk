#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Classes
//---------------------------------------------------------------------------

// Class CraftingUI.FortCraftingListItem
// 0x00D0 (0x00F8 - 0x0028)
class FortCraftingListItem : public Object_32759
{
public:
	unsigned char                                      UnknownData00[0xD0];                                      // 0x0028(0x00D0) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CraftingUI.FortCraftingListItem"));
		
		return ptr;
	}

};


// Class CraftingUI.AthenaCraftingQuickBarButton
// 0x0020 (0x1410 - 0x13F0)
class AthenaCraftingQuickBarButton : public AthenaQuickBarSlotButtonBase
{
public:
	unsigned char                                      UnknownData00[0x20];                                      // 0x13F0(0x0020) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CraftingUI.AthenaCraftingQuickBarButton"));
		
		return ptr;
	}


	void OnIsCraftableItemChanged(bool bIsCraftableItem_69);
	void OnCanCraftNowChanged(bool bCanCraftNow_69);
};


// Class CraftingUI.AthenaEquippedItemCraftingIndicator
// 0x0020 (0x02B0 - 0x0290)
class AthenaEquippedItemCraftingIndicator : public CommonUserWidget
{
public:
	unsigned char                                      UnknownData00[0x20];                                      // 0x0290(0x0020) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CraftingUI.AthenaEquippedItemCraftingIndicator"));
		
		return ptr;
	}


	void OnIsCraftableItemChanged(bool bIsCraftableItem_69);
	void OnCanCraftNowChanged(bool bCanCraftNow_69);
	void HandleWeaponEquipped(class FortWeapon* NewWeapon_69, class FortWeapon* PrevWeapon_69);
};


// Class CraftingUI.AthenaInventoryItemInfoCraftingIndicator
// 0x0020 (0x02B0 - 0x0290)
class AthenaInventoryItemInfoCraftingIndicator : public CommonUserWidget
{
public:
	unsigned char                                      UnknownData00[0x20];                                      // 0x0290(0x0020) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CraftingUI.AthenaInventoryItemInfoCraftingIndicator"));
		
		return ptr;
	}


	void OnIsCraftableItemChanged(bool bIsCraftableItem_69);
	void OnCanCraftNowChanged(bool bCanCraftNow_69);
	void HandleInventoryItemSelected(class FortItem* SelectedItem_69);
};


// Class CraftingUI.AthenaQuickBarSlotCraftingIndicator
// 0x0030 (0x02C8 - 0x0298)
class AthenaQuickBarSlotCraftingIndicator : public AthenaQuickBarSlotExtensionWidgetBase
{
public:
	unsigned char                                      UnknownData00[0x20];                                      // 0x0298(0x0020) MISSED OFFSET
	bool                                               bCheckForIngredientChangesWhenCraftable_69;               // 0x02B8(0x0001) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData01[0xF];                                       // 0x02B9(0x000F) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CraftingUI.AthenaQuickBarSlotCraftingIndicator"));
		
		return ptr;
	}


	void OnIsCraftableItemChanged(bool bIsCraftableItem_69);
	void OnIngredientChanged(bool bCanCraftNow_69);
	void OnCanCraftNowChanged(bool bCanCraftNow_69);
	void HandleWeaponEquipped(class FortWeapon* NewWeapon_69, class FortWeapon* PrevWeapon_69);
};


// Class CraftingUI.FortCookingScreen
// 0x0050 (0x03F8 - 0x03A8)
class FortCookingScreen : public CommonActivatableWidget
{
public:
	unsigned char                                      UnknownData00[0x8];                                       // 0x03A8(0x0008) MISSED OFFSET
	struct FDataTableRowHandle                         CloseInputAction_69;                                      // 0x03B0(0x0010) (Edit)
	unsigned char                                      UnknownData01[0x8];                                       // 0x03C0(0x0008) MISSED OFFSET
	class CommonButtonLegacy*                          Button_EjectAll_69;                                       // 0x03C8(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	class CommonButtonLegacy*                          Button_Cancel_69;                                         // 0x03D0(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	class CommonTextBlock*                             Text_RecipeName_69;                                       // 0x03D8(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	class CommonTextBlock*                             Text_RecipeDescription_69;                                // 0x03E0(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	class Image*                                       Image_Recipe_69;                                          // 0x03E8(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	class FortSlottedRadialMenu*                       RadialMenu_Recipes_69;                                    // 0x03F0(0x0008) (ExportObject, ZeroConstructor, InstancedReference)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CraftingUI.FortCookingScreen"));
		
		return ptr;
	}

};


// Class CraftingUI.FortCraftingFormulaIngredientsWidget
// 0x0008 (0x0298 - 0x0290)
class FortCraftingFormulaIngredientsWidget : public CommonUserWidget
{
public:
	class DynamicEntryBox*                             EntryBox_Ingredients_69;                                  // 0x0290(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CraftingUI.FortCraftingFormulaIngredientsWidget"));
		
		return ptr;
	}

};


// Class CraftingUI.FortCraftingIngredientWidget
// 0x0028 (0x02B8 - 0x0290)
class FortCraftingIngredientWidget : public CommonUserWidget
{
public:
	unsigned char                                      UnknownData00[0x8];                                       // 0x0290(0x0008) MISSED OFFSET
	class CommonTextBlock*                             Text_NumAvailable_69;                                     // 0x0298(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)
	class CommonTextBlock*                             Text_NumRequired_69;                                      // 0x02A0(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)
	class AthenaItemIcon*                              ItemIcon_69;                                              // 0x02A8(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)
	class CommonLazyImage*                             LazyImage_Icon_69;                                        // 0x02B0(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CraftingUI.FortCraftingIngredientWidget"));
		
		return ptr;
	}


	void OnIngredientWidgetUpdated(int NumAvailable_69, int NumRequired_69, bool bIsPrimaryIngredient_69, bool bIsLastIngredient_69);
};


// Class CraftingUI.FortCraftingItemInfoWidget
// 0x0068 (0x0410 - 0x03A8)
class FortCraftingItemInfoWidget : public CommonActivatableWidget
{
public:
	unsigned char                                      UnknownData00[0x8];                                       // 0x03A8(0x0008) MISSED OFFSET
	struct FText                                       RarityTextFormat_69;                                      // 0x03B0(0x0018) (Edit, DisableEditOnInstance)
	class CommonTextBlock*                             Text_ItemName_69;                                         // 0x03C8(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)
	class CommonTextBlock*                             Text_ItemRarity_69;                                       // 0x03D0(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)
	class CommonTextBlock*                             Text_ItemCategory_69;                                     // 0x03D8(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)
	class FortItemCategoryIndicator*                   ItemCategoryIndicator_69;                                 // 0x03E0(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)
	class CommonTextBlock*                             Text_ItemDescription_69;                                  // 0x03E8(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)
	class AthenaInventoryItemStatsWidget*              ItemStatsWidget_69;                                       // 0x03F0(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)
	class FortCraftingFormulaIngredientsWidget*        IngredientsWidget_69;                                     // 0x03F8(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)
	class CommonButtonLegacy*                          Button_StartCrafting_69;                                  // 0x0400(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)
	unsigned char                                      UnknownData01[0x8];                                       // 0x0408(0x0008) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CraftingUI.FortCraftingItemInfoWidget"));
		
		return ptr;
	}


	void OnItemRaritySet(EFortRarity Rarity_69, const struct FFortRarityItemData& RarityItemData_69);
};


// Class CraftingUI.FortCraftingListEntry
// 0x0020 (0x1450 - 0x1430)
class FortCraftingListEntry : public CommonButtonLegacy
{
public:
	unsigned char                                      UnknownData00[0x8];                                       // 0x1430(0x0008) MISSED OFFSET
	class AthenaItemIcon*                              ItemIcon_69;                                              // 0x1438(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)
	bool                                               bCanCraftItem_69;                                         // 0x1440(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0xF];                                       // 0x1441(0x000F) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CraftingUI.FortCraftingListEntry"));
		
		return ptr;
	}


	void OnCraftingListItemSet();
};


// Class CraftingUI.FortCraftingTab
// 0x0138 (0x04E0 - 0x03A8)
class FortCraftingTab : public CommonActivatableWidget
{
public:
	unsigned char                                      UnknownData00[0x8];                                       // 0x03A8(0x0008) MISSED OFFSET
	struct FName                                       TabNameID_69;                                             // 0x03B0(0x0008) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0xC];                                       // 0x03B4(0x000C) MISSED OFFSET
	struct FFortTabButtonLabelInfo                     TabButtonLabelInfo_69;                                    // 0x03C0(0x00E0) (Edit)
	struct FGameplayTagContainer                       PrimaryIngredientTags_69;                                 // 0x04A0(0x0020) (Edit)
	class FortCraftingItemInfoWidget*                  CraftingItemInfo_69;                                      // 0x04C0(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)
	class CommonListView*                              ListView_Recipes_69;                                      // 0x04C8(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)
	class AthenaQuickbarEditorBase*                    QuickbarEditor_69;                                        // 0x04D0(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)
	unsigned char                                      UnknownData02[0x8];                                       // 0x04D8(0x0008) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CraftingUI.FortCraftingTab"));
		
		return ptr;
	}


	void OnFormulaListUpdated(int NumFormulas_69);
	void HandleInventoryItemSelected(class FortItem* Item_69);
};


// Class CraftingUI.FortPotContentsPopup
// 0x0028 (0x0290 - 0x0268)
class FortPotContentsPopup : public UserWidget
{
public:
	int                                                MaxItemsToShow_69;                                        // 0x0268(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0xC];                                       // 0x026C(0x000C) MISSED OFFSET
	class CommonTileView*                              TileView_PotContents_69;                                  // 0x0278(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	class CommonTextBlock*                             Text_MoreItems_69;                                        // 0x0280(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	class Widget*                                      Overlay_Popup_69;                                         // 0x0288(0x0008) (ExportObject, ZeroConstructor, InstancedReference)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CraftingUI.FortPotContentsPopup"));
		
		return ptr;
	}


	void SetOwningCraftingObject(class CraftingObjectBGA* InCraftingObject_69);
};


// Class CraftingUI.FortPotContentsTile
// 0x0010 (0x1440 - 0x1430)
class FortPotContentsTile : public CommonButtonLegacy
{
public:
	unsigned char                                      UnknownData00[0x8];                                       // 0x1430(0x0008) MISSED OFFSET
	class CommonLazyImage*                             Image_Item_69;                                            // 0x1438(0x0008) (ExportObject, ZeroConstructor, InstancedReference)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CraftingUI.FortPotContentsTile"));
		
		return ptr;
	}

};


// Class CraftingUI.FortUIGameFeatureAction_SetCraftMenuWidget
// 0x0038 (0x0060 - 0x0028)
class FortUIGameFeatureAction_SetCraftMenuWidget : public FortUIGameFeatureAction
{
public:
	class CraftingObjectBGA*                           CraftingObject_69;                                        // 0x0028(0x0008) (Edit, ZeroConstructor)
	unsigned char                                      UnknownData00[0x28];                                      // 0x0030(0x0028) UNKNOWN PROPERTY: SoftClassProperty CraftingUI.FortUIGameFeatureAction_SetCraftMenuWidget.CraftingMenuWidget_69
	unsigned char                                      UnknownData01[0x8];                                       // 0x0058(0x0008) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CraftingUI.FortUIGameFeatureAction_SetCraftMenuWidget"));
		
		return ptr;
	}

};


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

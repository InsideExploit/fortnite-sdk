#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Enums
//---------------------------------------------------------------------------

// Enum Constraints.EHandleEvent
enum class EHandleEvent : uint8_t
{
	LocalTransformUpdated          = 0,
	GlobalTransformUpdated         = 1,
	ComponentUpdated               = 2,
	Max                            = 3
};



//---------------------------------------------------------------------------
//Script Structs
//---------------------------------------------------------------------------

// ScriptStruct Constraints.ConstraintTickFunction
// 0x0018 (0x0040 - 0x0028)
struct FConstraintTickFunction : public FTickFunction
{
	unsigned char                                      UnknownData00[0x18];                                      // 0x0028(0x0018) MISSED OFFSET
};

// ScriptStruct Constraints.MovieSceneConstraintChannel
// 0x0000 (0x00D8 - 0x00D8)
struct FMovieSceneConstraintChannel : public FMovieSceneBoolChannel
{

};

// ScriptStruct Constraints.ConstraintAndActiveChannel
// 0x0100
struct FConstraintAndActiveChannel
{
	unsigned char                                      UnknownData00[0x28];                                      // 0x0000(0x0028) UNKNOWN PROPERTY: SoftObjectProperty Constraints.ConstraintAndActiveChannel.Constraint_69
	struct FMovieSceneConstraintChannel                ActiveChannel_69;                                         // 0x0028(0x00D8)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

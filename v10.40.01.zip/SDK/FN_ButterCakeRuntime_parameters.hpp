#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function ButterCakeRuntime.ButterCakeUnstuckComponent.ResetUnstuckLocationSamples
struct ButterCakeUnstuckComponent_ResetUnstuckLocationSamples_Params
{
};

// Function ButterCakeRuntime.ButterCakeUnstuckComponent.HandleAthenaGamePhaseChanged
struct ButterCakeUnstuckComponent_HandleAthenaGamePhaseChanged_Params
{
	EAthenaGamePhase                                   GamePhase_69;                                             // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function ButterCakeRuntime.FortAIAnimInstance_ButterCake.SetFootPhaseMembers
struct FortAIAnimInstance_ButterCake_SetFootPhaseMembers_Params
{
};

// Function ButterCakeRuntime.FortAIAnimInstance_ButterCake.ComputeLeanAngleByVelocity
struct FortAIAnimInstance_ButterCake_ComputeLeanAngleByVelocity_Params
{
	float                                              ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function ButterCakeRuntime.FortAIAnimInstance_ButterCake.ComputeFootPhase
struct FortAIAnimInstance_ButterCake_ComputeFootPhase_Params
{
	EFortButterCakeFootPhase                           ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function ButterCakeRuntime.FortButterCakeComponent_Telemetry.OnLured
struct FortButterCakeComponent_Telemetry_OnLured_Params
{
};

// Function ButterCakeRuntime.FortButterCakeComponent_Telemetry.OnItemsSneezed
struct FortButterCakeComponent_Telemetry_OnItemsSneezed_Params
{
	int                                                ItemsCount_69;                                            // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function ButterCakeRuntime.FortButterCakeComponent_Telemetry.OnItemsEaten
struct FortButterCakeComponent_Telemetry_OnItemsEaten_Params
{
	int                                                ItemsCount_69;                                            // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function ButterCakeRuntime.FortButterCakeComponent_Telemetry.OnEnterBerserk
struct FortButterCakeComponent_Telemetry_OnEnterBerserk_Params
{
	class Controller*                                  Instigator_69;                                            // (ConstParm, Parm, ZeroConstructor)
};

// Function ButterCakeRuntime.FortButterCakeComponent_Telemetry.OnBlowHoleUsed
struct FortButterCakeComponent_Telemetry_OnBlowHoleUsed_Params
{
};

// Function ButterCakeRuntime.FortButterCakeControlRig.GetGroundHitNormalAt
struct FortButterCakeControlRig_GetGroundHitNormalAt_Params
{
	int                                                Index_69;                                                 // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	struct FVector                                     ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function ButterCakeRuntime.FortButterCakeControlRig.GetGroundHitLocationAt
struct FortButterCakeControlRig_GetGroundHitLocationAt_Params
{
	int                                                Index_69;                                                 // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	struct FVector                                     ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

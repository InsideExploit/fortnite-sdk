#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Classes
//---------------------------------------------------------------------------

// Class AutomationUtils.AutomationUtilsBlueprintLibrary
// 0x0000 (0x0028 - 0x0028)
class AutomationUtilsBlueprintLibrary : public BlueprintFunctionLibrary
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AutomationUtils.AutomationUtilsBlueprintLibrary"));
		
		return ptr;
	}


	void STATIC_TakeGameplayAutomationScreenshot(const struct FString& ScreenshotName_69, float MaxGlobalError_69, float MaxLocalError_69, const struct FString& MapNameOverride_69);
};


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

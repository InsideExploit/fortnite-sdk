#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function AttachableWheelsRuntime.AttachableWheel.OnRep_AttachData
struct AttachableWheel_OnRep_AttachData_Params
{
	struct FAttachableWheelAttachData                  AttachDataPrev_69;                                        // (ConstParm, Parm, OutParm, ReferenceParm)
};

// Function AttachableWheelsRuntime.AttachableWheel.OnPhysicsStateChanged
struct AttachableWheel_OnPhysicsStateChanged_Params
{
	class PrimitiveComponent*                          PrimitiveComponent_69;                                    // (Parm, ZeroConstructor, InstancedReference)
	EComponentPhysicsStateChange                       StateChange_69;                                           // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function AttachableWheelsRuntime.AttachableWheel.OnDetached
struct AttachableWheel_OnDetached_Params
{
	class PrimitiveComponent*                          DetachedComponent_69;                                     // (Parm, ZeroConstructor, InstancedReference)
};

// Function AttachableWheelsRuntime.AttachableWheel.OnAttached
struct AttachableWheel_OnAttached_Params
{
	class PrimitiveComponent*                          AttachedComponent_69;                                     // (Parm, ZeroConstructor, InstancedReference)
};

// Function AttachableWheelsRuntime.AttachableWheel.GetWorldSpaceAttachData
struct AttachableWheel_GetWorldSpaceAttachData_Params
{
	struct FAttachableWheelAttachData                  OutAttachData_69;                                         // (Parm, OutParm)
	class PrimitiveComponent*                          PrimitiveComponent_69;                                    // (Parm, ZeroConstructor, InstancedReference)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AttachableWheelsRuntime.AttachableWheel.GetAttachedComponent
struct AttachableWheel_GetAttachedComponent_Params
{
	class PrimitiveComponent*                          ReturnValue_69;                                           // (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)
};

// Function AttachableWheelsRuntime.AttachableWheel.DrawDebug
struct AttachableWheel_DrawDebug_Params
{
};

// Function AttachableWheelsRuntime.AttachableWheel.DetachFrom
struct AttachableWheel_DetachFrom_Params
{
	class PrimitiveComponent*                          InComponent_69;                                           // (Parm, ZeroConstructor, InstancedReference)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AttachableWheelsRuntime.AttachableWheel.Detach
struct AttachableWheel_Detach_Params
{
};

// Function AttachableWheelsRuntime.AttachableWheel.AttachTo
struct AttachableWheel_AttachTo_Params
{
	class PrimitiveComponent*                          InComponent_69;                                           // (Parm, ZeroConstructor, InstancedReference)
	struct FVector                                     WorldLocation_69;                                         // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
	struct FVector                                     AxleDirection_69;                                         // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AttachableWheelsRuntime.AttachableWheel.AttachInPlace
struct AttachableWheel_AttachInPlace_Params
{
	class PrimitiveComponent*                          InComponent_69;                                           // (Parm, ZeroConstructor, InstancedReference)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AttachableWheelsRuntime.AttachableWheelsComponent.OnWheelDetached
struct AttachableWheelsComponent_OnWheelDetached_Params
{
	class AttachableWheel*                             AttachedWheel_69;                                         // (Parm, ZeroConstructor)
};

// Function AttachableWheelsRuntime.AttachableWheelsComponent.OnWheelAttached
struct AttachableWheelsComponent_OnWheelAttached_Params
{
	class AttachableWheel*                             AttachedWheel_69;                                         // (Parm, ZeroConstructor)
};

// Function AttachableWheelsRuntime.AttachableWheelsComponent.HandleWheelDetached_Internal
struct AttachableWheelsComponent_HandleWheelDetached_Internal_Params
{
	class AttachableWheel*                             AttachedWheel_69;                                         // (Parm, ZeroConstructor)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AttachableWheelsRuntime.AttachableWheelsComponent.HandleWheelAttached_Internal
struct AttachableWheelsComponent_HandleWheelAttached_Internal_Params
{
	class AttachableWheel*                             AttachedWheel_69;                                         // (Parm, ZeroConstructor)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AttachableWheelsRuntime.AttachableWheelsComponent.GetAttachedWheels
struct AttachableWheelsComponent_GetAttachedWheels_Params
{
	TArray<class AttachableWheel*>                     ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function AttachableWheelsRuntime.AttachableWheelsComponent.GetAttachedWheelClosestOnAxis
struct AttachableWheelsComponent_GetAttachedWheelClosestOnAxis_Params
{
	struct FVector                                     Point_69;                                                 // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
	float                                              OutClosetDistanceToAxis_69;                               // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	struct FVector                                     OutClosestPointOnAxis_69;                                 // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	struct FVector                                     OutClosestAxis_69;                                        // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	class AttachableWheel*                             ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function AttachableWheelsRuntime.AttachableWheelsComponent.DrawDebug
struct AttachableWheelsComponent_DrawDebug_Params
{
};

// Function AttachableWheelsRuntime.AttachableWheelsComponent.DetachAllWheels
struct AttachableWheelsComponent_DetachAllWheels_Params
{
	int                                                ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

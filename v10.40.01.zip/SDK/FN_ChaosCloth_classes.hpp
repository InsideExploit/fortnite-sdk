#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Classes
//---------------------------------------------------------------------------

// Class ChaosCloth.ChaosClothConfig
// 0x00F0 (0x0118 - 0x0028)
class ChaosClothConfig : public ClothConfigCommon
{
public:
	EClothMassMode                                     MassMode_69;                                              // 0x0028(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0029(0x0003) MISSED OFFSET
	float                                              UniformMass_69;                                           // 0x002C(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	float                                              TotalMass_69;                                             // 0x0030(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	float                                              Density_69;                                               // 0x0034(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	float                                              MinPerParticleMass_69;                                    // 0x0038(0x0004) (ZeroConstructor, IsPlainOldData)
	struct FChaosClothWeightedValue                    EdgeStiffnessWeighted_69;                                 // 0x003C(0x0008) (Edit)
	struct FChaosClothWeightedValue                    BendingStiffnessWeighted_69;                              // 0x0044(0x0008) (Edit)
	float                                              BucklingRatio_69;                                         // 0x004C(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	struct FChaosClothWeightedValue                    BucklingStiffnessWeighted_69;                             // 0x0050(0x0008) (Edit)
	bool                                               bUseBendingElements_69;                                   // 0x0058(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x3];                                       // 0x0059(0x0003) MISSED OFFSET
	struct FChaosClothWeightedValue                    AreaStiffnessWeighted_69;                                 // 0x005C(0x0008) (Edit)
	float                                              VolumeStiffness_69;                                       // 0x0064(0x0004) (ZeroConstructor, IsPlainOldData)
	struct FChaosClothWeightedValue                    TetherStiffness_69;                                       // 0x0068(0x0008) (Edit)
	struct FChaosClothWeightedValue                    TetherScale_69;                                           // 0x0070(0x0008) (Edit)
	bool                                               bUseGeodesicDistance_69;                                  // 0x0078(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData02[0x3];                                       // 0x0079(0x0003) MISSED OFFSET
	float                                              ShapeTargetStiffness_69;                                  // 0x007C(0x0004) (ZeroConstructor, IsPlainOldData)
	float                                              CollisionThickness_69;                                    // 0x0080(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	float                                              FrictionCoefficient_69;                                   // 0x0084(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	bool                                               bUseCCD_69;                                               // 0x0088(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	bool                                               bUseSelfCollisions_69;                                    // 0x0089(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData03[0x2];                                       // 0x008A(0x0002) MISSED OFFSET
	float                                              SelfCollisionThickness_69;                                // 0x008C(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	float                                              SelfCollisionFriction_69;                                 // 0x0090(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	bool                                               bUseSelfIntersections_69;                                 // 0x0094(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	bool                                               bUseLegacyBackstop_69;                                    // 0x0095(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData04[0x2];                                       // 0x0096(0x0002) MISSED OFFSET
	float                                              DampingCoefficient_69;                                    // 0x0098(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	float                                              LocalDampingCoefficient_69;                               // 0x009C(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	bool                                               bUsePointBasedWindModel_69;                               // 0x00A0(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData05[0x3];                                       // 0x00A1(0x0003) MISSED OFFSET
	struct FChaosClothWeightedValue                    Drag_69;                                                  // 0x00A4(0x0008) (Edit)
	struct FChaosClothWeightedValue                    Lift_69;                                                  // 0x00AC(0x0008) (Edit)
	bool                                               bUseGravityOverride_69;                                   // 0x00B4(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData06[0x3];                                       // 0x00B5(0x0003) MISSED OFFSET
	float                                              GravityScale_69;                                          // 0x00B8(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData07[0x4];                                       // 0x00BC(0x0004) MISSED OFFSET
	struct FVector                                     Gravity_69;                                               // 0x00C0(0x0018) (Edit, ZeroConstructor, IsPlainOldData)
	struct FChaosClothWeightedValue                    Pressure_69;                                              // 0x00D8(0x0008) (Edit)
	struct FChaosClothWeightedValue                    AnimDriveStiffness_69;                                    // 0x00E0(0x0008) (Edit)
	struct FChaosClothWeightedValue                    AnimDriveDamping_69;                                      // 0x00E8(0x0008) (Edit)
	struct FVector                                     LinearVelocityScale_69;                                   // 0x00F0(0x0018) (Edit, ZeroConstructor, IsPlainOldData)
	float                                              AngularVelocityScale_69;                                  // 0x0108(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	float                                              FictitiousAngularScale_69;                                // 0x010C(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	bool                                               bUseTetrahedralConstraints_69;                            // 0x0110(0x0001) (ZeroConstructor, IsPlainOldData)
	bool                                               bUseThinShellVolumeConstraints_69;                        // 0x0111(0x0001) (ZeroConstructor, IsPlainOldData)
	bool                                               bUseContinuousCollisionDetection_69;                      // 0x0112(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData08[0x5];                                       // 0x0113(0x0005) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class ChaosCloth.ChaosClothConfig"));
		
		return ptr;
	}

};


// Class ChaosCloth.ChaosClothSharedSimConfig
// 0x0010 (0x0038 - 0x0028)
class ChaosClothSharedSimConfig : public ClothSharedConfigCommon
{
public:
	int                                                IterationCount_69;                                        // 0x0028(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	int                                                MaxIterationCount_69;                                     // 0x002C(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	int                                                SubdivisionCount_69;                                      // 0x0030(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	bool                                               bUseLocalSpaceSimulation_69;                              // 0x0034(0x0001) (ZeroConstructor, IsPlainOldData)
	bool                                               bUseXPBDConstraints_69;                                   // 0x0035(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x2];                                       // 0x0036(0x0002) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class ChaosCloth.ChaosClothSharedSimConfig"));
		
		return ptr;
	}

};


// Class ChaosCloth.ChaosClothingSimulationFactory
// 0x0000 (0x0028 - 0x0028)
class ChaosClothingSimulationFactory : public ClothingSimulationFactory
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class ChaosCloth.ChaosClothingSimulationFactory"));
		
		return ptr;
	}

};


// Class ChaosCloth.ChaosClothingInteractor
// 0x0010 (0x0040 - 0x0030)
class ChaosClothingInteractor : public ClothingInteractor
{
public:
	unsigned char                                      UnknownData00[0x10];                                      // 0x0030(0x0010) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class ChaosCloth.ChaosClothingInteractor"));
		
		return ptr;
	}


	void SetWind(const struct FVector2D& Drag_69, const struct FVector2D& Lift_69, float AirDensity_69, const struct FVector& WindVelocity_69);
	void SetVelocityScale(const struct FVector& LinearVelocityScale_69, float AngularVelocityScale_69, float FictitiousAngularScale_69);
	void SetPressure(const struct FVector2D& Pressure_69);
	void SetMaterialLinear(float EdgeStiffness_69, float BendingStiffness_69, float AreaStiffness_69);
	void SetMaterial(const struct FVector2D& EdgeStiffness_69, const struct FVector2D& BendingStiffness_69, const struct FVector2D& AreaStiffness_69);
	void SetLongRangeAttachmentLinear(float TetherStiffness_69, float TetherScale_69);
	void SetLongRangeAttachment(const struct FVector2D& TetherStiffness_69, const struct FVector2D& TetherScale_69);
	void SetGravity(float GravityScale_69, bool bIsGravityOverridden_69, const struct FVector& GravityOverride_69);
	void SetDamping(float DampingCoefficient_69, float LocalDampingCoefficient_69);
	void SetCollision(float CollisionThickness_69, float FrictionCoefficient_69, bool bUseCCD_69, float SelfCollisionThickness_69);
	void SetBackstop(bool bEnabled_69);
	void SetAnimDriveLinear(float AnimDriveStiffness_69);
	void SetAnimDrive(const struct FVector2D& AnimDriveStiffness_69, const struct FVector2D& AnimDriveDamping_69);
	void SetAerodynamics(float DragCoefficient_69, float LiftCoefficient_69, const struct FVector& WindVelocity_69);
	void ResetAndTeleport(bool bReset_69, bool bTeleport_69);
};


// Class ChaosCloth.ChaosClothingSimulationInteractor
// 0x0010 (0x00A0 - 0x0090)
class ChaosClothingSimulationInteractor : public ClothingSimulationInteractor
{
public:
	unsigned char                                      UnknownData00[0x10];                                      // 0x0090(0x0010) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class ChaosCloth.ChaosClothingSimulationInteractor"));
		
		return ptr;
	}

};


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

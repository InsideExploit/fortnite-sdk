// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Functions
//---------------------------------------------------------------------------

// Function BlueprintContext.BlueprintContextLibrary.GetContext
// (Final, BlueprintCosmetic, Native, Static, Public, BlueprintCallable, BlueprintPure)
// Parameters:
// class Object_32759*            ContextObject_69               (Parm, ZeroConstructor)
// class Subsystem*               Class_69                       (Parm, ZeroConstructor)
// class Subsystem*               ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

class Subsystem* BlueprintContextLibrary::STATIC_GetContext(class Object_32759* ContextObject_69, class Subsystem* Class_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function BlueprintContext.BlueprintContextLibrary.GetContext"));

	BlueprintContextLibrary_GetContext_Params params;
	params.ContextObject_69 = ContextObject_69;
	params.Class_69 = Class_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

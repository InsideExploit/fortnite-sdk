// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Functions
//---------------------------------------------------------------------------

// Function AudioMotorSim.AudioMotorModelComponent.Update
// (Native, Public, BlueprintCallable)
// Parameters:
// struct FAudioMotorSimInputContext Input_69                       (Parm)

void AudioMotorModelComponent::Update(const struct FAudioMotorSimInputContext& Input_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioMotorSim.AudioMotorModelComponent.Update"));

	AudioMotorModelComponent_Update_Params params;
	params.Input_69 = Input_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AudioMotorSim.AudioMotorModelComponent.StopOutput
// (Native, Public, BlueprintCallable)

void AudioMotorModelComponent::StopOutput()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioMotorSim.AudioMotorModelComponent.StopOutput"));

	AudioMotorModelComponent_StopOutput_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AudioMotorSim.AudioMotorModelComponent.StartOutput
// (Native, Public, BlueprintCallable)

void AudioMotorModelComponent::StartOutput()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioMotorSim.AudioMotorModelComponent.StartOutput"));

	AudioMotorModelComponent_StartOutput_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AudioMotorSim.AudioMotorModelComponent.Reset
// (Native, Public, BlueprintCallable)

void AudioMotorModelComponent::Reset()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioMotorSim.AudioMotorModelComponent.Reset"));

	AudioMotorModelComponent_Reset_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AudioMotorSim.AudioMotorModelComponent.RemoveMotorSimComponent
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// TScriptInterface<class AudioMotorSim> InComponent_69                 (Parm, ZeroConstructor, IsPlainOldData)

void AudioMotorModelComponent::RemoveMotorSimComponent(const TScriptInterface<class AudioMotorSim>& InComponent_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioMotorSim.AudioMotorModelComponent.RemoveMotorSimComponent"));

	AudioMotorModelComponent_RemoveMotorSimComponent_Params params;
	params.InComponent_69 = InComponent_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AudioMotorSim.AudioMotorModelComponent.RemoveMotorAudioComponent
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// TScriptInterface<class AudioMotorSimOutput> InComponent_69                 (Parm, ZeroConstructor, IsPlainOldData)

void AudioMotorModelComponent::RemoveMotorAudioComponent(const TScriptInterface<class AudioMotorSimOutput>& InComponent_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioMotorSim.AudioMotorModelComponent.RemoveMotorAudioComponent"));

	AudioMotorModelComponent_RemoveMotorAudioComponent_Params params;
	params.InComponent_69 = InComponent_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AudioMotorSim.AudioMotorModelComponent.GetRuntimeInfo
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FAudioMotorSimRuntimeContext ReturnValue_69                 (Parm, OutParm, ReturnParm)

struct FAudioMotorSimRuntimeContext AudioMotorModelComponent::GetRuntimeInfo()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioMotorSim.AudioMotorModelComponent.GetRuntimeInfo"));

	AudioMotorModelComponent_GetRuntimeInfo_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AudioMotorSim.AudioMotorModelComponent.GetRpm
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// float                          ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

float AudioMotorModelComponent::GetRpm()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioMotorSim.AudioMotorModelComponent.GetRpm"));

	AudioMotorModelComponent_GetRpm_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AudioMotorSim.AudioMotorModelComponent.GetGear
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// int                            ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int AudioMotorModelComponent::GetGear()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioMotorSim.AudioMotorModelComponent.GetGear"));

	AudioMotorModelComponent_GetGear_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AudioMotorSim.AudioMotorModelComponent.GetCachedInputData
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FAudioMotorSimInputContext ReturnValue_69                 (Parm, OutParm, ReturnParm)

struct FAudioMotorSimInputContext AudioMotorModelComponent::GetCachedInputData()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioMotorSim.AudioMotorModelComponent.GetCachedInputData"));

	AudioMotorModelComponent_GetCachedInputData_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AudioMotorSim.AudioMotorModelComponent.AddMotorSimComponent
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// TScriptInterface<class AudioMotorSim> InComponent_69                 (Parm, ZeroConstructor, IsPlainOldData)
// int                            SortOrder_69                   (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void AudioMotorModelComponent::AddMotorSimComponent(const TScriptInterface<class AudioMotorSim>& InComponent_69, int SortOrder_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioMotorSim.AudioMotorModelComponent.AddMotorSimComponent"));

	AudioMotorModelComponent_AddMotorSimComponent_Params params;
	params.InComponent_69 = InComponent_69;
	params.SortOrder_69 = SortOrder_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AudioMotorSim.AudioMotorModelComponent.AddMotorAudioComponent
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// TScriptInterface<class AudioMotorSimOutput> InComponent_69                 (Parm, ZeroConstructor, IsPlainOldData)

void AudioMotorModelComponent::AddMotorAudioComponent(const TScriptInterface<class AudioMotorSimOutput>& InComponent_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioMotorSim.AudioMotorModelComponent.AddMotorAudioComponent"));

	AudioMotorModelComponent_AddMotorAudioComponent_Params params;
	params.InComponent_69 = InComponent_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

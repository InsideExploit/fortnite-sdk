#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function AnimGraphRuntime.AnimationStateMachineLibrary.SetState
struct AnimationStateMachineLibrary_SetState_Params
{
	struct FAnimUpdateContext                          UpdateContext_69;                                         // (ConstParm, Parm, OutParm, ReferenceParm)
	struct FAnimationStateMachineReference             Node_69;                                                  // (ConstParm, Parm, OutParm, ReferenceParm)
	struct FName                                       TargetState_69;                                           // (Parm, ZeroConstructor, IsPlainOldData)
	float                                              Duration_69;                                              // (Parm, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<ETransitionLogicType>                  BlendType_69;                                             // (Parm, ZeroConstructor, IsPlainOldData)
	class BlendProfile*                                BlendProfile_69;                                          // (Parm, ZeroConstructor)
	EAlphaBlendOption                                  AlphaBlendOption_69;                                      // (Parm, ZeroConstructor, IsPlainOldData)
	class CurveFloat*                                  CustomBlendCurve_69;                                      // (Parm, ZeroConstructor)
};

// Function AnimGraphRuntime.AnimationStateMachineLibrary.IsStateBlendingOut
struct AnimationStateMachineLibrary_IsStateBlendingOut_Params
{
	struct FAnimUpdateContext                          UpdateContext_69;                                         // (ConstParm, Parm, OutParm, ReferenceParm)
	struct FAnimationStateResultReference              Node_69;                                                  // (ConstParm, Parm, OutParm, ReferenceParm)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AnimGraphRuntime.AnimationStateMachineLibrary.IsStateBlendingIn
struct AnimationStateMachineLibrary_IsStateBlendingIn_Params
{
	struct FAnimUpdateContext                          UpdateContext_69;                                         // (ConstParm, Parm, OutParm, ReferenceParm)
	struct FAnimationStateResultReference              Node_69;                                                  // (ConstParm, Parm, OutParm, ReferenceParm)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AnimGraphRuntime.AnimationStateMachineLibrary.GetState
struct AnimationStateMachineLibrary_GetState_Params
{
	struct FAnimUpdateContext                          UpdateContext_69;                                         // (ConstParm, Parm, OutParm, ReferenceParm)
	struct FAnimationStateMachineReference             Node_69;                                                  // (ConstParm, Parm, OutParm, ReferenceParm)
	struct FName                                       ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AnimGraphRuntime.AnimationStateMachineLibrary.GetRelevantAnimTimeRemainingFraction
struct AnimationStateMachineLibrary_GetRelevantAnimTimeRemainingFraction_Params
{
	struct FAnimUpdateContext                          UpdateContext_69;                                         // (ConstParm, Parm, OutParm, ReferenceParm)
	struct FAnimationStateResultReference              Node_69;                                                  // (ConstParm, Parm, OutParm, ReferenceParm)
	float                                              ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AnimGraphRuntime.AnimationStateMachineLibrary.GetRelevantAnimTimeRemaining
struct AnimationStateMachineLibrary_GetRelevantAnimTimeRemaining_Params
{
	struct FAnimUpdateContext                          UpdateContext_69;                                         // (ConstParm, Parm, OutParm, ReferenceParm)
	struct FAnimationStateResultReference              Node_69;                                                  // (ConstParm, Parm, OutParm, ReferenceParm)
	float                                              ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AnimGraphRuntime.AnimationStateMachineLibrary.ConvertToAnimationStateResultPure
struct AnimationStateMachineLibrary_ConvertToAnimationStateResultPure_Params
{
	struct FAnimNodeReference                          Node_69;                                                  // (ConstParm, Parm, OutParm, ReferenceParm)
	struct FAnimationStateResultReference              AnimationState_69;                                        // (Parm, OutParm)
	bool                                               Result_69;                                                // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
};

// Function AnimGraphRuntime.AnimationStateMachineLibrary.ConvertToAnimationStateResult
struct AnimationStateMachineLibrary_ConvertToAnimationStateResult_Params
{
	struct FAnimNodeReference                          Node_69;                                                  // (ConstParm, Parm, OutParm, ReferenceParm)
	struct FAnimationStateResultReference              AnimationState_69;                                        // (Parm, OutParm)
	EAnimNodeReferenceConversionResult                 Result_69;                                                // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
};

// Function AnimGraphRuntime.AnimationStateMachineLibrary.ConvertToAnimationStateMachinePure
struct AnimationStateMachineLibrary_ConvertToAnimationStateMachinePure_Params
{
	struct FAnimNodeReference                          Node_69;                                                  // (ConstParm, Parm, OutParm, ReferenceParm)
	struct FAnimationStateMachineReference             AnimationState_69;                                        // (Parm, OutParm)
	bool                                               Result_69;                                                // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
};

// Function AnimGraphRuntime.AnimationStateMachineLibrary.ConvertToAnimationStateMachine
struct AnimationStateMachineLibrary_ConvertToAnimationStateMachine_Params
{
	struct FAnimNodeReference                          Node_69;                                                  // (ConstParm, Parm, OutParm, ReferenceParm)
	struct FAnimationStateMachineReference             AnimationState_69;                                        // (Parm, OutParm)
	EAnimNodeReferenceConversionResult                 Result_69;                                                // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
};

// Function AnimGraphRuntime.AnimExecutionContextLibrary.GetDeltaTime
struct AnimExecutionContextLibrary_GetDeltaTime_Params
{
	struct FAnimUpdateContext                          Context_69;                                               // (ConstParm, Parm, OutParm, ReferenceParm)
	float                                              ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AnimGraphRuntime.AnimExecutionContextLibrary.GetCurrentWeight
struct AnimExecutionContextLibrary_GetCurrentWeight_Params
{
	struct FAnimUpdateContext                          Context_69;                                               // (ConstParm, Parm, OutParm, ReferenceParm)
	float                                              ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AnimGraphRuntime.AnimExecutionContextLibrary.GetAnimNodeReference
struct AnimExecutionContextLibrary_GetAnimNodeReference_Params
{
	class AnimInstance*                                Instance_69;                                              // (Parm, ZeroConstructor)
	int                                                Index_69;                                                 // (Parm, ZeroConstructor, IsPlainOldData)
	struct FAnimNodeReference                          ReturnValue_69;                                           // (Parm, OutParm, ReturnParm)
};

// Function AnimGraphRuntime.AnimExecutionContextLibrary.GetAnimInstance
struct AnimExecutionContextLibrary_GetAnimInstance_Params
{
	struct FAnimExecutionContext                       Context_69;                                               // (ConstParm, Parm, OutParm, ReferenceParm)
	class AnimInstance*                                ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function AnimGraphRuntime.AnimExecutionContextLibrary.ConvertToUpdateContext
struct AnimExecutionContextLibrary_ConvertToUpdateContext_Params
{
	struct FAnimExecutionContext                       Context_69;                                               // (ConstParm, Parm, OutParm, ReferenceParm)
	EAnimExecutionContextConversionResult              Result_69;                                                // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	struct FAnimUpdateContext                          ReturnValue_69;                                           // (Parm, OutParm, ReturnParm)
};

// Function AnimGraphRuntime.AnimExecutionContextLibrary.ConvertToPoseContext
struct AnimExecutionContextLibrary_ConvertToPoseContext_Params
{
	struct FAnimExecutionContext                       Context_69;                                               // (ConstParm, Parm, OutParm, ReferenceParm)
	EAnimExecutionContextConversionResult              Result_69;                                                // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	struct FAnimPoseContext                            ReturnValue_69;                                           // (Parm, OutParm, ReturnParm)
};

// Function AnimGraphRuntime.AnimExecutionContextLibrary.ConvertToInitializationContext
struct AnimExecutionContextLibrary_ConvertToInitializationContext_Params
{
	struct FAnimExecutionContext                       Context_69;                                               // (ConstParm, Parm, OutParm, ReferenceParm)
	EAnimExecutionContextConversionResult              Result_69;                                                // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	struct FAnimInitializationContext                  ReturnValue_69;                                           // (Parm, OutParm, ReturnParm)
};

// Function AnimGraphRuntime.AnimExecutionContextLibrary.ConvertToComponentSpacePoseContext
struct AnimExecutionContextLibrary_ConvertToComponentSpacePoseContext_Params
{
	struct FAnimExecutionContext                       Context_69;                                               // (ConstParm, Parm, OutParm, ReferenceParm)
	EAnimExecutionContextConversionResult              Result_69;                                                // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	struct FAnimComponentSpacePoseContext              ReturnValue_69;                                           // (Parm, OutParm, ReturnParm)
};

// Function AnimGraphRuntime.KismetAnimationLibrary.K2_TwoBoneIK
struct KismetAnimationLibrary_K2_TwoBoneIK_Params
{
	struct FVector                                     RootPos_69;                                               // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
	struct FVector                                     JointPos_69;                                              // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
	struct FVector                                     EndPos_69;                                                // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
	struct FVector                                     JointTarget_69;                                           // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
	struct FVector                                     Effector_69;                                              // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
	struct FVector                                     OutJointPos_69;                                           // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	struct FVector                                     OutEndPos_69;                                             // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	bool                                               bAllowStretching_69;                                      // (Parm, ZeroConstructor, IsPlainOldData)
	float                                              StartStretchRatio_69;                                     // (Parm, ZeroConstructor, IsPlainOldData)
	float                                              MaxStretchScale_69;                                       // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function AnimGraphRuntime.KismetAnimationLibrary.K2_StartProfilingTimer
struct KismetAnimationLibrary_K2_StartProfilingTimer_Params
{
};

// Function AnimGraphRuntime.KismetAnimationLibrary.K2_MakePerlinNoiseVectorAndRemap
struct KismetAnimationLibrary_K2_MakePerlinNoiseVectorAndRemap_Params
{
	float                                              X_69;                                                     // (Parm, ZeroConstructor, IsPlainOldData)
	float                                              Y_69;                                                     // (Parm, ZeroConstructor, IsPlainOldData)
	float                                              Z_69;                                                     // (Parm, ZeroConstructor, IsPlainOldData)
	float                                              RangeOutMinX_69;                                          // (Parm, ZeroConstructor, IsPlainOldData)
	float                                              RangeOutMaxX_69;                                          // (Parm, ZeroConstructor, IsPlainOldData)
	float                                              RangeOutMinY_69;                                          // (Parm, ZeroConstructor, IsPlainOldData)
	float                                              RangeOutMaxY_69;                                          // (Parm, ZeroConstructor, IsPlainOldData)
	float                                              RangeOutMinZ_69;                                          // (Parm, ZeroConstructor, IsPlainOldData)
	float                                              RangeOutMaxZ_69;                                          // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector                                     ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AnimGraphRuntime.KismetAnimationLibrary.K2_MakePerlinNoiseAndRemap
struct KismetAnimationLibrary_K2_MakePerlinNoiseAndRemap_Params
{
	float                                              Value_69;                                                 // (Parm, ZeroConstructor, IsPlainOldData)
	float                                              RangeOutMin_69;                                           // (Parm, ZeroConstructor, IsPlainOldData)
	float                                              RangeOutMax_69;                                           // (Parm, ZeroConstructor, IsPlainOldData)
	float                                              ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AnimGraphRuntime.KismetAnimationLibrary.K2_LookAt
struct KismetAnimationLibrary_K2_LookAt_Params
{
	struct FCoreUObject_FTransform                     CurrentTransform_69;                                      // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	struct FVector                                     TargetPosition_69;                                        // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
	struct FVector                                     LookAtVector_69;                                          // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bUseUpVector_69;                                          // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector                                     UpVector_69;                                              // (Parm, ZeroConstructor, IsPlainOldData)
	float                                              ClampConeInDegree_69;                                     // (Parm, ZeroConstructor, IsPlainOldData)
	struct FCoreUObject_FTransform                     ReturnValue_69;                                           // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function AnimGraphRuntime.KismetAnimationLibrary.K2_EndProfilingTimer
struct KismetAnimationLibrary_K2_EndProfilingTimer_Params
{
	bool                                               bLog_69;                                                  // (Parm, ZeroConstructor, IsPlainOldData)
	struct FString                                     LogPrefix_69;                                             // (Parm, ZeroConstructor)
	float                                              ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AnimGraphRuntime.KismetAnimationLibrary.K2_DistanceBetweenTwoSocketsAndMapRange
struct KismetAnimationLibrary_K2_DistanceBetweenTwoSocketsAndMapRange_Params
{
	class SkeletalMeshComponent*                       Component_69;                                             // (ConstParm, Parm, ZeroConstructor, InstancedReference)
	struct FName                                       SocketOrBoneNameA_69;                                     // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<ERelativeTransformSpace>               SocketSpaceA_69;                                          // (Parm, ZeroConstructor, IsPlainOldData)
	struct FName                                       SocketOrBoneNameB_69;                                     // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<ERelativeTransformSpace>               SocketSpaceB_69;                                          // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bRemapRange_69;                                           // (Parm, ZeroConstructor, IsPlainOldData)
	float                                              InRangeMin_69;                                            // (Parm, ZeroConstructor, IsPlainOldData)
	float                                              InRangeMax_69;                                            // (Parm, ZeroConstructor, IsPlainOldData)
	float                                              OutRangeMin_69;                                           // (Parm, ZeroConstructor, IsPlainOldData)
	float                                              OutRangeMax_69;                                           // (Parm, ZeroConstructor, IsPlainOldData)
	float                                              ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AnimGraphRuntime.KismetAnimationLibrary.K2_DirectionBetweenSockets
struct KismetAnimationLibrary_K2_DirectionBetweenSockets_Params
{
	class SkeletalMeshComponent*                       Component_69;                                             // (ConstParm, Parm, ZeroConstructor, InstancedReference)
	struct FName                                       SocketOrBoneNameFrom_69;                                  // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	struct FName                                       SocketOrBoneNameTo_69;                                    // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	struct FVector                                     ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AnimGraphRuntime.KismetAnimationLibrary.K2_CalculateVelocityFromSockets
struct KismetAnimationLibrary_K2_CalculateVelocityFromSockets_Params
{
	float                                              DeltaSeconds_69;                                          // (Parm, ZeroConstructor, IsPlainOldData)
	class SkeletalMeshComponent*                       Component_69;                                             // (Parm, ZeroConstructor, InstancedReference)
	struct FName                                       SocketOrBoneName_69;                                      // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	struct FName                                       ReferenceSocketOrBone_69;                                 // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<ERelativeTransformSpace>               SocketSpace_69;                                           // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector                                     OffsetInBoneSpace_69;                                     // (Parm, ZeroConstructor, IsPlainOldData)
	struct FPositionHistory                            History_69;                                               // (Parm, OutParm, ReferenceParm)
	int                                                NumberOfSamples_69;                                       // (Parm, ZeroConstructor, IsPlainOldData)
	float                                              VelocityMin_69;                                           // (Parm, ZeroConstructor, IsPlainOldData)
	float                                              VelocityMax_69;                                           // (Parm, ZeroConstructor, IsPlainOldData)
	EEasingFuncType                                    EasingType_69;                                            // (Parm, ZeroConstructor, IsPlainOldData)
	struct FRuntimeFloatCurve                          CustomCurve_69;                                           // (ConstParm, Parm, OutParm, ReferenceParm)
	float                                              ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AnimGraphRuntime.KismetAnimationLibrary.K2_CalculateVelocityFromPositionHistory
struct KismetAnimationLibrary_K2_CalculateVelocityFromPositionHistory_Params
{
	float                                              DeltaSeconds_69;                                          // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector                                     Position_69;                                              // (Parm, ZeroConstructor, IsPlainOldData)
	struct FPositionHistory                            History_69;                                               // (Parm, OutParm, ReferenceParm)
	int                                                NumberOfSamples_69;                                       // (Parm, ZeroConstructor, IsPlainOldData)
	float                                              VelocityMin_69;                                           // (Parm, ZeroConstructor, IsPlainOldData)
	float                                              VelocityMax_69;                                           // (Parm, ZeroConstructor, IsPlainOldData)
	float                                              ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AnimGraphRuntime.KismetAnimationLibrary.CalculateDirection
struct KismetAnimationLibrary_CalculateDirection_Params
{
	struct FVector                                     Velocity_69;                                              // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
	struct FRotator                                    BaseRotation_69;                                          // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
	float                                              ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AnimGraphRuntime.LinkedAnimGraphLibrary.HasLinkedAnimInstance
struct LinkedAnimGraphLibrary_HasLinkedAnimInstance_Params
{
	struct FLinkedAnimGraphReference                   Node_69;                                                  // (ConstParm, Parm, OutParm, ReferenceParm)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AnimGraphRuntime.LinkedAnimGraphLibrary.GetLinkedAnimInstance
struct LinkedAnimGraphLibrary_GetLinkedAnimInstance_Params
{
	struct FLinkedAnimGraphReference                   Node_69;                                                  // (ConstParm, Parm, OutParm, ReferenceParm)
	class AnimInstance*                                ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function AnimGraphRuntime.LinkedAnimGraphLibrary.ConvertToLinkedAnimGraphPure
struct LinkedAnimGraphLibrary_ConvertToLinkedAnimGraphPure_Params
{
	struct FAnimNodeReference                          Node_69;                                                  // (ConstParm, Parm, OutParm, ReferenceParm)
	struct FLinkedAnimGraphReference                   LinkedAnimGraph_69;                                       // (Parm, OutParm)
	bool                                               Result_69;                                                // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
};

// Function AnimGraphRuntime.LinkedAnimGraphLibrary.ConvertToLinkedAnimGraph
struct LinkedAnimGraphLibrary_ConvertToLinkedAnimGraph_Params
{
	struct FAnimNodeReference                          Node_69;                                                  // (ConstParm, Parm, OutParm, ReferenceParm)
	EAnimNodeReferenceConversionResult                 Result_69;                                                // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	struct FLinkedAnimGraphReference                   ReturnValue_69;                                           // (Parm, OutParm, ReturnParm)
};

// Function AnimGraphRuntime.PlayMontageCallbackProxy.OnNotifyEndReceived
struct PlayMontageCallbackProxy_OnNotifyEndReceived_Params
{
	struct FName                                       NotifyName_69;                                            // (Parm, ZeroConstructor, IsPlainOldData)
	struct FBranchingPointNotifyPayload                BranchingPointNotifyPayload_69;                           // (ConstParm, Parm, OutParm, ReferenceParm)
};

// Function AnimGraphRuntime.PlayMontageCallbackProxy.OnNotifyBeginReceived
struct PlayMontageCallbackProxy_OnNotifyBeginReceived_Params
{
	struct FName                                       NotifyName_69;                                            // (Parm, ZeroConstructor, IsPlainOldData)
	struct FBranchingPointNotifyPayload                BranchingPointNotifyPayload_69;                           // (ConstParm, Parm, OutParm, ReferenceParm)
};

// Function AnimGraphRuntime.PlayMontageCallbackProxy.OnMontageEnded
struct PlayMontageCallbackProxy_OnMontageEnded_Params
{
	class AnimMontage*                                 Montage_69;                                               // (Parm, ZeroConstructor)
	bool                                               bInterrupted_69;                                          // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function AnimGraphRuntime.PlayMontageCallbackProxy.OnMontageBlendingOut
struct PlayMontageCallbackProxy_OnMontageBlendingOut_Params
{
	class AnimMontage*                                 Montage_69;                                               // (Parm, ZeroConstructor)
	bool                                               bInterrupted_69;                                          // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function AnimGraphRuntime.PlayMontageCallbackProxy.CreateProxyObjectForPlayMontage
struct PlayMontageCallbackProxy_CreateProxyObjectForPlayMontage_Params
{
	class SkeletalMeshComponent*                       InSkeletalMeshComponent_69;                               // (Parm, ZeroConstructor, InstancedReference)
	class AnimMontage*                                 MontageToPlay_69;                                         // (Parm, ZeroConstructor)
	float                                              PlayRate_69;                                              // (Parm, ZeroConstructor, IsPlainOldData)
	float                                              StartingPosition_69;                                      // (Parm, ZeroConstructor, IsPlainOldData)
	struct FName                                       StartingSection_69;                                       // (Parm, ZeroConstructor, IsPlainOldData)
	class PlayMontageCallbackProxy*                    ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function AnimGraphRuntime.SequenceEvaluatorLibrary.SetSequenceWithInertialBlending
struct SequenceEvaluatorLibrary_SetSequenceWithInertialBlending_Params
{
	struct FAnimUpdateContext                          UpdateContext_69;                                         // (ConstParm, Parm, OutParm, ReferenceParm)
	struct FSequenceEvaluatorReference                 SequenceEvaluator_69;                                     // (ConstParm, Parm, OutParm, ReferenceParm)
	class AnimSequenceBase*                            Sequence_69;                                              // (Parm, ZeroConstructor)
	float                                              BlendTime_69;                                             // (Parm, ZeroConstructor, IsPlainOldData)
	struct FSequenceEvaluatorReference                 ReturnValue_69;                                           // (Parm, OutParm, ReturnParm)
};

// Function AnimGraphRuntime.SequenceEvaluatorLibrary.SetSequence
struct SequenceEvaluatorLibrary_SetSequence_Params
{
	struct FSequenceEvaluatorReference                 SequenceEvaluator_69;                                     // (ConstParm, Parm, OutParm, ReferenceParm)
	class AnimSequenceBase*                            Sequence_69;                                              // (Parm, ZeroConstructor)
	struct FSequenceEvaluatorReference                 ReturnValue_69;                                           // (Parm, OutParm, ReturnParm)
};

// Function AnimGraphRuntime.SequenceEvaluatorLibrary.SetExplicitTime
struct SequenceEvaluatorLibrary_SetExplicitTime_Params
{
	struct FSequenceEvaluatorReference                 SequenceEvaluator_69;                                     // (ConstParm, Parm, OutParm, ReferenceParm)
	float                                              Time_69;                                                  // (Parm, ZeroConstructor, IsPlainOldData)
	struct FSequenceEvaluatorReference                 ReturnValue_69;                                           // (Parm, OutParm, ReturnParm)
};

// Function AnimGraphRuntime.SequenceEvaluatorLibrary.GetSequence
struct SequenceEvaluatorLibrary_GetSequence_Params
{
	struct FSequenceEvaluatorReference                 SequenceEvaluator_69;                                     // (ConstParm, Parm, OutParm, ReferenceParm)
	class AnimSequenceBase*                            ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function AnimGraphRuntime.SequenceEvaluatorLibrary.GetAccumulatedTime
struct SequenceEvaluatorLibrary_GetAccumulatedTime_Params
{
	struct FSequenceEvaluatorReference                 SequenceEvaluator_69;                                     // (ConstParm, Parm, OutParm, ReferenceParm)
	float                                              ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AnimGraphRuntime.SequenceEvaluatorLibrary.ConvertToSequenceEvaluatorPure
struct SequenceEvaluatorLibrary_ConvertToSequenceEvaluatorPure_Params
{
	struct FAnimNodeReference                          Node_69;                                                  // (ConstParm, Parm, OutParm, ReferenceParm)
	struct FSequenceEvaluatorReference                 SequenceEvaluator_69;                                     // (Parm, OutParm)
	bool                                               Result_69;                                                // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
};

// Function AnimGraphRuntime.SequenceEvaluatorLibrary.ConvertToSequenceEvaluator
struct SequenceEvaluatorLibrary_ConvertToSequenceEvaluator_Params
{
	struct FAnimNodeReference                          Node_69;                                                  // (ConstParm, Parm, OutParm, ReferenceParm)
	EAnimNodeReferenceConversionResult                 Result_69;                                                // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	struct FSequenceEvaluatorReference                 ReturnValue_69;                                           // (Parm, OutParm, ReturnParm)
};

// Function AnimGraphRuntime.SequenceEvaluatorLibrary.AdvanceTime
struct SequenceEvaluatorLibrary_AdvanceTime_Params
{
	struct FAnimUpdateContext                          UpdateContext_69;                                         // (ConstParm, Parm, OutParm, ReferenceParm)
	struct FSequenceEvaluatorReference                 SequenceEvaluator_69;                                     // (ConstParm, Parm, OutParm, ReferenceParm)
	float                                              PlayRate_69;                                              // (Parm, ZeroConstructor, IsPlainOldData)
	struct FSequenceEvaluatorReference                 ReturnValue_69;                                           // (Parm, OutParm, ReturnParm)
};

// Function AnimGraphRuntime.SequencePlayerLibrary.SetStartPosition
struct SequencePlayerLibrary_SetStartPosition_Params
{
	struct FSequencePlayerReference                    SequencePlayer_69;                                        // (ConstParm, Parm, OutParm, ReferenceParm)
	float                                              StartPosition_69;                                         // (Parm, ZeroConstructor, IsPlainOldData)
	struct FSequencePlayerReference                    ReturnValue_69;                                           // (Parm, OutParm, ReturnParm)
};

// Function AnimGraphRuntime.SequencePlayerLibrary.SetSequenceWithInertialBlending
struct SequencePlayerLibrary_SetSequenceWithInertialBlending_Params
{
	struct FAnimUpdateContext                          UpdateContext_69;                                         // (ConstParm, Parm, OutParm, ReferenceParm)
	struct FSequencePlayerReference                    SequencePlayer_69;                                        // (ConstParm, Parm, OutParm, ReferenceParm)
	class AnimSequenceBase*                            Sequence_69;                                              // (Parm, ZeroConstructor)
	float                                              BlendTime_69;                                             // (Parm, ZeroConstructor, IsPlainOldData)
	struct FSequencePlayerReference                    ReturnValue_69;                                           // (Parm, OutParm, ReturnParm)
};

// Function AnimGraphRuntime.SequencePlayerLibrary.SetSequence
struct SequencePlayerLibrary_SetSequence_Params
{
	struct FSequencePlayerReference                    SequencePlayer_69;                                        // (ConstParm, Parm, OutParm, ReferenceParm)
	class AnimSequenceBase*                            Sequence_69;                                              // (Parm, ZeroConstructor)
	struct FSequencePlayerReference                    ReturnValue_69;                                           // (Parm, OutParm, ReturnParm)
};

// Function AnimGraphRuntime.SequencePlayerLibrary.SetPlayRate
struct SequencePlayerLibrary_SetPlayRate_Params
{
	struct FSequencePlayerReference                    SequencePlayer_69;                                        // (ConstParm, Parm, OutParm, ReferenceParm)
	float                                              PlayRate_69;                                              // (Parm, ZeroConstructor, IsPlainOldData)
	struct FSequencePlayerReference                    ReturnValue_69;                                           // (Parm, OutParm, ReturnParm)
};

// Function AnimGraphRuntime.SequencePlayerLibrary.SetAccumulatedTime
struct SequencePlayerLibrary_SetAccumulatedTime_Params
{
	struct FSequencePlayerReference                    SequencePlayer_69;                                        // (ConstParm, Parm, OutParm, ReferenceParm)
	float                                              Time_69;                                                  // (Parm, ZeroConstructor, IsPlainOldData)
	struct FSequencePlayerReference                    ReturnValue_69;                                           // (Parm, OutParm, ReturnParm)
};

// Function AnimGraphRuntime.SequencePlayerLibrary.GetStartPosition
struct SequencePlayerLibrary_GetStartPosition_Params
{
	struct FSequencePlayerReference                    SequencePlayer_69;                                        // (ConstParm, Parm, OutParm, ReferenceParm)
	float                                              ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AnimGraphRuntime.SequencePlayerLibrary.GetSequencePure
struct SequencePlayerLibrary_GetSequencePure_Params
{
	struct FSequencePlayerReference                    SequencePlayer_69;                                        // (ConstParm, Parm, OutParm, ReferenceParm)
	class AnimSequenceBase*                            ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function AnimGraphRuntime.SequencePlayerLibrary.GetSequence
struct SequencePlayerLibrary_GetSequence_Params
{
	struct FSequencePlayerReference                    SequencePlayer_69;                                        // (ConstParm, Parm, OutParm, ReferenceParm)
	class AnimSequenceBase*                            SequenceBase_69;                                          // (Parm, OutParm, ZeroConstructor, ReferenceParm)
	struct FSequencePlayerReference                    ReturnValue_69;                                           // (Parm, OutParm, ReturnParm)
};

// Function AnimGraphRuntime.SequencePlayerLibrary.GetPlayRate
struct SequencePlayerLibrary_GetPlayRate_Params
{
	struct FSequencePlayerReference                    SequencePlayer_69;                                        // (ConstParm, Parm, OutParm, ReferenceParm)
	float                                              ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AnimGraphRuntime.SequencePlayerLibrary.GetLoopAnimation
struct SequencePlayerLibrary_GetLoopAnimation_Params
{
	struct FSequencePlayerReference                    SequencePlayer_69;                                        // (ConstParm, Parm, OutParm, ReferenceParm)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AnimGraphRuntime.SequencePlayerLibrary.GetAccumulatedTime
struct SequencePlayerLibrary_GetAccumulatedTime_Params
{
	struct FSequencePlayerReference                    SequencePlayer_69;                                        // (ConstParm, Parm, OutParm, ReferenceParm)
	float                                              ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AnimGraphRuntime.SequencePlayerLibrary.ConvertToSequencePlayerPure
struct SequencePlayerLibrary_ConvertToSequencePlayerPure_Params
{
	struct FAnimNodeReference                          Node_69;                                                  // (ConstParm, Parm, OutParm, ReferenceParm)
	struct FSequencePlayerReference                    SequencePlayer_69;                                        // (Parm, OutParm)
	bool                                               Result_69;                                                // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
};

// Function AnimGraphRuntime.SequencePlayerLibrary.ConvertToSequencePlayer
struct SequencePlayerLibrary_ConvertToSequencePlayer_Params
{
	struct FAnimNodeReference                          Node_69;                                                  // (ConstParm, Parm, OutParm, ReferenceParm)
	EAnimNodeReferenceConversionResult                 Result_69;                                                // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	struct FSequencePlayerReference                    ReturnValue_69;                                           // (Parm, OutParm, ReturnParm)
};

// Function AnimGraphRuntime.SkeletalControlLibrary.SetAlpha
struct SkeletalControlLibrary_SetAlpha_Params
{
	struct FSkeletalControlReference                   SkeletalControl_69;                                       // (ConstParm, Parm, OutParm, ReferenceParm)
	float                                              Alpha_69;                                                 // (Parm, ZeroConstructor, IsPlainOldData)
	struct FSkeletalControlReference                   ReturnValue_69;                                           // (Parm, OutParm, ReturnParm)
};

// Function AnimGraphRuntime.SkeletalControlLibrary.GetAlpha
struct SkeletalControlLibrary_GetAlpha_Params
{
	struct FSkeletalControlReference                   SkeletalControl_69;                                       // (ConstParm, Parm, OutParm, ReferenceParm)
	float                                              ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AnimGraphRuntime.SkeletalControlLibrary.ConvertToSkeletalControlPure
struct SkeletalControlLibrary_ConvertToSkeletalControlPure_Params
{
	struct FAnimNodeReference                          Node_69;                                                  // (ConstParm, Parm, OutParm, ReferenceParm)
	struct FSkeletalControlReference                   SkeletalControl_69;                                       // (Parm, OutParm)
	bool                                               Result_69;                                                // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
};

// Function AnimGraphRuntime.SkeletalControlLibrary.ConvertToSkeletalControl
struct SkeletalControlLibrary_ConvertToSkeletalControl_Params
{
	struct FAnimNodeReference                          Node_69;                                                  // (ConstParm, Parm, OutParm, ReferenceParm)
	EAnimNodeReferenceConversionResult                 Result_69;                                                // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	struct FSkeletalControlReference                   ReturnValue_69;                                           // (Parm, OutParm, ReturnParm)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

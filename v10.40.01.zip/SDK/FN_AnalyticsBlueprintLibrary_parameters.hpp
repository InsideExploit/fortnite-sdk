#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary.StartSessionWithAttributes
struct AnalyticsBlueprintLibrary_StartSessionWithAttributes_Params
{
	TArray<struct FAnalyticsEventAttr>                 Attributes_69;                                            // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary.StartSession
struct AnalyticsBlueprintLibrary_StartSession_Params
{
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary.SetUserId
struct AnalyticsBlueprintLibrary_SetUserId_Params
{
	struct FString                                     UserId_69;                                                // (Parm, ZeroConstructor)
};

// Function AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary.SetSessionId
struct AnalyticsBlueprintLibrary_SetSessionId_Params
{
	struct FString                                     SessionId_69;                                             // (Parm, ZeroConstructor)
};

// Function AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary.SetLocation
struct AnalyticsBlueprintLibrary_SetLocation_Params
{
	struct FString                                     Location_69;                                              // (Parm, ZeroConstructor)
};

// Function AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary.SetGender
struct AnalyticsBlueprintLibrary_SetGender_Params
{
	struct FString                                     Gender_69;                                                // (Parm, ZeroConstructor)
};

// Function AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary.SetBuildInfo
struct AnalyticsBlueprintLibrary_SetBuildInfo_Params
{
	struct FString                                     BuildInfo_69;                                             // (Parm, ZeroConstructor)
};

// Function AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary.SetAge
struct AnalyticsBlueprintLibrary_SetAge_Params
{
	int                                                Age_69;                                                   // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary.RecordSimpleItemPurchaseWithAttributes
struct AnalyticsBlueprintLibrary_RecordSimpleItemPurchaseWithAttributes_Params
{
	struct FString                                     ItemId_69;                                                // (Parm, ZeroConstructor)
	int                                                ItemQuantity_69;                                          // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<struct FAnalyticsEventAttr>                 Attributes_69;                                            // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
};

// Function AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary.RecordSimpleItemPurchase
struct AnalyticsBlueprintLibrary_RecordSimpleItemPurchase_Params
{
	struct FString                                     ItemId_69;                                                // (Parm, ZeroConstructor)
	int                                                ItemQuantity_69;                                          // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary.RecordSimpleCurrencyPurchaseWithAttributes
struct AnalyticsBlueprintLibrary_RecordSimpleCurrencyPurchaseWithAttributes_Params
{
	struct FString                                     GameCurrencyType_69;                                      // (Parm, ZeroConstructor)
	int                                                GameCurrencyAmount_69;                                    // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<struct FAnalyticsEventAttr>                 Attributes_69;                                            // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
};

// Function AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary.RecordSimpleCurrencyPurchase
struct AnalyticsBlueprintLibrary_RecordSimpleCurrencyPurchase_Params
{
	struct FString                                     GameCurrencyType_69;                                      // (Parm, ZeroConstructor)
	int                                                GameCurrencyAmount_69;                                    // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary.RecordProgressWithFullHierarchyAndAttributes
struct AnalyticsBlueprintLibrary_RecordProgressWithFullHierarchyAndAttributes_Params
{
	struct FString                                     ProgressType_69;                                          // (Parm, ZeroConstructor)
	TArray<struct FString>                             ProgressNames_69;                                         // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	TArray<struct FAnalyticsEventAttr>                 Attributes_69;                                            // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
};

// Function AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary.RecordProgressWithAttributes
struct AnalyticsBlueprintLibrary_RecordProgressWithAttributes_Params
{
	struct FString                                     ProgressType_69;                                          // (Parm, ZeroConstructor)
	struct FString                                     ProgressName_69;                                          // (Parm, ZeroConstructor)
	TArray<struct FAnalyticsEventAttr>                 Attributes_69;                                            // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
};

// Function AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary.RecordProgress
struct AnalyticsBlueprintLibrary_RecordProgress_Params
{
	struct FString                                     ProgressType_69;                                          // (Parm, ZeroConstructor)
	struct FString                                     ProgressName_69;                                          // (Parm, ZeroConstructor)
};

// Function AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary.RecordItemPurchase
struct AnalyticsBlueprintLibrary_RecordItemPurchase_Params
{
	struct FString                                     ItemId_69;                                                // (Parm, ZeroConstructor)
	struct FString                                     Currency_69;                                              // (Parm, ZeroConstructor)
	int                                                PerItemCost_69;                                           // (Parm, ZeroConstructor, IsPlainOldData)
	int                                                ItemQuantity_69;                                          // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary.RecordEventWithAttributes
struct AnalyticsBlueprintLibrary_RecordEventWithAttributes_Params
{
	struct FString                                     EventName_69;                                             // (Parm, ZeroConstructor)
	TArray<struct FAnalyticsEventAttr>                 Attributes_69;                                            // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
};

// Function AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary.RecordEventWithAttribute
struct AnalyticsBlueprintLibrary_RecordEventWithAttribute_Params
{
	struct FString                                     EventName_69;                                             // (Parm, ZeroConstructor)
	struct FString                                     AttributeName_69;                                         // (Parm, ZeroConstructor)
	struct FString                                     AttributeValue_69;                                        // (Parm, ZeroConstructor)
};

// Function AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary.RecordEvent
struct AnalyticsBlueprintLibrary_RecordEvent_Params
{
	struct FString                                     EventName_69;                                             // (Parm, ZeroConstructor)
};

// Function AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary.RecordErrorWithAttributes
struct AnalyticsBlueprintLibrary_RecordErrorWithAttributes_Params
{
	struct FString                                     Error_69;                                                 // (Parm, ZeroConstructor)
	TArray<struct FAnalyticsEventAttr>                 Attributes_69;                                            // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
};

// Function AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary.RecordError
struct AnalyticsBlueprintLibrary_RecordError_Params
{
	struct FString                                     Error_69;                                                 // (Parm, ZeroConstructor)
};

// Function AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary.RecordCurrencyPurchase
struct AnalyticsBlueprintLibrary_RecordCurrencyPurchase_Params
{
	struct FString                                     GameCurrencyType_69;                                      // (Parm, ZeroConstructor)
	int                                                GameCurrencyAmount_69;                                    // (Parm, ZeroConstructor, IsPlainOldData)
	struct FString                                     RealCurrencyType_69;                                      // (Parm, ZeroConstructor)
	float                                              RealMoneyCost_69;                                         // (Parm, ZeroConstructor, IsPlainOldData)
	struct FString                                     PaymentProvider_69;                                       // (Parm, ZeroConstructor)
};

// Function AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary.RecordCurrencyGivenWithAttributes
struct AnalyticsBlueprintLibrary_RecordCurrencyGivenWithAttributes_Params
{
	struct FString                                     GameCurrencyType_69;                                      // (Parm, ZeroConstructor)
	int                                                GameCurrencyAmount_69;                                    // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<struct FAnalyticsEventAttr>                 Attributes_69;                                            // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
};

// Function AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary.RecordCurrencyGiven
struct AnalyticsBlueprintLibrary_RecordCurrencyGiven_Params
{
	struct FString                                     GameCurrencyType_69;                                      // (Parm, ZeroConstructor)
	int                                                GameCurrencyAmount_69;                                    // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary.MakeEventAttribute
struct AnalyticsBlueprintLibrary_MakeEventAttribute_Params
{
	struct FString                                     AttributeName_69;                                         // (Parm, ZeroConstructor)
	struct FString                                     AttributeValue_69;                                        // (Parm, ZeroConstructor)
	struct FAnalyticsEventAttr                         ReturnValue_69;                                           // (Parm, OutParm, ReturnParm)
};

// Function AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary.GetUserId
struct AnalyticsBlueprintLibrary_GetUserId_Params
{
	struct FString                                     ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary.GetSessionId
struct AnalyticsBlueprintLibrary_GetSessionId_Params
{
	struct FString                                     ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary.FlushEvents
struct AnalyticsBlueprintLibrary_FlushEvents_Params
{
};

// Function AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary.EndSession
struct AnalyticsBlueprintLibrary_EndSession_Params
{
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

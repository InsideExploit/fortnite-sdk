#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Enums
//---------------------------------------------------------------------------

// Enum AIPatrolPath.EAIPatrolPathVersion
enum class EAIPatrolPathVersion : uint8_t
{
	InitialVersion                 = 0,
	TemplateFromQuickBarVersion    = 1,
	VersionPlusOne                 = 2,
	LatestVersion                  = 3,
	EAIPatrolPathVersion_MAX       = 4
};


// Enum AIPatrolPath.SegmentPathStatus
enum class ESegmentPathStatus : uint8_t
{
	INVALID                        = 0,
	CALCULATING                    = 1,
	RECALCULATING_PENDING          = 2,
	PATH_FAILED                    = 3,
	PATH_SUCCESS                   = 4,
	SegmentPathStatus_MAX          = 5
};



//---------------------------------------------------------------------------
//Script Structs
//---------------------------------------------------------------------------

// ScriptStruct AIPatrolPath.PatrolPathSegmentDetails
// 0x0108
struct FPatrolPathSegmentDetails
{
	unsigned char                                      UnknownData00[0xA8];                                      // 0x0000(0x00A8) MISSED OFFSET
	class NavigationPath*                              Path_69;                                                  // 0x00A8(0x0008) (ZeroConstructor, Transient)
	class AIPatrolPathComponent*                       Start_69;                                                 // 0x00B0(0x0008) (ExportObject, ZeroConstructor, Transient, InstancedReference)
	class AIPatrolPathComponent*                       End_69;                                                   // 0x00B8(0x0008) (ExportObject, ZeroConstructor, Transient, InstancedReference)
	unsigned char                                      UnknownData01[0x48];                                      // 0x00C0(0x0048) MISSED OFFSET
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function CRD_GameStreamRuntime.CreativeGameStreamDeviceComponent.RemoveFromEndGameQueue
struct CreativeGameStreamDeviceComponent_RemoveFromEndGameQueue_Params
{
};

// Function CRD_GameStreamRuntime.CreativeGameStreamDeviceComponent.OnMinigameStateChanged
struct CreativeGameStreamDeviceComponent_OnMinigameStateChanged_Params
{
	class FortMinigame*                                Minigame_69;                                              // (Parm, ZeroConstructor)
	EFortMinigameState                                 NewMinigameState_69;                                      // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function CRD_GameStreamRuntime.CreativeGameStreamDeviceComponent.IsWithinPublishedPlayspace
struct CreativeGameStreamDeviceComponent_IsWithinPublishedPlayspace_Params
{
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CRD_GameStreamRuntime.CreativeGameStreamDeviceComponent.Init
struct CreativeGameStreamDeviceComponent_Init_Params
{
	class FortMinigameLogicComponent*                  InMinigameLogicComponent_69;                              // (Parm, ZeroConstructor, InstancedReference)
};

// SparseDelegateFunction CRD_GameStreamRuntime.CreativeGameStreamDeviceComponent.CreativeGameStreamDeviceComponentSignature__DelegateSignature
struct CreativeGameStreamDeviceComponent_CreativeGameStreamDeviceComponentSignature__DelegateSignature_Params
{
	class CreativeGameStreamDeviceComponent*           CreativeGameStreamDeviceComponent_69;                     // (Parm, ZeroConstructor, InstancedReference)
};

// Function CRD_GameStreamRuntime.CreativeGameStreamDeviceComponent.AddToEndGameQueue
struct CreativeGameStreamDeviceComponent_AddToEndGameQueue_Params
{
};

// Function CRD_GameStreamRuntime.CreativeGameStreamDeviceCoordinatorComponent.OnMinigameStateChanged
struct CreativeGameStreamDeviceCoordinatorComponent_OnMinigameStateChanged_Params
{
	class FortMinigame*                                InMinigame_69;                                            // (Parm, ZeroConstructor)
	EFortMinigameState                                 NewMinigameState_69;                                      // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

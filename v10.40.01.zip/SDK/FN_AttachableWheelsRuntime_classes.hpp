#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Classes
//---------------------------------------------------------------------------

// Class AttachableWheelsRuntime.AttachableWheel
// 0x0080 (0x0308 - 0x0288)
class AttachableWheel : public Actor_32759
{
public:
	class StaticMeshComponent*                         WheelMeshComponent_69;                                    // 0x0288(0x0008) (Edit, BlueprintVisible, ExportObject, ZeroConstructor, EditConst, InstancedReference)
	struct FRotator                                    WheelOrientation_69;                                      // 0x0290(0x0018) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	float                                              WheelDistance_69;                                         // 0x02A8(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x02AC(0x0004) MISSED OFFSET
	class PhysicsConstraintComponent*                  AxleConstraint_69;                                        // 0x02B0(0x0008) (Edit, BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, Transient, EditConst, InstancedReference)
	struct FAttachableWheelAttachData                  AttachData_69;                                            // 0x02B8(0x0050) (Edit, BlueprintVisible, BlueprintReadOnly, Net, Transient, EditConst)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AttachableWheelsRuntime.AttachableWheel"));
		
		return ptr;
	}


	void OnRep_AttachData(const struct FAttachableWheelAttachData& AttachDataPrev_69);
	void OnPhysicsStateChanged(class PrimitiveComponent* PrimitiveComponent_69, EComponentPhysicsStateChange StateChange_69);
	void OnDetached(class PrimitiveComponent* DetachedComponent_69);
	void OnAttached(class PrimitiveComponent* AttachedComponent_69);
	bool GetWorldSpaceAttachData(class PrimitiveComponent* PrimitiveComponent_69, struct FAttachableWheelAttachData* OutAttachData_69);
	class PrimitiveComponent* GetAttachedComponent();
	void DrawDebug();
	bool DetachFrom(class PrimitiveComponent* InComponent_69);
	void Detach();
	bool AttachTo(class PrimitiveComponent* InComponent_69, const struct FVector& WorldLocation_69, const struct FVector& AxleDirection_69);
	bool AttachInPlace(class PrimitiveComponent* InComponent_69);
};


// Class AttachableWheelsRuntime.AttachableWheelsComponent
// 0x0050 (0x00F0 - 0x00A0)
class AttachableWheelsComponent : public ActorComponent
{
public:
	unsigned char                                      UnknownData00[0x50];                                      // 0x00A0(0x0050) UNKNOWN PROPERTY: SetProperty AttachableWheelsRuntime.AttachableWheelsComponent.AttachedWheels_69

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AttachableWheelsRuntime.AttachableWheelsComponent"));
		
		return ptr;
	}


	void OnWheelDetached(class AttachableWheel* AttachedWheel_69);
	void OnWheelAttached(class AttachableWheel* AttachedWheel_69);
	bool HandleWheelDetached_Internal(class AttachableWheel* AttachedWheel_69);
	bool HandleWheelAttached_Internal(class AttachableWheel* AttachedWheel_69);
	TArray<class AttachableWheel*> GetAttachedWheels();
	class AttachableWheel* GetAttachedWheelClosestOnAxis(const struct FVector& Point_69, float* OutClosetDistanceToAxis_69, struct FVector* OutClosestPointOnAxis_69, struct FVector* OutClosestAxis_69);
	void DrawDebug();
	int DetachAllWheels();
};


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

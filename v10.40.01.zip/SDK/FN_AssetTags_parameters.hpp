#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function AssetTags.AssetTagsSubsystem.GetCollectionsContainingAssetPtr
struct AssetTagsSubsystem_GetCollectionsContainingAssetPtr_Params
{
	class Object_32759*                                AssetPtr_69;                                              // (ConstParm, Parm, ZeroConstructor)
	TArray<struct FName>                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function AssetTags.AssetTagsSubsystem.GetCollectionsContainingAssetData
struct AssetTagsSubsystem_GetCollectionsContainingAssetData_Params
{
	struct FAssetData                                  AssetData_69;                                             // (ConstParm, Parm, OutParm, ReferenceParm)
	TArray<struct FName>                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function AssetTags.AssetTagsSubsystem.GetCollectionsContainingAsset
struct AssetTagsSubsystem_GetCollectionsContainingAsset_Params
{
	struct FName                                       AssetPathName_69;                                         // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	TArray<struct FName>                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function AssetTags.AssetTagsSubsystem.GetCollections
struct AssetTagsSubsystem_GetCollections_Params
{
	TArray<struct FName>                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function AssetTags.AssetTagsSubsystem.GetAssetsInCollection
struct AssetTagsSubsystem_GetAssetsInCollection_Params
{
	struct FName                                       Name_69;                                                  // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	TArray<struct FAssetData>                          ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function AssetTags.AssetTagsSubsystem.CollectionExists
struct AssetTagsSubsystem_CollectionExists_Params
{
	struct FName                                       Name_69;                                                  // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

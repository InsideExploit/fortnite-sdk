#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Classes
//---------------------------------------------------------------------------

// Class CorruptionGameplayCodeUI.FortPowerupReticleExtensionWidget
// 0x0008 (0x02E8 - 0x02E0)
class FortPowerupReticleExtensionWidget : public FortWeaponReticleExtensionWidgetBase
{
public:
	EPowerupHeatState                                  LastPowerupHeatState_69;                                  // 0x02E0(0x0001) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x02E1(0x0007) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CorruptionGameplayCodeUI.FortPowerupReticleExtensionWidget"));
		
		return ptr;
	}


	float GetOverheatingMaxValue();
	float GetCurrentOverheatValue();
	float GetCurrentOverheatPercent();
};


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

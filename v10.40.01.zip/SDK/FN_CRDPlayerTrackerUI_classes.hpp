#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Classes
//---------------------------------------------------------------------------

// Class CRDPlayerTrackerUI.CRDPlayerTrackerUIComponent
// 0x0008 (0x00A8 - 0x00A0)
class CRDPlayerTrackerUIComponent : public ActorComponent
{
public:
	class CRDPlayerTrackerWidget*                      SpawnedWidget_69;                                         // 0x00A0(0x0008) (ExportObject, ZeroConstructor, Transient, InstancedReference)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CRDPlayerTrackerUI.CRDPlayerTrackerUIComponent"));
		
		return ptr;
	}

};


// Class CRDPlayerTrackerUI.CRDPlayerTrackerWidget
// 0x0010 (0x02E0 - 0x02D0)
class CRDPlayerTrackerWidget : public FortHUDElementWidget
{
public:
	unsigned char                                      UnknownData00[0x10];                                      // 0x02D0(0x0010) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CRDPlayerTrackerUI.CRDPlayerTrackerWidget"));
		
		return ptr;
	}

};


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

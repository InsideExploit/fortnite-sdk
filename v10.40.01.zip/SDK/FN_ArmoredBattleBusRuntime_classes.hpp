#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Classes
//---------------------------------------------------------------------------

// Class ArmoredBattleBusRuntime.FortArmoredBattleBusPassengerAnimInstance
// 0x00C0 (0x1E00 - 0x1D40)
class FortArmoredBattleBusPassengerAnimInstance : public FortPlayerAnimInstance_32759
{
public:
	unsigned char                                      UnknownData00[0x10];                                      // 0x1D40(0x0010) MISSED OFFSET
	float                                              SmoothedVehicleYawRate_69;                                // 0x1D50(0x0004) (Edit, BlueprintVisible, ZeroConstructor, Transient, IsPlainOldData)
	int                                                PawnSeat_69;                                              // 0x1D54(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, Transient, IsPlainOldData)
	bool                                               bIsFrontTurretPassenger_69;                               // 0x1D58(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, Transient, IsPlainOldData)
	bool                                               bIsRearTurretPassenger_69;                                // 0x1D59(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, Transient, IsPlainOldData)
	unsigned char                                      UnknownData01[0x2];                                       // 0x1D5A(0x0002) MISSED OFFSET
	float                                              Speed_69;                                                 // 0x1D5C(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, Transient, IsPlainOldData)
	float                                              YawDelta_69;                                              // 0x1D60(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, Transient, IsPlainOldData)
	float                                              TurretYaw_69;                                             // 0x1D64(0x0004) (Edit, BlueprintVisible, ZeroConstructor, Transient, IsPlainOldData)
	float                                              TurretPitch_69;                                           // 0x1D68(0x0004) (Edit, BlueprintVisible, ZeroConstructor, Transient, IsPlainOldData)
	unsigned char                                      UnknownData02[0x4];                                       // 0x1D6C(0x0004) MISSED OFFSET
	struct FRotator                                    TurretYawRotator_69;                                      // 0x1D70(0x0018) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, Transient, IsPlainOldData)
	float                                              SlopeRollDegreeAngle_69;                                  // 0x1D88(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, Transient, IsPlainOldData)
	float                                              SlopePitchDegreeAngle_69;                                 // 0x1D8C(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, Transient, IsPlainOldData)
	struct FVector                                     HandAttachL_69;                                           // 0x1D90(0x0018) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, Transient, IsPlainOldData)
	struct FVector                                     HandAttachR_69;                                           // 0x1DA8(0x0018) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, Transient, IsPlainOldData)
	TEnumAsByte<ERelativeTransformSpace>               TransformSpace_69;                                        // 0x1DC0(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData03[0x3];                                       // 0x1DC1(0x0003) MISSED OFFSET
	float                                              UpdateYawDeltaSmoothedLerpRate_69;                        // 0x1DC4(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	int                                                TurretPassengerFront_69;                                  // 0x1DC8(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	int                                                TurretPassengerRear_69;                                   // 0x1DCC(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	struct FName                                       FrontFootBoneName_69;                                     // 0x1DD0(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	struct FName                                       RearFootBoneName_69;                                      // 0x1DD4(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	struct FName                                       GunHandAttachBoneName_FrontLeft_69;                       // 0x1DD8(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	struct FName                                       GunHandAttachBoneName_RearLeft_69;                        // 0x1DDC(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	struct FName                                       GunHandAttachBoneName_FrontRight_69;                      // 0x1DE0(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	struct FName                                       GunHandAttachBoneName_RearRight_69;                       // 0x1DE4(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	struct FName                                       PassengerBoneName_Front_69;                               // 0x1DE8(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	struct FName                                       PassengerBoneName_Rear_69;                                // 0x1DEC(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	float                                              TurretPitchDegMin_69;                                     // 0x1DF0(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	float                                              TurretPitchDegMax_69;                                     // 0x1DF4(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	float                                              LocalPlayerTurretPitchEaseRate_69;                        // 0x1DF8(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData04[0x4];                                       // 0x1DFC(0x0004) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class ArmoredBattleBusRuntime.FortArmoredBattleBusPassengerAnimInstance"));
		
		return ptr;
	}


	void UpdateYawDeltaSmoothed(class FortAthenaVehicle* VehicleActor_69, const struct FName& SocketName_69, const struct FRotator& NewRotation_69, float* SmoothedYawValue_69);
	void UpdateSmoothedVehicleYawRate(class FortAthenaVehicle* VehicleActor_69);
	void UpdateHandPositionsSlopeValues(class SkeletalMeshComponent* BusMeshComponent_69);
	struct FVector UnrotateHandAttachLocation(const struct FVector& HandLocation_69, const struct FVector& FootLocation_69, const struct FRotator& FootRotation_69);
	struct FCoreUObject_FTransform GetPassengerTransform(class SkeletalMeshComponent* BusMeshComponent_69);
	struct FVector GetHandAttachLocation(class SkeletalMeshComponent* BusMeshComponent_69, const struct FName& FrontHandAttachBoneName_69, const struct FName& RearHandAttachBoneName_69);
	struct FCoreUObject_FTransform GetFootAttachTransform(class SkeletalMeshComponent* BusMeshComponent_69);
	void GenerateCharacterPitchAndYawForSlopedTerrain(class FortAthenaVehicle* VehicleActor_69, float* TurretYaw_69, float* TurretPitch_69, struct FRotator* PawnYawRotator_69);
};


// Class ArmoredBattleBusRuntime.FortArmoredBattleBusVehicleAnimInstance_32759
// 0x0090 (0x0680 - 0x05F0)
class FortArmoredBattleBusVehicleAnimInstance_32759 : public FortVehicleAnimInstance
{
public:
	float                                              FrontTurretAimPitch_69;                                   // 0x05F0(0x0004) (Edit, BlueprintVisible, ZeroConstructor, Transient, IsPlainOldData)
	float                                              RearTurretAimPitch_69;                                    // 0x05F4(0x0004) (Edit, BlueprintVisible, ZeroConstructor, Transient, IsPlainOldData)
	float                                              FrontYawDeltaSmoothed_69;                                 // 0x05F8(0x0004) (Edit, BlueprintVisible, ZeroConstructor, Transient, IsPlainOldData)
	float                                              RearYawDeltaSmoothed_69;                                  // 0x05FC(0x0004) (Edit, BlueprintVisible, ZeroConstructor, Transient, IsPlainOldData)
	float                                              SmoothedVehicleYawRate_69;                                // 0x0600(0x0004) (Edit, BlueprintVisible, ZeroConstructor, Transient, IsPlainOldData)
	float                                              FrontYawDeltaSmoothedAlpha_69;                            // 0x0604(0x0004) (Edit, BlueprintVisible, ZeroConstructor, Transient, IsPlainOldData)
	float                                              RearYawDeltaSmoothedAlpha_69;                             // 0x0608(0x0004) (Edit, BlueprintVisible, ZeroConstructor, Transient, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x060C(0x0004) MISSED OFFSET
	struct FRotator                                    FrontWeaponYaw_69;                                        // 0x0610(0x0018) (Edit, BlueprintVisible, ZeroConstructor, Transient, IsPlainOldData)
	struct FRotator                                    RearWeaponYaw_69;                                         // 0x0628(0x0018) (Edit, BlueprintVisible, ZeroConstructor, Transient, IsPlainOldData)
	struct FRotator                                    PreviousVehicleRotator_69;                                // 0x0640(0x0018) (Edit, BlueprintVisible, ZeroConstructor, Transient, IsPlainOldData)
	bool                                               bHasFrontTurretPassenger_69;                              // 0x0658(0x0001) (Edit, BlueprintVisible, ZeroConstructor, Transient, IsPlainOldData)
	bool                                               bHasRearTurretPassenger_69;                               // 0x0659(0x0001) (Edit, BlueprintVisible, ZeroConstructor, Transient, IsPlainOldData)
	unsigned char                                      UnknownData01[0x2];                                       // 0x065A(0x0002) MISSED OFFSET
	float                                              NetworkEaseRate_69;                                       // 0x065C(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	float                                              UpdateYawDeltaSmoothedLerpRate_69;                        // 0x0660(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	int                                                FrontPassengerSeatIndex_69;                               // 0x0664(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	int                                                RearPassengerSeatIndex_69;                                // 0x0668(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	float                                              FrontPassengerYawOffset_69;                               // 0x066C(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	float                                              RearPassengerYawOffset_69;                                // 0x0670(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	struct FName                                       FrontPassengerBoneName_69;                                // 0x0674(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	struct FName                                       RearPassengerBoneName_69;                                 // 0x0678(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData02[0x4];                                       // 0x067C(0x0004) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class ArmoredBattleBusRuntime.FortArmoredBattleBusVehicleAnimInstance_32759"));
		
		return ptr;
	}


	float UpdateYawDeltaSmoothed(class FortAthenaVehicle* VehicleActor_69, const struct FName& SocketName_69, const struct FRotator& NewRotation_69, float SmoothedYawValue_69);
	void UpdateTurretAimPitchWeaponYaw(class FortAthenaVehicle* OwnerVehicle_69, class FortPlayerPawn* GunnerActor_69, const struct FName& SocketName_69, float YawOffset_69, float* TurretAimPitch_69, float* YawDeltaSmoothed_69, struct FRotator* WeaponYaw_69);
	float UpdateSmoothedVehicleYawRate(class FortAthenaVehicle* VehicleActor_69, const struct FRotator& PreviousRotator_69);
	void GetPitchAndYaw(class FortAthenaVehicle* VehicleActor_69, class FortPlayerPawn* GunnerActor_69, float* AdjustedPitch_69, float* AdjustedYaw_69, bool* bIsLocalPlayerControlled_69, struct FRotator* YawRotator_69);
};


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Functions
//---------------------------------------------------------------------------

// Function AnimationSharing.AnimationSharingStateProcessor.ProcessActorState
// (Native, Event, Public, HasOutParms, BlueprintEvent)
// Parameters:
// int                            OutState_69                    (Parm, OutParm, ZeroConstructor, IsPlainOldData)
// class Actor_32759*             InActor_69                     (Parm, ZeroConstructor)
// unsigned char                  CurrentState_69                (Parm, ZeroConstructor, IsPlainOldData)
// unsigned char                  OnDemandState_69               (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bShouldProcess_69              (Parm, OutParm, ZeroConstructor, IsPlainOldData)

void AnimationSharingStateProcessor::ProcessActorState(class Actor_32759* InActor_69, unsigned char CurrentState_69, unsigned char OnDemandState_69, int* OutState_69, bool* bShouldProcess_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AnimationSharing.AnimationSharingStateProcessor.ProcessActorState"));

	AnimationSharingStateProcessor_ProcessActorState_Params params;
	params.InActor_69 = InActor_69;
	params.CurrentState_69 = CurrentState_69;
	params.OnDemandState_69 = OnDemandState_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (OutState_69 != nullptr)
		*OutState_69 = params.OutState_69;
	if (bShouldProcess_69 != nullptr)
		*bShouldProcess_69 = params.bShouldProcess_69;
}


// Function AnimationSharing.AnimationSharingStateProcessor.GetAnimationStateEnum
// (Native, Event, Public, BlueprintEvent)
// Parameters:
// class Enum*                    ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

class Enum* AnimationSharingStateProcessor::GetAnimationStateEnum()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AnimationSharing.AnimationSharingStateProcessor.GetAnimationStateEnum"));

	AnimationSharingStateProcessor_GetAnimationStateEnum_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AnimationSharing.AnimSharingStateInstance.GetInstancedActors
// (Final, Native, Protected, HasOutParms, BlueprintCallable)
// Parameters:
// TArray<class Actor_32759*>     Actors_69                      (Parm, OutParm, ZeroConstructor)

void AnimSharingStateInstance::GetInstancedActors(TArray<class Actor_32759*>* Actors_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AnimationSharing.AnimSharingStateInstance.GetInstancedActors"));

	AnimSharingStateInstance_GetInstancedActors_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (Actors_69 != nullptr)
		*Actors_69 = params.Actors_69;
}


// Function AnimationSharing.AnimationSharingManager.RegisterActorWithSkeletonBP
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// class Actor_32759*             InActor_69                     (Parm, ZeroConstructor)
// class Skeleton*                SharingSkeleton_69             (ConstParm, Parm, ZeroConstructor)

void AnimationSharingManager::RegisterActorWithSkeletonBP(class Actor_32759* InActor_69, class Skeleton* SharingSkeleton_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AnimationSharing.AnimationSharingManager.RegisterActorWithSkeletonBP"));

	AnimationSharingManager_RegisterActorWithSkeletonBP_Params params;
	params.InActor_69 = InActor_69;
	params.SharingSkeleton_69 = SharingSkeleton_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AnimationSharing.AnimationSharingManager.GetAnimationSharingManager
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// class Object_32759*            WorldContextObject_69          (Parm, ZeroConstructor)
// class AnimationSharingManager* ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

class AnimationSharingManager* AnimationSharingManager::STATIC_GetAnimationSharingManager(class Object_32759* WorldContextObject_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AnimationSharing.AnimationSharingManager.GetAnimationSharingManager"));

	AnimationSharingManager_GetAnimationSharingManager_Params params;
	params.WorldContextObject_69 = WorldContextObject_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AnimationSharing.AnimationSharingManager.CreateAnimationSharingManager
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// class Object_32759*            WorldContextObject_69          (Parm, ZeroConstructor)
// class AnimationSharingSetup*   Setup_69                       (ConstParm, Parm, ZeroConstructor)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool AnimationSharingManager::STATIC_CreateAnimationSharingManager(class Object_32759* WorldContextObject_69, class AnimationSharingSetup* Setup_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AnimationSharing.AnimationSharingManager.CreateAnimationSharingManager"));

	AnimationSharingManager_CreateAnimationSharingManager_Params params;
	params.WorldContextObject_69 = WorldContextObject_69;
	params.Setup_69 = Setup_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AnimationSharing.AnimationSharingManager.AnimationSharingEnabled
// (Final, Native, Static, Public, BlueprintCallable, BlueprintPure)
// Parameters:
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool AnimationSharingManager::STATIC_AnimationSharingEnabled()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AnimationSharing.AnimationSharingManager.AnimationSharingEnabled"));

	AnimationSharingManager_AnimationSharingEnabled_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

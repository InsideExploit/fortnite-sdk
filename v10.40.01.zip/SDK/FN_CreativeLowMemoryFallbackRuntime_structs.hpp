#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Script Structs
//---------------------------------------------------------------------------

// ScriptStruct CreativeLowMemoryFallbackRuntime.CreativeLowMemoryFallbackUserFacingText
// 0x0048
struct FCreativeLowMemoryFallbackUserFacingText
{
	struct FText                                       ExitToMainMenuReasonText_69;                              // 0x0000(0x0018) (Edit)
	struct FText                                       WarningToastTitle_69;                                     // 0x0018(0x0018) (Edit)
	struct FText                                       WarningToastDescription_69;                               // 0x0030(0x0018) (Edit)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

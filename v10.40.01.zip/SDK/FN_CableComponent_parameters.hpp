#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function CableComponent.CableComponent.SetAttachEndToComponent
struct CableComponent_SetAttachEndToComponent_Params
{
	class SceneComponent*                              Component_69;                                             // (Parm, ZeroConstructor, InstancedReference)
	struct FName                                       SocketName_69;                                            // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function CableComponent.CableComponent.SetAttachEndTo
struct CableComponent_SetAttachEndTo_Params
{
	class Actor_32759*                                 Actor_69;                                                 // (Parm, ZeroConstructor)
	struct FName                                       ComponentProperty_69;                                     // (Parm, ZeroConstructor, IsPlainOldData)
	struct FName                                       SocketName_69;                                            // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function CableComponent.CableComponent.GetCableParticleLocations
struct CableComponent_GetCableParticleLocations_Params
{
	TArray<struct FVector>                             Locations_69;                                             // (Parm, OutParm, ZeroConstructor)
};

// Function CableComponent.CableComponent.GetAttachedComponent
struct CableComponent_GetAttachedComponent_Params
{
	class SceneComponent*                              ReturnValue_69;                                           // (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)
};

// Function CableComponent.CableComponent.GetAttachedActor
struct CableComponent_GetAttachedActor_Params
{
	class Actor_32759*                                 ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

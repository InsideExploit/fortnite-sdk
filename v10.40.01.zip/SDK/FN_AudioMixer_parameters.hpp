#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function AudioMixer.SynthComponent.Stop
struct SynthComponent_Stop_Params
{
};

// Function AudioMixer.SynthComponent.Start
struct SynthComponent_Start_Params
{
};

// Function AudioMixer.SynthComponent.SetVolumeMultiplier
struct SynthComponent_SetVolumeMultiplier_Params
{
	float                                              VolumeMultiplier_69;                                      // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function AudioMixer.SynthComponent.SetSubmixSend
struct SynthComponent_SetSubmixSend_Params
{
	class SoundSubmixBase*                             Submix_69;                                                // (Parm, ZeroConstructor)
	float                                              SendLevel_69;                                             // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function AudioMixer.SynthComponent.SetOutputToBusOnly
struct SynthComponent_SetOutputToBusOnly_Params
{
	bool                                               bInOutputToBusOnly_69;                                    // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function AudioMixer.SynthComponent.SetLowPassFilterFrequency
struct SynthComponent_SetLowPassFilterFrequency_Params
{
	float                                              InLowPassFilterFrequency_69;                              // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function AudioMixer.SynthComponent.SetLowPassFilterEnabled
struct SynthComponent_SetLowPassFilterEnabled_Params
{
	bool                                               InLowPassFilterEnabled_69;                                // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function AudioMixer.SynthComponent.IsPlaying
struct SynthComponent_IsPlaying_Params
{
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AudioMixer.SynthComponent.FadeOut
struct SynthComponent_FadeOut_Params
{
	float                                              FadeOutDuration_69;                                       // (Parm, ZeroConstructor, IsPlainOldData)
	float                                              FadeVolumeLevel_69;                                       // (Parm, ZeroConstructor, IsPlainOldData)
	EAudioFaderCurve                                   FadeCurve_69;                                             // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function AudioMixer.SynthComponent.FadeIn
struct SynthComponent_FadeIn_Params
{
	float                                              FadeInDuration_69;                                        // (Parm, ZeroConstructor, IsPlainOldData)
	float                                              FadeVolumeLevel_69;                                       // (Parm, ZeroConstructor, IsPlainOldData)
	float                                              StartTime_69;                                             // (Parm, ZeroConstructor, IsPlainOldData)
	EAudioFaderCurve                                   FadeCurve_69;                                             // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function AudioMixer.SynthComponent.AdjustVolume
struct SynthComponent_AdjustVolume_Params
{
	float                                              AdjustVolumeDuration_69;                                  // (Parm, ZeroConstructor, IsPlainOldData)
	float                                              AdjustVolumeLevel_69;                                     // (Parm, ZeroConstructor, IsPlainOldData)
	EAudioFaderCurve                                   FadeCurve_69;                                             // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function AudioMixer.AudioMixerBlueprintLibrary.TrimAudioCache
struct AudioMixerBlueprintLibrary_TrimAudioCache_Params
{
	float                                              InMegabytesToFree_69;                                     // (Parm, ZeroConstructor, IsPlainOldData)
	float                                              ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AudioMixer.AudioMixerBlueprintLibrary.SwapAudioOutputDevice
struct AudioMixerBlueprintLibrary_SwapAudioOutputDevice_Params
{
	class Object_32759*                                WorldContextObject_69;                                    // (ConstParm, Parm, ZeroConstructor)
	struct FString                                     NewDeviceId_69;                                           // (Parm, ZeroConstructor)
	struct FScriptDelegate                             OnCompletedDeviceSwap_69;                                 // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
};

// Function AudioMixer.AudioMixerBlueprintLibrary.StopRecordingOutput
struct AudioMixerBlueprintLibrary_StopRecordingOutput_Params
{
	class Object_32759*                                WorldContextObject_69;                                    // (ConstParm, Parm, ZeroConstructor)
	EAudioRecordingExportType                          ExportType_69;                                            // (Parm, ZeroConstructor, IsPlainOldData)
	struct FString                                     Name_69;                                                  // (Parm, ZeroConstructor)
	struct FString                                     Path_69;                                                  // (Parm, ZeroConstructor)
	class SoundSubmix*                                 SubmixToRecord_69;                                        // (Parm, ZeroConstructor)
	class SoundWave*                                   ExistingSoundWaveToOverwrite_69;                          // (Parm, ZeroConstructor)
	class SoundWave*                                   ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function AudioMixer.AudioMixerBlueprintLibrary.StopAudioBus
struct AudioMixerBlueprintLibrary_StopAudioBus_Params
{
	class Object_32759*                                WorldContextObject_69;                                    // (ConstParm, Parm, ZeroConstructor)
	class AudioBus*                                    AudioBus_69;                                              // (Parm, ZeroConstructor)
};

// Function AudioMixer.AudioMixerBlueprintLibrary.StopAnalyzingOutput
struct AudioMixerBlueprintLibrary_StopAnalyzingOutput_Params
{
	class Object_32759*                                WorldContextObject_69;                                    // (ConstParm, Parm, ZeroConstructor)
	class SoundSubmix*                                 SubmixToStopAnalyzing_69;                                 // (Parm, ZeroConstructor)
};

// Function AudioMixer.AudioMixerBlueprintLibrary.StartRecordingOutput
struct AudioMixerBlueprintLibrary_StartRecordingOutput_Params
{
	class Object_32759*                                WorldContextObject_69;                                    // (ConstParm, Parm, ZeroConstructor)
	float                                              ExpectedDuration_69;                                      // (Parm, ZeroConstructor, IsPlainOldData)
	class SoundSubmix*                                 SubmixToRecord_69;                                        // (Parm, ZeroConstructor)
};

// Function AudioMixer.AudioMixerBlueprintLibrary.StartAudioBus
struct AudioMixerBlueprintLibrary_StartAudioBus_Params
{
	class Object_32759*                                WorldContextObject_69;                                    // (ConstParm, Parm, ZeroConstructor)
	class AudioBus*                                    AudioBus_69;                                              // (Parm, ZeroConstructor)
};

// Function AudioMixer.AudioMixerBlueprintLibrary.StartAnalyzingOutput
struct AudioMixerBlueprintLibrary_StartAnalyzingOutput_Params
{
	class Object_32759*                                WorldContextObject_69;                                    // (ConstParm, Parm, ZeroConstructor)
	class SoundSubmix*                                 SubmixToAnalyze_69;                                       // (Parm, ZeroConstructor)
	EFFTSize                                           FFTSize_69;                                               // (Parm, ZeroConstructor, IsPlainOldData)
	EFFTPeakInterpolationMethod                        InterpolationMethod_69;                                   // (Parm, ZeroConstructor, IsPlainOldData)
	EFFTWindowType                                     WindowType_69;                                            // (Parm, ZeroConstructor, IsPlainOldData)
	float                                              HopSize_69;                                               // (Parm, ZeroConstructor, IsPlainOldData)
	EAudioSpectrumType                                 SpectrumType_69;                                          // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function AudioMixer.AudioMixerBlueprintLibrary.SetSubmixEffectChainOverride
struct AudioMixerBlueprintLibrary_SetSubmixEffectChainOverride_Params
{
	class Object_32759*                                WorldContextObject_69;                                    // (ConstParm, Parm, ZeroConstructor)
	class SoundSubmix*                                 SoundSubmix_69;                                           // (Parm, ZeroConstructor)
	TArray<class SoundEffectSubmixPreset*>             SubmixEffectPresetChain_69;                               // (Parm, ZeroConstructor)
	float                                              FadeTimeSec_69;                                           // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function AudioMixer.AudioMixerBlueprintLibrary.SetBypassSourceEffectChainEntry
struct AudioMixerBlueprintLibrary_SetBypassSourceEffectChainEntry_Params
{
	class Object_32759*                                WorldContextObject_69;                                    // (ConstParm, Parm, ZeroConstructor)
	class SoundEffectSourcePresetChain*                PresetChain_69;                                           // (Parm, ZeroConstructor)
	int                                                EntryIndex_69;                                            // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bBypassed_69;                                             // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function AudioMixer.AudioMixerBlueprintLibrary.ResumeRecordingOutput
struct AudioMixerBlueprintLibrary_ResumeRecordingOutput_Params
{
	class Object_32759*                                WorldContextObject_69;                                    // (ConstParm, Parm, ZeroConstructor)
	class SoundSubmix*                                 SubmixToPause_69;                                         // (Parm, ZeroConstructor)
};

// Function AudioMixer.AudioMixerBlueprintLibrary.ReplaceSubmixEffect
struct AudioMixerBlueprintLibrary_ReplaceSubmixEffect_Params
{
	class Object_32759*                                WorldContextObject_69;                                    // (ConstParm, Parm, ZeroConstructor)
	class SoundSubmix*                                 InSoundSubmix_69;                                         // (Parm, ZeroConstructor)
	int                                                SubmixChainIndex_69;                                      // (Parm, ZeroConstructor, IsPlainOldData)
	class SoundEffectSubmixPreset*                     SubmixEffectPreset_69;                                    // (Parm, ZeroConstructor)
};

// Function AudioMixer.AudioMixerBlueprintLibrary.ReplaceSoundEffectSubmix
struct AudioMixerBlueprintLibrary_ReplaceSoundEffectSubmix_Params
{
	class Object_32759*                                WorldContextObject_69;                                    // (ConstParm, Parm, ZeroConstructor)
	class SoundSubmix*                                 InSoundSubmix_69;                                         // (Parm, ZeroConstructor)
	int                                                SubmixChainIndex_69;                                      // (Parm, ZeroConstructor, IsPlainOldData)
	class SoundEffectSubmixPreset*                     SubmixEffectPreset_69;                                    // (Parm, ZeroConstructor)
};

// Function AudioMixer.AudioMixerBlueprintLibrary.RemoveSubmixEffectPresetAtIndex
struct AudioMixerBlueprintLibrary_RemoveSubmixEffectPresetAtIndex_Params
{
	class Object_32759*                                WorldContextObject_69;                                    // (ConstParm, Parm, ZeroConstructor)
	class SoundSubmix*                                 SoundSubmix_69;                                           // (Parm, ZeroConstructor)
	int                                                SubmixChainIndex_69;                                      // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function AudioMixer.AudioMixerBlueprintLibrary.RemoveSubmixEffectPreset
struct AudioMixerBlueprintLibrary_RemoveSubmixEffectPreset_Params
{
	class Object_32759*                                WorldContextObject_69;                                    // (ConstParm, Parm, ZeroConstructor)
	class SoundSubmix*                                 SoundSubmix_69;                                           // (Parm, ZeroConstructor)
	class SoundEffectSubmixPreset*                     SubmixEffectPreset_69;                                    // (Parm, ZeroConstructor)
};

// Function AudioMixer.AudioMixerBlueprintLibrary.RemoveSubmixEffectAtIndex
struct AudioMixerBlueprintLibrary_RemoveSubmixEffectAtIndex_Params
{
	class Object_32759*                                WorldContextObject_69;                                    // (ConstParm, Parm, ZeroConstructor)
	class SoundSubmix*                                 SoundSubmix_69;                                           // (Parm, ZeroConstructor)
	int                                                SubmixChainIndex_69;                                      // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function AudioMixer.AudioMixerBlueprintLibrary.RemoveSubmixEffect
struct AudioMixerBlueprintLibrary_RemoveSubmixEffect_Params
{
	class Object_32759*                                WorldContextObject_69;                                    // (ConstParm, Parm, ZeroConstructor)
	class SoundSubmix*                                 SoundSubmix_69;                                           // (Parm, ZeroConstructor)
	class SoundEffectSubmixPreset*                     SubmixEffectPreset_69;                                    // (Parm, ZeroConstructor)
};

// Function AudioMixer.AudioMixerBlueprintLibrary.RemoveSourceEffectFromPresetChain
struct AudioMixerBlueprintLibrary_RemoveSourceEffectFromPresetChain_Params
{
	class Object_32759*                                WorldContextObject_69;                                    // (ConstParm, Parm, ZeroConstructor)
	class SoundEffectSourcePresetChain*                PresetChain_69;                                           // (Parm, ZeroConstructor)
	int                                                EntryIndex_69;                                            // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function AudioMixer.AudioMixerBlueprintLibrary.RemoveMasterSubmixEffect
struct AudioMixerBlueprintLibrary_RemoveMasterSubmixEffect_Params
{
	class Object_32759*                                WorldContextObject_69;                                    // (ConstParm, Parm, ZeroConstructor)
	class SoundEffectSubmixPreset*                     SubmixEffectPreset_69;                                    // (Parm, ZeroConstructor)
};

// Function AudioMixer.AudioMixerBlueprintLibrary.PrimeSoundForPlayback
struct AudioMixerBlueprintLibrary_PrimeSoundForPlayback_Params
{
	class SoundWave*                                   SoundWave_69;                                             // (Parm, ZeroConstructor)
	struct FScriptDelegate                             OnLoadCompletion_69;                                      // (ConstParm, Parm, ZeroConstructor)
};

// Function AudioMixer.AudioMixerBlueprintLibrary.PrimeSoundCueForPlayback
struct AudioMixerBlueprintLibrary_PrimeSoundCueForPlayback_Params
{
	class SoundCue*                                    SoundCue_69;                                              // (Parm, ZeroConstructor)
};

// Function AudioMixer.AudioMixerBlueprintLibrary.PauseRecordingOutput
struct AudioMixerBlueprintLibrary_PauseRecordingOutput_Params
{
	class Object_32759*                                WorldContextObject_69;                                    // (ConstParm, Parm, ZeroConstructor)
	class SoundSubmix*                                 SubmixToPause_69;                                         // (Parm, ZeroConstructor)
};

// Function AudioMixer.AudioMixerBlueprintLibrary.MakePresetSpectralAnalysisBandSettings
struct AudioMixerBlueprintLibrary_MakePresetSpectralAnalysisBandSettings_Params
{
	EAudioSpectrumBandPresetType                       InBandPresetType_69;                                      // (Parm, ZeroConstructor, IsPlainOldData)
	int                                                InNumBands_69;                                            // (Parm, ZeroConstructor, IsPlainOldData)
	int                                                InAttackTimeMsec_69;                                      // (Parm, ZeroConstructor, IsPlainOldData)
	int                                                InReleaseTimeMsec_69;                                     // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<struct FSoundSubmixSpectralAnalysisBandSettings> ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function AudioMixer.AudioMixerBlueprintLibrary.MakeMusicalSpectralAnalysisBandSettings
struct AudioMixerBlueprintLibrary_MakeMusicalSpectralAnalysisBandSettings_Params
{
	int                                                InNumSemitones_69;                                        // (Parm, ZeroConstructor, IsPlainOldData)
	EMusicalNoteName                                   InStartingMusicalNote_69;                                 // (Parm, ZeroConstructor, IsPlainOldData)
	int                                                InStartingOctave_69;                                      // (Parm, ZeroConstructor, IsPlainOldData)
	int                                                InAttackTimeMsec_69;                                      // (Parm, ZeroConstructor, IsPlainOldData)
	int                                                InReleaseTimeMsec_69;                                     // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<struct FSoundSubmixSpectralAnalysisBandSettings> ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function AudioMixer.AudioMixerBlueprintLibrary.MakeFullSpectrumSpectralAnalysisBandSettings
struct AudioMixerBlueprintLibrary_MakeFullSpectrumSpectralAnalysisBandSettings_Params
{
	int                                                InNumBands_69;                                            // (Parm, ZeroConstructor, IsPlainOldData)
	float                                              InMinimumFrequency_69;                                    // (Parm, ZeroConstructor, IsPlainOldData)
	float                                              InMaximumFrequency_69;                                    // (Parm, ZeroConstructor, IsPlainOldData)
	int                                                InAttackTimeMsec_69;                                      // (Parm, ZeroConstructor, IsPlainOldData)
	int                                                InReleaseTimeMsec_69;                                     // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<struct FSoundSubmixSpectralAnalysisBandSettings> ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function AudioMixer.AudioMixerBlueprintLibrary.IsAudioBusActive
struct AudioMixerBlueprintLibrary_IsAudioBusActive_Params
{
	class Object_32759*                                WorldContextObject_69;                                    // (ConstParm, Parm, ZeroConstructor)
	class AudioBus*                                    AudioBus_69;                                              // (Parm, ZeroConstructor)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AudioMixer.AudioMixerBlueprintLibrary.GetPhaseForFrequencies
struct AudioMixerBlueprintLibrary_GetPhaseForFrequencies_Params
{
	class Object_32759*                                WorldContextObject_69;                                    // (ConstParm, Parm, ZeroConstructor)
	TArray<float>                                      Frequencies_69;                                           // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	TArray<float>                                      Phases_69;                                                // (Parm, OutParm, ZeroConstructor)
	class SoundSubmix*                                 SubmixToAnalyze_69;                                       // (Parm, ZeroConstructor)
};

// Function AudioMixer.AudioMixerBlueprintLibrary.GetNumberOfEntriesInSourceEffectChain
struct AudioMixerBlueprintLibrary_GetNumberOfEntriesInSourceEffectChain_Params
{
	class Object_32759*                                WorldContextObject_69;                                    // (ConstParm, Parm, ZeroConstructor)
	class SoundEffectSourcePresetChain*                PresetChain_69;                                           // (Parm, ZeroConstructor)
	int                                                ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AudioMixer.AudioMixerBlueprintLibrary.GetMagnitudeForFrequencies
struct AudioMixerBlueprintLibrary_GetMagnitudeForFrequencies_Params
{
	class Object_32759*                                WorldContextObject_69;                                    // (ConstParm, Parm, ZeroConstructor)
	TArray<float>                                      Frequencies_69;                                           // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	TArray<float>                                      Magnitudes_69;                                            // (Parm, OutParm, ZeroConstructor)
	class SoundSubmix*                                 SubmixToAnalyze_69;                                       // (Parm, ZeroConstructor)
};

// Function AudioMixer.AudioMixerBlueprintLibrary.GetCurrentAudioOutputDeviceName
struct AudioMixerBlueprintLibrary_GetCurrentAudioOutputDeviceName_Params
{
	class Object_32759*                                WorldContextObject_69;                                    // (ConstParm, Parm, ZeroConstructor)
	struct FScriptDelegate                             OnObtainCurrentDeviceEvent_69;                            // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
};

// Function AudioMixer.AudioMixerBlueprintLibrary.GetAvailableAudioOutputDevices
struct AudioMixerBlueprintLibrary_GetAvailableAudioOutputDevices_Params
{
	class Object_32759*                                WorldContextObject_69;                                    // (ConstParm, Parm, ZeroConstructor)
	struct FScriptDelegate                             OnObtainDevicesEvent_69;                                  // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
};

// Function AudioMixer.AudioMixerBlueprintLibrary.Conv_AudioOutputDeviceInfoToString
struct AudioMixerBlueprintLibrary_Conv_AudioOutputDeviceInfoToString_Params
{
	struct FAudioOutputDeviceInfo                      Info_69;                                                  // (ConstParm, Parm, OutParm, ReferenceParm)
	struct FString                                     ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function AudioMixer.AudioMixerBlueprintLibrary.ClearSubmixEffects
struct AudioMixerBlueprintLibrary_ClearSubmixEffects_Params
{
	class Object_32759*                                WorldContextObject_69;                                    // (ConstParm, Parm, ZeroConstructor)
	class SoundSubmix*                                 SoundSubmix_69;                                           // (Parm, ZeroConstructor)
};

// Function AudioMixer.AudioMixerBlueprintLibrary.ClearSubmixEffectChainOverride
struct AudioMixerBlueprintLibrary_ClearSubmixEffectChainOverride_Params
{
	class Object_32759*                                WorldContextObject_69;                                    // (ConstParm, Parm, ZeroConstructor)
	class SoundSubmix*                                 SoundSubmix_69;                                           // (Parm, ZeroConstructor)
	float                                              FadeTimeSec_69;                                           // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function AudioMixer.AudioMixerBlueprintLibrary.ClearMasterSubmixEffects
struct AudioMixerBlueprintLibrary_ClearMasterSubmixEffects_Params
{
	class Object_32759*                                WorldContextObject_69;                                    // (ConstParm, Parm, ZeroConstructor)
};

// Function AudioMixer.AudioMixerBlueprintLibrary.AddSubmixEffect
struct AudioMixerBlueprintLibrary_AddSubmixEffect_Params
{
	class Object_32759*                                WorldContextObject_69;                                    // (ConstParm, Parm, ZeroConstructor)
	class SoundSubmix*                                 SoundSubmix_69;                                           // (Parm, ZeroConstructor)
	class SoundEffectSubmixPreset*                     SubmixEffectPreset_69;                                    // (Parm, ZeroConstructor)
	int                                                ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AudioMixer.AudioMixerBlueprintLibrary.AddSourceEffectToPresetChain
struct AudioMixerBlueprintLibrary_AddSourceEffectToPresetChain_Params
{
	class Object_32759*                                WorldContextObject_69;                                    // (ConstParm, Parm, ZeroConstructor)
	class SoundEffectSourcePresetChain*                PresetChain_69;                                           // (Parm, ZeroConstructor)
	struct FSourceEffectChainEntry                     Entry_69;                                                 // (Parm)
};

// Function AudioMixer.AudioMixerBlueprintLibrary.AddMasterSubmixEffect
struct AudioMixerBlueprintLibrary_AddMasterSubmixEffect_Params
{
	class Object_32759*                                WorldContextObject_69;                                    // (ConstParm, Parm, ZeroConstructor)
	class SoundEffectSubmixPreset*                     SubmixEffectPreset_69;                                    // (Parm, ZeroConstructor)
};

// Function AudioMixer.SubmixEffectDynamicsProcessorPreset.SetSettings
struct SubmixEffectDynamicsProcessorPreset_SetSettings_Params
{
	struct FSubmixEffectDynamicsProcessorSettings      Settings_69;                                              // (ConstParm, Parm, OutParm, ReferenceParm)
};

// Function AudioMixer.SubmixEffectDynamicsProcessorPreset.SetExternalSubmix
struct SubmixEffectDynamicsProcessorPreset_SetExternalSubmix_Params
{
	class SoundSubmix*                                 Submix_69;                                                // (Parm, ZeroConstructor)
};

// Function AudioMixer.SubmixEffectDynamicsProcessorPreset.SetAudioBus
struct SubmixEffectDynamicsProcessorPreset_SetAudioBus_Params
{
	class AudioBus*                                    AudioBus_69;                                              // (Parm, ZeroConstructor)
};

// Function AudioMixer.SubmixEffectDynamicsProcessorPreset.ResetKey
struct SubmixEffectDynamicsProcessorPreset_ResetKey_Params
{
};

// Function AudioMixer.SubmixEffectSubmixEQPreset.SetSettings
struct SubmixEffectSubmixEQPreset_SetSettings_Params
{
	struct FSubmixEffectSubmixEQSettings               InSettings_69;                                            // (ConstParm, Parm, OutParm, ReferenceParm)
};

// Function AudioMixer.SubmixEffectReverbPreset.SetSettingsWithReverbEffect
struct SubmixEffectReverbPreset_SetSettingsWithReverbEffect_Params
{
	class ReverbEffect*                                InReverbEffect_69;                                        // (ConstParm, Parm, ZeroConstructor)
	float                                              WetLevel_69;                                              // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	float                                              DryLevel_69;                                              // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function AudioMixer.SubmixEffectReverbPreset.SetSettings
struct SubmixEffectReverbPreset_SetSettings_Params
{
	struct FSubmixEffectReverbSettings                 InSettings_69;                                            // (ConstParm, Parm, OutParm, ReferenceParm)
};

// Function AudioMixer.QuartzClockHandle.UnsubscribeFromTimeDivision
struct QuartzClockHandle_UnsubscribeFromTimeDivision_Params
{
	class Object_32759*                                WorldContextObject_69;                                    // (ConstParm, Parm, ZeroConstructor)
	EQuartzCommandQuantization                         InQuantizationBoundary_69;                                // (Parm, ZeroConstructor, IsPlainOldData)
	class QuartzClockHandle*                           ClockHandle_69;                                           // (Parm, OutParm, ZeroConstructor)
};

// Function AudioMixer.QuartzClockHandle.UnsubscribeFromAllTimeDivisions
struct QuartzClockHandle_UnsubscribeFromAllTimeDivisions_Params
{
	class Object_32759*                                WorldContextObject_69;                                    // (ConstParm, Parm, ZeroConstructor)
	class QuartzClockHandle*                           ClockHandle_69;                                           // (Parm, OutParm, ZeroConstructor)
};

// Function AudioMixer.QuartzClockHandle.SubscribeToQuantizationEvent
struct QuartzClockHandle_SubscribeToQuantizationEvent_Params
{
	class Object_32759*                                WorldContextObject_69;                                    // (ConstParm, Parm, ZeroConstructor)
	EQuartzCommandQuantization                         InQuantizationBoundary_69;                                // (Parm, ZeroConstructor, IsPlainOldData)
	struct FScriptDelegate                             OnQuantizationEvent_69;                                   // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	class QuartzClockHandle*                           ClockHandle_69;                                           // (Parm, OutParm, ZeroConstructor)
};

// Function AudioMixer.QuartzClockHandle.SubscribeToAllQuantizationEvents
struct QuartzClockHandle_SubscribeToAllQuantizationEvents_Params
{
	class Object_32759*                                WorldContextObject_69;                                    // (ConstParm, Parm, ZeroConstructor)
	struct FScriptDelegate                             OnQuantizationEvent_69;                                   // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	class QuartzClockHandle*                           ClockHandle_69;                                           // (Parm, OutParm, ZeroConstructor)
};

// Function AudioMixer.QuartzClockHandle.StopClock
struct QuartzClockHandle_StopClock_Params
{
	class Object_32759*                                WorldContextObject_69;                                    // (ConstParm, Parm, ZeroConstructor)
	bool                                               CancelPendingEvents_69;                                   // (Parm, ZeroConstructor, IsPlainOldData)
	class QuartzClockHandle*                           ClockHandle_69;                                           // (Parm, OutParm, ZeroConstructor)
};

// Function AudioMixer.QuartzClockHandle.StartOtherClock
struct QuartzClockHandle_StartOtherClock_Params
{
	class Object_32759*                                WorldContextObject_69;                                    // (ConstParm, Parm, ZeroConstructor)
	struct FName                                       OtherClockName_69;                                        // (Parm, ZeroConstructor, IsPlainOldData)
	struct FQuartzQuantizationBoundary                 InQuantizationBoundary_69;                                // (Parm)
	struct FScriptDelegate                             InDelegate_69;                                            // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
};

// Function AudioMixer.QuartzClockHandle.StartClock
struct QuartzClockHandle_StartClock_Params
{
	class Object_32759*                                WorldContextObject_69;                                    // (ConstParm, Parm, ZeroConstructor)
	class QuartzClockHandle*                           ClockHandle_69;                                           // (Parm, OutParm, ZeroConstructor)
};

// Function AudioMixer.QuartzClockHandle.SetTicksPerSecond
struct QuartzClockHandle_SetTicksPerSecond_Params
{
	class Object_32759*                                WorldContextObject_69;                                    // (ConstParm, Parm, ZeroConstructor)
	struct FQuartzQuantizationBoundary                 QuantizationBoundary_69;                                  // (ConstParm, Parm, OutParm, ReferenceParm)
	struct FScriptDelegate                             Delegate_69;                                              // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	class QuartzClockHandle*                           ClockHandle_69;                                           // (Parm, OutParm, ZeroConstructor)
	float                                              TicksPerSecond_69;                                        // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function AudioMixer.QuartzClockHandle.SetThirtySecondNotesPerMinute
struct QuartzClockHandle_SetThirtySecondNotesPerMinute_Params
{
	class Object_32759*                                WorldContextObject_69;                                    // (ConstParm, Parm, ZeroConstructor)
	struct FQuartzQuantizationBoundary                 QuantizationBoundary_69;                                  // (ConstParm, Parm, OutParm, ReferenceParm)
	struct FScriptDelegate                             Delegate_69;                                              // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	class QuartzClockHandle*                           ClockHandle_69;                                           // (Parm, OutParm, ZeroConstructor)
	float                                              ThirtySecondsNotesPerMinute_69;                           // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function AudioMixer.QuartzClockHandle.SetSecondsPerTick
struct QuartzClockHandle_SetSecondsPerTick_Params
{
	class Object_32759*                                WorldContextObject_69;                                    // (ConstParm, Parm, ZeroConstructor)
	struct FQuartzQuantizationBoundary                 QuantizationBoundary_69;                                  // (ConstParm, Parm, OutParm, ReferenceParm)
	struct FScriptDelegate                             Delegate_69;                                              // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	class QuartzClockHandle*                           ClockHandle_69;                                           // (Parm, OutParm, ZeroConstructor)
	float                                              SecondsPerTick_69;                                        // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function AudioMixer.QuartzClockHandle.SetMillisecondsPerTick
struct QuartzClockHandle_SetMillisecondsPerTick_Params
{
	class Object_32759*                                WorldContextObject_69;                                    // (ConstParm, Parm, ZeroConstructor)
	struct FQuartzQuantizationBoundary                 QuantizationBoundary_69;                                  // (ConstParm, Parm, OutParm, ReferenceParm)
	struct FScriptDelegate                             Delegate_69;                                              // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	class QuartzClockHandle*                           ClockHandle_69;                                           // (Parm, OutParm, ZeroConstructor)
	float                                              MillisecondsPerTick_69;                                   // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function AudioMixer.QuartzClockHandle.SetBeatsPerMinute
struct QuartzClockHandle_SetBeatsPerMinute_Params
{
	class Object_32759*                                WorldContextObject_69;                                    // (ConstParm, Parm, ZeroConstructor)
	struct FQuartzQuantizationBoundary                 QuantizationBoundary_69;                                  // (ConstParm, Parm, OutParm, ReferenceParm)
	struct FScriptDelegate                             Delegate_69;                                              // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	class QuartzClockHandle*                           ClockHandle_69;                                           // (Parm, OutParm, ZeroConstructor)
	float                                              BeatsPerMinute_69;                                        // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function AudioMixer.QuartzClockHandle.ResumeClock
struct QuartzClockHandle_ResumeClock_Params
{
	class Object_32759*                                WorldContextObject_69;                                    // (ConstParm, Parm, ZeroConstructor)
	class QuartzClockHandle*                           ClockHandle_69;                                           // (Parm, OutParm, ZeroConstructor)
};

// Function AudioMixer.QuartzClockHandle.ResetTransportQuantized
struct QuartzClockHandle_ResetTransportQuantized_Params
{
	class Object_32759*                                WorldContextObject_69;                                    // (ConstParm, Parm, ZeroConstructor)
	struct FQuartzQuantizationBoundary                 InQuantizationBoundary_69;                                // (Parm)
	struct FScriptDelegate                             InDelegate_69;                                            // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	class QuartzClockHandle*                           ClockHandle_69;                                           // (Parm, OutParm, ZeroConstructor)
};

// Function AudioMixer.QuartzClockHandle.ResetTransport
struct QuartzClockHandle_ResetTransport_Params
{
	class Object_32759*                                WorldContextObject_69;                                    // (ConstParm, Parm, ZeroConstructor)
	struct FScriptDelegate                             InDelegate_69;                                            // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
};

// Function AudioMixer.QuartzClockHandle.PauseClock
struct QuartzClockHandle_PauseClock_Params
{
	class Object_32759*                                WorldContextObject_69;                                    // (ConstParm, Parm, ZeroConstructor)
	class QuartzClockHandle*                           ClockHandle_69;                                           // (Parm, OutParm, ZeroConstructor)
};

// Function AudioMixer.QuartzClockHandle.IsClockRunning
struct QuartzClockHandle_IsClockRunning_Params
{
	class Object_32759*                                WorldContextObject_69;                                    // (ConstParm, Parm, ZeroConstructor)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AudioMixer.QuartzClockHandle.GetTicksPerSecond
struct QuartzClockHandle_GetTicksPerSecond_Params
{
	class Object_32759*                                WorldContextObject_69;                                    // (ConstParm, Parm, ZeroConstructor)
	float                                              ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AudioMixer.QuartzClockHandle.GetThirtySecondNotesPerMinute
struct QuartzClockHandle_GetThirtySecondNotesPerMinute_Params
{
	class Object_32759*                                WorldContextObject_69;                                    // (ConstParm, Parm, ZeroConstructor)
	float                                              ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AudioMixer.QuartzClockHandle.GetSecondsPerTick
struct QuartzClockHandle_GetSecondsPerTick_Params
{
	class Object_32759*                                WorldContextObject_69;                                    // (ConstParm, Parm, ZeroConstructor)
	float                                              ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AudioMixer.QuartzClockHandle.GetMillisecondsPerTick
struct QuartzClockHandle_GetMillisecondsPerTick_Params
{
	class Object_32759*                                WorldContextObject_69;                                    // (ConstParm, Parm, ZeroConstructor)
	float                                              ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AudioMixer.QuartzClockHandle.GetEstimatedRunTime
struct QuartzClockHandle_GetEstimatedRunTime_Params
{
	class Object_32759*                                WorldContextObject_69;                                    // (ConstParm, Parm, ZeroConstructor)
	float                                              ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AudioMixer.QuartzClockHandle.GetDurationOfQuantizationTypeInSeconds
struct QuartzClockHandle_GetDurationOfQuantizationTypeInSeconds_Params
{
	class Object_32759*                                WorldContextObject_69;                                    // (ConstParm, Parm, ZeroConstructor)
	EQuartzCommandQuantization                         QuantizationType_69;                                      // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
	float                                              Multiplier_69;                                            // (Parm, ZeroConstructor, IsPlainOldData)
	float                                              ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AudioMixer.QuartzClockHandle.GetCurrentTimestamp
struct QuartzClockHandle_GetCurrentTimestamp_Params
{
	class Object_32759*                                WorldContextObject_69;                                    // (ConstParm, Parm, ZeroConstructor)
	struct FQuartzTransportTimeStamp                   ReturnValue_69;                                           // (Parm, OutParm, ReturnParm)
};

// Function AudioMixer.QuartzClockHandle.GetBeatsPerMinute
struct QuartzClockHandle_GetBeatsPerMinute_Params
{
	class Object_32759*                                WorldContextObject_69;                                    // (ConstParm, Parm, ZeroConstructor)
	float                                              ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AudioMixer.QuartzSubsystem.IsQuartzEnabled
struct QuartzSubsystem_IsQuartzEnabled_Params
{
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AudioMixer.QuartzSubsystem.IsClockRunning
struct QuartzSubsystem_IsClockRunning_Params
{
	class Object_32759*                                WorldContextObject_69;                                    // (ConstParm, Parm, ZeroConstructor)
	struct FName                                       ClockName_69;                                             // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AudioMixer.QuartzSubsystem.GetRoundTripMinLatency
struct QuartzSubsystem_GetRoundTripMinLatency_Params
{
	class Object_32759*                                WorldContextObject_69;                                    // (ConstParm, Parm, ZeroConstructor)
	float                                              ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AudioMixer.QuartzSubsystem.GetRoundTripMaxLatency
struct QuartzSubsystem_GetRoundTripMaxLatency_Params
{
	class Object_32759*                                WorldContextObject_69;                                    // (ConstParm, Parm, ZeroConstructor)
	float                                              ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AudioMixer.QuartzSubsystem.GetRoundTripAverageLatency
struct QuartzSubsystem_GetRoundTripAverageLatency_Params
{
	class Object_32759*                                WorldContextObject_69;                                    // (ConstParm, Parm, ZeroConstructor)
	float                                              ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AudioMixer.QuartzSubsystem.GetHandleForClock
struct QuartzSubsystem_GetHandleForClock_Params
{
	class Object_32759*                                WorldContextObject_69;                                    // (ConstParm, Parm, ZeroConstructor)
	struct FName                                       ClockName_69;                                             // (Parm, ZeroConstructor, IsPlainOldData)
	class QuartzClockHandle*                           ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function AudioMixer.QuartzSubsystem.GetGameThreadToAudioRenderThreadMinLatency
struct QuartzSubsystem_GetGameThreadToAudioRenderThreadMinLatency_Params
{
	class Object_32759*                                WorldContextObject_69;                                    // (ConstParm, Parm, ZeroConstructor)
	float                                              ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AudioMixer.QuartzSubsystem.GetGameThreadToAudioRenderThreadMaxLatency
struct QuartzSubsystem_GetGameThreadToAudioRenderThreadMaxLatency_Params
{
	class Object_32759*                                WorldContextObject_69;                                    // (ConstParm, Parm, ZeroConstructor)
	float                                              ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AudioMixer.QuartzSubsystem.GetGameThreadToAudioRenderThreadAverageLatency
struct QuartzSubsystem_GetGameThreadToAudioRenderThreadAverageLatency_Params
{
	class Object_32759*                                WorldContextObject_69;                                    // (ConstParm, Parm, ZeroConstructor)
	float                                              ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AudioMixer.QuartzSubsystem.GetEstimatedClockRunTime
struct QuartzSubsystem_GetEstimatedClockRunTime_Params
{
	class Object_32759*                                WorldContextObject_69;                                    // (ConstParm, Parm, ZeroConstructor)
	struct FName                                       InClockName_69;                                           // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
	float                                              ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AudioMixer.QuartzSubsystem.GetDurationOfQuantizationTypeInSeconds
struct QuartzSubsystem_GetDurationOfQuantizationTypeInSeconds_Params
{
	class Object_32759*                                WorldContextObject_69;                                    // (ConstParm, Parm, ZeroConstructor)
	struct FName                                       ClockName_69;                                             // (Parm, ZeroConstructor, IsPlainOldData)
	EQuartzCommandQuantization                         QuantizationType_69;                                      // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
	float                                              Multiplier_69;                                            // (Parm, ZeroConstructor, IsPlainOldData)
	float                                              ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AudioMixer.QuartzSubsystem.GetCurrentClockTimestamp
struct QuartzSubsystem_GetCurrentClockTimestamp_Params
{
	class Object_32759*                                WorldContextObject_69;                                    // (ConstParm, Parm, ZeroConstructor)
	struct FName                                       InClockName_69;                                           // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
	struct FQuartzTransportTimeStamp                   ReturnValue_69;                                           // (Parm, OutParm, ReturnParm)
};

// Function AudioMixer.QuartzSubsystem.GetAudioRenderThreadToGameThreadMinLatency
struct QuartzSubsystem_GetAudioRenderThreadToGameThreadMinLatency_Params
{
	float                                              ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AudioMixer.QuartzSubsystem.GetAudioRenderThreadToGameThreadMaxLatency
struct QuartzSubsystem_GetAudioRenderThreadToGameThreadMaxLatency_Params
{
	float                                              ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AudioMixer.QuartzSubsystem.GetAudioRenderThreadToGameThreadAverageLatency
struct QuartzSubsystem_GetAudioRenderThreadToGameThreadAverageLatency_Params
{
	float                                              ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AudioMixer.QuartzSubsystem.DoesClockExist
struct QuartzSubsystem_DoesClockExist_Params
{
	class Object_32759*                                WorldContextObject_69;                                    // (ConstParm, Parm, ZeroConstructor)
	struct FName                                       ClockName_69;                                             // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AudioMixer.QuartzSubsystem.DeleteClockByName
struct QuartzSubsystem_DeleteClockByName_Params
{
	class Object_32759*                                WorldContextObject_69;                                    // (ConstParm, Parm, ZeroConstructor)
	struct FName                                       ClockName_69;                                             // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function AudioMixer.QuartzSubsystem.DeleteClockByHandle
struct QuartzSubsystem_DeleteClockByHandle_Params
{
	class Object_32759*                                WorldContextObject_69;                                    // (ConstParm, Parm, ZeroConstructor)
	class QuartzClockHandle*                           InClockHandle_69;                                         // (Parm, OutParm, ZeroConstructor, ReferenceParm)
};

// Function AudioMixer.QuartzSubsystem.CreateNewClock
struct QuartzSubsystem_CreateNewClock_Params
{
	class Object_32759*                                WorldContextObject_69;                                    // (ConstParm, Parm, ZeroConstructor)
	struct FName                                       ClockName_69;                                             // (Parm, ZeroConstructor, IsPlainOldData)
	struct FQuartzClockSettings                        InSettings_69;                                            // (Parm)
	bool                                               bOverrideSettingsIfClockExists_69;                        // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bUseAudioEngineClockManager_69;                           // (Parm, ZeroConstructor, IsPlainOldData)
	class QuartzClockHandle*                           ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

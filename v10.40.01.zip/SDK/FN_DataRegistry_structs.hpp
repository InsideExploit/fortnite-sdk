#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Enums
//---------------------------------------------------------------------------

// Enum DataRegistry.EDataRegistryAcquireStatus
enum class EDataRegistryAcquireStatus : uint8_t
{
	NotStarted                     = 0,
	WaitingForInitialAcquire       = 1,
	InitialAcquireFinished         = 2,
	WaitingForResources            = 3,
	AcquireFinished                = 4,
	AcquireError                   = 5,
	DoesNotExist                   = 6,
	EDataRegistryAcquireStatus_MAX = 7
};


// Enum DataRegistry.EMetaDataRegistrySourceAssetUsage
enum class EMetaDataRegistrySourceAssetUsage : uint8_t
{
	NoAssets                       = 0,
	SearchAssets                   = 1,
	RegisterAssets                 = 2,
	SearchAndRegisterAssets        = 3,
	EMetaDataRegistrySourceAssetUsage_MAX = 4
};


// Enum DataRegistry.EDataRegistrySubsystemGetItemResult
enum class EDataRegistrySubsystemGetItemResult : uint8_t
{
	Found                          = 0,
	NotFound                       = 1,
	EDataRegistrySubsystemGetItemResult_MAX = 2
};


// Enum DataRegistry.EDataRegistryAvailability
enum class EDataRegistryAvailability : uint8_t
{
	DoesNotExist                   = 0,
	Unknown                        = 1,
	Remote                         = 2,
	OnDisk                         = 3,
	LocalAsset                     = 4,
	PreCached                      = 5,
	EDataRegistryAvailability_MAX  = 6
};



//---------------------------------------------------------------------------
//Script Structs
//---------------------------------------------------------------------------

// ScriptStruct DataRegistry.DataRegistryIdFormat
// 0x0004
struct FDataRegistryIdFormat
{
	struct FGameplayTag                                BaseGameplayTag_69;                                       // 0x0000(0x0004) (Edit)
};

// ScriptStruct DataRegistry.DataRegistryCachePolicy
// 0x0014
struct FDataRegistryCachePolicy
{
	bool                                               bCacheIsAlwaysVolatile_69;                                // 0x0000(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bUseCurveTableCacheVersion_69;                            // 0x0001(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x2];                                       // 0x0002(0x0002) MISSED OFFSET
	int                                                MinNumberKept_69;                                         // 0x0004(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                MaxNumberKept_69;                                         // 0x0008(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              ForceKeepSeconds_69;                                      // 0x000C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              ForceReleaseSeconds_69;                                   // 0x0010(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct DataRegistry.DataRegistrySource_DataTableRules
// 0x0008
struct FDataRegistrySource_DataTableRules
{
	bool                                               bPrecacheTable_69;                                        // 0x0000(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0001(0x0003) MISSED OFFSET
	float                                              CachedTableKeepSeconds_69;                                // 0x0004(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct DataRegistry.DataRegistryType
// 0x0004
struct FDataRegistryType
{
	struct FName                                       Name_69;                                                  // 0x0000(0x0008) (Edit, BlueprintVisible, ZeroConstructor, SaveGame, IsPlainOldData)
};

// ScriptStruct DataRegistry.DataRegistryId
// 0x0008
struct FDataRegistryId
{
	struct FDataRegistryType                           RegistryType_69;                                          // 0x0000(0x0004) (Edit, BlueprintVisible, ZeroConstructor, SaveGame)
	struct FName                                       ItemName_69;                                              // 0x0004(0x0008) (Edit, BlueprintVisible, ZeroConstructor, SaveGame, IsPlainOldData)
};

// ScriptStruct DataRegistry.DataRegistryLookup
// 0x0018
struct FDataRegistryLookup
{
	unsigned char                                      UnknownData00[0x18];                                      // 0x0000(0x0018) MISSED OFFSET
};

// ScriptStruct DataRegistry.DataRegistrySourceItemId
// 0x0030
struct FDataRegistrySourceItemId
{
	unsigned char                                      UnknownData00[0x30];                                      // 0x0000(0x0030) MISSED OFFSET
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

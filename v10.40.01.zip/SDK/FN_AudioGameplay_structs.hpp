#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Script Structs
//---------------------------------------------------------------------------

// ScriptStruct AudioGameplay.AudioGameplayRequirements
// 0x0050
struct FAudioGameplayRequirements
{
	class AudioRequirementPreset*                      Preset_69;                                                // 0x0000(0x0008) (Edit, BlueprintVisible, ZeroConstructor)
	struct FGameplayTagQuery                           Custom_69;                                                // 0x0008(0x0048) (Edit, BlueprintVisible)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

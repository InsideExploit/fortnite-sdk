#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Classes
//---------------------------------------------------------------------------

// Class AudioLinkEngine.AudioLinkBlueprintInterface
// 0x0000 (0x0028 - 0x0028)
class AudioLinkBlueprintInterface : public Interface
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AudioLinkEngine.AudioLinkBlueprintInterface"));
		
		return ptr;
	}


	void StopLink();
	void SetLinkSound(class SoundBase* NewSound_69);
	void PlayLink(float StartTime_69);
	bool IsLinkPlaying();
};


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

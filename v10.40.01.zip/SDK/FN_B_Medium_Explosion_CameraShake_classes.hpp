#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Classes
//---------------------------------------------------------------------------

// BlueprintGeneratedClass B_Medium_Explosion_CameraShake.B_Medium_Explosion_CameraShake_C
// 0x0000 (0x0210 - 0x0210)
class B_Medium_Explosion_CameraShake_C : public LegacyCameraShake
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("BlueprintGeneratedClass B_Medium_Explosion_CameraShake.B_Medium_Explosion_CameraShake_C"));
		
		return ptr;
	}

};


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function AnimationSharing.AnimationSharingStateProcessor.ProcessActorState
struct AnimationSharingStateProcessor_ProcessActorState_Params
{
	int                                                OutState_69;                                              // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	class Actor_32759*                                 InActor_69;                                               // (Parm, ZeroConstructor)
	unsigned char                                      CurrentState_69;                                          // (Parm, ZeroConstructor, IsPlainOldData)
	unsigned char                                      OnDemandState_69;                                         // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bShouldProcess_69;                                        // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
};

// Function AnimationSharing.AnimationSharingStateProcessor.GetAnimationStateEnum
struct AnimationSharingStateProcessor_GetAnimationStateEnum_Params
{
	class Enum*                                        ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function AnimationSharing.AnimSharingStateInstance.GetInstancedActors
struct AnimSharingStateInstance_GetInstancedActors_Params
{
	TArray<class Actor_32759*>                         Actors_69;                                                // (Parm, OutParm, ZeroConstructor)
};

// Function AnimationSharing.AnimationSharingManager.RegisterActorWithSkeletonBP
struct AnimationSharingManager_RegisterActorWithSkeletonBP_Params
{
	class Actor_32759*                                 InActor_69;                                               // (Parm, ZeroConstructor)
	class Skeleton*                                    SharingSkeleton_69;                                       // (ConstParm, Parm, ZeroConstructor)
};

// Function AnimationSharing.AnimationSharingManager.GetAnimationSharingManager
struct AnimationSharingManager_GetAnimationSharingManager_Params
{
	class Object_32759*                                WorldContextObject_69;                                    // (Parm, ZeroConstructor)
	class AnimationSharingManager*                     ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function AnimationSharing.AnimationSharingManager.CreateAnimationSharingManager
struct AnimationSharingManager_CreateAnimationSharingManager_Params
{
	class Object_32759*                                WorldContextObject_69;                                    // (Parm, ZeroConstructor)
	class AnimationSharingSetup*                       Setup_69;                                                 // (ConstParm, Parm, ZeroConstructor)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AnimationSharing.AnimationSharingManager.AnimationSharingEnabled
struct AnimationSharingManager_AnimationSharingEnabled_Params
{
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

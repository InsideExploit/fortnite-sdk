#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function CRDLevelInstanceRuntime.LevelInstanceGameplayVolume.SetWantsLevelLoaded
struct LevelInstanceGameplayVolume_SetWantsLevelLoaded_Params
{
	bool                                               bInWantsLevelLoaded_69;                                   // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function CRDLevelInstanceRuntime.LevelInstanceGameplayVolume.SetReadyForInstantiation
struct LevelInstanceGameplayVolume_SetReadyForInstantiation_Params
{
	bool                                               bReady_69;                                                // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function CRDLevelInstanceRuntime.LevelInstanceGameplayVolume.SetLevelInstanceName
struct LevelInstanceGameplayVolume_SetLevelInstanceName_Params
{
	struct FString                                     InName_69;                                                // (Parm, ZeroConstructor)
};

// Function CRDLevelInstanceRuntime.LevelInstanceGameplayVolume.SetLevelInstanceContentCollection
struct LevelInstanceGameplayVolume_SetLevelInstanceContentCollection_Params
{
};

// Function CRDLevelInstanceRuntime.LevelInstanceGameplayVolume.SetLevelInstanceActorGuid
struct LevelInstanceGameplayVolume_SetLevelInstanceActorGuid_Params
{
	struct FGuid                                       InLevelInstanceActorGuid_69;                              // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function CRDLevelInstanceRuntime.LevelInstanceGameplayVolume.SetEditMode
struct LevelInstanceGameplayVolume_SetEditMode_Params
{
	bool                                               bInEditMode_69;                                           // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function CRDLevelInstanceRuntime.LevelInstanceGameplayVolume.RemoveActorWhenEndPlay
struct LevelInstanceGameplayVolume_RemoveActorWhenEndPlay_Params
{
	class Actor_32759*                                 Actor_69;                                                 // (Parm, ZeroConstructor)
	TEnumAsByte<EEndPlayReason>                        EndPlayReason_69;                                         // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function CRDLevelInstanceRuntime.LevelInstanceGameplayVolume.RemoveActorWhenDied
struct LevelInstanceGameplayVolume_RemoveActorWhenDied_Params
{
	class Actor_32759*                                 DamagedActor_69;                                          // (Parm, ZeroConstructor)
	float                                              Damage_69;                                                // (Parm, ZeroConstructor, IsPlainOldData)
	class Controller*                                  InstigatedBy_69;                                          // (Parm, ZeroConstructor)
	class Actor_32759*                                 DamageCauser_69;                                          // (Parm, ZeroConstructor)
	struct FVector                                     HitLocation_69;                                           // (Parm, ZeroConstructor, IsPlainOldData)
	class PrimitiveComponent*                          FHitComponent_69;                                         // (Parm, ZeroConstructor, InstancedReference)
	struct FName                                       BoneName_69;                                              // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector                                     Momentum_69;                                              // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function CRDLevelInstanceRuntime.LevelInstanceGameplayVolume.OnVolumeChanged
struct LevelInstanceGameplayVolume_OnVolumeChanged_Params
{
};

// Function CRDLevelInstanceRuntime.LevelInstanceGameplayVolume.OnRep_IsDisabled
struct LevelInstanceGameplayVolume_OnRep_IsDisabled_Params
{
};

// Function CRDLevelInstanceRuntime.LevelInstanceGameplayVolume.OnRep_InstanceLoaded
struct LevelInstanceGameplayVolume_OnRep_InstanceLoaded_Params
{
};

// Function CRDLevelInstanceRuntime.LevelInstanceGameplayVolume.OnRep_EditMode
struct LevelInstanceGameplayVolume_OnRep_EditMode_Params
{
};

// Function CRDLevelInstanceRuntime.LevelInstanceGameplayVolume.OnMinigameStateChanged
struct LevelInstanceGameplayVolume_OnMinigameStateChanged_Params
{
	class FortMinigame*                                Minigame_69;                                              // (Parm, ZeroConstructor)
	EFortMinigameState                                 MinigameState_69;                                         // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function CRDLevelInstanceRuntime.LevelInstanceGameplayVolume.LevelInstanceSizeChanged
struct LevelInstanceGameplayVolume_LevelInstanceSizeChanged_Params
{
	class Actor_32759*                                 InstigatorActor_69;                                       // (ConstParm, Parm, ZeroConstructor)
};

// Function CRDLevelInstanceRuntime.LevelInstanceGameplayVolume.LevelInstanceNameChanged
struct LevelInstanceGameplayVolume_LevelInstanceNameChanged_Params
{
	struct FString                                     Name_69;                                                  // (Parm, ZeroConstructor)
};

// Function CRDLevelInstanceRuntime.LevelInstanceGameplayVolume.LevelInstanceContentCollectionChanged
struct LevelInstanceGameplayVolume_LevelInstanceContentCollectionChanged_Params
{
	class Actor_32759*                                 InstigatorActor_69;                                       // (ConstParm, Parm, ZeroConstructor)
};

// Function CRDLevelInstanceRuntime.LevelInstanceGameplayVolume.LevelInstanceContentChanged
struct LevelInstanceGameplayVolume_LevelInstanceContentChanged_Params
{
	class Actor_32759*                                 InstigatorActor_69;                                       // (ConstParm, Parm, ZeroConstructor)
};

// Function CRDLevelInstanceRuntime.LevelInstanceGameplayVolume.LevelInstanceBeingDestroyed
struct LevelInstanceGameplayVolume_LevelInstanceBeingDestroyed_Params
{
};

// Function CRDLevelInstanceRuntime.LevelInstanceGameplayVolume.IsPreviewActor
struct LevelInstanceGameplayVolume_IsPreviewActor_Params
{
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CRDLevelInstanceRuntime.LevelInstanceGameplayVolume.IsInEditMode
struct LevelInstanceGameplayVolume_IsInEditMode_Params
{
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CRDLevelInstanceRuntime.LevelInstanceGameplayVolume.IsDisabled
struct LevelInstanceGameplayVolume_IsDisabled_Params
{
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CRDLevelInstanceRuntime.LevelInstanceGameplayVolume.InstantiateFromLevelInstanceSaveActor
struct LevelInstanceGameplayVolume_InstantiateFromLevelInstanceSaveActor_Params
{
};

// Function CRDLevelInstanceRuntime.LevelInstanceGameplayVolume.HandleActorHealthChanged
struct LevelInstanceGameplayVolume_HandleActorHealthChanged_Params
{
	class Actor_32759*                                 Actor_69;                                                 // (Parm, ZeroConstructor)
	float                                              NewHealth_69;                                             // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function CRDLevelInstanceRuntime.LevelInstanceGameplayVolume.GetLevelInstanceName
struct LevelInstanceGameplayVolume_GetLevelInstanceName_Params
{
	struct FString                                     ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function CRDLevelInstanceRuntime.LevelInstanceGameplayVolume.CreateLevelInstanceSaveActor
struct LevelInstanceGameplayVolume_CreateLevelInstanceSaveActor_Params
{
	class FortLevelInstanceSaveActor*                  ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function CRDLevelInstanceRuntime.LevelInstanceGameplayVolume.CheckForOverlappingVolumes
struct LevelInstanceGameplayVolume_CheckForOverlappingVolumes_Params
{
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

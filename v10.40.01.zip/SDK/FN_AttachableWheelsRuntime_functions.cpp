// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Functions
//---------------------------------------------------------------------------

// Function AttachableWheelsRuntime.AttachableWheel.OnRep_AttachData
// (Final, Native, Protected, HasOutParms)
// Parameters:
// struct FAttachableWheelAttachData AttachDataPrev_69              (ConstParm, Parm, OutParm, ReferenceParm)

void AttachableWheel::OnRep_AttachData(const struct FAttachableWheelAttachData& AttachDataPrev_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AttachableWheelsRuntime.AttachableWheel.OnRep_AttachData"));

	AttachableWheel_OnRep_AttachData_Params params;
	params.AttachDataPrev_69 = AttachDataPrev_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AttachableWheelsRuntime.AttachableWheel.OnPhysicsStateChanged
// (Final, Native, Protected)
// Parameters:
// class PrimitiveComponent*      PrimitiveComponent_69          (Parm, ZeroConstructor, InstancedReference)
// EComponentPhysicsStateChange   StateChange_69                 (Parm, ZeroConstructor, IsPlainOldData)

void AttachableWheel::OnPhysicsStateChanged(class PrimitiveComponent* PrimitiveComponent_69, EComponentPhysicsStateChange StateChange_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AttachableWheelsRuntime.AttachableWheel.OnPhysicsStateChanged"));

	AttachableWheel_OnPhysicsStateChanged_Params params;
	params.PrimitiveComponent_69 = PrimitiveComponent_69;
	params.StateChange_69 = StateChange_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AttachableWheelsRuntime.AttachableWheel.OnDetached
// (Event, Public, BlueprintEvent)
// Parameters:
// class PrimitiveComponent*      DetachedComponent_69           (Parm, ZeroConstructor, InstancedReference)

void AttachableWheel::OnDetached(class PrimitiveComponent* DetachedComponent_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AttachableWheelsRuntime.AttachableWheel.OnDetached"));

	AttachableWheel_OnDetached_Params params;
	params.DetachedComponent_69 = DetachedComponent_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AttachableWheelsRuntime.AttachableWheel.OnAttached
// (Event, Public, BlueprintEvent)
// Parameters:
// class PrimitiveComponent*      AttachedComponent_69           (Parm, ZeroConstructor, InstancedReference)

void AttachableWheel::OnAttached(class PrimitiveComponent* AttachedComponent_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AttachableWheelsRuntime.AttachableWheel.OnAttached"));

	AttachableWheel_OnAttached_Params params;
	params.AttachedComponent_69 = AttachedComponent_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AttachableWheelsRuntime.AttachableWheel.GetWorldSpaceAttachData
// (Final, Native, Public, HasOutParms, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FAttachableWheelAttachData OutAttachData_69               (Parm, OutParm)
// class PrimitiveComponent*      PrimitiveComponent_69          (Parm, ZeroConstructor, InstancedReference)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool AttachableWheel::GetWorldSpaceAttachData(class PrimitiveComponent* PrimitiveComponent_69, struct FAttachableWheelAttachData* OutAttachData_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AttachableWheelsRuntime.AttachableWheel.GetWorldSpaceAttachData"));

	AttachableWheel_GetWorldSpaceAttachData_Params params;
	params.PrimitiveComponent_69 = PrimitiveComponent_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (OutAttachData_69 != nullptr)
		*OutAttachData_69 = params.OutAttachData_69;

	return params.ReturnValue_69;
}


// Function AttachableWheelsRuntime.AttachableWheel.GetAttachedComponent
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// class PrimitiveComponent*      ReturnValue_69                 (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)

class PrimitiveComponent* AttachableWheel::GetAttachedComponent()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AttachableWheelsRuntime.AttachableWheel.GetAttachedComponent"));

	AttachableWheel_GetAttachedComponent_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AttachableWheelsRuntime.AttachableWheel.DrawDebug
// (Final, Native, Public, BlueprintCallable, Const)

void AttachableWheel::DrawDebug()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AttachableWheelsRuntime.AttachableWheel.DrawDebug"));

	AttachableWheel_DrawDebug_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AttachableWheelsRuntime.AttachableWheel.DetachFrom
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// class PrimitiveComponent*      InComponent_69                 (Parm, ZeroConstructor, InstancedReference)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool AttachableWheel::DetachFrom(class PrimitiveComponent* InComponent_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AttachableWheelsRuntime.AttachableWheel.DetachFrom"));

	AttachableWheel_DetachFrom_Params params;
	params.InComponent_69 = InComponent_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AttachableWheelsRuntime.AttachableWheel.Detach
// (Final, Native, Public, BlueprintCallable)

void AttachableWheel::Detach()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AttachableWheelsRuntime.AttachableWheel.Detach"));

	AttachableWheel_Detach_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AttachableWheelsRuntime.AttachableWheel.AttachTo
// (Final, Native, Public, HasOutParms, HasDefaults, BlueprintCallable)
// Parameters:
// class PrimitiveComponent*      InComponent_69                 (Parm, ZeroConstructor, InstancedReference)
// struct FVector                 WorldLocation_69               (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
// struct FVector                 AxleDirection_69               (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool AttachableWheel::AttachTo(class PrimitiveComponent* InComponent_69, const struct FVector& WorldLocation_69, const struct FVector& AxleDirection_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AttachableWheelsRuntime.AttachableWheel.AttachTo"));

	AttachableWheel_AttachTo_Params params;
	params.InComponent_69 = InComponent_69;
	params.WorldLocation_69 = WorldLocation_69;
	params.AxleDirection_69 = AxleDirection_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AttachableWheelsRuntime.AttachableWheel.AttachInPlace
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// class PrimitiveComponent*      InComponent_69                 (Parm, ZeroConstructor, InstancedReference)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool AttachableWheel::AttachInPlace(class PrimitiveComponent* InComponent_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AttachableWheelsRuntime.AttachableWheel.AttachInPlace"));

	AttachableWheel_AttachInPlace_Params params;
	params.InComponent_69 = InComponent_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AttachableWheelsRuntime.AttachableWheelsComponent.OnWheelDetached
// (RequiredAPI, Event, Public, BlueprintEvent)
// Parameters:
// class AttachableWheel*         AttachedWheel_69               (Parm, ZeroConstructor)

void AttachableWheelsComponent::OnWheelDetached(class AttachableWheel* AttachedWheel_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AttachableWheelsRuntime.AttachableWheelsComponent.OnWheelDetached"));

	AttachableWheelsComponent_OnWheelDetached_Params params;
	params.AttachedWheel_69 = AttachedWheel_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AttachableWheelsRuntime.AttachableWheelsComponent.OnWheelAttached
// (RequiredAPI, Event, Public, BlueprintEvent)
// Parameters:
// class AttachableWheel*         AttachedWheel_69               (Parm, ZeroConstructor)

void AttachableWheelsComponent::OnWheelAttached(class AttachableWheel* AttachedWheel_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AttachableWheelsRuntime.AttachableWheelsComponent.OnWheelAttached"));

	AttachableWheelsComponent_OnWheelAttached_Params params;
	params.AttachedWheel_69 = AttachedWheel_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AttachableWheelsRuntime.AttachableWheelsComponent.HandleWheelDetached_Internal
// (Final, Native, Protected)
// Parameters:
// class AttachableWheel*         AttachedWheel_69               (Parm, ZeroConstructor)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool AttachableWheelsComponent::HandleWheelDetached_Internal(class AttachableWheel* AttachedWheel_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AttachableWheelsRuntime.AttachableWheelsComponent.HandleWheelDetached_Internal"));

	AttachableWheelsComponent_HandleWheelDetached_Internal_Params params;
	params.AttachedWheel_69 = AttachedWheel_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AttachableWheelsRuntime.AttachableWheelsComponent.HandleWheelAttached_Internal
// (Final, Native, Protected)
// Parameters:
// class AttachableWheel*         AttachedWheel_69               (Parm, ZeroConstructor)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool AttachableWheelsComponent::HandleWheelAttached_Internal(class AttachableWheel* AttachedWheel_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AttachableWheelsRuntime.AttachableWheelsComponent.HandleWheelAttached_Internal"));

	AttachableWheelsComponent_HandleWheelAttached_Internal_Params params;
	params.AttachedWheel_69 = AttachedWheel_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AttachableWheelsRuntime.AttachableWheelsComponent.GetAttachedWheels
// (Final, RequiredAPI, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// TArray<class AttachableWheel*> ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

TArray<class AttachableWheel*> AttachableWheelsComponent::GetAttachedWheels()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AttachableWheelsRuntime.AttachableWheelsComponent.GetAttachedWheels"));

	AttachableWheelsComponent_GetAttachedWheels_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AttachableWheelsRuntime.AttachableWheelsComponent.GetAttachedWheelClosestOnAxis
// (Final, RequiredAPI, Native, Public, HasOutParms, HasDefaults, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FVector                 Point_69                       (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
// float                          OutClosetDistanceToAxis_69     (Parm, OutParm, ZeroConstructor, IsPlainOldData)
// struct FVector                 OutClosestPointOnAxis_69       (Parm, OutParm, ZeroConstructor, IsPlainOldData)
// struct FVector                 OutClosestAxis_69              (Parm, OutParm, ZeroConstructor, IsPlainOldData)
// class AttachableWheel*         ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

class AttachableWheel* AttachableWheelsComponent::GetAttachedWheelClosestOnAxis(const struct FVector& Point_69, float* OutClosetDistanceToAxis_69, struct FVector* OutClosestPointOnAxis_69, struct FVector* OutClosestAxis_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AttachableWheelsRuntime.AttachableWheelsComponent.GetAttachedWheelClosestOnAxis"));

	AttachableWheelsComponent_GetAttachedWheelClosestOnAxis_Params params;
	params.Point_69 = Point_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (OutClosetDistanceToAxis_69 != nullptr)
		*OutClosetDistanceToAxis_69 = params.OutClosetDistanceToAxis_69;
	if (OutClosestPointOnAxis_69 != nullptr)
		*OutClosestPointOnAxis_69 = params.OutClosestPointOnAxis_69;
	if (OutClosestAxis_69 != nullptr)
		*OutClosestAxis_69 = params.OutClosestAxis_69;

	return params.ReturnValue_69;
}


// Function AttachableWheelsRuntime.AttachableWheelsComponent.DrawDebug
// (Final, RequiredAPI, Native, Public, BlueprintCallable, Const)

void AttachableWheelsComponent::DrawDebug()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AttachableWheelsRuntime.AttachableWheelsComponent.DrawDebug"));

	AttachableWheelsComponent_DrawDebug_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AttachableWheelsRuntime.AttachableWheelsComponent.DetachAllWheels
// (Final, RequiredAPI, Native, Public, BlueprintCallable)
// Parameters:
// int                            ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int AttachableWheelsComponent::DetachAllWheels()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AttachableWheelsRuntime.AttachableWheelsComponent.DetachAllWheels"));

	AttachableWheelsComponent_DetachAllWheels_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

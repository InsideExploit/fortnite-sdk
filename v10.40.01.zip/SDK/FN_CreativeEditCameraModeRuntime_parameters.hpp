#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function CreativeEditCameraModeRuntime.FortPawnComponent_CreativeEditCameraMode.ServerSetImmersiveEdit
struct FortPawnComponent_CreativeEditCameraMode_ServerSetImmersiveEdit_Params
{
	bool                                               bWantsToImmersiveEdit_69;                                 // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bIsCreativeEditModeEnabled_69;                            // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function CreativeEditCameraModeRuntime.FortPawnComponent_CreativeEditCameraMode.RestrictImmersiveMode
struct FortPawnComponent_CreativeEditCameraMode_RestrictImmersiveMode_Params
{
};

// Function CreativeEditCameraModeRuntime.FortPawnComponent_CreativeEditCameraMode.OnWantsToImmersiveEditChanged
struct FortPawnComponent_CreativeEditCameraMode_OnWantsToImmersiveEditChanged_Params
{
	class FortCreativeOption*                          CreativeOption_69;                                        // (Parm, ZeroConstructor)
	unsigned char                                      IndexValue_69;                                            // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function CreativeEditCameraModeRuntime.FortPawnComponent_CreativeEditCameraMode.OnRep_IsImmersiveModeEnabled
struct FortPawnComponent_CreativeEditCameraMode_OnRep_IsImmersiveModeEnabled_Params
{
};

// Function CreativeEditCameraModeRuntime.FortPawnComponent_CreativeEditCameraMode.OnCreativeEditModeChanged
struct FortPawnComponent_CreativeEditCameraMode_OnCreativeEditModeChanged_Params
{
	bool                                               bIsCreativeEditModeEnabled_69;                            // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function CreativeEditCameraModeRuntime.FortPawnComponent_CreativeEditCameraMode.HandleWeaponEquipped
struct FortPawnComponent_CreativeEditCameraMode_HandleWeaponEquipped_Params
{
	class FortWeapon*                                  NewWeapon_69;                                             // (Parm, ZeroConstructor)
	class FortWeapon*                                  PrevWeapon_69;                                            // (Parm, ZeroConstructor)
};

// Function CreativeEditCameraModeRuntime.FortPawnComponent_CreativeEditCameraMode.BindVehicleEvents
struct FortPawnComponent_CreativeEditCameraMode_BindVehicleEvents_Params
{
	class Pawn*                                        Pawn_69;                                                  // (Parm, ZeroConstructor)
	class Controller*                                  OldController_69;                                         // (Parm, ZeroConstructor)
	class Controller*                                  NewController_69;                                         // (Parm, ZeroConstructor)
};

// Function CreativeEditCameraModeRuntime.FortPawnComponent_CreativeEditCameraMode.AllowImmersiveMode
struct FortPawnComponent_CreativeEditCameraMode_AllowImmersiveMode_Params
{
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

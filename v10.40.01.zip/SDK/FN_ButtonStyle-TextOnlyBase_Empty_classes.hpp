#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Classes
//---------------------------------------------------------------------------

// BlueprintGeneratedClass ButtonStyle-TextOnlyBase_Empty.ButtonStyle-TextOnlyBase_Empty_C
// 0x0000 (0x0730 - 0x0730)
class ButtonStyle_TextOnlyBase_Empty_C : public ButtonStyle_Base_C
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("BlueprintGeneratedClass ButtonStyle-TextOnlyBase_Empty.ButtonStyle-TextOnlyBase_Empty_C"));
		
		return ptr;
	}

};


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Classes
//---------------------------------------------------------------------------

// Class AugmentedReality.ARActor
// 0x0000 (0x0288 - 0x0288)
class ARActor : public Actor_32759
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AugmentedReality.ARActor"));
		
		return ptr;
	}


	class ARComponent* AddARComponent(class ARComponent* InComponentClass_69, const struct FGuid& NativeID_69);
};


// Class AugmentedReality.ARBlueprintLibrary
// 0x0000 (0x0028 - 0x0028)
class ARBlueprintLibrary : public BlueprintFunctionLibrary
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AugmentedReality.ARBlueprintLibrary"));
		
		return ptr;
	}


	void STATIC_UnpinComponent(class SceneComponent* ComponentToUnpin_69);
	bool STATIC_ToggleARCapture(bool bOnOff_69, EARCaptureType CaptureType_69);
	void STATIC_StopARSession();
	void STATIC_StartARSession(class ARSessionConfig* SessionConfig_69);
	void STATIC_SetEnabledXRCamera(bool bOnOff_69);
	void STATIC_SetARWorldScale(float InWorldScale_69);
	void STATIC_SetARWorldOriginLocationAndRotation(const struct FVector& OriginLocation_69, const struct FRotator& OriginRotation_69, bool bIsTransformInWorldSpace_69, bool bMaintainUpDirection_69);
	void STATIC_SetAlignmentTransform(const struct FCoreUObject_FTransform& InAlignmentTransform_69);
	bool STATIC_SaveARPinToLocalStore(const struct FName& InSaveName_69, class ARPin* InPin_69);
	struct FIntPoint STATIC_ResizeXRCamera(const struct FIntPoint& InSize_69);
	void STATIC_RemovePin(class ARPin* PinToRemove_69);
	void STATIC_RemoveARPinFromLocalStore(const struct FName& InSaveName_69);
	void STATIC_RemoveAllARPinsFromLocalStore();
	class ARPin* STATIC_PinComponentToTraceResult(class SceneComponent* ComponentToPin_69, const struct FARTraceResult& TraceResult_69, const struct FName& DebugName_69);
	bool STATIC_PinComponentToARPin(class SceneComponent* ComponentToPin_69, class ARPin* Pin_69);
	class ARPin* STATIC_PinComponent(class SceneComponent* ComponentToPin_69, const struct FCoreUObject_FTransform& PinToWorldTransform_69, class ARTrackedGeometry* TrackedGeometry_69, const struct FName& DebugName_69);
	void STATIC_PauseARSession();
	TMap<struct FName, class ARPin*> STATIC_LoadARPinsFromLocalStore();
	TArray<struct FARTraceResult> STATIC_LineTraceTrackedObjects3D(const struct FVector& Start_69, const struct FVector& End_69, bool bTestFeaturePoints_69, bool bTestGroundPlane_69, bool bTestPlaneExtents_69, bool bTestPlaneBoundaryPolygon_69);
	TArray<struct FARTraceResult> STATIC_LineTraceTrackedObjects(const struct FVector2D& ScreenCoord_69, bool bTestFeaturePoints_69, bool bTestGroundPlane_69, bool bTestPlaneExtents_69, bool bTestPlaneBoundaryPolygon_69);
	bool STATIC_IsSessionTypeSupported(EARSessionType SessionType_69);
	bool STATIC_IsSessionTrackingFeatureSupported(EARSessionType SessionType_69, EARSessionTrackingFeature SessionTrackingFeature_69);
	bool STATIC_IsSceneReconstructionSupported(EARSessionType SessionType_69, EARSceneReconstruction SceneReconstructionMethod_69);
	bool STATIC_IsARSupported();
	bool STATIC_IsARPinLocalStoreSupported();
	bool STATIC_IsARPinLocalStoreReady();
	EARWorldMappingState STATIC_GetWorldMappingStatus();
	EARTrackingQualityReason STATIC_GetTrackingQualityReason();
	EARTrackingQuality STATIC_GetTrackingQuality();
	TArray<struct FARVideoFormat> STATIC_GetSupportedVideoFormats(EARSessionType SessionType_69);
	class ARSessionConfig* STATIC_GetSessionConfig();
	TArray<struct FVector> STATIC_GetPointCloud();
	class ARTexture* STATIC_GetPersonSegmentationImage();
	class ARTexture* STATIC_GetPersonSegmentationDepthImage();
	bool STATIC_GetObjectClassificationAtLocation(const struct FVector& InWorldLocation_69, float MaxLocationDiff_69, EARObjectClassification* OutClassification_69, struct FVector* OutClassificationLocation_69);
	int STATIC_GetNumberOfTrackedFacesSupported();
	class ARLightEstimate* STATIC_GetCurrentLightEstimate();
	bool STATIC_GetCameraIntrinsics(struct FARCameraIntrinsics* OutCameraIntrinsics_69);
	class ARTextureCameraImage* STATIC_GetCameraImage();
	class ARTextureCameraDepth* STATIC_GetCameraDepth();
	float STATIC_GetARWorldScale();
	class ARTexture* STATIC_GetARTexture(EARTextureType TextureType_69);
	struct FARSessionStatus STATIC_GetARSessionStatus();
	TArray<class ARTrackedPose*> STATIC_GetAllTrackedPoses();
	TArray<class ARTrackedPoint*> STATIC_GetAllTrackedPoints();
	TArray<class ARPlaneGeometry*> STATIC_GetAllTrackedPlanes();
	TArray<class ARTrackedImage*> STATIC_GetAllTrackedImages();
	TArray<class AREnvironmentCaptureProbe*> STATIC_GetAllTrackedEnvironmentCaptureProbes();
	TArray<struct FARPose2D> STATIC_GetAllTracked2DPoses();
	TArray<class ARPin*> STATIC_GetAllPins();
	TArray<class ARTrackedGeometry*> STATIC_GetAllGeometriesByClass(class ARTrackedGeometry* GeometryClass_69);
	TArray<class ARTrackedGeometry*> STATIC_GetAllGeometries();
	struct FCoreUObject_FTransform STATIC_GetAlignmentTransform();
	TArray<class ARTrackedPoint*> STATIC_FindTrackedPointsByName(const struct FString& PointName_69);
	void STATIC_DebugDrawTrackedGeometry(class ARTrackedGeometry* TrackedGeometry_69, class Object_32759* WorldContextObject_69, const struct FLinearColor& Color_69, float OutlineThickness_69, float PersistForSeconds_69);
	void STATIC_DebugDrawPin(class ARPin* ARPin_69, class Object_32759* WorldContextObject_69, const struct FLinearColor& Color_69, float Scale_69, float PersistForSeconds_69);
	void STATIC_CalculateClosestIntersection(TArray<struct FVector> StartPoints_69, TArray<struct FVector> EndPoints_69, struct FVector* ClosestIntersection_69);
	void STATIC_CalculateAlignmentTransform(const struct FCoreUObject_FTransform& TransformInFirstCoordinateSystem_69, const struct FCoreUObject_FTransform& TransformInSecondCoordinateSystem_69, struct FCoreUObject_FTransform* AlignmentTransform_69);
	bool STATIC_AddTrackedPointWithName(const struct FCoreUObject_FTransform& WorldTransform_69, const struct FString& PointName_69, bool bDeletePointsWithSameName_69);
	class ARCandidateImage* STATIC_AddRuntimeCandidateImage(class ARSessionConfig* SessionConfig_69, class Texture2D* CandidateTexture_69, const struct FString& FriendlyName_69, float PhysicalWidth_69);
	bool STATIC_AddManualEnvironmentCaptureProbe(const struct FVector& Location_69, const struct FVector& Extent_69);
};


// Class AugmentedReality.ARTraceResultLibrary_32759
// 0x0000 (0x0028 - 0x0028)
class ARTraceResultLibrary_32759 : public BlueprintFunctionLibrary
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AugmentedReality.ARTraceResultLibrary_32759"));
		
		return ptr;
	}


	class ARTrackedGeometry* STATIC_GetTrackedGeometry(const struct FARTraceResult& TraceResult_69);
	EARLineTraceChannels STATIC_GetTraceChannel(const struct FARTraceResult& TraceResult_69);
	struct FCoreUObject_FTransform STATIC_GetLocalTransform(const struct FARTraceResult& TraceResult_69);
	struct FCoreUObject_FTransform STATIC_GetLocalToWorldTransform(const struct FARTraceResult& TraceResult_69);
	struct FCoreUObject_FTransform STATIC_GetLocalToTrackingTransform(const struct FARTraceResult& TraceResult_69);
	float STATIC_GetDistanceFromCamera(const struct FARTraceResult& TraceResult_69);
};


// Class AugmentedReality.ARBaseAsyncTaskBlueprintProxy
// 0x0020 (0x0050 - 0x0030)
class ARBaseAsyncTaskBlueprintProxy : public BlueprintAsyncActionBase
{
public:
	unsigned char                                      UnknownData00[0x20];                                      // 0x0030(0x0020) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AugmentedReality.ARBaseAsyncTaskBlueprintProxy"));
		
		return ptr;
	}

};


// Class AugmentedReality.ARSaveWorldAsyncTaskBlueprintProxy
// 0x0030 (0x0080 - 0x0050)
class ARSaveWorldAsyncTaskBlueprintProxy : public ARBaseAsyncTaskBlueprintProxy
{
public:
	unsigned char                                      UnknownData00[0x10];                                      // 0x0050(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty AugmentedReality.ARSaveWorldAsyncTaskBlueprintProxy.OnSuccess_69
	unsigned char                                      UnknownData01[0x10];                                      // 0x0060(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty AugmentedReality.ARSaveWorldAsyncTaskBlueprintProxy.OnFailed_69
	unsigned char                                      UnknownData02[0x10];                                      // 0x0070(0x0010) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AugmentedReality.ARSaveWorldAsyncTaskBlueprintProxy"));
		
		return ptr;
	}


	class ARSaveWorldAsyncTaskBlueprintProxy* STATIC_ARSaveWorld(class Object_32759* WorldContextObject_69);
};


// Class AugmentedReality.ARGetCandidateObjectAsyncTaskBlueprintProxy
// 0x0060 (0x00B0 - 0x0050)
class ARGetCandidateObjectAsyncTaskBlueprintProxy : public ARBaseAsyncTaskBlueprintProxy
{
public:
	unsigned char                                      UnknownData00[0x10];                                      // 0x0050(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty AugmentedReality.ARGetCandidateObjectAsyncTaskBlueprintProxy.OnSuccess_69
	unsigned char                                      UnknownData01[0x10];                                      // 0x0060(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty AugmentedReality.ARGetCandidateObjectAsyncTaskBlueprintProxy.OnFailed_69
	unsigned char                                      UnknownData02[0x40];                                      // 0x0070(0x0040) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AugmentedReality.ARGetCandidateObjectAsyncTaskBlueprintProxy"));
		
		return ptr;
	}


	class ARGetCandidateObjectAsyncTaskBlueprintProxy* STATIC_ARGetCandidateObject(class Object_32759* WorldContextObject_69, const struct FVector& Location_69, const struct FVector& Extent_69);
};


// Class AugmentedReality.ARComponent
// 0x0080 (0x0320 - 0x02A0)
class ARComponent : public SceneComponent
{
public:
	struct FGuid                                       NativeID_69;                                              // 0x02A0(0x0010) (Net, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x30];                                      // 0x02B0(0x0030) MISSED OFFSET
	bool                                               bUseDefaultReplication_69;                                // 0x02E0(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x7];                                       // 0x02E1(0x0007) MISSED OFFSET
	class MaterialInterface*                           DefaultMeshMaterial_69;                                   // 0x02E8(0x0008) (Edit, ZeroConstructor)
	class MaterialInterface*                           DefaultWireframeMeshMaterial_69;                          // 0x02F0(0x0008) (Edit, ZeroConstructor)
	class MRMeshComponent*                             MRMeshComponent_69;                                       // 0x02F8(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	class ARTrackedGeometry*                           MyTrackedGeometry_69;                                     // 0x0300(0x0008) (ZeroConstructor)
	unsigned char                                      UnknownData02[0x18];                                      // 0x0308(0x0018) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AugmentedReality.ARComponent"));
		
		return ptr;
	}


	void UpdateVisualization();
	void SetNativeID(const struct FGuid& NativeID_69);
	void ReceiveRemove();
	void OnRep_Payload();
	class MRMeshComponent* GetMRMesh();
};


// Class AugmentedReality.ARPlaneComponent
// 0x00D0 (0x03F0 - 0x0320)
class ARPlaneComponent : public ARComponent
{
public:
	struct FARPlaneUpdatePayload                       ReplicatedPayload_69;                                     // 0x0320(0x00D0) (BlueprintVisible, BlueprintReadOnly, Net)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AugmentedReality.ARPlaneComponent"));
		
		return ptr;
	}


	void STATIC_SetPlaneComponentDebugMode(EPlaneComponentDebugMode NewDebugMode_69);
	void STATIC_SetObjectClassificationDebugColors(TMap<EARObjectClassification, struct FLinearColor> InColors_69);
	void ServerUpdatePayload(const struct FARPlaneUpdatePayload& NewPayload_69);
	void ReceiveUpdate(const struct FARPlaneUpdatePayload& Payload_69);
	void ReceiveAdd(const struct FARPlaneUpdatePayload& Payload_69);
	TMap<EARObjectClassification, struct FLinearColor> STATIC_GetObjectClassificationDebugColors();
};


// Class AugmentedReality.ARPointComponent
// 0x0010 (0x0330 - 0x0320)
class ARPointComponent : public ARComponent
{
public:
	struct FARPointUpdatePayload                       ReplicatedPayload_69;                                     // 0x0320(0x0001) (BlueprintVisible, BlueprintReadOnly, Net, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0xF];                                       // 0x0321(0x000F) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AugmentedReality.ARPointComponent"));
		
		return ptr;
	}


	void ServerUpdatePayload(const struct FARPointUpdatePayload& NewPayload_69);
	void ReceiveUpdate(const struct FARPointUpdatePayload& Payload_69);
	void ReceiveAdd(const struct FARPointUpdatePayload& Payload_69);
};


// Class AugmentedReality.ARFaceComponent
// 0x0090 (0x03B0 - 0x0320)
class ARFaceComponent : public ARComponent
{
public:
	EARFaceTransformMixing                             TransformSetting_69;                                      // 0x0320(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	bool                                               bUpdateVertexNormal_69;                                   // 0x0321(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	bool                                               bFaceOutOfScreen_69;                                      // 0x0322(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x5];                                       // 0x0323(0x0005) MISSED OFFSET
	struct FARFaceUpdatePayload                        ReplicatedPayload_69;                                     // 0x0328(0x0060) (BlueprintVisible, BlueprintReadOnly, Net)
	unsigned char                                      UnknownData01[0x28];                                      // 0x0388(0x0028) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AugmentedReality.ARFaceComponent"));
		
		return ptr;
	}


	void STATIC_SetFaceComponentDebugMode(EFaceComponentDebugMode NewDebugMode_69);
	void ServerUpdatePayload(const struct FARFaceUpdatePayload& NewPayload_69);
	void ReceiveUpdate(const struct FARFaceUpdatePayload& Payload_69);
	void ReceiveAdd(const struct FARFaceUpdatePayload& Payload_69);
};


// Class AugmentedReality.ARImageComponent
// 0x00A0 (0x03C0 - 0x0320)
class ARImageComponent : public ARComponent
{
public:
	struct FARImageUpdatePayload                       ReplicatedPayload_69;                                     // 0x0320(0x00A0) (BlueprintVisible, BlueprintReadOnly, Net)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AugmentedReality.ARImageComponent"));
		
		return ptr;
	}


	void STATIC_SetImageComponentDebugMode(EImageComponentDebugMode NewDebugMode_69);
	void ServerUpdatePayload(const struct FARImageUpdatePayload& NewPayload_69);
	void ReceiveUpdate(const struct FARImageUpdatePayload& Payload_69);
	void ReceiveAdd(const struct FARImageUpdatePayload& Payload_69);
};


// Class AugmentedReality.ARQRCodeComponent
// 0x00B0 (0x03D0 - 0x0320)
class ARQRCodeComponent : public ARComponent
{
public:
	struct FARQRCodeUpdatePayload                      ReplicatedPayload_69;                                     // 0x0320(0x00B0) (BlueprintVisible, BlueprintReadOnly, Net)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AugmentedReality.ARQRCodeComponent"));
		
		return ptr;
	}


	void STATIC_SetQRCodeComponentDebugMode(EQRCodeComponentDebugMode NewDebugMode_69);
	void ServerUpdatePayload(const struct FARQRCodeUpdatePayload& NewPayload_69);
	void ReceiveUpdate(const struct FARQRCodeUpdatePayload& Payload_69);
	void ReceiveAdd(const struct FARQRCodeUpdatePayload& Payload_69);
};


// Class AugmentedReality.ARPoseComponent
// 0x0070 (0x0390 - 0x0320)
class ARPoseComponent : public ARComponent
{
public:
	struct FARPoseUpdatePayload                        ReplicatedPayload_69;                                     // 0x0320(0x0070) (BlueprintVisible, BlueprintReadOnly, Net)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AugmentedReality.ARPoseComponent"));
		
		return ptr;
	}


	void STATIC_SetPoseComponentDebugMode(EPoseComponentDebugMode NewDebugMode_69);
	void ServerUpdatePayload(const struct FARPoseUpdatePayload& NewPayload_69);
	void ReceiveUpdate(const struct FARPoseUpdatePayload& Payload_69);
	void ReceiveAdd(const struct FARPoseUpdatePayload& Payload_69);
};


// Class AugmentedReality.AREnvironmentProbeComponent
// 0x0060 (0x0380 - 0x0320)
class AREnvironmentProbeComponent : public ARComponent
{
public:
	struct FAREnvironmentProbeUpdatePayload            ReplicatedPayload_69;                                     // 0x0320(0x0060) (BlueprintVisible, BlueprintReadOnly, Net)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AugmentedReality.AREnvironmentProbeComponent"));
		
		return ptr;
	}


	void ServerUpdatePayload(const struct FAREnvironmentProbeUpdatePayload& NewPayload_69);
	void ReceiveUpdate(const struct FAREnvironmentProbeUpdatePayload& Payload_69);
	void ReceiveAdd(const struct FAREnvironmentProbeUpdatePayload& Payload_69);
};


// Class AugmentedReality.ARObjectComponent
// 0x0060 (0x0380 - 0x0320)
class ARObjectComponent : public ARComponent
{
public:
	struct FARObjectUpdatePayload                      ReplicatedPayload_69;                                     // 0x0320(0x0060) (BlueprintVisible, BlueprintReadOnly, Net)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AugmentedReality.ARObjectComponent"));
		
		return ptr;
	}


	void ServerUpdatePayload(const struct FARObjectUpdatePayload& NewPayload_69);
	void ReceiveUpdate(const struct FARObjectUpdatePayload& Payload_69);
	void ReceiveAdd(const struct FARObjectUpdatePayload& Payload_69);
};


// Class AugmentedReality.ARMeshComponent
// 0x0090 (0x03B0 - 0x0320)
class ARMeshComponent : public ARComponent
{
public:
	struct FARMeshUpdatePayload                        ReplicatedPayload_69;                                     // 0x0320(0x0090) (BlueprintVisible, BlueprintReadOnly, Net)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AugmentedReality.ARMeshComponent"));
		
		return ptr;
	}


	void ServerUpdatePayload(const struct FARMeshUpdatePayload& NewPayload_69);
	void ReceiveUpdate(const struct FARMeshUpdatePayload& Payload_69);
	void ReceiveAdd(const struct FARMeshUpdatePayload& Payload_69);
};


// Class AugmentedReality.ARGeoAnchorComponent
// 0x00A0 (0x03C0 - 0x0320)
class ARGeoAnchorComponent : public ARComponent
{
public:
	struct FARGeoAnchorUpdatePayload                   ReplicatedPayload_69;                                     // 0x0320(0x00A0) (BlueprintVisible, BlueprintReadOnly, Net)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AugmentedReality.ARGeoAnchorComponent"));
		
		return ptr;
	}


	void STATIC_SetGeoAnchorComponentDebugMode(EGeoAnchorComponentDebugMode NewDebugMode_69);
	void ServerUpdatePayload(const struct FARGeoAnchorUpdatePayload& NewPayload_69);
	void ReceiveUpdate(const struct FARGeoAnchorUpdatePayload& Payload_69);
	void ReceiveAdd(const struct FARGeoAnchorUpdatePayload& Payload_69);
};


// Class AugmentedReality.ARDependencyHandler
// 0x0000 (0x0028 - 0x0028)
class ARDependencyHandler : public Object_32759
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AugmentedReality.ARDependencyHandler"));
		
		return ptr;
	}


	void StartARSessionLatent(class Object_32759* WorldContextObject_69, class ARSessionConfig* SessionConfig_69, const struct FLatentActionInfo& LatentInfo_69);
	void RequestARSessionPermission(class Object_32759* WorldContextObject_69, class ARSessionConfig* SessionConfig_69, const struct FLatentActionInfo& LatentInfo_69, EARServicePermissionRequestResult* OutPermissionResult_69);
	void InstallARService(class Object_32759* WorldContextObject_69, const struct FLatentActionInfo& LatentInfo_69, EARServiceInstallRequestResult* OutInstallResult_69);
	class ARDependencyHandler* STATIC_GetARDependencyHandler();
	void CheckARServiceAvailability(class Object_32759* WorldContextObject_69, const struct FLatentActionInfo& LatentInfo_69, EARServiceAvailability* OutAvailability_69);
};


// Class AugmentedReality.ARGeoTrackingSupport
// 0x0000 (0x0028 - 0x0028)
class ARGeoTrackingSupport : public Object_32759
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AugmentedReality.ARGeoTrackingSupport"));
		
		return ptr;
	}


	class ARGeoTrackingSupport* STATIC_GetGeoTrackingSupport();
	EARGeoTrackingStateReason GetGeoTrackingStateReason();
	EARGeoTrackingState GetGeoTrackingState();
	EARGeoTrackingAccuracy GetGeoTrackingAccuracy();
	bool AddGeoAnchorAtLocationWithAltitude(float Longitude_69, float Latitude_69, float AltitudeMeters_69, const struct FString& OptionalAnchorName_69);
	bool AddGeoAnchorAtLocation(float Longitude_69, float Latitude_69, const struct FString& OptionalAnchorName_69);
};


// Class AugmentedReality.CheckGeoTrackingAvailabilityAsyncTaskBlueprintProxy
// 0x0050 (0x00A0 - 0x0050)
class CheckGeoTrackingAvailabilityAsyncTaskBlueprintProxy : public ARBaseAsyncTaskBlueprintProxy
{
public:
	unsigned char                                      UnknownData00[0x10];                                      // 0x0050(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty AugmentedReality.CheckGeoTrackingAvailabilityAsyncTaskBlueprintProxy.OnSuccess_69
	unsigned char                                      UnknownData01[0x10];                                      // 0x0060(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty AugmentedReality.CheckGeoTrackingAvailabilityAsyncTaskBlueprintProxy.OnFailed_69
	unsigned char                                      UnknownData02[0x30];                                      // 0x0070(0x0030) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AugmentedReality.CheckGeoTrackingAvailabilityAsyncTaskBlueprintProxy"));
		
		return ptr;
	}


	void GeoTrackingAvailabilityDelegate__DelegateSignature(bool bIsAvailable_69, const struct FString& Error_69);
	class CheckGeoTrackingAvailabilityAsyncTaskBlueprintProxy* STATIC_CheckGeoTrackingAvailabilityAtLocation(class Object_32759* WorldContextObject_69, float Longitude_69, float Latitude_69);
	class CheckGeoTrackingAvailabilityAsyncTaskBlueprintProxy* STATIC_CheckGeoTrackingAvailability(class Object_32759* WorldContextObject_69);
};


// Class AugmentedReality.GetGeoLocationAsyncTaskBlueprintProxy
// 0x0058 (0x00A8 - 0x0050)
class GetGeoLocationAsyncTaskBlueprintProxy : public ARBaseAsyncTaskBlueprintProxy
{
public:
	unsigned char                                      UnknownData00[0x10];                                      // 0x0050(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty AugmentedReality.GetGeoLocationAsyncTaskBlueprintProxy.OnSuccess_69
	unsigned char                                      UnknownData01[0x10];                                      // 0x0060(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty AugmentedReality.GetGeoLocationAsyncTaskBlueprintProxy.OnFailed_69
	unsigned char                                      UnknownData02[0x38];                                      // 0x0070(0x0038) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AugmentedReality.GetGeoLocationAsyncTaskBlueprintProxy"));
		
		return ptr;
	}


	void GetGeoLocationDelegate__DelegateSignature(float Longitude_69, float Latitude_69, float Altitude_69, const struct FString& Error_69);
	class GetGeoLocationAsyncTaskBlueprintProxy* STATIC_GetGeoLocationAtWorldPosition(class Object_32759* WorldContextObject_69, const struct FVector& WorldPosition_69);
};


// Class AugmentedReality.ARLifeCycleComponent
// 0x0030 (0x02D0 - 0x02A0)
class ARLifeCycleComponent : public SceneComponent
{
public:
	unsigned char                                      UnknownData00[0x10];                                      // 0x02A0(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty AugmentedReality.ARLifeCycleComponent.OnARActorSpawnedDelegate_69
	unsigned char                                      UnknownData01[0x10];                                      // 0x02B0(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty AugmentedReality.ARLifeCycleComponent.OnARActorToBeDestroyedDelegate_69
	unsigned char                                      UnknownData02[0x10];                                      // 0x02C0(0x0010) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AugmentedReality.ARLifeCycleComponent"));
		
		return ptr;
	}


	void ServerSpawnARActor(class Object_32759* ComponentClass_69, const struct FGuid& NativeID_69);
	void ServerDestroyARActor(class ARActor* Actor_69);
	void InstanceARActorToBeDestroyedDelegate__DelegateSignature(class ARActor* Actor_69);
	void InstanceARActorSpawnedDelegate__DelegateSignature(class Object_32759* ComponentClass_69, const struct FGuid& NativeID_69, class ARActor* SpawnedActor_69);
};


// Class AugmentedReality.ARLightEstimate
// 0x0000 (0x0028 - 0x0028)
class ARLightEstimate : public Object_32759
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AugmentedReality.ARLightEstimate"));
		
		return ptr;
	}

};


// Class AugmentedReality.ARBasicLightEstimate
// 0x0018 (0x0040 - 0x0028)
class ARBasicLightEstimate : public ARLightEstimate
{
public:
	float                                              AmbientIntensityLumens_69;                                // 0x0028(0x0004) (ZeroConstructor, IsPlainOldData)
	float                                              AmbientColorTemperatureKelvin_69;                         // 0x002C(0x0004) (ZeroConstructor, IsPlainOldData)
	struct FLinearColor                                AmbientColor_69;                                          // 0x0030(0x0010) (ZeroConstructor, IsPlainOldData)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AugmentedReality.ARBasicLightEstimate"));
		
		return ptr;
	}


	float GetAmbientIntensityLumens();
	float GetAmbientColorTemperatureKelvin();
	struct FLinearColor GetAmbientColor();
};


// Class AugmentedReality.AROriginActor
// 0x0000 (0x0288 - 0x0288)
class AROriginActor : public Actor_32759
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AugmentedReality.AROriginActor"));
		
		return ptr;
	}

};


// Class AugmentedReality.ARPin
// 0x0128 (0x0150 - 0x0028)
class ARPin : public Object_32759
{
public:
	class ARTrackedGeometry*                           TrackedGeometry_69;                                       // 0x0028(0x0008) (ZeroConstructor)
	class SceneComponent*                              PinnedComponent_69;                                       // 0x0030(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	unsigned char                                      UnknownData00[0x8];                                       // 0x0038(0x0008) MISSED OFFSET
	struct FCoreUObject_FTransform                     LocalToTrackingTransform_69;                              // 0x0040(0x0060) (IsPlainOldData)
	struct FCoreUObject_FTransform                     LocalToAlignedTrackingTransform_69;                       // 0x00A0(0x0060) (IsPlainOldData)
	EARTrackingState                                   TrackingState_69;                                         // 0x0100(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x1F];                                      // 0x0101(0x001F) MISSED OFFSET
	unsigned char                                      UnknownData02[0x10];                                      // 0x0101(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty AugmentedReality.ARPin.OnARTrackingStateChanged_69
	unsigned char                                      UnknownData03[0x10];                                      // 0x0130(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty AugmentedReality.ARPin.OnARTransformUpdated_69
	unsigned char                                      UnknownData04[0x10];                                      // 0x0140(0x0010) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AugmentedReality.ARPin"));
		
		return ptr;
	}


	EARTrackingState GetTrackingState();
	class ARTrackedGeometry* GetTrackedGeometry();
	class SceneComponent* GetPinnedComponent();
	struct FCoreUObject_FTransform GetLocalToWorldTransform();
	struct FCoreUObject_FTransform GetLocalToTrackingTransform();
	struct FName GetDebugName();
	void DebugDraw(class World* World_69, const struct FLinearColor& Color_69, float Scale_69, float PersistForSeconds_69);
};


// Class AugmentedReality.ARSessionConfig
// 0x00E0 (0x0110 - 0x0030)
class ARSessionConfig : public DataAsset
{
public:
	bool                                               bGenerateMeshDataFromTrackedGeometry_69;                  // 0x0030(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	bool                                               bGenerateCollisionForMeshData_69;                         // 0x0031(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	bool                                               bGenerateNavMeshForMeshData_69;                           // 0x0032(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	bool                                               bUseMeshDataForOcclusion_69;                              // 0x0033(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	bool                                               bRenderMeshDataInWireframe_69;                            // 0x0034(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	bool                                               bTrackSceneObjects_69;                                    // 0x0035(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	bool                                               bUsePersonSegmentationForOcclusion_69;                    // 0x0036(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	bool                                               bUseSceneDepthForOcclusion_69;                            // 0x0037(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	bool                                               bUseAutomaticImageScaleEstimation_69;                     // 0x0038(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	bool                                               bUseStandardOnboardingUX_69;                              // 0x0039(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	EARWorldAlignment                                  WorldAlignment_69;                                        // 0x003A(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	EARSessionType                                     SessionType_69;                                           // 0x003B(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	EARPlaneDetectionMode                              PlaneDetectionMode_69;                                    // 0x003C(0x0001) (ZeroConstructor, Deprecated, IsPlainOldData)
	bool                                               bHorizontalPlaneDetection_69;                             // 0x003D(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	bool                                               bVerticalPlaneDetection_69;                               // 0x003E(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	bool                                               bEnableAutoFocus_69;                                      // 0x003F(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	EARLightEstimationMode                             LightEstimationMode_69;                                   // 0x0040(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	EARFrameSyncMode                                   FrameSyncMode_69;                                         // 0x0041(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	bool                                               bEnableAutomaticCameraOverlay_69;                         // 0x0042(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	bool                                               bEnableAutomaticCameraTracking_69;                        // 0x0043(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	bool                                               bResetCameraTracking_69;                                  // 0x0044(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	bool                                               bResetTrackedObjects_69;                                  // 0x0045(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x2];                                       // 0x0046(0x0002) MISSED OFFSET
	TArray<class ARCandidateImage*>                    CandidateImages_69;                                       // 0x0048(0x0010) (Edit, ZeroConstructor)
	int                                                MaxNumSimultaneousImagesTracked_69;                       // 0x0058(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	EAREnvironmentCaptureProbeType                     EnvironmentCaptureProbeType_69;                           // 0x005C(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x3];                                       // 0x005D(0x0003) MISSED OFFSET
	TArray<unsigned char>                              WorldMapData_69;                                          // 0x0060(0x0010) (Edit, ZeroConstructor, EditConst)
	TArray<class ARCandidateObject*>                   CandidateObjects_69;                                      // 0x0070(0x0010) (Edit, ZeroConstructor)
	struct FARVideoFormat                              DesiredVideoFormat_69;                                    // 0x0080(0x000C) (Edit)
	bool                                               bUseOptimalVideoFormat_69;                                // 0x008C(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	EARFaceTrackingDirection                           FaceTrackingDirection_69;                                 // 0x008D(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	EARFaceTrackingUpdate                              FaceTrackingUpdate_69;                                    // 0x008E(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData02[0x1];                                       // 0x008F(0x0001) MISSED OFFSET
	int                                                MaxNumberOfTrackedFaces_69;                               // 0x0090(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData03[0x4];                                       // 0x0094(0x0004) MISSED OFFSET
	TArray<unsigned char>                              SerializedARCandidateImageDatabase_69;                    // 0x0098(0x0010) (ZeroConstructor)
	EARSessionTrackingFeature                          EnabledSessionTrackingFeature_69;                         // 0x00A8(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	EARSceneReconstruction                             SceneReconstructionMethod_69;                             // 0x00A9(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData04[0x6];                                       // 0x00AA(0x0006) MISSED OFFSET
	class ARPlaneComponent*                            PlaneComponentClass_69;                                   // 0x00B0(0x0008) (Edit, ZeroConstructor)
	class ARPointComponent*                            PointComponentClass_69;                                   // 0x00B8(0x0008) (Edit, ZeroConstructor)
	class ARFaceComponent*                             FaceComponentClass_69;                                    // 0x00C0(0x0008) (Edit, ZeroConstructor)
	class ARImageComponent*                            ImageComponentClass_69;                                   // 0x00C8(0x0008) (Edit, ZeroConstructor)
	class ARQRCodeComponent*                           QRCodeComponentClass_69;                                  // 0x00D0(0x0008) (Edit, ZeroConstructor)
	class ARPoseComponent*                             PoseComponentClass_69;                                    // 0x00D8(0x0008) (Edit, ZeroConstructor)
	class AREnvironmentProbeComponent*                 EnvironmentProbeComponentClass_69;                        // 0x00E0(0x0008) (Edit, ZeroConstructor)
	class ARObjectComponent*                           ObjectComponentClass_69;                                  // 0x00E8(0x0008) (Edit, ZeroConstructor)
	class ARMeshComponent*                             MeshComponentClass_69;                                    // 0x00F0(0x0008) (Edit, ZeroConstructor)
	class ARGeoAnchorComponent*                        GeoAnchorComponentClass_69;                               // 0x00F8(0x0008) (Edit, ZeroConstructor)
	class MaterialInterface*                           DefaultMeshMaterial_69;                                   // 0x0100(0x0008) (Edit, ZeroConstructor)
	class MaterialInterface*                           DefaultWireframeMeshMaterial_69;                          // 0x0108(0x0008) (Edit, ZeroConstructor)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AugmentedReality.ARSessionConfig"));
		
		return ptr;
	}


	bool ShouldResetTrackedObjects();
	bool ShouldResetCameraTracking();
	bool ShouldRenderCameraOverlay();
	bool ShouldEnableCameraTracking();
	bool ShouldEnableAutoFocus();
	void SetWorldMapData(TArray<unsigned char> WorldMapData_69);
	void SetSessionTrackingFeatureToEnable(EARSessionTrackingFeature InSessionTrackingFeature_69);
	void SetSceneReconstructionMethod(EARSceneReconstruction InSceneReconstructionMethod_69);
	void SetResetTrackedObjects(bool bNewValue_69);
	void SetResetCameraTracking(bool bNewValue_69);
	void SetFaceTrackingUpdate(EARFaceTrackingUpdate InUpdate_69);
	void SetFaceTrackingDirection(EARFaceTrackingDirection InDirection_69);
	void SetEnableAutoFocus(bool bNewValue_69);
	void SetDesiredVideoFormat(const struct FARVideoFormat& NewFormat_69);
	void SetCandidateObjectList(TArray<class ARCandidateObject*> InCandidateObjects_69);
	TArray<unsigned char> GetWorldMapData();
	EARWorldAlignment GetWorldAlignment();
	EARSessionType GetSessionType();
	EARSceneReconstruction GetSceneReconstructionMethod();
	EARPlaneDetectionMode GetPlaneDetectionMode();
	int GetMaxNumSimultaneousImagesTracked();
	EARLightEstimationMode GetLightEstimationMode();
	EARFrameSyncMode GetFrameSyncMode();
	EARFaceTrackingUpdate GetFaceTrackingUpdate();
	EARFaceTrackingDirection GetFaceTrackingDirection();
	EAREnvironmentCaptureProbeType GetEnvironmentCaptureProbeType();
	EARSessionTrackingFeature GetEnabledSessionTrackingFeature();
	struct FARVideoFormat GetDesiredVideoFormat();
	TArray<class ARCandidateObject*> GetCandidateObjectList();
	TArray<class ARCandidateImage*> GetCandidateImageList();
	void AddCandidateObject(class ARCandidateObject* CandidateObject_69);
	void AddCandidateImage(class ARCandidateImage* NewCandidateImage_69);
};


// Class AugmentedReality.ARSharedWorldGameMode
// 0x0068 (0x03D8 - 0x0370)
class ARSharedWorldGameMode : public GameMode
{
public:
	int                                                BufferSizePerChunk_69;                                    // 0x0370(0x0004) (Edit, BlueprintVisible, ZeroConstructor, Config, IsPlainOldData)
	unsigned char                                      UnknownData00[0x64];                                      // 0x0374(0x0064) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AugmentedReality.ARSharedWorldGameMode"));
		
		return ptr;
	}


	void SetPreviewImageData(TArray<unsigned char> ImageData_69);
	void SetARWorldSharingIsReady();
	void SetARSharedWorldData(TArray<unsigned char> ARWorldData_69);
	class ARSharedWorldGameState* GetARSharedWorldGameState();
};


// Class AugmentedReality.ARSharedWorldGameState
// 0x0038 (0x0328 - 0x02F0)
class ARSharedWorldGameState : public GameState
{
public:
	TArray<unsigned char>                              PreviewImageData_69;                                      // 0x02F0(0x0010) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
	TArray<unsigned char>                              ARWorldData_69;                                           // 0x0300(0x0010) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
	int                                                PreviewImageBytesTotal_69;                                // 0x0310(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                ARWorldBytesTotal_69;                                     // 0x0314(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                PreviewImageBytesDelivered_69;                            // 0x0318(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                ARWorldBytesDelivered_69;                                 // 0x031C(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x8];                                       // 0x0320(0x0008) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AugmentedReality.ARSharedWorldGameState"));
		
		return ptr;
	}


	void K2_OnARWorldMapIsReady();
};


// Class AugmentedReality.ARSharedWorldPlayerController
// 0x0008 (0x0800 - 0x07F8)
class ARSharedWorldPlayerController : public PlayerController
{
public:
	unsigned char                                      UnknownData00[0x8];                                       // 0x07F8(0x0008) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AugmentedReality.ARSharedWorldPlayerController"));
		
		return ptr;
	}


	void ServerMarkReadyForReceiving();
	void ClientUpdatePreviewImageData(int Offset_69, TArray<unsigned char> Buffer_69);
	void ClientUpdateARWorldData(int Offset_69, TArray<unsigned char> Buffer_69);
	void ClientInitSharedWorld(int PreviewImageSize_69, int ARWorldDataSize_69);
};


// Class AugmentedReality.ARSkyLight
// 0x0010 (0x02A8 - 0x0298)
class ARSkyLight : public SkyLight
{
public:
	class AREnvironmentCaptureProbe*                   CaptureProbe_69;                                          // 0x0298(0x0008) (ZeroConstructor)
	unsigned char                                      UnknownData00[0x8];                                       // 0x02A0(0x0008) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AugmentedReality.ARSkyLight"));
		
		return ptr;
	}


	void SetEnvironmentCaptureProbe(class AREnvironmentCaptureProbe* InCaptureProbe_69);
};


// Class AugmentedReality.ARTexture
// 0x0028 (0x0180 - 0x0158)
class ARTexture : public Texture
{
public:
	EARTextureType                                     TextureType_69;                                           // 0x0158(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0159(0x0003) MISSED OFFSET
	float                                              Timestamp_69;                                             // 0x015C(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	struct FGuid                                       ExternalTextureGuid_69;                                   // 0x0160(0x0010) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	struct FVector2D                                   Size_69;                                                  // 0x0170(0x0010) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AugmentedReality.ARTexture"));
		
		return ptr;
	}

};


// Class AugmentedReality.ARTextureCameraImage
// 0x0000 (0x0180 - 0x0180)
class ARTextureCameraImage : public ARTexture
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AugmentedReality.ARTextureCameraImage"));
		
		return ptr;
	}

};


// Class AugmentedReality.ARTextureCameraDepth
// 0x0008 (0x0188 - 0x0180)
class ARTextureCameraDepth : public ARTexture
{
public:
	EARDepthQuality                                    DepthQuality_69;                                          // 0x0180(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	EARDepthAccuracy                                   DepthAccuracy_69;                                         // 0x0181(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	bool                                               bIsTemporallySmoothed_69;                                 // 0x0182(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x5];                                       // 0x0183(0x0005) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AugmentedReality.ARTextureCameraDepth"));
		
		return ptr;
	}

};


// Class AugmentedReality.AREnvironmentCaptureProbeTexture
// 0x0028 (0x0188 - 0x0160)
class AREnvironmentCaptureProbeTexture : public TextureCube
{
public:
	EARTextureType                                     TextureType_69;                                           // 0x0160(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0161(0x0003) MISSED OFFSET
	float                                              Timestamp_69;                                             // 0x0164(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	struct FGuid                                       ExternalTextureGuid_69;                                   // 0x0168(0x0010) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	struct FVector2D                                   Size_69;                                                  // 0x0178(0x0010) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AugmentedReality.AREnvironmentCaptureProbeTexture"));
		
		return ptr;
	}

};


// Class AugmentedReality.ARTraceResultDummy
// 0x0000 (0x0028 - 0x0028)
class ARTraceResultDummy : public Object_32759
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AugmentedReality.ARTraceResultDummy"));
		
		return ptr;
	}

};


// Class AugmentedReality.ARTrackedGeometry
// 0x0138 (0x0160 - 0x0028)
class ARTrackedGeometry : public Object_32759
{
public:
	struct FGuid                                       UniqueId_69;                                              // 0x0028(0x0010) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x8];                                       // 0x0038(0x0008) MISSED OFFSET
	struct FCoreUObject_FTransform                     LocalToTrackingTransform_69;                              // 0x0040(0x0060) (IsPlainOldData)
	struct FCoreUObject_FTransform                     LocalToAlignedTrackingTransform_69;                       // 0x00A0(0x0060) (IsPlainOldData)
	EARTrackingState                                   TrackingState_69;                                         // 0x0100(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0xF];                                       // 0x0101(0x000F) MISSED OFFSET
	class MRMeshComponent*                             UnderlyingMesh_69;                                        // 0x0110(0x0008) (ExportObject, ZeroConstructor, Transient, InstancedReference)
	EARObjectClassification                            ObjectClassification_69;                                  // 0x0118(0x0001) (ZeroConstructor, IsPlainOldData)
	EARSpatialMeshUsageFlags                           SpatialMeshUsageFlags_69;                                 // 0x0119(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData02[0x16];                                      // 0x011A(0x0016) MISSED OFFSET
	int                                                LastUpdateFrameNumber_69;                                 // 0x0130(0x0004) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData03[0xC];                                       // 0x0134(0x000C) MISSED OFFSET
	struct FName                                       DebugName_69;                                             // 0x0140(0x0008) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData04[0x1C];                                      // 0x0144(0x001C) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AugmentedReality.ARTrackedGeometry"));
		
		return ptr;
	}


	bool IsTracked();
	bool HasSpatialMeshUsageFlag(EARSpatialMeshUsageFlags InFlag_69);
	class MRMeshComponent* GetUnderlyingMesh();
	EARTrackingState GetTrackingState();
	EARObjectClassification GetObjectClassification();
	struct FString GetName();
	struct FCoreUObject_FTransform GetLocalToWorldTransform();
	struct FCoreUObject_FTransform GetLocalToTrackingTransform();
	float GetLastUpdateTimestamp();
	int GetLastUpdateFrameNumber();
	struct FName GetDebugName();
};


// Class AugmentedReality.ARPlaneGeometry
// 0x0050 (0x01B0 - 0x0160)
class ARPlaneGeometry : public ARTrackedGeometry
{
public:
	struct FVector                                     Center_69;                                                // 0x0160(0x0018) (ZeroConstructor, IsPlainOldData)
	struct FVector                                     Extent_69;                                                // 0x0178(0x0018) (ZeroConstructor, IsPlainOldData)
	TArray<struct FVector>                             BoundaryPolygon_69;                                       // 0x0190(0x0010) (ZeroConstructor)
	class ARPlaneGeometry*                             SubsumedBy_69;                                            // 0x01A0(0x0008) (ZeroConstructor)
	unsigned char                                      UnknownData00[0x8];                                       // 0x01A8(0x0008) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AugmentedReality.ARPlaneGeometry"));
		
		return ptr;
	}


	class ARPlaneGeometry* GetSubsumedBy();
	EARPlaneOrientation GetOrientation();
	struct FVector GetExtent();
	struct FVector GetCenter();
	TArray<struct FVector> GetBoundaryPolygonInLocalSpace();
};


// Class AugmentedReality.ARTrackedPoint
// 0x0000 (0x0160 - 0x0160)
class ARTrackedPoint : public ARTrackedGeometry
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AugmentedReality.ARTrackedPoint"));
		
		return ptr;
	}

};


// Class AugmentedReality.ARTrackedImage
// 0x0010 (0x0170 - 0x0160)
class ARTrackedImage : public ARTrackedGeometry
{
public:
	struct FVector2D                                   EstimatedSize_69;                                         // 0x0160(0x0010) (ZeroConstructor, IsPlainOldData)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AugmentedReality.ARTrackedImage"));
		
		return ptr;
	}


	struct FVector2D GetEstimateSize();
	class ARCandidateImage* GetDetectedImage();
};


// Class AugmentedReality.ARTrackedQRCode
// 0x0020 (0x0190 - 0x0170)
class ARTrackedQRCode : public ARTrackedImage
{
public:
	struct FString                                     QRCode_69;                                                // 0x0170(0x0010) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
	int                                                Version_69;                                               // 0x0180(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0xC];                                       // 0x0184(0x000C) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AugmentedReality.ARTrackedQRCode"));
		
		return ptr;
	}

};


// Class AugmentedReality.ARFaceGeometry
// 0x0160 (0x02C0 - 0x0160)
class ARFaceGeometry : public ARTrackedGeometry
{
public:
	unsigned char                                      UnknownData00[0x10];                                      // 0x0160(0x0010) MISSED OFFSET
	bool                                               bIsTracked_69;                                            // 0x0170(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x7];                                       // 0x0171(0x0007) MISSED OFFSET
	TMap<EARFaceBlendShape, float>                     BlendShapes_69;                                           // 0x0178(0x0050)
	unsigned char                                      UnknownData02[0x38];                                      // 0x01C8(0x0038) MISSED OFFSET
	struct FCoreUObject_FTransform                     LeftEyeTransform_69;                                      // 0x0200(0x0060) (IsPlainOldData)
	struct FCoreUObject_FTransform                     RightEyeTransform_69;                                     // 0x0260(0x0060) (IsPlainOldData)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AugmentedReality.ARFaceGeometry"));
		
		return ptr;
	}


	struct FCoreUObject_FTransform GetWorldSpaceEyeTransform(EAREye Eye_69);
	struct FCoreUObject_FTransform GetLocalSpaceEyeTransform(EAREye Eye_69);
	float GetBlendShapeValue(EARFaceBlendShape BlendShape_69);
	TMap<EARFaceBlendShape, float> GetBlendShapes();
};


// Class AugmentedReality.AREnvironmentCaptureProbe
// 0x0020 (0x0180 - 0x0160)
class AREnvironmentCaptureProbe : public ARTrackedGeometry
{
public:
	unsigned char                                      UnknownData00[0x10];                                      // 0x0160(0x0010) MISSED OFFSET
	class AREnvironmentCaptureProbeTexture*            EnvironmentCaptureTexture_69;                             // 0x0170(0x0008) (ZeroConstructor)
	unsigned char                                      UnknownData01[0x8];                                       // 0x0178(0x0008) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AugmentedReality.AREnvironmentCaptureProbe"));
		
		return ptr;
	}


	struct FVector GetExtent();
	class AREnvironmentCaptureProbeTexture* GetEnvironmentCaptureTexture();
};


// Class AugmentedReality.ARTrackedObject
// 0x0000 (0x0160 - 0x0160)
class ARTrackedObject : public ARTrackedGeometry
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AugmentedReality.ARTrackedObject"));
		
		return ptr;
	}


	class ARCandidateObject* GetDetectedObject();
};


// Class AugmentedReality.ARTrackedPose
// 0x0050 (0x01B0 - 0x0160)
class ARTrackedPose : public ARTrackedGeometry
{
public:
	unsigned char                                      UnknownData00[0x50];                                      // 0x0160(0x0050) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AugmentedReality.ARTrackedPose"));
		
		return ptr;
	}


	struct FARPose3D GetTrackedPoseData();
};


// Class AugmentedReality.ARMeshGeometry
// 0x0000 (0x0160 - 0x0160)
class ARMeshGeometry : public ARTrackedGeometry
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AugmentedReality.ARMeshGeometry"));
		
		return ptr;
	}


	bool GetObjectClassificationAtLocation(const struct FVector& InWorldLocation_69, float MaxLocationDiff_69, EARObjectClassification* OutClassification_69, struct FVector* OutClassificationLocation_69);
};


// Class AugmentedReality.ARGeoAnchor
// 0x0010 (0x0170 - 0x0160)
class ARGeoAnchor : public ARTrackedGeometry
{
public:
	unsigned char                                      UnknownData00[0x10];                                      // 0x0160(0x0010) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AugmentedReality.ARGeoAnchor"));
		
		return ptr;
	}


	float GetLongitude();
	float GetLatitude();
	EARAltitudeSource GetAltitudeSource();
	float GetAltitudeMeters();
};


// Class AugmentedReality.ARTrackableNotifyComponent
// 0x0150 (0x01F0 - 0x00A0)
class ARTrackableNotifyComponent : public ActorComponent
{
public:
	unsigned char                                      UnknownData00[0x10];                                      // 0x00A0(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty AugmentedReality.ARTrackableNotifyComponent.OnAddTrackedGeometry_69
	unsigned char                                      UnknownData01[0x10];                                      // 0x00B0(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty AugmentedReality.ARTrackableNotifyComponent.OnUpdateTrackedGeometry_69
	unsigned char                                      UnknownData02[0x10];                                      // 0x00C0(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty AugmentedReality.ARTrackableNotifyComponent.OnRemoveTrackedGeometry_69
	unsigned char                                      UnknownData03[0x10];                                      // 0x00D0(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty AugmentedReality.ARTrackableNotifyComponent.OnAddTrackedPlane_69
	unsigned char                                      UnknownData04[0x10];                                      // 0x00E0(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty AugmentedReality.ARTrackableNotifyComponent.OnUpdateTrackedPlane_69
	unsigned char                                      UnknownData05[0x10];                                      // 0x00F0(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty AugmentedReality.ARTrackableNotifyComponent.OnRemoveTrackedPlane_69
	unsigned char                                      UnknownData06[0x10];                                      // 0x0100(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty AugmentedReality.ARTrackableNotifyComponent.OnAddTrackedPoint_69
	unsigned char                                      UnknownData07[0x10];                                      // 0x0110(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty AugmentedReality.ARTrackableNotifyComponent.OnUpdateTrackedPoint_69
	unsigned char                                      UnknownData08[0x10];                                      // 0x0120(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty AugmentedReality.ARTrackableNotifyComponent.OnRemoveTrackedPoint_69
	unsigned char                                      UnknownData09[0x10];                                      // 0x0130(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty AugmentedReality.ARTrackableNotifyComponent.OnAddTrackedImage_69
	unsigned char                                      UnknownData10[0x10];                                      // 0x0140(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty AugmentedReality.ARTrackableNotifyComponent.OnUpdateTrackedImage_69
	unsigned char                                      UnknownData11[0x10];                                      // 0x0150(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty AugmentedReality.ARTrackableNotifyComponent.OnRemoveTrackedImage_69
	unsigned char                                      UnknownData12[0x10];                                      // 0x0160(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty AugmentedReality.ARTrackableNotifyComponent.OnAddTrackedFace_69
	unsigned char                                      UnknownData13[0x10];                                      // 0x0170(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty AugmentedReality.ARTrackableNotifyComponent.OnUpdateTrackedFace_69
	unsigned char                                      UnknownData14[0x10];                                      // 0x0180(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty AugmentedReality.ARTrackableNotifyComponent.OnRemoveTrackedFace_69
	unsigned char                                      UnknownData15[0x10];                                      // 0x0190(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty AugmentedReality.ARTrackableNotifyComponent.OnAddTrackedEnvProbe_69
	unsigned char                                      UnknownData16[0x10];                                      // 0x01A0(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty AugmentedReality.ARTrackableNotifyComponent.OnUpdateTrackedEnvProbe_69
	unsigned char                                      UnknownData17[0x10];                                      // 0x01B0(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty AugmentedReality.ARTrackableNotifyComponent.OnRemoveTrackedEnvProbe_69
	unsigned char                                      UnknownData18[0x10];                                      // 0x01C0(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty AugmentedReality.ARTrackableNotifyComponent.OnAddTrackedObject_69
	unsigned char                                      UnknownData19[0x10];                                      // 0x01D0(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty AugmentedReality.ARTrackableNotifyComponent.OnUpdateTrackedObject_69
	unsigned char                                      UnknownData20[0x10];                                      // 0x01E0(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty AugmentedReality.ARTrackableNotifyComponent.OnRemoveTrackedObject_69

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AugmentedReality.ARTrackableNotifyComponent"));
		
		return ptr;
	}

};


// Class AugmentedReality.ARTypesDummyClass
// 0x0000 (0x0028 - 0x0028)
class ARTypesDummyClass : public Object_32759
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AugmentedReality.ARTypesDummyClass"));
		
		return ptr;
	}

};


// Class AugmentedReality.ARCandidateImage
// 0x0028 (0x0058 - 0x0030)
class ARCandidateImage : public DataAsset
{
public:
	class Texture2D*                                   CandidateTexture_69;                                      // 0x0030(0x0008) (Edit, ZeroConstructor)
	struct FString                                     FriendlyName_69;                                          // 0x0038(0x0010) (Edit, ZeroConstructor)
	float                                              Width_69;                                                 // 0x0048(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	float                                              Height_69;                                                // 0x004C(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	EARCandidateImageOrientation                       Orientation_69;                                           // 0x0050(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0051(0x0007) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AugmentedReality.ARCandidateImage"));
		
		return ptr;
	}


	float GetPhysicalWidth();
	float GetPhysicalHeight();
	EARCandidateImageOrientation GetOrientation();
	struct FString GetFriendlyName();
	class Texture2D* GetCandidateTexture();
};


// Class AugmentedReality.ARCandidateObject
// 0x0058 (0x0088 - 0x0030)
class ARCandidateObject : public DataAsset
{
public:
	TArray<unsigned char>                              CandidateObjectData_69;                                   // 0x0030(0x0010) (Edit, ZeroConstructor)
	struct FString                                     FriendlyName_69;                                          // 0x0040(0x0010) (Edit, ZeroConstructor)
	struct FBox                                        BoundingBox_69;                                           // 0x0050(0x0038) (Edit, ZeroConstructor, IsPlainOldData)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AugmentedReality.ARCandidateObject"));
		
		return ptr;
	}


	void SetFriendlyName(const struct FString& NewName_69);
	void SetCandidateObjectData(TArray<unsigned char> InCandidateObject_69);
	void SetBoundingBox(const struct FBox& InBoundingBox_69);
	struct FString GetFriendlyName();
	TArray<unsigned char> GetCandidateObjectData();
	struct FBox GetBoundingBox();
};


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Classes
//---------------------------------------------------------------------------

// Class Account.ExternalAccountProvider
// 0x0010 (0x0038 - 0x0028)
class ExternalAccountProvider : public Object_32759
{
public:
	TArray<struct FExternalAccountServiceConfig>       Services_69;                                              // 0x0028(0x0010) (ZeroConstructor, Config)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class Account.ExternalAccountProvider"));
		
		return ptr;
	}

};


// Class Account.OnlineAccountCommon
// 0x0750 (0x0778 - 0x0028)
class OnlineAccountCommon : public Object_32759
{
public:
	unsigned char                                      UnknownData00[0x10];                                      // 0x0028(0x0010) MISSED OFFSET
	struct FString                                     AvailabilityServiceGameName_69;                           // 0x0038(0x0010) (ZeroConstructor, Config)
	bool                                               bRequireLightswitchAtStartup_69;                          // 0x0048(0x0001) (ZeroConstructor, Config, IsPlainOldData)
	unsigned char                                      UnknownData01[0x7];                                       // 0x0049(0x0007) MISSED OFFSET
	struct FString                                     EulaKey_69;                                               // 0x0050(0x0010) (ZeroConstructor, Config)
	TMap<struct FString, struct FString>               EulaKeyMapping_69;                                        // 0x0060(0x0050) (Config)
	bool                                               bEnableWaitingRoom_69;                                    // 0x00B0(0x0001) (ZeroConstructor, Config, IsPlainOldData)
	unsigned char                                      UnknownData02[0x7];                                       // 0x00B1(0x0007) MISSED OFFSET
	TArray<struct FWebEnvUrl>                          WebCreateEpicAccountUrl_69;                               // 0x00B8(0x0010) (ZeroConstructor, Config)
	bool                                               bAllowLocalLogout_69;                                     // 0x00C8(0x0001) (ZeroConstructor, Config, IsPlainOldData)
	unsigned char                                      UnknownData03[0x37];                                      // 0x00C9(0x0037) MISSED OFFSET
	float                                              DefaultLoginStepTimeout_69;                               // 0x0100(0x0004) (ZeroConstructor, Config, IsPlainOldData)
	unsigned char                                      UnknownData04[0x4];                                       // 0x0104(0x0004) MISSED OFFSET
	TMap<struct FName, float>                          CustomLoginStepTimeouts_69;                               // 0x0108(0x0050) (Config)
	bool                                               bEnableDevLoginStepTimeouts_69;                           // 0x0158(0x0001) (ZeroConstructor, Config, IsPlainOldData)
	unsigned char                                      UnknownData05[0x1F];                                      // 0x0159(0x001F) MISSED OFFSET
	struct FString                                     RedeemAccessUrl_69;                                       // 0x0178(0x0010) (ZeroConstructor, Config)
	struct FString                                     RequestFreeAccessUrl_69;                                  // 0x0188(0x0010) (ZeroConstructor, Config)
	struct FString                                     RealGameAccessUrl_69;                                     // 0x0198(0x0010) (ZeroConstructor, Config)
	float                                              SkipRedeemOfflinePurchasesChance_69;                      // 0x01A8(0x0004) (ZeroConstructor, Config, IsPlainOldData)
	bool                                               bUseFreeAccessInsteadOfGameAccess_69;                     // 0x01AC(0x0001) (ZeroConstructor, Config, IsPlainOldData)
	bool                                               bShouldGrantFreeAccess_69;                                // 0x01AD(0x0001) (ZeroConstructor, Config, IsPlainOldData)
	unsigned char                                      UnknownData06[0x1];                                       // 0x01AE(0x0001) MISSED OFFSET
	bool                                               bAllowHomeSharingAccess_69;                               // 0x01AF(0x0001) (ZeroConstructor, Config, IsPlainOldData)
	bool                                               bRequireUGCPrivilege_69;                                  // 0x01B0(0x0001) (ZeroConstructor, Config, IsPlainOldData)
	unsigned char                                      UnknownData07[0x22F];                                     // 0x01B1(0x022F) MISSED OFFSET
	float                                              AccessGrantDelaySeconds_69;                               // 0x03E0(0x0004) (ZeroConstructor, Config, IsPlainOldData)
	unsigned char                                      UnknownData08[0x4];                                       // 0x03E4(0x0004) MISSED OFFSET
	class WaitingRoomState*                            WaitingRoomState_69;                                      // 0x03E8(0x0008) (ZeroConstructor, Transient)
	unsigned char                                      UnknownData09[0x350];                                     // 0x03F0(0x0350) MISSED OFFSET
	bool                                               bAutoCreateHeadlessAccount_69;                            // 0x0740(0x0001) (ZeroConstructor, Config, IsPlainOldData)
	unsigned char                                      UnknownData10[0x37];                                      // 0x0741(0x0037) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class Account.OnlineAccountCommon"));
		
		return ptr;
	}

};


// Class Account.WaitingRoomState
// 0x0060 (0x0088 - 0x0028)
class WaitingRoomState : public Object_32759
{
public:
	unsigned char                                      UnknownData00[0x34];                                      // 0x0028(0x0034) MISSED OFFSET
	int                                                GracePeriodMins_69;                                       // 0x005C(0x0004) (ZeroConstructor, Config, IsPlainOldData)
	unsigned char                                      UnknownData01[0x28];                                      // 0x0060(0x0028) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class Account.WaitingRoomState"));
		
		return ptr;
	}

};


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

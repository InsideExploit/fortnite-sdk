#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function AudioParameterComponent.AudioParameterComponent_C.UpdateRootParameterComponent
struct AudioParameterComponent_C_UpdateRootParameterComponent_Params
{
};

// Function AudioParameterComponent.AudioParameterComponent_C.GetParameters
struct AudioParameterComponent_C_GetParameters_Params
{
	TArray<struct FAudioParameter>                     Parameters_1;                                             // (Parm, OutParm)
};

// Function AudioParameterComponent.AudioParameterComponent_C.SetIntParameterInternal
struct AudioParameterComponent_C_SetIntParameterInternal_Params
{
	struct FName                                       Name_1;                                                   // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
	int                                                Value_1;                                                  // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

// Function AudioParameterComponent.AudioParameterComponent_C.SetBoolParameterInternal
struct AudioParameterComponent_C_SetBoolParameterInternal_Params
{
	struct FName                                       Name_1;                                                   // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
	bool                                               Value_1;                                                  // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

// Function AudioParameterComponent.AudioParameterComponent_C.SetFloatParameterInternal
struct AudioParameterComponent_C_SetFloatParameterInternal_Params
{
	struct FName                                       Name_1;                                                   // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
	double                                             Value_1;                                                  // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

// Function AudioParameterComponent.AudioParameterComponent_C.GetRootParameterComponent
struct AudioParameterComponent_C_GetRootParameterComponent_Params
{
	class AudioParameterComponent_C*                   Component_1;                                              // (Parm, OutParm, ZeroConstructor, InstancedReference)
};

// Function AudioParameterComponent.AudioParameterComponent_C.FindOrAddGetIndex
struct AudioParameterComponent_C_FindOrAddGetIndex_Params
{
	struct FName                                       Name_1;                                                   // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
	int                                                Index_1;                                                  // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
};

// Function AudioParameterComponent.AudioParameterComponent_C.SetIntParameter
struct AudioParameterComponent_C_SetIntParameter_Params
{
	struct FName                                       Name_1;                                                   // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
	int                                                Value_1;                                                  // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

// Function AudioParameterComponent.AudioParameterComponent_C.SetBoolParameter
struct AudioParameterComponent_C_SetBoolParameter_Params
{
	struct FName                                       Name_1;                                                   // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
	bool                                               Value_1;                                                  // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

// Function AudioParameterComponent.AudioParameterComponent_C.SetFloatParameter
struct AudioParameterComponent_C_SetFloatParameter_Params
{
	struct FName                                       Name_1;                                                   // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
	double                                             Value_1;                                                  // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

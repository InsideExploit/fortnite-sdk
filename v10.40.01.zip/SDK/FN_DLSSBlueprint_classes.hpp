#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Classes
//---------------------------------------------------------------------------

// Class DLSSBlueprint.DLSSLibrary
// 0x0000 (0x0028 - 0x0028)
class DLSSLibrary : public BlueprintFunctionLibrary
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class DLSSBlueprint.DLSSLibrary"));
		
		return ptr;
	}


	void STATIC_SetDLSSSharpness(float Sharpness_69);
	void STATIC_SetDLSSMode(EUDLSSMode DLSSMode_69);
	EUDLSSSupport STATIC_QueryDLSSSupport();
	bool STATIC_IsDLSSSupported();
	bool STATIC_IsDLSSModeSupported(EUDLSSMode DLSSMode_69);
	TArray<EUDLSSMode> STATIC_GetSupportedDLSSModes();
	float STATIC_GetDLSSSharpness();
	void STATIC_GetDLSSScreenPercentageRange(float* MinScreenPercentage_69, float* MaxScreenPercentage_69);
	void STATIC_GetDLSSModeInformation(EUDLSSMode DLSSMode_69, const struct FVector2D& ScreenResolution_69, bool* bIsSupported_69, float* OptimalScreenPercentage_69, bool* bIsFixedScreenPercentage_69, float* MinScreenPercentage_69, float* MaxScreenPercentage_69, float* OptimalSharpness_69);
	EUDLSSMode STATIC_GetDLSSMode();
	void STATIC_GetDLSSMinimumDriverVersion(int* MinDriverVersionMajor_69, int* MinDriverVersionMinor_69);
	EUDLSSMode STATIC_GetDefaultDLSSMode();
};


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

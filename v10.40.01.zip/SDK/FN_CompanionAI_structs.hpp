#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Enums
//---------------------------------------------------------------------------

// SolarisGeneratedEnum CompanionAI.command_type
enum class Ecommand_type : uint8_t
{
	go_to                          = 0,
	back_to_me                     = 1,
	back_to_default                = 2,
	hold_position                  = 3,
	revive                         = 4,
	invalid                        = 5
};


// SolarisGeneratedEnum CompanionAI.entity_type
enum class Eentity_type : uint8_t
{
	pawn                           = 0,
	pickup                         = 1,
	weapon                         = 2,
	container                      = 3,
	player_built_actor             = 4,
	building_actor                 = 5,
	undefined                      = 6
};



//---------------------------------------------------------------------------
//Script Structs
//---------------------------------------------------------------------------

// VerseStruct CompanionAI.tuple_Lentity_Mfloat_R
// 0x0010
struct Ftuple_Lentity_Mfloat_R
{
	class Entity*                                      __verse_0x18E3F084_Elem0;                                 // 0x0000(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	double                                             __verse_0x7D844C3C_Elem1;                                 // 0x0008(0x0008) (ZeroConstructor, InstancedReference, IsPlainOldData)
};

// VerseStruct CompanionAI.tuple_L_R
// 0x0001
struct FCompanionAI_Ftuple_L_R
{
	unsigned char                                      $StructPaddingDummy;                                      // 0x0000(0x0001) (ZeroConstructor, IsPlainOldData)
};

// VerseStruct CompanionAI.tuple_Lvector3_Mfloat_Mentity_R
// 0x0028
struct Ftuple_Lvector3_Mfloat_Mentity_R
{
	struct Fvector3                                    __verse_0x18E3F084_Elem0;                                 // 0x0000(0x0018) (ZeroConstructor, InstancedReference, IsPlainOldData)
	double                                             __verse_0x7D844C3C_Elem1;                                 // 0x0018(0x0008) (ZeroConstructor, InstancedReference, IsPlainOldData)
	class Entity*                                      __verse_0x932BF92E_Elem2;                                 // 0x0020(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
};

// VerseStruct CompanionAI.tuple_Lvector3_Mfloat_Mfloat_R
// 0x0028
struct FCompanionAI_Ftuple_Lvector3_Mfloat_Mfloat_R
{
	struct Fvector3                                    __verse_0x18E3F084_Elem0;                                 // 0x0000(0x0018) (ZeroConstructor, InstancedReference, IsPlainOldData)
	double                                             __verse_0x7D844C3C_Elem1;                                 // 0x0018(0x0008) (ZeroConstructor, InstancedReference, IsPlainOldData)
	double                                             __verse_0x932BF92E_Elem2;                                 // 0x0020(0x0008) (ZeroConstructor, InstancedReference, IsPlainOldData)
};

// VerseStruct CompanionAI.tuple_L_Kchar_M_QLevel_Nlog__level_20_3d_20_2e_2e_2e_M_QDuration_Nfloat_20_3d_20_2e_2e_2e_M_QColor_Ncolor_20_3d_20_2e_2e_2e_R
// 0x0041
struct FCompanionAI_Ftuple_L_Kchar_M_QLevel_Nlog__level_20_3d_20_2e_2e_2e_M_QDuration_Nfloat_20_3d_20_2e_2e_2e_M_QColor_Ncolor_20_3d_20_2e_2e_2e_R
{
	unsigned char                                      UnknownData00[0x10];                                      // 0x0000(0x0010) UNKNOWN PROPERTY: VerseStringProperty CompanionAI.tuple_L_Kchar_M_QLevel_Nlog__level_20_3d_20_2e_2e_2e_M_QDuration_Nfloat_20_3d_20_2e_2e_2e_M_QColor_Ncolor_20_3d_20_2e_2e_2e_R.__verse_0x18E3F084_Elem0
	unsigned char                                      UnknownData01[0x2];                                       // 0x0010(0x0002) UNKNOWN PROPERTY: OptionProperty CompanionAI.tuple_L_Kchar_M_QLevel_Nlog__level_20_3d_20_2e_2e_2e_M_QDuration_Nfloat_20_3d_20_2e_2e_2e_M_QColor_Ncolor_20_3d_20_2e_2e_2e_R.__verse_0x7D844C3C_Elem1
	unsigned char                                      UnknownData02[0x6];                                       // 0x0012(0x0006) MISSED OFFSET
	unsigned char                                      UnknownData03[0x9];                                       // 0x0012(0x0009) UNKNOWN PROPERTY: OptionProperty CompanionAI.tuple_L_Kchar_M_QLevel_Nlog__level_20_3d_20_2e_2e_2e_M_QDuration_Nfloat_20_3d_20_2e_2e_2e_M_QColor_Ncolor_20_3d_20_2e_2e_2e_R.__verse_0x932BF92E_Elem2
	unsigned char                                      UnknownData04[0x7];                                       // 0x0021(0x0007) MISSED OFFSET
	unsigned char                                      UnknownData05[0x19];                                      // 0x0021(0x0019) UNKNOWN PROPERTY: OptionProperty CompanionAI.tuple_L_Kchar_M_QLevel_Nlog__level_20_3d_20_2e_2e_2e_M_QDuration_Nfloat_20_3d_20_2e_2e_2e_M_QColor_Ncolor_20_3d_20_2e_2e_2e_R.__verse_0xF64C4596_Elem3
};

// VerseStruct CompanionAI.ping_info
// 0x0038
struct Fping_info
{
	Ecommand_type                                      __verse_0x72E298E9_Type;                                  // 0x0000(0x0001) (ZeroConstructor, InstancedReference, IsPlainOldData)
	Eentity_type                                       __verse_0x6CF7C7E8_EntityType;                            // 0x0001(0x0001) (ZeroConstructor, InstancedReference, IsPlainOldData)
	unsigned char                                      UnknownData00[0x6];                                       // 0x0002(0x0006) MISSED OFFSET
	struct Fvector3                                    __verse_0xB0C27E0A_Location;                              // 0x0008(0x0018) (ZeroConstructor, InstancedReference, IsPlainOldData)
	unsigned char                                      __verse_0x0FA78E7E_LocationOnHorizontalSurface : 1;       // 0x0020(0x0001) (InstancedReference)
	unsigned char                                      UnknownData01[0x7];                                       // 0x0021(0x0007) MISSED OFFSET
	unsigned char                                      UnknownData02[0x8];                                       // 0x0021(0x0008) UNKNOWN PROPERTY: OptionProperty CompanionAI.ping_info.__verse_0x459049A1_Target
	unsigned char                                      UnknownData03[0x8];                                       // 0x0030(0x0008) UNKNOWN PROPERTY: OptionProperty CompanionAI.ping_info.__verse_0xFD64D7AA_Emitter
};

// VerseStruct CompanionAI.tuple_Lvector3_M_Qfort__character_Mlogic_M_QNavigationParameters_Nnavigation__parameters_20_3d_20_2e_2e_2e_R
// 0x0039
struct Ftuple_Lvector3_M_Qfort__character_Mlogic_M_QNavigationParameters_Nnavigation__parameters_20_3d_20_2e_2e_2e_R
{
	struct Fvector3                                    __verse_0x18E3F084_Elem0;                                 // 0x0000(0x0018) (ZeroConstructor, InstancedReference, IsPlainOldData)
	unsigned char                                      UnknownData00[0x8];                                       // 0x0018(0x0008) UNKNOWN PROPERTY: OptionProperty CompanionAI.tuple_Lvector3_M_Qfort__character_Mlogic_M_QNavigationParameters_Nnavigation__parameters_20_3d_20_2e_2e_2e_R.__verse_0x7D844C3C_Elem1
	unsigned char                                      __verse_0x932BF92E_Elem2 : 1;                             // 0x0020(0x0001) (InstancedReference)
	unsigned char                                      UnknownData01[0x7];                                       // 0x0021(0x0007) MISSED OFFSET
	unsigned char                                      UnknownData02[0x11];                                      // 0x0021(0x0011) UNKNOWN PROPERTY: OptionProperty CompanionAI.tuple_Lvector3_M_Qfort__character_Mlogic_M_QNavigationParameters_Nnavigation__parameters_20_3d_20_2e_2e_2e_R.__verse_0xF64C4596_Elem3
};

// VerseStruct CompanionAI.tuple_Lvector3_Mfloat_Mcolor_R
// 0x0038
struct Ftuple_Lvector3_Mfloat_Mcolor_R
{
	struct Fvector3                                    __verse_0x18E3F084_Elem0;                                 // 0x0000(0x0018) (ZeroConstructor, InstancedReference, IsPlainOldData)
	double                                             __verse_0x7D844C3C_Elem1;                                 // 0x0018(0x0008) (ZeroConstructor, InstancedReference, IsPlainOldData)
	struct FVerse_FColor                               __verse_0x932BF92E_Elem2;                                 // 0x0020(0x0018) (ZeroConstructor, InstancedReference, IsPlainOldData)
};

// VerseStruct CompanionAI.tuple_Lobstacle__info_Mentity_R
// 0x0030
struct Ftuple_Lobstacle__info_Mentity_R
{
	struct Fobstacle_info                              __verse_0x18E3F084_Elem0;                                 // 0x0000(0x0028) (InstancedReference)
	class Entity*                                      __verse_0x7D844C3C_Elem1;                                 // 0x0028(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
};

// VerseStruct CompanionAI.tuple_Lvector3_M_QParams_Nsphere__draw__params_R
// 0x0061
struct Ftuple_Lvector3_M_QParams_Nsphere__draw__params_R
{
	struct Fvector3                                    __verse_0x18E3F084_Elem0;                                 // 0x0000(0x0018) (ZeroConstructor, InstancedReference, IsPlainOldData)
	unsigned char                                      UnknownData00[0x49];                                      // 0x0018(0x0049) UNKNOWN PROPERTY: OptionProperty CompanionAI.tuple_Lvector3_M_QParams_Nsphere__draw__params_R.__verse_0x7D844C3C_Elem1
};

// VerseStruct CompanionAI.tuple_L_Kchar_M_Kchar_R
// 0x0020
struct FCompanionAI_Ftuple_L_Kchar_M_Kchar_R
{
	unsigned char                                      UnknownData00[0x10];                                      // 0x0000(0x0010) UNKNOWN PROPERTY: VerseStringProperty CompanionAI.tuple_L_Kchar_M_Kchar_R.__verse_0x18E3F084_Elem0
	unsigned char                                      UnknownData01[0x10];                                      // 0x0010(0x0010) UNKNOWN PROPERTY: VerseStringProperty CompanionAI.tuple_L_Kchar_M_Kchar_R.__verse_0x7D844C3C_Elem1
};

// VerseStruct CompanionAI.tuple_Lnavigation__target_M_QNavigationParameters_Nnavigation__parameters_R
// 0x0019
struct Ftuple_Lnavigation__target_M_QNavigationParameters_Nnavigation__parameters_R
{
	class navigation_target*                           __verse_0x18E3F084_Elem0;                                 // 0x0000(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	unsigned char                                      UnknownData00[0x11];                                      // 0x0008(0x0011) UNKNOWN PROPERTY: OptionProperty CompanionAI.tuple_Lnavigation__target_M_QNavigationParameters_Nnavigation__parameters_R.__verse_0x7D844C3C_Elem1
};

// VerseStruct CompanionAI.tuple_Lvector3_M_Qfort__character_Mlogic_M_QNavigationParameters_Nnavigation__parameters_R
// 0x0039
struct Ftuple_Lvector3_M_Qfort__character_Mlogic_M_QNavigationParameters_Nnavigation__parameters_R
{
	struct Fvector3                                    __verse_0x18E3F084_Elem0;                                 // 0x0000(0x0018) (ZeroConstructor, InstancedReference, IsPlainOldData)
	unsigned char                                      UnknownData00[0x8];                                       // 0x0018(0x0008) UNKNOWN PROPERTY: OptionProperty CompanionAI.tuple_Lvector3_M_Qfort__character_Mlogic_M_QNavigationParameters_Nnavigation__parameters_R.__verse_0x7D844C3C_Elem1
	unsigned char                                      __verse_0x932BF92E_Elem2 : 1;                             // 0x0020(0x0001) (InstancedReference)
	unsigned char                                      UnknownData01[0x7];                                       // 0x0021(0x0007) MISSED OFFSET
	unsigned char                                      UnknownData02[0x11];                                      // 0x0021(0x0011) UNKNOWN PROPERTY: OptionProperty CompanionAI.tuple_Lvector3_M_Qfort__character_Mlogic_M_QNavigationParameters_Nnavigation__parameters_R.__verse_0xF64C4596_Elem3
};

// VerseStruct CompanionAI.tuple_Lvector3_M_Qfalse_Mlogic_M_QNavigationParameters_Nnavigation__parameters_R
// 0x0031
struct Ftuple_Lvector3_M_Qfalse_Mlogic_M_QNavigationParameters_Nnavigation__parameters_R
{
	struct Fvector3                                    __verse_0x18E3F084_Elem0;                                 // 0x0000(0x0018) (ZeroConstructor, InstancedReference, IsPlainOldData)
	unsigned char                                      UnknownData00[0x2];                                       // 0x0018(0x0002) UNKNOWN PROPERTY: OptionProperty CompanionAI.tuple_Lvector3_M_Qfalse_Mlogic_M_QNavigationParameters_Nnavigation__parameters_R.__verse_0x7D844C3C_Elem1
	unsigned char                                      __verse_0x932BF92E_Elem2 : 1;                             // 0x001A(0x0001) (InstancedReference)
	unsigned char                                      UnknownData01[0x5];                                       // 0x001B(0x0005) MISSED OFFSET
	unsigned char                                      UnknownData02[0x11];                                      // 0x001B(0x0011) UNKNOWN PROPERTY: OptionProperty CompanionAI.tuple_Lvector3_M_Qfalse_Mlogic_M_QNavigationParameters_Nnavigation__parameters_R.__verse_0xF64C4596_Elem3
};

// VerseStruct CompanionAI.tuple_Lvector3_Mtype_7b0_2e500000_7d_Mtype_7b1_2e500000_7d_R
// 0x0028
struct Ftuple_Lvector3_Mtype_7b0_2e500000_7d_Mtype_7b1_2e500000_7d_R
{
	struct Fvector3                                    __verse_0x18E3F084_Elem0;                                 // 0x0000(0x0018) (ZeroConstructor, InstancedReference, IsPlainOldData)
	double                                             __verse_0x7D844C3C_Elem1;                                 // 0x0018(0x0008) (ZeroConstructor, InstancedReference, IsPlainOldData)
	double                                             __verse_0x932BF92E_Elem2;                                 // 0x0020(0x0008) (ZeroConstructor, InstancedReference, IsPlainOldData)
};

// VerseStruct CompanionAI.tuple_Lvector3_Mvector3_R
// 0x0030
struct FCompanionAI_Ftuple_Lvector3_Mvector3_R
{
	struct Fvector3                                    __verse_0x18E3F084_Elem0;                                 // 0x0000(0x0018) (ZeroConstructor, InstancedReference, IsPlainOldData)
	struct Fvector3                                    __verse_0x7D844C3C_Elem1;                                 // 0x0018(0x0018) (ZeroConstructor, InstancedReference, IsPlainOldData)
};

// VerseStruct CompanionAI.tuple_L_Kchar_M_Kchar_M_Kchar_M_Kchar_R
// 0x0040
struct Ftuple_L_Kchar_M_Kchar_M_Kchar_M_Kchar_R
{
	unsigned char                                      UnknownData00[0x10];                                      // 0x0000(0x0010) UNKNOWN PROPERTY: VerseStringProperty CompanionAI.tuple_L_Kchar_M_Kchar_M_Kchar_M_Kchar_R.__verse_0x18E3F084_Elem0
	unsigned char                                      UnknownData01[0x10];                                      // 0x0010(0x0010) UNKNOWN PROPERTY: VerseStringProperty CompanionAI.tuple_L_Kchar_M_Kchar_M_Kchar_M_Kchar_R.__verse_0x7D844C3C_Elem1
	unsigned char                                      UnknownData02[0x10];                                      // 0x0020(0x0010) UNKNOWN PROPERTY: VerseStringProperty CompanionAI.tuple_L_Kchar_M_Kchar_M_Kchar_M_Kchar_R.__verse_0x932BF92E_Elem2
	unsigned char                                      UnknownData03[0x10];                                      // 0x0030(0x0010) UNKNOWN PROPERTY: VerseStringProperty CompanionAI.tuple_L_Kchar_M_Kchar_M_Kchar_M_Kchar_R.__verse_0xF64C4596_Elem3
};

// VerseStruct CompanionAI.tuple_Ltype_7b_2d1_2e000000e_2b03_7d_Mtype_7b1_2e000000e_2b03_7d_R
// 0x0010
struct Ftuple_Ltype_7b_2d1_2e000000e_2b03_7d_Mtype_7b1_2e000000e_2b03_7d_R
{
	double                                             __verse_0x18E3F084_Elem0;                                 // 0x0000(0x0008) (ZeroConstructor, InstancedReference, IsPlainOldData)
	double                                             __verse_0x7D844C3C_Elem1;                                 // 0x0008(0x0008) (ZeroConstructor, InstancedReference, IsPlainOldData)
};

// VerseStruct CompanionAI.tuple_Ltype_7b5_2e000000e_2b01_7d_Mtype_7b2_2e000000e_2b02_7d_R
// 0x0010
struct Ftuple_Ltype_7b5_2e000000e_2b01_7d_Mtype_7b2_2e000000e_2b02_7d_R
{
	double                                             __verse_0x18E3F084_Elem0;                                 // 0x0000(0x0008) (ZeroConstructor, InstancedReference, IsPlainOldData)
	double                                             __verse_0x7D844C3C_Elem1;                                 // 0x0008(0x0008) (ZeroConstructor, InstancedReference, IsPlainOldData)
};

// VerseStruct CompanionAI.tuple_Lfloat_Mfloat_R
// 0x0010
struct FCompanionAI_Ftuple_Lfloat_Mfloat_R
{
	double                                             __verse_0x18E3F084_Elem0;                                 // 0x0000(0x0008) (ZeroConstructor, InstancedReference, IsPlainOldData)
	double                                             __verse_0x7D844C3C_Elem1;                                 // 0x0008(0x0008) (ZeroConstructor, InstancedReference, IsPlainOldData)
};

// VerseStruct CompanionAI.tuple_Lvector3_Mtype_7b1_2e000000e_2b02_7d_Mfloat_R
// 0x0028
struct Ftuple_Lvector3_Mtype_7b1_2e000000e_2b02_7d_Mfloat_R
{
	struct Fvector3                                    __verse_0x18E3F084_Elem0;                                 // 0x0000(0x0018) (ZeroConstructor, InstancedReference, IsPlainOldData)
	double                                             __verse_0x7D844C3C_Elem1;                                 // 0x0018(0x0008) (ZeroConstructor, InstancedReference, IsPlainOldData)
	double                                             __verse_0x932BF92E_Elem2;                                 // 0x0020(0x0008) (ZeroConstructor, InstancedReference, IsPlainOldData)
};

// VerseStruct CompanionAI.tuple_Lnavigation__target_M_QNavigationParameters_Nnavigation__parameters_20_3d_20_2e_2e_2e_R
// 0x0019
struct FCompanionAI_Ftuple_Lnavigation__target_M_QNavigationParameters_Nnavigation__parameters_20_3d_20_2e_2e_2e_R
{
	class navigation_target*                           __verse_0x18E3F084_Elem0;                                 // 0x0000(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	unsigned char                                      UnknownData00[0x11];                                      // 0x0008(0x0011) UNKNOWN PROPERTY: OptionProperty CompanionAI.tuple_Lnavigation__target_M_QNavigationParameters_Nnavigation__parameters_20_3d_20_2e_2e_2e_R.__verse_0x7D844C3C_Elem1
};

// VerseStruct CompanionAI.tuple_Lvector3_M_QParams_Nsphere__draw__params_20_3d_20_2e_2e_2e_R
// 0x0061
struct FCompanionAI_Ftuple_Lvector3_M_QParams_Nsphere__draw__params_20_3d_20_2e_2e_2e_R
{
	struct Fvector3                                    __verse_0x18E3F084_Elem0;                                 // 0x0000(0x0018) (ZeroConstructor, InstancedReference, IsPlainOldData)
	unsigned char                                      UnknownData00[0x49];                                      // 0x0018(0x0049) UNKNOWN PROPERTY: OptionProperty CompanionAI.tuple_Lvector3_M_QParams_Nsphere__draw__params_20_3d_20_2e_2e_2e_R.__verse_0x7D844C3C_Elem1
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function AudioMotorSim.AudioMotorModelComponent.Update
struct AudioMotorModelComponent_Update_Params
{
	struct FAudioMotorSimInputContext                  Input_69;                                                 // (Parm)
};

// Function AudioMotorSim.AudioMotorModelComponent.StopOutput
struct AudioMotorModelComponent_StopOutput_Params
{
};

// Function AudioMotorSim.AudioMotorModelComponent.StartOutput
struct AudioMotorModelComponent_StartOutput_Params
{
};

// Function AudioMotorSim.AudioMotorModelComponent.Reset
struct AudioMotorModelComponent_Reset_Params
{
};

// Function AudioMotorSim.AudioMotorModelComponent.RemoveMotorSimComponent
struct AudioMotorModelComponent_RemoveMotorSimComponent_Params
{
	TScriptInterface<class AudioMotorSim>              InComponent_69;                                           // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function AudioMotorSim.AudioMotorModelComponent.RemoveMotorAudioComponent
struct AudioMotorModelComponent_RemoveMotorAudioComponent_Params
{
	TScriptInterface<class AudioMotorSimOutput>        InComponent_69;                                           // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function AudioMotorSim.AudioMotorModelComponent.GetRuntimeInfo
struct AudioMotorModelComponent_GetRuntimeInfo_Params
{
	struct FAudioMotorSimRuntimeContext                ReturnValue_69;                                           // (Parm, OutParm, ReturnParm)
};

// Function AudioMotorSim.AudioMotorModelComponent.GetRpm
struct AudioMotorModelComponent_GetRpm_Params
{
	float                                              ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AudioMotorSim.AudioMotorModelComponent.GetGear
struct AudioMotorModelComponent_GetGear_Params
{
	int                                                ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AudioMotorSim.AudioMotorModelComponent.GetCachedInputData
struct AudioMotorModelComponent_GetCachedInputData_Params
{
	struct FAudioMotorSimInputContext                  ReturnValue_69;                                           // (Parm, OutParm, ReturnParm)
};

// Function AudioMotorSim.AudioMotorModelComponent.AddMotorSimComponent
struct AudioMotorModelComponent_AddMotorSimComponent_Params
{
	TScriptInterface<class AudioMotorSim>              InComponent_69;                                           // (Parm, ZeroConstructor, IsPlainOldData)
	int                                                SortOrder_69;                                             // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function AudioMotorSim.AudioMotorModelComponent.AddMotorAudioComponent
struct AudioMotorModelComponent_AddMotorAudioComponent_Params
{
	TScriptInterface<class AudioMotorSimOutput>        InComponent_69;                                           // (Parm, ZeroConstructor, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function AIModule.AIController.UseBlackboard
struct AIController_UseBlackboard_Params
{
	class BlackboardData*                              BlackboardAsset_69;                                       // (Parm, ZeroConstructor)
	class BlackboardComponent*                         BlackboardComponent_69;                                   // (Parm, OutParm, ZeroConstructor, InstancedReference)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AIModule.AIController.UnclaimTaskResource
struct AIController_UnclaimTaskResource_Params
{
	class GameplayTaskResource*                        ResourceClass_69;                                         // (Parm, ZeroConstructor)
};

// Function AIModule.AIController.SetPathFollowingComponent
struct AIController_SetPathFollowingComponent_Params
{
	class PathFollowingComponent*                      NewPFComponent_69;                                        // (Parm, ZeroConstructor, InstancedReference)
};

// Function AIModule.AIController.SetMoveBlockDetection
struct AIController_SetMoveBlockDetection_Params
{
	bool                                               bEnable_69;                                               // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function AIModule.AIController.RunBehaviorTree
struct AIController_RunBehaviorTree_Params
{
	class BehaviorTree*                                BTAsset_69;                                               // (Parm, ZeroConstructor)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AIModule.AIController.OnUsingBlackBoard
struct AIController_OnUsingBlackBoard_Params
{
	class BlackboardComponent*                         BlackboardComp_69;                                        // (Parm, ZeroConstructor, InstancedReference)
	class BlackboardData*                              BlackboardAsset_69;                                       // (Parm, ZeroConstructor)
};

// Function AIModule.AIController.OnGameplayTaskResourcesClaimed
struct AIController_OnGameplayTaskResourcesClaimed_Params
{
	struct FGameplayResourceSet                        NewlyClaimed_69;                                          // (Parm)
	struct FGameplayResourceSet                        FreshlyReleased_69;                                       // (Parm)
};

// Function AIModule.AIController.MoveToLocation
struct AIController_MoveToLocation_Params
{
	struct FVector                                     Dest_69;                                                  // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
	float                                              AcceptanceRadius_69;                                      // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bStopOnOverlap_69;                                        // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bUsePathfinding_69;                                       // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bProjectDestinationToNavigation_69;                       // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bCanStrafe_69;                                            // (Parm, ZeroConstructor, IsPlainOldData)
	class NavigationQueryFilter*                       FilterClass_69;                                           // (Parm, ZeroConstructor)
	bool                                               bAllowPartialPath_69;                                     // (Parm, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<EPathFollowingRequestResult>           ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AIModule.AIController.MoveToActor
struct AIController_MoveToActor_Params
{
	class Actor_32759*                                 Goal_69;                                                  // (Parm, ZeroConstructor)
	float                                              AcceptanceRadius_69;                                      // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bStopOnOverlap_69;                                        // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bUsePathfinding_69;                                       // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bCanStrafe_69;                                            // (Parm, ZeroConstructor, IsPlainOldData)
	class NavigationQueryFilter*                       FilterClass_69;                                           // (Parm, ZeroConstructor)
	bool                                               bAllowPartialPath_69;                                     // (Parm, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<EPathFollowingRequestResult>           ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AIModule.AIController.K2_SetFocus
struct AIController_K2_SetFocus_Params
{
	class Actor_32759*                                 NewFocus_69;                                              // (Parm, ZeroConstructor)
};

// Function AIModule.AIController.K2_SetFocalPoint
struct AIController_K2_SetFocalPoint_Params
{
	struct FVector                                     FP_69;                                                    // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function AIModule.AIController.K2_ClearFocus
struct AIController_K2_ClearFocus_Params
{
};

// Function AIModule.AIController.HasPartialPath
struct AIController_HasPartialPath_Params
{
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AIModule.AIController.GetPathFollowingComponent
struct AIController_GetPathFollowingComponent_Params
{
	class PathFollowingComponent*                      ReturnValue_69;                                           // (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)
};

// Function AIModule.AIController.GetMoveStatus
struct AIController_GetMoveStatus_Params
{
	TEnumAsByte<EPathFollowingStatus>                  ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AIModule.AIController.GetImmediateMoveDestination
struct AIController_GetImmediateMoveDestination_Params
{
	struct FVector                                     ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AIModule.AIController.GetFocusActor
struct AIController_GetFocusActor_Params
{
	class Actor_32759*                                 ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function AIModule.AIController.GetFocalPointOnActor
struct AIController_GetFocalPointOnActor_Params
{
	class Actor_32759*                                 Actor_69;                                                 // (ConstParm, Parm, ZeroConstructor)
	struct FVector                                     ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AIModule.AIController.GetFocalPoint
struct AIController_GetFocalPoint_Params
{
	struct FVector                                     ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AIModule.AIController.GetAIPerceptionComponent
struct AIController_GetAIPerceptionComponent_Params
{
	class AIPerceptionComponent*                       ReturnValue_69;                                           // (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)
};

// Function AIModule.AIController.ClaimTaskResource
struct AIController_ClaimTaskResource_Params
{
	class GameplayTaskResource*                        ResourceClass_69;                                         // (Parm, ZeroConstructor)
};

// Function AIModule.AITask_MoveTo.AIMoveTo
struct AITask_MoveTo_AIMoveTo_Params
{
	class AIController*                                Controller_69;                                            // (Parm, ZeroConstructor)
	struct FVector                                     GoalLocation_69;                                          // (Parm, ZeroConstructor, IsPlainOldData)
	class Actor_32759*                                 GoalActor_69;                                             // (Parm, ZeroConstructor)
	float                                              AcceptanceRadius_69;                                      // (Parm, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<EAIOptionFlag>                         StopOnOverlap_69;                                         // (Parm, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<EAIOptionFlag>                         AcceptPartialPath_69;                                     // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bUsePathfinding_69;                                       // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bLockAILogic_69;                                          // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bUseContinuousGoalTracking_69;                            // (Parm, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<EAIOptionFlag>                         ProjectGoalOnNavigation_69;                               // (Parm, ZeroConstructor, IsPlainOldData)
	class AITask_MoveTo*                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function AIModule.AIAsyncTaskBlueprintProxy.OnMoveCompleted
struct AIAsyncTaskBlueprintProxy_OnMoveCompleted_Params
{
	struct FAIRequestID                                RequestId_69;                                             // (Parm)
	TEnumAsByte<EPathFollowingResult>                  MovementResult_69;                                        // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function AIModule.PawnAction.GetActionPriority
struct PawnAction_GetActionPriority_Params
{
	TEnumAsByte<EAIRequestPriority>                    ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AIModule.PawnAction.Finish
struct PawnAction_Finish_Params
{
	TEnumAsByte<EPawnActionResult>                     WithResult_69;                                            // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function AIModule.PawnAction.CreateActionInstance
struct PawnAction_CreateActionInstance_Params
{
	class Object_32759*                                WorldContextObject_69;                                    // (Parm, ZeroConstructor)
	class PawnAction*                                  ActionClass_69;                                           // (Parm, ZeroConstructor)
	class PawnAction*                                  ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function AIModule.PawnActionsComponent.K2_PushAction
struct PawnActionsComponent_K2_PushAction_Params
{
	class PawnAction*                                  NewAction_69;                                             // (Parm, ZeroConstructor)
	TEnumAsByte<EAIRequestPriority>                    Priority_69;                                              // (Parm, ZeroConstructor, IsPlainOldData)
	class Object_32759*                                Instigator_69;                                            // (Parm, ZeroConstructor)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AIModule.PawnActionsComponent.K2_PerformAction
struct PawnActionsComponent_K2_PerformAction_Params
{
	class Pawn*                                        Pawn_69;                                                  // (Parm, ZeroConstructor)
	class PawnAction*                                  Action_69;                                                // (Parm, ZeroConstructor)
	TEnumAsByte<EAIRequestPriority>                    Priority_69;                                              // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AIModule.PawnActionsComponent.K2_ForceAbortAction
struct PawnActionsComponent_K2_ForceAbortAction_Params
{
	class PawnAction*                                  ActionToAbort_69;                                         // (Parm, ZeroConstructor)
	TEnumAsByte<EPawnActionAbortState>                 ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AIModule.PawnActionsComponent.K2_AbortAction
struct PawnActionsComponent_K2_AbortAction_Params
{
	class PawnAction*                                  ActionToAbort_69;                                         // (Parm, ZeroConstructor)
	TEnumAsByte<EPawnActionAbortState>                 ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AIModule.PawnAction_BlueprintBase.ActionTick
struct PawnAction_BlueprintBase_ActionTick_Params
{
	class Pawn*                                        ControlledPawn_69;                                        // (Parm, ZeroConstructor)
	float                                              DeltaSeconds_69;                                          // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function AIModule.PawnAction_BlueprintBase.ActionStart
struct PawnAction_BlueprintBase_ActionStart_Params
{
	class Pawn*                                        ControlledPawn_69;                                        // (Parm, ZeroConstructor)
};

// Function AIModule.PawnAction_BlueprintBase.ActionResume
struct PawnAction_BlueprintBase_ActionResume_Params
{
	class Pawn*                                        ControlledPawn_69;                                        // (Parm, ZeroConstructor)
};

// Function AIModule.PawnAction_BlueprintBase.ActionPause
struct PawnAction_BlueprintBase_ActionPause_Params
{
	class Pawn*                                        ControlledPawn_69;                                        // (Parm, ZeroConstructor)
};

// Function AIModule.PawnAction_BlueprintBase.ActionFinished
struct PawnAction_BlueprintBase_ActionFinished_Params
{
	class Pawn*                                        ControlledPawn_69;                                        // (Parm, ZeroConstructor)
	TEnumAsByte<EPawnActionResult>                     WithResult_69;                                            // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function AIModule.AISystem.AILoggingVerbose
struct AISystem_AILoggingVerbose_Params
{
};

// Function AIModule.AISystem.AIIgnorePlayers
struct AISystem_AIIgnorePlayers_Params
{
};

// Function AIModule.BrainComponent.StopLogic
struct BrainComponent_StopLogic_Params
{
	struct FString                                     Reason_69;                                                // (Parm, ZeroConstructor)
};

// Function AIModule.BrainComponent.StartLogic
struct BrainComponent_StartLogic_Params
{
};

// Function AIModule.BrainComponent.RestartLogic
struct BrainComponent_RestartLogic_Params
{
};

// Function AIModule.BrainComponent.IsRunning
struct BrainComponent_IsRunning_Params
{
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AIModule.BrainComponent.IsPaused
struct BrainComponent_IsPaused_Params
{
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AIModule.BehaviorTreeComponent.SetDynamicSubtree
struct BehaviorTreeComponent_SetDynamicSubtree_Params
{
	struct FGameplayTag                                InjectTag_69;                                             // (Parm)
	class BehaviorTree*                                BehaviorAsset_69;                                         // (Parm, ZeroConstructor)
};

// Function AIModule.BehaviorTreeComponent.GetTagCooldownEndTime
struct BehaviorTreeComponent_GetTagCooldownEndTime_Params
{
	struct FGameplayTag                                CooldownTag_69;                                           // (Parm)
	float                                              ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AIModule.BehaviorTreeComponent.AddCooldownTagDuration
struct BehaviorTreeComponent_AddCooldownTagDuration_Params
{
	struct FGameplayTag                                CooldownTag_69;                                           // (Parm)
	float                                              CooldownDuration_69;                                      // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bAddToExistingDuration_69;                                // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function AIModule.BlackboardAssetProvider.GetBlackboardAsset
struct BlackboardAssetProvider_GetBlackboardAsset_Params
{
	class BlackboardData*                              ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function AIModule.BlackboardComponent.SetValueAsVector
struct BlackboardComponent_SetValueAsVector_Params
{
	struct FName                                       KeyName_69;                                               // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
	struct FVector                                     VectorValue_69;                                           // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function AIModule.BlackboardComponent.SetValueAsString
struct BlackboardComponent_SetValueAsString_Params
{
	struct FName                                       KeyName_69;                                               // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
	struct FString                                     StringValue_69;                                           // (Parm, ZeroConstructor)
};

// Function AIModule.BlackboardComponent.SetValueAsRotator
struct BlackboardComponent_SetValueAsRotator_Params
{
	struct FName                                       KeyName_69;                                               // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
	struct FRotator                                    VectorValue_69;                                           // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function AIModule.BlackboardComponent.SetValueAsObject
struct BlackboardComponent_SetValueAsObject_Params
{
	struct FName                                       KeyName_69;                                               // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
	class Object_32759*                                ObjectValue_69;                                           // (Parm, ZeroConstructor)
};

// Function AIModule.BlackboardComponent.SetValueAsName
struct BlackboardComponent_SetValueAsName_Params
{
	struct FName                                       KeyName_69;                                               // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
	struct FName                                       NameValue_69;                                             // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function AIModule.BlackboardComponent.SetValueAsInt
struct BlackboardComponent_SetValueAsInt_Params
{
	struct FName                                       KeyName_69;                                               // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
	int                                                IntValue_69;                                              // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function AIModule.BlackboardComponent.SetValueAsFloat
struct BlackboardComponent_SetValueAsFloat_Params
{
	struct FName                                       KeyName_69;                                               // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
	float                                              FloatValue_69;                                            // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function AIModule.BlackboardComponent.SetValueAsEnum
struct BlackboardComponent_SetValueAsEnum_Params
{
	struct FName                                       KeyName_69;                                               // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
	unsigned char                                      EnumValue_69;                                             // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function AIModule.BlackboardComponent.SetValueAsClass
struct BlackboardComponent_SetValueAsClass_Params
{
	struct FName                                       KeyName_69;                                               // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
	class Object_32759*                                ClassValue_69;                                            // (Parm, ZeroConstructor)
};

// Function AIModule.BlackboardComponent.SetValueAsBool
struct BlackboardComponent_SetValueAsBool_Params
{
	struct FName                                       KeyName_69;                                               // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
	bool                                               BoolValue_69;                                             // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function AIModule.BlackboardComponent.IsVectorValueSet
struct BlackboardComponent_IsVectorValueSet_Params
{
	struct FName                                       KeyName_69;                                               // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AIModule.BlackboardComponent.GetValueAsVector
struct BlackboardComponent_GetValueAsVector_Params
{
	struct FName                                       KeyName_69;                                               // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
	struct FVector                                     ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AIModule.BlackboardComponent.GetValueAsString
struct BlackboardComponent_GetValueAsString_Params
{
	struct FName                                       KeyName_69;                                               // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
	struct FString                                     ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function AIModule.BlackboardComponent.GetValueAsRotator
struct BlackboardComponent_GetValueAsRotator_Params
{
	struct FName                                       KeyName_69;                                               // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
	struct FRotator                                    ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AIModule.BlackboardComponent.GetValueAsObject
struct BlackboardComponent_GetValueAsObject_Params
{
	struct FName                                       KeyName_69;                                               // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
	class Object_32759*                                ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function AIModule.BlackboardComponent.GetValueAsName
struct BlackboardComponent_GetValueAsName_Params
{
	struct FName                                       KeyName_69;                                               // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
	struct FName                                       ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AIModule.BlackboardComponent.GetValueAsInt
struct BlackboardComponent_GetValueAsInt_Params
{
	struct FName                                       KeyName_69;                                               // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
	int                                                ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AIModule.BlackboardComponent.GetValueAsFloat
struct BlackboardComponent_GetValueAsFloat_Params
{
	struct FName                                       KeyName_69;                                               // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
	float                                              ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AIModule.BlackboardComponent.GetValueAsEnum
struct BlackboardComponent_GetValueAsEnum_Params
{
	struct FName                                       KeyName_69;                                               // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
	unsigned char                                      ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AIModule.BlackboardComponent.GetValueAsClass
struct BlackboardComponent_GetValueAsClass_Params
{
	struct FName                                       KeyName_69;                                               // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
	class Object_32759*                                ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function AIModule.BlackboardComponent.GetValueAsBool
struct BlackboardComponent_GetValueAsBool_Params
{
	struct FName                                       KeyName_69;                                               // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AIModule.BlackboardComponent.GetRotationFromEntry
struct BlackboardComponent_GetRotationFromEntry_Params
{
	struct FName                                       KeyName_69;                                               // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
	struct FRotator                                    ResultRotation_69;                                        // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AIModule.BlackboardComponent.GetLocationFromEntry
struct BlackboardComponent_GetLocationFromEntry_Params
{
	struct FName                                       KeyName_69;                                               // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
	struct FVector                                     ResultLocation_69;                                        // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AIModule.BlackboardComponent.ClearValue
struct BlackboardComponent_ClearValue_Params
{
	struct FName                                       KeyName_69;                                               // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
};

// Function AIModule.BTFunctionLibrary.StopUsingExternalEvent
struct BTFunctionLibrary_StopUsingExternalEvent_Params
{
	class BTNode*                                      NodeOwner_69;                                             // (Parm, ZeroConstructor)
};

// Function AIModule.BTFunctionLibrary.StartUsingExternalEvent
struct BTFunctionLibrary_StartUsingExternalEvent_Params
{
	class BTNode*                                      NodeOwner_69;                                             // (Parm, ZeroConstructor)
	class Actor_32759*                                 OwningActor_69;                                           // (Parm, ZeroConstructor)
};

// Function AIModule.BTFunctionLibrary.SetBlackboardValueAsVector
struct BTFunctionLibrary_SetBlackboardValueAsVector_Params
{
	class BTNode*                                      NodeOwner_69;                                             // (Parm, ZeroConstructor)
	struct FBlackboardKeySelector                      Key_69;                                                   // (ConstParm, Parm, OutParm, ReferenceParm)
	struct FVector                                     Value_69;                                                 // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function AIModule.BTFunctionLibrary.SetBlackboardValueAsString
struct BTFunctionLibrary_SetBlackboardValueAsString_Params
{
	class BTNode*                                      NodeOwner_69;                                             // (Parm, ZeroConstructor)
	struct FBlackboardKeySelector                      Key_69;                                                   // (ConstParm, Parm, OutParm, ReferenceParm)
	struct FString                                     Value_69;                                                 // (Parm, ZeroConstructor)
};

// Function AIModule.BTFunctionLibrary.SetBlackboardValueAsRotator
struct BTFunctionLibrary_SetBlackboardValueAsRotator_Params
{
	class BTNode*                                      NodeOwner_69;                                             // (Parm, ZeroConstructor)
	struct FBlackboardKeySelector                      Key_69;                                                   // (ConstParm, Parm, OutParm, ReferenceParm)
	struct FRotator                                    Value_69;                                                 // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function AIModule.BTFunctionLibrary.SetBlackboardValueAsObject
struct BTFunctionLibrary_SetBlackboardValueAsObject_Params
{
	class BTNode*                                      NodeOwner_69;                                             // (Parm, ZeroConstructor)
	struct FBlackboardKeySelector                      Key_69;                                                   // (ConstParm, Parm, OutParm, ReferenceParm)
	class Object_32759*                                Value_69;                                                 // (Parm, ZeroConstructor)
};

// Function AIModule.BTFunctionLibrary.SetBlackboardValueAsName
struct BTFunctionLibrary_SetBlackboardValueAsName_Params
{
	class BTNode*                                      NodeOwner_69;                                             // (Parm, ZeroConstructor)
	struct FBlackboardKeySelector                      Key_69;                                                   // (ConstParm, Parm, OutParm, ReferenceParm)
	struct FName                                       Value_69;                                                 // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function AIModule.BTFunctionLibrary.SetBlackboardValueAsInt
struct BTFunctionLibrary_SetBlackboardValueAsInt_Params
{
	class BTNode*                                      NodeOwner_69;                                             // (Parm, ZeroConstructor)
	struct FBlackboardKeySelector                      Key_69;                                                   // (ConstParm, Parm, OutParm, ReferenceParm)
	int                                                Value_69;                                                 // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function AIModule.BTFunctionLibrary.SetBlackboardValueAsFloat
struct BTFunctionLibrary_SetBlackboardValueAsFloat_Params
{
	class BTNode*                                      NodeOwner_69;                                             // (Parm, ZeroConstructor)
	struct FBlackboardKeySelector                      Key_69;                                                   // (ConstParm, Parm, OutParm, ReferenceParm)
	float                                              Value_69;                                                 // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function AIModule.BTFunctionLibrary.SetBlackboardValueAsEnum
struct BTFunctionLibrary_SetBlackboardValueAsEnum_Params
{
	class BTNode*                                      NodeOwner_69;                                             // (Parm, ZeroConstructor)
	struct FBlackboardKeySelector                      Key_69;                                                   // (ConstParm, Parm, OutParm, ReferenceParm)
	unsigned char                                      Value_69;                                                 // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function AIModule.BTFunctionLibrary.SetBlackboardValueAsClass
struct BTFunctionLibrary_SetBlackboardValueAsClass_Params
{
	class BTNode*                                      NodeOwner_69;                                             // (Parm, ZeroConstructor)
	struct FBlackboardKeySelector                      Key_69;                                                   // (ConstParm, Parm, OutParm, ReferenceParm)
	class Object_32759*                                Value_69;                                                 // (Parm, ZeroConstructor)
};

// Function AIModule.BTFunctionLibrary.SetBlackboardValueAsBool
struct BTFunctionLibrary_SetBlackboardValueAsBool_Params
{
	class BTNode*                                      NodeOwner_69;                                             // (Parm, ZeroConstructor)
	struct FBlackboardKeySelector                      Key_69;                                                   // (ConstParm, Parm, OutParm, ReferenceParm)
	bool                                               Value_69;                                                 // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function AIModule.BTFunctionLibrary.GetOwnersBlackboard
struct BTFunctionLibrary_GetOwnersBlackboard_Params
{
	class BTNode*                                      NodeOwner_69;                                             // (Parm, ZeroConstructor)
	class BlackboardComponent*                         ReturnValue_69;                                           // (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)
};

// Function AIModule.BTFunctionLibrary.GetOwnerComponent
struct BTFunctionLibrary_GetOwnerComponent_Params
{
	class BTNode*                                      NodeOwner_69;                                             // (Parm, ZeroConstructor)
	class BehaviorTreeComponent*                       ReturnValue_69;                                           // (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)
};

// Function AIModule.BTFunctionLibrary.GetBlackboardValueAsVector
struct BTFunctionLibrary_GetBlackboardValueAsVector_Params
{
	class BTNode*                                      NodeOwner_69;                                             // (Parm, ZeroConstructor)
	struct FBlackboardKeySelector                      Key_69;                                                   // (ConstParm, Parm, OutParm, ReferenceParm)
	struct FVector                                     ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AIModule.BTFunctionLibrary.GetBlackboardValueAsString
struct BTFunctionLibrary_GetBlackboardValueAsString_Params
{
	class BTNode*                                      NodeOwner_69;                                             // (Parm, ZeroConstructor)
	struct FBlackboardKeySelector                      Key_69;                                                   // (ConstParm, Parm, OutParm, ReferenceParm)
	struct FString                                     ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function AIModule.BTFunctionLibrary.GetBlackboardValueAsRotator
struct BTFunctionLibrary_GetBlackboardValueAsRotator_Params
{
	class BTNode*                                      NodeOwner_69;                                             // (Parm, ZeroConstructor)
	struct FBlackboardKeySelector                      Key_69;                                                   // (ConstParm, Parm, OutParm, ReferenceParm)
	struct FRotator                                    ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AIModule.BTFunctionLibrary.GetBlackboardValueAsObject
struct BTFunctionLibrary_GetBlackboardValueAsObject_Params
{
	class BTNode*                                      NodeOwner_69;                                             // (Parm, ZeroConstructor)
	struct FBlackboardKeySelector                      Key_69;                                                   // (ConstParm, Parm, OutParm, ReferenceParm)
	class Object_32759*                                ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function AIModule.BTFunctionLibrary.GetBlackboardValueAsName
struct BTFunctionLibrary_GetBlackboardValueAsName_Params
{
	class BTNode*                                      NodeOwner_69;                                             // (Parm, ZeroConstructor)
	struct FBlackboardKeySelector                      Key_69;                                                   // (ConstParm, Parm, OutParm, ReferenceParm)
	struct FName                                       ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AIModule.BTFunctionLibrary.GetBlackboardValueAsInt
struct BTFunctionLibrary_GetBlackboardValueAsInt_Params
{
	class BTNode*                                      NodeOwner_69;                                             // (Parm, ZeroConstructor)
	struct FBlackboardKeySelector                      Key_69;                                                   // (ConstParm, Parm, OutParm, ReferenceParm)
	int                                                ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AIModule.BTFunctionLibrary.GetBlackboardValueAsFloat
struct BTFunctionLibrary_GetBlackboardValueAsFloat_Params
{
	class BTNode*                                      NodeOwner_69;                                             // (Parm, ZeroConstructor)
	struct FBlackboardKeySelector                      Key_69;                                                   // (ConstParm, Parm, OutParm, ReferenceParm)
	float                                              ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AIModule.BTFunctionLibrary.GetBlackboardValueAsEnum
struct BTFunctionLibrary_GetBlackboardValueAsEnum_Params
{
	class BTNode*                                      NodeOwner_69;                                             // (Parm, ZeroConstructor)
	struct FBlackboardKeySelector                      Key_69;                                                   // (ConstParm, Parm, OutParm, ReferenceParm)
	unsigned char                                      ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AIModule.BTFunctionLibrary.GetBlackboardValueAsClass
struct BTFunctionLibrary_GetBlackboardValueAsClass_Params
{
	class BTNode*                                      NodeOwner_69;                                             // (Parm, ZeroConstructor)
	struct FBlackboardKeySelector                      Key_69;                                                   // (ConstParm, Parm, OutParm, ReferenceParm)
	class Object_32759*                                ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function AIModule.BTFunctionLibrary.GetBlackboardValueAsBool
struct BTFunctionLibrary_GetBlackboardValueAsBool_Params
{
	class BTNode*                                      NodeOwner_69;                                             // (Parm, ZeroConstructor)
	struct FBlackboardKeySelector                      Key_69;                                                   // (ConstParm, Parm, OutParm, ReferenceParm)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AIModule.BTFunctionLibrary.GetBlackboardValueAsActor
struct BTFunctionLibrary_GetBlackboardValueAsActor_Params
{
	class BTNode*                                      NodeOwner_69;                                             // (Parm, ZeroConstructor)
	struct FBlackboardKeySelector                      Key_69;                                                   // (ConstParm, Parm, OutParm, ReferenceParm)
	class Actor_32759*                                 ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function AIModule.BTFunctionLibrary.ClearBlackboardValueAsVector
struct BTFunctionLibrary_ClearBlackboardValueAsVector_Params
{
	class BTNode*                                      NodeOwner_69;                                             // (Parm, ZeroConstructor)
	struct FBlackboardKeySelector                      Key_69;                                                   // (ConstParm, Parm, OutParm, ReferenceParm)
};

// Function AIModule.BTFunctionLibrary.ClearBlackboardValue
struct BTFunctionLibrary_ClearBlackboardValue_Params
{
	class BTNode*                                      NodeOwner_69;                                             // (Parm, ZeroConstructor)
	struct FBlackboardKeySelector                      Key_69;                                                   // (ConstParm, Parm, OutParm, ReferenceParm)
};

// Function AIModule.BTDecorator_BlueprintBase.ReceiveTickAI
struct BTDecorator_BlueprintBase_ReceiveTickAI_Params
{
	class AIController*                                OwnerController_69;                                       // (Parm, ZeroConstructor)
	class Pawn*                                        ControlledPawn_69;                                        // (Parm, ZeroConstructor)
	float                                              DeltaSeconds_69;                                          // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function AIModule.BTDecorator_BlueprintBase.ReceiveTick
struct BTDecorator_BlueprintBase_ReceiveTick_Params
{
	class Actor_32759*                                 OwnerActor_69;                                            // (Parm, ZeroConstructor)
	float                                              DeltaSeconds_69;                                          // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function AIModule.BTDecorator_BlueprintBase.ReceiveObserverDeactivatedAI
struct BTDecorator_BlueprintBase_ReceiveObserverDeactivatedAI_Params
{
	class AIController*                                OwnerController_69;                                       // (Parm, ZeroConstructor)
	class Pawn*                                        ControlledPawn_69;                                        // (Parm, ZeroConstructor)
};

// Function AIModule.BTDecorator_BlueprintBase.ReceiveObserverDeactivated
struct BTDecorator_BlueprintBase_ReceiveObserverDeactivated_Params
{
	class Actor_32759*                                 OwnerActor_69;                                            // (Parm, ZeroConstructor)
};

// Function AIModule.BTDecorator_BlueprintBase.ReceiveObserverActivatedAI
struct BTDecorator_BlueprintBase_ReceiveObserverActivatedAI_Params
{
	class AIController*                                OwnerController_69;                                       // (Parm, ZeroConstructor)
	class Pawn*                                        ControlledPawn_69;                                        // (Parm, ZeroConstructor)
};

// Function AIModule.BTDecorator_BlueprintBase.ReceiveObserverActivated
struct BTDecorator_BlueprintBase_ReceiveObserverActivated_Params
{
	class Actor_32759*                                 OwnerActor_69;                                            // (Parm, ZeroConstructor)
};

// Function AIModule.BTDecorator_BlueprintBase.ReceiveExecutionStartAI
struct BTDecorator_BlueprintBase_ReceiveExecutionStartAI_Params
{
	class AIController*                                OwnerController_69;                                       // (Parm, ZeroConstructor)
	class Pawn*                                        ControlledPawn_69;                                        // (Parm, ZeroConstructor)
};

// Function AIModule.BTDecorator_BlueprintBase.ReceiveExecutionStart
struct BTDecorator_BlueprintBase_ReceiveExecutionStart_Params
{
	class Actor_32759*                                 OwnerActor_69;                                            // (Parm, ZeroConstructor)
};

// Function AIModule.BTDecorator_BlueprintBase.ReceiveExecutionFinishAI
struct BTDecorator_BlueprintBase_ReceiveExecutionFinishAI_Params
{
	class AIController*                                OwnerController_69;                                       // (Parm, ZeroConstructor)
	class Pawn*                                        ControlledPawn_69;                                        // (Parm, ZeroConstructor)
	TEnumAsByte<EBTNodeResult>                         NodeResult_69;                                            // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function AIModule.BTDecorator_BlueprintBase.ReceiveExecutionFinish
struct BTDecorator_BlueprintBase_ReceiveExecutionFinish_Params
{
	class Actor_32759*                                 OwnerActor_69;                                            // (Parm, ZeroConstructor)
	TEnumAsByte<EBTNodeResult>                         NodeResult_69;                                            // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function AIModule.BTDecorator_BlueprintBase.PerformConditionCheckAI
struct BTDecorator_BlueprintBase_PerformConditionCheckAI_Params
{
	class AIController*                                OwnerController_69;                                       // (Parm, ZeroConstructor)
	class Pawn*                                        ControlledPawn_69;                                        // (Parm, ZeroConstructor)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AIModule.BTDecorator_BlueprintBase.PerformConditionCheck
struct BTDecorator_BlueprintBase_PerformConditionCheck_Params
{
	class Actor_32759*                                 OwnerActor_69;                                            // (Parm, ZeroConstructor)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AIModule.BTDecorator_BlueprintBase.IsDecoratorObserverActive
struct BTDecorator_BlueprintBase_IsDecoratorObserverActive_Params
{
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AIModule.BTDecorator_BlueprintBase.IsDecoratorExecutionActive
struct BTDecorator_BlueprintBase_IsDecoratorExecutionActive_Params
{
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AIModule.BTService_BlueprintBase.ReceiveTickAI
struct BTService_BlueprintBase_ReceiveTickAI_Params
{
	class AIController*                                OwnerController_69;                                       // (Parm, ZeroConstructor)
	class Pawn*                                        ControlledPawn_69;                                        // (Parm, ZeroConstructor)
	float                                              DeltaSeconds_69;                                          // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function AIModule.BTService_BlueprintBase.ReceiveTick
struct BTService_BlueprintBase_ReceiveTick_Params
{
	class Actor_32759*                                 OwnerActor_69;                                            // (Parm, ZeroConstructor)
	float                                              DeltaSeconds_69;                                          // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function AIModule.BTService_BlueprintBase.ReceiveSearchStartAI
struct BTService_BlueprintBase_ReceiveSearchStartAI_Params
{
	class AIController*                                OwnerController_69;                                       // (Parm, ZeroConstructor)
	class Pawn*                                        ControlledPawn_69;                                        // (Parm, ZeroConstructor)
};

// Function AIModule.BTService_BlueprintBase.ReceiveSearchStart
struct BTService_BlueprintBase_ReceiveSearchStart_Params
{
	class Actor_32759*                                 OwnerActor_69;                                            // (Parm, ZeroConstructor)
};

// Function AIModule.BTService_BlueprintBase.ReceiveDeactivationAI
struct BTService_BlueprintBase_ReceiveDeactivationAI_Params
{
	class AIController*                                OwnerController_69;                                       // (Parm, ZeroConstructor)
	class Pawn*                                        ControlledPawn_69;                                        // (Parm, ZeroConstructor)
};

// Function AIModule.BTService_BlueprintBase.ReceiveDeactivation
struct BTService_BlueprintBase_ReceiveDeactivation_Params
{
	class Actor_32759*                                 OwnerActor_69;                                            // (Parm, ZeroConstructor)
};

// Function AIModule.BTService_BlueprintBase.ReceiveActivationAI
struct BTService_BlueprintBase_ReceiveActivationAI_Params
{
	class AIController*                                OwnerController_69;                                       // (Parm, ZeroConstructor)
	class Pawn*                                        ControlledPawn_69;                                        // (Parm, ZeroConstructor)
};

// Function AIModule.BTService_BlueprintBase.ReceiveActivation
struct BTService_BlueprintBase_ReceiveActivation_Params
{
	class Actor_32759*                                 OwnerActor_69;                                            // (Parm, ZeroConstructor)
};

// Function AIModule.BTService_BlueprintBase.IsServiceActive
struct BTService_BlueprintBase_IsServiceActive_Params
{
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AIModule.BTTask_BlueprintBase.SetFinishOnMessageWithId
struct BTTask_BlueprintBase_SetFinishOnMessageWithId_Params
{
	struct FName                                       MessageName_69;                                           // (Parm, ZeroConstructor, IsPlainOldData)
	int                                                RequestId_69;                                             // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function AIModule.BTTask_BlueprintBase.SetFinishOnMessage
struct BTTask_BlueprintBase_SetFinishOnMessage_Params
{
	struct FName                                       MessageName_69;                                           // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function AIModule.BTTask_BlueprintBase.ReceiveTickAI
struct BTTask_BlueprintBase_ReceiveTickAI_Params
{
	class AIController*                                OwnerController_69;                                       // (Parm, ZeroConstructor)
	class Pawn*                                        ControlledPawn_69;                                        // (Parm, ZeroConstructor)
	float                                              DeltaSeconds_69;                                          // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function AIModule.BTTask_BlueprintBase.ReceiveTick
struct BTTask_BlueprintBase_ReceiveTick_Params
{
	class Actor_32759*                                 OwnerActor_69;                                            // (Parm, ZeroConstructor)
	float                                              DeltaSeconds_69;                                          // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function AIModule.BTTask_BlueprintBase.ReceiveExecuteAI
struct BTTask_BlueprintBase_ReceiveExecuteAI_Params
{
	class AIController*                                OwnerController_69;                                       // (Parm, ZeroConstructor)
	class Pawn*                                        ControlledPawn_69;                                        // (Parm, ZeroConstructor)
};

// Function AIModule.BTTask_BlueprintBase.ReceiveExecute
struct BTTask_BlueprintBase_ReceiveExecute_Params
{
	class Actor_32759*                                 OwnerActor_69;                                            // (Parm, ZeroConstructor)
};

// Function AIModule.BTTask_BlueprintBase.ReceiveAbortAI
struct BTTask_BlueprintBase_ReceiveAbortAI_Params
{
	class AIController*                                OwnerController_69;                                       // (Parm, ZeroConstructor)
	class Pawn*                                        ControlledPawn_69;                                        // (Parm, ZeroConstructor)
};

// Function AIModule.BTTask_BlueprintBase.ReceiveAbort
struct BTTask_BlueprintBase_ReceiveAbort_Params
{
	class Actor_32759*                                 OwnerActor_69;                                            // (Parm, ZeroConstructor)
};

// Function AIModule.BTTask_BlueprintBase.IsTaskExecuting
struct BTTask_BlueprintBase_IsTaskExecuting_Params
{
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AIModule.BTTask_BlueprintBase.IsTaskAborting
struct BTTask_BlueprintBase_IsTaskAborting_Params
{
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AIModule.BTTask_BlueprintBase.FinishExecute
struct BTTask_BlueprintBase_FinishExecute_Params
{
	bool                                               bSuccess_69;                                              // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function AIModule.BTTask_BlueprintBase.FinishAbort
struct BTTask_BlueprintBase_FinishAbort_Params
{
};

// Function AIModule.AIBlueprintHelperLibrary.UnlockAIResourcesWithAnimation
struct AIBlueprintHelperLibrary_UnlockAIResourcesWithAnimation_Params
{
	class AnimInstance*                                AnimInstance_69;                                          // (Parm, ZeroConstructor)
	bool                                               bUnlockMovement_69;                                       // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               UnlockAILogic_69;                                         // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function AIModule.AIBlueprintHelperLibrary.SpawnAIFromClass
struct AIBlueprintHelperLibrary_SpawnAIFromClass_Params
{
	class Object_32759*                                WorldContextObject_69;                                    // (Parm, ZeroConstructor)
	class Pawn*                                        PawnClass_69;                                             // (Parm, ZeroConstructor)
	class BehaviorTree*                                BehaviorTree_69;                                          // (Parm, ZeroConstructor)
	struct FVector                                     Location_69;                                              // (Parm, ZeroConstructor, IsPlainOldData)
	struct FRotator                                    Rotation_69;                                              // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bNoCollisionFail_69;                                      // (Parm, ZeroConstructor, IsPlainOldData)
	class Actor_32759*                                 Owner_69;                                                 // (Parm, ZeroConstructor)
	class Pawn*                                        ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function AIModule.AIBlueprintHelperLibrary.SimpleMoveToLocation
struct AIBlueprintHelperLibrary_SimpleMoveToLocation_Params
{
	class Controller*                                  Controller_69;                                            // (Parm, ZeroConstructor)
	struct FVector                                     Goal_69;                                                  // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
};

// Function AIModule.AIBlueprintHelperLibrary.SimpleMoveToActor
struct AIBlueprintHelperLibrary_SimpleMoveToActor_Params
{
	class Controller*                                  Controller_69;                                            // (Parm, ZeroConstructor)
	class Actor_32759*                                 Goal_69;                                                  // (ConstParm, Parm, ZeroConstructor)
};

// Function AIModule.AIBlueprintHelperLibrary.SendAIMessage
struct AIBlueprintHelperLibrary_SendAIMessage_Params
{
	class Pawn*                                        Target_69;                                                // (Parm, ZeroConstructor)
	struct FName                                       message_69;                                               // (Parm, ZeroConstructor, IsPlainOldData)
	class Object_32759*                                MessageSource_69;                                         // (Parm, ZeroConstructor)
	bool                                               bSuccess_69;                                              // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function AIModule.AIBlueprintHelperLibrary.LockAIResourcesWithAnimation
struct AIBlueprintHelperLibrary_LockAIResourcesWithAnimation_Params
{
	class AnimInstance*                                AnimInstance_69;                                          // (Parm, ZeroConstructor)
	bool                                               bLockMovement_69;                                         // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               LockAILogic_69;                                           // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function AIModule.AIBlueprintHelperLibrary.IsValidAIRotation
struct AIBlueprintHelperLibrary_IsValidAIRotation_Params
{
	struct FRotator                                    Rotation_69;                                              // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AIModule.AIBlueprintHelperLibrary.IsValidAILocation
struct AIBlueprintHelperLibrary_IsValidAILocation_Params
{
	struct FVector                                     Location_69;                                              // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AIModule.AIBlueprintHelperLibrary.IsValidAIDirection
struct AIBlueprintHelperLibrary_IsValidAIDirection_Params
{
	struct FVector                                     DirectionVector_69;                                       // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AIModule.AIBlueprintHelperLibrary.GetNextNavLinkIndex
struct AIBlueprintHelperLibrary_GetNextNavLinkIndex_Params
{
	class Controller*                                  Controller_69;                                            // (ConstParm, Parm, ZeroConstructor)
	int                                                ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AIModule.AIBlueprintHelperLibrary.GetCurrentPathPoints
struct AIBlueprintHelperLibrary_GetCurrentPathPoints_Params
{
	class Controller*                                  Controller_69;                                            // (Parm, ZeroConstructor)
	TArray<struct FVector>                             ReturnValue_69;                                           // (ConstParm, Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function AIModule.AIBlueprintHelperLibrary.GetCurrentPathIndex
struct AIBlueprintHelperLibrary_GetCurrentPathIndex_Params
{
	class Controller*                                  Controller_69;                                            // (ConstParm, Parm, ZeroConstructor)
	int                                                ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AIModule.AIBlueprintHelperLibrary.GetCurrentPath
struct AIBlueprintHelperLibrary_GetCurrentPath_Params
{
	class Controller*                                  Controller_69;                                            // (Parm, ZeroConstructor)
	class NavigationPath*                              ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function AIModule.AIBlueprintHelperLibrary.GetBlackboard
struct AIBlueprintHelperLibrary_GetBlackboard_Params
{
	class Actor_32759*                                 Target_69;                                                // (Parm, ZeroConstructor)
	class BlackboardComponent*                         ReturnValue_69;                                           // (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)
};

// Function AIModule.AIBlueprintHelperLibrary.GetAIController
struct AIBlueprintHelperLibrary_GetAIController_Params
{
	class Actor_32759*                                 ControlledActor_69;                                       // (Parm, ZeroConstructor)
	class AIController*                                ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function AIModule.AIBlueprintHelperLibrary.CreateMoveToProxyObject
struct AIBlueprintHelperLibrary_CreateMoveToProxyObject_Params
{
	class Object_32759*                                WorldContextObject_69;                                    // (Parm, ZeroConstructor)
	class Pawn*                                        Pawn_69;                                                  // (Parm, ZeroConstructor)
	struct FVector                                     Destination_69;                                           // (Parm, ZeroConstructor, IsPlainOldData)
	class Actor_32759*                                 TargetActor_69;                                           // (Parm, ZeroConstructor)
	float                                              AcceptanceRadius_69;                                      // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bStopOnOverlap_69;                                        // (Parm, ZeroConstructor, IsPlainOldData)
	class AIAsyncTaskBlueprintProxy*                   ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function AIModule.EnvQueryContext_BlueprintBase.ProvideSingleLocation
struct EnvQueryContext_BlueprintBase_ProvideSingleLocation_Params
{
	class Object_32759*                                QuerierObject_69;                                         // (Parm, ZeroConstructor)
	class Actor_32759*                                 QuerierActor_69;                                          // (Parm, ZeroConstructor)
	struct FVector                                     ResultingLocation_69;                                     // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
};

// Function AIModule.EnvQueryContext_BlueprintBase.ProvideSingleActor
struct EnvQueryContext_BlueprintBase_ProvideSingleActor_Params
{
	class Object_32759*                                QuerierObject_69;                                         // (Parm, ZeroConstructor)
	class Actor_32759*                                 QuerierActor_69;                                          // (Parm, ZeroConstructor)
	class Actor_32759*                                 ResultingActor_69;                                        // (Parm, OutParm, ZeroConstructor)
};

// Function AIModule.EnvQueryContext_BlueprintBase.ProvideLocationsSet
struct EnvQueryContext_BlueprintBase_ProvideLocationsSet_Params
{
	class Object_32759*                                QuerierObject_69;                                         // (Parm, ZeroConstructor)
	class Actor_32759*                                 QuerierActor_69;                                          // (Parm, ZeroConstructor)
	TArray<struct FVector>                             ResultingLocationSet_69;                                  // (Parm, OutParm, ZeroConstructor)
};

// Function AIModule.EnvQueryContext_BlueprintBase.ProvideActorsSet
struct EnvQueryContext_BlueprintBase_ProvideActorsSet_Params
{
	class Object_32759*                                QuerierObject_69;                                         // (Parm, ZeroConstructor)
	class Actor_32759*                                 QuerierActor_69;                                          // (Parm, ZeroConstructor)
	TArray<class Actor_32759*>                         ResultingActorsSet_69;                                    // (Parm, OutParm, ZeroConstructor)
};

// Function AIModule.EnvQueryInstanceBlueprintWrapper.SetNamedParam
struct EnvQueryInstanceBlueprintWrapper_SetNamedParam_Params
{
	struct FName                                       ParamName_69;                                             // (Parm, ZeroConstructor, IsPlainOldData)
	float                                              Value_69;                                                 // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function AIModule.EnvQueryInstanceBlueprintWrapper.GetResultsAsLocations
struct EnvQueryInstanceBlueprintWrapper_GetResultsAsLocations_Params
{
	TArray<struct FVector>                             ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function AIModule.EnvQueryInstanceBlueprintWrapper.GetResultsAsActors
struct EnvQueryInstanceBlueprintWrapper_GetResultsAsActors_Params
{
	TArray<class Actor_32759*>                         ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function AIModule.EnvQueryInstanceBlueprintWrapper.GetQueryResultsAsLocations
struct EnvQueryInstanceBlueprintWrapper_GetQueryResultsAsLocations_Params
{
	TArray<struct FVector>                             ResultLocations_69;                                       // (Parm, OutParm, ZeroConstructor)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AIModule.EnvQueryInstanceBlueprintWrapper.GetQueryResultsAsActors
struct EnvQueryInstanceBlueprintWrapper_GetQueryResultsAsActors_Params
{
	TArray<class Actor_32759*>                         ResultActors_69;                                          // (Parm, OutParm, ZeroConstructor)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AIModule.EnvQueryInstanceBlueprintWrapper.GetItemScore
struct EnvQueryInstanceBlueprintWrapper_GetItemScore_Params
{
	int                                                ItemIndex_69;                                             // (Parm, ZeroConstructor, IsPlainOldData)
	float                                              ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// DelegateFunction AIModule.EnvQueryInstanceBlueprintWrapper.EQSQueryDoneSignature__DelegateSignature
struct EnvQueryInstanceBlueprintWrapper_EQSQueryDoneSignature__DelegateSignature_Params
{
	class EnvQueryInstanceBlueprintWrapper*            QueryInstance_69;                                         // (Parm, ZeroConstructor)
	TEnumAsByte<EEnvQueryStatus>                       QueryStatus_69;                                           // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function AIModule.EnvQueryManager.RunEQSQuery
struct EnvQueryManager_RunEQSQuery_Params
{
	class Object_32759*                                WorldContextObject_69;                                    // (Parm, ZeroConstructor)
	class EnvQuery*                                    QueryTemplate_69;                                         // (Parm, ZeroConstructor)
	class Object_32759*                                Querier_69;                                               // (Parm, ZeroConstructor)
	TEnumAsByte<EEnvQueryRunMode>                      RunMode_69;                                               // (Parm, ZeroConstructor, IsPlainOldData)
	class EnvQueryInstanceBlueprintWrapper*            WrapperClass_69;                                          // (Parm, ZeroConstructor)
	class EnvQueryInstanceBlueprintWrapper*            ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function AIModule.EnvQueryGenerator_BlueprintBase.GetQuerier
struct EnvQueryGenerator_BlueprintBase_GetQuerier_Params
{
	class Object_32759*                                ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function AIModule.EnvQueryGenerator_BlueprintBase.DoItemGenerationFromActors
struct EnvQueryGenerator_BlueprintBase_DoItemGenerationFromActors_Params
{
	TArray<class Actor_32759*>                         ContextActors_69;                                         // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
};

// Function AIModule.EnvQueryGenerator_BlueprintBase.DoItemGeneration
struct EnvQueryGenerator_BlueprintBase_DoItemGeneration_Params
{
	TArray<struct FVector>                             ContextLocations_69;                                      // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
};

// Function AIModule.EnvQueryGenerator_BlueprintBase.AddGeneratedVector
struct EnvQueryGenerator_BlueprintBase_AddGeneratedVector_Params
{
	struct FVector                                     GeneratedVector_69;                                       // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function AIModule.EnvQueryGenerator_BlueprintBase.AddGeneratedActor
struct EnvQueryGenerator_BlueprintBase_AddGeneratedActor_Params
{
	class Actor_32759*                                 GeneratedActor_69;                                        // (Parm, ZeroConstructor)
};

// Function AIModule.PathFollowingComponent.OnNavDataRegistered
struct PathFollowingComponent_OnNavDataRegistered_Params
{
	class NavigationData*                              NavData_69;                                               // (Parm, ZeroConstructor)
};

// Function AIModule.PathFollowingComponent.OnActorBump
struct PathFollowingComponent_OnActorBump_Params
{
	class Actor_32759*                                 SelfActor_69;                                             // (Parm, ZeroConstructor)
	class Actor_32759*                                 OtherActor_69;                                            // (Parm, ZeroConstructor)
	struct FVector                                     NormalImpulse_69;                                         // (Parm, ZeroConstructor, IsPlainOldData)
	struct FHitResult                                  Hit_69;                                                   // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
};

// Function AIModule.PathFollowingComponent.GetPathDestination
struct PathFollowingComponent_GetPathDestination_Params
{
	struct FVector                                     ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AIModule.PathFollowingComponent.GetPathActionType
struct PathFollowingComponent_GetPathActionType_Params
{
	TEnumAsByte<EPathFollowingAction>                  ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AIModule.CrowdFollowingComponent.SuspendCrowdSteering
struct CrowdFollowingComponent_SuspendCrowdSteering_Params
{
	bool                                               bSuspend_69;                                              // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function AIModule.NavLinkProxy.SetSmartLinkEnabled
struct NavLinkProxy_SetSmartLinkEnabled_Params
{
	bool                                               bEnabled_69;                                              // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function AIModule.NavLinkProxy.ResumePathFollowing
struct NavLinkProxy_ResumePathFollowing_Params
{
	class Actor_32759*                                 Agent_69;                                                 // (Parm, ZeroConstructor)
};

// Function AIModule.NavLinkProxy.ReceiveSmartLinkReached
struct NavLinkProxy_ReceiveSmartLinkReached_Params
{
	class Actor_32759*                                 Agent_69;                                                 // (Parm, ZeroConstructor)
	struct FVector                                     Destination_69;                                           // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
};

// Function AIModule.NavLinkProxy.IsSmartLinkEnabled
struct NavLinkProxy_IsSmartLinkEnabled_Params
{
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AIModule.NavLinkProxy.HasMovingAgents
struct NavLinkProxy_HasMovingAgents_Params
{
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AIModule.NavLocalGridManager.SetLocalNavigationGridDensity
struct NavLocalGridManager_SetLocalNavigationGridDensity_Params
{
	class Object_32759*                                WorldContextObject_69;                                    // (Parm, ZeroConstructor)
	float                                              CellSize_69;                                              // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AIModule.NavLocalGridManager.RemoveLocalNavigationGrid
struct NavLocalGridManager_RemoveLocalNavigationGrid_Params
{
	class Object_32759*                                WorldContextObject_69;                                    // (Parm, ZeroConstructor)
	int                                                GridId_69;                                                // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bRebuildGrids_69;                                         // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function AIModule.NavLocalGridManager.FindLocalNavigationGridPath
struct NavLocalGridManager_FindLocalNavigationGridPath_Params
{
	class Object_32759*                                WorldContextObject_69;                                    // (Parm, ZeroConstructor)
	struct FVector                                     Start_69;                                                 // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
	struct FVector                                     End_69;                                                   // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
	TArray<struct FVector>                             PathPoints_69;                                            // (Parm, OutParm, ZeroConstructor)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AIModule.NavLocalGridManager.AddLocalNavigationGridForPoints
struct NavLocalGridManager_AddLocalNavigationGridForPoints_Params
{
	class Object_32759*                                WorldContextObject_69;                                    // (Parm, ZeroConstructor)
	TArray<struct FVector>                             Locations_69;                                             // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	int                                                Radius2D_69;                                              // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	float                                              Height_69;                                                // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bRebuildGrids_69;                                         // (Parm, ZeroConstructor, IsPlainOldData)
	int                                                ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AIModule.NavLocalGridManager.AddLocalNavigationGridForPoint
struct NavLocalGridManager_AddLocalNavigationGridForPoint_Params
{
	class Object_32759*                                WorldContextObject_69;                                    // (Parm, ZeroConstructor)
	struct FVector                                     Location_69;                                              // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
	int                                                Radius2D_69;                                              // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	float                                              Height_69;                                                // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bRebuildGrids_69;                                         // (Parm, ZeroConstructor, IsPlainOldData)
	int                                                ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AIModule.NavLocalGridManager.AddLocalNavigationGridForCapsule
struct NavLocalGridManager_AddLocalNavigationGridForCapsule_Params
{
	class Object_32759*                                WorldContextObject_69;                                    // (Parm, ZeroConstructor)
	struct FVector                                     Location_69;                                              // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
	float                                              CapsuleRadius_69;                                         // (Parm, ZeroConstructor, IsPlainOldData)
	float                                              CapsuleHalfHeight_69;                                     // (Parm, ZeroConstructor, IsPlainOldData)
	int                                                Radius2D_69;                                              // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	float                                              Height_69;                                                // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bRebuildGrids_69;                                         // (Parm, ZeroConstructor, IsPlainOldData)
	int                                                ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AIModule.NavLocalGridManager.AddLocalNavigationGridForBox
struct NavLocalGridManager_AddLocalNavigationGridForBox_Params
{
	class Object_32759*                                WorldContextObject_69;                                    // (Parm, ZeroConstructor)
	struct FVector                                     Location_69;                                              // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
	struct FVector                                     Extent_69;                                                // (Parm, ZeroConstructor, IsPlainOldData)
	struct FRotator                                    Rotation_69;                                              // (Parm, ZeroConstructor, IsPlainOldData)
	int                                                Radius2D_69;                                              // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	float                                              Height_69;                                                // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bRebuildGrids_69;                                         // (Parm, ZeroConstructor, IsPlainOldData)
	int                                                ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AIModule.AIPerceptionComponent.SetSenseEnabled
struct AIPerceptionComponent_SetSenseEnabled_Params
{
	class AISense*                                     SenseClass_69;                                            // (Parm, ZeroConstructor)
	bool                                               bEnable_69;                                               // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function AIModule.AIPerceptionComponent.RequestStimuliListenerUpdate
struct AIPerceptionComponent_RequestStimuliListenerUpdate_Params
{
};

// Function AIModule.AIPerceptionComponent.OnOwnerEndPlay
struct AIPerceptionComponent_OnOwnerEndPlay_Params
{
	class Actor_32759*                                 Actor_69;                                                 // (Parm, ZeroConstructor)
	TEnumAsByte<EEndPlayReason>                        EndPlayReason_69;                                         // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function AIModule.AIPerceptionComponent.GetPerceivedHostileActorsBySense
struct AIPerceptionComponent_GetPerceivedHostileActorsBySense_Params
{
	class AISense*                                     SenseToUse_69;                                            // (ConstParm, Parm, ZeroConstructor)
	TArray<class Actor_32759*>                         OutActors_69;                                             // (Parm, OutParm, ZeroConstructor)
};

// Function AIModule.AIPerceptionComponent.GetPerceivedHostileActors
struct AIPerceptionComponent_GetPerceivedHostileActors_Params
{
	TArray<class Actor_32759*>                         OutActors_69;                                             // (Parm, OutParm, ZeroConstructor)
};

// Function AIModule.AIPerceptionComponent.GetPerceivedActors
struct AIPerceptionComponent_GetPerceivedActors_Params
{
	class AISense*                                     SenseToUse_69;                                            // (Parm, ZeroConstructor)
	TArray<class Actor_32759*>                         OutActors_69;                                             // (Parm, OutParm, ZeroConstructor)
};

// Function AIModule.AIPerceptionComponent.GetKnownPerceivedActors
struct AIPerceptionComponent_GetKnownPerceivedActors_Params
{
	class AISense*                                     SenseToUse_69;                                            // (Parm, ZeroConstructor)
	TArray<class Actor_32759*>                         OutActors_69;                                             // (Parm, OutParm, ZeroConstructor)
};

// Function AIModule.AIPerceptionComponent.GetCurrentlyPerceivedActors
struct AIPerceptionComponent_GetCurrentlyPerceivedActors_Params
{
	class AISense*                                     SenseToUse_69;                                            // (Parm, ZeroConstructor)
	TArray<class Actor_32759*>                         OutActors_69;                                             // (Parm, OutParm, ZeroConstructor)
};

// Function AIModule.AIPerceptionComponent.GetActorsPerception
struct AIPerceptionComponent_GetActorsPerception_Params
{
	class Actor_32759*                                 Actor_69;                                                 // (Parm, ZeroConstructor)
	struct FActorPerceptionBlueprintInfo               Info_69;                                                  // (Parm, OutParm)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AIModule.AIPerceptionComponent.ForgetAll
struct AIPerceptionComponent_ForgetAll_Params
{
};

// Function AIModule.AIPerceptionStimuliSourceComponent.UnregisterFromSense
struct AIPerceptionStimuliSourceComponent_UnregisterFromSense_Params
{
	class AISense*                                     SenseClass_69;                                            // (Parm, ZeroConstructor)
};

// Function AIModule.AIPerceptionStimuliSourceComponent.UnregisterFromPerceptionSystem
struct AIPerceptionStimuliSourceComponent_UnregisterFromPerceptionSystem_Params
{
};

// Function AIModule.AIPerceptionStimuliSourceComponent.RegisterWithPerceptionSystem
struct AIPerceptionStimuliSourceComponent_RegisterWithPerceptionSystem_Params
{
};

// Function AIModule.AIPerceptionStimuliSourceComponent.RegisterForSense
struct AIPerceptionStimuliSourceComponent_RegisterForSense_Params
{
	class AISense*                                     SenseClass_69;                                            // (Parm, ZeroConstructor)
};

// Function AIModule.AIPerceptionSystem.ReportPerceptionEvent
struct AIPerceptionSystem_ReportPerceptionEvent_Params
{
	class Object_32759*                                WorldContextObject_69;                                    // (Parm, ZeroConstructor)
	class AISenseEvent*                                PerceptionEvent_69;                                       // (Parm, ZeroConstructor)
};

// Function AIModule.AIPerceptionSystem.ReportEvent
struct AIPerceptionSystem_ReportEvent_Params
{
	class AISenseEvent*                                PerceptionEvent_69;                                       // (Parm, ZeroConstructor)
};

// Function AIModule.AIPerceptionSystem.RegisterPerceptionStimuliSource
struct AIPerceptionSystem_RegisterPerceptionStimuliSource_Params
{
	class Object_32759*                                WorldContextObject_69;                                    // (Parm, ZeroConstructor)
	class AISense*                                     Sense_69;                                                 // (Parm, ZeroConstructor)
	class Actor_32759*                                 Target_69;                                                // (Parm, ZeroConstructor)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AIModule.AIPerceptionSystem.OnPerceptionStimuliSourceEndPlay
struct AIPerceptionSystem_OnPerceptionStimuliSourceEndPlay_Params
{
	class Actor_32759*                                 Actor_69;                                                 // (Parm, ZeroConstructor)
	TEnumAsByte<EEndPlayReason>                        EndPlayReason_69;                                         // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function AIModule.AIPerceptionSystem.GetSenseClassForStimulus
struct AIPerceptionSystem_GetSenseClassForStimulus_Params
{
	class Object_32759*                                WorldContextObject_69;                                    // (Parm, ZeroConstructor)
	struct FAIStimulus                                 Stimulus_69;                                              // (ConstParm, Parm, OutParm, ReferenceParm)
	class AISense*                                     ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function AIModule.AISense_Blueprint.OnUpdate
struct AISense_Blueprint_OnUpdate_Params
{
	TArray<class AISenseEvent*>                        EventsToProcess_69;                                       // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	float                                              ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AIModule.AISense_Blueprint.OnListenerUpdated
struct AISense_Blueprint_OnListenerUpdated_Params
{
	class Actor_32759*                                 ActorListener_69;                                         // (Parm, ZeroConstructor)
	class AIPerceptionComponent*                       PerceptionComponent_69;                                   // (Parm, ZeroConstructor, InstancedReference)
};

// Function AIModule.AISense_Blueprint.OnListenerUnregistered
struct AISense_Blueprint_OnListenerUnregistered_Params
{
	class Actor_32759*                                 ActorListener_69;                                         // (Parm, ZeroConstructor)
	class AIPerceptionComponent*                       PerceptionComponent_69;                                   // (Parm, ZeroConstructor, InstancedReference)
};

// Function AIModule.AISense_Blueprint.OnListenerRegistered
struct AISense_Blueprint_OnListenerRegistered_Params
{
	class Actor_32759*                                 ActorListener_69;                                         // (Parm, ZeroConstructor)
	class AIPerceptionComponent*                       PerceptionComponent_69;                                   // (Parm, ZeroConstructor, InstancedReference)
};

// Function AIModule.AISense_Blueprint.K2_OnNewPawn
struct AISense_Blueprint_K2_OnNewPawn_Params
{
	class Pawn*                                        NewPawn_69;                                               // (Parm, ZeroConstructor)
};

// Function AIModule.AISense_Blueprint.GetAllListenerComponents
struct AISense_Blueprint_GetAllListenerComponents_Params
{
	TArray<class AIPerceptionComponent*>               ListenerComponents_69;                                    // (Parm, OutParm, ZeroConstructor)
};

// Function AIModule.AISense_Blueprint.GetAllListenerActors
struct AISense_Blueprint_GetAllListenerActors_Params
{
	TArray<class Actor_32759*>                         ListenerActors_69;                                        // (Parm, OutParm, ZeroConstructor)
};

// Function AIModule.AISense_Damage.ReportDamageEvent
struct AISense_Damage_ReportDamageEvent_Params
{
	class Object_32759*                                WorldContextObject_69;                                    // (Parm, ZeroConstructor)
	class Actor_32759*                                 DamagedActor_69;                                          // (Parm, ZeroConstructor)
	class Actor_32759*                                 Instigator_69;                                            // (Parm, ZeroConstructor)
	float                                              DamageAmount_69;                                          // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector                                     EventLocation_69;                                         // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector                                     HitLocation_69;                                           // (Parm, ZeroConstructor, IsPlainOldData)
	struct FName                                       tag_69;                                                   // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function AIModule.AISense_Hearing.ReportNoiseEvent
struct AISense_Hearing_ReportNoiseEvent_Params
{
	class Object_32759*                                WorldContextObject_69;                                    // (Parm, ZeroConstructor)
	struct FVector                                     NoiseLocation_69;                                         // (Parm, ZeroConstructor, IsPlainOldData)
	float                                              Loudness_69;                                              // (Parm, ZeroConstructor, IsPlainOldData)
	class Actor_32759*                                 Instigator_69;                                            // (Parm, ZeroConstructor)
	float                                              MaxRange_69;                                              // (Parm, ZeroConstructor, IsPlainOldData)
	struct FName                                       tag_69;                                                   // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function AIModule.AISense_Prediction.RequestPawnPredictionEvent
struct AISense_Prediction_RequestPawnPredictionEvent_Params
{
	class Pawn*                                        Requestor_69;                                             // (Parm, ZeroConstructor)
	class Actor_32759*                                 PredictedActor_69;                                        // (Parm, ZeroConstructor)
	float                                              PredictionTime_69;                                        // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function AIModule.AISense_Prediction.RequestControllerPredictionEvent
struct AISense_Prediction_RequestControllerPredictionEvent_Params
{
	class AIController*                                Requestor_69;                                             // (Parm, ZeroConstructor)
	class Actor_32759*                                 PredictedActor_69;                                        // (Parm, ZeroConstructor)
	float                                              PredictionTime_69;                                        // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function AIModule.AISense_Touch.ReportTouchEvent
struct AISense_Touch_ReportTouchEvent_Params
{
	class Object_32759*                                WorldContextObject_69;                                    // (Parm, ZeroConstructor)
	class Actor_32759*                                 TouchReceiver_69;                                         // (Parm, ZeroConstructor)
	class Actor_32759*                                 OtherActor_69;                                            // (Parm, ZeroConstructor)
	struct FVector                                     Location_69;                                              // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function AIModule.PawnSensingComponent.SetSensingUpdatesEnabled
struct PawnSensingComponent_SetSensingUpdatesEnabled_Params
{
	bool                                               bEnabled_69;                                              // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function AIModule.PawnSensingComponent.SetSensingInterval
struct PawnSensingComponent_SetSensingInterval_Params
{
	float                                              NewSensingInterval_69;                                    // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function AIModule.PawnSensingComponent.SetPeripheralVisionAngle
struct PawnSensingComponent_SetPeripheralVisionAngle_Params
{
	float                                              NewPeripheralVisionAngle_69;                              // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// DelegateFunction AIModule.PawnSensingComponent.SeePawnDelegate__DelegateSignature
struct PawnSensingComponent_SeePawnDelegate__DelegateSignature_Params
{
	class Pawn*                                        Pawn_69;                                                  // (Parm, ZeroConstructor)
};

// DelegateFunction AIModule.PawnSensingComponent.HearNoiseDelegate__DelegateSignature
struct PawnSensingComponent_HearNoiseDelegate__DelegateSignature_Params
{
	class Pawn*                                        Instigator_69;                                            // (Parm, ZeroConstructor)
	struct FVector                                     Location_69;                                              // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
	float                                              Volume_69;                                                // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function AIModule.PawnSensingComponent.GetPeripheralVisionCosine
struct PawnSensingComponent_GetPeripheralVisionCosine_Params
{
	float                                              ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AIModule.PawnSensingComponent.GetPeripheralVisionAngle
struct PawnSensingComponent_GetPeripheralVisionAngle_Params
{
	float                                              ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AIModule.AITask_RunEQS.RunEQS
struct AITask_RunEQS_RunEQS_Params
{
	class AIController*                                Controller_69;                                            // (Parm, ZeroConstructor)
	class EnvQuery*                                    QueryTemplate_69;                                         // (Parm, ZeroConstructor)
	class AITask_RunEQS*                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

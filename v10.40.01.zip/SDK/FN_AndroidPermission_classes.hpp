#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Classes
//---------------------------------------------------------------------------

// Class AndroidPermission.AndroidPermissionCallbackProxy
// 0x0028 (0x0050 - 0x0028)
class AndroidPermissionCallbackProxy : public Object_32759
{
public:
	unsigned char                                      UnknownData00[0x10];                                      // 0x0028(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty AndroidPermission.AndroidPermissionCallbackProxy.OnPermissionsGrantedDynamicDelegate_69
	unsigned char                                      UnknownData01[0x18];                                      // 0x0038(0x0018) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AndroidPermission.AndroidPermissionCallbackProxy"));
		
		return ptr;
	}

};


// Class AndroidPermission.AndroidPermissionFunctionLibrary
// 0x0000 (0x0028 - 0x0028)
class AndroidPermissionFunctionLibrary : public BlueprintFunctionLibrary
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AndroidPermission.AndroidPermissionFunctionLibrary"));
		
		return ptr;
	}


	bool STATIC_CheckPermission(const struct FString& Permission_69);
	class AndroidPermissionCallbackProxy* STATIC_AcquirePermissions(TArray<struct FString> Permissions_69);
};


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Classes
//---------------------------------------------------------------------------

// Class AudioModulation.AudioModulationStyle
// 0x0000 (0x0028 - 0x0028)
class AudioModulationStyle : public BlueprintFunctionLibrary
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AudioModulation.AudioModulationStyle"));
		
		return ptr;
	}


	struct FCoreUObject_FColor STATIC_GetPatchColor();
	struct FCoreUObject_FColor STATIC_GetParameterColor();
	struct FCoreUObject_FColor STATIC_GetModulationGeneratorColor();
	struct FCoreUObject_FColor STATIC_GetControlBusMixColor();
	struct FCoreUObject_FColor STATIC_GetControlBusColor();
};


// Class AudioModulation.AudioModulationSettings
// 0x0010 (0x0040 - 0x0030)
class AudioModulationSettings : public DeveloperSettings
{
public:
	TArray<struct FSoftObjectPath>                     Parameters_69;                                            // 0x0030(0x0010) (Edit, ZeroConstructor, Config)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AudioModulation.AudioModulationSettings"));
		
		return ptr;
	}

};


// Class AudioModulation.AudioModulationStatics
// 0x0000 (0x0028 - 0x0028)
class AudioModulationStatics : public BlueprintFunctionLibrary
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AudioModulation.AudioModulationStatics"));
		
		return ptr;
	}


	void STATIC_UpdateModulator(class Object_32759* WorldContextObject_69, class SoundModulatorBase* Modulator_69);
	void STATIC_UpdateMixFromObject(class Object_32759* WorldContextObject_69, class SoundControlBusMix* Mix_69, float FadeTime_69);
	void STATIC_UpdateMixByFilter(class Object_32759* WorldContextObject_69, class SoundControlBusMix* Mix_69, const struct FString& AddressFilter_69, class SoundModulationParameter* ParamClassFilter_69, class SoundModulationParameter* ParamFilter_69, float Value_69, float FadeTime_69);
	void STATIC_UpdateMix(class Object_32759* WorldContextObject_69, class SoundControlBusMix* Mix_69, TArray<struct FSoundControlBusMixStage> Stages_69, float FadeTime_69);
	void STATIC_SetGlobalBusMixValue(class Object_32759* WorldContextObject_69, class SoundControlBus* Bus_69, float Value_69, float FadeTime_69);
	void STATIC_SaveMixToProfile(class Object_32759* WorldContextObject_69, class SoundControlBusMix* Mix_69, int ProfileIndex_69);
	TArray<struct FSoundControlBusMixStage> STATIC_LoadMixFromProfile(class Object_32759* WorldContextObject_69, class SoundControlBusMix* Mix_69, bool bActivate_69, int ProfileIndex_69);
	void STATIC_DeactivateGenerator(class Object_32759* WorldContextObject_69, class SoundModulationGenerator* Generator_69);
	void STATIC_DeactivateBusMix(class Object_32759* WorldContextObject_69, class SoundControlBusMix* Mix_69);
	void STATIC_DeactivateBus(class Object_32759* WorldContextObject_69, class SoundControlBus* Bus_69);
	struct FSoundControlBusMixStage STATIC_CreateBusMixStage(class Object_32759* WorldContextObject_69, class SoundControlBus* Bus_69, float Value_69, float AttackTime_69, float ReleaseTime_69);
	class SoundControlBusMix* STATIC_CreateBusMix(class Object_32759* WorldContextObject_69, const struct FName& Name_69, TArray<struct FSoundControlBusMixStage> Stages_69, bool Activate_69);
	class SoundControlBus* STATIC_CreateBus(class Object_32759* WorldContextObject_69, const struct FName& Name_69, class SoundModulationParameter* Parameter_69, bool Activate_69);
	void STATIC_ClearGlobalBusMixValue(class Object_32759* WorldContextObject_69, class SoundControlBus* Bus_69, float FadeTime_69);
	void STATIC_ClearAllGlobalBusMixValues(class Object_32759* WorldContextObject_69, float FadeTime_69);
	void STATIC_ActivateGenerator(class Object_32759* WorldContextObject_69, class SoundModulationGenerator* Generator_69);
	void STATIC_ActivateBusMix(class Object_32759* WorldContextObject_69, class SoundControlBusMix* Mix_69);
	void STATIC_ActivateBus(class Object_32759* WorldContextObject_69, class SoundControlBus* Bus_69);
};


// Class AudioModulation.SoundModulationGenerator
// 0x0000 (0x0030 - 0x0030)
class SoundModulationGenerator : public SoundModulatorBase
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AudioModulation.SoundModulationGenerator"));
		
		return ptr;
	}

};


// Class AudioModulation.SoundModulationGeneratorEnvelopeFollower
// 0x0020 (0x0050 - 0x0030)
class SoundModulationGeneratorEnvelopeFollower : public SoundModulationGenerator
{
public:
	struct FEnvelopeFollowerGeneratorParams            Params_69;                                                // 0x0030(0x0020) (Edit, BlueprintVisible)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AudioModulation.SoundModulationGeneratorEnvelopeFollower"));
		
		return ptr;
	}

};


// Class AudioModulation.SoundModulationGeneratorLFO
// 0x0018 (0x0048 - 0x0030)
class SoundModulationGeneratorLFO : public SoundModulationGenerator
{
public:
	struct FSoundModulationLFOParams                   Params_69;                                                // 0x0030(0x0014) (Edit, BlueprintVisible)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0044(0x0004) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AudioModulation.SoundModulationGeneratorLFO"));
		
		return ptr;
	}

};


// Class AudioModulation.SoundControlBus
// 0x0030 (0x0060 - 0x0030)
class SoundControlBus : public SoundModulatorBase
{
public:
	bool                                               bBypass_69;                                               // 0x0030(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0031(0x0007) MISSED OFFSET
	struct FString                                     Address_69;                                               // 0x0038(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	TArray<class SoundModulationGenerator*>            Generators_69;                                            // 0x0048(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	class SoundModulationParameter*                    Parameter_69;                                             // 0x0058(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AudioModulation.SoundControlBus"));
		
		return ptr;
	}

};


// Class AudioModulation.SoundControlBusMix
// 0x0018 (0x0040 - 0x0028)
class SoundControlBusMix : public Object_32759
{
public:
	uint32_t                                           ProfileIndex_69;                                          // 0x0028(0x0004) (Edit, ZeroConstructor, Transient, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x002C(0x0004) MISSED OFFSET
	TArray<struct FSoundControlBusMixStage>            MixStages_69;                                             // 0x0030(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AudioModulation.SoundControlBusMix"));
		
		return ptr;
	}


	void SoloMix();
	void SaveMixToProfile();
	void LoadMixFromProfile();
	void DeactivateMix();
	void DeactivateAllMixes();
	void ActivateMix();
};


// Class AudioModulation.SoundModulationParameter
// 0x0010 (0x0038 - 0x0028)
class SoundModulationParameter : public Object_32759
{
public:
	unsigned char                                      UnknownData00[0x8];                                       // 0x0028(0x0008) MISSED OFFSET
	struct FSoundModulationParameterSettings           Settings_69;                                              // 0x0030(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly)
	unsigned char                                      UnknownData01[0x4];                                       // 0x0034(0x0004) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AudioModulation.SoundModulationParameter"));
		
		return ptr;
	}

};


// Class AudioModulation.SoundModulationParameterScaled
// 0x0008 (0x0040 - 0x0038)
class SoundModulationParameterScaled : public SoundModulationParameter
{
public:
	float                                              UnitMin_69;                                               // 0x0038(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              UnitMax_69;                                               // 0x003C(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AudioModulation.SoundModulationParameterScaled"));
		
		return ptr;
	}

};


// Class AudioModulation.SoundModulationParameterFrequencyBase
// 0x0000 (0x0038 - 0x0038)
class SoundModulationParameterFrequencyBase : public SoundModulationParameter
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AudioModulation.SoundModulationParameterFrequencyBase"));
		
		return ptr;
	}

};


// Class AudioModulation.SoundModulationParameterFrequency
// 0x0008 (0x0040 - 0x0038)
class SoundModulationParameterFrequency : public SoundModulationParameterFrequencyBase
{
public:
	float                                              UnitMin_69;                                               // 0x0038(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              UnitMax_69;                                               // 0x003C(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AudioModulation.SoundModulationParameterFrequency"));
		
		return ptr;
	}

};


// Class AudioModulation.SoundModulationParameterFilterFrequency
// 0x0000 (0x0038 - 0x0038)
class SoundModulationParameterFilterFrequency : public SoundModulationParameterFrequencyBase
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AudioModulation.SoundModulationParameterFilterFrequency"));
		
		return ptr;
	}

};


// Class AudioModulation.SoundModulationParameterLPFFrequency
// 0x0000 (0x0038 - 0x0038)
class SoundModulationParameterLPFFrequency : public SoundModulationParameterFilterFrequency
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AudioModulation.SoundModulationParameterLPFFrequency"));
		
		return ptr;
	}

};


// Class AudioModulation.SoundModulationParameterHPFFrequency
// 0x0000 (0x0038 - 0x0038)
class SoundModulationParameterHPFFrequency : public SoundModulationParameterFilterFrequency
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AudioModulation.SoundModulationParameterHPFFrequency"));
		
		return ptr;
	}

};


// Class AudioModulation.SoundModulationParameterBipolar
// 0x0008 (0x0040 - 0x0038)
class SoundModulationParameterBipolar : public SoundModulationParameter
{
public:
	float                                              UnitRange_69;                                             // 0x0038(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x003C(0x0004) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AudioModulation.SoundModulationParameterBipolar"));
		
		return ptr;
	}

};


// Class AudioModulation.SoundModulationParameterVolume
// 0x0008 (0x0040 - 0x0038)
class SoundModulationParameterVolume : public SoundModulationParameter
{
public:
	float                                              MinVolume_69;                                             // 0x0038(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x003C(0x0004) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AudioModulation.SoundModulationParameterVolume"));
		
		return ptr;
	}

};


// Class AudioModulation.SoundModulationPatch
// 0x0020 (0x0050 - 0x0030)
class SoundModulationPatch : public SoundModulatorBase
{
public:
	struct FSoundControlModulationPatch                PatchSettings_69;                                         // 0x0030(0x0020) (Edit, BlueprintVisible)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AudioModulation.SoundModulationPatch"));
		
		return ptr;
	}

};


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

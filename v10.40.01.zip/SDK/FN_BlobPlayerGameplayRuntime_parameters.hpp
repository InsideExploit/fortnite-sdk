#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function BlobPlayerGameplayRuntime.BlobGameplayAbility_Keybind.SetActionDisplayActive
struct BlobGameplayAbility_Keybind_SetActionDisplayActive_Params
{
	bool                                               bWillDisplayActive_69;                                    // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function BlobPlayerGameplayRuntime.FortBlobPlayerBlueprintLibrary.CheckForResumeTeleport
struct FortBlobPlayerBlueprintLibrary_CheckForResumeTeleport_Params
{
	class FortPlayerPawn*                              TargetPawn_69;                                            // (Parm, ZeroConstructor)
	bool                                               bForceCrouch_69;                                          // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	float                                              UnburrowLaunchXYSpeed_69;                                 // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	float                                              UnburrowLaunchZSpeed_69;                                  // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	float                                              ExitHorizontalOffset_69;                                  // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	float                                              ExitUpVerticalOffset_69;                                  // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	float                                              ExitDownVerticalOffset_69;                                // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function BlobPlayerGameplayRuntime.FortBlobPlayerBlueprintLibrary.BlobLog
struct FortBlobPlayerBlueprintLibrary_BlobLog_Params
{
	class Object_32759*                                WorldContextObject_69;                                    // (Parm, ZeroConstructor)
	struct FString                                     InString_69;                                              // (Parm, ZeroConstructor)
	bool                                               bLogInShipping_69;                                        // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function BlobPlayerGameplayRuntime.FortPawnComponent_BlobPlayer.RecoverFromSpecialMeshSetting
struct FortPawnComponent_BlobPlayer_RecoverFromSpecialMeshSetting_Params
{
};

// Function BlobPlayerGameplayRuntime.FortPawnComponent_BlobPlayer.OnRep_MeshSetting
struct FortPawnComponent_BlobPlayer_OnRep_MeshSetting_Params
{
};

// Function BlobPlayerGameplayRuntime.FortPawnComponent_BlobPlayer.HandleFinishedCharacterCustomization
struct FortPawnComponent_BlobPlayer_HandleFinishedCharacterCustomization_Params
{
	class FortPlayerPawn*                              Pawn_69;                                                  // (Parm, ZeroConstructor)
};

// Function BlobPlayerGameplayRuntime.FortPawnComponent_BlobPlayer.ApplySpecialMeshSetting
struct FortPawnComponent_BlobPlayer_ApplySpecialMeshSetting_Params
{
	class AnimInstance*                                BlobAnimInstance_69;                                      // (ConstParm, Parm, ZeroConstructor)
	class SkeletalMesh*                                BlobSkeletalMesh_69;                                      // (Parm, ZeroConstructor)
	TArray<class MaterialInterface*>                   BlobMeshMaterials_69;                                     // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

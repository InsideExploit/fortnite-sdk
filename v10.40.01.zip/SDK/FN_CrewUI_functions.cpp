// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Functions
//---------------------------------------------------------------------------

// Function CrewUI.BattlePassCrewPurchaseButton.OnCurrencyUpdated
// (Event, Protected, BlueprintEvent)

void BattlePassCrewPurchaseButton::OnCurrencyUpdated()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CrewUI.BattlePassCrewPurchaseButton.OnCurrencyUpdated"));

	BattlePassCrewPurchaseButton_OnCurrencyUpdated_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CrewUI.BattlePassCrewPurchaseContainer.OnTriggerIntroAnimation
// (Event, Protected, BlueprintEvent)
// Parameters:
// bool                           bCanClaimRewards_69            (Parm, ZeroConstructor, IsPlainOldData)

void BattlePassCrewPurchaseContainer::OnTriggerIntroAnimation(bool bCanClaimRewards_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CrewUI.BattlePassCrewPurchaseContainer.OnTriggerIntroAnimation"));

	BattlePassCrewPurchaseContainer_OnTriggerIntroAnimation_Params params;
	params.bCanClaimRewards_69 = bCanClaimRewards_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CrewUI.BattlePassCrewPurchaseContainer.OnContentStateUpdated
// (Event, Protected, BlueprintEvent)
// Parameters:
// EBattlePassCrewContentState    InState_69                     (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bInScreenOpened_69             (Parm, ZeroConstructor, IsPlainOldData)

void BattlePassCrewPurchaseContainer::OnContentStateUpdated(EBattlePassCrewContentState InState_69, bool bInScreenOpened_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CrewUI.BattlePassCrewPurchaseContainer.OnContentStateUpdated"));

	BattlePassCrewPurchaseContainer_OnContentStateUpdated_Params params;
	params.InState_69 = InState_69;
	params.bInScreenOpened_69 = bInScreenOpened_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CrewUI.BattlePassPurchaseScreen.OnShowNavButtonNotification
// (Event, Protected, BlueprintEvent)
// Parameters:
// bool                           bShowNotification_69           (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void BattlePassPurchaseScreen::OnShowNavButtonNotification(bool bShowNotification_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CrewUI.BattlePassPurchaseScreen.OnShowNavButtonNotification"));

	BattlePassPurchaseScreen_OnShowNavButtonNotification_Params params;
	params.bShowNotification_69 = bShowNotification_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CrewUI.BattlePassPurchaseScreen.OnSetScreenInteractable
// (Event, Protected, BlueprintEvent)
// Parameters:
// bool                           bInteractable_69               (Parm, ZeroConstructor, IsPlainOldData)

void BattlePassPurchaseScreen::OnSetScreenInteractable(bool bInteractable_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CrewUI.BattlePassPurchaseScreen.OnSetScreenInteractable"));

	BattlePassPurchaseScreen_OnSetScreenInteractable_Params params;
	params.bInteractable_69 = bInteractable_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CrewUI.BattlePassPurchaseScreen.OnSetNavButtonNotificationText
// (Event, Protected, HasOutParms, BlueprintEvent)
// Parameters:
// struct FText                   NotificationText_69            (ConstParm, Parm, OutParm, ReferenceParm)

void BattlePassPurchaseScreen::OnSetNavButtonNotificationText(const struct FText& NotificationText_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CrewUI.BattlePassPurchaseScreen.OnSetNavButtonNotificationText"));

	BattlePassPurchaseScreen_OnSetNavButtonNotificationText_Params params;
	params.NotificationText_69 = NotificationText_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CrewUI.BattlePassPurchaseScreen.OnPurchaseStateChanged
// (Event, Protected, BlueprintEvent)
// Parameters:
// EBattlePassPurchaseState       InCurrentState_69              (Parm, ZeroConstructor, IsPlainOldData)

void BattlePassPurchaseScreen::OnPurchaseStateChanged(EBattlePassPurchaseState InCurrentState_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CrewUI.BattlePassPurchaseScreen.OnPurchaseStateChanged"));

	BattlePassPurchaseScreen_OnPurchaseStateChanged_Params params;
	params.InCurrentState_69 = InCurrentState_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CrewUI.BattlePassPurchaseScreen.OnPurchaseConfirmed
// (Event, Protected, BlueprintEvent)

void BattlePassPurchaseScreen::OnPurchaseConfirmed()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CrewUI.BattlePassPurchaseScreen.OnPurchaseConfirmed"));

	BattlePassPurchaseScreen_OnPurchaseConfirmed_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CrewUI.CrewMultiSubscriptionAlertModal.OnSetHowToCancelURL
// (Event, Protected, BlueprintEvent)
// Parameters:
// struct FString                 MoreInfoUrl_69                 (Parm, ZeroConstructor)

void CrewMultiSubscriptionAlertModal::OnSetHowToCancelURL(const struct FString& MoreInfoUrl_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CrewUI.CrewMultiSubscriptionAlertModal.OnSetHowToCancelURL"));

	CrewMultiSubscriptionAlertModal_OnSetHowToCancelURL_Params params;
	params.MoreInfoUrl_69 = MoreInfoUrl_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CrewUI.CrewPriceChangeAcknowledgeModal.OnSetPriceChangeAcknowledgeTitle
// (Event, Protected, HasOutParms, BlueprintEvent)
// Parameters:
// struct FText                   Title_69                       (ConstParm, Parm, OutParm, ReferenceParm)

void CrewPriceChangeAcknowledgeModal::OnSetPriceChangeAcknowledgeTitle(const struct FText& Title_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CrewUI.CrewPriceChangeAcknowledgeModal.OnSetPriceChangeAcknowledgeTitle"));

	CrewPriceChangeAcknowledgeModal_OnSetPriceChangeAcknowledgeTitle_Params params;
	params.Title_69 = Title_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CrewUI.CrewPriceChangeAcknowledgeModal.OnSetPriceChangeAcknowledgeMoreInfoUrl
// (Event, Protected, HasOutParms, BlueprintEvent)
// Parameters:
// struct FText                   MoreInfoUrl_69                 (ConstParm, Parm, OutParm, ReferenceParm)

void CrewPriceChangeAcknowledgeModal::OnSetPriceChangeAcknowledgeMoreInfoUrl(const struct FText& MoreInfoUrl_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CrewUI.CrewPriceChangeAcknowledgeModal.OnSetPriceChangeAcknowledgeMoreInfoUrl"));

	CrewPriceChangeAcknowledgeModal_OnSetPriceChangeAcknowledgeMoreInfoUrl_Params params;
	params.MoreInfoUrl_69 = MoreInfoUrl_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CrewUI.CrewPriceChangeAcknowledgeModal.OnSetPriceChangeAcknowledgeMoreInfoText
// (Event, Protected, HasOutParms, BlueprintEvent)
// Parameters:
// struct FText                   ConfirmButtonText_69           (ConstParm, Parm, OutParm, ReferenceParm)

void CrewPriceChangeAcknowledgeModal::OnSetPriceChangeAcknowledgeMoreInfoText(const struct FText& ConfirmButtonText_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CrewUI.CrewPriceChangeAcknowledgeModal.OnSetPriceChangeAcknowledgeMoreInfoText"));

	CrewPriceChangeAcknowledgeModal_OnSetPriceChangeAcknowledgeMoreInfoText_Params params;
	params.ConfirmButtonText_69 = ConfirmButtonText_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CrewUI.CrewPriceChangeAcknowledgeModal.OnSetPriceChangeAcknowledgeConfirmButtonText
// (Event, Protected, HasOutParms, BlueprintEvent)
// Parameters:
// struct FText                   ConfirmButtonText_69           (ConstParm, Parm, OutParm, ReferenceParm)

void CrewPriceChangeAcknowledgeModal::OnSetPriceChangeAcknowledgeConfirmButtonText(const struct FText& ConfirmButtonText_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CrewUI.CrewPriceChangeAcknowledgeModal.OnSetPriceChangeAcknowledgeConfirmButtonText"));

	CrewPriceChangeAcknowledgeModal_OnSetPriceChangeAcknowledgeConfirmButtonText_Params params;
	params.ConfirmButtonText_69 = ConfirmButtonText_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CrewUI.CrewPriceChangeAcknowledgeModal.OnSetPriceChangeAcknowledgeCheckboxText
// (Event, Protected, HasOutParms, BlueprintEvent)
// Parameters:
// struct FText                   CheckboxText_69                (ConstParm, Parm, OutParm, ReferenceParm)

void CrewPriceChangeAcknowledgeModal::OnSetPriceChangeAcknowledgeCheckboxText(const struct FText& CheckboxText_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CrewUI.CrewPriceChangeAcknowledgeModal.OnSetPriceChangeAcknowledgeCheckboxText"));

	CrewPriceChangeAcknowledgeModal_OnSetPriceChangeAcknowledgeCheckboxText_Params params;
	params.CheckboxText_69 = CheckboxText_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CrewUI.CrewPriceChangeAcknowledgeModal.OnSetPriceChangeAcknowledgeCancelSubscriptionButtonText
// (Event, Protected, HasOutParms, BlueprintEvent)
// Parameters:
// struct FText                   CancelSubscriptionButtonText_69 (ConstParm, Parm, OutParm, ReferenceParm)

void CrewPriceChangeAcknowledgeModal::OnSetPriceChangeAcknowledgeCancelSubscriptionButtonText(const struct FText& CancelSubscriptionButtonText_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CrewUI.CrewPriceChangeAcknowledgeModal.OnSetPriceChangeAcknowledgeCancelSubscriptionButtonText"));

	CrewPriceChangeAcknowledgeModal_OnSetPriceChangeAcknowledgeCancelSubscriptionButtonText_Params params;
	params.CancelSubscriptionButtonText_69 = CancelSubscriptionButtonText_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CrewUI.CrewPriceChangeAcknowledgeModal.OnSetPriceChangeAcknowledgeBodyText
// (Event, Protected, HasOutParms, BlueprintEvent)
// Parameters:
// struct FText                   BodyText_69                    (ConstParm, Parm, OutParm, ReferenceParm)

void CrewPriceChangeAcknowledgeModal::OnSetPriceChangeAcknowledgeBodyText(const struct FText& BodyText_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CrewUI.CrewPriceChangeAcknowledgeModal.OnSetPriceChangeAcknowledgeBodyText"));

	CrewPriceChangeAcknowledgeModal_OnSetPriceChangeAcknowledgeBodyText_Params params;
	params.BodyText_69 = BodyText_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CrewUI.CrewPriceChangeAcknowledgeModal.OnSetPriceChangeAcknowledgeBodyTable
// (Event, Protected, HasOutParms, BlueprintEvent)
// Parameters:
// TArray<struct FCrewTableRow>   PriceChangeByRegionRows_69     (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)

void CrewPriceChangeAcknowledgeModal::OnSetPriceChangeAcknowledgeBodyTable(TArray<struct FCrewTableRow> PriceChangeByRegionRows_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CrewUI.CrewPriceChangeAcknowledgeModal.OnSetPriceChangeAcknowledgeBodyTable"));

	CrewPriceChangeAcknowledgeModal_OnSetPriceChangeAcknowledgeBodyTable_Params params;
	params.PriceChangeByRegionRows_69 = PriceChangeByRegionRows_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CrewUI.CrewPriceChangeAcknowledgeModal.OnModalBackout
// (Event, Protected, BlueprintEvent)

void CrewPriceChangeAcknowledgeModal::OnModalBackout()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CrewUI.CrewPriceChangeAcknowledgeModal.OnModalBackout"));

	CrewPriceChangeAcknowledgeModal_OnModalBackout_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CrewUI.CrewPriceChangeAcknowledgeModal.ExitModal
// (Final, Native, Protected, BlueprintCallable)

void CrewPriceChangeAcknowledgeModal::ExitModal()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CrewUI.CrewPriceChangeAcknowledgeModal.ExitModal"));

	CrewPriceChangeAcknowledgeModal_ExitModal_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CrewUI.CrewPurchaseScreen.OnUserInformationTextsUpdated
// (Event, Protected, HasOutParms, BlueprintEvent)
// Parameters:
// struct FText                   UserInformationText1_69        (ConstParm, Parm, OutParm, ReferenceParm)
// struct FText                   UserInformationText2_69        (ConstParm, Parm, OutParm, ReferenceParm)
// EMcpSubscriptionState          SubscriptionState_69           (Parm, ZeroConstructor, IsPlainOldData)

void CrewPurchaseScreen::OnUserInformationTextsUpdated(const struct FText& UserInformationText1_69, const struct FText& UserInformationText2_69, EMcpSubscriptionState SubscriptionState_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CrewUI.CrewPurchaseScreen.OnUserInformationTextsUpdated"));

	CrewPurchaseScreen_OnUserInformationTextsUpdated_Params params;
	params.UserInformationText1_69 = UserInformationText1_69;
	params.UserInformationText2_69 = UserInformationText2_69;
	params.SubscriptionState_69 = SubscriptionState_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CrewUI.CrewPurchaseScreen.OnUpdateVBuckRefundVisibility
// (Event, Protected, BlueprintEvent)
// Parameters:
// bool                           bVisible_69                    (Parm, ZeroConstructor, IsPlainOldData)

void CrewPurchaseScreen::OnUpdateVBuckRefundVisibility(bool bVisible_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CrewUI.CrewPurchaseScreen.OnUpdateVBuckRefundVisibility"));

	CrewPurchaseScreen_OnUpdateVBuckRefundVisibility_Params params;
	params.bVisible_69 = bVisible_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CrewUI.CrewPurchaseScreen.OnUpdatePurchaseButtonState
// (Event, Protected, BlueprintEvent)
// Parameters:
// ECrewPurchaseButtonState       ButtonState_69                 (Parm, ZeroConstructor, IsPlainOldData)

void CrewPurchaseScreen::OnUpdatePurchaseButtonState(ECrewPurchaseButtonState ButtonState_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CrewUI.CrewPurchaseScreen.OnUpdatePurchaseButtonState"));

	CrewPurchaseScreen_OnUpdatePurchaseButtonState_Params params;
	params.ButtonState_69 = ButtonState_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CrewUI.CrewPurchaseScreen.OnShowNavButtonNotification
// (Event, Protected, BlueprintEvent)
// Parameters:
// bool                           bShowNotification_69           (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void CrewPurchaseScreen::OnShowNavButtonNotification(bool bShowNotification_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CrewUI.CrewPurchaseScreen.OnShowNavButtonNotification"));

	CrewPurchaseScreen_OnShowNavButtonNotification_Params params;
	params.bShowNotification_69 = bShowNotification_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CrewUI.CrewPurchaseScreen.OnSetNavButtonNotificationText
// (Event, Protected, HasOutParms, BlueprintEvent)
// Parameters:
// struct FText                   NotificationText_69            (ConstParm, Parm, OutParm, ReferenceParm)

void CrewPurchaseScreen::OnSetNavButtonNotificationText(const struct FText& NotificationText_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CrewUI.CrewPurchaseScreen.OnSetNavButtonNotificationText"));

	CrewPurchaseScreen_OnSetNavButtonNotificationText_Params params;
	params.NotificationText_69 = NotificationText_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CrewUI.CrewPurchaseScreen.OnContainerTabVisibilityUpdated
// (Event, Protected, BlueprintEvent)
// Parameters:
// bool                           bTabsVisible_69                (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// float                          SpacingAdjustmentForTabs_69    (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void CrewPurchaseScreen::OnContainerTabVisibilityUpdated(bool bTabsVisible_69, float SpacingAdjustmentForTabs_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CrewUI.CrewPurchaseScreen.OnContainerTabVisibilityUpdated"));

	CrewPurchaseScreen_OnContainerTabVisibilityUpdated_Params params;
	params.bTabsVisible_69 = bTabsVisible_69;
	params.SpacingAdjustmentForTabs_69 = SpacingAdjustmentForTabs_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CrewUI.CrewPurchaseScreen.EndProgress
// (Event, Protected, BlueprintEvent)

void CrewPurchaseScreen::EndProgress()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CrewUI.CrewPurchaseScreen.EndProgress"));

	CrewPurchaseScreen_EndProgress_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CrewUI.CrewPurchaseScreen.BeginProgress
// (Event, Protected, HasOutParms, BlueprintEvent)
// Parameters:
// struct FText                   ProgressLabel_69               (ConstParm, Parm, OutParm, ReferenceParm)

void CrewPurchaseScreen::BeginProgress(const struct FText& ProgressLabel_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CrewUI.CrewPurchaseScreen.BeginProgress"));

	CrewPurchaseScreen_BeginProgress_Params params;
	params.ProgressLabel_69 = ProgressLabel_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CrewUI.CrewRewardTile.OnUpdateOwnedState
// (Event, Protected, BlueprintEvent)
// Parameters:
// bool                           bOwned_69                      (Parm, ZeroConstructor, IsPlainOldData)

void CrewRewardTile::OnUpdateOwnedState(bool bOwned_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CrewUI.CrewRewardTile.OnUpdateOwnedState"));

	CrewRewardTile_OnUpdateOwnedState_Params params;
	params.bOwned_69 = bOwned_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CrewUI.CrewRewardTile.OnStartingDownloadTileImage
// (Event, Protected, BlueprintEvent)

void CrewRewardTile::OnStartingDownloadTileImage()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CrewUI.CrewRewardTile.OnStartingDownloadTileImage"));

	CrewRewardTile_OnStartingDownloadTileImage_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CrewUI.CrewRewardTile.OnDownloadTileImageComplete
// (Event, Protected, BlueprintEvent)
// Parameters:
// class Texture2D*               Texture_69                     (Parm, ZeroConstructor)

void CrewRewardTile::OnDownloadTileImageComplete(class Texture2D* Texture_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CrewUI.CrewRewardTile.OnDownloadTileImageComplete"));

	CrewRewardTile_OnDownloadTileImageComplete_Params params;
	params.Texture_69 = Texture_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CrewUI.CrewRewardTile.IsMonthlyBenefit
// (Final, Native, Protected, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool CrewRewardTile::IsMonthlyBenefit()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CrewUI.CrewRewardTile.IsMonthlyBenefit"));

	CrewRewardTile_IsMonthlyBenefit_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CrewUI.CrewSubscriptionContentContainer.OnTabSelected
// (Event, Protected, BlueprintEvent)
// Parameters:
// int                            TabIndex_69                    (Parm, ZeroConstructor, IsPlainOldData)

void CrewSubscriptionContentContainer::OnTabSelected(int TabIndex_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CrewUI.CrewSubscriptionContentContainer.OnTabSelected"));

	CrewSubscriptionContentContainer_OnTabSelected_Params params;
	params.TabIndex_69 = TabIndex_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CrewUI.CrewTileDetailsTag.OnTagSetup
// (Event, Protected, BlueprintEvent)
// Parameters:
// ECrewDetailsTag                RewardTag_69                   (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bIsOwnedTag_69                 (Parm, ZeroConstructor, IsPlainOldData)

void CrewTileDetailsTag::OnTagSetup(ECrewDetailsTag RewardTag_69, bool bIsOwnedTag_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CrewUI.CrewTileDetailsTag.OnTagSetup"));

	CrewTileDetailsTag_OnTagSetup_Params params;
	params.RewardTag_69 = RewardTag_69;
	params.bIsOwnedTag_69 = bIsOwnedTag_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CrewUI.FortProgressiveScreenBase.BP_OnContainerTabVisibilityUpdated
// (Event, Protected, BlueprintEvent)
// Parameters:
// bool                           bTabsVisible_69                (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// float                          SpacingAdjustmentForTabs_69    (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void FortProgressiveScreenBase::BP_OnContainerTabVisibilityUpdated(bool bTabsVisible_69, float SpacingAdjustmentForTabs_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CrewUI.FortProgressiveScreenBase.BP_OnContainerTabVisibilityUpdated"));

	FortProgressiveScreenBase_BP_OnContainerTabVisibilityUpdated_Params params;
	params.bTabsVisible_69 = bTabsVisible_69;
	params.SpacingAdjustmentForTabs_69 = SpacingAdjustmentForTabs_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CrewUI.FortProgressiveItemScreen.OnUpdateSubscriptionState
// (Event, Protected, BlueprintEvent)
// Parameters:
// bool                           bSubscribed_69                 (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void FortProgressiveItemScreen::OnUpdateSubscriptionState(bool bSubscribed_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CrewUI.FortProgressiveItemScreen.OnUpdateSubscriptionState"));

	FortProgressiveItemScreen_OnUpdateSubscriptionState_Params params;
	params.bSubscribed_69 = bSubscribed_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CrewUI.FortProgressiveItemScreen.OnSetIsSoloScreen
// (Event, Protected, BlueprintEvent)
// Parameters:
// bool                           bInIsSoloScreen_69             (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void FortProgressiveItemScreen::OnSetIsSoloScreen(bool bInIsSoloScreen_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CrewUI.FortProgressiveItemScreen.OnSetIsSoloScreen"));

	FortProgressiveItemScreen_OnSetIsSoloScreen_Params params;
	params.bInIsSoloScreen_69 = bInIsSoloScreen_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CrewUI.FortProgressiveItemScreen.OnItemSelected
// (Event, Protected, BlueprintEvent)

void FortProgressiveItemScreen::OnItemSelected()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CrewUI.FortProgressiveItemScreen.OnItemSelected"));

	FortProgressiveItemScreen_OnItemSelected_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CrewUI.FortProgressiveItemScreen.OnErrorStateTextUpdated
// (Event, Protected, HasOutParms, BlueprintEvent)
// Parameters:
// struct FText                   ErrorStateText_69              (ConstParm, Parm, OutParm, ReferenceParm)

void FortProgressiveItemScreen::OnErrorStateTextUpdated(const struct FText& ErrorStateText_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CrewUI.FortProgressiveItemScreen.OnErrorStateTextUpdated"));

	FortProgressiveItemScreen_OnErrorStateTextUpdated_Params params;
	params.ErrorStateText_69 = ErrorStateText_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CrewUI.FortProgressiveItemStateTitleWidget.BP_OnSetHeaderInfo
// (Event, Protected, HasOutParms, BlueprintEvent)
// Parameters:
// struct FText                   Subheading_69                  (ConstParm, Parm, OutParm, ReferenceParm)
// bool                           bSubscribed_69                 (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// int                            UnlockedStages_69              (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// int                            MaxStages_69                   (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void FortProgressiveItemStateTitleWidget::BP_OnSetHeaderInfo(const struct FText& Subheading_69, bool bSubscribed_69, int UnlockedStages_69, int MaxStages_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CrewUI.FortProgressiveItemStateTitleWidget.BP_OnSetHeaderInfo"));

	FortProgressiveItemStateTitleWidget_BP_OnSetHeaderInfo_Params params;
	params.Subheading_69 = Subheading_69;
	params.bSubscribed_69 = bSubscribed_69;
	params.UnlockedStages_69 = UnlockedStages_69;
	params.MaxStages_69 = MaxStages_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CrewUI.FortProgressiveItemWidget.OnUnhighlighted
// (Event, Protected, BlueprintEvent)

void FortProgressiveItemWidget::OnUnhighlighted()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CrewUI.FortProgressiveItemWidget.OnUnhighlighted"));

	FortProgressiveItemWidget_OnUnhighlighted_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CrewUI.FortProgressiveItemWidget.OnTileMaterialLoaded
// (Event, Protected, BlueprintEvent)
// Parameters:
// bool                           bSubscribed_69                 (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void FortProgressiveItemWidget::OnTileMaterialLoaded(bool bSubscribed_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CrewUI.FortProgressiveItemWidget.OnTileMaterialLoaded"));

	FortProgressiveItemWidget_OnTileMaterialLoaded_Params params;
	params.bSubscribed_69 = bSubscribed_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CrewUI.FortProgressiveItemWidget.OnStageItemChanged
// (Event, Protected, HasOutParms, BlueprintEvent)
// Parameters:
// struct FProgressiveStageItemInfo InStageItemInfo_69             (ConstParm, Parm, OutParm, ReferenceParm)

void FortProgressiveItemWidget::OnStageItemChanged(const struct FProgressiveStageItemInfo& InStageItemInfo_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CrewUI.FortProgressiveItemWidget.OnStageItemChanged"));

	FortProgressiveItemWidget_OnStageItemChanged_Params params;
	params.InStageItemInfo_69 = InStageItemInfo_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CrewUI.FortProgressiveItemWidget.OnPeekStateChanged
// (Event, Protected, BlueprintEvent)
// Parameters:
// bool                           bIsInPeekState_69              (Parm, ZeroConstructor, IsPlainOldData)

void FortProgressiveItemWidget::OnPeekStateChanged(bool bIsInPeekState_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CrewUI.FortProgressiveItemWidget.OnPeekStateChanged"));

	FortProgressiveItemWidget_OnPeekStateChanged_Params params;
	params.bIsInPeekState_69 = bIsInPeekState_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CrewUI.FortProgressiveItemWidget.OnHighlighted
// (Event, Protected, BlueprintEvent)

void FortProgressiveItemWidget::OnHighlighted()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CrewUI.FortProgressiveItemWidget.OnHighlighted"));

	FortProgressiveItemWidget_OnHighlighted_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CrewUI.FortProgressiveSetDetailsWidget.BP_OnUpdateSetDetails
// (Event, Protected, HasOutParms, BlueprintEvent)
// Parameters:
// struct FText                   SetName_69                     (ConstParm, Parm, OutParm, ReferenceParm)
// struct FText                   ExpiringText_69                (ConstParm, Parm, OutParm, ReferenceParm)
// bool                           bCompleted_69                  (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void FortProgressiveSetDetailsWidget::BP_OnUpdateSetDetails(const struct FText& SetName_69, const struct FText& ExpiringText_69, bool bCompleted_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CrewUI.FortProgressiveSetDetailsWidget.BP_OnUpdateSetDetails"));

	FortProgressiveSetDetailsWidget_BP_OnUpdateSetDetails_Params params;
	params.SetName_69 = SetName_69;
	params.ExpiringText_69 = ExpiringText_69;
	params.bCompleted_69 = bCompleted_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CrewUI.FortProgressiveSetList.ClearSetTiles
// (Event, Protected, BlueprintEvent)

void FortProgressiveSetList::ClearSetTiles()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CrewUI.FortProgressiveSetList.ClearSetTiles"));

	FortProgressiveSetList_ClearSetTiles_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CrewUI.FortProgressiveSetList.AddSetTile
// (Event, Protected, BlueprintEvent)
// Parameters:
// class FortProgressiveSetTile*  ReturnValue_69                 (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)

class FortProgressiveSetTile* FortProgressiveSetList::AddSetTile()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CrewUI.FortProgressiveSetList.AddSetTile"));

	FortProgressiveSetList_AddSetTile_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CrewUI.FortProgressiveSetTile.BP_OnTileMaterialLoaded
// (Event, Protected, BlueprintEvent)
// Parameters:
// bool                           bSubscribed_69                 (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void FortProgressiveSetTile::BP_OnTileMaterialLoaded(bool bSubscribed_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CrewUI.FortProgressiveSetTile.BP_OnTileMaterialLoaded"));

	FortProgressiveSetTile_BP_OnTileMaterialLoaded_Params params;
	params.bSubscribed_69 = bSubscribed_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CrewUI.FortProgressiveSetTile.BP_OnInitializeSetInfo
// (Event, Protected, HasOutParms, BlueprintEvent)
// Parameters:
// struct FProgressiveSetInfo     InSetInfo_69                   (ConstParm, Parm, OutParm, ReferenceParm)
// struct FText                   BottomText_69                  (ConstParm, Parm, OutParm, ReferenceParm)
// struct FText                   BottomSubtext_69               (ConstParm, Parm, OutParm, ReferenceParm)
// bool                           bSubscribed_69                 (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void FortProgressiveSetTile::BP_OnInitializeSetInfo(const struct FProgressiveSetInfo& InSetInfo_69, const struct FText& BottomText_69, const struct FText& BottomSubtext_69, bool bSubscribed_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CrewUI.FortProgressiveSetTile.BP_OnInitializeSetInfo"));

	FortProgressiveSetTile_BP_OnInitializeSetInfo_Params params;
	params.InSetInfo_69 = InSetInfo_69;
	params.BottomText_69 = BottomText_69;
	params.BottomSubtext_69 = BottomSubtext_69;
	params.bSubscribed_69 = bSubscribed_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CrewUI.FortProgressiveStageList.SelectStageInDirection
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// int                            Direction_69                   (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void FortProgressiveStageList::SelectStageInDirection(int Direction_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CrewUI.FortProgressiveStageList.SelectStageInDirection"));

	FortProgressiveStageList_SelectStageInDirection_Params params;
	params.Direction_69 = Direction_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CrewUI.FortProgressiveStageList.ClearStageWidgets
// (Event, Protected, BlueprintEvent)

void FortProgressiveStageList::ClearStageWidgets()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CrewUI.FortProgressiveStageList.ClearStageWidgets"));

	FortProgressiveStageList_ClearStageWidgets_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CrewUI.FortProgressiveStageList.AddStageWidget
// (Event, Protected, BlueprintEvent)
// Parameters:
// class FortProgressiveStageWidget* ReturnValue_69                 (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)

class FortProgressiveStageWidget* FortProgressiveStageList::AddStageWidget()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CrewUI.FortProgressiveStageList.AddStageWidget"));

	FortProgressiveStageList_AddStageWidget_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CrewUI.FortProgressiveStageWidget.OnSetTooltipVisible
// (Event, Protected, BlueprintEvent)
// Parameters:
// bool                           bVisible_69                    (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void FortProgressiveStageWidget::OnSetTooltipVisible(bool bVisible_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CrewUI.FortProgressiveStageWidget.OnSetTooltipVisible"));

	FortProgressiveStageWidget_OnSetTooltipVisible_Params params;
	params.bVisible_69 = bVisible_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CrewUI.FortProgressiveStageWidget.OnSetTooltipText
// (Event, Protected, HasOutParms, BlueprintEvent)
// Parameters:
// struct FText                   InToolTipText_69               (ConstParm, Parm, OutParm, ReferenceParm)

void FortProgressiveStageWidget::OnSetTooltipText(const struct FText& InToolTipText_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CrewUI.FortProgressiveStageWidget.OnSetTooltipText"));

	FortProgressiveStageWidget_OnSetTooltipText_Params params;
	params.InToolTipText_69 = InToolTipText_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CrewUI.FortProgressiveStageWidget.OnPeekStateChanged
// (Event, Protected, BlueprintEvent)
// Parameters:
// bool                           bIsInPeekState_69              (Parm, ZeroConstructor, IsPlainOldData)

void FortProgressiveStageWidget::OnPeekStateChanged(bool bIsInPeekState_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CrewUI.FortProgressiveStageWidget.OnPeekStateChanged"));

	FortProgressiveStageWidget_OnPeekStateChanged_Params params;
	params.bIsInPeekState_69 = bIsInPeekState_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CrewUI.FortProgressiveStageWidget.ClearStageItemWidgets
// (Event, Protected, BlueprintEvent)

void FortProgressiveStageWidget::ClearStageItemWidgets()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CrewUI.FortProgressiveStageWidget.ClearStageItemWidgets"));

	FortProgressiveStageWidget_ClearStageItemWidgets_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CrewUI.FortProgressiveStageWidget.AddStageItemWidget
// (Event, Protected, BlueprintEvent)
// Parameters:
// class FortProgressiveItemWidget* ReturnValue_69                 (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)

class FortProgressiveItemWidget* FortProgressiveStageWidget::AddStageItemWidget()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CrewUI.FortProgressiveStageWidget.AddStageItemWidget"));

	FortProgressiveStageWidget_AddStageItemWidget_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CrewUI.FortProgressiveTableOfContentsScreen.BP_OnUpdateSubscriptionState
// (Event, Protected, BlueprintEvent)
// Parameters:
// bool                           bSubscribed_69                 (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void FortProgressiveTableOfContentsScreen::BP_OnUpdateSubscriptionState(bool bSubscribed_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CrewUI.FortProgressiveTableOfContentsScreen.BP_OnUpdateSubscriptionState"));

	FortProgressiveTableOfContentsScreen_BP_OnUpdateSubscriptionState_Params params;
	params.bSubscribed_69 = bSubscribed_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CrewUI.FortProgressiveTableOfContentsScreen.BP_OnUpdateNumTilesAvailable
// (Event, Protected, BlueprintEvent)
// Parameters:
// int                            NumTiles_69                    (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void FortProgressiveTableOfContentsScreen::BP_OnUpdateNumTilesAvailable(int NumTiles_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CrewUI.FortProgressiveTableOfContentsScreen.BP_OnUpdateNumTilesAvailable"));

	FortProgressiveTableOfContentsScreen_BP_OnUpdateNumTilesAvailable_Params params;
	params.NumTiles_69 = NumTiles_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CrewUI.FortProgressiveTableOfContentsScreen.BP_OnUpdateErrorStateText
// (Event, Protected, HasOutParms, BlueprintEvent)
// Parameters:
// struct FText                   ErrorStateText_69              (ConstParm, Parm, OutParm, ReferenceParm)

void FortProgressiveTableOfContentsScreen::BP_OnUpdateErrorStateText(const struct FText& ErrorStateText_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CrewUI.FortProgressiveTableOfContentsScreen.BP_OnUpdateErrorStateText"));

	FortProgressiveTableOfContentsScreen_BP_OnUpdateErrorStateText_Params params;
	params.ErrorStateText_69 = ErrorStateText_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CrewUI.FortProgressiveTableOfContentsScreen.BP_OnUpdateBanner
// (Event, Protected, HasOutParms, BlueprintEvent)
// Parameters:
// struct FText                   BannerText_69                  (ConstParm, Parm, OutParm, ReferenceParm)
// bool                           bAllSetsCompleted_69           (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// bool                           bSubscribed_69                 (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void FortProgressiveTableOfContentsScreen::BP_OnUpdateBanner(const struct FText& BannerText_69, bool bAllSetsCompleted_69, bool bSubscribed_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CrewUI.FortProgressiveTableOfContentsScreen.BP_OnUpdateBanner"));

	FortProgressiveTableOfContentsScreen_BP_OnUpdateBanner_Params params;
	params.BannerText_69 = BannerText_69;
	params.bAllSetsCompleted_69 = bAllSetsCompleted_69;
	params.bSubscribed_69 = bSubscribed_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CrewUI.FortProgressiveTableOfContentsScreen.BP_OnSetDescriptionText
// (Event, Protected, HasOutParms, BlueprintEvent)
// Parameters:
// struct FText                   ProductDescription_69          (ConstParm, Parm, OutParm, ReferenceParm)

void FortProgressiveTableOfContentsScreen::BP_OnSetDescriptionText(const struct FText& ProductDescription_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CrewUI.FortProgressiveTableOfContentsScreen.BP_OnSetDescriptionText"));

	FortProgressiveTableOfContentsScreen_BP_OnSetDescriptionText_Params params;
	params.ProductDescription_69 = ProductDescription_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function ArmoredBattleBusRuntime.FortArmoredBattleBusPassengerAnimInstance.UpdateYawDeltaSmoothed
struct FortArmoredBattleBusPassengerAnimInstance_UpdateYawDeltaSmoothed_Params
{
	class FortAthenaVehicle*                           VehicleActor_69;                                          // (ConstParm, Parm, ZeroConstructor)
	struct FName                                       SocketName_69;                                            // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	struct FRotator                                    NewRotation_69;                                           // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
	float                                              SmoothedYawValue_69;                                      // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
};

// Function ArmoredBattleBusRuntime.FortArmoredBattleBusPassengerAnimInstance.UpdateSmoothedVehicleYawRate
struct FortArmoredBattleBusPassengerAnimInstance_UpdateSmoothedVehicleYawRate_Params
{
	class FortAthenaVehicle*                           VehicleActor_69;                                          // (ConstParm, Parm, ZeroConstructor)
};

// Function ArmoredBattleBusRuntime.FortArmoredBattleBusPassengerAnimInstance.UpdateHandPositionsSlopeValues
struct FortArmoredBattleBusPassengerAnimInstance_UpdateHandPositionsSlopeValues_Params
{
	class SkeletalMeshComponent*                       BusMeshComponent_69;                                      // (ConstParm, Parm, ZeroConstructor, InstancedReference)
};

// Function ArmoredBattleBusRuntime.FortArmoredBattleBusPassengerAnimInstance.UnrotateHandAttachLocation
struct FortArmoredBattleBusPassengerAnimInstance_UnrotateHandAttachLocation_Params
{
	struct FVector                                     HandLocation_69;                                          // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
	struct FVector                                     FootLocation_69;                                          // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
	struct FRotator                                    FootRotation_69;                                          // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
	struct FVector                                     ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function ArmoredBattleBusRuntime.FortArmoredBattleBusPassengerAnimInstance.GetPassengerTransform
struct FortArmoredBattleBusPassengerAnimInstance_GetPassengerTransform_Params
{
	class SkeletalMeshComponent*                       BusMeshComponent_69;                                      // (ConstParm, Parm, ZeroConstructor, InstancedReference)
	struct FCoreUObject_FTransform                     ReturnValue_69;                                           // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function ArmoredBattleBusRuntime.FortArmoredBattleBusPassengerAnimInstance.GetHandAttachLocation
struct FortArmoredBattleBusPassengerAnimInstance_GetHandAttachLocation_Params
{
	class SkeletalMeshComponent*                       BusMeshComponent_69;                                      // (ConstParm, Parm, ZeroConstructor, InstancedReference)
	struct FName                                       FrontHandAttachBoneName_69;                               // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	struct FName                                       RearHandAttachBoneName_69;                                // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	struct FVector                                     ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function ArmoredBattleBusRuntime.FortArmoredBattleBusPassengerAnimInstance.GetFootAttachTransform
struct FortArmoredBattleBusPassengerAnimInstance_GetFootAttachTransform_Params
{
	class SkeletalMeshComponent*                       BusMeshComponent_69;                                      // (ConstParm, Parm, ZeroConstructor, InstancedReference)
	struct FCoreUObject_FTransform                     ReturnValue_69;                                           // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function ArmoredBattleBusRuntime.FortArmoredBattleBusPassengerAnimInstance.GenerateCharacterPitchAndYawForSlopedTerrain
struct FortArmoredBattleBusPassengerAnimInstance_GenerateCharacterPitchAndYawForSlopedTerrain_Params
{
	class FortAthenaVehicle*                           VehicleActor_69;                                          // (ConstParm, Parm, ZeroConstructor)
	float                                              TurretYaw_69;                                             // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	float                                              TurretPitch_69;                                           // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	struct FRotator                                    PawnYawRotator_69;                                        // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
};

// Function ArmoredBattleBusRuntime.FortArmoredBattleBusVehicleAnimInstance_32759.UpdateYawDeltaSmoothed
struct FortArmoredBattleBusVehicleAnimInstance_32759_UpdateYawDeltaSmoothed_Params
{
	class FortAthenaVehicle*                           VehicleActor_69;                                          // (ConstParm, Parm, ZeroConstructor)
	struct FName                                       SocketName_69;                                            // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	struct FRotator                                    NewRotation_69;                                           // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	float                                              SmoothedYawValue_69;                                      // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	float                                              ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function ArmoredBattleBusRuntime.FortArmoredBattleBusVehicleAnimInstance_32759.UpdateTurretAimPitchWeaponYaw
struct FortArmoredBattleBusVehicleAnimInstance_32759_UpdateTurretAimPitchWeaponYaw_Params
{
	class FortAthenaVehicle*                           OwnerVehicle_69;                                          // (ConstParm, Parm, ZeroConstructor)
	class FortPlayerPawn*                              GunnerActor_69;                                           // (ConstParm, Parm, ZeroConstructor)
	struct FName                                       SocketName_69;                                            // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	float                                              YawOffset_69;                                             // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	float                                              TurretAimPitch_69;                                        // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	float                                              YawDeltaSmoothed_69;                                      // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	struct FRotator                                    WeaponYaw_69;                                             // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
};

// Function ArmoredBattleBusRuntime.FortArmoredBattleBusVehicleAnimInstance_32759.UpdateSmoothedVehicleYawRate
struct FortArmoredBattleBusVehicleAnimInstance_32759_UpdateSmoothedVehicleYawRate_Params
{
	class FortAthenaVehicle*                           VehicleActor_69;                                          // (ConstParm, Parm, ZeroConstructor)
	struct FRotator                                    PreviousRotator_69;                                       // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	float                                              ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function ArmoredBattleBusRuntime.FortArmoredBattleBusVehicleAnimInstance_32759.GetPitchAndYaw
struct FortArmoredBattleBusVehicleAnimInstance_32759_GetPitchAndYaw_Params
{
	class FortAthenaVehicle*                           VehicleActor_69;                                          // (ConstParm, Parm, ZeroConstructor)
	class FortPlayerPawn*                              GunnerActor_69;                                           // (ConstParm, Parm, ZeroConstructor)
	float                                              AdjustedPitch_69;                                         // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	float                                              AdjustedYaw_69;                                           // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	bool                                               bIsLocalPlayerControlled_69;                              // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	struct FRotator                                    YawRotator_69;                                            // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

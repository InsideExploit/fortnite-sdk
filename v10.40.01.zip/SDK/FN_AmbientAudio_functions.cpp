// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Functions
//---------------------------------------------------------------------------

// Function AmbientAudio.AmbientAudioComponent.SetPriority
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// int                            InPriority_69                  (Parm, ZeroConstructor, IsPlainOldData)

void AmbientAudioComponent::SetPriority(int InPriority_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AmbientAudio.AmbientAudioComponent.SetPriority"));

	AmbientAudioComponent_SetPriority_Params params;
	params.InPriority_69 = InPriority_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AmbientAudio.AmbientAudioComponent.SetCrossfadeTime
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// float                          InCrossfadeTime_69             (Parm, ZeroConstructor, IsPlainOldData)

void AmbientAudioComponent::SetCrossfadeTime(float InCrossfadeTime_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AmbientAudio.AmbientAudioComponent.SetCrossfadeTime"));

	AmbientAudioComponent_SetCrossfadeTime_Params params;
	params.InCrossfadeTime_69 = InCrossfadeTime_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AmbientAudio.AmbientAudioComponent.SetAmbientAsset
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// class AmbientAudioDataAsset*   InAmbientAsset_69              (Parm, ZeroConstructor)

void AmbientAudioComponent::SetAmbientAsset(class AmbientAudioDataAsset* InAmbientAsset_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AmbientAudio.AmbientAudioComponent.SetAmbientAsset"));

	AmbientAudioComponent_SetAmbientAsset_Params params;
	params.InAmbientAsset_69 = InAmbientAsset_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AmbientAudio.AmbientAudioSubsystem.RemoveGameplayTag
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// struct FGameplayTag            GameplayTag_69                 (Parm)

void AmbientAudioSubsystem::RemoveGameplayTag(const struct FGameplayTag& GameplayTag_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AmbientAudio.AmbientAudioSubsystem.RemoveGameplayTag"));

	AmbientAudioSubsystem_RemoveGameplayTag_Params params;
	params.GameplayTag_69 = GameplayTag_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AmbientAudio.AmbientAudioSubsystem.RemoveAmbientEntry
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// struct FName                   AmbientName_69                 (Parm, ZeroConstructor, IsPlainOldData)
// float                          CrossfadeOverride_69           (Parm, ZeroConstructor, IsPlainOldData)

void AmbientAudioSubsystem::RemoveAmbientEntry(const struct FName& AmbientName_69, float CrossfadeOverride_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AmbientAudio.AmbientAudioSubsystem.RemoveAmbientEntry"));

	AmbientAudioSubsystem_RemoveAmbientEntry_Params params;
	params.AmbientName_69 = AmbientName_69;
	params.CrossfadeOverride_69 = CrossfadeOverride_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AmbientAudio.AmbientAudioSubsystem.AddGameplayTag
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// struct FGameplayTag            GameplayTag_69                 (Parm)

void AmbientAudioSubsystem::AddGameplayTag(const struct FGameplayTag& GameplayTag_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AmbientAudio.AmbientAudioSubsystem.AddGameplayTag"));

	AmbientAudioSubsystem_AddGameplayTag_Params params;
	params.GameplayTag_69 = GameplayTag_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AmbientAudio.AmbientAudioSubsystem.AddAmbientEntry
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// struct FName                   AmbientName_69                 (Parm, ZeroConstructor, IsPlainOldData)
// class AmbientAudioDataAsset*   Asset_69                       (Parm, ZeroConstructor)
// int                            Priority_69                    (Parm, ZeroConstructor, IsPlainOldData)
// float                          CrossfadeTime_69               (Parm, ZeroConstructor, IsPlainOldData)

void AmbientAudioSubsystem::AddAmbientEntry(const struct FName& AmbientName_69, class AmbientAudioDataAsset* Asset_69, int Priority_69, float CrossfadeTime_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AmbientAudio.AmbientAudioSubsystem.AddAmbientEntry"));

	AmbientAudioSubsystem_AddAmbientEntry_Params params;
	params.AmbientName_69 = AmbientName_69;
	params.Asset_69 = Asset_69;
	params.Priority_69 = Priority_69;
	params.CrossfadeTime_69 = CrossfadeTime_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Functions
//---------------------------------------------------------------------------

// Function AudioGameplayVolume.AudioGameplayVolumeMutator.SetPriority
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// int                            InPriority_69                  (Parm, ZeroConstructor, IsPlainOldData)

void AudioGameplayVolumeMutator::SetPriority(int InPriority_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioGameplayVolume.AudioGameplayVolumeMutator.SetPriority"));

	AudioGameplayVolumeMutator_SetPriority_Params params;
	params.InPriority_69 = InPriority_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AudioGameplayVolume.AttenuationVolumeComponent.SetInteriorVolume
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// float                          Volume_69                      (Parm, ZeroConstructor, IsPlainOldData)
// float                          InterpolateTime_69             (Parm, ZeroConstructor, IsPlainOldData)

void AttenuationVolumeComponent::SetInteriorVolume(float Volume_69, float InterpolateTime_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioGameplayVolume.AttenuationVolumeComponent.SetInteriorVolume"));

	AttenuationVolumeComponent_SetInteriorVolume_Params params;
	params.Volume_69 = Volume_69;
	params.InterpolateTime_69 = InterpolateTime_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AudioGameplayVolume.AttenuationVolumeComponent.SetExteriorVolume
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// float                          Volume_69                      (Parm, ZeroConstructor, IsPlainOldData)
// float                          InterpolateTime_69             (Parm, ZeroConstructor, IsPlainOldData)

void AttenuationVolumeComponent::SetExteriorVolume(float Volume_69, float InterpolateTime_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioGameplayVolume.AttenuationVolumeComponent.SetExteriorVolume"));

	AttenuationVolumeComponent_SetExteriorVolume_Params params;
	params.Volume_69 = Volume_69;
	params.InterpolateTime_69 = InterpolateTime_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AudioGameplayVolume.AudioGameplayVolume.SetEnabled
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// bool                           bEnable_69                     (Parm, ZeroConstructor, IsPlainOldData)

void AudioGameplayVolume::SetEnabled(bool bEnable_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioGameplayVolume.AudioGameplayVolume.SetEnabled"));

	AudioGameplayVolume_SetEnabled_Params params;
	params.bEnable_69 = bEnable_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AudioGameplayVolume.AudioGameplayVolume.OnRep_bEnabled
// (Native, Protected)

void AudioGameplayVolume::OnRep_bEnabled()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioGameplayVolume.AudioGameplayVolume.OnRep_bEnabled"));

	AudioGameplayVolume_OnRep_bEnabled_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AudioGameplayVolume.AudioGameplayVolume.OnListenerExit
// (Native, Event, Public, BlueprintEvent)

void AudioGameplayVolume::OnListenerExit()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioGameplayVolume.AudioGameplayVolume.OnListenerExit"));

	AudioGameplayVolume_OnListenerExit_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AudioGameplayVolume.AudioGameplayVolume.OnListenerEnter
// (Native, Event, Public, BlueprintEvent)

void AudioGameplayVolume::OnListenerEnter()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioGameplayVolume.AudioGameplayVolume.OnListenerEnter"));

	AudioGameplayVolume_OnListenerEnter_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AudioGameplayVolume.FilterVolumeComponent.SetInteriorLPF
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// float                          Volume_69                      (Parm, ZeroConstructor, IsPlainOldData)
// float                          InterpolateTime_69             (Parm, ZeroConstructor, IsPlainOldData)

void FilterVolumeComponent::SetInteriorLPF(float Volume_69, float InterpolateTime_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioGameplayVolume.FilterVolumeComponent.SetInteriorLPF"));

	FilterVolumeComponent_SetInteriorLPF_Params params;
	params.Volume_69 = Volume_69;
	params.InterpolateTime_69 = InterpolateTime_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AudioGameplayVolume.FilterVolumeComponent.SetExteriorLPF
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// float                          Volume_69                      (Parm, ZeroConstructor, IsPlainOldData)
// float                          InterpolateTime_69             (Parm, ZeroConstructor, IsPlainOldData)

void FilterVolumeComponent::SetExteriorLPF(float Volume_69, float InterpolateTime_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioGameplayVolume.FilterVolumeComponent.SetExteriorLPF"));

	FilterVolumeComponent_SetExteriorLPF_Params params;
	params.Volume_69 = Volume_69;
	params.InterpolateTime_69 = InterpolateTime_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AudioGameplayVolume.ReverbVolumeComponent.SetReverbSettings
// (Final, Native, Public, HasOutParms, BlueprintCallable)
// Parameters:
// struct FReverbSettings         NewReverbSettings_69           (ConstParm, Parm, OutParm, ReferenceParm)

void ReverbVolumeComponent::SetReverbSettings(const struct FReverbSettings& NewReverbSettings_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioGameplayVolume.ReverbVolumeComponent.SetReverbSettings"));

	ReverbVolumeComponent_SetReverbSettings_Params params;
	params.NewReverbSettings_69 = NewReverbSettings_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AudioGameplayVolume.SubmixOverrideVolumeComponent.SetSubmixOverrideSettings
// (Final, Native, Public, HasOutParms, BlueprintCallable)
// Parameters:
// TArray<struct FAudioVolumeSubmixOverrideSettings> NewSubmixOverrideSettings_69   (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)

void SubmixOverrideVolumeComponent::SetSubmixOverrideSettings(TArray<struct FAudioVolumeSubmixOverrideSettings> NewSubmixOverrideSettings_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioGameplayVolume.SubmixOverrideVolumeComponent.SetSubmixOverrideSettings"));

	SubmixOverrideVolumeComponent_SetSubmixOverrideSettings_Params params;
	params.NewSubmixOverrideSettings_69 = NewSubmixOverrideSettings_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AudioGameplayVolume.SubmixSendVolumeComponent.SetSubmixSendSettings
// (Final, Native, Public, HasOutParms, BlueprintCallable)
// Parameters:
// TArray<struct FAudioVolumeSubmixSendSettings> NewSubmixSendSettings_69       (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)

void SubmixSendVolumeComponent::SetSubmixSendSettings(TArray<struct FAudioVolumeSubmixSendSettings> NewSubmixSendSettings_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioGameplayVolume.SubmixSendVolumeComponent.SetSubmixSendSettings"));

	SubmixSendVolumeComponent_SetSubmixSendSettings_Params params;
	params.NewSubmixSendSettings_69 = NewSubmixSendSettings_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

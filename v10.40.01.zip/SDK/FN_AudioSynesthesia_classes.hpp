#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Classes
//---------------------------------------------------------------------------

// Class AudioSynesthesia.AudioSynesthesiaSettings
// 0x0000 (0x0028 - 0x0028)
class AudioSynesthesiaSettings : public AudioAnalyzerSettings
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AudioSynesthesia.AudioSynesthesiaSettings"));
		
		return ptr;
	}

};


// Class AudioSynesthesia.AudioSynesthesiaNRTSettings
// 0x0000 (0x0028 - 0x0028)
class AudioSynesthesiaNRTSettings : public AudioAnalyzerNRTSettings
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AudioSynesthesia.AudioSynesthesiaNRTSettings"));
		
		return ptr;
	}

};


// Class AudioSynesthesia.AudioSynesthesiaNRT
// 0x0000 (0x0078 - 0x0078)
class AudioSynesthesiaNRT : public AudioAnalyzerNRT
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AudioSynesthesia.AudioSynesthesiaNRT"));
		
		return ptr;
	}

};


// Class AudioSynesthesia.ConstantQNRTSettings
// 0x0020 (0x0048 - 0x0028)
class ConstantQNRTSettings : public AudioSynesthesiaNRTSettings
{
public:
	float                                              StartingFrequency_69;                                     // 0x0028(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                NumBands_69;                                              // 0x002C(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              NumBandsPerOctave_69;                                     // 0x0030(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              AnalysisPeriod_69;                                        // 0x0034(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	bool                                               bDownmixToMono_69;                                        // 0x0038(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	EConstantQFFTSizeEnum                              FFTSize_69;                                               // 0x0039(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	EFFTWindowType                                     WindowType_69;                                            // 0x003A(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	EAudioSpectrumType                                 SpectrumType_69;                                          // 0x003B(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              BandWidthStretch_69;                                      // 0x003C(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	EConstantQNormalizationEnum                        CQTNormalization_69;                                      // 0x0040(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0041(0x0003) MISSED OFFSET
	float                                              NoiseFloorDb_69;                                          // 0x0044(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AudioSynesthesia.ConstantQNRTSettings"));
		
		return ptr;
	}

};


// Class AudioSynesthesia.ConstantQNRT
// 0x0008 (0x0080 - 0x0078)
class ConstantQNRT : public AudioSynesthesiaNRT
{
public:
	class ConstantQNRTSettings*                        Settings_69;                                              // 0x0078(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AudioSynesthesia.ConstantQNRT"));
		
		return ptr;
	}


	void GetNormalizedChannelConstantQAtTime(float InSeconds_69, int InChannel_69, TArray<float>* OutConstantQ_69);
	void GetChannelConstantQAtTime(float InSeconds_69, int InChannel_69, TArray<float>* OutConstantQ_69);
};


// Class AudioSynesthesia.LoudnessSettings
// 0x0018 (0x0040 - 0x0028)
class LoudnessSettings : public AudioSynesthesiaSettings
{
public:
	float                                              AnalysisPeriod_69;                                        // 0x0028(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              MinimumFrequency_69;                                      // 0x002C(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              MaximumFrequency_69;                                      // 0x0030(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	ELoudnessCurveTypeEnum                             CurveType_69;                                             // 0x0034(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0035(0x0003) MISSED OFFSET
	float                                              NoiseFloorDb_69;                                          // 0x0038(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              ExpectedMaxLoudness_69;                                   // 0x003C(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AudioSynesthesia.LoudnessSettings"));
		
		return ptr;
	}

};


// Class AudioSynesthesia.LoudnessAnalyzer
// 0x0048 (0x00D8 - 0x0090)
class LoudnessAnalyzer : public AudioAnalyzer
{
public:
	class LoudnessSettings*                            Settings_69;                                              // 0x0090(0x0008) (Edit, BlueprintVisible, ZeroConstructor)
	unsigned char                                      UnknownData00[0x10];                                      // 0x0098(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty AudioSynesthesia.LoudnessAnalyzer.OnOverallLoudnessResults_69
	unsigned char                                      UnknownData01[0x10];                                      // 0x00A8(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty AudioSynesthesia.LoudnessAnalyzer.OnPerChannelLoudnessResults_69
	unsigned char                                      UnknownData02[0x10];                                      // 0x00B8(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty AudioSynesthesia.LoudnessAnalyzer.OnLatestOverallLoudnessResults_69
	unsigned char                                      UnknownData03[0x10];                                      // 0x00C8(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty AudioSynesthesia.LoudnessAnalyzer.OnLatestPerChannelLoudnessResults_69

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AudioSynesthesia.LoudnessAnalyzer"));
		
		return ptr;
	}

};


// Class AudioSynesthesia.LoudnessNRTSettings
// 0x0018 (0x0040 - 0x0028)
class LoudnessNRTSettings : public AudioSynesthesiaNRTSettings
{
public:
	float                                              AnalysisPeriod_69;                                        // 0x0028(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              MinimumFrequency_69;                                      // 0x002C(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              MaximumFrequency_69;                                      // 0x0030(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	ELoudnessNRTCurveTypeEnum                          CurveType_69;                                             // 0x0034(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0035(0x0003) MISSED OFFSET
	float                                              NoiseFloorDb_69;                                          // 0x0038(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x4];                                       // 0x003C(0x0004) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AudioSynesthesia.LoudnessNRTSettings"));
		
		return ptr;
	}

};


// Class AudioSynesthesia.LoudnessNRT
// 0x0008 (0x0080 - 0x0078)
class LoudnessNRT : public AudioSynesthesiaNRT
{
public:
	class LoudnessNRTSettings*                         Settings_69;                                              // 0x0078(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AudioSynesthesia.LoudnessNRT"));
		
		return ptr;
	}


	void GetNormalizedLoudnessAtTime(float InSeconds_69, float* OutLoudness_69);
	void GetNormalizedChannelLoudnessAtTime(float InSeconds_69, int InChannel_69, float* OutLoudness_69);
	void GetLoudnessAtTime(float InSeconds_69, float* OutLoudness_69);
	void GetChannelLoudnessAtTime(float InSeconds_69, int InChannel_69, float* OutLoudness_69);
};


// Class AudioSynesthesia.MeterSettings
// 0x0018 (0x0040 - 0x0028)
class MeterSettings : public AudioSynesthesiaSettings
{
public:
	float                                              AnalysisPeriod_69;                                        // 0x0028(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	EMeterPeakType                                     PeakMode_69;                                              // 0x002C(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x002D(0x0003) MISSED OFFSET
	int                                                MeterAttackTime_69;                                       // 0x0030(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                MeterReleaseTime_69;                                      // 0x0034(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                PeakHoldTime_69;                                          // 0x0038(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              ClippingThreshold_69;                                     // 0x003C(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AudioSynesthesia.MeterSettings"));
		
		return ptr;
	}

};


// Class AudioSynesthesia.MeterAnalyzer
// 0x00A8 (0x0138 - 0x0090)
class MeterAnalyzer : public AudioAnalyzer
{
public:
	class MeterSettings*                               Settings_69;                                              // 0x0090(0x0008) (Edit, BlueprintVisible, ZeroConstructor)
	unsigned char                                      UnknownData00[0x10];                                      // 0x0098(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty AudioSynesthesia.MeterAnalyzer.OnOverallMeterResults_69
	unsigned char                                      UnknownData01[0x18];                                      // 0x00A8(0x0018) MISSED OFFSET
	unsigned char                                      UnknownData02[0x10];                                      // 0x00A8(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty AudioSynesthesia.MeterAnalyzer.OnPerChannelMeterResults_69
	unsigned char                                      UnknownData03[0x18];                                      // 0x00D0(0x0018) MISSED OFFSET
	unsigned char                                      UnknownData04[0x10];                                      // 0x00D0(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty AudioSynesthesia.MeterAnalyzer.OnLatestOverallMeterResults_69
	unsigned char                                      UnknownData05[0x18];                                      // 0x00F8(0x0018) MISSED OFFSET
	unsigned char                                      UnknownData06[0x10];                                      // 0x00F8(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty AudioSynesthesia.MeterAnalyzer.OnLatestPerChannelMeterResults_69
	unsigned char                                      UnknownData07[0x18];                                      // 0x0120(0x0018) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AudioSynesthesia.MeterAnalyzer"));
		
		return ptr;
	}

};


// Class AudioSynesthesia.OnsetNRTSettings
// 0x0018 (0x0040 - 0x0028)
class OnsetNRTSettings : public AudioSynesthesiaNRTSettings
{
public:
	bool                                               bDownmixToMono_69;                                        // 0x0028(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0029(0x0003) MISSED OFFSET
	float                                              GranularityInSeconds_69;                                  // 0x002C(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              Sensitivity_69;                                           // 0x0030(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              MinimumFrequency_69;                                      // 0x0034(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              MaximumFrequency_69;                                      // 0x0038(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x4];                                       // 0x003C(0x0004) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AudioSynesthesia.OnsetNRTSettings"));
		
		return ptr;
	}

};


// Class AudioSynesthesia.OnsetNRT
// 0x0008 (0x0080 - 0x0078)
class OnsetNRT : public AudioSynesthesiaNRT
{
public:
	class OnsetNRTSettings*                            Settings_69;                                              // 0x0078(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AudioSynesthesia.OnsetNRT"));
		
		return ptr;
	}


	void GetNormalizedChannelOnsetsBetweenTimes(float InStartSeconds_69, float InEndSeconds_69, int InChannel_69, TArray<float>* OutOnsetTimestamps_69, TArray<float>* OutOnsetStrengths_69);
	void GetChannelOnsetsBetweenTimes(float InStartSeconds_69, float InEndSeconds_69, int InChannel_69, TArray<float>* OutOnsetTimestamps_69, TArray<float>* OutOnsetStrengths_69);
};


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

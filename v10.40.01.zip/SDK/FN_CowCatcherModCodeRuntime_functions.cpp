// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Functions
//---------------------------------------------------------------------------

// Function CowCatcherModCodeRuntime.CowCatcherBarricadeBase.OnPlacementBlockedByPawnChanged
// (Event, Protected, BlueprintEvent)
// Parameters:
// bool                           bBlockedByPawn_69              (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void CowCatcherBarricadeBase::OnPlacementBlockedByPawnChanged(bool bBlockedByPawn_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CowCatcherModCodeRuntime.CowCatcherBarricadeBase.OnPlacementBlockedByPawnChanged"));

	CowCatcherBarricadeBase_OnPlacementBlockedByPawnChanged_Params params;
	params.bBlockedByPawn_69 = bBlockedByPawn_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CowCatcherModCodeRuntime.CowCatcherBarricadeBase.BeginCheckingForTouchingPawns
// (Final, BlueprintAuthorityOnly, Native, Protected, BlueprintCallable)

void CowCatcherBarricadeBase::BeginCheckingForTouchingPawns()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CowCatcherModCodeRuntime.CowCatcherBarricadeBase.BeginCheckingForTouchingPawns"));

	CowCatcherBarricadeBase_BeginCheckingForTouchingPawns_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

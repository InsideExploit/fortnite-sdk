// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Functions
//---------------------------------------------------------------------------

// Function ClamberingCodeRuntime.ClamberingComponent.UnregisterMutatorUpdatedDelegate
// (Final, Native, Protected)

void ClamberingComponent::UnregisterMutatorUpdatedDelegate()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ClamberingCodeRuntime.ClamberingComponent.UnregisterMutatorUpdatedDelegate"));

	ClamberingComponent_UnregisterMutatorUpdatedDelegate_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ClamberingCodeRuntime.ClamberingComponent.ShouldShowClamberIndicator
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool ClamberingComponent::ShouldShowClamberIndicator()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ClamberingCodeRuntime.ClamberingComponent.ShouldShowClamberIndicator"));

	ClamberingComponent_ShouldShowClamberIndicator_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ClamberingCodeRuntime.ClamberingComponent.SetTutorialModeEnabled
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// bool                           bEnabled_69                    (Parm, ZeroConstructor, IsPlainOldData)

void ClamberingComponent::SetTutorialModeEnabled(bool bEnabled_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ClamberingCodeRuntime.ClamberingComponent.SetTutorialModeEnabled"));

	ClamberingComponent_SetTutorialModeEnabled_Params params;
	params.bEnabled_69 = bEnabled_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ClamberingCodeRuntime.ClamberingComponent.ServerStartClambering
// (Net, NetReliable, Native, Event, Protected, NetServer, NetValidate)
// Parameters:
// struct FReplicatedClamberingTargetingData InReplicatedTargetingData_69   (ConstParm, Parm)

void ClamberingComponent::ServerStartClambering(const struct FReplicatedClamberingTargetingData& InReplicatedTargetingData_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ClamberingCodeRuntime.ClamberingComponent.ServerStartClambering"));

	ClamberingComponent_ServerStartClambering_Params params;
	params.InReplicatedTargetingData_69 = InReplicatedTargetingData_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ClamberingCodeRuntime.ClamberingComponent.RegisterMutatorUpdatedDelegate
// (Final, Native, Protected)
// Parameters:
// class Pawn*                    AffectedPawn_69                (Parm, ZeroConstructor)

void ClamberingComponent::RegisterMutatorUpdatedDelegate(class Pawn* AffectedPawn_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ClamberingCodeRuntime.ClamberingComponent.RegisterMutatorUpdatedDelegate"));

	ClamberingComponent_RegisterMutatorUpdatedDelegate_Params params;
	params.AffectedPawn_69 = AffectedPawn_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ClamberingCodeRuntime.ClamberingComponent.OnRep_ReplicatedTargetingData
// (Final, Native, Protected)

void ClamberingComponent::OnRep_ReplicatedTargetingData()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ClamberingCodeRuntime.ClamberingComponent.OnRep_ReplicatedTargetingData"));

	ClamberingComponent_OnRep_ReplicatedTargetingData_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ClamberingCodeRuntime.ClamberingComponent.OnRep_ReplicatedClamberingState
// (Final, Native, Protected)

void ClamberingComponent::OnRep_ReplicatedClamberingState()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ClamberingCodeRuntime.ClamberingComponent.OnRep_ReplicatedClamberingState"));

	ClamberingComponent_OnRep_ReplicatedClamberingState_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ClamberingCodeRuntime.ClamberingComponent.OnPlayerStatePawnSet
// (Final, Native, Protected)
// Parameters:
// class PlayerState*             Player_69                      (Parm, ZeroConstructor)
// class Pawn*                    NewPawn_69                     (Parm, ZeroConstructor)
// class Pawn*                    OldPawn_69                     (Parm, ZeroConstructor)

void ClamberingComponent::OnPlayerStatePawnSet(class PlayerState* Player_69, class Pawn* NewPawn_69, class Pawn* OldPawn_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ClamberingCodeRuntime.ClamberingComponent.OnPlayerStatePawnSet"));

	ClamberingComponent_OnPlayerStatePawnSet_Params params;
	params.Player_69 = Player_69;
	params.NewPawn_69 = NewPawn_69;
	params.OldPawn_69 = OldPawn_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ClamberingCodeRuntime.ClamberingComponent.OnMutatorUpdated
// (Final, Native, Protected)

void ClamberingComponent::OnMutatorUpdated()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ClamberingCodeRuntime.ClamberingComponent.OnMutatorUpdated"));

	ClamberingComponent_OnMutatorUpdated_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ClamberingCodeRuntime.ClamberingComponent.NetMulticast_ClamberingLedgeFailed
// (Net, NetReliable, Native, Event, NetMulticast, Protected)
// Parameters:
// EClamberingFailedReason        FailedReason_69                (Parm, ZeroConstructor, IsPlainOldData)
// EClamberingState               FailedState_69                 (Parm, ZeroConstructor, IsPlainOldData)

void ClamberingComponent::NetMulticast_ClamberingLedgeFailed(EClamberingFailedReason FailedReason_69, EClamberingState FailedState_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ClamberingCodeRuntime.ClamberingComponent.NetMulticast_ClamberingLedgeFailed"));

	ClamberingComponent_NetMulticast_ClamberingLedgeFailed_Params params;
	params.FailedReason_69 = FailedReason_69;
	params.FailedState_69 = FailedState_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ClamberingCodeRuntime.ClamberingComponent.IsTutorialModeEnabled
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool ClamberingComponent::IsTutorialModeEnabled()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ClamberingCodeRuntime.ClamberingComponent.IsTutorialModeEnabled"));

	ClamberingComponent_IsTutorialModeEnabled_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ClamberingCodeRuntime.ClamberingComponent.IsClamberingEnabled
// (Final, Native, Protected, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool ClamberingComponent::IsClamberingEnabled()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ClamberingCodeRuntime.ClamberingComponent.IsClamberingEnabled"));

	ClamberingComponent_IsClamberingEnabled_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ClamberingCodeRuntime.ClamberingComponent.IsAutoClamberingEnabled
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool ClamberingComponent::IsAutoClamberingEnabled()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ClamberingCodeRuntime.ClamberingComponent.IsAutoClamberingEnabled"));

	ClamberingComponent_IsAutoClamberingEnabled_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ClamberingCodeRuntime.ClamberingComponent.HandleTargetingDataValid
// (Event, Protected, HasOutParms, BlueprintEvent)
// Parameters:
// struct FClamberingTargetingData TargetingData_69               (ConstParm, Parm, OutParm, ReferenceParm)

void ClamberingComponent::HandleTargetingDataValid(const struct FClamberingTargetingData& TargetingData_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ClamberingCodeRuntime.ClamberingComponent.HandleTargetingDataValid"));

	ClamberingComponent_HandleTargetingDataValid_Params params;
	params.TargetingData_69 = TargetingData_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ClamberingCodeRuntime.ClamberingComponent.HandleTargetingDataInvalid
// (Event, Protected, BlueprintEvent)

void ClamberingComponent::HandleTargetingDataInvalid()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ClamberingCodeRuntime.ClamberingComponent.HandleTargetingDataInvalid"));

	ClamberingComponent_HandleTargetingDataInvalid_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ClamberingCodeRuntime.ClamberingComponent.HandleTargetActorHealthChanged
// (Final, Native, Protected)

void ClamberingComponent::HandleTargetActorHealthChanged()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ClamberingCodeRuntime.ClamberingComponent.HandleTargetActorHealthChanged"));

	ClamberingComponent_HandleTargetActorHealthChanged_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ClamberingCodeRuntime.ClamberingComponent.HandleTargetActorDestroyed
// (Final, Native, Protected)
// Parameters:
// class Actor_32759*             Actor_69                       (Parm, ZeroConstructor)

void ClamberingComponent::HandleTargetActorDestroyed(class Actor_32759* Actor_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ClamberingCodeRuntime.ClamberingComponent.HandleTargetActorDestroyed"));

	ClamberingComponent_HandleTargetActorDestroyed_Params params;
	params.Actor_69 = Actor_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ClamberingCodeRuntime.ClamberingComponent.HandleOwnerMovementModeChanged
// (Final, Native, Protected)
// Parameters:
// class Character*               Character_69                   (Parm, ZeroConstructor)
// TEnumAsByte<EMovementMode>     PreviousMovementMode_69        (Parm, ZeroConstructor, IsPlainOldData)
// unsigned char                  PreviousCustomMode_69          (Parm, ZeroConstructor, IsPlainOldData)

void ClamberingComponent::HandleOwnerMovementModeChanged(class Character* Character_69, TEnumAsByte<EMovementMode> PreviousMovementMode_69, unsigned char PreviousCustomMode_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ClamberingCodeRuntime.ClamberingComponent.HandleOwnerMovementModeChanged"));

	ClamberingComponent_HandleOwnerMovementModeChanged_Params params;
	params.Character_69 = Character_69;
	params.PreviousMovementMode_69 = PreviousMovementMode_69;
	params.PreviousCustomMode_69 = PreviousCustomMode_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ClamberingCodeRuntime.ClamberingComponent.HandleOwnerJumpInput
// (Final, Native, Protected)
// Parameters:
// bool                           bPressed_69                    (Parm, ZeroConstructor, IsPlainOldData)

void ClamberingComponent::HandleOwnerJumpInput(bool bPressed_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ClamberingCodeRuntime.ClamberingComponent.HandleOwnerJumpInput"));

	ClamberingComponent_HandleOwnerJumpInput_Params params;
	params.bPressed_69 = bPressed_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ClamberingCodeRuntime.ClamberingComponent.HandleOwnerDied
// (Final, Native, Protected)
// Parameters:
// class FortPawn*                DeadPawn_69                    (Parm, ZeroConstructor)

void ClamberingComponent::HandleOwnerDied(class FortPawn* DeadPawn_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ClamberingCodeRuntime.ClamberingComponent.HandleOwnerDied"));

	ClamberingComponent_HandleOwnerDied_Params params;
	params.DeadPawn_69 = DeadPawn_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ClamberingCodeRuntime.ClamberingComponent.HandleOwnerDBNO
// (Final, Native, Protected)

void ClamberingComponent::HandleOwnerDBNO()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ClamberingCodeRuntime.ClamberingComponent.HandleOwnerDBNO"));

	ClamberingComponent_HandleOwnerDBNO_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ClamberingCodeRuntime.ClamberingComponent.HandleOwnerASCInvalidated
// (Final, Native, Protected)

void ClamberingComponent::HandleOwnerASCInvalidated()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ClamberingCodeRuntime.ClamberingComponent.HandleOwnerASCInvalidated"));

	ClamberingComponent_HandleOwnerASCInvalidated_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ClamberingCodeRuntime.ClamberingComponent.HandleOwnerASCInitialized
// (Final, Native, Protected)
// Parameters:
// class FortAbilitySystemComponent* AbilitySystemComponent_69      (Parm, ZeroConstructor, InstancedReference)
// class FortPlayerPawn*          AffectedPawn_69                (Parm, ZeroConstructor)

void ClamberingComponent::HandleOwnerASCInitialized(class FortAbilitySystemComponent* AbilitySystemComponent_69, class FortPlayerPawn* AffectedPawn_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ClamberingCodeRuntime.ClamberingComponent.HandleOwnerASCInitialized"));

	ClamberingComponent_HandleOwnerASCInitialized_Params params;
	params.AbilitySystemComponent_69 = AbilitySystemComponent_69;
	params.AffectedPawn_69 = AffectedPawn_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ClamberingCodeRuntime.ClamberingComponent.HandleClamberingTargetOutOfActivationRange
// (Event, Protected, BlueprintEvent)

void ClamberingComponent::HandleClamberingTargetOutOfActivationRange()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ClamberingCodeRuntime.ClamberingComponent.HandleClamberingTargetOutOfActivationRange"));

	ClamberingComponent_HandleClamberingTargetOutOfActivationRange_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ClamberingCodeRuntime.ClamberingComponent.HandleClamberingTargetInActivationRange
// (Event, Protected, BlueprintEvent)

void ClamberingComponent::HandleClamberingTargetInActivationRange()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ClamberingCodeRuntime.ClamberingComponent.HandleClamberingTargetInActivationRange"));

	ClamberingComponent_HandleClamberingTargetInActivationRange_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ClamberingCodeRuntime.ClamberingComponent.DrawDebugHUD
// (Final, Native, Protected)
// Parameters:
// class HUD_32759*               HUD_69                         (Parm, ZeroConstructor)
// class Canvas*                  Canvas_69                      (Parm, ZeroConstructor)

void ClamberingComponent::DrawDebugHUD(class HUD_32759* HUD_69, class Canvas* Canvas_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ClamberingCodeRuntime.ClamberingComponent.DrawDebugHUD"));

	ClamberingComponent_DrawDebugHUD_Params params;
	params.HUD_69 = HUD_69;
	params.Canvas_69 = Canvas_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ClamberingCodeRuntime.ClamberingComponent.BP_TutorialModeEnabled
// (Event, Protected, BlueprintEvent, Const)

void ClamberingComponent::BP_TutorialModeEnabled()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ClamberingCodeRuntime.ClamberingComponent.BP_TutorialModeEnabled"));

	ClamberingComponent_BP_TutorialModeEnabled_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ClamberingCodeRuntime.ClamberingComponent.BP_TutorialModeDisabled
// (Event, Protected, BlueprintEvent, Const)

void ClamberingComponent::BP_TutorialModeDisabled()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ClamberingCodeRuntime.ClamberingComponent.BP_TutorialModeDisabled"));

	ClamberingComponent_BP_TutorialModeDisabled_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ClamberingCodeRuntime.ClamberingComponent.BP_IsValidTargetActor
// (Event, Protected, HasOutParms, BlueprintEvent, Const)
// Parameters:
// class Actor_32759*             TargetActor_69                 (ConstParm, Parm, ZeroConstructor)
// bool                           bIsValidTargetActor_69         (Parm, OutParm, ZeroConstructor, IsPlainOldData)

void ClamberingComponent::BP_IsValidTargetActor(class Actor_32759* TargetActor_69, bool* bIsValidTargetActor_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ClamberingCodeRuntime.ClamberingComponent.BP_IsValidTargetActor"));

	ClamberingComponent_BP_IsValidTargetActor_Params params;
	params.TargetActor_69 = TargetActor_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (bIsValidTargetActor_69 != nullptr)
		*bIsValidTargetActor_69 = params.bIsValidTargetActor_69;
}


// Function ClamberingCodeRuntime.ClamberingComponent.BP_HandleSynchedActionStarted
// (Event, Protected, HasOutParms, BlueprintEvent)
// Parameters:
// struct FSynchedActionInfo      SynchedActionInfo_69           (ConstParm, Parm, OutParm, ReferenceParm)

void ClamberingComponent::BP_HandleSynchedActionStarted(const struct FSynchedActionInfo& SynchedActionInfo_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ClamberingCodeRuntime.ClamberingComponent.BP_HandleSynchedActionStarted"));

	ClamberingComponent_BP_HandleSynchedActionStarted_Params params;
	params.SynchedActionInfo_69 = SynchedActionInfo_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ClamberingCodeRuntime.ClamberingComponent.BP_HandleClamberingStateChanged
// (Event, Protected, BlueprintEvent)
// Parameters:
// EClamberingState               OldClamberingState_69          (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// EClamberingState               NewClamberingState_69          (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void ClamberingComponent::BP_HandleClamberingStateChanged(EClamberingState OldClamberingState_69, EClamberingState NewClamberingState_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ClamberingCodeRuntime.ClamberingComponent.BP_HandleClamberingStateChanged"));

	ClamberingComponent_BP_HandleClamberingStateChanged_Params params;
	params.OldClamberingState_69 = OldClamberingState_69;
	params.NewClamberingState_69 = NewClamberingState_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ClamberingCodeRuntime.ClamberingComponent.BP_CanStartTargeting
// (Event, Protected, HasOutParms, BlueprintEvent, Const)
// Parameters:
// bool                           bCanStartTargeting_69          (Parm, OutParm, ZeroConstructor, IsPlainOldData)

void ClamberingComponent::BP_CanStartTargeting(bool* bCanStartTargeting_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ClamberingCodeRuntime.ClamberingComponent.BP_CanStartTargeting"));

	ClamberingComponent_BP_CanStartTargeting_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (bCanStartTargeting_69 != nullptr)
		*bCanStartTargeting_69 = params.bCanStartTargeting_69;
}


// Function ClamberingCodeRuntime.ClamberingComponent.BP_CanStartClambering
// (Event, Protected, HasOutParms, BlueprintEvent, Const)
// Parameters:
// bool                           bCanStartClambering_69         (Parm, OutParm, ZeroConstructor, IsPlainOldData)

void ClamberingComponent::BP_CanStartClambering(bool* bCanStartClambering_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ClamberingCodeRuntime.ClamberingComponent.BP_CanStartClambering"));

	ClamberingComponent_BP_CanStartClambering_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (bCanStartClambering_69 != nullptr)
		*bCanStartClambering_69 = params.bCanStartClambering_69;
}


// Function ClamberingCodeRuntime.ClamberingLibrary.PerformClamberingTargeting
// (Final, Native, Static, Public, HasOutParms, BlueprintCallable)
// Parameters:
// class Character*               Character_69                   (ConstParm, Parm, ZeroConstructor)
// struct FClamberingTargetingData OutTargetingData_69            (Parm, OutParm)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool ClamberingLibrary::STATIC_PerformClamberingTargeting(class Character* Character_69, struct FClamberingTargetingData* OutTargetingData_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ClamberingCodeRuntime.ClamberingLibrary.PerformClamberingTargeting"));

	ClamberingLibrary_PerformClamberingTargeting_Params params;
	params.Character_69 = Character_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (OutTargetingData_69 != nullptr)
		*OutTargetingData_69 = params.OutTargetingData_69;

	return params.ReturnValue_69;
}


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

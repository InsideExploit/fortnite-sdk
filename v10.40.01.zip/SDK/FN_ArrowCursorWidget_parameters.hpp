#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function ArrowCursorWidget.ArrowCursorWidget_C.GetBackground_0
struct ArrowCursorWidget_C_GetBackground_0_Params
{
	struct FSlateBrush                                 ReturnValue_1;                                            // (Parm, OutParm, ReturnParm)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function CreativeVideoPlayerRuntime.CreativeVideoPlayerFullscreenGameplayAbility.ServerLeaveFullscreenMode
struct CreativeVideoPlayerFullscreenGameplayAbility_ServerLeaveFullscreenMode_Params
{
};

// Function CreativeVideoPlayerRuntime.CreativeVideoPlayerFullscreenGameplayAbility.ServerEnterFullscreenMode
struct CreativeVideoPlayerFullscreenGameplayAbility_ServerEnterFullscreenMode_Params
{
};

// Function CreativeVideoPlayerRuntime.CreativeVideoPlayerFullscreenGameplayAbility.OnFullscreenUIEnds
struct CreativeVideoPlayerFullscreenGameplayAbility_OnFullscreenUIEnds_Params
{
};

// Function CreativeVideoPlayerRuntime.CreativeVideoPlayerFullscreenGameplayAbility.HandleEnterFullscreenActionReleased
struct CreativeVideoPlayerFullscreenGameplayAbility_HandleEnterFullscreenActionReleased_Params
{
};

// Function CreativeVideoPlayerRuntime.CreativeVideoPlayerFullscreenGameplayAbility.HandleEnterFullscreenActionPressed
struct CreativeVideoPlayerFullscreenGameplayAbility_HandleEnterFullscreenActionPressed_Params
{
};

// Function CreativeVideoPlayerRuntime.CreativeVideoPlayerFullscreenGameplayAbility.ExitFullscreenState
struct CreativeVideoPlayerFullscreenGameplayAbility_ExitFullscreenState_Params
{
};

// Function CreativeVideoPlayerRuntime.CreativeVideoPlayerFullscreenGameplayAbility.EnterFullscreenStateWithOptions
struct CreativeVideoPlayerFullscreenGameplayAbility_EnterFullscreenStateWithOptions_Params
{
	struct FCreativeVideoPlayerFullscreenOptions       Options_69;                                               // (Parm)
};

// Function CreativeVideoPlayerRuntime.CreativeVideoPlayerFullscreenGameplayAbility.EnterFullscreenState
struct CreativeVideoPlayerFullscreenGameplayAbility_EnterFullscreenState_Params
{
};

// Function CreativeVideoPlayerRuntime.CreativeVideoPlayerFullscreenGameplayAbility.ClientTransitionToFullscreenVideo
struct CreativeVideoPlayerFullscreenGameplayAbility_ClientTransitionToFullscreenVideo_Params
{
};

// Function CreativeVideoPlayerRuntime.CreativeVideoPlayerFullscreenGameplayAbility.ClientLeaveFullscreenVideo
struct CreativeVideoPlayerFullscreenGameplayAbility_ClientLeaveFullscreenVideo_Params
{
};

// Function CreativeVideoPlayerRuntime.CreativeVideoPlayerFunctionLibrary.ShutdownFullscreenVideoMode
struct CreativeVideoPlayerFunctionLibrary_ShutdownFullscreenVideoMode_Params
{
	class Controller*                                  Controller_69;                                            // (Parm, ZeroConstructor)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

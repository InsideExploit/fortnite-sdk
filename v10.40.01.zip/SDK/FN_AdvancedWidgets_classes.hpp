#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Classes
//---------------------------------------------------------------------------

// Class AdvancedWidgets.RadialSlider
// 0x0628 (0x0770 - 0x0148)
class RadialSlider : public Widget
{
public:
	float                                              Value_69;                                                 // 0x0148(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FScriptDelegate                             ValueDelegate_69;                                         // 0x014C(0x0010) (ZeroConstructor, InstancedReference)
	bool                                               bUseCustomDefaultValue_69;                                // 0x0158(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0159(0x0003) MISSED OFFSET
	float                                              CustomDefaultValue_69;                                    // 0x015C(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	struct FRuntimeFloatCurve                          SliderRange_69;                                           // 0x0160(0x0088) (Edit, BlueprintVisible, BlueprintReadOnly)
	TArray<float>                                      ValueTags_69;                                             // 0x01E8(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
	float                                              SliderHandleStartAngle_69;                                // 0x01F8(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              SliderHandleEndAngle_69;                                  // 0x01FC(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              AngularOffset_69;                                         // 0x0200(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x4];                                       // 0x0204(0x0004) MISSED OFFSET
	struct FVector2D                                   HandStartEndRatio_69;                                     // 0x0208(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData02[0x8];                                       // 0x0218(0x0008) MISSED OFFSET
	struct FSliderStyle                                WidgetStyle_69;                                           // 0x0220(0x04A0) (Edit, BlueprintVisible)
	struct FLinearColor                                SliderBarColor_69;                                        // 0x06C0(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	struct FLinearColor                                SliderProgressColor_69;                                   // 0x06D0(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	struct FLinearColor                                SliderHandleColor_69;                                     // 0x06E0(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	struct FLinearColor                                CenterBackgroundColor_69;                                 // 0x06F0(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	bool                                               Locked_69;                                                // 0x0700(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	bool                                               MouseUsesStep_69;                                         // 0x0701(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	bool                                               RequiresControllerLock_69;                                // 0x0702(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData03[0x1];                                       // 0x0703(0x0001) MISSED OFFSET
	float                                              StepSize_69;                                              // 0x0704(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	bool                                               IsFocusable_69;                                           // 0x0708(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	bool                                               UseVerticalDrag_69;                                       // 0x0709(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               ShowSliderHandle_69;                                      // 0x070A(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               ShowSliderHand_69;                                        // 0x070B(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData04[0x4];                                       // 0x070C(0x0004) MISSED OFFSET
	unsigned char                                      UnknownData05[0x10];                                      // 0x070C(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty AdvancedWidgets.RadialSlider.OnMouseCaptureBegin_69
	unsigned char                                      UnknownData06[0x10];                                      // 0x0720(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty AdvancedWidgets.RadialSlider.OnMouseCaptureEnd_69
	unsigned char                                      UnknownData07[0x10];                                      // 0x0730(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty AdvancedWidgets.RadialSlider.OnControllerCaptureBegin_69
	unsigned char                                      UnknownData08[0x10];                                      // 0x0740(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty AdvancedWidgets.RadialSlider.OnControllerCaptureEnd_69
	unsigned char                                      UnknownData09[0x10];                                      // 0x0750(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty AdvancedWidgets.RadialSlider.OnValueChanged_69
	unsigned char                                      UnknownData10[0x10];                                      // 0x0760(0x0010) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AdvancedWidgets.RadialSlider"));
		
		return ptr;
	}


	void SetValueTags(TArray<float> InValueTags_69);
	void SetValue(float InValue_69);
	void SetUseVerticalDrag(bool InUseVerticalDrag_69);
	void SetStepSize(float InValue_69);
	void SetSliderRange(const struct FRuntimeFloatCurve& InSliderRange_69);
	void SetSliderProgressColor(const struct FLinearColor& InValue_69);
	void SetSliderHandleStartAngle(float InValue_69);
	void SetSliderHandleEndAngle(float InValue_69);
	void SetSliderHandleColor(const struct FLinearColor& InValue_69);
	void SetSliderBarColor(const struct FLinearColor& InValue_69);
	void SetShowSliderHandle(bool InShowSliderHandle_69);
	void SetShowSliderHand(bool InShowSliderHand_69);
	void SetLocked(bool InValue_69);
	void SetHandStartEndRatio(const struct FVector2D& InValue_69);
	void SetCustomDefaultValue(float InValue_69);
	void SetCenterBackgroundColor(const struct FLinearColor& InValue_69);
	void SetAngularOffset(float InValue_69);
	float GetValue();
	float GetNormalizedSliderHandlePosition();
	float GetCustomDefaultValue();
};


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function CommonUILegacy.CommonActivatablePanelLegacy.SetInputActionHandlerWithProgressPopupMenu
struct CommonActivatablePanelLegacy_SetInputActionHandlerWithProgressPopupMenu_Params
{
	struct FDataTableRowHandle                         InputActionRow_69;                                        // (Parm)
	struct FScriptDelegate                             CommitedEvent_69;                                         // (Parm, ZeroConstructor)
	struct FScriptDelegate                             ProgressEvent_69;                                         // (Parm, ZeroConstructor)
	class CommonPopupMenuLegacy*                       PopupMenu_69;                                             // (Parm, ZeroConstructor, InstancedReference)
};

// Function CommonUILegacy.CommonActivatablePanelLegacy.SetInputActionHandlerWithProgress
struct CommonActivatablePanelLegacy_SetInputActionHandlerWithProgress_Params
{
	struct FDataTableRowHandle                         InputActionRow_69;                                        // (Parm)
	struct FScriptDelegate                             CommitedEvent_69;                                         // (Parm, ZeroConstructor)
	struct FScriptDelegate                             ProgressEvent_69;                                         // (Parm, ZeroConstructor)
};

// Function CommonUILegacy.CommonActivatablePanelLegacy.SetInputActionHandlerWithPopupMenu
struct CommonActivatablePanelLegacy_SetInputActionHandlerWithPopupMenu_Params
{
	struct FDataTableRowHandle                         InputActionRow_69;                                        // (Parm)
	struct FScriptDelegate                             CommitedEvent_69;                                         // (Parm, ZeroConstructor)
	class CommonPopupMenuLegacy*                       PopupMenu_69;                                             // (Parm, ZeroConstructor, InstancedReference)
};

// Function CommonUILegacy.CommonActivatablePanelLegacy.SetInputActionHandler
struct CommonActivatablePanelLegacy_SetInputActionHandler_Params
{
	struct FDataTableRowHandle                         InputActionRow_69;                                        // (Parm)
	struct FScriptDelegate                             CommitedEvent_69;                                         // (Parm, ZeroConstructor)
};

// Function CommonUILegacy.CommonActivatablePanelLegacy.SetActionHandlerStateWithDisabledCommitEvent
struct CommonActivatablePanelLegacy_SetActionHandlerStateWithDisabledCommitEvent_Params
{
	class DataTable*                                   DataTable_69;                                             // (Parm, ZeroConstructor)
	struct FName                                       RowName_69;                                               // (Parm, ZeroConstructor, IsPlainOldData)
	EInputActionState                                  State_69;                                                 // (Parm, ZeroConstructor, IsPlainOldData)
	struct FScriptDelegate                             DisabledCommitEvent_69;                                   // (Parm, ZeroConstructor)
};

// Function CommonUILegacy.CommonActivatablePanelLegacy.SetActionHandlerStateFromHandleWithDisabledCommitEvent
struct CommonActivatablePanelLegacy_SetActionHandlerStateFromHandleWithDisabledCommitEvent_Params
{
	struct FDataTableRowHandle                         InputActionRow_69;                                        // (Parm)
	EInputActionState                                  State_69;                                                 // (Parm, ZeroConstructor, IsPlainOldData)
	struct FScriptDelegate                             DisabledCommitEvent_69;                                   // (Parm, ZeroConstructor)
};

// Function CommonUILegacy.CommonActivatablePanelLegacy.SetActionHandlerStateFromHandle
struct CommonActivatablePanelLegacy_SetActionHandlerStateFromHandle_Params
{
	struct FDataTableRowHandle                         InputActionRow_69;                                        // (Parm)
	EInputActionState                                  State_69;                                                 // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function CommonUILegacy.CommonActivatablePanelLegacy.SetActionHandlerState
struct CommonActivatablePanelLegacy_SetActionHandlerState_Params
{
	class DataTable*                                   DataTable_69;                                             // (ConstParm, Parm, ZeroConstructor)
	struct FName                                       RowName_69;                                               // (Parm, ZeroConstructor, IsPlainOldData)
	EInputActionState                                  State_69;                                                 // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function CommonUILegacy.CommonActivatablePanelLegacy.RemoveInputActionHandler
struct CommonActivatablePanelLegacy_RemoveInputActionHandler_Params
{
	struct FDataTableRowHandle                         InputActionRow_69;                                        // (Parm)
};

// Function CommonUILegacy.CommonActivatablePanelLegacy.RemoveAllInputActionHandlers
struct CommonActivatablePanelLegacy_RemoveAllInputActionHandlers_Params
{
};

// Function CommonUILegacy.CommonActivatablePanelLegacy.PopPanel
struct CommonActivatablePanelLegacy_PopPanel_Params
{
};

// Function CommonUILegacy.CommonActivatablePanelLegacy.OnTransitionedBySwitcher
struct CommonActivatablePanelLegacy_OnTransitionedBySwitcher_Params
{
};

// Function CommonUILegacy.CommonActivatablePanelLegacy.OnRemovedFromActivationStack
struct CommonActivatablePanelLegacy_OnRemovedFromActivationStack_Params
{
};

// Function CommonUILegacy.CommonActivatablePanelLegacy.OnInputModeChanged
struct CommonActivatablePanelLegacy_OnInputModeChanged_Params
{
	bool                                               bUsingGamepad_69;                                         // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function CommonUILegacy.CommonActivatablePanelLegacy.OnBeginOutro
struct CommonActivatablePanelLegacy_OnBeginOutro_Params
{
};

// Function CommonUILegacy.CommonActivatablePanelLegacy.OnBeginIntro
struct CommonActivatablePanelLegacy_OnBeginIntro_Params
{
};

// Function CommonUILegacy.CommonActivatablePanelLegacy.OnAddedToActivationStack
struct CommonActivatablePanelLegacy_OnAddedToActivationStack_Params
{
};

// Function CommonUILegacy.CommonActivatablePanelLegacy.IsIntroed
struct CommonActivatablePanelLegacy_IsIntroed_Params
{
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CommonUILegacy.CommonActivatablePanelLegacy.IsInActivationStack
struct CommonActivatablePanelLegacy_IsInActivationStack_Params
{
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CommonUILegacy.CommonActivatablePanelLegacy.HasInputActionHandler
struct CommonActivatablePanelLegacy_HasInputActionHandler_Params
{
	struct FDataTableRowHandle                         InputActionRow_69;                                        // (Parm)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CommonUILegacy.CommonActivatablePanelLegacy.GetInputActions
struct CommonActivatablePanelLegacy_GetInputActions_Params
{
	TArray<struct FCommonInputActionHandlerData>       InputActionDataRows_69;                                   // (Parm, OutParm, ZeroConstructor)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CommonUILegacy.CommonActivatablePanelLegacy.EndOutro
struct CommonActivatablePanelLegacy_EndOutro_Params
{
};

// Function CommonUILegacy.CommonActivatablePanelLegacy.EndIntro
struct CommonActivatablePanelLegacy_EndIntro_Params
{
};

// Function CommonUILegacy.CommonActivatablePanelLegacy.BeginOutro
struct CommonActivatablePanelLegacy_BeginOutro_Params
{
};

// Function CommonUILegacy.CommonActivatablePanelLegacy.BeginIntro
struct CommonActivatablePanelLegacy_BeginIntro_Params
{
};

// Function CommonUILegacy.CommonActivatablePanelLegacy.AddInputActionNoHandler
struct CommonActivatablePanelLegacy_AddInputActionNoHandler_Params
{
	class DataTable*                                   DataTable_69;                                             // (Parm, ZeroConstructor)
	struct FName                                       RowName_69;                                               // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function CommonUILegacy.CommonActivatablePanelLegacy.AddInputActionHandlerWithProgressPopup
struct CommonActivatablePanelLegacy_AddInputActionHandlerWithProgressPopup_Params
{
	class DataTable*                                   DataTable_69;                                             // (Parm, ZeroConstructor)
	struct FName                                       RowName_69;                                               // (Parm, ZeroConstructor, IsPlainOldData)
	struct FScriptDelegate                             CommitedEvent_69;                                         // (Parm, ZeroConstructor)
	struct FScriptDelegate                             ProgressEvent_69;                                         // (Parm, ZeroConstructor)
	class CommonPopupMenuLegacy*                       PopupMenu_69;                                             // (Parm, ZeroConstructor, InstancedReference)
};

// Function CommonUILegacy.CommonActivatablePanelLegacy.AddInputActionHandlerWithProgress
struct CommonActivatablePanelLegacy_AddInputActionHandlerWithProgress_Params
{
	class DataTable*                                   DataTable_69;                                             // (Parm, ZeroConstructor)
	struct FName                                       RowName_69;                                               // (Parm, ZeroConstructor, IsPlainOldData)
	struct FScriptDelegate                             CommitedEvent_69;                                         // (Parm, ZeroConstructor)
	struct FScriptDelegate                             ProgressEvent_69;                                         // (Parm, ZeroConstructor)
};

// Function CommonUILegacy.CommonActivatablePanelLegacy.AddInputActionHandlerWithPopup
struct CommonActivatablePanelLegacy_AddInputActionHandlerWithPopup_Params
{
	class DataTable*                                   DataTable_69;                                             // (Parm, ZeroConstructor)
	struct FName                                       RowName_69;                                               // (Parm, ZeroConstructor, IsPlainOldData)
	struct FScriptDelegate                             CommitedEvent_69;                                         // (Parm, ZeroConstructor)
	class CommonPopupMenuLegacy*                       PopupMenu_69;                                             // (Parm, ZeroConstructor, InstancedReference)
};

// Function CommonUILegacy.CommonActivatablePanelLegacy.AddInputActionHandler
struct CommonActivatablePanelLegacy_AddInputActionHandler_Params
{
	class DataTable*                                   DataTable_69;                                             // (Parm, ZeroConstructor)
	struct FName                                       RowName_69;                                               // (Parm, ZeroConstructor, IsPlainOldData)
	struct FScriptDelegate                             CommitedEvent_69;                                         // (Parm, ZeroConstructor)
};

// Function CommonUILegacy.CommonButtonGroupLegacy.OnSelectionStateChanged
struct CommonButtonGroupLegacy_OnSelectionStateChanged_Params
{
	class CommonButtonLegacy*                          BaseButton_69;                                            // (Parm, ZeroConstructor, InstancedReference)
	bool                                               bIsSelected_69;                                           // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function CommonUILegacy.CommonButtonGroupLegacy.OnHandleButtonDoubleClicked
struct CommonButtonGroupLegacy_OnHandleButtonDoubleClicked_Params
{
	class CommonButtonLegacy*                          BaseButton_69;                                            // (Parm, ZeroConstructor, InstancedReference)
};

// Function CommonUILegacy.CommonButtonGroupLegacy.OnHandleButtonClicked
struct CommonButtonGroupLegacy_OnHandleButtonClicked_Params
{
	class CommonButtonLegacy*                          BaseButton_69;                                            // (Parm, ZeroConstructor, InstancedReference)
};

// Function CommonUILegacy.CommonButtonGroupLegacy.OnButtonUnhovered
struct CommonButtonGroupLegacy_OnButtonUnhovered_Params
{
	class CommonButtonLegacy*                          BaseButton_69;                                            // (Parm, ZeroConstructor, InstancedReference)
};

// Function CommonUILegacy.CommonButtonGroupLegacy.OnButtonHovered
struct CommonButtonGroupLegacy_OnButtonHovered_Params
{
	class CommonButtonLegacy*                          BaseButton_69;                                            // (Parm, ZeroConstructor, InstancedReference)
};

// Function CommonUILegacy.CommonButtonGroupLegacy.HandleOnSelectedButtonChanged
struct CommonButtonGroupLegacy_HandleOnSelectedButtonChanged_Params
{
	class CommonButtonBase*                            BaseButton_69;                                            // (Parm, ZeroConstructor, InstancedReference)
	int                                                InSelectedButtonIndex_69;                                 // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function CommonUILegacy.CommonButtonGroupLegacy.HandleOnHoveredButtonChanged
struct CommonButtonGroupLegacy_HandleOnHoveredButtonChanged_Params
{
	class CommonButtonBase*                            BaseButton_69;                                            // (Parm, ZeroConstructor, InstancedReference)
	int                                                InSelectedButtonIndex_69;                                 // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function CommonUILegacy.CommonButtonGroupLegacy.HandleOnButtonDoubleClicked
struct CommonButtonGroupLegacy_HandleOnButtonDoubleClicked_Params
{
	class CommonButtonBase*                            BaseButton_69;                                            // (Parm, ZeroConstructor, InstancedReference)
	int                                                InSelectedButtonIndex_69;                                 // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function CommonUILegacy.CommonButtonGroupLegacy.HandleOnButtonClicked
struct CommonButtonGroupLegacy_HandleOnButtonClicked_Params
{
	class CommonButtonBase*                            BaseButton_69;                                            // (Parm, ZeroConstructor, InstancedReference)
	int                                                InSelectedButtonIndex_69;                                 // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function CommonUILegacy.CommonButtonGroupLegacy.HandleNativeOnSelectedButtonChanged
struct CommonButtonGroupLegacy_HandleNativeOnSelectedButtonChanged_Params
{
	class CommonButtonBase*                            BaseButton_69;                                            // (Parm, ZeroConstructor, InstancedReference)
	int                                                InSelectedButtonIndex_69;                                 // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function CommonUILegacy.CommonButtonGroupLegacy.HandleNativeOnHoveredButtonChanged
struct CommonButtonGroupLegacy_HandleNativeOnHoveredButtonChanged_Params
{
	class CommonButtonBase*                            BaseButton_69;                                            // (Parm, ZeroConstructor, InstancedReference)
	int                                                InSelectedButtonIndex_69;                                 // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function CommonUILegacy.CommonButtonGroupLegacy.HandleNativeOnButtonDoubleClicked
struct CommonButtonGroupLegacy_HandleNativeOnButtonDoubleClicked_Params
{
	class CommonButtonBase*                            BaseButton_69;                                            // (Parm, ZeroConstructor, InstancedReference)
	int                                                InSelectedButtonIndex_69;                                 // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function CommonUILegacy.CommonButtonGroupLegacy.HandleNativeOnButtonClicked
struct CommonButtonGroupLegacy_HandleNativeOnButtonClicked_Params
{
	class CommonButtonBase*                            BaseButton_69;                                            // (Parm, ZeroConstructor, InstancedReference)
	int                                                InSelectedButtonIndex_69;                                 // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function CommonUILegacy.CommonButtonGroupLegacy.GetSelectedButton
struct CommonButtonGroupLegacy_GetSelectedButton_Params
{
	class CommonButtonLegacy*                          ReturnValue_69;                                           // (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)
};

// Function CommonUILegacy.CommonButtonGroupLegacy.GetButtonAtIndex
struct CommonButtonGroupLegacy_GetButtonAtIndex_Params
{
	int                                                Index_69;                                                 // (Parm, ZeroConstructor, IsPlainOldData)
	class CommonButtonLegacy*                          ReturnValue_69;                                           // (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)
};

// Function CommonUILegacy.CommonButtonGroupLegacy.CreateButtonGroup
struct CommonButtonGroupLegacy_CreateButtonGroup_Params
{
	class Object_32759*                                ContextObject_69;                                         // (Parm, ZeroConstructor)
	bool                                               bInSelectionRequired_69;                                  // (Parm, ZeroConstructor, IsPlainOldData)
	class CommonButtonGroupLegacy*                     ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function CommonUILegacy.CommonButtonLegacy.SetTriggeredInputActionLegacy
struct CommonButtonLegacy_SetTriggeredInputActionLegacy_Params
{
	struct FDataTableRowHandle                         InputActionRow_69;                                        // (ConstParm, Parm, OutParm, ReferenceParm)
	class CommonActivatablePanelLegacy*                OldPanel_69;                                              // (Parm, ZeroConstructor, InstancedReference)
};

// Function CommonUILegacy.CommonButtonLegacy.HandleOnSelectedChanged
struct CommonButtonLegacy_HandleOnSelectedChanged_Params
{
	class CommonButtonBase*                            Button_69;                                                // (Parm, ZeroConstructor, InstancedReference)
	bool                                               InSelected_69;                                            // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function CommonUILegacy.CommonButtonLegacy.HandleOnButtonUnhovered
struct CommonButtonLegacy_HandleOnButtonUnhovered_Params
{
	class CommonButtonBase*                            Button_69;                                                // (Parm, ZeroConstructor, InstancedReference)
};

// Function CommonUILegacy.CommonButtonLegacy.HandleOnButtonHovered
struct CommonButtonLegacy_HandleOnButtonHovered_Params
{
	class CommonButtonBase*                            Button_69;                                                // (Parm, ZeroConstructor, InstancedReference)
};

// Function CommonUILegacy.CommonButtonLegacy.HandleOnButtonDoubleClicked
struct CommonButtonLegacy_HandleOnButtonDoubleClicked_Params
{
	class CommonButtonBase*                            Button_69;                                                // (Parm, ZeroConstructor, InstancedReference)
};

// Function CommonUILegacy.CommonButtonLegacy.HandleOnButtonClicked
struct CommonButtonLegacy_HandleOnButtonClicked_Params
{
	class CommonButtonBase*                            Button_69;                                                // (Parm, ZeroConstructor, InstancedReference)
};

// Function CommonUILegacy.CommonInputManagerLegacy.SuspendStartingOperationProcessing
struct CommonInputManagerLegacy_SuspendStartingOperationProcessing_Params
{
};

// Function CommonUILegacy.CommonInputManagerLegacy.StopListeningForExistingHeldAction
struct CommonInputManagerLegacy_StopListeningForExistingHeldAction_Params
{
	struct FDataTableRowHandle                         InputActionDataRow_69;                                    // (ConstParm, Parm, OutParm, ReferenceParm)
	struct FScriptDelegate                             CompleteEvent_69;                                         // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	struct FScriptDelegate                             ProgressEvent_69;                                         // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CommonUILegacy.CommonInputManagerLegacy.StartListeningForExistingHeldAction
struct CommonInputManagerLegacy_StartListeningForExistingHeldAction_Params
{
	struct FDataTableRowHandle                         InputActionDataRow_69;                                    // (ConstParm, Parm, OutParm, ReferenceParm)
	struct FScriptDelegate                             CompleteEvent_69;                                         // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	struct FScriptDelegate                             ProgressEvent_69;                                         // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CommonUILegacy.CommonInputManagerLegacy.SetGlobalInputHandlerPriorityFilter
struct CommonInputManagerLegacy_SetGlobalInputHandlerPriorityFilter_Params
{
	int                                                InFilterPriority_69;                                      // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function CommonUILegacy.CommonInputManagerLegacy.ResumeStartingOperationProcessing
struct CommonInputManagerLegacy_ResumeStartingOperationProcessing_Params
{
};

// Function CommonUILegacy.CommonInputManagerLegacy.PushActivatablePanel
struct CommonInputManagerLegacy_PushActivatablePanel_Params
{
	class CommonActivatablePanelLegacy*                ActivatablePanel_69;                                      // (Parm, ZeroConstructor, InstancedReference)
	bool                                               bIntroPanel_69;                                           // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bOutroPanelBelow_69;                                      // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function CommonUILegacy.CommonInputManagerLegacy.PopActivatablePanel
struct CommonInputManagerLegacy_PopActivatablePanel_Params
{
	class CommonActivatablePanelLegacy*                ActivatablePanel_69;                                      // (Parm, ZeroConstructor, InstancedReference)
};

// Function CommonUILegacy.CommonInputManagerLegacy.IsPanelOnStack
struct CommonInputManagerLegacy_IsPanelOnStack_Params
{
	class CommonActivatablePanelLegacy*                InPanel_69;                                               // (ConstParm, Parm, ZeroConstructor, InstancedReference)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CommonUILegacy.CommonInputManagerLegacy.IsInputSuspended
struct CommonInputManagerLegacy_IsInputSuspended_Params
{
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CommonUILegacy.CommonInputManagerLegacy.GetTopPanel
struct CommonInputManagerLegacy_GetTopPanel_Params
{
	class CommonActivatablePanelLegacy*                ReturnValue_69;                                           // (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)
};

// Function CommonUILegacy.CommonInputManagerLegacy.GetGlobalInputHandlerPriorityFilter
struct CommonInputManagerLegacy_GetGlobalInputHandlerPriorityFilter_Params
{
	int                                                ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CommonUILegacy.CommonInputManagerLegacy.GetAvailableInputActions
struct CommonInputManagerLegacy_GetAvailableInputActions_Params
{
	TArray<struct FCommonInputActionHandlerData>       AvailableInputActions_69;                                 // (Parm, OutParm, ZeroConstructor)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CommonUILegacy.CommonInputReflectorLegacy.OnButtonAdded
struct CommonInputReflectorLegacy_OnButtonAdded_Params
{
	class CommonButtonLegacy*                          AddedButton_69;                                           // (Parm, ZeroConstructor, InstancedReference)
	struct FCommonInputActionHandlerData               Data_69;                                                  // (ConstParm, Parm, OutParm, ReferenceParm)
};

// Function CommonUILegacy.CommonPopupButtonLegacy.GetMenuAnchorWidget
struct CommonPopupButtonLegacy_GetMenuAnchorWidget_Params
{
	class UserWidget*                                  ReturnValue_69;                                           // (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)
};

// Function CommonUILegacy.CommonPopupMenuLegacy.SetOwningMenuAnchor
struct CommonPopupMenuLegacy_SetOwningMenuAnchor_Params
{
	class MenuAnchor*                                  MenuAnchor_69;                                            // (ConstParm, Parm, ZeroConstructor, InstancedReference)
};

// Function CommonUILegacy.CommonPopupMenuLegacy.SetContextProvider
struct CommonPopupMenuLegacy_SetContextProvider_Params
{
	class Object_32759*                                ContextProvidingObject_69;                                // (ConstParm, Parm, ZeroConstructor)
};

// Function CommonUILegacy.CommonPopupMenuLegacy.RequestClose
struct CommonPopupMenuLegacy_RequestClose_Params
{
};

// Function CommonUILegacy.CommonPopupMenuLegacy.OnIsOpenChanged
struct CommonPopupMenuLegacy_OnIsOpenChanged_Params
{
	bool                                               IsOpen_69;                                                // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function CommonUILegacy.CommonPopupMenuLegacy.HandlePreDifferentContextProviderSet
struct CommonPopupMenuLegacy_HandlePreDifferentContextProviderSet_Params
{
};

// Function CommonUILegacy.CommonPopupMenuLegacy.HandlePostDifferentContextProviderSet
struct CommonPopupMenuLegacy_HandlePostDifferentContextProviderSet_Params
{
};

// DelegateFunction CommonUILegacy.CommonTabListWidgetLegacy.OnTabButtonRemoved__DelegateSignature
struct CommonTabListWidgetLegacy_OnTabButtonRemoved__DelegateSignature_Params
{
	struct FName                                       TabId_69;                                                 // (Parm, ZeroConstructor, IsPlainOldData)
	class CommonButtonLegacy*                          TabButton_69;                                             // (Parm, ZeroConstructor, InstancedReference)
};

// DelegateFunction CommonUILegacy.CommonTabListWidgetLegacy.OnTabButtonCreated__DelegateSignature
struct CommonTabListWidgetLegacy_OnTabButtonCreated__DelegateSignature_Params
{
	struct FName                                       TabId_69;                                                 // (Parm, ZeroConstructor, IsPlainOldData)
	class CommonButtonLegacy*                          TabButton_69;                                             // (Parm, ZeroConstructor, InstancedReference)
};

// Function CommonUILegacy.CommonTabListWidgetLegacy.HandleTabRemoved
struct CommonTabListWidgetLegacy_HandleTabRemoved_Params
{
	struct FName                                       TabNameID_69;                                             // (Parm, ZeroConstructor, IsPlainOldData)
	class CommonButtonLegacy*                          TabButton_69;                                             // (Parm, ZeroConstructor, InstancedReference)
};

// Function CommonUILegacy.CommonTabListWidgetLegacy.HandleTabCreated
struct CommonTabListWidgetLegacy_HandleTabCreated_Params
{
	struct FName                                       TabNameID_69;                                             // (Parm, ZeroConstructor, IsPlainOldData)
	class CommonButtonLegacy*                          TabButton_69;                                             // (Parm, ZeroConstructor, InstancedReference)
};

// Function CommonUILegacy.CommonTabListWidgetLegacy.HandleOnTabButtonRemoved
struct CommonTabListWidgetLegacy_HandleOnTabButtonRemoved_Params
{
	struct FName                                       TabId_69;                                                 // (Parm, ZeroConstructor, IsPlainOldData)
	class CommonButtonBase*                            TabButton_69;                                             // (Parm, ZeroConstructor, InstancedReference)
};

// Function CommonUILegacy.CommonTabListWidgetLegacy.HandleOnTabButtonCreated
struct CommonTabListWidgetLegacy_HandleOnTabButtonCreated_Params
{
	struct FName                                       TabId_69;                                                 // (Parm, ZeroConstructor, IsPlainOldData)
	class CommonButtonBase*                            TabButton_69;                                             // (Parm, ZeroConstructor, InstancedReference)
};

// Function CommonUILegacy.CommonTabListWidgetLegacy.GetTabButtonByID
struct CommonTabListWidgetLegacy_GetTabButtonByID_Params
{
	struct FName                                       TabNameID_69;                                             // (Parm, ZeroConstructor, IsPlainOldData)
	class CommonButtonLegacy*                          ReturnValue_69;                                           // (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)
};

// DelegateFunction CommonUILegacy.CommonUISubsystemLegacy.InputSuspensionChanged__DelegateSignature
struct CommonUISubsystemLegacy_InputSuspensionChanged__DelegateSignature_Params
{
	bool                                               bInputSuspended_69;                                       // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function CommonUILegacy.CommonUISubsystemLegacy.GetInputManager
struct CommonUISubsystemLegacy_GetInputManager_Params
{
	class CommonInputManagerLegacy*                    ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function CommonUILegacy.CommonWidgetStackLegacy.PushWidget
struct CommonWidgetStackLegacy_PushWidget_Params
{
	class Widget*                                      InWidget_69;                                              // (Parm, ZeroConstructor, InstancedReference)
};

// Function CommonUILegacy.CommonWidgetStackLegacy.PopWidget
struct CommonWidgetStackLegacy_PopWidget_Params
{
	class Widget*                                      ReturnValue_69;                                           // (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)
};

// DelegateFunction CommonUILegacy.CommonWidgetStackLegacy.OnActiveWidgetChangedLegacy__DelegateSignature
struct CommonWidgetStackLegacy_OnActiveWidgetChangedLegacy__DelegateSignature_Params
{
	class Widget*                                      InActiveWidget_69;                                        // (Parm, ZeroConstructor, InstancedReference)
	int                                                InActiveWidgetIndex_69;                                   // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function CommonUILegacy.CommonWidgetStackLegacy.DeactivateWidget
struct CommonWidgetStackLegacy_DeactivateWidget_Params
{
};

// Function CommonUILegacy.CommonWidgetStackLegacy.ActivateWidget
struct CommonWidgetStackLegacy_ActivateWidget_Params
{
};

// Function CommonUILegacy.CommonWidgetSwitcherLegacy.SetActiveWidgetIndex_Advanced
struct CommonWidgetSwitcherLegacy_SetActiveWidgetIndex_Advanced_Params
{
	int                                                Index_69;                                                 // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	bool                                               AttemptActivationChange_69;                               // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function CommonUILegacy.CommonWidgetSwitcherLegacy.SetActiveWidget_Advanced
struct CommonWidgetSwitcherLegacy_SetActiveWidget_Advanced_Params
{
	class Widget*                                      Widget_69;                                                // (Parm, ZeroConstructor, InstancedReference)
	bool                                               AttemptActivationChange_69;                               // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function CommonUILegacy.CommonWidgetSwitcherLegacy.HandleActiveWidgetDeactivated
struct CommonWidgetSwitcherLegacy_HandleActiveWidgetDeactivated_Params
{
	class CommonActivatablePanelLegacy*                DeactivatedPanel_69;                                      // (Parm, ZeroConstructor, InstancedReference)
};

// Function CommonUILegacy.CommonWidgetSwitcherLegacy.DeactivateWidget
struct CommonWidgetSwitcherLegacy_DeactivateWidget_Params
{
};

// Function CommonUILegacy.CommonWidgetSwitcherLegacy.ActivateWidget
struct CommonWidgetSwitcherLegacy_ActivateWidget_Params
{
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

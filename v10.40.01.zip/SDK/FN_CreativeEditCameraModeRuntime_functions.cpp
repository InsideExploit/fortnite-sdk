// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Functions
//---------------------------------------------------------------------------

// Function CreativeEditCameraModeRuntime.FortPawnComponent_CreativeEditCameraMode.ServerSetImmersiveEdit
// (Final, Net, NetReliable, Native, Event, Private, NetServer, NetValidate)
// Parameters:
// bool                           bWantsToImmersiveEdit_69       (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// bool                           bIsCreativeEditModeEnabled_69  (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void FortPawnComponent_CreativeEditCameraMode::ServerSetImmersiveEdit(bool bWantsToImmersiveEdit_69, bool bIsCreativeEditModeEnabled_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CreativeEditCameraModeRuntime.FortPawnComponent_CreativeEditCameraMode.ServerSetImmersiveEdit"));

	FortPawnComponent_CreativeEditCameraMode_ServerSetImmersiveEdit_Params params;
	params.bWantsToImmersiveEdit_69 = bWantsToImmersiveEdit_69;
	params.bIsCreativeEditModeEnabled_69 = bIsCreativeEditModeEnabled_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CreativeEditCameraModeRuntime.FortPawnComponent_CreativeEditCameraMode.RestrictImmersiveMode
// (Final, Native, Private)

void FortPawnComponent_CreativeEditCameraMode::RestrictImmersiveMode()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CreativeEditCameraModeRuntime.FortPawnComponent_CreativeEditCameraMode.RestrictImmersiveMode"));

	FortPawnComponent_CreativeEditCameraMode_RestrictImmersiveMode_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CreativeEditCameraModeRuntime.FortPawnComponent_CreativeEditCameraMode.OnWantsToImmersiveEditChanged
// (Final, Native, Private)
// Parameters:
// class FortCreativeOption*      CreativeOption_69              (Parm, ZeroConstructor)
// unsigned char                  IndexValue_69                  (Parm, ZeroConstructor, IsPlainOldData)

void FortPawnComponent_CreativeEditCameraMode::OnWantsToImmersiveEditChanged(class FortCreativeOption* CreativeOption_69, unsigned char IndexValue_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CreativeEditCameraModeRuntime.FortPawnComponent_CreativeEditCameraMode.OnWantsToImmersiveEditChanged"));

	FortPawnComponent_CreativeEditCameraMode_OnWantsToImmersiveEditChanged_Params params;
	params.CreativeOption_69 = CreativeOption_69;
	params.IndexValue_69 = IndexValue_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CreativeEditCameraModeRuntime.FortPawnComponent_CreativeEditCameraMode.OnRep_IsImmersiveModeEnabled
// (Final, Native, Private)

void FortPawnComponent_CreativeEditCameraMode::OnRep_IsImmersiveModeEnabled()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CreativeEditCameraModeRuntime.FortPawnComponent_CreativeEditCameraMode.OnRep_IsImmersiveModeEnabled"));

	FortPawnComponent_CreativeEditCameraMode_OnRep_IsImmersiveModeEnabled_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CreativeEditCameraModeRuntime.FortPawnComponent_CreativeEditCameraMode.OnCreativeEditModeChanged
// (Final, Native, Private)
// Parameters:
// bool                           bIsCreativeEditModeEnabled_69  (Parm, ZeroConstructor, IsPlainOldData)

void FortPawnComponent_CreativeEditCameraMode::OnCreativeEditModeChanged(bool bIsCreativeEditModeEnabled_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CreativeEditCameraModeRuntime.FortPawnComponent_CreativeEditCameraMode.OnCreativeEditModeChanged"));

	FortPawnComponent_CreativeEditCameraMode_OnCreativeEditModeChanged_Params params;
	params.bIsCreativeEditModeEnabled_69 = bIsCreativeEditModeEnabled_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CreativeEditCameraModeRuntime.FortPawnComponent_CreativeEditCameraMode.HandleWeaponEquipped
// (Final, Native, Private)
// Parameters:
// class FortWeapon*              NewWeapon_69                   (Parm, ZeroConstructor)
// class FortWeapon*              PrevWeapon_69                  (Parm, ZeroConstructor)

void FortPawnComponent_CreativeEditCameraMode::HandleWeaponEquipped(class FortWeapon* NewWeapon_69, class FortWeapon* PrevWeapon_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CreativeEditCameraModeRuntime.FortPawnComponent_CreativeEditCameraMode.HandleWeaponEquipped"));

	FortPawnComponent_CreativeEditCameraMode_HandleWeaponEquipped_Params params;
	params.NewWeapon_69 = NewWeapon_69;
	params.PrevWeapon_69 = PrevWeapon_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CreativeEditCameraModeRuntime.FortPawnComponent_CreativeEditCameraMode.BindVehicleEvents
// (Final, Native, Private)
// Parameters:
// class Pawn*                    Pawn_69                        (Parm, ZeroConstructor)
// class Controller*              OldController_69               (Parm, ZeroConstructor)
// class Controller*              NewController_69               (Parm, ZeroConstructor)

void FortPawnComponent_CreativeEditCameraMode::BindVehicleEvents(class Pawn* Pawn_69, class Controller* OldController_69, class Controller* NewController_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CreativeEditCameraModeRuntime.FortPawnComponent_CreativeEditCameraMode.BindVehicleEvents"));

	FortPawnComponent_CreativeEditCameraMode_BindVehicleEvents_Params params;
	params.Pawn_69 = Pawn_69;
	params.OldController_69 = OldController_69;
	params.NewController_69 = NewController_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CreativeEditCameraModeRuntime.FortPawnComponent_CreativeEditCameraMode.AllowImmersiveMode
// (Final, Native, Private)

void FortPawnComponent_CreativeEditCameraMode::AllowImmersiveMode()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CreativeEditCameraModeRuntime.FortPawnComponent_CreativeEditCameraMode.AllowImmersiveMode"));

	FortPawnComponent_CreativeEditCameraMode_AllowImmersiveMode_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

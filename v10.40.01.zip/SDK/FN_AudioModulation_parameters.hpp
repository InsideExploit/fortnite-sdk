#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function AudioModulation.AudioModulationStyle.GetPatchColor
struct AudioModulationStyle_GetPatchColor_Params
{
	struct FCoreUObject_FColor                         ReturnValue_69;                                           // (ConstParm, Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AudioModulation.AudioModulationStyle.GetParameterColor
struct AudioModulationStyle_GetParameterColor_Params
{
	struct FCoreUObject_FColor                         ReturnValue_69;                                           // (ConstParm, Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AudioModulation.AudioModulationStyle.GetModulationGeneratorColor
struct AudioModulationStyle_GetModulationGeneratorColor_Params
{
	struct FCoreUObject_FColor                         ReturnValue_69;                                           // (ConstParm, Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AudioModulation.AudioModulationStyle.GetControlBusMixColor
struct AudioModulationStyle_GetControlBusMixColor_Params
{
	struct FCoreUObject_FColor                         ReturnValue_69;                                           // (ConstParm, Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AudioModulation.AudioModulationStyle.GetControlBusColor
struct AudioModulationStyle_GetControlBusColor_Params
{
	struct FCoreUObject_FColor                         ReturnValue_69;                                           // (ConstParm, Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AudioModulation.AudioModulationStatics.UpdateModulator
struct AudioModulationStatics_UpdateModulator_Params
{
	class Object_32759*                                WorldContextObject_69;                                    // (ConstParm, Parm, ZeroConstructor)
	class SoundModulatorBase*                          Modulator_69;                                             // (Parm, ZeroConstructor)
};

// Function AudioModulation.AudioModulationStatics.UpdateMixFromObject
struct AudioModulationStatics_UpdateMixFromObject_Params
{
	class Object_32759*                                WorldContextObject_69;                                    // (ConstParm, Parm, ZeroConstructor)
	class SoundControlBusMix*                          Mix_69;                                                   // (Parm, ZeroConstructor)
	float                                              FadeTime_69;                                              // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function AudioModulation.AudioModulationStatics.UpdateMixByFilter
struct AudioModulationStatics_UpdateMixByFilter_Params
{
	class Object_32759*                                WorldContextObject_69;                                    // (ConstParm, Parm, ZeroConstructor)
	class SoundControlBusMix*                          Mix_69;                                                   // (Parm, ZeroConstructor)
	struct FString                                     AddressFilter_69;                                         // (Parm, ZeroConstructor)
	class SoundModulationParameter*                    ParamClassFilter_69;                                      // (Parm, ZeroConstructor)
	class SoundModulationParameter*                    ParamFilter_69;                                           // (Parm, ZeroConstructor)
	float                                              Value_69;                                                 // (Parm, ZeroConstructor, IsPlainOldData)
	float                                              FadeTime_69;                                              // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function AudioModulation.AudioModulationStatics.UpdateMix
struct AudioModulationStatics_UpdateMix_Params
{
	class Object_32759*                                WorldContextObject_69;                                    // (ConstParm, Parm, ZeroConstructor)
	class SoundControlBusMix*                          Mix_69;                                                   // (Parm, ZeroConstructor)
	TArray<struct FSoundControlBusMixStage>            Stages_69;                                                // (Parm, ZeroConstructor)
	float                                              FadeTime_69;                                              // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function AudioModulation.AudioModulationStatics.SetGlobalBusMixValue
struct AudioModulationStatics_SetGlobalBusMixValue_Params
{
	class Object_32759*                                WorldContextObject_69;                                    // (ConstParm, Parm, ZeroConstructor)
	class SoundControlBus*                             Bus_69;                                                   // (Parm, ZeroConstructor)
	float                                              Value_69;                                                 // (Parm, ZeroConstructor, IsPlainOldData)
	float                                              FadeTime_69;                                              // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function AudioModulation.AudioModulationStatics.SaveMixToProfile
struct AudioModulationStatics_SaveMixToProfile_Params
{
	class Object_32759*                                WorldContextObject_69;                                    // (ConstParm, Parm, ZeroConstructor)
	class SoundControlBusMix*                          Mix_69;                                                   // (Parm, ZeroConstructor)
	int                                                ProfileIndex_69;                                          // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function AudioModulation.AudioModulationStatics.LoadMixFromProfile
struct AudioModulationStatics_LoadMixFromProfile_Params
{
	class Object_32759*                                WorldContextObject_69;                                    // (ConstParm, Parm, ZeroConstructor)
	class SoundControlBusMix*                          Mix_69;                                                   // (Parm, ZeroConstructor)
	bool                                               bActivate_69;                                             // (Parm, ZeroConstructor, IsPlainOldData)
	int                                                ProfileIndex_69;                                          // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<struct FSoundControlBusMixStage>            ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function AudioModulation.AudioModulationStatics.DeactivateGenerator
struct AudioModulationStatics_DeactivateGenerator_Params
{
	class Object_32759*                                WorldContextObject_69;                                    // (ConstParm, Parm, ZeroConstructor)
	class SoundModulationGenerator*                    Generator_69;                                             // (Parm, ZeroConstructor)
};

// Function AudioModulation.AudioModulationStatics.DeactivateBusMix
struct AudioModulationStatics_DeactivateBusMix_Params
{
	class Object_32759*                                WorldContextObject_69;                                    // (ConstParm, Parm, ZeroConstructor)
	class SoundControlBusMix*                          Mix_69;                                                   // (Parm, ZeroConstructor)
};

// Function AudioModulation.AudioModulationStatics.DeactivateBus
struct AudioModulationStatics_DeactivateBus_Params
{
	class Object_32759*                                WorldContextObject_69;                                    // (ConstParm, Parm, ZeroConstructor)
	class SoundControlBus*                             Bus_69;                                                   // (Parm, ZeroConstructor)
};

// Function AudioModulation.AudioModulationStatics.CreateBusMixStage
struct AudioModulationStatics_CreateBusMixStage_Params
{
	class Object_32759*                                WorldContextObject_69;                                    // (ConstParm, Parm, ZeroConstructor)
	class SoundControlBus*                             Bus_69;                                                   // (Parm, ZeroConstructor)
	float                                              Value_69;                                                 // (Parm, ZeroConstructor, IsPlainOldData)
	float                                              AttackTime_69;                                            // (Parm, ZeroConstructor, IsPlainOldData)
	float                                              ReleaseTime_69;                                           // (Parm, ZeroConstructor, IsPlainOldData)
	struct FSoundControlBusMixStage                    ReturnValue_69;                                           // (Parm, OutParm, ReturnParm)
};

// Function AudioModulation.AudioModulationStatics.CreateBusMix
struct AudioModulationStatics_CreateBusMix_Params
{
	class Object_32759*                                WorldContextObject_69;                                    // (Parm, ZeroConstructor)
	struct FName                                       Name_69;                                                  // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<struct FSoundControlBusMixStage>            Stages_69;                                                // (Parm, ZeroConstructor)
	bool                                               Activate_69;                                              // (Parm, ZeroConstructor, IsPlainOldData)
	class SoundControlBusMix*                          ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function AudioModulation.AudioModulationStatics.CreateBus
struct AudioModulationStatics_CreateBus_Params
{
	class Object_32759*                                WorldContextObject_69;                                    // (Parm, ZeroConstructor)
	struct FName                                       Name_69;                                                  // (Parm, ZeroConstructor, IsPlainOldData)
	class SoundModulationParameter*                    Parameter_69;                                             // (Parm, ZeroConstructor)
	bool                                               Activate_69;                                              // (Parm, ZeroConstructor, IsPlainOldData)
	class SoundControlBus*                             ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function AudioModulation.AudioModulationStatics.ClearGlobalBusMixValue
struct AudioModulationStatics_ClearGlobalBusMixValue_Params
{
	class Object_32759*                                WorldContextObject_69;                                    // (ConstParm, Parm, ZeroConstructor)
	class SoundControlBus*                             Bus_69;                                                   // (Parm, ZeroConstructor)
	float                                              FadeTime_69;                                              // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function AudioModulation.AudioModulationStatics.ClearAllGlobalBusMixValues
struct AudioModulationStatics_ClearAllGlobalBusMixValues_Params
{
	class Object_32759*                                WorldContextObject_69;                                    // (ConstParm, Parm, ZeroConstructor)
	float                                              FadeTime_69;                                              // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function AudioModulation.AudioModulationStatics.ActivateGenerator
struct AudioModulationStatics_ActivateGenerator_Params
{
	class Object_32759*                                WorldContextObject_69;                                    // (ConstParm, Parm, ZeroConstructor)
	class SoundModulationGenerator*                    Generator_69;                                             // (Parm, ZeroConstructor)
};

// Function AudioModulation.AudioModulationStatics.ActivateBusMix
struct AudioModulationStatics_ActivateBusMix_Params
{
	class Object_32759*                                WorldContextObject_69;                                    // (ConstParm, Parm, ZeroConstructor)
	class SoundControlBusMix*                          Mix_69;                                                   // (Parm, ZeroConstructor)
};

// Function AudioModulation.AudioModulationStatics.ActivateBus
struct AudioModulationStatics_ActivateBus_Params
{
	class Object_32759*                                WorldContextObject_69;                                    // (ConstParm, Parm, ZeroConstructor)
	class SoundControlBus*                             Bus_69;                                                   // (Parm, ZeroConstructor)
};

// Function AudioModulation.SoundControlBusMix.SoloMix
struct SoundControlBusMix_SoloMix_Params
{
};

// Function AudioModulation.SoundControlBusMix.SaveMixToProfile
struct SoundControlBusMix_SaveMixToProfile_Params
{
};

// Function AudioModulation.SoundControlBusMix.LoadMixFromProfile
struct SoundControlBusMix_LoadMixFromProfile_Params
{
};

// Function AudioModulation.SoundControlBusMix.DeactivateMix
struct SoundControlBusMix_DeactivateMix_Params
{
};

// Function AudioModulation.SoundControlBusMix.DeactivateAllMixes
struct SoundControlBusMix_DeactivateAllMixes_Params
{
};

// Function AudioModulation.SoundControlBusMix.ActivateMix
struct SoundControlBusMix_ActivateMix_Params
{
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

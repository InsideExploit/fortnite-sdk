#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Enums
//---------------------------------------------------------------------------

// Enum AnnualRefundTokenUI.EFortPurchaseHistoryRefundType
enum class EFortPurchaseHistoryRefundType : uint8_t
{
	CancelPurchase                 = 0,
	ReturnTicket                   = 1,
	TokenlessRefund                = 2,
	NonRefundable                  = 3,
	EFortPurchaseHistoryRefundType_MAX = 4
};



}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

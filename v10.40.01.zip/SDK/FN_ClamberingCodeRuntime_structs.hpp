#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Enums
//---------------------------------------------------------------------------

// Enum ClamberingCodeRuntime.EClamberingType
enum class EClamberingType : uint8_t
{
	Invalid                        = 0,
	Ledge                          = 1,
	Window                         = 2,
	EClamberingType_MAX            = 3
};


// Enum ClamberingCodeRuntime.EClamberingState
enum class EClamberingState : uint8_t
{
	Inactive                       = 0,
	Targeting                      = 1,
	Ledge_Moving                   = 2,
	Ledge_Failed                   = 3,
	Window_Moving                  = 4,
	Window_Failed                  = 5,
	EClamberingState_MAX           = 6
};


// Enum ClamberingCodeRuntime.EClamberingFailedReason
enum class EClamberingFailedReason : uint8_t
{
	None                           = 0,
	Unknown                        = 1,
	DebugForced                    = 2,
	OwnerDied                      = 3,
	OwnerDBNO                      = 4,
	OwnerLaunched                  = 5,
	SynchedActionNotStarted        = 6,
	Ledge_PlayerTooFar             = 7,
	Ledge_TargetLocationInvalid    = 8,
	Ledge_TargetActorInvalid       = 9,
	Ledge_TargetActorDestroyed     = 10,
	Ledge_BlockerEncountered       = 11,
	EClamberingFailedReason_MAX    = 12
};


// Enum ClamberingCodeRuntime.EClamberingActivationMode
enum class EClamberingActivationMode : uint8_t
{
	ClientPreference               = 0,
	ForceAutoClambering            = 1,
	ForceManualClambering          = 2,
	EClamberingActivationMode_MAX  = 3
};


// Enum ClamberingCodeRuntime.EClamberingDebugTextAlign
enum class EClamberingDebugTextAlign : uint8_t
{
	Left                           = 0,
	Right                          = 1,
	Center                         = 2,
	EClamberingDebugTextAlign_MAX  = 3
};



//---------------------------------------------------------------------------
//Script Structs
//---------------------------------------------------------------------------

// ScriptStruct ClamberingCodeRuntime.ClamberingTargetingData
// 0x00D0
struct FClamberingTargetingData
{
	EClamberingType                                    Type_69;                                                  // 0x0000(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      bValid_69 : 1;                                            // 0x0001(0x0001) (BlueprintVisible, BlueprintReadOnly)
	unsigned char                                      UnknownData00[0x6];                                       // 0x0002(0x0006) MISSED OFFSET
	class Actor_32759*                                 SourceActor_69;                                           // 0x0008(0x0008) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
	struct FVector                                     SourceLocation_69;                                        // 0x0010(0x0018) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	struct FVector                                     SourceAim_69;                                             // 0x0028(0x0018) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	struct FVector                                     WallLocation_69;                                          // 0x0040(0x0018) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	struct FVector                                     WallNormal_69;                                            // 0x0058(0x0018) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	struct FVector                                     TargetLocation_69;                                        // 0x0070(0x0018) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	struct FVector                                     TargetNormal_69;                                          // 0x0088(0x0018) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	class Actor_32759*                                 TargetActor_69;                                           // 0x00A0(0x0008) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
	class ActorComponent*                              TargetActorComponent_69;                                  // 0x00A8(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)
	struct FVector                                     TargetActorComponentLocation_69;                          // 0x00B0(0x0018) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	struct FName                                       TargetActorBoneName_69;                                   // 0x00C8(0x0008) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x4];                                       // 0x00CC(0x0004) MISSED OFFSET
};

// ScriptStruct ClamberingCodeRuntime.ReplicatedClamberingTargetingData_SimClient
// 0x0038
struct FReplicatedClamberingTargetingData_SimClient
{
	EClamberingType                                    Type_69;                                                  // 0x0000(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x1];                                       // 0x0001(0x0001) MISSED OFFSET
	uint16_t                                           WallNormalYawQuantized_69;                                // 0x0002(0x0002) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x4];                                       // 0x0004(0x0004) MISSED OFFSET
	struct FVector_NetQuantize100                      TargetLocation_69;                                        // 0x0008(0x0018)
	class Actor_32759*                                 TargetActor_69;                                           // 0x0020(0x0008) (ZeroConstructor)
	class ActorComponent*                              TargetActorComponent_69;                                  // 0x0028(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	struct FName                                       TargetActorBoneName_69;                                   // 0x0030(0x0008) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData02[0x4];                                       // 0x0034(0x0004) MISSED OFFSET
};

// ScriptStruct ClamberingCodeRuntime.ClamberingInputConfig
// 0x0210
struct FClamberingInputConfig
{
	struct FScalableFloat                              ClamberActivationHorizontalRange_69;                      // 0x0000(0x0028) (Edit, BlueprintVisible, BlueprintReadOnly, DisableEditOnInstance)
	struct FScalableFloat                              ClamberActivationVerticalRange_69;                        // 0x0028(0x0028) (Edit, BlueprintVisible, BlueprintReadOnly, DisableEditOnInstance)
	struct FScalableFloat                              EnableInputDelay_69;                                      // 0x0050(0x0028) (Edit, BlueprintVisible, BlueprintReadOnly, DisableEditOnInstance)
	struct FScalableFloat                              QueuedInputWindow_69;                                     // 0x0078(0x0028) (Edit, BlueprintVisible, BlueprintReadOnly, DisableEditOnInstance)
	struct FScalableFloat                              HeldInputDuration_69;                                     // 0x00A0(0x0028) (Edit, BlueprintVisible, BlueprintReadOnly, DisableEditOnInstance)
	EClamberingActivationMode                          ActivationMode_69;                                        // 0x00C8(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x00C9(0x0007) MISSED OFFSET
	struct FScalableFloat                              AutoStartMovementThreshold_69;                            // 0x00D0(0x0028) (Edit, BlueprintVisible, BlueprintReadOnly, DisableEditOnInstance)
	struct FScalableFloat                              AutoStartLookAtThreshold_69;                              // 0x00F8(0x0028) (Edit, BlueprintVisible, BlueprintReadOnly, DisableEditOnInstance)
	struct FScalableFloat                              AutoStartWallCheckCastRadius_69;                          // 0x0120(0x0028) (Edit, BlueprintVisible, BlueprintReadOnly, DisableEditOnInstance)
	struct FScalableFloat                              AutoStartWallCheckHorizontalRange_69;                     // 0x0148(0x0028) (Edit, BlueprintVisible, BlueprintReadOnly, DisableEditOnInstance)
	struct FScalableFloat                              AutoStartWallCheckLookAtThresholdMultiplier_69;           // 0x0170(0x0028) (Edit, BlueprintVisible, BlueprintReadOnly, DisableEditOnInstance)
	struct FScalableFloat                              TargetInvalidateDistance_69;                              // 0x0198(0x0028) (Edit, BlueprintVisible, BlueprintReadOnly, DisableEditOnInstance)
	struct FScalableFloat                              TargetAimInvalidateAngle_69;                              // 0x01C0(0x0028) (Edit, BlueprintVisible, BlueprintReadOnly, DisableEditOnInstance)
	struct FScalableFloat                              TargetActorMovementInvalidateDistance_69;                 // 0x01E8(0x0028) (Edit, BlueprintVisible, BlueprintReadOnly, DisableEditOnInstance)
};

// ScriptStruct ClamberingCodeRuntime.ClamberingTargetingConfig_Ledge
// 0x02A8
struct FClamberingTargetingConfig_Ledge
{
	struct FScalableFloat                              ForwardCastDistance_69;                                   // 0x0000(0x0028) (Edit, BlueprintVisible, BlueprintReadOnly, DisableEditOnInstance)
	struct FScalableFloat                              ForwardCastRadius_69;                                     // 0x0028(0x0028) (Edit, BlueprintVisible, BlueprintReadOnly, DisableEditOnInstance)
	struct FScalableFloat                              FowardCast2D_69;                                          // 0x0050(0x0028) (Edit, BlueprintVisible, BlueprintReadOnly, DisableEditOnInstance)
	struct FScalableFloat                              VerticalSurfaceThreshold_69;                              // 0x0078(0x0028) (Edit, BlueprintVisible, BlueprintReadOnly, DisableEditOnInstance)
	struct FScalableFloat                              HorizontalSurfaceThreshold_69;                            // 0x00A0(0x0028) (Edit, BlueprintVisible, BlueprintReadOnly, DisableEditOnInstance)
	struct FScalableFloat                              UpwardDistanceCapsuleHeightMultiplier_69;                 // 0x00C8(0x0028) (Edit, BlueprintVisible, BlueprintReadOnly, DisableEditOnInstance)
	struct FScalableFloat                              UpwardStartDistanceCapsuleHeightMultiplier_69;            // 0x00F0(0x0028) (Edit, BlueprintVisible, BlueprintReadOnly, DisableEditOnInstance)
	struct FScalableFloat                              DownwardDistanceCapsuleHeightMultiplier_69;               // 0x0118(0x0028) (Edit, BlueprintVisible, BlueprintReadOnly, DisableEditOnInstance)
	struct FScalableFloat                              MinimumLedgeHeight_69;                                    // 0x0140(0x0028) (Edit, BlueprintVisible, BlueprintReadOnly, DisableEditOnInstance)
	struct FScalableFloat                              MinimumLedgeHeightWater_69;                               // 0x0168(0x0028) (Edit, BlueprintVisible, BlueprintReadOnly, DisableEditOnInstance)
	struct FScalableFloat                              ForwardSphereCastRadius_69;                               // 0x0190(0x0028) (Edit, BlueprintVisible, BlueprintReadOnly, DisableEditOnInstance)
	struct FScalableFloat                              DownwardSphereCastRadius_69;                              // 0x01B8(0x0028) (Edit, BlueprintVisible, BlueprintReadOnly, DisableEditOnInstance)
	struct FScalableFloat                              AllowNonWalkableSurfaces_69;                              // 0x01E0(0x0028) (Edit, BlueprintVisible, BlueprintReadOnly, DisableEditOnInstance)
	struct FScalableFloat                              TargetValidationEnabled_69;                               // 0x0208(0x0028) (Edit, BlueprintVisible, BlueprintReadOnly, DisableEditOnInstance)
	struct FScalableFloat                              TargetValidationCapsuleRadiusModifier_69;                 // 0x0230(0x0028) (Edit, BlueprintVisible, BlueprintReadOnly, DisableEditOnInstance)
	struct FScalableFloat                              TargetValidationCapsuleHalfHeightModifier_69;             // 0x0258(0x0028) (Edit, BlueprintVisible, BlueprintReadOnly, DisableEditOnInstance)
	struct FScalableFloat                              TargetValidationCapsuleBottomVerticalOffset_69;           // 0x0280(0x0028) (Edit, BlueprintVisible, BlueprintReadOnly, DisableEditOnInstance)
};

// ScriptStruct ClamberingCodeRuntime.ClamberingTargetingConfig_Ledge_CachedContextualValues
// 0x0008
struct FClamberingTargetingConfig_Ledge_CachedContextualValues
{
	unsigned char                                      UnknownData00[0x8];                                       // 0x0000(0x0008) MISSED OFFSET
};

// ScriptStruct ClamberingCodeRuntime.ClamberingMovementConfig_Ledge
// 0x0050
struct FClamberingMovementConfig_Ledge
{
	struct FScalableFloat                              Duration_69;                                              // 0x0000(0x0028) (Edit, BlueprintVisible, BlueprintReadOnly, DisableEditOnInstance)
	struct FScalableFloat                              BlockCheckTickRate_69;                                    // 0x0028(0x0028) (Edit, BlueprintVisible, BlueprintReadOnly, DisableEditOnInstance)
};

// ScriptStruct ClamberingCodeRuntime.ReplicatedClamberingTargetingData
// 0x0078
struct FReplicatedClamberingTargetingData
{
	EClamberingType                                    Type_69;                                                  // 0x0000(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0001(0x0007) MISSED OFFSET
	struct FVector_NetQuantize10                       SourceLocation_69;                                        // 0x0008(0x0018)
	struct FVector_NetQuantize100                      WallLocation_69;                                          // 0x0020(0x0018)
	uint16_t                                           WallNormalYawQuantized_69;                                // 0x0038(0x0002) (ZeroConstructor, IsPlainOldData)
	uint16_t                                           WallNormalPitchQuantized_69;                              // 0x003A(0x0002) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x4];                                       // 0x003C(0x0004) MISSED OFFSET
	struct FVector_NetQuantize100                      TargetLocation_69;                                        // 0x0040(0x0018)
	uint16_t                                           TargetNormalYawQuantized_69;                              // 0x0058(0x0002) (ZeroConstructor, IsPlainOldData)
	uint16_t                                           TargetNormalPitchQuantized_69;                            // 0x005A(0x0002) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData02[0x4];                                       // 0x005C(0x0004) MISSED OFFSET
	class Actor_32759*                                 TargetActor_69;                                           // 0x0060(0x0008) (ZeroConstructor)
	class ActorComponent*                              TargetActorComponent_69;                                  // 0x0068(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	struct FName                                       TargetActorBoneName_69;                                   // 0x0070(0x0008) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData03[0x4];                                       // 0x0074(0x0004) MISSED OFFSET
};

// ScriptStruct ClamberingCodeRuntime.ClamberingTargetingDebugDrawData
// 0x0028
struct FClamberingTargetingDebugDrawData
{
	unsigned char                                      UnknownData00[0x28];                                      // 0x0000(0x0028) MISSED OFFSET
};

// ScriptStruct ClamberingCodeRuntime.ClamberingTargetingDebugDrawData_Capsule
// 0x0028 (0x0050 - 0x0028)
struct FClamberingTargetingDebugDrawData_Capsule : public FClamberingTargetingDebugDrawData
{
	unsigned char                                      UnknownData00[0x28];                                      // 0x0028(0x0028) MISSED OFFSET
};

// ScriptStruct ClamberingCodeRuntime.ClamberingTargetingDebugDrawData_Line
// 0x0018 (0x0040 - 0x0028)
struct FClamberingTargetingDebugDrawData_Line : public FClamberingTargetingDebugDrawData
{
	unsigned char                                      UnknownData00[0x18];                                      // 0x0028(0x0018) MISSED OFFSET
};

// ScriptStruct ClamberingCodeRuntime.ClamberingTargetingDebugDrawData_Sphere
// 0x0008 (0x0030 - 0x0028)
struct FClamberingTargetingDebugDrawData_Sphere : public FClamberingTargetingDebugDrawData
{
	unsigned char                                      UnknownData00[0x8];                                       // 0x0028(0x0008) MISSED OFFSET
};

// ScriptStruct ClamberingCodeRuntime.ClamberingTargetingDebugDrawData_DirectionalArrow
// 0x0020 (0x0048 - 0x0028)
struct FClamberingTargetingDebugDrawData_DirectionalArrow : public FClamberingTargetingDebugDrawData
{
	unsigned char                                      UnknownData00[0x20];                                      // 0x0028(0x0020) MISSED OFFSET
};

// ScriptStruct ClamberingCodeRuntime.ClamberingTargetingDebugDrawData_CapsuleCast
// 0x0020 (0x0070 - 0x0050)
struct FClamberingTargetingDebugDrawData_CapsuleCast : public FClamberingTargetingDebugDrawData_Capsule
{
	unsigned char                                      UnknownData00[0x20];                                      // 0x0050(0x0020) MISSED OFFSET
};

// ScriptStruct ClamberingCodeRuntime.ClamberingTargetingDebugDrawData_SphereCast
// 0x0018 (0x0048 - 0x0030)
struct FClamberingTargetingDebugDrawData_SphereCast : public FClamberingTargetingDebugDrawData_Sphere
{
	unsigned char                                      UnknownData00[0x18];                                      // 0x0030(0x0018) MISSED OFFSET
};

// ScriptStruct ClamberingCodeRuntime.ClamberingTargetingDebugData
// 0x0001
struct FClamberingTargetingDebugData
{
	unsigned char                                      UnknownData00[0x1];                                       // 0x0000(0x0001) MISSED OFFSET
};

// ScriptStruct ClamberingCodeRuntime.ClamberingTargetingDebugData_Ledge
// 0x0000 (0x0001 - 0x0001)
struct FClamberingTargetingDebugData_Ledge : public FClamberingTargetingDebugData
{

};

// ScriptStruct ClamberingCodeRuntime.ClamberingAnalytics_ClamberEvent
// 0x0028
struct FClamberingAnalytics_ClamberEvent
{
	int                                                MatchTime_69;                                             // 0x0000(0x0004) (ZeroConstructor, IsPlainOldData)
	EClamberingType                                    ClamberType_69;                                           // 0x0004(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0005(0x0003) MISSED OFFSET
	struct FVector                                     ClamberLocation_69;                                       // 0x0008(0x0018) (ZeroConstructor, IsPlainOldData)
	EClamberingFailedReason                            FailureReason_69;                                         // 0x0020(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x7];                                       // 0x0021(0x0007) MISSED OFFSET
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

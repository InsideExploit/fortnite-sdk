#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Classes
//---------------------------------------------------------------------------

// Class CustomizableObject.CustomizableInstanceLODManagementBase
// 0x0000 (0x0028 - 0x0028)
class CustomizableInstanceLODManagementBase : public Object_32759
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CustomizableObject.CustomizableInstanceLODManagementBase"));
		
		return ptr;
	}

};


// Class CustomizableObject.CustomizableInstanceLODManagement
// 0x0060 (0x0088 - 0x0028)
class CustomizableInstanceLODManagement : public CustomizableInstanceLODManagementBase
{
public:
	unsigned char                                      UnknownData00[0x60];                                      // 0x0028(0x0060) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CustomizableObject.CustomizableInstanceLODManagement"));
		
		return ptr;
	}

};


// Class CustomizableObject.CustomizableInstancePrivateData
// 0x0270 (0x0298 - 0x0028)
class CustomizableInstancePrivateData : public Object_32759
{
public:
	TArray<struct FGeneratedMaterial>                  GeneratedMaterials_69;                                    // 0x0028(0x0010) (ZeroConstructor, Transient)
	TArray<struct FGeneratedTexture>                   GeneratedTextures_69;                                     // 0x0038(0x0010) (ZeroConstructor, Transient)
	unsigned char                                      UnknownData00[0x50];                                      // 0x0048(0x0050) MISSED OFFSET
	TArray<struct FParameterDecorations>               ParameterDecorations_69;                                  // 0x0098(0x0010) (ZeroConstructor, Transient)
	unsigned char                                      UnknownData01[0x10];                                      // 0x00A8(0x0010) MISSED OFFSET
	TMap<struct FString, TWeakObjectPtr<class Texture2D>> TextureReuseCache_69;                                     // 0x00B8(0x0050) (Transient)
	unsigned char                                      UnknownData02[0x88];                                      // 0x0108(0x0088) MISSED OFFSET
	TArray<struct FCustomizableInstanceComponentData>  ComponentsData_69;                                        // 0x0190(0x0010) (ZeroConstructor, Transient)
	TArray<class MaterialInterface*>                   ReferencedMaterials_69;                                   // 0x01A0(0x0010) (ZeroConstructor, Transient)
	unsigned char                                      UnknownData03[0xA0];                                      // 0x01B0(0x00A0) MISSED OFFSET
	TArray<class PhysicsAsset*>                        ClothingPhysicsAssets_69;                                 // 0x0250(0x0010) (ZeroConstructor, Transient)
	TArray<class AnimInstance*>                        GatheredAnimBPs_69;                                       // 0x0260(0x0010) (Edit, EditFixedSize, ZeroConstructor, Transient, EditConst)
	struct FGameplayTagContainer                       AnimBPGameplayTags_69;                                    // 0x0270(0x0020) (Edit, EditFixedSize, Transient, EditConst)
	unsigned char                                      UnknownData04[0x8];                                       // 0x0290(0x0008) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CustomizableObject.CustomizableInstancePrivateData"));
		
		return ptr;
	}

};


// Class CustomizableObject.MutableMaskOutCache
// 0x00A0 (0x00C8 - 0x0028)
class MutableMaskOutCache : public Object_32759
{
public:
	TMap<struct FString, struct FString>               Materials_69;                                             // 0x0028(0x0050)
	TMap<struct FString, struct FMaskOutTexture>       Textures_69;                                              // 0x0078(0x0050)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CustomizableObject.MutableMaskOutCache"));
		
		return ptr;
	}

};


// Class CustomizableObject.CustomizableObjectBulk
// 0x0010 (0x0038 - 0x0028)
class CustomizableObjectBulk : public Object_32759
{
public:
	TArray<struct FString>                             BulkDataFileNames_69;                                     // 0x0028(0x0010) (ZeroConstructor)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CustomizableObject.CustomizableObjectBulk"));
		
		return ptr;
	}

};


// Class CustomizableObject.CustomizableObject
// 0x0388 (0x03B0 - 0x0028)
class CustomizableObject : public Object_32759
{
public:
	class SkeletalMesh*                                ReferenceSkeletalMesh_69;                                 // 0x0028(0x0008) (ZeroConstructor, Deprecated)
	TArray<class SkeletalMesh*>                        ReferenceSkeletalMeshes_69;                               // 0x0030(0x0010) (Edit, ZeroConstructor)
	TArray<struct FMutableRefSkeletalMeshData>         ReferenceSkeletalMeshesData_69;                           // 0x0040(0x0010) (ZeroConstructor, Transient)
	class StaticMesh*                                  ReferenceStaticMesh_69;                                   // 0x0050(0x0008) (ZeroConstructor)
	unsigned char                                      UnknownData00[0x10];                                      // 0x0058(0x0010) UNKNOWN PROPERTY: ArrayProperty CustomizableObject.CustomizableObject.ReferencedMaterials_69
	TArray<struct FName>                               ReferencedMaterialSlotNames_69;                           // 0x0068(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData01[0x10];                                      // 0x0078(0x0010) UNKNOWN PROPERTY: ArrayProperty CustomizableObject.CustomizableObject.ReferencedSkeletons_69
	struct FMutableLODSettings                         LODSettings_69;                                           // 0x0088(0x0010) (Edit)
	TArray<struct FMutableModelImageProperties>        ImageProperties_69;                                       // 0x0098(0x0010) (Edit, ZeroConstructor, EditConst)
	TArray<struct FMorphTargetInfo>                    ContributingMorphTargetsInfo_69;                          // 0x00A8(0x0010) (ZeroConstructor, Transient)
	TArray<struct FMorphTargetVertexData>              MorphTargetReconstructionData_69;                         // 0x00B8(0x0010) (ZeroConstructor, Transient)
	TArray<struct FCustomizableObjectClothConfigData>  ClothSharedConfigsData_69;                                // 0x00C8(0x0010) (ZeroConstructor, Transient)
	TArray<struct FCustomizableObjectClothingAssetData> ContributingClothingAssetsData_69;                        // 0x00D8(0x0010) (ZeroConstructor, Transient)
	TArray<struct FCustomizableObjectMeshToMeshVertData> ClothMeshToMeshVertData_69;                               // 0x00E8(0x0010) (ZeroConstructor, Transient)
	TArray<struct FMutableModelParameterProperties>    ParameterProperties_69;                                   // 0x00F8(0x0010) (ZeroConstructor, Transient)
	unsigned char                                      UnknownData02[0x50];                                      // 0x0108(0x0050) MISSED OFFSET
	TMap<struct FString, struct FParameterUIData>      ParameterUIDataMap_69;                                    // 0x0158(0x0050)
	TMap<struct FString, struct FParameterUIData>      StateUIDataMap_69;                                        // 0x01A8(0x0050)
	unsigned char                                      UnknownData03[0x50];                                      // 0x01F8(0x0050) UNKNOWN PROPERTY: MapProperty CustomizableObject.CustomizableObject.PhysicsAssetsMap_69
	unsigned char                                      UnknownData04[0x50];                                      // 0x0248(0x0050) UNKNOWN PROPERTY: MapProperty CustomizableObject.CustomizableObject.AnimBPAssetsMap_69
	unsigned char                                      UnknownData05[0x28];                                      // 0x0298(0x0028) UNKNOWN PROPERTY: SoftObjectProperty CustomizableObject.CustomizableObject.MaskOutCache_69
	TMap<uint64_t, struct FMutableStreamableBlock>     HashToStreamableBlock_69;                                 // 0x02C0(0x0050)
	TArray<struct FString>                             CustomizableObjectClassTags_69;                           // 0x0310(0x0010) (ZeroConstructor)
	TArray<struct FString>                             PopulationClassTags_69;                                   // 0x0320(0x0010) (ZeroConstructor)
	TMap<struct FString, struct FParameterTags>        CustomizableObjectParametersTags_69;                      // 0x0330(0x0050)
	class MutableMaskOutCache*                         MaskOutCache_HardRef_69;                                  // 0x0380(0x0008) (ZeroConstructor, Transient)
	struct FGuid                                       Identifier_69;                                            // 0x0388(0x0010) (ZeroConstructor, IsPlainOldData)
	class CustomizableObjectBulk*                      BulkData_69;                                              // 0x0398(0x0008) (ZeroConstructor)
	unsigned char                                      UnknownData06[0x10];                                      // 0x03A0(0x0010) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CustomizableObject.CustomizableObject"));
		
		return ptr;
	}


	void UnloadMaskOutCache();
	void LoadMaskOutCache();
	bool IsCompiled();
	struct FParameterUIData GetStateUIMetadataFromIndex(int StateIndex_69);
	struct FParameterUIData GetStateUIMetadata(const struct FString& StateName_69);
	struct FString GetStateParameterName(const struct FString& StateName_69, int ParameterIndex_69);
	int GetStateParameterCount(const struct FString& StateName_69);
	struct FString GetStateName(int StateIndex_69);
	int GetStateCount();
	struct FParameterUIData GetParameterUIMetadataFromIndex(int ParamIndex_69);
	struct FParameterUIData GetParameterUIMetadata(const struct FString& ParamName_69);
	EMutableParameterType GetParameterTypeByName(const struct FString& Name_69);
	EMutableParameterType GetParameterType(int ParamIndex_69);
	struct FString GetParameterName(int ParamIndex_69);
	int GetParameterDescriptionCount(const struct FString& ParamName_69);
	int GetParameterCount();
	int GetIntParameterNumOptions(int ParamIndex_69);
	struct FString GetIntParameterAvailableOption(int ParamIndex_69, int K_69);
	int FindParameter(const struct FString& Name_69);
	class CustomizableObjectInstance* CreateInstance();
};


// Class CustomizableObject.DGGUI
// 0x0008 (0x0270 - 0x0268)
class DGGUI : public UserWidget
{
public:
	unsigned char                                      UnknownData00[0x8];                                       // 0x0268(0x0008) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CustomizableObject.DGGUI"));
		
		return ptr;
	}


	void SetCustomizableSkeletalComponent(class CustomizableSkeletalComponent_32759* CustomizableSkeletalComponent_69);
	class CustomizableSkeletalComponent_32759* GetCustomizableSkeletalComponent();
};


// Class CustomizableObject.CustomizableObjectInstance
// 0x0280 (0x02A8 - 0x0028)
class CustomizableObjectInstance : public Object_32759
{
public:
	TArray<class SkeletalMesh*>                        SkeletalMeshes_69;                                        // 0x0028(0x0010) (Edit, ZeroConstructor, Transient, EditConst)
	bool                                               bBuildParameterDecorations_69;                            // 0x0038(0x0001) (Edit, BlueprintVisible, ZeroConstructor, Transient, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0039(0x0007) MISSED OFFSET
	unsigned char                                      UnknownData01[0x10];                                      // 0x0039(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty CustomizableObject.CustomizableObjectInstance.UpdatedDelegate_69
	unsigned char                                      UnknownData02[0x78];                                      // 0x0050(0x0078) MISSED OFFSET
	struct FString                                     SkeletalMeshStatus_69;                                    // 0x00C8(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData03[0x48];                                      // 0x00D8(0x0048) MISSED OFFSET
	struct FCustomizableObjectInstanceDescriptor       Descriptor_69;                                            // 0x0120(0x00C0)
	class CustomizableInstancePrivateData*             PrivateData_69;                                           // 0x01E0(0x0008) (ZeroConstructor, Transient)
	TMap<struct FName, struct FMultilayerProjector>    MultilayerProjectors_69;                                  // 0x01E8(0x0050)
	unsigned char                                      UnknownData04[0x8];                                       // 0x0238(0x0008) MISSED OFFSET
	class CustomizableObject*                          CustomizableObject_69;                                    // 0x0240(0x0008) (ZeroConstructor, Deprecated)
	TArray<struct FCustomizableObjectBoolParameterValue> BoolParameters_69;                                        // 0x0248(0x0010) (ZeroConstructor, Deprecated)
	TArray<struct FCustomizableObjectIntParameterValue> IntParameters_69;                                         // 0x0258(0x0010) (ZeroConstructor, Deprecated)
	TArray<struct FCustomizableObjectFloatParameterValue> FloatParameters_69;                                       // 0x0268(0x0010) (ZeroConstructor, Deprecated)
	TArray<struct FCustomizableObjectTextureParameterValue> TextureParameters_69;                                     // 0x0278(0x0010) (ZeroConstructor, Deprecated)
	TArray<struct FCustomizableObjectVectorParameterValue> VectorParameters_69;                                      // 0x0288(0x0010) (ZeroConstructor, Deprecated)
	TArray<struct FCustomizableObjectProjectorParameterValue> ProjectorParameters_69;                                   // 0x0298(0x0010) (ZeroConstructor, Deprecated)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CustomizableObject.CustomizableObjectInstance"));
		
		return ptr;
	}


	void UpdateSkeletalMeshAsync(bool bIgnoreCloseDist_69, bool bForceHighPriority_69);
	void SetVectorParameterSelectedOption(const struct FString& VectorParamName_69, const struct FLinearColor& VectorValue_69);
	void SetReplacePhysicsAssets(bool bReplaceEnabled_69);
	void SetRandomValues();
	void SetProjectorValue(const struct FString& ProjectorParamName_69, const struct FVector& OutPos_69, const struct FVector& OutDirection_69, const struct FVector& OutUp_69, const struct FVector& OutScale_69, float OutAngle_69, int RangeIndex_69);
	void SetObject(class CustomizableObject* InObject_69);
	void SetIntParameterSelectedOption(const struct FString& ParamName_69, const struct FString& SelectedOptionName_69, int RangeIndex_69);
	void SetFloatParameterSelectedOption(const struct FString& FloatParamName_69, float FloatValue_69, int RangeIndex_69);
	void SetCurrentState(const struct FString& StateName_69);
	void SetColorParameterSelectedOption(const struct FString& ColorParamName_69, const struct FLinearColor& ColorValue_69);
	void SetBoolParameterSelectedOption(const struct FString& BoolParamName_69, bool BoolValue_69);
	int RemoveValueFromProjectorRange(const struct FString& ParamName_69);
	int RemoveValueFromIntRange(const struct FString& ParamName_69);
	int RemoveValueFromFloatRange(const struct FString& ParamName_69);
	void RemoveMultilayerProjector(const struct FName& ProjectorParamName_69);
	void MultilayerProjectorUpdateVirtualLayer(const struct FName& ProjectorParamName_69, const struct FName& ID_69, const struct FMultilayerProjectorVirtualLayer& Layer_69);
	void MultilayerProjectorUpdateLayer(const struct FName& ProjectorParamName_69, int Index_69, const struct FMultilayerProjectorLayer& Layer_69);
	void MultilayerProjectorRemoveVirtualLayer(const struct FName& ProjectorParamName_69, const struct FName& ID_69);
	void MultilayerProjectorRemoveLayerAt(const struct FName& ProjectorParamName_69, int Index_69);
	int MultilayerProjectorNumLayers(const struct FName& ProjectorParamName_69);
	TArray<struct FName> MultilayerProjectorGetVirtualLayers(const struct FName& ProjectorParamName_69);
	struct FMultilayerProjectorVirtualLayer MultilayerProjectorGetVirtualLayer(const struct FName& ProjectorParamName_69, const struct FName& ID_69);
	struct FMultilayerProjectorLayer MultilayerProjectorGetLayer(const struct FName& ProjectorParamName_69, int Index_69);
	struct FMultilayerProjectorVirtualLayer MultilayerProjectorFindOrCreateVirtualLayer(const struct FName& ProjectorParamName_69, const struct FName& ID_69);
	void MultilayerProjectorCreateVirtualLayer(const struct FName& ProjectorParamName_69, const struct FName& ID_69);
	void MultilayerProjectorCreateLayer(const struct FName& ProjectorParamName_69, int Index_69);
	bool IsParamMultidimensional(const struct FString& ParamName_69);
	bool IsParameterRelevant(const struct FString& ParamName_69);
	bool HasAnySkeletalMesh();
	bool HasAnyParameters();
	TArray<struct FCustomizableObjectVectorParameterValue> GetVectorParameters();
	TArray<struct FCustomizableObjectTextureParameterValue> GetTextureParameters();
	class SkeletalMesh* GetSkeletalMesh(int ComponentIndex_69);
	void GetProjectorValue(const struct FString& ProjectorParamName_69, int RangeIndex_69, struct FVector* OutPos_69, struct FVector* OutDirection_69, struct FVector* OutUp_69, struct FVector* OutScale_69, float* OutAngle_69, ECustomizableObjectProjectorType* OutType_69);
	struct FVector GetProjectorUp(const struct FString& ParamName_69, int RangeIndex_69);
	struct FVector GetProjectorScale(const struct FString& ParamName_69, int RangeIndex_69);
	struct FVector GetProjectorPosition(const struct FString& ParamName_69, int RangeIndex_69);
	ECustomizableObjectProjectorType GetProjectorParameterType(const struct FString& ParamName_69, int RangeIndex_69);
	TArray<struct FCustomizableObjectProjectorParameterValue> GetProjectorParameters();
	struct FVector GetProjectorDirection(const struct FString& ParamName_69, int RangeIndex_69);
	float GetProjectorAngle(const struct FString& ParamName_69, int RangeIndex_69);
	class Texture2D* GetParameterDescription(const struct FString& ParamName_69, int DescIndex_69);
	struct FString GetIntParameterSelectedOption(const struct FString& ParamName_69, int RangeIndex_69);
	TArray<struct FCustomizableObjectIntParameterValue> GetIntParameters();
	float GetFloatParameterSelectedOption(const struct FString& FloatParamName_69, int RangeIndex_69);
	TArray<struct FCustomizableObjectFloatParameterValue> GetFloatParameters();
	class CustomizableObject* GetCustomizableObject();
	struct FString GetCurrentState();
	struct FLinearColor GetColorParameterSelectedOption(const struct FString& ColorParamName_69);
	bool GetBoolParameterSelectedOption(const struct FString& BoolParamName_69);
	TArray<struct FCustomizableObjectBoolParameterValue> GetBoolParameters();
	class AnimInstance* GetAnimBP(int ComponentIndex_69, int SlotIndex_69);
	struct FGameplayTagContainer GetAnimationGameplayTags();
	void ForEachAnimInstance(int ComponentIndex_69, const struct FScriptDelegate& Delegate_69);
	int FindVectorParameterNameIndex(const struct FString& ParamName_69);
	int FindProjectorParameterNameIndex(const struct FString& ParamName_69);
	int FindIntParameterNameIndex(const struct FString& ParamName_69);
	int FindFloatParameterNameIndex(const struct FString& ParamName_69);
	int FindBoolParameterNameIndex(const struct FString& ParamName_69);
	int CurrentParamRange(const struct FString& ParamName_69);
	bool CreateMultiLayerProjector(const struct FName& ProjectorParamName_69);
	class CustomizableObjectInstance* CloneStatic(class Object_32759* Outer_69);
	class CustomizableObjectInstance* Clone();
	int AddValueToProjectorRange(const struct FString& ParamName_69);
	int AddValueToIntRange(const struct FString& ParamName_69);
	int AddValueToFloatRange(const struct FString& ParamName_69);
};


// Class CustomizableObject.CustomizableSkeletalComponent_32759
// 0x0040 (0x02E0 - 0x02A0)
class CustomizableSkeletalComponent_32759 : public SceneComponent
{
public:
	unsigned char                                      UnknownData00[0x4];                                       // 0x02A0(0x0004) MISSED OFFSET
	float                                              SkippedLastRenderTime_69;                                 // 0x02A4(0x0004) (ZeroConstructor, Transient, IsPlainOldData)
	class CustomizableObjectInstance*                  CustomizableObjectInstance_69;                            // 0x02A8(0x0008) (Edit, BlueprintVisible, ZeroConstructor)
	int                                                ComponentIndex_69;                                        // 0x02B0(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x2C];                                      // 0x02B4(0x002C) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CustomizableObject.CustomizableSkeletalComponent_32759"));
		
		return ptr;
	}


	void UpdateSkeletalMeshAsync(bool bNeverSkipUpdate_69);
};


// Class CustomizableObject.CustomizableSkeletalMeshActor
// 0x0028 (0x0330 - 0x0308)
class CustomizableSkeletalMeshActor : public SkeletalMeshActor
{
public:
	TArray<class CustomizableSkeletalComponent_32759*> CustomizableSkeletalComponents_69;                        // 0x0308(0x0010) (Edit, BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, EditConst)
	TArray<class SkeletalMeshComponent*>               SkeletalMeshComponents_69;                                // 0x0318(0x0010) (Edit, BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, EditConst)
	class CustomizableSkeletalComponent_32759*         CustomizableSkeletalComponent_69;                         // 0x0328(0x0008) (Edit, BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, EditConst, InstancedReference)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CustomizableObject.CustomizableSkeletalMeshActor"));
		
		return ptr;
	}

};


// Class CustomizableObject.MutableTextureMipDataProviderFactory
// 0x0028 (0x0050 - 0x0028)
class MutableTextureMipDataProviderFactory : public TextureMipDataProviderFactory
{
public:
	class CustomizableObjectInstance*                  CustomizableObjectInstance_69;                            // 0x0028(0x0008) (ZeroConstructor, Transient)
	unsigned char                                      UnknownData00[0x20];                                      // 0x0030(0x0020) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CustomizableObject.MutableTextureMipDataProviderFactory"));
		
		return ptr;
	}

};


// Class CustomizableObject.CustomizableSystemImageProvider
// 0x0000 (0x0028 - 0x0028)
class CustomizableSystemImageProvider : public Object_32759
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CustomizableObject.CustomizableSystemImageProvider"));
		
		return ptr;
	}

};


// Class CustomizableObject.CustomizableObjectImageProviderArray
// 0x0030 (0x0058 - 0x0028)
class CustomizableObjectImageProviderArray : public CustomizableSystemImageProvider
{
public:
	TArray<class Texture2D*>                           Textures_69;                                              // 0x0028(0x0010) (Edit, ZeroConstructor)
	unsigned char                                      UnknownData00[0x20];                                      // 0x0038(0x0020) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CustomizableObject.CustomizableObjectImageProviderArray"));
		
		return ptr;
	}

};


// Class CustomizableObject.CustomizableObjectSystem
// 0x0148 (0x0170 - 0x0028)
class CustomizableObjectSystem : public Object_32759
{
public:
	TArray<struct FPendingReleaseSkeletalMeshInfo>     PendingReleaseSkeletalMesh_69;                            // 0x0028(0x0010) (ZeroConstructor)
	class CustomizableObjectImageProviderArray*        PreviewExternalImageProvider_69;                          // 0x0038(0x0008) (ZeroConstructor)
	class CustomizableInstanceLODManagementBase*       DefaultInstanceLODManagement_69;                          // 0x0040(0x0008) (ZeroConstructor, Transient)
	class CustomizableInstanceLODManagementBase*       CurrentInstanceLODManagement_69;                          // 0x0048(0x0008) (ZeroConstructor, Transient)
	TArray<class Texture2D*>                           ProtectedCachedTextures_69;                               // 0x0050(0x0010) (ZeroConstructor, Transient)
	unsigned char                                      UnknownData00[0x110];                                     // 0x0060(0x0110) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CustomizableObject.CustomizableObjectSystem"));
		
		return ptr;
	}


	void SetReleaseMutableTexturesImmediately(bool bReleaseTextures_69);
	int GetTotalInstances();
	int GetTextureMemoryUsed();
	struct FString GetPluginVersion();
	int GetNumPendingInstances();
	int GetNumInstances();
	class CustomizableObjectSystem* STATIC_GetInstance();
	int GetAverageBuildTime();
};


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

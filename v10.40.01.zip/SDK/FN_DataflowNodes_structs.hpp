#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Script Structs
//---------------------------------------------------------------------------

// ScriptStruct DataflowNodes.GetSkeletalMeshDataflowNode
// 0x0020 (0x0068 - 0x0048)
struct FGetSkeletalMeshDataflowNode : public FDataflowNode
{
	class SkeletalMesh*                                SkeletalMesh_69;                                          // 0x0048(0x0008) (Edit, ZeroConstructor)
	struct FName                                       PropertyName_69;                                          // 0x0050(0x0008) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x14];                                      // 0x0054(0x0014) MISSED OFFSET
};

// ScriptStruct DataflowNodes.SkeletalMeshBoneDataflowNode
// 0x0028 (0x0070 - 0x0048)
struct FSkeletalMeshBoneDataflowNode : public FDataflowNode
{
	struct FName                                       BoneName_69;                                              // 0x0048(0x0008) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x24];                                      // 0x004C(0x0024) MISSED OFFSET
};

// ScriptStruct DataflowNodes.GetStaticMeshDataflowNode
// 0x0020 (0x0068 - 0x0048)
struct FGetStaticMeshDataflowNode : public FDataflowNode
{
	class StaticMesh*                                  StaticMesh_69;                                            // 0x0048(0x0008) (Edit, ZeroConstructor)
	struct FName                                       PropertyName_69;                                          // 0x0050(0x0008) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x14];                                      // 0x0054(0x0014) MISSED OFFSET
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function AIPatrolPath.AIPatrolPathComponent.SyncSharedUserOptions
struct AIPatrolPathComponent_SyncSharedUserOptions_Params
{
	class AIPatrolPathComponent*                       CopyToAIPatrolPathComp_69;                                // (Parm, ZeroConstructor, InstancedReference)
	TMap<struct FString, struct FString>               UserOptionValues_69;                                      // (ConstParm, Parm, OutParm, ReferenceParm)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AIPatrolPath.AIPatrolPathComponent.ShouldRenderPath
struct AIPatrolPathComponent_ShouldRenderPath_Params
{
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AIPatrolPath.AIPatrolPathComponent.SetRenderPath
struct AIPatrolPathComponent_SetRenderPath_Params
{
	bool                                               bRenderPath_69;                                           // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function AIPatrolPath.AIPatrolPathComponent.SetPatrolPathGroup
struct AIPatrolPathComponent_SetPatrolPathGroup_Params
{
	EFortCreativePatrolPathGroup                       PatrolPathGroup_69;                                       // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function AIPatrolPath.AIPatrolPathComponent.SetPatrolPathEnabled
struct AIPatrolPathComponent_SetPatrolPathEnabled_Params
{
	bool                                               bIsEnabled_69;                                            // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function AIPatrolPath.AIPatrolPathComponent.SetPatrollingMode
struct AIPatrolPathComponent_SetPatrollingMode_Params
{
	EPatrollingMode                                    NewMode_69;                                               // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function AIPatrolPath.AIPatrolPathComponent.RequestRenderPath
struct AIPatrolPathComponent_RequestRenderPath_Params
{
};

// Function AIPatrolPath.AIPatrolPathComponent.RenderToNextPoint
struct AIPatrolPathComponent_RenderToNextPoint_Params
{
};

// Function AIPatrolPath.AIPatrolPathComponent.RenderToNextAndPreviousPoint
struct AIPatrolPathComponent_RenderToNextAndPreviousPoint_Params
{
};

// Function AIPatrolPath.AIPatrolPathComponent.RemovePoint
struct AIPatrolPathComponent_RemovePoint_Params
{
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AIPatrolPath.AIPatrolPathComponent.PatrolPointReached
struct AIPatrolPathComponent_PatrolPointReached_Params
{
	class FortAthenaPatrolPoint*                       PathPoint_69;                                             // (Parm, ZeroConstructor)
	class AIController*                                Instigator_69;                                            // (Parm, ZeroConstructor)
};

// Function AIPatrolPath.AIPatrolPathComponent.PatrolPointFailedToReach
struct AIPatrolPathComponent_PatrolPointFailedToReach_Params
{
	class FortAthenaPatrolPoint*                       PathPoint_69;                                             // (Parm, ZeroConstructor)
	class AIController*                                Instigator_69;                                            // (Parm, ZeroConstructor)
};

// Function AIPatrolPath.AIPatrolPathComponent.PatrolPathStopped
struct AIPatrolPathComponent_PatrolPathStopped_Params
{
	class AIController*                                Instigator_69;                                            // (Parm, ZeroConstructor)
};

// Function AIPatrolPath.AIPatrolPathComponent.PatrolPathStarted
struct AIPatrolPathComponent_PatrolPathStarted_Params
{
	class AIController*                                Instigator_69;                                            // (Parm, ZeroConstructor)
};

// Function AIPatrolPath.AIPatrolPathComponent.OnPatrolPathGroupsMerged
struct AIPatrolPathComponent_OnPatrolPathGroupsMerged_Params
{
};

// Function AIPatrolPath.AIPatrolPathComponent.OnPatrolPathActorAssigned
struct AIPatrolPathComponent_OnPatrolPathActorAssigned_Params
{
};

// Function AIPatrolPath.AIPatrolPathComponent.OnPathExtremitiesChanged
struct AIPatrolPathComponent_OnPathExtremitiesChanged_Params
{
	bool                                               bIsStart_69;                                              // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bIsEnd_69;                                                // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function AIPatrolPath.AIPatrolPathComponent.HasValidPatrolPath
struct AIPatrolPathComponent_HasValidPatrolPath_Params
{
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AIPatrolPath.AIPatrolPathComponent.GetPatrolPathPointIndex
struct AIPatrolPathComponent_GetPatrolPathPointIndex_Params
{
	int                                                ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AIPatrolPath.AIPatrolPathComponent.GetPatrolPathPoint
struct AIPatrolPathComponent_GetPatrolPathPoint_Params
{
	int                                                InPatrolPathIndex_69;                                     // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	int                                                InPatrolPathPointIndex_69;                                // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	class AIPatrolPathComponent*                       ReturnValue_69;                                           // (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)
};

// Function AIPatrolPath.AIPatrolPathComponent.GetPatrolPathIndex
struct AIPatrolPathComponent_GetPatrolPathIndex_Params
{
	int                                                ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AIPatrolPath.AIPatrolPathComponent.GetPatrolFilterOptions
struct AIPatrolPathComponent_GetPatrolFilterOptions_Params
{
	class NavigationQueryFilter*                       ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function AIPatrolPath.AIPatrolPathComponent.GetNextAvailablePatrolPathIndex
struct AIPatrolPathComponent_GetNextAvailablePatrolPathIndex_Params
{
	int                                                NextAvailableIndex_69;                                    // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AIPatrolPath.AIPatrolPathComponent.GetLinkedPatrolPoints
struct AIPatrolPathComponent_GetLinkedPatrolPoints_Params
{
	TArray<class AIPatrolPathComponent*>               ReturnValue_69;                                           // (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function AIPatrolPath.AIPatrolPathComponent.GeneratePathPoints
struct AIPatrolPathComponent_GeneratePathPoints_Params
{
	EFortCreativePatrolPathGroup                       PatrolPathGroup_69;                                       // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function AIPatrolPath.AIPatrolPathComponent.CanNextPointBeReached
struct AIPatrolPathComponent_CanNextPointBeReached_Params
{
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

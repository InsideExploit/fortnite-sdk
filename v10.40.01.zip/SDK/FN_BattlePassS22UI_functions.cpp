// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Functions
//---------------------------------------------------------------------------

// Function BattlePassS22UI.BattlePassLandingPageS22.OnBattlePassSubscriptionAllowed
// (Event, Public, BlueprintEvent)
// Parameters:
// bool                           bSubscriptionAllowed_69        (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void BattlePassLandingPageS22::OnBattlePassSubscriptionAllowed(bool bSubscriptionAllowed_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function BattlePassS22UI.BattlePassLandingPageS22.OnBattlePassSubscriptionAllowed"));

	BattlePassLandingPageS22_OnBattlePassSubscriptionAllowed_Params params;
	params.bSubscriptionAllowed_69 = bSubscriptionAllowed_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function BattlePassS22UI.BattlePassLandingPageS22.OnBattlePassOwned
// (Event, Public, BlueprintEvent)

void BattlePassLandingPageS22::OnBattlePassOwned()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function BattlePassS22UI.BattlePassLandingPageS22.OnBattlePassOwned"));

	BattlePassLandingPageS22_OnBattlePassOwned_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function BattlePassS22UI.BattlePassLandingPageS22.OnBattlePassGiftingAllowed
// (Event, Public, BlueprintEvent)
// Parameters:
// bool                           bGiftingAllowed_69             (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void BattlePassLandingPageS22::OnBattlePassGiftingAllowed(bool bGiftingAllowed_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function BattlePassS22UI.BattlePassLandingPageS22.OnBattlePassGiftingAllowed"));

	BattlePassLandingPageS22_OnBattlePassGiftingAllowed_Params params;
	params.bGiftingAllowed_69 = bGiftingAllowed_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function BattlePassS22UI.BattlePassRewardPageS22.OnPageChanged
// (Event, Public, BlueprintEvent)
// Parameters:
// int                            PageNumber_69                  (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void BattlePassRewardPageS22::OnPageChanged(int PageNumber_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function BattlePassS22UI.BattlePassRewardPageS22.OnPageChanged"));

	BattlePassRewardPageS22_OnPageChanged_Params params;
	params.PageNumber_69 = PageNumber_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function BattlePassS22UI.BattlePassRewardPageS22.OnInputMethodChanged
// (Event, Protected, BlueprintEvent)
// Parameters:
// ECommonInputType               InputType_69                   (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void BattlePassRewardPageS22::OnInputMethodChanged(ECommonInputType InputType_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function BattlePassS22UI.BattlePassRewardPageS22.OnInputMethodChanged"));

	BattlePassRewardPageS22_OnInputMethodChanged_Params params;
	params.InputType_69 = InputType_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function BattlePassS22UI.BattlePassRewardPageS22.OnInitForPageType
// (Event, Public, BlueprintEvent)
// Parameters:
// ERewardPageType                InRewardPageType_69            (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void BattlePassRewardPageS22::OnInitForPageType(ERewardPageType InRewardPageType_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function BattlePassS22UI.BattlePassRewardPageS22.OnInitForPageType"));

	BattlePassRewardPageS22_OnInitForPageType_Params params;
	params.InRewardPageType_69 = InRewardPageType_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function BattlePassS22UI.BattlePassScreenS22.OverviewShowAnimationFinished
// (Final, Native, Public, BlueprintCallable)

void BattlePassScreenS22::OverviewShowAnimationFinished()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function BattlePassS22UI.BattlePassScreenS22.OverviewShowAnimationFinished"));

	BattlePassScreenS22_OverviewShowAnimationFinished_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function BattlePassS22UI.BattlePassScreenS22.OnTransitionItemDetails
// (Event, Protected, BlueprintEvent)
// Parameters:
// bool                           bTransitionForward_69          (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void BattlePassScreenS22::OnTransitionItemDetails(bool bTransitionForward_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function BattlePassS22UI.BattlePassScreenS22.OnTransitionItemDetails"));

	BattlePassScreenS22_OnTransitionItemDetails_Params params;
	params.bTransitionForward_69 = bTransitionForward_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function BattlePassS22UI.BattlePassScreenS22.OnSetResourcePrice
// (Event, Protected, BlueprintEvent)
// Parameters:
// int                            Cost_69                        (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// class FortPersistentResourceItemDefinition* PersistentResource_69          (ConstParm, Parm, ZeroConstructor)

void BattlePassScreenS22::OnSetResourcePrice(int Cost_69, class FortPersistentResourceItemDefinition* PersistentResource_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function BattlePassS22UI.BattlePassScreenS22.OnSetResourcePrice"));

	BattlePassScreenS22_OnSetResourcePrice_Params params;
	params.Cost_69 = Cost_69;
	params.PersistentResource_69 = PersistentResource_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function BattlePassS22UI.BattlePassScreenS22.OnSetPrerequisiteInfo
// (Event, Protected, HasOutParms, BlueprintEvent)
// Parameters:
// struct FText                   Description_69                 (ConstParm, Parm, OutParm, ReferenceParm)
// int                            OwnedRewards_69                (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// int                            NeededRewards_69               (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// bool                           bShowPrerequisiteLock_69       (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void BattlePassScreenS22::OnSetPrerequisiteInfo(const struct FText& Description_69, int OwnedRewards_69, int NeededRewards_69, bool bShowPrerequisiteLock_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function BattlePassS22UI.BattlePassScreenS22.OnSetPrerequisiteInfo"));

	BattlePassScreenS22_OnSetPrerequisiteInfo_Params params;
	params.Description_69 = Description_69;
	params.OwnedRewards_69 = OwnedRewards_69;
	params.NeededRewards_69 = NeededRewards_69;
	params.bShowPrerequisiteLock_69 = bShowPrerequisiteLock_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function BattlePassS22UI.BattlePassScreenS22.OnSetItemPrice
// (Event, Protected, BlueprintEvent)
// Parameters:
// int                            Cost_69                        (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// EBattlePassCurrencyType        CurrencyType_69                (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void BattlePassScreenS22::OnSetItemPrice(int Cost_69, EBattlePassCurrencyType CurrencyType_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function BattlePassS22UI.BattlePassScreenS22.OnSetItemPrice"));

	BattlePassScreenS22_OnSetItemPrice_Params params;
	params.Cost_69 = Cost_69;
	params.CurrencyType_69 = CurrencyType_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function BattlePassS22UI.BattlePassScreenS22.OnSetDynamicInput
// (Event, Protected, BlueprintEvent)
// Parameters:
// EBattlePassInputs              InputType_69                   (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// class BattlePassInputData*     InputData_69                   (ConstParm, Parm, ZeroConstructor)

void BattlePassScreenS22::OnSetDynamicInput(EBattlePassInputs InputType_69, class BattlePassInputData* InputData_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function BattlePassS22UI.BattlePassScreenS22.OnSetDynamicInput"));

	BattlePassScreenS22_OnSetDynamicInput_Params params;
	params.InputType_69 = InputType_69;
	params.InputData_69 = InputData_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function BattlePassS22UI.BattlePassScreenS22.OnSetClaimedRewardInfo
// (Event, Protected, BlueprintEvent)
// Parameters:
// int                            OwnedRewards_69                (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// int                            TotalRewards_69                (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void BattlePassScreenS22::OnSetClaimedRewardInfo(int OwnedRewards_69, int TotalRewards_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function BattlePassS22UI.BattlePassScreenS22.OnSetClaimedRewardInfo"));

	BattlePassScreenS22_OnSetClaimedRewardInfo_Params params;
	params.OwnedRewards_69 = OwnedRewards_69;
	params.TotalRewards_69 = TotalRewards_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function BattlePassS22UI.BattlePassScreenS22.OnLevelChanged
// (Event, Protected, BlueprintEvent)
// Parameters:
// int                            Level_69                       (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void BattlePassScreenS22::OnLevelChanged(int Level_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function BattlePassS22UI.BattlePassScreenS22.OnLevelChanged"));

	BattlePassScreenS22_OnLevelChanged_Params params;
	params.Level_69 = Level_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function BattlePassS22UI.BattlePassScreenS22.OnItemDelayed
// (Event, Protected, HasDefaults, BlueprintEvent)
// Parameters:
// struct FTimespan               Delay_69                       (ConstParm, Parm, ZeroConstructor)

void BattlePassScreenS22::OnItemDelayed(const struct FTimespan& Delay_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function BattlePassS22UI.BattlePassScreenS22.OnItemDelayed"));

	BattlePassScreenS22_OnItemDelayed_Params params;
	params.Delay_69 = Delay_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function BattlePassS22UI.BattlePassScreenS22.OnInsufficientResource
// (Event, Protected, BlueprintEvent)
// Parameters:
// class FortPersistentResourceItemDefinition* PersistentResource_69          (ConstParm, Parm, ZeroConstructor)

void BattlePassScreenS22::OnInsufficientResource(class FortPersistentResourceItemDefinition* PersistentResource_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function BattlePassS22UI.BattlePassScreenS22.OnInsufficientResource"));

	BattlePassScreenS22_OnInsufficientResource_Params params;
	params.PersistentResource_69 = PersistentResource_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function BattlePassS22UI.BattlePassScreenS22.OnInsufficientFunds
// (Event, Protected, BlueprintEvent)
// Parameters:
// EBattlePassCurrencyType        CurrencyType_69                (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void BattlePassScreenS22::OnInsufficientFunds(EBattlePassCurrencyType CurrencyType_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function BattlePassS22UI.BattlePassScreenS22.OnInsufficientFunds"));

	BattlePassScreenS22_OnInsufficientFunds_Params params;
	params.CurrencyType_69 = CurrencyType_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function BattlePassS22UI.BattlePassScreenS22.OnBattlePassOwned
// (Event, Protected, BlueprintEvent)

void BattlePassScreenS22::OnBattlePassOwned()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function BattlePassS22UI.BattlePassScreenS22.OnBattlePassOwned"));

	BattlePassScreenS22_OnBattlePassOwned_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function BattlePassS22UI.BattlePassScreenS22.IsSeasonalCustomizationItemOwned
// (Final, Native, Protected, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool BattlePassScreenS22::IsSeasonalCustomizationItemOwned()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function BattlePassS22UI.BattlePassScreenS22.IsSeasonalCustomizationItemOwned"));

	BattlePassScreenS22_IsSeasonalCustomizationItemOwned_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function BattlePassS22UI.BattlePassScreenS22.HandleSwitcherVisibilityShown
// (Final, Native, Public, BlueprintCallable)

void BattlePassScreenS22::HandleSwitcherVisibilityShown()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function BattlePassS22UI.BattlePassScreenS22.HandleSwitcherVisibilityShown"));

	BattlePassScreenS22_HandleSwitcherVisibilityShown_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function BattlePassS22UI.BattlePassScreenS22.HandleClaimRewardComplete
// (Final, Native, Private, HasOutParms)
// Parameters:
// bool                           bSuccess_69                    (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// TArray<struct FString>         OfferTemplateIdList_69         (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)

void BattlePassScreenS22::HandleClaimRewardComplete(bool bSuccess_69, TArray<struct FString> OfferTemplateIdList_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function BattlePassS22UI.BattlePassScreenS22.HandleClaimRewardComplete"));

	BattlePassScreenS22_HandleClaimRewardComplete_Params params;
	params.bSuccess_69 = bSuccess_69;
	params.OfferTemplateIdList_69 = OfferTemplateIdList_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function BattlePassS22UI.BattlePassScreenS22.GetQuestPageDelay
// (Final, Native, Protected, HasDefaults, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FTimespan               ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FTimespan BattlePassScreenS22::GetQuestPageDelay()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function BattlePassS22UI.BattlePassScreenS22.GetQuestPageDelay"));

	BattlePassScreenS22_GetQuestPageDelay_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function BattlePassS22UI.FortBattlePassResourcesWidgetS22.OnStylePointsRewardsSet
// (Event, Protected, BlueprintEvent)
// Parameters:
// int                            Rewards_69                     (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void FortBattlePassResourcesWidgetS22::OnStylePointsRewardsSet(int Rewards_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function BattlePassS22UI.FortBattlePassResourcesWidgetS22.OnStylePointsRewardsSet"));

	FortBattlePassResourcesWidgetS22_OnStylePointsRewardsSet_Params params;
	params.Rewards_69 = Rewards_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function BattlePassS22UI.FortBattlePassResourcesWidgetS22.OnBattleStarRewardsSet
// (Event, Protected, BlueprintEvent)
// Parameters:
// int                            Rewards_69                     (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void FortBattlePassResourcesWidgetS22::OnBattleStarRewardsSet(int Rewards_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function BattlePassS22UI.FortBattlePassResourcesWidgetS22.OnBattleStarRewardsSet"));

	FortBattlePassResourcesWidgetS22_OnBattleStarRewardsSet_Params params;
	params.Rewards_69 = Rewards_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function BattlePassS22UI.FortBattlePassTutorialTooltipS22.ShowTooltip
// (Event, Protected, BlueprintEvent)

void FortBattlePassTutorialTooltipS22::ShowTooltip()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function BattlePassS22UI.FortBattlePassTutorialTooltipS22.ShowTooltip"));

	FortBattlePassTutorialTooltipS22_ShowTooltip_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function BattlePassS22UI.FortBattlePassTutorialTooltipS22.SetText
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// struct FText                   Text_69                        (Parm)

void FortBattlePassTutorialTooltipS22::SetText(const struct FText& Text_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function BattlePassS22UI.FortBattlePassTutorialTooltipS22.SetText"));

	FortBattlePassTutorialTooltipS22_SetText_Params params;
	params.Text_69 = Text_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function BattlePassS22UI.FortBattlePassTutorialTooltipS22.HideTooltip
// (Event, Protected, BlueprintEvent)

void FortBattlePassTutorialTooltipS22::HideTooltip()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function BattlePassS22UI.FortBattlePassTutorialTooltipS22.HideTooltip"));

	FortBattlePassTutorialTooltipS22_HideTooltip_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function BattlePassS22UI.RebootRallyQuestPanel.OnRebootRallyEligibilityUpdated
// (Event, Public, BlueprintEvent)
// Parameters:
// bool                           bEligible_69                   (Parm, ZeroConstructor, IsPlainOldData)

void RebootRallyQuestPanel::OnRebootRallyEligibilityUpdated(bool bEligible_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function BattlePassS22UI.RebootRallyQuestPanel.OnRebootRallyEligibilityUpdated"));

	RebootRallyQuestPanel_OnRebootRallyEligibilityUpdated_Params params;
	params.bEligible_69 = bEligible_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

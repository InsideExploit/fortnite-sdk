#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function AudioGameplay_FunctionLibrary.AudioGameplay_FunctionLibrary_C.GetAudioForPlayerEvent
struct AudioGameplay_FunctionLibrary_C_GetAudioForPlayerEvent_Params
{
	class Actor_32759*                                 Target_1;                                                 // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor)
	class SoundBase*                                   _1P_Sound_1;                                              // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor)
	class SoundBase*                                   _3P_Sound_1;                                              // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor)
	class Object_32759*                                __WorldContext_1;                                         // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor)
	class SoundBase*                                   AudioAsset_1;                                             // (Parm, OutParm, ZeroConstructor)
};

// Function AudioGameplay_FunctionLibrary.AudioGameplay_FunctionLibrary_C.IsActorLocal
struct AudioGameplay_FunctionLibrary_C_IsActorLocal_Params
{
	class Actor_32759*                                 Actor_1;                                                  // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor)
	class Object_32759*                                __WorldContext_1;                                         // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor)
	bool                                               ReturnValue_1;                                            // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AudioGameplay_FunctionLibrary.AudioGameplay_FunctionLibrary_C.GetAudioForDamageEvent
struct AudioGameplay_FunctionLibrary_C_GetAudioForDamageEvent_Params
{
	class Actor_32759*                                 Receiver_1;                                               // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor)
	class Actor_32759*                                 Instigator_1;                                             // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor)
	class SoundBase*                                   ReceiverSound_1;                                          // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor)
	class SoundBase*                                   InstigatorSound_1;                                        // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor)
	class SoundBase*                                   ObserverSound_1;                                          // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor)
	class Object_32759*                                __WorldContext_1;                                         // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor)
	class SoundBase*                                   AudioAsset_1;                                             // (Parm, OutParm, ZeroConstructor)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

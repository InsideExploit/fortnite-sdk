// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Functions
//---------------------------------------------------------------------------

// Function AssetRegistry.AssetRegistryHelpers.ToSoftObjectPath
// (Final, Native, Static, Public, HasOutParms, HasDefaults, BlueprintCallable, BlueprintPure)
// Parameters:
// struct FAssetData              InAssetData_69                 (ConstParm, Parm, OutParm, ReferenceParm)
// struct FSoftObjectPath         ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FSoftObjectPath AssetRegistryHelpers::STATIC_ToSoftObjectPath(const struct FAssetData& InAssetData_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AssetRegistry.AssetRegistryHelpers.ToSoftObjectPath"));

	AssetRegistryHelpers_ToSoftObjectPath_Params params;
	params.InAssetData_69 = InAssetData_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AssetRegistry.AssetRegistryHelpers.SetFilterTagsAndValues
// (Final, Native, Static, Public, HasOutParms, HasDefaults, BlueprintCallable, BlueprintPure)
// Parameters:
// struct FARFilter               InFilter_69                    (ConstParm, Parm, OutParm, ReferenceParm)
// TArray<struct FTagAndValue>    InTagsAndValues_69             (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
// struct FARFilter               ReturnValue_69                 (Parm, OutParm, ReturnParm)

struct FARFilter AssetRegistryHelpers::STATIC_SetFilterTagsAndValues(const struct FARFilter& InFilter_69, TArray<struct FTagAndValue> InTagsAndValues_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AssetRegistry.AssetRegistryHelpers.SetFilterTagsAndValues"));

	AssetRegistryHelpers_SetFilterTagsAndValues_Params params;
	params.InFilter_69 = InFilter_69;
	params.InTagsAndValues_69 = InTagsAndValues_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AssetRegistry.AssetRegistryHelpers.IsValid
// (Final, Native, Static, Public, HasOutParms, HasDefaults, BlueprintCallable, BlueprintPure)
// Parameters:
// struct FAssetData              InAssetData_69                 (ConstParm, Parm, OutParm, ReferenceParm)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool AssetRegistryHelpers::STATIC_IsValid(const struct FAssetData& InAssetData_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AssetRegistry.AssetRegistryHelpers.IsValid"));

	AssetRegistryHelpers_IsValid_Params params;
	params.InAssetData_69 = InAssetData_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AssetRegistry.AssetRegistryHelpers.IsUAsset
// (Final, Native, Static, Public, HasOutParms, HasDefaults, BlueprintCallable, BlueprintPure)
// Parameters:
// struct FAssetData              InAssetData_69                 (ConstParm, Parm, OutParm, ReferenceParm)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool AssetRegistryHelpers::STATIC_IsUAsset(const struct FAssetData& InAssetData_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AssetRegistry.AssetRegistryHelpers.IsUAsset"));

	AssetRegistryHelpers_IsUAsset_Params params;
	params.InAssetData_69 = InAssetData_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AssetRegistry.AssetRegistryHelpers.IsRedirector
// (Final, Native, Static, Public, HasOutParms, HasDefaults, BlueprintCallable, BlueprintPure)
// Parameters:
// struct FAssetData              InAssetData_69                 (ConstParm, Parm, OutParm, ReferenceParm)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool AssetRegistryHelpers::STATIC_IsRedirector(const struct FAssetData& InAssetData_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AssetRegistry.AssetRegistryHelpers.IsRedirector"));

	AssetRegistryHelpers_IsRedirector_Params params;
	params.InAssetData_69 = InAssetData_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AssetRegistry.AssetRegistryHelpers.IsAssetLoaded
// (Final, Native, Static, Public, HasOutParms, HasDefaults, BlueprintCallable, BlueprintPure)
// Parameters:
// struct FAssetData              InAssetData_69                 (ConstParm, Parm, OutParm, ReferenceParm)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool AssetRegistryHelpers::STATIC_IsAssetLoaded(const struct FAssetData& InAssetData_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AssetRegistry.AssetRegistryHelpers.IsAssetLoaded"));

	AssetRegistryHelpers_IsAssetLoaded_Params params;
	params.InAssetData_69 = InAssetData_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AssetRegistry.AssetRegistryHelpers.GetTagValue
// (Final, Native, Static, Public, HasOutParms, HasDefaults, BlueprintCallable, BlueprintPure)
// Parameters:
// struct FAssetData              InAssetData_69                 (ConstParm, Parm, OutParm, ReferenceParm)
// struct FName                   InTagName_69                   (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
// struct FString                 OutTagValue_69                 (Parm, OutParm, ZeroConstructor)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool AssetRegistryHelpers::STATIC_GetTagValue(const struct FAssetData& InAssetData_69, const struct FName& InTagName_69, struct FString* OutTagValue_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AssetRegistry.AssetRegistryHelpers.GetTagValue"));

	AssetRegistryHelpers_GetTagValue_Params params;
	params.InAssetData_69 = InAssetData_69;
	params.InTagName_69 = InTagName_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (OutTagValue_69 != nullptr)
		*OutTagValue_69 = params.OutTagValue_69;

	return params.ReturnValue_69;
}


// Function AssetRegistry.AssetRegistryHelpers.GetFullName
// (Final, Native, Static, Public, HasOutParms, HasDefaults, BlueprintCallable, BlueprintPure)
// Parameters:
// struct FAssetData              InAssetData_69                 (ConstParm, Parm, OutParm, ReferenceParm)
// struct FString                 ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString AssetRegistryHelpers::STATIC_GetFullName(const struct FAssetData& InAssetData_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AssetRegistry.AssetRegistryHelpers.GetFullName"));

	AssetRegistryHelpers_GetFullName_Params params;
	params.InAssetData_69 = InAssetData_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AssetRegistry.AssetRegistryHelpers.GetExportTextName
// (Final, Native, Static, Public, HasOutParms, HasDefaults, BlueprintCallable, BlueprintPure)
// Parameters:
// struct FAssetData              InAssetData_69                 (ConstParm, Parm, OutParm, ReferenceParm)
// struct FString                 ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString AssetRegistryHelpers::STATIC_GetExportTextName(const struct FAssetData& InAssetData_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AssetRegistry.AssetRegistryHelpers.GetExportTextName"));

	AssetRegistryHelpers_GetExportTextName_Params params;
	params.InAssetData_69 = InAssetData_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AssetRegistry.AssetRegistryHelpers.GetClass
// (Final, Native, Static, Public, HasOutParms, HasDefaults, BlueprintCallable, BlueprintPure)
// Parameters:
// struct FAssetData              InAssetData_69                 (ConstParm, Parm, OutParm, ReferenceParm)
// class Object_32759*            ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

class Object_32759* AssetRegistryHelpers::STATIC_GetClass(const struct FAssetData& InAssetData_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AssetRegistry.AssetRegistryHelpers.GetClass"));

	AssetRegistryHelpers_GetClass_Params params;
	params.InAssetData_69 = InAssetData_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AssetRegistry.AssetRegistryHelpers.GetAssetRegistry
// (Final, Native, Static, Public, BlueprintCallable, BlueprintPure)
// Parameters:
// TScriptInterface<class AssetRegistry> ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

TScriptInterface<class AssetRegistry> AssetRegistryHelpers::STATIC_GetAssetRegistry()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AssetRegistry.AssetRegistryHelpers.GetAssetRegistry"));

	AssetRegistryHelpers_GetAssetRegistry_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AssetRegistry.AssetRegistryHelpers.GetAsset
// (Final, Native, Static, Public, HasOutParms, HasDefaults, BlueprintCallable, BlueprintPure)
// Parameters:
// struct FAssetData              InAssetData_69                 (ConstParm, Parm, OutParm, ReferenceParm)
// class Object_32759*            ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

class Object_32759* AssetRegistryHelpers::STATIC_GetAsset(const struct FAssetData& InAssetData_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AssetRegistry.AssetRegistryHelpers.GetAsset"));

	AssetRegistryHelpers_GetAsset_Params params;
	params.InAssetData_69 = InAssetData_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AssetRegistry.AssetRegistryHelpers.CreateAssetData
// (Final, Native, Static, Public, HasDefaults, BlueprintCallable, BlueprintPure)
// Parameters:
// class Object_32759*            InAsset_69                     (ConstParm, Parm, ZeroConstructor)
// bool                           bAllowBlueprintClass_69        (Parm, ZeroConstructor, IsPlainOldData)
// struct FAssetData              ReturnValue_69                 (Parm, OutParm, ReturnParm)

struct FAssetData AssetRegistryHelpers::STATIC_CreateAssetData(class Object_32759* InAsset_69, bool bAllowBlueprintClass_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AssetRegistry.AssetRegistryHelpers.CreateAssetData"));

	AssetRegistryHelpers_CreateAssetData_Params params;
	params.InAsset_69 = InAsset_69;
	params.bAllowBlueprintClass_69 = bAllowBlueprintClass_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AssetRegistry.AssetRegistry.WaitForPackage
// (Native, Public, BlueprintCallable)
// Parameters:
// struct FString                 PackageName_69                 (Parm, ZeroConstructor)

void AssetRegistry::WaitForPackage(const struct FString& PackageName_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AssetRegistry.AssetRegistry.WaitForPackage"));

	AssetRegistry_WaitForPackage_Params params;
	params.PackageName_69 = PackageName_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AssetRegistry.AssetRegistry.WaitForCompletion
// (Native, Public, BlueprintCallable)

void AssetRegistry::WaitForCompletion()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AssetRegistry.AssetRegistry.WaitForCompletion"));

	AssetRegistry_WaitForCompletion_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AssetRegistry.AssetRegistry.UseFilterToExcludeAssets
// (Native, Public, HasOutParms, HasDefaults, BlueprintCallable, Const)
// Parameters:
// TArray<struct FAssetData>      AssetDataList_69               (Parm, OutParm, ZeroConstructor, ReferenceParm)
// struct FARFilter               Filter_69                      (ConstParm, Parm, OutParm, ReferenceParm)

void AssetRegistry::UseFilterToExcludeAssets(const struct FARFilter& Filter_69, TArray<struct FAssetData>* AssetDataList_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AssetRegistry.AssetRegistry.UseFilterToExcludeAssets"));

	AssetRegistry_UseFilterToExcludeAssets_Params params;
	params.Filter_69 = Filter_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (AssetDataList_69 != nullptr)
		*AssetDataList_69 = params.AssetDataList_69;
}


// Function AssetRegistry.AssetRegistry.SearchAllAssets
// (Native, Public, BlueprintCallable)
// Parameters:
// bool                           bSynchronousSearch_69          (Parm, ZeroConstructor, IsPlainOldData)

void AssetRegistry::SearchAllAssets(bool bSynchronousSearch_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AssetRegistry.AssetRegistry.SearchAllAssets"));

	AssetRegistry_SearchAllAssets_Params params;
	params.bSynchronousSearch_69 = bSynchronousSearch_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AssetRegistry.AssetRegistry.ScanPathsSynchronous
// (Native, Public, HasOutParms, BlueprintCallable)
// Parameters:
// TArray<struct FString>         InPaths_69                     (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
// bool                           bForceRescan_69                (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bIgnoreDenyListScanFilters_69  (Parm, ZeroConstructor, IsPlainOldData)

void AssetRegistry::ScanPathsSynchronous(TArray<struct FString> InPaths_69, bool bForceRescan_69, bool bIgnoreDenyListScanFilters_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AssetRegistry.AssetRegistry.ScanPathsSynchronous"));

	AssetRegistry_ScanPathsSynchronous_Params params;
	params.InPaths_69 = InPaths_69;
	params.bForceRescan_69 = bForceRescan_69;
	params.bIgnoreDenyListScanFilters_69 = bIgnoreDenyListScanFilters_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AssetRegistry.AssetRegistry.ScanModifiedAssetFiles
// (Native, Public, HasOutParms, BlueprintCallable)
// Parameters:
// TArray<struct FString>         InFilePaths_69                 (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)

void AssetRegistry::ScanModifiedAssetFiles(TArray<struct FString> InFilePaths_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AssetRegistry.AssetRegistry.ScanModifiedAssetFiles"));

	AssetRegistry_ScanModifiedAssetFiles_Params params;
	params.InFilePaths_69 = InFilePaths_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AssetRegistry.AssetRegistry.ScanFilesSynchronous
// (Native, Public, HasOutParms, BlueprintCallable)
// Parameters:
// TArray<struct FString>         InFilePaths_69                 (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
// bool                           bForceRescan_69                (Parm, ZeroConstructor, IsPlainOldData)

void AssetRegistry::ScanFilesSynchronous(TArray<struct FString> InFilePaths_69, bool bForceRescan_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AssetRegistry.AssetRegistry.ScanFilesSynchronous"));

	AssetRegistry_ScanFilesSynchronous_Params params;
	params.InFilePaths_69 = InFilePaths_69;
	params.bForceRescan_69 = bForceRescan_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AssetRegistry.AssetRegistry.RunAssetsThroughFilter
// (Native, Public, HasOutParms, HasDefaults, BlueprintCallable, Const)
// Parameters:
// TArray<struct FAssetData>      AssetDataList_69               (Parm, OutParm, ZeroConstructor, ReferenceParm)
// struct FARFilter               Filter_69                      (ConstParm, Parm, OutParm, ReferenceParm)

void AssetRegistry::RunAssetsThroughFilter(const struct FARFilter& Filter_69, TArray<struct FAssetData>* AssetDataList_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AssetRegistry.AssetRegistry.RunAssetsThroughFilter"));

	AssetRegistry_RunAssetsThroughFilter_Params params;
	params.Filter_69 = Filter_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (AssetDataList_69 != nullptr)
		*AssetDataList_69 = params.AssetDataList_69;
}


// Function AssetRegistry.AssetRegistry.PrioritizeSearchPath
// (Native, Public, BlueprintCallable)
// Parameters:
// struct FString                 PathToPrioritize_69            (Parm, ZeroConstructor)

void AssetRegistry::PrioritizeSearchPath(const struct FString& PathToPrioritize_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AssetRegistry.AssetRegistry.PrioritizeSearchPath"));

	AssetRegistry_PrioritizeSearchPath_Params params;
	params.PathToPrioritize_69 = PathToPrioritize_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AssetRegistry.AssetRegistry.K2_GetReferencers
// (Native, Public, HasOutParms, BlueprintCallable, Const)
// Parameters:
// struct FName                   PackageName_69                 (Parm, ZeroConstructor, IsPlainOldData)
// struct FAssetRegistryDependencyOptions ReferenceOptions_69            (ConstParm, Parm, OutParm, ReferenceParm)
// TArray<struct FName>           OutReferencers_69              (Parm, OutParm, ZeroConstructor)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool AssetRegistry::K2_GetReferencers(const struct FName& PackageName_69, const struct FAssetRegistryDependencyOptions& ReferenceOptions_69, TArray<struct FName>* OutReferencers_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AssetRegistry.AssetRegistry.K2_GetReferencers"));

	AssetRegistry_K2_GetReferencers_Params params;
	params.PackageName_69 = PackageName_69;
	params.ReferenceOptions_69 = ReferenceOptions_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (OutReferencers_69 != nullptr)
		*OutReferencers_69 = params.OutReferencers_69;

	return params.ReturnValue_69;
}


// Function AssetRegistry.AssetRegistry.K2_GetDependencies
// (Native, Public, HasOutParms, BlueprintCallable, Const)
// Parameters:
// struct FName                   PackageName_69                 (Parm, ZeroConstructor, IsPlainOldData)
// struct FAssetRegistryDependencyOptions DependencyOptions_69           (ConstParm, Parm, OutParm, ReferenceParm)
// TArray<struct FName>           OutDependencies_69             (Parm, OutParm, ZeroConstructor)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool AssetRegistry::K2_GetDependencies(const struct FName& PackageName_69, const struct FAssetRegistryDependencyOptions& DependencyOptions_69, TArray<struct FName>* OutDependencies_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AssetRegistry.AssetRegistry.K2_GetDependencies"));

	AssetRegistry_K2_GetDependencies_Params params;
	params.PackageName_69 = PackageName_69;
	params.DependencyOptions_69 = DependencyOptions_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (OutDependencies_69 != nullptr)
		*OutDependencies_69 = params.OutDependencies_69;

	return params.ReturnValue_69;
}


// Function AssetRegistry.AssetRegistry.IsSearchAsync
// (Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool AssetRegistry::IsSearchAsync()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AssetRegistry.AssetRegistry.IsSearchAsync"));

	AssetRegistry_IsSearchAsync_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AssetRegistry.AssetRegistry.IsSearchAllAssets
// (Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool AssetRegistry::IsSearchAllAssets()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AssetRegistry.AssetRegistry.IsSearchAllAssets"));

	AssetRegistry_IsSearchAllAssets_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AssetRegistry.AssetRegistry.IsLoadingAssets
// (Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool AssetRegistry::IsLoadingAssets()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AssetRegistry.AssetRegistry.IsLoadingAssets"));

	AssetRegistry_IsLoadingAssets_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AssetRegistry.AssetRegistry.HasAssets
// (Native, Public, BlueprintCallable, Const)
// Parameters:
// struct FName                   PackagePath_69                 (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// bool                           bRecursive_69                  (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool AssetRegistry::HasAssets(const struct FName& PackagePath_69, bool bRecursive_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AssetRegistry.AssetRegistry.HasAssets"));

	AssetRegistry_HasAssets_Params params;
	params.PackagePath_69 = PackagePath_69;
	params.bRecursive_69 = bRecursive_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AssetRegistry.AssetRegistry.GetSubPaths
// (Native, Public, HasOutParms, BlueprintCallable, Const)
// Parameters:
// struct FString                 InBasePath_69                  (Parm, ZeroConstructor)
// TArray<struct FString>         OutPathList_69                 (Parm, OutParm, ZeroConstructor)
// bool                           bInRecurse_69                  (Parm, ZeroConstructor, IsPlainOldData)

void AssetRegistry::GetSubPaths(const struct FString& InBasePath_69, bool bInRecurse_69, TArray<struct FString>* OutPathList_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AssetRegistry.AssetRegistry.GetSubPaths"));

	AssetRegistry_GetSubPaths_Params params;
	params.InBasePath_69 = InBasePath_69;
	params.bInRecurse_69 = bInRecurse_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (OutPathList_69 != nullptr)
		*OutPathList_69 = params.OutPathList_69;
}


// Function AssetRegistry.AssetRegistry.GetAssetsByPaths
// (Native, Public, HasOutParms, BlueprintCallable, Const)
// Parameters:
// TArray<struct FName>           PackagePaths_69                (Parm, ZeroConstructor)
// TArray<struct FAssetData>      OutAssetData_69                (Parm, OutParm, ZeroConstructor)
// bool                           bRecursive_69                  (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bIncludeOnlyOnDiskAssets_69    (Parm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool AssetRegistry::GetAssetsByPaths(TArray<struct FName> PackagePaths_69, bool bRecursive_69, bool bIncludeOnlyOnDiskAssets_69, TArray<struct FAssetData>* OutAssetData_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AssetRegistry.AssetRegistry.GetAssetsByPaths"));

	AssetRegistry_GetAssetsByPaths_Params params;
	params.PackagePaths_69 = PackagePaths_69;
	params.bRecursive_69 = bRecursive_69;
	params.bIncludeOnlyOnDiskAssets_69 = bIncludeOnlyOnDiskAssets_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (OutAssetData_69 != nullptr)
		*OutAssetData_69 = params.OutAssetData_69;

	return params.ReturnValue_69;
}


// Function AssetRegistry.AssetRegistry.GetAssetsByPath
// (Native, Public, HasOutParms, BlueprintCallable, Const)
// Parameters:
// struct FName                   PackagePath_69                 (Parm, ZeroConstructor, IsPlainOldData)
// TArray<struct FAssetData>      OutAssetData_69                (Parm, OutParm, ZeroConstructor)
// bool                           bRecursive_69                  (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bIncludeOnlyOnDiskAssets_69    (Parm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool AssetRegistry::GetAssetsByPath(const struct FName& PackagePath_69, bool bRecursive_69, bool bIncludeOnlyOnDiskAssets_69, TArray<struct FAssetData>* OutAssetData_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AssetRegistry.AssetRegistry.GetAssetsByPath"));

	AssetRegistry_GetAssetsByPath_Params params;
	params.PackagePath_69 = PackagePath_69;
	params.bRecursive_69 = bRecursive_69;
	params.bIncludeOnlyOnDiskAssets_69 = bIncludeOnlyOnDiskAssets_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (OutAssetData_69 != nullptr)
		*OutAssetData_69 = params.OutAssetData_69;

	return params.ReturnValue_69;
}


// Function AssetRegistry.AssetRegistry.GetAssetsByPackageName
// (Native, Public, HasOutParms, BlueprintCallable, Const)
// Parameters:
// struct FName                   PackageName_69                 (Parm, ZeroConstructor, IsPlainOldData)
// TArray<struct FAssetData>      OutAssetData_69                (Parm, OutParm, ZeroConstructor)
// bool                           bIncludeOnlyOnDiskAssets_69    (Parm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool AssetRegistry::GetAssetsByPackageName(const struct FName& PackageName_69, bool bIncludeOnlyOnDiskAssets_69, TArray<struct FAssetData>* OutAssetData_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AssetRegistry.AssetRegistry.GetAssetsByPackageName"));

	AssetRegistry_GetAssetsByPackageName_Params params;
	params.PackageName_69 = PackageName_69;
	params.bIncludeOnlyOnDiskAssets_69 = bIncludeOnlyOnDiskAssets_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (OutAssetData_69 != nullptr)
		*OutAssetData_69 = params.OutAssetData_69;

	return params.ReturnValue_69;
}


// Function AssetRegistry.AssetRegistry.GetAssetsByClass
// (Native, Public, HasOutParms, BlueprintCallable, Const)
// Parameters:
// struct FTopLevelAssetPath      ClassPathName_69               (Parm)
// TArray<struct FAssetData>      OutAssetData_69                (Parm, OutParm, ZeroConstructor)
// bool                           bSearchSubClasses_69           (Parm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool AssetRegistry::GetAssetsByClass(const struct FTopLevelAssetPath& ClassPathName_69, bool bSearchSubClasses_69, TArray<struct FAssetData>* OutAssetData_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AssetRegistry.AssetRegistry.GetAssetsByClass"));

	AssetRegistry_GetAssetsByClass_Params params;
	params.ClassPathName_69 = ClassPathName_69;
	params.bSearchSubClasses_69 = bSearchSubClasses_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (OutAssetData_69 != nullptr)
		*OutAssetData_69 = params.OutAssetData_69;

	return params.ReturnValue_69;
}


// Function AssetRegistry.AssetRegistry.GetAssets
// (Native, Public, HasOutParms, HasDefaults, BlueprintCallable, Const)
// Parameters:
// struct FARFilter               Filter_69                      (ConstParm, Parm, OutParm, ReferenceParm)
// TArray<struct FAssetData>      OutAssetData_69                (Parm, OutParm, ZeroConstructor)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool AssetRegistry::GetAssets(const struct FARFilter& Filter_69, TArray<struct FAssetData>* OutAssetData_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AssetRegistry.AssetRegistry.GetAssets"));

	AssetRegistry_GetAssets_Params params;
	params.Filter_69 = Filter_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (OutAssetData_69 != nullptr)
		*OutAssetData_69 = params.OutAssetData_69;

	return params.ReturnValue_69;
}


// Function AssetRegistry.AssetRegistry.GetAssetByObjectPath
// (Native, Public, HasDefaults, BlueprintCallable, Const)
// Parameters:
// struct FName                   ObjectPath_69                  (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// bool                           bIncludeOnlyOnDiskAssets_69    (Parm, ZeroConstructor, IsPlainOldData)
// struct FAssetData              ReturnValue_69                 (Parm, OutParm, ReturnParm)

struct FAssetData AssetRegistry::GetAssetByObjectPath(const struct FName& ObjectPath_69, bool bIncludeOnlyOnDiskAssets_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AssetRegistry.AssetRegistry.GetAssetByObjectPath"));

	AssetRegistry_GetAssetByObjectPath_Params params;
	params.ObjectPath_69 = ObjectPath_69;
	params.bIncludeOnlyOnDiskAssets_69 = bIncludeOnlyOnDiskAssets_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AssetRegistry.AssetRegistry.GetAllCachedPaths
// (Native, Public, HasOutParms, BlueprintCallable, Const)
// Parameters:
// TArray<struct FString>         OutPathList_69                 (Parm, OutParm, ZeroConstructor)

void AssetRegistry::GetAllCachedPaths(TArray<struct FString>* OutPathList_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AssetRegistry.AssetRegistry.GetAllCachedPaths"));

	AssetRegistry_GetAllCachedPaths_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (OutPathList_69 != nullptr)
		*OutPathList_69 = params.OutPathList_69;
}


// Function AssetRegistry.AssetRegistry.GetAllAssets
// (Native, Public, HasOutParms, BlueprintCallable, Const)
// Parameters:
// TArray<struct FAssetData>      OutAssetData_69                (Parm, OutParm, ZeroConstructor)
// bool                           bIncludeOnlyOnDiskAssets_69    (Parm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool AssetRegistry::GetAllAssets(bool bIncludeOnlyOnDiskAssets_69, TArray<struct FAssetData>* OutAssetData_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AssetRegistry.AssetRegistry.GetAllAssets"));

	AssetRegistry_GetAllAssets_Params params;
	params.bIncludeOnlyOnDiskAssets_69 = bIncludeOnlyOnDiskAssets_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (OutAssetData_69 != nullptr)
		*OutAssetData_69 = params.OutAssetData_69;

	return params.ReturnValue_69;
}


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

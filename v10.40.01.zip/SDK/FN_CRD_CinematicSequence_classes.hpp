#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Classes
//---------------------------------------------------------------------------

// Class CRD_CinematicSequence.CinematicSequenceDeviceBase
// 0x0030 (0x0F10 - 0x0EE0)
class CinematicSequenceDeviceBase : public BuildingProp
{
public:
	unsigned char                                      UnknownData00[0x8];                                       // 0x0EE0(0x0008) MISSED OFFSET
	class LevelSequence*                               Sequence_69;                                              // 0x0EE8(0x0008) (Edit, BlueprintVisible, ZeroConstructor)
	class LevelSequenceActor*                          LevelSequenceActor_69;                                    // 0x0EF0(0x0008) (ZeroConstructor)
	class FortPlayerController*                        InstigatingController_69;                                 // 0x0EF8(0x0008) (BlueprintVisible, Net, ZeroConstructor)
	unsigned char                                      InstigatingTeam_69;                                       // 0x0F00(0x0001) (BlueprintVisible, Net, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x3];                                       // 0x0F01(0x0003) MISSED OFFSET
	unsigned char                                      bLoopPlayback_69 : 1;                                     // 0x0F04(0x0001) (Edit, BlueprintVisible)
	unsigned char                                      bRestoreState_69 : 1;                                     // 0x0F04(0x0001) (Edit, BlueprintVisible)
	unsigned char                                      bAutoPlay_69 : 1;                                         // 0x0F04(0x0001) (Edit, BlueprintVisible)
	unsigned char                                      UnknownData02[0x3];                                       // 0x0F05(0x0003) MISSED OFFSET
	ECinematicSequenceVisibility                       Visibility_69;                                            // 0x0F08(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bLevelSequenceActorAlwaysRelevant_69;                     // 0x0F09(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData03[0x6];                                       // 0x0F0A(0x0006) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CRD_CinematicSequence.CinematicSequenceDeviceBase"));
		
		return ptr;
	}


	void Stop();
	void Play();
	void Pause();
	void HandleSequencePlayerCreated(class LevelSequencePlayer* Player_69);
	class MovieSceneSequencePlayer* GetSequencePlayer();
};


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

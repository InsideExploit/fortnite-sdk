#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Enums
//---------------------------------------------------------------------------

// Enum ControlRigSpline.ESplineType
enum class ESplineType : uint8_t
{
	BSpline                        = 0,
	Hermite                        = 1,
	Max                            = 2
};



//---------------------------------------------------------------------------
//Script Structs
//---------------------------------------------------------------------------

// ScriptStruct ControlRigSpline.ControlRigSplineImpl
// 0x0058
struct FControlRigSplineImpl
{
	unsigned char                                      UnknownData00[0x58];                                      // 0x0000(0x0058) MISSED OFFSET
};

// ScriptStruct ControlRigSpline.ControlRigSpline
// 0x0018
struct FControlRigSpline
{
	unsigned char                                      UnknownData00[0x18];                                      // 0x0000(0x0018) MISSED OFFSET
};

// ScriptStruct ControlRigSpline.RigUnit_ControlRigSplineBase
// 0x0000 (0x0008 - 0x0008)
struct FRigUnit_ControlRigSplineBase : public FRigUnit
{

};

// ScriptStruct ControlRigSpline.RigUnit_ControlRigSplineFromPoints
// 0x0038 (0x0040 - 0x0008)
struct FRigUnit_ControlRigSplineFromPoints : public FRigUnit_ControlRigSplineBase
{
	TArray<struct FVector>                             Points_69;                                                // 0x0008(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	ESplineType                                        SplineMode_69;                                            // 0x0018(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0019(0x0003) MISSED OFFSET
	int                                                SamplesPerSegment_69;                                     // 0x001C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              Compression_69;                                           // 0x0020(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              Stretch_69;                                               // 0x0024(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FControlRigSpline                           Spline_69;                                                // 0x0028(0x0018) (BlueprintVisible, BlueprintReadOnly)
};

// ScriptStruct ControlRigSpline.RigUnit_SetSplinePoints
// 0x0028 (0x0060 - 0x0038)
struct FRigUnit_SetSplinePoints : public FRigUnitMutable
{
	TArray<struct FVector>                             Points_69;                                                // 0x0038(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FControlRigSpline                           Spline_69;                                                // 0x0048(0x0018) (Edit, BlueprintVisible)
};

// ScriptStruct ControlRigSpline.RigUnit_PositionFromControlRigSpline
// 0x0038 (0x0040 - 0x0008)
struct FRigUnit_PositionFromControlRigSpline : public FRigUnit_ControlRigSplineBase
{
	struct FControlRigSpline                           Spline_69;                                                // 0x0008(0x0018) (Edit, BlueprintVisible)
	float                                              U_69;                                                     // 0x0020(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0024(0x0004) MISSED OFFSET
	struct FVector                                     Position_69;                                              // 0x0028(0x0018) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct ControlRigSpline.RigUnit_TransformFromControlRigSpline
// 0x0098 (0x00A0 - 0x0008)
struct FRigUnit_TransformFromControlRigSpline : public FRigUnit_ControlRigSplineBase
{
	struct FControlRigSpline                           Spline_69;                                                // 0x0008(0x0018) (Edit, BlueprintVisible)
	struct FVector                                     UpVector_69;                                              // 0x0020(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              Roll_69;                                                  // 0x0038(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              U_69;                                                     // 0x003C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FCoreUObject_FTransform                     Transform_69;                                             // 0x0040(0x0060) (BlueprintVisible, BlueprintReadOnly, IsPlainOldData)
};

// ScriptStruct ControlRigSpline.RigUnit_TangentFromControlRigSpline
// 0x0038 (0x0040 - 0x0008)
struct FRigUnit_TangentFromControlRigSpline : public FRigUnit_ControlRigSplineBase
{
	struct FControlRigSpline                           Spline_69;                                                // 0x0008(0x0018) (Edit, BlueprintVisible)
	float                                              U_69;                                                     // 0x0020(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0024(0x0004) MISSED OFFSET
	struct FVector                                     Tangent_69;                                               // 0x0028(0x0018) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct ControlRigSpline.RigUnit_DrawControlRigSpline
// 0x0030 (0x0068 - 0x0038)
struct FRigUnit_DrawControlRigSpline : public FRigUnitMutable
{
	struct FControlRigSpline                           Spline_69;                                                // 0x0038(0x0018) (Edit, BlueprintVisible)
	struct FLinearColor                                Color_69;                                                 // 0x0050(0x0010) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              Thickness_69;                                             // 0x0060(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                Detail_69;                                                // 0x0064(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct ControlRigSpline.RigUnit_GetLengthControlRigSpline
// 0x0020 (0x0028 - 0x0008)
struct FRigUnit_GetLengthControlRigSpline : public FRigUnit
{
	struct FControlRigSpline                           Spline_69;                                                // 0x0008(0x0018) (Edit, BlueprintVisible)
	float                                              Length_69;                                                // 0x0020(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0024(0x0004) MISSED OFFSET
};

// ScriptStruct ControlRigSpline.RigUnit_FitChainToSplineCurve
// 0x01D8 (0x0210 - 0x0038)
struct FRigUnit_FitChainToSplineCurve : public FRigUnit_HighlevelBaseMutable
{
	struct FRigElementKeyCollection                    Items_69;                                                 // 0x0038(0x0010) (Edit, BlueprintVisible)
	struct FControlRigSpline                           Spline_69;                                                // 0x0048(0x0018) (Edit, BlueprintVisible)
	EControlRigCurveAlignment                          Alignment_69;                                             // 0x0060(0x0001) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0061(0x0003) MISSED OFFSET
	float                                              Minimum_69;                                               // 0x0064(0x0004) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	float                                              Maximum_69;                                               // 0x0068(0x0004) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	int                                                SamplingPrecision_69;                                     // 0x006C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	struct FVector                                     PrimaryAxis_69;                                           // 0x0070(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FVector                                     SecondaryAxis_69;                                         // 0x0088(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FVector                                     PoleVectorPosition_69;                                    // 0x00A0(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	TArray<struct FRigUnit_FitChainToCurve_Rotation>   Rotations_69;                                             // 0x00B8(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	EControlRigAnimEasingType                          RotationEaseType_69;                                      // 0x00C8(0x0001) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	unsigned char                                      UnknownData01[0x3];                                       // 0x00C9(0x0003) MISSED OFFSET
	float                                              Weight_69;                                                // 0x00CC(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bPropagateToChildren_69;                                  // 0x00D0(0x0001) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	unsigned char                                      UnknownData02[0xF];                                       // 0x00D1(0x000F) MISSED OFFSET
	struct FRigUnit_FitChainToCurve_DebugSettings      DebugSettings_69;                                         // 0x00E0(0x0090) (Edit, BlueprintVisible)
	struct FRigUnit_FitChainToCurve_WorkData           WorkData_69;                                              // 0x0170(0x0098) (Transient)
	unsigned char                                      UnknownData03[0x8];                                       // 0x0208(0x0008) MISSED OFFSET
};

// ScriptStruct ControlRigSpline.RigUnit_FitChainToSplineCurveItemArray
// 0x01D8 (0x0210 - 0x0038)
struct FRigUnit_FitChainToSplineCurveItemArray : public FRigUnit_HighlevelBaseMutable
{
	TArray<struct FRigElementKey>                      Items_69;                                                 // 0x0038(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FControlRigSpline                           Spline_69;                                                // 0x0048(0x0018) (Edit, BlueprintVisible)
	EControlRigCurveAlignment                          Alignment_69;                                             // 0x0060(0x0001) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0061(0x0003) MISSED OFFSET
	float                                              Minimum_69;                                               // 0x0064(0x0004) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	float                                              Maximum_69;                                               // 0x0068(0x0004) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	int                                                SamplingPrecision_69;                                     // 0x006C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	struct FVector                                     PrimaryAxis_69;                                           // 0x0070(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FVector                                     SecondaryAxis_69;                                         // 0x0088(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FVector                                     PoleVectorPosition_69;                                    // 0x00A0(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	TArray<struct FRigUnit_FitChainToCurve_Rotation>   Rotations_69;                                             // 0x00B8(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	EControlRigAnimEasingType                          RotationEaseType_69;                                      // 0x00C8(0x0001) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	unsigned char                                      UnknownData01[0x3];                                       // 0x00C9(0x0003) MISSED OFFSET
	float                                              Weight_69;                                                // 0x00CC(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bPropagateToChildren_69;                                  // 0x00D0(0x0001) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	unsigned char                                      UnknownData02[0xF];                                       // 0x00D1(0x000F) MISSED OFFSET
	struct FRigUnit_FitChainToCurve_DebugSettings      DebugSettings_69;                                         // 0x00E0(0x0090) (Edit, BlueprintVisible)
	struct FRigUnit_FitChainToCurve_WorkData           WorkData_69;                                              // 0x0170(0x0098) (Transient)
	unsigned char                                      UnknownData03[0x8];                                       // 0x0208(0x0008) MISSED OFFSET
};

// ScriptStruct ControlRigSpline.RigUnit_FitSplineCurveToChain
// 0x0028 (0x0060 - 0x0038)
struct FRigUnit_FitSplineCurveToChain : public FRigUnit_HighlevelBaseMutable
{
	struct FRigElementKeyCollection                    Items_69;                                                 // 0x0038(0x0010) (Edit, BlueprintVisible)
	struct FControlRigSpline                           Spline_69;                                                // 0x0048(0x0018) (Edit, BlueprintVisible)
};

// ScriptStruct ControlRigSpline.RigUnit_FitSplineCurveToChainItemArray
// 0x0028 (0x0060 - 0x0038)
struct FRigUnit_FitSplineCurveToChainItemArray : public FRigUnit_HighlevelBaseMutable
{
	TArray<struct FRigElementKey>                      Items_69;                                                 // 0x0038(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FControlRigSpline                           Spline_69;                                                // 0x0048(0x0018) (Edit, BlueprintVisible)
};

// ScriptStruct ControlRigSpline.RigUnit_ClosestParameterFromControlRigSpline
// 0x0038 (0x0040 - 0x0008)
struct FRigUnit_ClosestParameterFromControlRigSpline : public FRigUnit_ControlRigSplineBase
{
	struct FControlRigSpline                           Spline_69;                                                // 0x0008(0x0018) (Edit, BlueprintVisible)
	struct FVector                                     Position_69;                                              // 0x0020(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              U_69;                                                     // 0x0038(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x003C(0x0004) MISSED OFFSET
};

// ScriptStruct ControlRigSpline.RigUnit_ParameterAtPercentage
// 0x0020 (0x0028 - 0x0008)
struct FRigUnit_ParameterAtPercentage : public FRigUnit_ControlRigSplineBase
{
	struct FControlRigSpline                           Spline_69;                                                // 0x0008(0x0018) (Edit, BlueprintVisible)
	float                                              Percentage_69;                                            // 0x0020(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              U_69;                                                     // 0x0024(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Classes
//---------------------------------------------------------------------------

// Class CreativeDataChannelTriggerRuntime.CreativeDataChannelAnalytics
// 0x0000 (0x0028 - 0x0028)
class CreativeDataChannelAnalytics : public Object_32759
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CreativeDataChannelTriggerRuntime.CreativeDataChannelAnalytics"));
		
		return ptr;
	}

};


// Class CreativeDataChannelTriggerRuntime.CreativeDataChannelTarget
// 0x0050 (0x0350 - 0x0300)
class CreativeDataChannelTarget : public ElectraDataChannelTarget
{
public:
	unsigned char                                      UnknownData00[0x8];                                       // 0x0300(0x0008) MISSED OFFSET
	int8_t                                             VersionByte_69;                                           // 0x0308(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x7];                                       // 0x0309(0x0007) MISSED OFFSET
	struct FCreativeDataChannelEvents                  Events_69;                                                // 0x0310(0x0010) (BlueprintVisible)
	unsigned char                                      UnknownData02[0x10];                                      // 0x0320(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty CreativeDataChannelTriggerRuntime.CreativeDataChannelTarget.OnEventsRep_69
	struct FCreativeDataChannelEvents                  EventsCache_69;                                           // 0x0330(0x0010)
	unsigned char                                      UnknownData03[0x10];                                      // 0x0340(0x0010) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CreativeDataChannelTriggerRuntime.CreativeDataChannelTarget"));
		
		return ptr;
	}


	void TestCreativeDataChannelTarget(const struct FCreativeDataChannelEvents& TestEvents_69);
	void OnRep_Events();
	void FireEvent(const struct FName& EventName_69);
};


// Class CreativeDataChannelTriggerRuntime.CreativeDataChannelTargetFN
// 0x02B8 (0x05B8 - 0x0300)
class CreativeDataChannelTargetFN : public ElectraDataChannelTarget
{
public:
	unsigned char                                      UnknownData00[0x8];                                       // 0x0300(0x0008) MISSED OFFSET
	int                                                VersionByte_69;                                           // 0x0308(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	struct FCDCInt                                     VersionByteTracker_69;                                    // 0x030C(0x0004) (BlueprintVisible, BlueprintReadOnly)
	unsigned char                                      UnknownData01[0x10];                                      // 0x0310(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty CreativeDataChannelTriggerRuntime.CreativeDataChannelTargetFN.VersionByteEvent_69
	struct FString                                     LeaderBoard_69;                                           // 0x0320(0x0010) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
	int64_t                                            StormCircleSize_69;                                       // 0x0330(0x0008) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	struct FCDCLargeInt                                StormCircleSizeTracker_69;                                // 0x0338(0x0008) (BlueprintVisible, BlueprintReadOnly)
	unsigned char                                      UnknownData02[0x10];                                      // 0x0340(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty CreativeDataChannelTriggerRuntime.CreativeDataChannelTargetFN.StormCircleSizeEvent_69
	TArray<float>                                      StormCircleLocation_69;                                   // 0x0350(0x0010) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
	struct FCDCFloatArray                              StormCircleLocationTracker_69;                            // 0x0360(0x0010) (BlueprintVisible, BlueprintReadOnly)
	unsigned char                                      UnknownData03[0x10];                                      // 0x0370(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty CreativeDataChannelTriggerRuntime.CreativeDataChannelTargetFN.StormCircleLocationEvent_69
	struct FString                                     PlayerLocation_69;                                        // 0x0380(0x0010) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
	struct FCDCStringFloatArrayMap                     PlayerLocationTracker_69;                                 // 0x0390(0x0050) (BlueprintVisible, BlueprintReadOnly)
	unsigned char                                      UnknownData04[0x10];                                      // 0x03E0(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty CreativeDataChannelTriggerRuntime.CreativeDataChannelTargetFN.PlayerLocationEvent_69
	struct FString                                     ArenaPointLeaderBoard_69;                                 // 0x03F0(0x0010) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
	struct FCDCStringStringMap                         ArenaPointLeaderBoardTracker_69;                          // 0x0400(0x00A0) (BlueprintVisible, BlueprintReadOnly)
	unsigned char                                      UnknownData05[0x10];                                      // 0x04A0(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty CreativeDataChannelTriggerRuntime.CreativeDataChannelTargetFN.ArenaPointLeaderBoardEvent_69
	struct FString                                     CashCupDataAllTimeEarners_69;                             // 0x04B0(0x0010) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
	struct FCDCStringFloatMap                          CashCupDataAllTimeEanersTracker_69;                       // 0x04C0(0x0050) (BlueprintVisible, BlueprintReadOnly)
	unsigned char                                      UnknownData06[0x10];                                      // 0x0510(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty CreativeDataChannelTriggerRuntime.CreativeDataChannelTargetFN.CashCupDataAllTimeEarnersEvent_69
	struct FString                                     MythicBossEliminatedPlayer_69;                            // 0x0520(0x0010) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
	struct FCDCString                                  MythicBossEliminatedPlayerTracker_69;                     // 0x0530(0x0010) (BlueprintVisible, BlueprintReadOnly)
	unsigned char                                      UnknownData07[0x10];                                      // 0x0540(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty CreativeDataChannelTriggerRuntime.CreativeDataChannelTargetFN.MythicBossEliminatedPlayerEvent_69
	struct FString                                     MythicWeaponPlayer_69;                                    // 0x0550(0x0010) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
	struct FCDCString                                  MythicWeaponPlayerTracker_69;                             // 0x0560(0x0010) (BlueprintVisible, BlueprintReadOnly)
	unsigned char                                      UnknownData08[0x10];                                      // 0x0570(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty CreativeDataChannelTriggerRuntime.CreativeDataChannelTargetFN.MythicWeaponPlayerEvent_69
	struct FString                                     PlayerInfo_69;                                            // 0x0580(0x0010) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
	struct FCDCStringArray                             PlayerInfoTracker_69;                                     // 0x0590(0x0018) (BlueprintVisible, BlueprintReadOnly)
	unsigned char                                      UnknownData09[0x10];                                      // 0x05A8(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty CreativeDataChannelTriggerRuntime.CreativeDataChannelTargetFN.PlayerInfoEvent_69

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CreativeDataChannelTriggerRuntime.CreativeDataChannelTargetFN"));
		
		return ptr;
	}

};


// Class CreativeDataChannelTriggerRuntime.CreativeDataChannelTargetRL
// 0x04C0 (0x07C0 - 0x0300)
class CreativeDataChannelTargetRL : public ElectraDataChannelTarget
{
public:
	unsigned char                                      UnknownData00[0x8];                                       // 0x0300(0x0008) MISSED OFFSET
	int                                                VersionByte_69;                                           // 0x0308(0x0004) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FCDCInt                                     VersionByteTracker_69;                                    // 0x030C(0x0004) (BlueprintVisible, BlueprintReadOnly)
	unsigned char                                      UnknownData01[0x10];                                      // 0x0310(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty CreativeDataChannelTriggerRuntime.CreativeDataChannelTargetRL.VersionByteEvent_69
	int                                                ScoreTeam_69;                                             // 0x0320(0x0004) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData02[0x4];                                       // 0x0324(0x0004) MISSED OFFSET
	struct FCDCString                                  ScoreTeamTracker_69;                                      // 0x0328(0x0010) (BlueprintVisible, BlueprintReadOnly)
	unsigned char                                      UnknownData03[0x10];                                      // 0x0338(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty CreativeDataChannelTriggerRuntime.CreativeDataChannelTargetRL.ScoreTeamEvent_69
	struct FString                                     ScoreTotal_69;                                            // 0x0348(0x0010) (BlueprintVisible, ZeroConstructor)
	struct FCDCStringIntMap                            ScoreTotalTracker_69;                                     // 0x0358(0x0050) (BlueprintVisible, BlueprintReadOnly)
	unsigned char                                      UnknownData04[0x10];                                      // 0x03A8(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty CreativeDataChannelTriggerRuntime.CreativeDataChannelTargetRL.ScoreTotalEvent_69
	int64_t                                            ScoreboardTimeLeft_69;                                    // 0x03B8(0x0008) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FCDCLargeInt                                ScoreboardTimeLeftTracker_69;                             // 0x03C0(0x0008) (BlueprintVisible, BlueprintReadOnly)
	unsigned char                                      UnknownData05[0x10];                                      // 0x03C8(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty CreativeDataChannelTriggerRuntime.CreativeDataChannelTargetRL.ScoreboardTimeLeftEvent_69
	struct FString                                     ScoreboardBestOf_69;                                      // 0x03D8(0x0010) (BlueprintVisible, ZeroConstructor)
	struct FCDCStringIntMap                            ScoreboardBestOfTracker_69;                               // 0x03E8(0x0050) (BlueprintVisible, BlueprintReadOnly)
	unsigned char                                      UnknownData06[0x10];                                      // 0x0438(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty CreativeDataChannelTriggerRuntime.CreativeDataChannelTargetRL.ScoreboardBestOfEvent_69
	int                                                OverTime_69;                                              // 0x0448(0x0004) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FCDCInt                                     OvertimeTracker_69;                                       // 0x044C(0x0004) (BlueprintVisible, BlueprintReadOnly)
	unsigned char                                      UnknownData07[0x10];                                      // 0x0450(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty CreativeDataChannelTriggerRuntime.CreativeDataChannelTargetRL.OvertimeEvent_69
	struct FString                                     TeamNames_69;                                             // 0x0460(0x0010) (BlueprintVisible, ZeroConstructor)
	struct FCDCStringArray                             TeamNamesTracker_69;                                      // 0x0470(0x0018) (BlueprintVisible, BlueprintReadOnly)
	unsigned char                                      UnknownData08[0x10];                                      // 0x0488(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty CreativeDataChannelTriggerRuntime.CreativeDataChannelTargetRL.TeamNamesEvent_69
	struct FString                                     PlayerNames_69;                                           // 0x0498(0x0010) (BlueprintVisible, ZeroConstructor)
	struct FCDCStringArray                             PlayerNamesTracker_69;                                    // 0x04A8(0x0018) (BlueprintVisible, BlueprintReadOnly)
	unsigned char                                      UnknownData09[0x10];                                      // 0x04C0(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty CreativeDataChannelTriggerRuntime.CreativeDataChannelTargetRL.PlayerNamesEvent_69
	struct FString                                     PlayerBoost_69;                                           // 0x04D0(0x0010) (BlueprintVisible, ZeroConstructor)
	struct FCDCStringIntMap                            PlayerBoostTracker_69;                                    // 0x04E0(0x0050) (BlueprintVisible, BlueprintReadOnly)
	unsigned char                                      UnknownData10[0x10];                                      // 0x0530(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty CreativeDataChannelTriggerRuntime.CreativeDataChannelTargetRL.PlayerBoostEvent_69
	struct FString                                     PlayerBoostCollected_69;                                  // 0x0540(0x0010) (BlueprintVisible, ZeroConstructor)
	struct FCDCStringStringMap                         PlayerBoostCollectedTracker_69;                           // 0x0550(0x00A0) (BlueprintVisible, BlueprintReadOnly)
	unsigned char                                      UnknownData11[0x10];                                      // 0x05F0(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty CreativeDataChannelTriggerRuntime.CreativeDataChannelTargetRL.PlayerBoostCollectedEvent_69
	struct FString                                     PlayerCoords_69;                                          // 0x0600(0x0010) (BlueprintVisible, ZeroConstructor)
	struct FCDCStringFloatArrayMap                     PlayerCoordsTracker_69;                                   // 0x0610(0x0050) (BlueprintVisible, BlueprintReadOnly)
	unsigned char                                      UnknownData12[0x10];                                      // 0x0660(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty CreativeDataChannelTriggerRuntime.CreativeDataChannelTargetRL.PlayerCoordsEvent_69
	struct FString                                     BallCoords_69;                                            // 0x0670(0x0010) (BlueprintVisible, ZeroConstructor)
	struct FCDCFloatArray                              BallCoordsTracker_69;                                     // 0x0680(0x0010) (BlueprintVisible, BlueprintReadOnly)
	unsigned char                                      UnknownData13[0x10];                                      // 0x0690(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty CreativeDataChannelTriggerRuntime.CreativeDataChannelTargetRL.BallCoordsEvent_69
	struct FString                                     MediaStart_69;                                            // 0x06A0(0x0010) (BlueprintVisible, ZeroConstructor)
	struct FCDCStringStringMap                         MediaStartTracker_69;                                     // 0x06B0(0x00A0) (BlueprintVisible, BlueprintReadOnly)
	unsigned char                                      UnknownData14[0x10];                                      // 0x0750(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty CreativeDataChannelTriggerRuntime.CreativeDataChannelTargetRL.MediaStartEvent_69
	int                                                MediaStop_69;                                             // 0x0760(0x0004) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FCDCInt                                     MediaStopTracker_69;                                      // 0x0764(0x0004) (BlueprintVisible, BlueprintReadOnly)
	unsigned char                                      UnknownData15[0x10];                                      // 0x0768(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty CreativeDataChannelTriggerRuntime.CreativeDataChannelTargetRL.MediaStopEvent_69
	int                                                SeriesState_69;                                           // 0x0778(0x0004) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FCDCInt                                     SeriesStateTracker_69;                                    // 0x077C(0x0004) (BlueprintVisible, BlueprintReadOnly)
	unsigned char                                      UnknownData16[0x10];                                      // 0x0780(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty CreativeDataChannelTriggerRuntime.CreativeDataChannelTargetRL.SeriesStateEvent_69
	int                                                MatchState_69;                                            // 0x0790(0x0004) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FCDCInt                                     MatchStateTracker_69;                                     // 0x0794(0x0004) (BlueprintVisible, BlueprintReadOnly)
	unsigned char                                      UnknownData17[0x10];                                      // 0x0798(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty CreativeDataChannelTriggerRuntime.CreativeDataChannelTargetRL.MatchStateEvent_69
	int                                                FinaleState_69;                                           // 0x07A8(0x0004) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FCDCInt                                     FinaleStateTracker_69;                                    // 0x07AC(0x0004) (BlueprintVisible, BlueprintReadOnly)
	unsigned char                                      UnknownData18[0x10];                                      // 0x07B0(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty CreativeDataChannelTriggerRuntime.CreativeDataChannelTargetRL.FinaleStateEvent_69

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CreativeDataChannelTriggerRuntime.CreativeDataChannelTargetRL"));
		
		return ptr;
	}


	void ReportServerStateStreamError(const struct FString& Error_69, const struct FString& UID_69, const struct FString& URL_69);
	void OnRep_VersionByte();
	void OnRep_TeamNames();
	void OnRep_SeriesState();
	void OnRep_ScoreTotal();
	void OnRep_ScoreTeam();
	void OnRep_ScoreboardTimeLeft();
	void OnRep_ScoreboardBestOf();
	void OnRep_PlayerNames();
	void OnRep_PlayerCoords();
	void OnRep_PlayerBoostCollected();
	void OnRep_PlayerBoost();
	void OnRep_Overtime();
	void OnRep_MediaStop();
	void OnRep_MediaStart();
	void OnRep_MatchState();
	void OnRep_FinaleState();
	void OnRep_BallCoords();
};


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

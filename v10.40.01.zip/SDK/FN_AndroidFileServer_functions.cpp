// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Functions
//---------------------------------------------------------------------------

// Function AndroidFileServer.AndroidFileServerBPLibrary.StopFileServer
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// bool                           bUSB_69                        (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bNetwork_69                    (Parm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool AndroidFileServerBPLibrary::STATIC_StopFileServer(bool bUSB_69, bool bNetwork_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AndroidFileServer.AndroidFileServerBPLibrary.StopFileServer"));

	AndroidFileServerBPLibrary_StopFileServer_Params params;
	params.bUSB_69 = bUSB_69;
	params.bNetwork_69 = bNetwork_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AndroidFileServer.AndroidFileServerBPLibrary.StartFileServer
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// bool                           bUSB_69                        (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bNetwork_69                    (Parm, ZeroConstructor, IsPlainOldData)
// int                            Port_69                        (Parm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool AndroidFileServerBPLibrary::STATIC_StartFileServer(bool bUSB_69, bool bNetwork_69, int Port_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AndroidFileServer.AndroidFileServerBPLibrary.StartFileServer"));

	AndroidFileServerBPLibrary_StartFileServer_Params params;
	params.bUSB_69 = bUSB_69;
	params.bNetwork_69 = bNetwork_69;
	params.Port_69 = Port_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AndroidFileServer.AndroidFileServerBPLibrary.IsFileServerRunning
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// TEnumAsByte<EAFSActiveType>    ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

TEnumAsByte<EAFSActiveType> AndroidFileServerBPLibrary::STATIC_IsFileServerRunning()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AndroidFileServer.AndroidFileServerBPLibrary.IsFileServerRunning"));

	AndroidFileServerBPLibrary_IsFileServerRunning_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

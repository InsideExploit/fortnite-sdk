#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Enums
//---------------------------------------------------------------------------

// Enum AmbientAudio.EAmbientAudioEntryActionType
enum class EAmbientAudioEntryActionType : uint8_t
{
	Added                          = 0,
	Updated                        = 1,
	Removed                        = 2,
	Count                          = 3,
	EAmbientAudioEntryActionType_MAX = 4
};


// Enum AmbientAudio.EAmbientAudioTagActionType
enum class EAmbientAudioTagActionType : uint8_t
{
	Added                          = 0,
	Removed                        = 1,
	Count                          = 2,
	EAmbientAudioTagActionType_MAX = 3
};



//---------------------------------------------------------------------------
//Script Structs
//---------------------------------------------------------------------------

// ScriptStruct AmbientAudio.AmbientAudioBase
// 0x00C0
struct FAmbientAudioBase
{
	unsigned char                                      UnknownData00[0x28];                                      // 0x0000(0x0028) UNKNOWN PROPERTY: SoftObjectProperty AmbientAudio.AmbientAudioBase.sound_69
	struct FGameplayTagQuery                           Requirements_69;                                          // 0x0028(0x0048)
	struct FAudioGameplayRequirements                  PlaybackRequirements_69;                                  // 0x0070(0x0050) (Edit)
};

// ScriptStruct AmbientAudio.AmbientAudioLoop
// 0x0000 (0x00C0 - 0x00C0)
struct FAmbientAudioLoop : public FAmbientAudioBase
{

};

// ScriptStruct AmbientAudio.AmbientAudioOneShot
// 0x0020 (0x00E0 - 0x00C0)
struct FAmbientAudioOneShot : public FAmbientAudioBase
{
	struct FVector2D                                   RetriggerTimeRange_69;                                    // 0x00C0(0x0010) (Edit, ZeroConstructor, Config, IsPlainOldData)
	struct FVector2D                                   TriggerDistanceRange_69;                                  // 0x00D0(0x0010) (Edit, ZeroConstructor, Config, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

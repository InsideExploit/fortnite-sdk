#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Enums
//---------------------------------------------------------------------------

// Enum BRVKRuntime.EBRVKContentLoaderPauseType
enum class EBRVKContentLoaderPauseType : uint8_t
{
	NONE                           = 0,
	LOOT_CALCULATION               = 1,
	WARMUP                         = 2,
	EBRVKContentLoaderPauseType_MAX = 3
};



}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

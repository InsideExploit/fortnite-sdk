#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Classes
//---------------------------------------------------------------------------

// BlueprintGeneratedClass AnimNotify_FootStep.AnimNotify_FootStep_C
// 0x0004 (0x003C - 0x0038)
class AnimNotify_FootStep_C : public AnimNotify
{
public:
	int                                                FootIndex_2097153;                                        // 0x0038(0x0004) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("BlueprintGeneratedClass AnimNotify_FootStep.AnimNotify_FootStep_C"));
		
		return ptr;
	}


	bool Received_Notify(class SkeletalMeshComponent* MeshComp_1, class AnimSequenceBase* Animation_1, const struct FAnimNotifyEventReference& EventReference_1);
};


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

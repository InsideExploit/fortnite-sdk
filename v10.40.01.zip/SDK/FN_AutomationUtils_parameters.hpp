#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function AutomationUtils.AutomationUtilsBlueprintLibrary.TakeGameplayAutomationScreenshot
struct AutomationUtilsBlueprintLibrary_TakeGameplayAutomationScreenshot_Params
{
	struct FString                                     ScreenshotName_69;                                        // (ConstParm, Parm, ZeroConstructor)
	float                                              MaxGlobalError_69;                                        // (Parm, ZeroConstructor, IsPlainOldData)
	float                                              MaxLocalError_69;                                         // (Parm, ZeroConstructor, IsPlainOldData)
	struct FString                                     MapNameOverride_69;                                       // (Parm, ZeroConstructor)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

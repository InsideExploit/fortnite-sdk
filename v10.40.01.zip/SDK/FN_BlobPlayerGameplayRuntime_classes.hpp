#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Classes
//---------------------------------------------------------------------------

// Class BlobPlayerGameplayRuntime.BlobGameplayAbility_Keybind
// 0x0020 (0x0B40 - 0x0B20)
class BlobGameplayAbility_Keybind : public FortGameplayAbility
{
public:
	TArray<struct FActionDisplayTextInfo>              ActionDisplays_69;                                        // 0x0B20(0x0010) (Edit, ZeroConstructor, DisableEditOnInstance)
	class FortInputComponent*                          KeybindInputComponent_69;                                 // 0x0B30(0x0008) (ExportObject, ZeroConstructor, Transient, InstancedReference)
	bool                                               bIsDisplayActive_69;                                      // 0x0B38(0x0001) (ZeroConstructor, Transient, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0B39(0x0007) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class BlobPlayerGameplayRuntime.BlobGameplayAbility_Keybind"));
		
		return ptr;
	}


	void SetActionDisplayActive(bool bWillDisplayActive_69);
};


// Class BlobPlayerGameplayRuntime.FortBlobPlayerBlueprintLibrary
// 0x0000 (0x0028 - 0x0028)
class FortBlobPlayerBlueprintLibrary : public BlueprintFunctionLibrary
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class BlobPlayerGameplayRuntime.FortBlobPlayerBlueprintLibrary"));
		
		return ptr;
	}


	void STATIC_CheckForResumeTeleport(class FortPlayerPawn* TargetPawn_69, float UnburrowLaunchXYSpeed_69, float UnburrowLaunchZSpeed_69, float ExitHorizontalOffset_69, float ExitUpVerticalOffset_69, float ExitDownVerticalOffset_69, bool* bForceCrouch_69);
	void STATIC_BlobLog(class Object_32759* WorldContextObject_69, const struct FString& InString_69, bool bLogInShipping_69);
};


// Class BlobPlayerGameplayRuntime.FortBlobPlayerMovmentControls
// 0x0088 (0x00B8 - 0x0030)
class FortBlobPlayerMovmentControls : public FortMovementControls
{
public:
	struct FScalableFloat                              LandSpeedModifier_69;                                     // 0x0030(0x0028) (Edit, DisableEditOnInstance)
	struct FScalableFloat                              SwimSpeed_69;                                             // 0x0058(0x0028) (Edit, DisableEditOnInstance)
	struct FScalableFloat                              SwimImmersionDepth_69;                                    // 0x0080(0x0028) (Edit, DisableEditOnInstance)
	unsigned char                                      UnknownData00[0x10];                                      // 0x00A8(0x0010) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class BlobPlayerGameplayRuntime.FortBlobPlayerMovmentControls"));
		
		return ptr;
	}

};


// Class BlobPlayerGameplayRuntime.FortPawnComponent_BlobPlayer
// 0x0030 (0x00D0 - 0x00A0)
class FortPawnComponent_BlobPlayer : public FortPawnComponent
{
public:
	struct FFortPawnSkeltalMeshSettings                MeshSetting_69;                                           // 0x00A0(0x0028) (Net)
	bool                                               bShouldReapplyMeshSetting_69;                             // 0x00C8(0x0001) (ZeroConstructor, Transient, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x00C9(0x0007) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class BlobPlayerGameplayRuntime.FortPawnComponent_BlobPlayer"));
		
		return ptr;
	}


	void RecoverFromSpecialMeshSetting();
	void OnRep_MeshSetting();
	void HandleFinishedCharacterCustomization(class FortPlayerPawn* Pawn_69);
	void ApplySpecialMeshSetting(class AnimInstance* BlobAnimInstance_69, class SkeletalMesh* BlobSkeletalMesh_69, TArray<class MaterialInterface*> BlobMeshMaterials_69);
};


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

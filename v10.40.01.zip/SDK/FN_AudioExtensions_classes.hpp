#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Classes
//---------------------------------------------------------------------------

// Class AudioExtensions.SoundModulatorBase
// 0x0008 (0x0030 - 0x0028)
class SoundModulatorBase : public Object_32759
{
public:
	unsigned char                                      UnknownData00[0x8];                                       // 0x0028(0x0008) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AudioExtensions.SoundModulatorBase"));
		
		return ptr;
	}

};


// Class AudioExtensions.AudioEndpointSettingsBase
// 0x0000 (0x0028 - 0x0028)
class AudioEndpointSettingsBase : public Object_32759
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AudioExtensions.AudioEndpointSettingsBase"));
		
		return ptr;
	}

};


// Class AudioExtensions.SoundfieldEndpointSettingsBase
// 0x0000 (0x0028 - 0x0028)
class SoundfieldEndpointSettingsBase : public Object_32759
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AudioExtensions.SoundfieldEndpointSettingsBase"));
		
		return ptr;
	}

};


// Class AudioExtensions.SoundfieldEncodingSettingsBase
// 0x0000 (0x0028 - 0x0028)
class SoundfieldEncodingSettingsBase : public Object_32759
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AudioExtensions.SoundfieldEncodingSettingsBase"));
		
		return ptr;
	}

};


// Class AudioExtensions.SpatializationPluginSourceSettingsBase
// 0x0000 (0x0028 - 0x0028)
class SpatializationPluginSourceSettingsBase : public Object_32759
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AudioExtensions.SpatializationPluginSourceSettingsBase"));
		
		return ptr;
	}

};


// Class AudioExtensions.SourceDataOverridePluginSourceSettingsBase
// 0x0000 (0x0028 - 0x0028)
class SourceDataOverridePluginSourceSettingsBase : public Object_32759
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AudioExtensions.SourceDataOverridePluginSourceSettingsBase"));
		
		return ptr;
	}

};


// Class AudioExtensions.OcclusionPluginSourceSettingsBase
// 0x0000 (0x0028 - 0x0028)
class OcclusionPluginSourceSettingsBase : public Object_32759
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AudioExtensions.OcclusionPluginSourceSettingsBase"));
		
		return ptr;
	}

};


// Class AudioExtensions.ReverbPluginSourceSettingsBase
// 0x0000 (0x0028 - 0x0028)
class ReverbPluginSourceSettingsBase : public Object_32759
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AudioExtensions.ReverbPluginSourceSettingsBase"));
		
		return ptr;
	}

};


// Class AudioExtensions.AudioParameterControllerInterface
// 0x0000 (0x0028 - 0x0028)
class AudioParameterControllerInterface : public Interface
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AudioExtensions.AudioParameterControllerInterface"));
		
		return ptr;
	}


	void SetTriggerParameter(const struct FName& InName_69);
	void SetStringParameter(const struct FName& InName_69, const struct FString& InValue_69);
	void SetStringArrayParameter(const struct FName& InName_69, TArray<struct FString> InValue_69);
	void SetParameters_Blueprint(TArray<struct FAudioParameter> InParameters_69);
	void SetObjectParameter(const struct FName& InName_69, class Object_32759* InValue_69);
	void SetObjectArrayParameter(const struct FName& InName_69, TArray<class Object_32759*> InValue_69);
	void SetIntParameter(const struct FName& InName_69, int inInt_69);
	void SetIntArrayParameter(const struct FName& InName_69, TArray<int> InValue_69);
	void SetFloatParameter(const struct FName& InName_69, float InFloat_69);
	void SetFloatArrayParameter(const struct FName& InName_69, TArray<float> InValue_69);
	void SetBoolParameter(const struct FName& InName_69, bool InBool_69);
	void SetBoolArrayParameter(const struct FName& InName_69, TArray<bool> InValue_69);
	void ResetParameters();
};


// Class AudioExtensions.AudioCodecEncoderSettings
// 0x0008 (0x0030 - 0x0028)
class AudioCodecEncoderSettings : public Object_32759
{
public:
	int                                                Version_69;                                               // 0x0028(0x0004) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x002C(0x0004) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AudioExtensions.AudioCodecEncoderSettings"));
		
		return ptr;
	}

};


// Class AudioExtensions.DummyEndpointSettings
// 0x0000 (0x0028 - 0x0028)
class DummyEndpointSettings : public AudioEndpointSettingsBase
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AudioExtensions.DummyEndpointSettings"));
		
		return ptr;
	}

};


// Class AudioExtensions.SoundfieldEffectSettingsBase
// 0x0000 (0x0028 - 0x0028)
class SoundfieldEffectSettingsBase : public Object_32759
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AudioExtensions.SoundfieldEffectSettingsBase"));
		
		return ptr;
	}

};


// Class AudioExtensions.SoundfieldEffectBase
// 0x0008 (0x0030 - 0x0028)
class SoundfieldEffectBase : public Object_32759
{
public:
	class SoundfieldEffectSettingsBase*                Settings_69;                                              // 0x0028(0x0008) (Edit, ZeroConstructor)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AudioExtensions.SoundfieldEffectBase"));
		
		return ptr;
	}

};


// Class AudioExtensions.WaveformTransformationBase
// 0x0000 (0x0028 - 0x0028)
class WaveformTransformationBase : public Object_32759
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AudioExtensions.WaveformTransformationBase"));
		
		return ptr;
	}

};


// Class AudioExtensions.WaveformTransformationChain
// 0x0010 (0x0038 - 0x0028)
class WaveformTransformationChain : public Object_32759
{
public:
	TArray<class WaveformTransformationBase*>          Transformations_69;                                       // 0x0028(0x0010) (Edit, ExportObject, ZeroConstructor)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AudioExtensions.WaveformTransformationChain"));
		
		return ptr;
	}

};


// Class AudioExtensions.AudioPcmEncoderSettings
// 0x0008 (0x0038 - 0x0030)
class AudioPcmEncoderSettings : public AudioCodecEncoderSettings
{
public:
	EPcmBitDepthConversion                             BitDepthConversion_69;                                    // 0x0030(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0031(0x0007) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AudioExtensions.AudioPcmEncoderSettings"));
		
		return ptr;
	}

};


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

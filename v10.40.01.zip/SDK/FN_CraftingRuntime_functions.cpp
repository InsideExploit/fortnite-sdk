// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Functions
//---------------------------------------------------------------------------

// Function CraftingRuntime.CraftingObjectBGA.HandleInteractionRangeEndOverlap
// (Final, Native, Private)
// Parameters:
// class PrimitiveComponent*      OverlappedComponent_69         (Parm, ZeroConstructor, InstancedReference)
// class Actor_32759*             OtherActor_69                  (Parm, ZeroConstructor)
// class PrimitiveComponent*      OtherComp_69                   (Parm, ZeroConstructor, InstancedReference)
// int                            OtherBodyIndex_69              (Parm, ZeroConstructor, IsPlainOldData)

void CraftingObjectBGA::HandleInteractionRangeEndOverlap(class PrimitiveComponent* OverlappedComponent_69, class Actor_32759* OtherActor_69, class PrimitiveComponent* OtherComp_69, int OtherBodyIndex_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CraftingRuntime.CraftingObjectBGA.HandleInteractionRangeEndOverlap"));

	CraftingObjectBGA_HandleInteractionRangeEndOverlap_Params params;
	params.OverlappedComponent_69 = OverlappedComponent_69;
	params.OtherActor_69 = OtherActor_69;
	params.OtherComp_69 = OtherComp_69;
	params.OtherBodyIndex_69 = OtherBodyIndex_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CraftingRuntime.CraftingObjectBGA.HandleInteractionRangeBeginOverlap
// (Final, Native, Private, HasOutParms)
// Parameters:
// class PrimitiveComponent*      OverlappedComponent_69         (Parm, ZeroConstructor, InstancedReference)
// class Actor_32759*             OtherActor_69                  (Parm, ZeroConstructor)
// class PrimitiveComponent*      OtherComp_69                   (Parm, ZeroConstructor, InstancedReference)
// int                            OtherBodyIndex_69              (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bFromSweep_69                  (Parm, ZeroConstructor, IsPlainOldData)
// struct FHitResult              SweepResult_69                 (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)

void CraftingObjectBGA::HandleInteractionRangeBeginOverlap(class PrimitiveComponent* OverlappedComponent_69, class Actor_32759* OtherActor_69, class PrimitiveComponent* OtherComp_69, int OtherBodyIndex_69, bool bFromSweep_69, const struct FHitResult& SweepResult_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CraftingRuntime.CraftingObjectBGA.HandleInteractionRangeBeginOverlap"));

	CraftingObjectBGA_HandleInteractionRangeBeginOverlap_Params params;
	params.OverlappedComponent_69 = OverlappedComponent_69;
	params.OtherActor_69 = OtherActor_69;
	params.OtherComp_69 = OtherComp_69;
	params.OtherBodyIndex_69 = OtherBodyIndex_69;
	params.bFromSweep_69 = bFromSweep_69;
	params.SweepResult_69 = SweepResult_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CraftingRuntime.CraftingCheatManager.ToggleFreeCrafting
// (Final, Exec, Native, Public)

void CraftingCheatManager::ToggleFreeCrafting()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CraftingRuntime.CraftingCheatManager.ToggleFreeCrafting"));

	CraftingCheatManager_ToggleFreeCrafting_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CraftingRuntime.CraftingCheatManager.StartSelfCrafting
// (Final, BlueprintAuthorityOnly, Exec, Native, Public)
// Parameters:
// struct FName                   FormulaName_69                 (Parm, ZeroConstructor, IsPlainOldData)

void CraftingCheatManager::StartSelfCrafting(const struct FName& FormulaName_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CraftingRuntime.CraftingCheatManager.StartSelfCrafting"));

	CraftingCheatManager_StartSelfCrafting_Params params;
	params.FormulaName_69 = FormulaName_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CraftingRuntime.CraftingObjectComponent.OnRep_CraftingObjectRepStateData
// (Final, Native, Private)

void CraftingObjectComponent::OnRep_CraftingObjectRepStateData()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CraftingRuntime.CraftingObjectComponent.OnRep_CraftingObjectRepStateData"));

	CraftingObjectComponent_OnRep_CraftingObjectRepStateData_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CraftingRuntime.CraftingObjectComponent.HandlePickupCraftingItemPickedUp
// (Final, Native, Private, HasDefaults)
// Parameters:
// class FortPickup*              PickUp_69                      (Parm, ZeroConstructor)
// class FortPawn*                InteractingPawn_69             (Parm, ZeroConstructor)
// class FortWorldItemDefinition* WorldItemDefinition_69         (ConstParm, Parm, ZeroConstructor)
// struct FVector                 PickupLocation_69              (Parm, ZeroConstructor, IsPlainOldData)

void CraftingObjectComponent::HandlePickupCraftingItemPickedUp(class FortPickup* PickUp_69, class FortPawn* InteractingPawn_69, class FortWorldItemDefinition* WorldItemDefinition_69, const struct FVector& PickupLocation_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CraftingRuntime.CraftingObjectComponent.HandlePickupCraftingItemPickedUp"));

	CraftingObjectComponent_HandlePickupCraftingItemPickedUp_Params params;
	params.PickUp_69 = PickUp_69;
	params.InteractingPawn_69 = InteractingPawn_69;
	params.WorldItemDefinition_69 = WorldItemDefinition_69;
	params.PickupLocation_69 = PickupLocation_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// DelegateFunction CraftingRuntime.CraftingObjectComponent.CraftingObjectStateChanged__DelegateSignature
// (MulticastDelegate, Public, Delegate)
// Parameters:
// ECraftingObjectState           CraftingState_69               (Parm, ZeroConstructor, IsPlainOldData)
// float                          CraftingStateStartTime_69      (Parm, ZeroConstructor, IsPlainOldData)
// float                          CraftingStateDuration_69       (Parm, ZeroConstructor, IsPlainOldData)

void CraftingObjectComponent::CraftingObjectStateChanged__DelegateSignature(ECraftingObjectState CraftingState_69, float CraftingStateStartTime_69, float CraftingStateDuration_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("DelegateFunction CraftingRuntime.CraftingObjectComponent.CraftingObjectStateChanged__DelegateSignature"));

	CraftingObjectComponent_CraftingObjectStateChanged__DelegateSignature_Params params;
	params.CraftingState_69 = CraftingState_69;
	params.CraftingStateStartTime_69 = CraftingStateStartTime_69;
	params.CraftingStateDuration_69 = CraftingStateDuration_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// DelegateFunction CraftingRuntime.CraftingObjectComponent.CraftingObjectOnFormulaCraftableChanged__DelegateSignature
// (MulticastDelegate, Public, Delegate, HasOutParms)
// Parameters:
// struct FName                   FormulaRowName_69              (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
// bool                           bIsCraftable_69                (Parm, ZeroConstructor, IsPlainOldData)

void CraftingObjectComponent::CraftingObjectOnFormulaCraftableChanged__DelegateSignature(const struct FName& FormulaRowName_69, bool bIsCraftable_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("DelegateFunction CraftingRuntime.CraftingObjectComponent.CraftingObjectOnFormulaCraftableChanged__DelegateSignature"));

	CraftingObjectComponent_CraftingObjectOnFormulaCraftableChanged__DelegateSignature_Params params;
	params.FormulaRowName_69 = FormulaRowName_69;
	params.bIsCraftable_69 = bIsCraftable_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CraftingRuntime.FortControllerComponent_CraftingNetworkEvents.ServerStartCrafting
// (Net, NetReliable, Native, Event, Public, NetServer, BlueprintCallable, NetValidate)
// Parameters:
// class Actor_32759*             CraftingObject_69              (Parm, ZeroConstructor)
// struct FName                   CraftingFormulaName_69         (ConstParm, Parm, ZeroConstructor, ReferenceParm, IsPlainOldData)
// int                            NumberToCraft_69               (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void FortControllerComponent_CraftingNetworkEvents::ServerStartCrafting(class Actor_32759* CraftingObject_69, const struct FName& CraftingFormulaName_69, int NumberToCraft_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CraftingRuntime.FortControllerComponent_CraftingNetworkEvents.ServerStartCrafting"));

	FortControllerComponent_CraftingNetworkEvents_ServerStartCrafting_Params params;
	params.CraftingObject_69 = CraftingObject_69;
	params.CraftingFormulaName_69 = CraftingFormulaName_69;
	params.NumberToCraft_69 = NumberToCraft_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CraftingRuntime.FortControllerComponent_CraftingNetworkEvents.ServerReportCraftingSuccess
// (Net, NetReliable, Native, Event, Public, NetServer, BlueprintCallable, NetValidate)
// Parameters:
// class Actor_32759*             CraftingObject_69              (Parm, ZeroConstructor)

void FortControllerComponent_CraftingNetworkEvents::ServerReportCraftingSuccess(class Actor_32759* CraftingObject_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CraftingRuntime.FortControllerComponent_CraftingNetworkEvents.ServerReportCraftingSuccess"));

	FortControllerComponent_CraftingNetworkEvents_ServerReportCraftingSuccess_Params params;
	params.CraftingObject_69 = CraftingObject_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CraftingRuntime.FortControllerComponent_CraftingNetworkEvents.ServerPickupItemAndStartCrafting
// (Net, NetReliable, Native, Event, Public, NetServer, BlueprintCallable, NetValidate)
// Parameters:
// class Actor_32759*             CraftingObject_69              (Parm, ZeroConstructor)
// class FortPickup*              PickUp_69                      (Parm, ZeroConstructor)
// struct FName                   CraftingFormulaName_69         (ConstParm, Parm, ZeroConstructor, ReferenceParm, IsPlainOldData)

void FortControllerComponent_CraftingNetworkEvents::ServerPickupItemAndStartCrafting(class Actor_32759* CraftingObject_69, class FortPickup* PickUp_69, const struct FName& CraftingFormulaName_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CraftingRuntime.FortControllerComponent_CraftingNetworkEvents.ServerPickupItemAndStartCrafting"));

	FortControllerComponent_CraftingNetworkEvents_ServerPickupItemAndStartCrafting_Params params;
	params.CraftingObject_69 = CraftingObject_69;
	params.PickUp_69 = PickUp_69;
	params.CraftingFormulaName_69 = CraftingFormulaName_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CraftingRuntime.FortControllerComponent_CraftingNetworkEvents.ServerEjectItems
// (Net, NetReliable, Native, Event, Public, NetServer, BlueprintCallable, NetValidate)
// Parameters:
// class Actor_32759*             CraftingObject_69              (Parm, ZeroConstructor)

void FortControllerComponent_CraftingNetworkEvents::ServerEjectItems(class Actor_32759* CraftingObject_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CraftingRuntime.FortControllerComponent_CraftingNetworkEvents.ServerEjectItems"));

	FortControllerComponent_CraftingNetworkEvents_ServerEjectItems_Params params;
	params.CraftingObject_69 = CraftingObject_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CraftingRuntime.FortControllerComponent_CraftingNetworkEvents.ServerClaimCraftingResults
// (Net, NetReliable, Native, Event, Public, NetServer, BlueprintCallable, NetValidate)
// Parameters:
// class Actor_32759*             CraftingObject_69              (Parm, ZeroConstructor)

void FortControllerComponent_CraftingNetworkEvents::ServerClaimCraftingResults(class Actor_32759* CraftingObject_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CraftingRuntime.FortControllerComponent_CraftingNetworkEvents.ServerClaimCraftingResults"));

	FortControllerComponent_CraftingNetworkEvents_ServerClaimCraftingResults_Params params;
	params.CraftingObject_69 = CraftingObject_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CraftingRuntime.FortControllerComponent_CraftingNetworkEvents.ServerCancelCrafting
// (Net, NetReliable, Native, Event, Public, NetServer, BlueprintCallable, NetValidate)
// Parameters:
// class Actor_32759*             CraftingObject_69              (Parm, ZeroConstructor)

void FortControllerComponent_CraftingNetworkEvents::ServerCancelCrafting(class Actor_32759* CraftingObject_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CraftingRuntime.FortControllerComponent_CraftingNetworkEvents.ServerCancelCrafting"));

	FortControllerComponent_CraftingNetworkEvents_ServerCancelCrafting_Params params;
	params.CraftingObject_69 = CraftingObject_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CraftingRuntime.FortControllerComponent_CraftingNetworkEvents.NotifyCraftingSuccess
// (Final, Native, Public, HasOutParms)
// Parameters:
// class Actor_32759*             CraftingObject_69              (Parm, ZeroConstructor)
// struct FName                   FormulaRowName_69              (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)

void FortControllerComponent_CraftingNetworkEvents::NotifyCraftingSuccess(class Actor_32759* CraftingObject_69, const struct FName& FormulaRowName_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CraftingRuntime.FortControllerComponent_CraftingNetworkEvents.NotifyCraftingSuccess"));

	FortControllerComponent_CraftingNetworkEvents_NotifyCraftingSuccess_Params params;
	params.CraftingObject_69 = CraftingObject_69;
	params.FormulaRowName_69 = FormulaRowName_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CraftingRuntime.FortControllerComponent_CraftingNetworkEvents.ClientNotifyCraftingSuccess
// (Net, Native, Event, Public, NetClient)
// Parameters:
// class Actor_32759*             CraftingObject_69              (Parm, ZeroConstructor)
// struct FName                   FormulaRowName_69              (ConstParm, Parm, ZeroConstructor, ReferenceParm, IsPlainOldData)

void FortControllerComponent_CraftingNetworkEvents::ClientNotifyCraftingSuccess(class Actor_32759* CraftingObject_69, const struct FName& FormulaRowName_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CraftingRuntime.FortControllerComponent_CraftingNetworkEvents.ClientNotifyCraftingSuccess"));

	FortControllerComponent_CraftingNetworkEvents_ClientNotifyCraftingSuccess_Params params;
	params.CraftingObject_69 = CraftingObject_69;
	params.FormulaRowName_69 = FormulaRowName_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CraftingRuntime.FortControllerComponent_CraftingNetworkEvents.ClientNotifyCraftingFailed
// (Net, Native, Event, Public, NetClient)
// Parameters:
// class Actor_32759*             CraftingObject_69              (Parm, ZeroConstructor)
// struct FGameplayTagContainer   FailedReason_69                (ConstParm, Parm, ReferenceParm)

void FortControllerComponent_CraftingNetworkEvents::ClientNotifyCraftingFailed(class Actor_32759* CraftingObject_69, const struct FGameplayTagContainer& FailedReason_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CraftingRuntime.FortControllerComponent_CraftingNetworkEvents.ClientNotifyCraftingFailed"));

	FortControllerComponent_CraftingNetworkEvents_ClientNotifyCraftingFailed_Params params;
	params.CraftingObject_69 = CraftingObject_69;
	params.FailedReason_69 = FailedReason_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CraftingRuntime.FortGameStateComponent_Crafting.OnRep_CraftingResultsList
// (Final, Native, Protected)

void FortGameStateComponent_Crafting::OnRep_CraftingResultsList()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CraftingRuntime.FortGameStateComponent_Crafting.OnRep_CraftingResultsList"));

	FortGameStateComponent_Crafting_OnRep_CraftingResultsList_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CraftingRuntime.FortGameStateComponent_Crafting.OnPlaylistDataReady
// (Final, Native, Protected, HasOutParms)
// Parameters:
// class FortGameStateAthena*     GameState_69                   (Parm, ZeroConstructor)
// class FortPlaylist*            Playlist_69                    (ConstParm, Parm, ZeroConstructor)
// struct FGameplayTagContainer   PlaylistContextTags_69         (ConstParm, Parm, OutParm, ReferenceParm)

void FortGameStateComponent_Crafting::OnPlaylistDataReady(class FortGameStateAthena* GameState_69, class FortPlaylist* Playlist_69, const struct FGameplayTagContainer& PlaylistContextTags_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CraftingRuntime.FortGameStateComponent_Crafting.OnPlaylistDataReady"));

	FortGameStateComponent_Crafting_OnPlaylistDataReady_Params params;
	params.GameState_69 = GameState_69;
	params.Playlist_69 = Playlist_69;
	params.PlaylistContextTags_69 = PlaylistContextTags_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CraftingRuntime.FortContextualTutorial_CraftingComplete.OnCraftingSuccess
// (Final, Native, Private, HasOutParms)
// Parameters:
// class FortPlayerController*    Instigator_69                  (Parm, ZeroConstructor)
// class Actor_32759*             CraftingObject_69              (Parm, ZeroConstructor)
// struct FName                   FormulaRowName_69              (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)

void FortContextualTutorial_CraftingComplete::OnCraftingSuccess(class FortPlayerController* Instigator_69, class Actor_32759* CraftingObject_69, const struct FName& FormulaRowName_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CraftingRuntime.FortContextualTutorial_CraftingComplete.OnCraftingSuccess"));

	FortContextualTutorial_CraftingComplete_OnCraftingSuccess_Params params;
	params.Instigator_69 = Instigator_69;
	params.CraftingObject_69 = CraftingObject_69;
	params.FormulaRowName_69 = FormulaRowName_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CraftingRuntime.FortContextualTutorial_CraftingReady.HandleFormulaCraftableChanged
// (Final, Native, Private, HasOutParms)
// Parameters:
// struct FName                   FormulaRowName_69              (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
// bool                           bIsCraftable_69                (Parm, ZeroConstructor, IsPlainOldData)

void FortContextualTutorial_CraftingReady::HandleFormulaCraftableChanged(const struct FName& FormulaRowName_69, bool bIsCraftable_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CraftingRuntime.FortContextualTutorial_CraftingReady.HandleFormulaCraftableChanged"));

	FortContextualTutorial_CraftingReady_HandleFormulaCraftableChanged_Params params;
	params.FormulaRowName_69 = FormulaRowName_69;
	params.bIsCraftable_69 = bIsCraftable_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CraftingRuntime.FortContextualTutorial_CraftingTabOpen.HandleInventoryTabChanged
// (Final, Native, Private)
// Parameters:
// struct FName                   InventoryTabNameId_69          (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void FortContextualTutorial_CraftingTabOpen::HandleInventoryTabChanged(const struct FName& InventoryTabNameId_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CraftingRuntime.FortContextualTutorial_CraftingTabOpen.HandleInventoryTabChanged"));

	FortContextualTutorial_CraftingTabOpen_HandleInventoryTabChanged_Params params;
	params.InventoryTabNameId_69 = InventoryTabNameId_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CraftingRuntime.FortContextualTutorial_CraftingTabOpen.HandleFormulaCraftableChanged
// (Final, Native, Private, HasOutParms)
// Parameters:
// struct FName                   FormulaRowName_69              (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
// bool                           bIsCraftable_69                (Parm, ZeroConstructor, IsPlainOldData)

void FortContextualTutorial_CraftingTabOpen::HandleFormulaCraftableChanged(const struct FName& FormulaRowName_69, bool bIsCraftable_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CraftingRuntime.FortContextualTutorial_CraftingTabOpen.HandleFormulaCraftableChanged"));

	FortContextualTutorial_CraftingTabOpen_HandleFormulaCraftableChanged_Params params;
	params.FormulaRowName_69 = FormulaRowName_69;
	params.bIsCraftable_69 = bIsCraftable_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CraftingRuntime.CraftingLibrary.StartCrafting
// (Final, Native, Static, Public, HasOutParms, BlueprintCallable)
// Parameters:
// class FortPlayerController*    Instigator_69                  (Parm, ZeroConstructor)
// class Actor_32759*             CraftingObject_69              (Parm, ZeroConstructor)
// struct FName                   CraftingFormulaName_69         (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
// int                            NumberToCraft_69               (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void CraftingLibrary::STATIC_StartCrafting(class FortPlayerController* Instigator_69, class Actor_32759* CraftingObject_69, const struct FName& CraftingFormulaName_69, int NumberToCraft_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CraftingRuntime.CraftingLibrary.StartCrafting"));

	CraftingLibrary_StartCrafting_Params params;
	params.Instigator_69 = Instigator_69;
	params.CraftingObject_69 = CraftingObject_69;
	params.CraftingFormulaName_69 = CraftingFormulaName_69;
	params.NumberToCraft_69 = NumberToCraft_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CraftingRuntime.CraftingLibrary.ReportCraftingSuccess
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// class FortPlayerController*    Instigator_69                  (Parm, ZeroConstructor)
// class Actor_32759*             CraftingObject_69              (Parm, ZeroConstructor)

void CraftingLibrary::STATIC_ReportCraftingSuccess(class FortPlayerController* Instigator_69, class Actor_32759* CraftingObject_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CraftingRuntime.CraftingLibrary.ReportCraftingSuccess"));

	CraftingLibrary_ReportCraftingSuccess_Params params;
	params.Instigator_69 = Instigator_69;
	params.CraftingObject_69 = CraftingObject_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CraftingRuntime.CraftingLibrary.PickupItemAndStartCrafting
// (Final, Native, Static, Public, HasOutParms, BlueprintCallable)
// Parameters:
// class FortPlayerController*    Instigator_69                  (Parm, ZeroConstructor)
// class Actor_32759*             CraftingObject_69              (Parm, ZeroConstructor)
// class FortPickup*              PickUp_69                      (Parm, ZeroConstructor)
// struct FName                   CraftingFormulaName_69         (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)

void CraftingLibrary::STATIC_PickupItemAndStartCrafting(class FortPlayerController* Instigator_69, class Actor_32759* CraftingObject_69, class FortPickup* PickUp_69, const struct FName& CraftingFormulaName_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CraftingRuntime.CraftingLibrary.PickupItemAndStartCrafting"));

	CraftingLibrary_PickupItemAndStartCrafting_Params params;
	params.Instigator_69 = Instigator_69;
	params.CraftingObject_69 = CraftingObject_69;
	params.PickUp_69 = PickUp_69;
	params.CraftingFormulaName_69 = CraftingFormulaName_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CraftingRuntime.CraftingLibrary.IsValidIngredient
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// class FortPlayerController*    FortPC_69                      (ConstParm, Parm, ZeroConstructor)
// class Actor_32759*             CraftingObject_69              (ConstParm, Parm, ZeroConstructor)
// class FortItemDefinition*      ItemDef_69                     (ConstParm, Parm, ZeroConstructor)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool CraftingLibrary::STATIC_IsValidIngredient(class FortPlayerController* FortPC_69, class Actor_32759* CraftingObject_69, class FortItemDefinition* ItemDef_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CraftingRuntime.CraftingLibrary.IsValidIngredient"));

	CraftingLibrary_IsValidIngredient_Params params;
	params.FortPC_69 = FortPC_69;
	params.CraftingObject_69 = CraftingObject_69;
	params.ItemDef_69 = ItemDef_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CraftingRuntime.CraftingLibrary.GiveItemToCraftingObject
// (Final, Native, Static, Public, HasOutParms, BlueprintCallable, BlueprintPure)
// Parameters:
// class FortPlayerController*    Instigator_69                  (Parm, ZeroConstructor)
// class Actor_32759*             CraftingObject_69              (Parm, ZeroConstructor)
// struct FFortItemEntry          ItemEntryToGrant_69            (ConstParm, Parm, OutParm, ReferenceParm)

void CraftingLibrary::STATIC_GiveItemToCraftingObject(class FortPlayerController* Instigator_69, class Actor_32759* CraftingObject_69, const struct FFortItemEntry& ItemEntryToGrant_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CraftingRuntime.CraftingLibrary.GiveItemToCraftingObject"));

	CraftingLibrary_GiveItemToCraftingObject_Params params;
	params.Instigator_69 = Instigator_69;
	params.CraftingObject_69 = CraftingObject_69;
	params.ItemEntryToGrant_69 = ItemEntryToGrant_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CraftingRuntime.CraftingLibrary.GetValidIngredientsInInventory
// (Final, Native, Static, Public, HasOutParms, BlueprintCallable)
// Parameters:
// class FortPlayerController*    FortPC_69                      (ConstParm, Parm, ZeroConstructor)
// class Actor_32759*             CraftingObject_69              (ConstParm, Parm, ZeroConstructor)
// TArray<class FortWorldItem*>   OutIngredients_69              (Parm, OutParm, ZeroConstructor)

void CraftingLibrary::STATIC_GetValidIngredientsInInventory(class FortPlayerController* FortPC_69, class Actor_32759* CraftingObject_69, TArray<class FortWorldItem*>* OutIngredients_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CraftingRuntime.CraftingLibrary.GetValidIngredientsInInventory"));

	CraftingLibrary_GetValidIngredientsInInventory_Params params;
	params.FortPC_69 = FortPC_69;
	params.CraftingObject_69 = CraftingObject_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (OutIngredients_69 != nullptr)
		*OutIngredients_69 = params.OutIngredients_69;
}


// Function CraftingRuntime.CraftingLibrary.GetUIDataForCraftingIngredientTags
// (Final, Native, Static, Public, HasOutParms, BlueprintCallable)
// Parameters:
// class Object_32759*            WorldContextObject_69          (Parm, ZeroConstructor)
// struct FGameplayTagContainer   IngredientTags_69              (ConstParm, Parm, OutParm, ReferenceParm)

void CraftingLibrary::STATIC_GetUIDataForCraftingIngredientTags(class Object_32759* WorldContextObject_69, const struct FGameplayTagContainer& IngredientTags_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CraftingRuntime.CraftingLibrary.GetUIDataForCraftingIngredientTags"));

	CraftingLibrary_GetUIDataForCraftingIngredientTags_Params params;
	params.WorldContextObject_69 = WorldContextObject_69;
	params.IngredientTags_69 = IngredientTags_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CraftingRuntime.CraftingLibrary.GetKnownCraftingFormulas
// (Final, Native, Static, Public, HasOutParms, BlueprintCallable)
// Parameters:
// class FortPlayerController*    FortPC_69                      (ConstParm, Parm, ZeroConstructor)
// class Actor_32759*             CraftingObject_69              (ConstParm, Parm, ZeroConstructor)
// TArray<struct FName>           OutFormulas_69                 (Parm, OutParm, ZeroConstructor)

void CraftingLibrary::STATIC_GetKnownCraftingFormulas(class FortPlayerController* FortPC_69, class Actor_32759* CraftingObject_69, TArray<struct FName>* OutFormulas_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CraftingRuntime.CraftingLibrary.GetKnownCraftingFormulas"));

	CraftingLibrary_GetKnownCraftingFormulas_Params params;
	params.FortPC_69 = FortPC_69;
	params.CraftingObject_69 = CraftingObject_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (OutFormulas_69 != nullptr)
		*OutFormulas_69 = params.OutFormulas_69;
}


// Function CraftingRuntime.CraftingLibrary.GetIngredientsInCraftingObject
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// class Actor_32759*             CraftingObject_69              (Parm, ZeroConstructor)
// TArray<class FortWorldItem*>   ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

TArray<class FortWorldItem*> CraftingLibrary::STATIC_GetIngredientsInCraftingObject(class Actor_32759* CraftingObject_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CraftingRuntime.CraftingLibrary.GetIngredientsInCraftingObject"));

	CraftingLibrary_GetIngredientsInCraftingObject_Params params;
	params.CraftingObject_69 = CraftingObject_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CraftingRuntime.CraftingLibrary.GetCraftingResultsForRowName
// (Final, Native, Static, Public, HasOutParms, BlueprintCallable)
// Parameters:
// class Object_32759*            WorldContextObject_69          (ConstParm, Parm, ZeroConstructor)
// struct FName                   CraftingFormulaRow_69          (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
// TArray<struct FItemAndCount>   OutResults_69                  (Parm, OutParm, ZeroConstructor)
// int                            NumToCraft_69                  (Parm, ZeroConstructor, IsPlainOldData)

void CraftingLibrary::STATIC_GetCraftingResultsForRowName(class Object_32759* WorldContextObject_69, const struct FName& CraftingFormulaRow_69, int NumToCraft_69, TArray<struct FItemAndCount>* OutResults_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CraftingRuntime.CraftingLibrary.GetCraftingResultsForRowName"));

	CraftingLibrary_GetCraftingResultsForRowName_Params params;
	params.WorldContextObject_69 = WorldContextObject_69;
	params.CraftingFormulaRow_69 = CraftingFormulaRow_69;
	params.NumToCraft_69 = NumToCraft_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (OutResults_69 != nullptr)
		*OutResults_69 = params.OutResults_69;
}


// Function CraftingRuntime.CraftingLibrary.GetCraftingObjectCurrentCraftingStateTimeLeft
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// class Actor_32759*             CraftingObject_69              (ConstParm, Parm, ZeroConstructor)
// float                          ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

float CraftingLibrary::STATIC_GetCraftingObjectCurrentCraftingStateTimeLeft(class Actor_32759* CraftingObject_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CraftingRuntime.CraftingLibrary.GetCraftingObjectCurrentCraftingStateTimeLeft"));

	CraftingLibrary_GetCraftingObjectCurrentCraftingStateTimeLeft_Params params;
	params.CraftingObject_69 = CraftingObject_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CraftingRuntime.CraftingLibrary.GetCraftingObjectCurrentCraftingStateStartTime
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// class Actor_32759*             CraftingObject_69              (ConstParm, Parm, ZeroConstructor)
// float                          ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

float CraftingLibrary::STATIC_GetCraftingObjectCurrentCraftingStateStartTime(class Actor_32759* CraftingObject_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CraftingRuntime.CraftingLibrary.GetCraftingObjectCurrentCraftingStateStartTime"));

	CraftingLibrary_GetCraftingObjectCurrentCraftingStateStartTime_Params params;
	params.CraftingObject_69 = CraftingObject_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CraftingRuntime.CraftingLibrary.GetCraftingObjectCurrentCraftingStateEndTime
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// class Actor_32759*             CraftingObject_69              (ConstParm, Parm, ZeroConstructor)
// float                          ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

float CraftingLibrary::STATIC_GetCraftingObjectCurrentCraftingStateEndTime(class Actor_32759* CraftingObject_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CraftingRuntime.CraftingLibrary.GetCraftingObjectCurrentCraftingStateEndTime"));

	CraftingLibrary_GetCraftingObjectCurrentCraftingStateEndTime_Params params;
	params.CraftingObject_69 = CraftingObject_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CraftingRuntime.CraftingLibrary.GetCraftingObjectCraftingState
// (Final, Native, Static, Public, BlueprintCallable, BlueprintPure)
// Parameters:
// class Actor_32759*             CraftingObject_69              (Parm, ZeroConstructor)
// ECraftingObjectState           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

ECraftingObjectState CraftingLibrary::STATIC_GetCraftingObjectCraftingState(class Actor_32759* CraftingObject_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CraftingRuntime.CraftingLibrary.GetCraftingObjectCraftingState"));

	CraftingLibrary_GetCraftingObjectCraftingState_Params params;
	params.CraftingObject_69 = CraftingObject_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CraftingRuntime.CraftingLibrary.GetCraftingIngredients_TempItems
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// class Actor_32759*             CraftingObject_69              (Parm, ZeroConstructor)
// TArray<class FortWorldItem*>   ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

TArray<class FortWorldItem*> CraftingLibrary::STATIC_GetCraftingIngredients_TempItems(class Actor_32759* CraftingObject_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CraftingRuntime.CraftingLibrary.GetCraftingIngredients_TempItems"));

	CraftingLibrary_GetCraftingIngredients_TempItems_Params params;
	params.CraftingObject_69 = CraftingObject_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CraftingRuntime.CraftingLibrary.GetCraftingFormulaNameBeingCrafted
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// class Actor_32759*             CraftingObject_69              (Parm, ZeroConstructor)
// struct FName                   ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

struct FName CraftingLibrary::STATIC_GetCraftingFormulaNameBeingCrafted(class Actor_32759* CraftingObject_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CraftingRuntime.CraftingLibrary.GetCraftingFormulaNameBeingCrafted"));

	CraftingLibrary_GetCraftingFormulaNameBeingCrafted_Params params;
	params.CraftingObject_69 = CraftingObject_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CraftingRuntime.CraftingLibrary.GetCraftingFormulaIngredientRequirements
// (Final, Native, Static, Public, HasOutParms, BlueprintCallable)
// Parameters:
// class Object_32759*            WorldContextObject_69          (Parm, ZeroConstructor)
// struct FName                   CraftingFormulaRow_69          (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
// TArray<struct FCraftingIngredientRequirement> OutIngredientRequirements_69   (Parm, OutParm, ZeroConstructor)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool CraftingLibrary::STATIC_GetCraftingFormulaIngredientRequirements(class Object_32759* WorldContextObject_69, const struct FName& CraftingFormulaRow_69, TArray<struct FCraftingIngredientRequirement>* OutIngredientRequirements_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CraftingRuntime.CraftingLibrary.GetCraftingFormulaIngredientRequirements"));

	CraftingLibrary_GetCraftingFormulaIngredientRequirements_Params params;
	params.WorldContextObject_69 = WorldContextObject_69;
	params.CraftingFormulaRow_69 = CraftingFormulaRow_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (OutIngredientRequirements_69 != nullptr)
		*OutIngredientRequirements_69 = params.OutIngredientRequirements_69;

	return params.ReturnValue_69;
}


// Function CraftingRuntime.CraftingLibrary.GetCraftedResults_TempItems
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// class Actor_32759*             CraftingObject_69              (Parm, ZeroConstructor)
// TArray<class FortWorldItem*>   ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

TArray<class FortWorldItem*> CraftingLibrary::STATIC_GetCraftedResults_TempItems(class Actor_32759* CraftingObject_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CraftingRuntime.CraftingLibrary.GetCraftedResults_TempItems"));

	CraftingLibrary_GetCraftedResults_TempItems_Params params;
	params.CraftingObject_69 = CraftingObject_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CraftingRuntime.CraftingLibrary.GetAllValidIngredients
// (Final, Native, Static, Public, HasOutParms, BlueprintCallable)
// Parameters:
// class FortPlayerController*    FortPC_69                      (ConstParm, Parm, ZeroConstructor)
// class Actor_32759*             CraftingObject_69              (ConstParm, Parm, ZeroConstructor)
// TArray<struct FGameplayTagContainer> OutIngredients_69              (Parm, OutParm, ZeroConstructor)

void CraftingLibrary::STATIC_GetAllValidIngredients(class FortPlayerController* FortPC_69, class Actor_32759* CraftingObject_69, TArray<struct FGameplayTagContainer>* OutIngredients_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CraftingRuntime.CraftingLibrary.GetAllValidIngredients"));

	CraftingLibrary_GetAllValidIngredients_Params params;
	params.FortPC_69 = FortPC_69;
	params.CraftingObject_69 = CraftingObject_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (OutIngredients_69 != nullptr)
		*OutIngredients_69 = params.OutIngredients_69;
}


// Function CraftingRuntime.CraftingLibrary.GetAllCraftingFormulas
// (Final, Native, Static, Public, HasOutParms, BlueprintCallable)
// Parameters:
// class FortPlayerController*    FortPC_69                      (ConstParm, Parm, ZeroConstructor)
// class Actor_32759*             CraftingObject_69              (ConstParm, Parm, ZeroConstructor)
// TArray<struct FName>           OutFormulas_69                 (Parm, OutParm, ZeroConstructor)

void CraftingLibrary::STATIC_GetAllCraftingFormulas(class FortPlayerController* FortPC_69, class Actor_32759* CraftingObject_69, TArray<struct FName>* OutFormulas_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CraftingRuntime.CraftingLibrary.GetAllCraftingFormulas"));

	CraftingLibrary_GetAllCraftingFormulas_Params params;
	params.FortPC_69 = FortPC_69;
	params.CraftingObject_69 = CraftingObject_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (OutFormulas_69 != nullptr)
		*OutFormulas_69 = params.OutFormulas_69;
}


// Function CraftingRuntime.CraftingLibrary.GetAllCraftableFormulas
// (Final, Native, Static, Public, HasOutParms, BlueprintCallable)
// Parameters:
// class FortPlayerController*    FortPC_69                      (ConstParm, Parm, ZeroConstructor)
// class Actor_32759*             CraftingObject_69              (ConstParm, Parm, ZeroConstructor)
// TArray<struct FName>           OutFormulas_69                 (Parm, OutParm, ZeroConstructor)

void CraftingLibrary::STATIC_GetAllCraftableFormulas(class FortPlayerController* FortPC_69, class Actor_32759* CraftingObject_69, TArray<struct FName>* OutFormulas_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CraftingRuntime.CraftingLibrary.GetAllCraftableFormulas"));

	CraftingLibrary_GetAllCraftableFormulas_Params params;
	params.FortPC_69 = FortPC_69;
	params.CraftingObject_69 = CraftingObject_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (OutFormulas_69 != nullptr)
		*OutFormulas_69 = params.OutFormulas_69;
}


// Function CraftingRuntime.CraftingLibrary.EjectItems
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// class FortPlayerController*    Instigator_69                  (Parm, ZeroConstructor)
// class Actor_32759*             CraftingObject_69              (Parm, ZeroConstructor)

void CraftingLibrary::STATIC_EjectItems(class FortPlayerController* Instigator_69, class Actor_32759* CraftingObject_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CraftingRuntime.CraftingLibrary.EjectItems"));

	CraftingLibrary_EjectItems_Params params;
	params.Instigator_69 = Instigator_69;
	params.CraftingObject_69 = CraftingObject_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CraftingRuntime.CraftingLibrary.ClaimCraftingResults
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// class FortPlayerController*    Instigator_69                  (Parm, ZeroConstructor)
// class Actor_32759*             CraftingObject_69              (Parm, ZeroConstructor)

void CraftingLibrary::STATIC_ClaimCraftingResults(class FortPlayerController* Instigator_69, class Actor_32759* CraftingObject_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CraftingRuntime.CraftingLibrary.ClaimCraftingResults"));

	CraftingLibrary_ClaimCraftingResults_Params params;
	params.Instigator_69 = Instigator_69;
	params.CraftingObject_69 = CraftingObject_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CraftingRuntime.CraftingLibrary.CanCraftFormulaWithAdditionalItems
// (Final, Native, Static, Public, HasOutParms, BlueprintCallable)
// Parameters:
// class FortPlayerController*    FortPC_69                      (ConstParm, Parm, ZeroConstructor)
// class Actor_32759*             CraftingObject_69              (ConstParm, Parm, ZeroConstructor)
// struct FName                   CraftingFormulaRow_69          (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// TArray<struct FItemAndCount>   AdditionalItems_69             (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
// TArray<struct FCraftingIngredientQueryState> OutIngredientStates_69         (Parm, OutParm, ZeroConstructor)
// int                            NumberToCraft_69               (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool CraftingLibrary::STATIC_CanCraftFormulaWithAdditionalItems(class FortPlayerController* FortPC_69, class Actor_32759* CraftingObject_69, const struct FName& CraftingFormulaRow_69, TArray<struct FItemAndCount> AdditionalItems_69, int NumberToCraft_69, TArray<struct FCraftingIngredientQueryState>* OutIngredientStates_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CraftingRuntime.CraftingLibrary.CanCraftFormulaWithAdditionalItems"));

	CraftingLibrary_CanCraftFormulaWithAdditionalItems_Params params;
	params.FortPC_69 = FortPC_69;
	params.CraftingObject_69 = CraftingObject_69;
	params.CraftingFormulaRow_69 = CraftingFormulaRow_69;
	params.AdditionalItems_69 = AdditionalItems_69;
	params.NumberToCraft_69 = NumberToCraft_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (OutIngredientStates_69 != nullptr)
		*OutIngredientStates_69 = params.OutIngredientStates_69;

	return params.ReturnValue_69;
}


// Function CraftingRuntime.CraftingLibrary.CanCraftFormula
// (Final, Native, Static, Public, HasOutParms, BlueprintCallable)
// Parameters:
// class FortPlayerController*    FortPC_69                      (ConstParm, Parm, ZeroConstructor)
// class Actor_32759*             CraftingObject_69              (ConstParm, Parm, ZeroConstructor)
// struct FName                   CraftingFormulaRow_69          (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// TArray<struct FCraftingIngredientQueryState> OutIngredientStates_69         (Parm, OutParm, ZeroConstructor)
// int                            NumberToCraft_69               (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool CraftingLibrary::STATIC_CanCraftFormula(class FortPlayerController* FortPC_69, class Actor_32759* CraftingObject_69, const struct FName& CraftingFormulaRow_69, int NumberToCraft_69, TArray<struct FCraftingIngredientQueryState>* OutIngredientStates_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CraftingRuntime.CraftingLibrary.CanCraftFormula"));

	CraftingLibrary_CanCraftFormula_Params params;
	params.FortPC_69 = FortPC_69;
	params.CraftingObject_69 = CraftingObject_69;
	params.CraftingFormulaRow_69 = CraftingFormulaRow_69;
	params.NumberToCraft_69 = NumberToCraft_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (OutIngredientStates_69 != nullptr)
		*OutIngredientStates_69 = params.OutIngredientStates_69;

	return params.ReturnValue_69;
}


// Function CraftingRuntime.CraftingLibrary.CancelCrafting
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// class FortPlayerController*    Instigator_69                  (Parm, ZeroConstructor)
// class Actor_32759*             CraftingObject_69              (Parm, ZeroConstructor)

void CraftingLibrary::STATIC_CancelCrafting(class FortPlayerController* Instigator_69, class Actor_32759* CraftingObject_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CraftingRuntime.CraftingLibrary.CancelCrafting"));

	CraftingLibrary_CancelCrafting_Params params;
	params.Instigator_69 = Instigator_69;
	params.CraftingObject_69 = CraftingObject_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

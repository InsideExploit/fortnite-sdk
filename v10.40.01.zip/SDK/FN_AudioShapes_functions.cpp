// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Functions
//---------------------------------------------------------------------------

// Function AudioShapes.AudioShapeComponent.UpdateAudioShape
// (Final, Native, Public, HasOutParms)
// Parameters:
// TArray<class PlayerController*> InLocalControllers_69          (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)

void AudioShapeComponent::UpdateAudioShape(TArray<class PlayerController*> InLocalControllers_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioShapes.AudioShapeComponent.UpdateAudioShape"));

	AudioShapeComponent_UpdateAudioShape_Params params;
	params.InLocalControllers_69 = InLocalControllers_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AudioShapes.AudioShapePrimitiveComponent.GetIsPlayerInside
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool AudioShapePrimitiveComponent::GetIsPlayerInside()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioShapes.AudioShapePrimitiveComponent.GetIsPlayerInside"));

	AudioShapePrimitiveComponent_GetIsPlayerInside_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AudioShapes.AudioShapePrimitiveComponent.GetInsideAudioComponent
// (Final, Native, Public, BlueprintCallable, BlueprintPure)
// Parameters:
// class AudioComponent*          ReturnValue_69                 (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)

class AudioComponent* AudioShapePrimitiveComponent::GetInsideAudioComponent()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioShapes.AudioShapePrimitiveComponent.GetInsideAudioComponent"));

	AudioShapePrimitiveComponent_GetInsideAudioComponent_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AudioShapes.AudioShapePrimitiveComponent.GetEdgeAudioComponent
// (Final, Native, Public, BlueprintCallable, BlueprintPure)
// Parameters:
// class AudioComponent*          ReturnValue_69                 (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)

class AudioComponent* AudioShapePrimitiveComponent::GetEdgeAudioComponent()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioShapes.AudioShapePrimitiveComponent.GetEdgeAudioComponent"));

	AudioShapePrimitiveComponent_GetEdgeAudioComponent_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AudioShapes.AudioShapeBoxComponent.SetBoxTransform
// (Final, Native, Public, HasOutParms, HasDefaults, BlueprintCallable)
// Parameters:
// struct FCoreUObject_FTransform InTransform_69                 (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)

void AudioShapeBoxComponent::SetBoxTransform(const struct FCoreUObject_FTransform& InTransform_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioShapes.AudioShapeBoxComponent.SetBoxTransform"));

	AudioShapeBoxComponent_SetBoxTransform_Params params;
	params.InTransform_69 = InTransform_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AudioShapes.AudioShapeCylinderComponent.SetRadius
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// float                          InRadius_69                    (Parm, ZeroConstructor, IsPlainOldData)

void AudioShapeCylinderComponent::SetRadius(float InRadius_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioShapes.AudioShapeCylinderComponent.SetRadius"));

	AudioShapeCylinderComponent_SetRadius_Params params;
	params.InRadius_69 = InRadius_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AudioShapes.AudioShapeCylinderComponent.SetHalfHeight
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// float                          InHalfHeight_69                (Parm, ZeroConstructor, IsPlainOldData)

void AudioShapeCylinderComponent::SetHalfHeight(float InHalfHeight_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioShapes.AudioShapeCylinderComponent.SetHalfHeight"));

	AudioShapeCylinderComponent_SetHalfHeight_Params params;
	params.InHalfHeight_69 = InHalfHeight_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AudioShapes.AudioShapeLineComponent.SetStartPoint
// (Final, Native, Public, HasOutParms, HasDefaults, BlueprintCallable)
// Parameters:
// struct FVector                 InStartPoint_69                (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)

void AudioShapeLineComponent::SetStartPoint(const struct FVector& InStartPoint_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioShapes.AudioShapeLineComponent.SetStartPoint"));

	AudioShapeLineComponent_SetStartPoint_Params params;
	params.InStartPoint_69 = InStartPoint_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AudioShapes.AudioShapeLineComponent.SetEndPoint
// (Final, Native, Public, HasOutParms, HasDefaults, BlueprintCallable)
// Parameters:
// struct FVector                 InEndPoint_69                  (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)

void AudioShapeLineComponent::SetEndPoint(const struct FVector& InEndPoint_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioShapes.AudioShapeLineComponent.SetEndPoint"));

	AudioShapeLineComponent_SetEndPoint_Params params;
	params.InEndPoint_69 = InEndPoint_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AudioShapes.AudioShapeLineListComponent.UpdatePoint
// (Final, Native, Public, HasOutParms, HasDefaults, BlueprintCallable)
// Parameters:
// int                            InIndex_69                     (Parm, ZeroConstructor, IsPlainOldData)
// struct FVector                 InPoint_69                     (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool AudioShapeLineListComponent::UpdatePoint(int InIndex_69, const struct FVector& InPoint_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioShapes.AudioShapeLineListComponent.UpdatePoint"));

	AudioShapeLineListComponent_UpdatePoint_Params params;
	params.InIndex_69 = InIndex_69;
	params.InPoint_69 = InPoint_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AudioShapes.AudioShapeLineListComponent.RemovePoint
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// int                            InIndex_69                     (Parm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool AudioShapeLineListComponent::RemovePoint(int InIndex_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioShapes.AudioShapeLineListComponent.RemovePoint"));

	AudioShapeLineListComponent_RemovePoint_Params params;
	params.InIndex_69 = InIndex_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AudioShapes.AudioShapeLineListComponent.GetPoints
// (Final, Native, Public, HasOutParms, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// TArray<struct FVector>         OutPoints_69                   (Parm, OutParm, ZeroConstructor)

void AudioShapeLineListComponent::GetPoints(TArray<struct FVector>* OutPoints_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioShapes.AudioShapeLineListComponent.GetPoints"));

	AudioShapeLineListComponent_GetPoints_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (OutPoints_69 != nullptr)
		*OutPoints_69 = params.OutPoints_69;
}


// Function AudioShapes.AudioShapeLineListComponent.AddPoint
// (Final, Native, Public, HasOutParms, HasDefaults, BlueprintCallable)
// Parameters:
// struct FVector                 InPoint_69                     (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
// int                            ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int AudioShapeLineListComponent::AddPoint(const struct FVector& InPoint_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioShapes.AudioShapeLineListComponent.AddPoint"));

	AudioShapeLineListComponent_AddPoint_Params params;
	params.InPoint_69 = InPoint_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AudioShapes.AudioShapeSphereComponent.SetRadius
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// float                          InRadius_69                    (Parm, ZeroConstructor, IsPlainOldData)

void AudioShapeSphereComponent::SetRadius(float InRadius_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioShapes.AudioShapeSphereComponent.SetRadius"));

	AudioShapeSphereComponent_SetRadius_Params params;
	params.InRadius_69 = InRadius_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Classes
//---------------------------------------------------------------------------

// Class DiscoveryBrowserUI.FortActivityBrowserTabButton
// 0x0000 (0x1410 - 0x1410)
class FortActivityBrowserTabButton : public FortTabButton
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class DiscoveryBrowserUI.FortActivityBrowserTabButton"));
		
		return ptr;
	}


	void OnFavoriteChanged(bool bIsFavorite_69);
};


// Class DiscoveryBrowserUI.FortActivityBrowserView
// 0x0090 (0x0488 - 0x03F8)
class FortActivityBrowserView : public FortActivityView
{
public:
	unsigned char                                      UnknownData00[0x8];                                       // 0x03F8(0x0008) MISSED OFFSET
	bool                                               bShowCustomMatchmakingModalButton_69;                     // 0x0400(0x0001) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	bool                                               bShowSpectateMatchModalButton_69;                         // 0x0401(0x0001) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	bool                                               bShowMobileGameDetailsButton_69;                          // 0x0402(0x0001) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	bool                                               bShowMobileAcceptButton_69;                               // 0x0403(0x0001) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	bool                                               bShowBackToTopButton_69;                                  // 0x0404(0x0001) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData01[0x3];                                       // 0x0405(0x0003) MISSED OFFSET
	struct FName                                       DiscoverySurfaceName_69;                                  // 0x0408(0x0008) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData02[0x7C];                                      // 0x040C(0x007C) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class DiscoveryBrowserUI.FortActivityBrowserView"));
		
		return ptr;
	}


	void OnSurfaceDataDirty();
	EFortInvalidActivityReason GetInvalidActivityReason();
};


// Class DiscoveryBrowserUI.FortActivityPlayerBrowserView
// 0x0128 (0x05B0 - 0x0488)
class FortActivityPlayerBrowserView : public FortActivityBrowserView
{
public:
	unsigned char                                      UnknownData00[0x8];                                       // 0x0488(0x0008) MISSED OFFSET
	class FortGameActivityProvider*                    ActivityProvider_69;                                      // 0x0490(0x0008) (ZeroConstructor)
	struct FName                                       TabNameID_69;                                             // 0x0498(0x0008) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData01[0x4];                                       // 0x049C(0x0004) MISSED OFFSET
	struct FFortTabButtonLabelInfo                     TabButtonLabelInfo_69;                                    // 0x04A0(0x00E0) (Edit, DisableEditOnInstance)
	EFortCreativeDiscoveryPlayHistoryType              PlayHistoryProviderType_69;                               // 0x0580(0x0001) (Edit, ZeroConstructor, DisableEditOnTemplate, IsPlainOldData)
	unsigned char                                      UnknownData02[0x7];                                       // 0x0581(0x0007) MISSED OFFSET
	class FortActivityTileView*                        TileView_PlayerActivities_69;                             // 0x0588(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)
	unsigned char                                      UnknownData03[0x20];                                      // 0x0590(0x0020) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class DiscoveryBrowserUI.FortActivityPlayerBrowserView"));
		
		return ptr;
	}


	void PlayViewIntro();
	void OnPlayViewIntro();
	void BP_OnTileViewUpdated();
};


// Class DiscoveryBrowserUI.FortActivityCategoryPageView
// 0x0010 (0x05C0 - 0x05B0)
class FortActivityCategoryPageView : public FortActivityPlayerBrowserView
{
public:
	class CommonRichTextBlock*                         Text_CategoryTitle_69;                                    // 0x05B0(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	unsigned char                                      UnknownData00[0x8];                                       // 0x05B8(0x0008) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class DiscoveryBrowserUI.FortActivityCategoryPageView"));
		
		return ptr;
	}

};


// Class DiscoveryBrowserUI.FortActivityCreatorPageView
// 0x0060 (0x0620 - 0x05C0)
class FortActivityCreatorPageView : public FortActivityCategoryPageView
{
public:
	unsigned char                                      UnknownData00[0x8];                                       // 0x05C0(0x0008) MISSED OFFSET
	class CommonButtonBase*                            Button_MobileClose_69;                                    // 0x05C8(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	class CommonButtonBase*                            Button_MobileAccept_69;                                   // 0x05D0(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	class CommonButtonBase*                            Button_Back_69;                                           // 0x05D8(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	class CommonButtonBase*                            Button_JoinAsSpectator_69;                                // 0x05E0(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)
	class CommonButtonBase*                            Button_MobileShowGameDetails_69;                          // 0x05E8(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	unsigned char                                      UnknownData01[0x30];                                      // 0x05F0(0x0030) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class DiscoveryBrowserUI.FortActivityCreatorPageView"));
		
		return ptr;
	}


	void OnPlayerQueueTypeChanged(EPlayerQueueType PlayerQueueType_69);
	void OnCreatorActivitiesQueryFinished();
};


// Class DiscoveryBrowserUI.FortActivityListItemWrapper
// 0x0010 (0x0038 - 0x0028)
class FortActivityListItemWrapper : public Object_32759
{
public:
	unsigned char                                      UnknownData00[0x10];                                      // 0x0028(0x0010) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class DiscoveryBrowserUI.FortActivityListItemWrapper"));
		
		return ptr;
	}

};


// Class DiscoveryBrowserUI.FortActivityBrowser
// 0x0290 (0x0638 - 0x03A8)
class FortActivityBrowser : public CommonActivatableWidget
{
public:
	unsigned char                                      UnknownData00[0x8];                                       // 0x03A8(0x0008) MISSED OFFSET
	class CommonActivatableWidgetSwitcher_32759*       Switcher_MainContent_69;                                  // 0x03B0(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)
	class CommonActivatableWidgetSwitcher_32759*       Switcher_TabActivityBrowserViews_69;                      // 0x03B8(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)
	class FortActivityCategoryPageView*                View_CategoryPage_69;                                     // 0x03C0(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	class CommonButtonBase*                            Button_Back_69;                                           // 0x03C8(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	class CommonButtonBase*                            Button_ShowCustomMatchmakingModal_69;                     // 0x03D0(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	class CommonButtonBase*                            Button_BackToTop_69;                                      // 0x03D8(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)
	class CommonButtonBase*                            Button_MobileShowGameDetails_69;                          // 0x03E0(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	class CommonButtonBase*                            Button_MobileAccept_69;                                   // 0x03E8(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	class CommonButtonBase*                            Button_MobileClose_69;                                    // 0x03F0(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	class CommonButtonBase*                            Button_JoinAsSpectator_69;                                // 0x03F8(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)
	class CommonButtonBase*                            Button_ShowSpectateMatchModal_69;                         // 0x0400(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	class FortTabListWidgetBase*                       TabList_BrowserTabs_69;                                   // 0x0408(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)
	struct FPrimaryContentSetup                        PrimaryContentSetup_69;                                   // 0x0410(0x0003) (Edit, DisableEditOnInstance)
	unsigned char                                      UnknownData01[0x5];                                       // 0x0413(0x0005) MISSED OFFSET
	class FortTabButton*                               TabButtonClass_69;                                        // 0x0418(0x0008) (Edit, ZeroConstructor, DisableEditOnInstance)
	class FortActivityDetailsModal*                    ActivityDetailsModalClass_69;                             // 0x0420(0x0008) (Edit, ZeroConstructor, DisableEditOnInstance)
	class FortActivityModeSetSelectionModal*           ActivityModeSetSelectionModalClass_69;                    // 0x0428(0x0008) (Edit, ZeroConstructor, DisableEditOnInstance)
	class CommonActivatableWidget*                     ActivityModeSetFirstTimeNotificationModalClass_69;        // 0x0430(0x0008) (Edit, ZeroConstructor, DisableEditOnInstance)
	class FortActivityCreatorPageView*                 CreatorPageViewClass_69;                                  // 0x0438(0x0008) (Edit, ZeroConstructor, DisableEditOnInstance)
	unsigned char                                      UnknownData02[0x28];                                      // 0x0440(0x0028) UNKNOWN PROPERTY: SoftClassProperty DiscoveryBrowserUI.FortActivityBrowser.SoftCustomMatchmakingModalClass_69
	unsigned char                                      UnknownData03[0x28];                                      // 0x0468(0x0028) UNKNOWN PROPERTY: SoftClassProperty DiscoveryBrowserUI.FortActivityBrowser.SoftSpectateMatchModalClass_69
	class FortCampaignPurchaseScreen*                  CampaignPurchaseScreenClass_69;                           // 0x0490(0x0008) (Edit, ZeroConstructor, DisableEditOnInstance)
	TMap<struct FName, class FortActivityBrowserColorSchemeAsset*> ColorSchemes_69;                                          // 0x0498(0x0050) (Edit, DisableEditOnInstance)
	class FortCreativeDiscoverySurfaceManager*         Manager_69;                                               // 0x04E8(0x0008) (ZeroConstructor, Transient)
	TArray<struct FCachedSurfaceData>                  CachedSurfacesData_69;                                    // 0x04F0(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData04[0x100];                                     // 0x0500(0x0100) MISSED OFFSET
	class FortGameActivityProvider*                    CachedWinterfestActivityProvider_69;                      // 0x0600(0x0008) (ZeroConstructor, Transient)
	unsigned char                                      UnknownData05[0x10];                                      // 0x0608(0x0010) MISSED OFFSET
	class FortActivityBrowserColorSchemeAsset*         CurrentColorScheme_69;                                    // 0x0618(0x0008) (ZeroConstructor, Transient)
	unsigned char                                      UnknownData06[0x8];                                       // 0x0620(0x0008) MISSED OFFSET
	class FortActivityCreatorPageView*                 CachedCreatorPageView_69;                                 // 0x0628(0x0008) (ExportObject, ZeroConstructor, Transient, InstancedReference)
	unsigned char                                      UnknownData07[0x8];                                       // 0x0630(0x0008) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class DiscoveryBrowserUI.FortActivityBrowser"));
		
		return ptr;
	}


	void OnUpdateCategoryPage(bool bShowCategoryPage_69);
	void OnSwapColorScheme(bool bInIsUsingAlternateColorScheme_69);
	void OnPlayerQueueTypeChanged(EPlayerQueueType PlayerQueueType_69);
	void OnEnableColorScheme(bool bIsColorSchemeActive_69);
	void OnActivitySelected();
	void HandleTabChanged(const struct FName& TabId_69);
};


// Class DiscoveryBrowserUI.FortActivityBrowserColorSchemeAsset
// 0x0050 (0x0080 - 0x0030)
class FortActivityBrowserColorSchemeAsset : public DataAsset
{
public:
	TMap<class MaterialParameterCollection*, struct FColorSchemeParamaterValues> MaterialCollectionOverrides_69;                           // 0x0030(0x0050) (Edit, BlueprintVisible, BlueprintReadOnly)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class DiscoveryBrowserUI.FortActivityBrowserColorSchemeAsset"));
		
		return ptr;
	}

};


// Class DiscoveryBrowserUI.FortActivityBrowserListView
// 0x0200 (0x0460 - 0x0260)
class FortActivityBrowserListView : public ListViewBase
{
public:
	unsigned char                                      UnknownData00[0xD8];                                      // 0x0260(0x00D8) MISSED OFFSET
	float                                              DirectionalNavigationTimeThreshold_69;                    // 0x0338(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bLockPositionForController_69;                            // 0x033C(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x3];                                       // 0x033D(0x0003) MISSED OFFSET
	int                                                LockedPositionAt_69;                                      // 0x0340(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData02[0x4];                                       // 0x0344(0x0004) MISSED OFFSET
	class FortActivityBrowserRow*                      PromotedActivityClass_69;                                 // 0x0348(0x0008) (Edit, ZeroConstructor)
	TMap<struct FName, class FortActivityBrowserRow*>  RowTypes_69;                                              // 0x0350(0x0050) (Edit)
	unsigned char                                      UnknownData03[0xC0];                                      // 0x03A0(0x00C0) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class DiscoveryBrowserUI.FortActivityBrowserListView"));
		
		return ptr;
	}

};


// Class DiscoveryBrowserUI.FortActivityBrowserRow
// 0x00A0 (0x0330 - 0x0290)
class FortActivityBrowserRow : public CommonUserWidget
{
public:
	unsigned char                                      UnknownData00[0x98];                                      // 0x0290(0x0098) MISSED OFFSET
	class CommonTextBlock*                             Text_CategoryName_69;                                     // 0x0328(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class DiscoveryBrowserUI.FortActivityBrowserRow"));
		
		return ptr;
	}


	void OnRowPeekStateChanged(bool bIsInPeekState_69);
	void OnRowMoveUp(bool bMovingOffscreen_69);
	void OnRowMoveDown(bool bMovingOffscreen_69);
	void OnRowIsSelectedChanged(bool bIsSelected_69);
	void OnRowIsActiveChanged(bool bIsActive_69);
	void OnCategoryItemChanged(bool bPlayAnimation_69);
	bool GetIsSelected();
	bool GetIsInPeekState();
	bool GetIsActive();
};


// Class DiscoveryBrowserUI.FortActivityBrowserRowHero
// 0x0078 (0x03A8 - 0x0330)
class FortActivityBrowserRowHero : public FortActivityBrowserRow
{
public:
	class FortActivityListView*                        ListView_Activities_69;                                   // 0x0330(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0338(0x0003) MISSED OFFSET
	bool                                               bPlayDetailsAnimationOnScreenOpen_69;                     // 0x033B(0x0001) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	float                                              DetailsDisplayUpdateDelay_69;                             // 0x033C(0x0004) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	class FortActivityDetailsDisplay*                  DetailsDisplay_SelectedActivity_69;                       // 0x0340(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)
	class FortActivityVideoCycle*                      ActivityVideoCycleWidget_69;                              // 0x0348(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	unsigned char                                      UnknownData01[0x20];                                      // 0x0350(0x0020) MISSED OFFSET
	class WidgetAnimation*                             BoundKeyArtOutroAnimation_69;                             // 0x0370(0x0008) (ZeroConstructor, Transient)
	unsigned char                                      UnknownData02[0x2];                                       // 0x0378(0x0002) MISSED OFFSET
	bool                                               bShouldAutoCycle_69;                                      // 0x037A(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData03[0x2D];                                      // 0x037B(0x002D) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class DiscoveryBrowserUI.FortActivityBrowserRowHero"));
		
		return ptr;
	}


	void OnVideoStarted();
	void OnVideoEndReached();
	void OnUpdateDetailsDisplay();
	void OnRowHeroFocusChanged(bool bHasFocus_69);
	void OnQueryStatusChanged(bool bIsActive_69);
	void OnQueryActivitiesFinished();
	void OnPreviewImageChanged(bool bIsLoading_69, class Texture* Texture_69);
	void OnPlayKeyArtOutro();
	void OnPlayKeyArtIntro();
	void OnActivityUpdated();
	bool IsShowingSeasonalContent();
	bool IsInOutroState();
	bool IsImageLoading();
	void HandleActivityVideoCycleStarted();
	void HandleActivityVideoCycleEndReached();
	class WidgetAnimation* GetKeyArtOutroAnimation();
	class Texture* GetCurrentTexture();
	void CycleNextActivity();
	void CheckUpdateDetailsDelay();
};


// Class DiscoveryBrowserUI.FortActivityBrowserRowList
// 0x0020 (0x0350 - 0x0330)
class FortActivityBrowserRowList : public FortActivityBrowserRow
{
public:
	class FortActivityListView*                        ListView_Activities_69;                                   // 0x0330(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)
	class CommonButtonBase*                            Button_PageLeft_69;                                       // 0x0338(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)
	class CommonButtonBase*                            Button_PageRight_69;                                      // 0x0340(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)
	unsigned char                                      UnknownData00[0x8];                                       // 0x0348(0x0008) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class DiscoveryBrowserUI.FortActivityBrowserRowList"));
		
		return ptr;
	}


	void OnQueryStatusChanged(bool bIsActive_69);
};


// Class DiscoveryBrowserUI.FortActivityBrowserRowPromoted
// 0x0008 (0x0338 - 0x0330)
class FortActivityBrowserRowPromoted : public FortActivityBrowserRow
{
public:
	class CommonTextBlock*                             Text_ActivityName_69;                                     // 0x0330(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class DiscoveryBrowserUI.FortActivityBrowserRowPromoted"));
		
		return ptr;
	}


	void OnPreviewImageChanged(bool bIsLoading_69, class Texture* Texture_69);
};


// Class DiscoveryBrowserUI.FortActivityBrowserRowView
// 0x0198 (0x0620 - 0x0488)
class FortActivityBrowserRowView : public FortActivityBrowserView
{
public:
	unsigned char                                      UnknownData00[0x8];                                       // 0x0488(0x0008) MISSED OFFSET
	float                                              MouseWheelScrollTimeThreshold_69;                         // 0x0490(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x4];                                       // 0x0494(0x0004) MISSED OFFSET
	class FortActivityBrowserListView*                 BrowserList_Activities_69;                                // 0x0498(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)
	unsigned char                                      UnknownData02[0x60];                                      // 0x04A0(0x0060) MISSED OFFSET
	struct FName                                       TabNameID_69;                                             // 0x0500(0x0008) (Edit, ZeroConstructor, DisableEditOnTemplate, IsPlainOldData)
	unsigned char                                      UnknownData03[0xC];                                       // 0x0504(0x000C) MISSED OFFSET
	struct FFortTabButtonLabelInfo                     TabButtonLabelInfo_69;                                    // 0x0510(0x00E0) (Edit, DisableEditOnTemplate)
	class FortSwipePanel*                              SwipePanel_Navigation_69;                                 // 0x05F0(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)
	unsigned char                                      UnknownData04[0x28];                                      // 0x05F8(0x0028) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class DiscoveryBrowserUI.FortActivityBrowserRowView"));
		
		return ptr;
	}


	void OnRowChanged(int NewCategoryIndex_69);
	void OnQueryActivitiesFinished();
	void OnActivityUpdated();
};


// Class DiscoveryBrowserUI.FortActivityBrowserTileBase
// 0x0060 (0x1440 - 0x13E0)
class FortActivityBrowserTileBase : public CommonButtonBase
{
public:
	unsigned char                                      UnknownData00[0x60];                                      // 0x13E0(0x0060) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class DiscoveryBrowserUI.FortActivityBrowserTileBase"));
		
		return ptr;
	}

};


// Class DiscoveryBrowserUI.FortActivityBrowserTile
// 0x0040 (0x1480 - 0x1440)
class FortActivityBrowserTile : public FortActivityBrowserTileBase
{
public:
	class FortActivityTileDetailsDisplay*              Display_TileDetails_69;                                   // 0x1440(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)
	unsigned char                                      UnknownData00[0x38];                                      // 0x1448(0x0038) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class DiscoveryBrowserUI.FortActivityBrowserTile"));
		
		return ptr;
	}


	void HandleActivitySelected();
};


// Class DiscoveryBrowserUI.FortActivityTileViewTileBase
// 0x0090 (0x1470 - 0x13E0)
class FortActivityTileViewTileBase : public CommonButtonBase
{
public:
	unsigned char                                      UnknownData00[0x90];                                      // 0x13E0(0x0090) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class DiscoveryBrowserUI.FortActivityTileViewTileBase"));
		
		return ptr;
	}

};


// Class DiscoveryBrowserUI.FortActivityCategoryTile
// 0x0010 (0x1480 - 0x1470)
class FortActivityCategoryTile : public FortActivityTileViewTileBase
{
public:
	class CommonTextBlock*                             Text_CategoryTitle_69;                                    // 0x1470(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	unsigned char                                      UnknownData00[0x8];                                       // 0x1478(0x0008) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class DiscoveryBrowserUI.FortActivityCategoryTile"));
		
		return ptr;
	}


	void OnTileActiveSet(bool bIsTileActive_69);
};


// Class DiscoveryBrowserUI.FortActivityCategoryTilePanel
// 0x0070 (0x0300 - 0x0290)
class FortActivityCategoryTilePanel : public CommonUserWidget
{
public:
	class FortActivityTileView*                        TileView_Categories_69;                                   // 0x0290(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)
	class CommonTextBlock*                             Text_Title_69;                                            // 0x0298(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)
	int                                                TileViewQueryThreshold_69;                                // 0x02A0(0x0004) (Edit, ZeroConstructor, DisableEditOnTemplate, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x02A4(0x0004) MISSED OFFSET
	class FortCreativeDiscoveryActivityProvider*       CachedActivityProvider_69;                                // 0x02A8(0x0008) (ZeroConstructor, Transient)
	unsigned char                                      UnknownData01[0x50];                                      // 0x02B0(0x0050) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class DiscoveryBrowserUI.FortActivityCategoryTilePanel"));
		
		return ptr;
	}

};


// Class DiscoveryBrowserUI.FortActivityCategoryView
// 0x0118 (0x05A0 - 0x0488)
class FortActivityCategoryView : public FortActivityBrowserView
{
public:
	unsigned char                                      UnknownData00[0x8];                                       // 0x0488(0x0008) MISSED OFFSET
	struct FName                                       TabNameID_69;                                             // 0x0490(0x0008) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData01[0xC];                                       // 0x0494(0x000C) MISSED OFFSET
	struct FFortTabButtonLabelInfo                     TabButtonLabelInfo_69;                                    // 0x04A0(0x00E0) (Edit, DisableEditOnInstance)
	class FortActivityCategoryTilePanel*               TilePanel_Featured_69;                                    // 0x0580(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)
	class FortActivityCategoryTilePanel*               TilePanel_All_69;                                         // 0x0588(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)
	class FortActivityCategoryTilePanel*               CurrentSelectedPanel_69;                                  // 0x0590(0x0008) (ExportObject, ZeroConstructor, Transient, InstancedReference)
	unsigned char                                      UnknownData02[0x8];                                       // 0x0598(0x0008) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class DiscoveryBrowserUI.FortActivityCategoryView"));
		
		return ptr;
	}


	void OnSurfaceDataReady();
	void OnCategoryTilePanelSelected(class FortActivityCategoryTilePanel* SelectedPanel_69);
	class FortActivityCategoryTilePanel* NavigateFromPanel(EUINavigation Direction_69, class FortActivityCategoryTilePanel* NavigatingPanel_69);
	class FortActivityCategoryTilePanel* GetTopMostVisiblePanel();
	class FortActivityCategoryTilePanel* GetCurrentSelectedPanel();
};


// Class DiscoveryBrowserUI.FortActivityCreateView
// 0x0118 (0x05A0 - 0x0488)
class FortActivityCreateView : public FortActivityBrowserView
{
public:
	unsigned char                                      UnknownData00[0x8];                                       // 0x0488(0x0008) MISSED OFFSET
	struct FName                                       TabNameID_69;                                             // 0x0490(0x0008) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData01[0xC];                                       // 0x0494(0x000C) MISSED OFFSET
	struct FFortTabButtonLabelInfo                     TabButtonLabelInfo_69;                                    // 0x04A0(0x00E0) (Edit, DisableEditOnInstance)
	class CommonButtonBase*                            Button_Create_69;                                         // 0x0580(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)
	unsigned char                                      UnknownData02[0x18];                                      // 0x0588(0x0018) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class DiscoveryBrowserUI.FortActivityCreateView"));
		
		return ptr;
	}


	void OnCreativeActivityUpdated();
	EFortInvalidActivityReason GetInvalidCreativeActivityReason();
};


// Class DiscoveryBrowserUI.FortActivityDiscoverView
// 0x00C0 (0x06E0 - 0x0620)
class FortActivityDiscoverView : public FortActivityBrowserRowView
{
public:
	TArray<ECommonPlatformType>                        PlatformMovieBlacklist_69;                                // 0x0620(0x0010) (ZeroConstructor, Config)
	TArray<struct FString>                             ActivityMovieBlacklist_69;                                // 0x0630(0x0010) (ZeroConstructor, Config)
	bool                                               bPlayDetailsAnimationOnScreenOpen_69;                     // 0x0640(0x0001) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0641(0x0003) MISSED OFFSET
	float                                              DetailsDisplayUpdateDelay_69;                             // 0x0644(0x0004) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	class FortActivatableMovieWidget*                  MovieWidgetClass_69;                                      // 0x0648(0x0008) (Edit, ZeroConstructor, DisableEditOnInstance)
	class FortActivityDetailsDisplay*                  DetailsDisplay_SelectedActivity_69;                       // 0x0650(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	class FortActivityDetailsDisplay*                  DetailsDisplay_PromotedActivity_69;                       // 0x0658(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)
	class PanelWidget*                                 Panel_VideoSlot_69;                                       // 0x0660(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	class PanelWidget*                                 Panel_PromotedVideoSlot_69;                               // 0x0668(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	class FortActivatableMovieWidget*                  ActivityMovieWidget_69;                                   // 0x0670(0x0008) (ExportObject, ZeroConstructor, Transient, InstancedReference)
	class FortActivatableMovieWidget*                  PromotedActivityMovieWidget_69;                           // 0x0678(0x0008) (ExportObject, ZeroConstructor, Transient, InstancedReference)
	unsigned char                                      UnknownData01[0x48];                                      // 0x0680(0x0048) MISSED OFFSET
	class WidgetAnimation*                             BoundKeyArtOutroAnimation_69;                             // 0x06C8(0x0008) (ZeroConstructor, Transient)
	unsigned char                                      UnknownData02[0x10];                                      // 0x06D0(0x0010) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class DiscoveryBrowserUI.FortActivityDiscoverView"));
		
		return ptr;
	}


	void OnUpdateDetailsDisplay();
	void OnPreviewImageChanged(bool bIsLoading_69, class Texture* Texture_69);
	void OnPlayKeyArtOutro();
	void OnPlayKeyArtIntro();
	void OnMoviePreEndEvent();
	void OnMoviePlayingChanged(bool bIsPlaying_69);
	bool IsShowingSeasonalContent();
	bool IsShowingPromotedContent();
	bool IsInOutroState();
	bool IsImageLoading();
	void HandleMovieWidgetMediaStarted();
	void HandleMovieWidgetMediaPreEndEvent();
	class FortActivatableMovieWidget* GetPromotedMovieWidget();
	class FortActivatableMovieWidget* GetMovieWidget();
	class WidgetAnimation* GetKeyArtOutroAnimation();
	class Texture* GetCurrentTexture();
	void CheckUpdateDetailsDelay();
};


// Class DiscoveryBrowserUI.FortActivityDiscoverViewV2
// 0x0030 (0x0650 - 0x0620)
class FortActivityDiscoverViewV2 : public FortActivityBrowserRowView
{
public:
	unsigned char                                      UnknownData00[0x30];                                      // 0x0620(0x0030) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class DiscoveryBrowserUI.FortActivityDiscoverViewV2"));
		
		return ptr;
	}


	bool IsShowingSeasonalContent();
	bool IsShowingPromotedContent();
};


// Class DiscoveryBrowserUI.FortActivityFavoriteBrowserView
// 0x0000 (0x05B0 - 0x05B0)
class FortActivityFavoriteBrowserView : public FortActivityPlayerBrowserView
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class DiscoveryBrowserUI.FortActivityFavoriteBrowserView"));
		
		return ptr;
	}

};


// Class DiscoveryBrowserUI.FortActivityListView
// 0x0178 (0x03D8 - 0x0260)
class FortActivityListView : public ListViewBase
{
public:
	unsigned char                                      UnknownData00[0xD8];                                      // 0x0260(0x00D8) MISSED OFFSET
	float                                              DirectionalNavigationTimeThreshold_69;                    // 0x0338(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<EOrientation>                          Orientation_69;                                           // 0x033C(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x3];                                       // 0x033D(0x0003) MISSED OFFSET
	float                                              EntrySpacing_69;                                          // 0x0340(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData02[0x4];                                       // 0x0344(0x0004) MISSED OFFSET
	TMap<EActivityBrowserTileStyle, class FortActivityBrowserTileBase*> TileTypes_69;                                             // 0x0348(0x0050) (Edit)
	unsigned char                                      UnknownData03[0x40];                                      // 0x0398(0x0040) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class DiscoveryBrowserUI.FortActivityListView"));
		
		return ptr;
	}


	int GetInViewCount();
};


// Class DiscoveryBrowserUI.FortActivityLobbyTile
// 0x0070 (0x14A0 - 0x1430)
class FortActivityLobbyTile : public CommonButtonLegacy
{
public:
	class CommonTextBlock*                             Text_ActivityName_69;                                     // 0x1430(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)
	class FortActivityBrowserTag*                      ActivityBrowserTag_EpicOriginal_69;                       // 0x1438(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)
	class FortActivityModeSetSelectionModal*           ActivityModeSetSelectionModalClass_69;                    // 0x1440(0x0008) (Edit, ZeroConstructor, DisableEditOnInstance)
	class FortGameActivityProvider*                    ActivityProvider_69;                                      // 0x1448(0x0008) (ZeroConstructor, Transient)
	TArray<class FortGameActivity*>                    CachedQueriedActivities_69;                               // 0x1450(0x0010) (ZeroConstructor, Transient)
	unsigned char                                      UnknownData00[0x40];                                      // 0x1460(0x0040) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class DiscoveryBrowserUI.FortActivityLobbyTile"));
		
		return ptr;
	}


	void TrySendFirstTimeNotification();
	void ShowModeSetSelectionModal();
	void OnShowChildActivityFirstTimeNotification();
	void OnShowChildActivityChangedNotification(const struct FText& DisplayName_69);
	void OnPreviewImageChanged(bool bIsLoading_69, class Texture* Texture_69);
	void OnHideChildActivityFirstTimeNotification();
	void OnDetailsUpdated();
	bool IsModeSetActivity();
	bool IsActivityEpicCreated();
	struct FText GetChildActivityDisplayName();
};


// Class DiscoveryBrowserUI.FortActivityModeSetSelectionModal
// 0x0070 (0x0418 - 0x03A8)
class FortActivityModeSetSelectionModal : public CommonActivatableWidget
{
public:
	class CommonTextBlock*                             Text_ActivityName_69;                                     // 0x03A8(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)
	unsigned char                                      UnknownData00[0x40];                                      // 0x03B0(0x0040) MISSED OFFSET
	class CommonButtonBase*                            Button_Back_69;                                           // 0x03F0(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	class CommonButtonBase*                            Button_BackBoard_69;                                      // 0x03F8(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	class FortActivityModeSetSelection*                List_SubModeList_69;                                      // 0x0400(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)
	class FortActivitySquadFillButton*                 Button_ActivitySquadFill_69;                              // 0x0408(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)
	class FortActivityPrivacyButton*                   Button_ActivityPrivacy_69;                                // 0x0410(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class DiscoveryBrowserUI.FortActivityModeSetSelectionModal"));
		
		return ptr;
	}


	void SaveSelectionAndClose();
	void OnSubModeSelectionChanged();
	void OnSubModeSelected();
	void OnPreviewImageChanged(bool bIsLoading_69, class Texture* Texture_69);
	void OnActivityChanged(class FortGameActivity* GameActivity_69, const struct FString& StartingSelectedMnemonic_69);
};


// Class DiscoveryBrowserUI.FortActivityPlayerBrowserTile
// 0x0050 (0x14C0 - 0x1470)
class FortActivityPlayerBrowserTile : public FortActivityTileViewTileBase
{
public:
	class FortActivityTileDetailsDisplay*              Display_TileDetails_69;                                   // 0x1470(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)
	class CommonTextBlock*                             Text_LastPlayedDate_69;                                   // 0x1478(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	unsigned char                                      UnknownData00[0x40];                                      // 0x1480(0x0040) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class DiscoveryBrowserUI.FortActivityPlayerBrowserTile"));
		
		return ptr;
	}


	void HandleActivitySelected();
};


// Class DiscoveryBrowserUI.FortActivityPlayerView
// 0x0138 (0x05C0 - 0x0488)
class FortActivityPlayerView : public FortActivityBrowserView
{
public:
	unsigned char                                      UnknownData00[0x8];                                       // 0x0488(0x0008) MISSED OFFSET
	struct FName                                       TabNameID_69;                                             // 0x0490(0x0008) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData01[0xC];                                       // 0x0494(0x000C) MISSED OFFSET
	struct FFortTabButtonLabelInfo                     TabButtonLabelInfo_69;                                    // 0x04A0(0x00E0) (Edit, DisableEditOnInstance)
	class CommonButtonBase*                            TabButtonClass_69;                                        // 0x0580(0x0008) (Edit, ZeroConstructor, DisableEditOnInstance)
	class FortTabListWidgetBase*                       TabList_PlayerViewTabs_69;                                // 0x0588(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	class CommonActivatableWidgetSwitcher_32759*       Switcher_PlayerBrowserViews_69;                           // 0x0590(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)
	class FortActivityPlayerBrowserView*               BrowserView_Favorites_69;                                 // 0x0598(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	class FortActivityPlayerBrowserView*               BrowserView_History_69;                                   // 0x05A0(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	unsigned char                                      UnknownData02[0x18];                                      // 0x05A8(0x0018) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class DiscoveryBrowserUI.FortActivityPlayerView"));
		
		return ptr;
	}

};


// Class DiscoveryBrowserUI.FortActivityPlayerViewTabButton
// 0x0000 (0x1410 - 0x1410)
class FortActivityPlayerViewTabButton : public FortTabButton
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class DiscoveryBrowserUI.FortActivityPlayerViewTabButton"));
		
		return ptr;
	}

};


// Class DiscoveryBrowserUI.FortActivitySearchView
// 0x0158 (0x05E0 - 0x0488)
class FortActivitySearchView : public FortActivityBrowserView
{
public:
	unsigned char                                      UnknownData00[0x8];                                       // 0x0488(0x0008) MISSED OFFSET
	struct FName                                       TabNameID_69;                                             // 0x0490(0x0008) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData01[0xC];                                       // 0x0494(0x000C) MISSED OFFSET
	struct FFortTabButtonLabelInfo                     TabButtonLabelInfo_69;                                    // 0x04A0(0x00E0) (Edit, DisableEditOnInstance)
	class EditableText*                                EditableText_IslandLink_69;                               // 0x0580(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	unsigned char                                      UnknownData02[0x58];                                      // 0x0588(0x0058) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class DiscoveryBrowserUI.FortActivitySearchView"));
		
		return ptr;
	}


	void OnActivityValidated(EFortActivityValidationResult ValidateResult_69);
	void OnActivityClear();
	void HandleTextCommitted(const struct FText& InText_69, TEnumAsByte<ETextCommit> CommitInfo_69);
	void HandleTextChanged(const struct FText& Text_69);
};


// Class DiscoveryBrowserUI.FortActivitySeasonalBrowserView
// 0x0000 (0x05B0 - 0x05B0)
class FortActivitySeasonalBrowserView : public FortActivityPlayerBrowserView
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class DiscoveryBrowserUI.FortActivitySeasonalBrowserView"));
		
		return ptr;
	}

};


// Class DiscoveryBrowserUI.FortActivityTileDetailsDisplay
// 0x0110 (0x14F0 - 0x13E0)
class FortActivityTileDetailsDisplay : public CommonButtonBase
{
public:
	unsigned char                                      UnknownData00[0x10];                                      // 0x13E0(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty DiscoveryBrowserUI.FortActivityTileDetailsDisplay.OnActivitySelectedDelegate_69
	unsigned char                                      UnknownData01[0x10];                                      // 0x13F0(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty DiscoveryBrowserUI.FortActivityTileDetailsDisplay.OnActivityUnSelectedDelegate_69
	bool                                               bShowDetailsButton_69;                                    // 0x1400(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnTemplate, IsPlainOldData)
	unsigned char                                      UnknownData02[0x7];                                       // 0x1401(0x0007) MISSED OFFSET
	class CommonTextBlock*                             Text_ActivityName_69;                                     // 0x1408(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)
	class CommonTextBlock*                             Text_PlayerCount_69;                                      // 0x1410(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)
	class CommonButtonBase*                            Button_Favorite_69;                                       // 0x1418(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)
	class CommonButtonBase*                            Button_Details_69;                                        // 0x1420(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)
	class FortActivityBrowserTag*                      ActivityBrowserTag_EpicOriginal_69;                       // 0x1428(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)
	class TextBlock*                                   Text_DebugId_69;                                          // 0x1430(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)
	TMap<uint32_t, ECreativeLinkPreviewSize>           MinColumnSizeToImageSize_69;                              // 0x1438(0x0050) (Config)
	unsigned char                                      UnknownData03[0x68];                                      // 0x1488(0x0068) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class DiscoveryBrowserUI.FortActivityTileDetailsDisplay"));
		
		return ptr;
	}


	void OnUpdateColumnSize(int NewColumnSize_69);
	void OnTileActiveSet(bool bIsTileActive_69);
	void OnSocialUsersPlayingChanged(int NumPlaying_69);
	void OnRequiresPurchaseChanged(bool bRequiresPurchase_69);
	void OnPreviewImageChanged(bool bIsLoading_69, class Texture* Texture_69);
	void OnPartySizeChanged(int PartySize_69);
	void OnLocalPlayerPromotedToLeader();
	void OnLocalPlayerDemoted();
	void OnIsFavoriteChanged(bool bIsFavorite_69);
	void OnDetailsUpdated();
	void OnActivityUnSelected__DelegateSignature();
	void OnActivitySelected__DelegateSignature();
	bool IsModeSetActivity();
	bool IsActivityFavorited();
	bool IsActivityEpicCreated();
	EFortInvalidActivityReason GetInvalidActivityReason();
	bool DoesActivityRequirePurchase();
};


// Class DiscoveryBrowserUI.FortActivityTileView
// 0x0000 (0x0BA0 - 0x0BA0)
class FortActivityTileView : public CommonTileView
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class DiscoveryBrowserUI.FortActivityTileView"));
		
		return ptr;
	}


	void SetListenForMouseWheelInput(bool bListenForInput_69);
};


// Class DiscoveryBrowserUI.ActivityLibraryComponent
// 0x0010 (0x00B0 - 0x00A0)
class ActivityLibraryComponent : public ActorComponent
{
public:
	unsigned char                                      UnknownData00[0x10];                                      // 0x00A0(0x0010) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class DiscoveryBrowserUI.ActivityLibraryComponent"));
		
		return ptr;
	}

};


// Class DiscoveryBrowserUI.FortActivityBrowserContext
// 0x0018 (0x0048 - 0x0030)
class FortActivityBrowserContext : public GameInstanceSubsystem
{
public:
	unsigned char                                      UnknownData00[0x18];                                      // 0x0030(0x0018) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class DiscoveryBrowserUI.FortActivityBrowserContext"));
		
		return ptr;
	}

};


// Class DiscoveryBrowserUI.OverrideMatchmakingUIComponent
// 0x0078 (0x0118 - 0x00A0)
class OverrideMatchmakingUIComponent : public ActorComponent
{
public:
	struct FMatchmakingUIOverride                      MatchmakingUIOverride_69;                                 // 0x00A0(0x0078) (Edit, DisableEditOnInstance)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class DiscoveryBrowserUI.OverrideMatchmakingUIComponent"));
		
		return ptr;
	}

};


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

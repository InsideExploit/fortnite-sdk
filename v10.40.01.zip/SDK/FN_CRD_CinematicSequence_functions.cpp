// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Functions
//---------------------------------------------------------------------------

// Function CRD_CinematicSequence.CinematicSequenceDeviceBase.Stop
// (Final, Native, Public, BlueprintCallable)

void CinematicSequenceDeviceBase::Stop()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CRD_CinematicSequence.CinematicSequenceDeviceBase.Stop"));

	CinematicSequenceDeviceBase_Stop_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CRD_CinematicSequence.CinematicSequenceDeviceBase.Play
// (Final, Native, Public, BlueprintCallable)

void CinematicSequenceDeviceBase::Play()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CRD_CinematicSequence.CinematicSequenceDeviceBase.Play"));

	CinematicSequenceDeviceBase_Play_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CRD_CinematicSequence.CinematicSequenceDeviceBase.Pause
// (Final, Native, Public, BlueprintCallable)

void CinematicSequenceDeviceBase::Pause()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CRD_CinematicSequence.CinematicSequenceDeviceBase.Pause"));

	CinematicSequenceDeviceBase_Pause_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CRD_CinematicSequence.CinematicSequenceDeviceBase.HandleSequencePlayerCreated
// (Native, Event, Protected, BlueprintEvent)
// Parameters:
// class LevelSequencePlayer*     Player_69                      (Parm, ZeroConstructor)

void CinematicSequenceDeviceBase::HandleSequencePlayerCreated(class LevelSequencePlayer* Player_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CRD_CinematicSequence.CinematicSequenceDeviceBase.HandleSequencePlayerCreated"));

	CinematicSequenceDeviceBase_HandleSequencePlayerCreated_Params params;
	params.Player_69 = Player_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CRD_CinematicSequence.CinematicSequenceDeviceBase.GetSequencePlayer
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// class MovieSceneSequencePlayer* ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

class MovieSceneSequencePlayer* CinematicSequenceDeviceBase::GetSequencePlayer()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CRD_CinematicSequence.CinematicSequenceDeviceBase.GetSequencePlayer"));

	CinematicSequenceDeviceBase_GetSequencePlayer_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

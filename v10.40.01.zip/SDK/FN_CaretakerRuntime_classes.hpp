#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Classes
//---------------------------------------------------------------------------

// Class CaretakerRuntime.FortAthenaCaretakerAIController
// 0x0008 (0x05B0 - 0x05A8)
class FortAthenaCaretakerAIController : public AthenaAIController
{
public:
	unsigned char                                      UnknownData00[0x8];                                       // 0x05A8(0x0008) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CaretakerRuntime.FortAthenaCaretakerAIController"));
		
		return ptr;
	}


	void OnMovementModeChanged(class Character* CharacterOwner_69, TEnumAsByte<EMovementMode> PreviousMovementMode_69, unsigned char PreviousCustomMode_69);
	void DebugUpdate(float UpdateInterval_69);
};


// Class CaretakerRuntime.FortBTTask_CaretakerMoveTo
// 0x0030 (0x00E0 - 0x00B0)
class FortBTTask_CaretakerMoveTo : public BTTask_MoveTo
{
public:
	struct FBlackboardKeySelector                      FocalPointWhileMoving_69;                                 // 0x00B0(0x0028) (Edit)
	TEnumAsByte<EPathObstacleAction>                   PathObstacleAction_69;                                    // 0x00D8(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x00D9(0x0003) MISSED OFFSET
	unsigned char                                      bEnableSlowdownAtGoal_69 : 1;                             // 0x00DC(0x0001) (Edit)
	unsigned char                                      bMoveDirectlyTowards_69 : 1;                              // 0x00DC(0x0001) (Edit)
	unsigned char                                      bStopAtGoal_69 : 1;                                       // 0x00DC(0x0001) (Edit)
	unsigned char                                      bFinishMoveOnOverlap_69 : 1;                              // 0x00DC(0x0001) (Edit, Config)
	unsigned char                                      UnknownData01[0x3];                                       // 0x00DD(0x0003) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CaretakerRuntime.FortBTTask_CaretakerMoveTo"));
		
		return ptr;
	}

};


// Class CaretakerRuntime.FortNavigationFilter_Caretaker
// 0x0018 (0x0060 - 0x0048)
class FortNavigationFilter_Caretaker : public NavigationQueryFilter
{
public:
	float                                              EndPointAcceptableRadius_69;                              // 0x0048(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x004C(0x0004) MISSED OFFSET
	class NavigationQueryFilter*                       EndPointFilterClass_69;                                   // 0x0050(0x0008) (Edit, BlueprintVisible, ZeroConstructor)
	unsigned char                                      bEndPointReachTestIncludesAgentRadius_69 : 1;             // 0x0058(0x0001) (Edit)
	unsigned char                                      bEndPointReachTestIncludesGoalRadius_69 : 1;              // 0x0058(0x0001) (Edit)
	unsigned char                                      UnknownData01[0x7];                                       // 0x0059(0x0007) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CaretakerRuntime.FortNavigationFilter_Caretaker"));
		
		return ptr;
	}

};


// Class CaretakerRuntime.FortAITask_CaretakerMove
// 0x0000 (0x0190 - 0x0190)
class FortAITask_CaretakerMove : public FortAbilityTask_MoveAI
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CaretakerRuntime.FortAITask_CaretakerMove"));
		
		return ptr;
	}

};


// Class CaretakerRuntime.FortAIAnimInstance_Caretaker
// 0x0050 (0x05D0 - 0x0580)
class FortAIAnimInstance_Caretaker : public FortAIAnimInstance
{
public:
	float                                              AimOffsetCurve_69;                                        // 0x0580(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, Transient, IsPlainOldData)
	bool                                               bFootPhase_StopLeftPlant_69;                              // 0x0584(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, Transient, IsPlainOldData)
	bool                                               bFootPhase_StopLeftPass_69;                               // 0x0585(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, Transient, IsPlainOldData)
	bool                                               bFootPhase_StopRightPlant_69;                             // 0x0586(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, Transient, IsPlainOldData)
	bool                                               bFootPhase_StopRightPass_69;                              // 0x0587(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, Transient, IsPlainOldData)
	float                                              BreathingCurve_69;                                        // 0x0588(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, Transient, IsPlainOldData)
	float                                              MovingTreshold_69;                                        // 0x058C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FName                                       CurveName_AimOffsetCurve_69;                              // 0x0590(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FName                                       CurveName_FootPhase_69;                                   // 0x0594(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FName                                       CurveName_BreathingCurve_69;                              // 0x0598(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FName                                       SocketName_FX_Chest_69;                                   // 0x059C(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FName                                       ParamName_ChestSocketLocation_69;                         // 0x05A0(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FName                                       ParamName_ChestSocketVector_69;                           // 0x05A4(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              FirstFootPhaseMin_69;                                     // 0x05A8(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              SecondFootPhaseMin_69;                                    // 0x05AC(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              ThirdFootPhaseMin_69;                                     // 0x05B0(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              FourthFootPhaseMin_69;                                    // 0x05B4(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              FootPhaseMax_69;                                          // 0x05B8(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x05BC(0x0004) MISSED OFFSET
	class FortAnimWorldStriderComponent*               WorldStriderComponent_69;                                 // 0x05C0(0x0008) (Edit, ExportObject, ZeroConstructor, DisableEditOnInstance, InstancedReference)
	unsigned char                                      UnknownData01[0x8];                                       // 0x05C8(0x0008) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CaretakerRuntime.FortAIAnimInstance_Caretaker"));
		
		return ptr;
	}


	void SetDelayedMaterialParameters();
	class FortAnimWorldStriderComponent* GetWorldStriderComponent();
	float GetWalkSpeedWarpingValue();
	float GetWalkPlayRateValue();
	float GetStartAnimPosition();
};


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

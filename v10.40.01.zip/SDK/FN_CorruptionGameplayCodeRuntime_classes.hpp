#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Classes
//---------------------------------------------------------------------------

// Class CorruptionGameplayCodeRuntime.WarEffortFundingLibrary
// 0x0000 (0x0028 - 0x0028)
class WarEffortFundingLibrary : public BlueprintFunctionLibrary
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CorruptionGameplayCodeRuntime.WarEffortFundingLibrary"));
		
		return ptr;
	}


	struct FString STATIC_WriteTextToBuffer(const struct FText& Text_69);
	bool STATIC_IsOption2ChoiceWinner(const struct FWarEffortFundingMetadata& MetaData_69, int ChoiceIndex_69);
	bool STATIC_IsOption1ChoiceWinner(const struct FWarEffortFundingMetadata& MetaData_69, int ChoiceIndex_69);
	bool STATIC_IsIndexFunded(const struct FWarEffortFundingMetadata& MetaData_69, int Index_69, TEnumAsByte<EWarEffortFundingStationType> StationType_69);
	float STATIC_GetIndexFundedPercent(const struct FWarEffortFundingMetadata& MetaData_69, int Index_69, TEnumAsByte<EWarEffortFundingStationType> StationType_69);
	bool STATIC_DoesChoiceHaveWinner(const struct FWarEffortFundingMetadata& MetaData_69, int ChoiceIndex_69);
	int STATIC_AdjustDonation(int DonationAmount_69, TEnumAsByte<EWarEffortFundingStationType> StationType_69);
};


// Class CorruptionGameplayCodeRuntime.CorruptionCoverageMap
// 0x0068 (0x0090 - 0x0028)
class CorruptionCoverageMap : public Object_32759
{
public:
	unsigned char                                      UnknownData00[0x68];                                      // 0x0028(0x0068) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CorruptionGameplayCodeRuntime.CorruptionCoverageMap"));
		
		return ptr;
	}


	bool UpdateCorruptionCoverageMap(class Object_32759* WorldContextObject_69, class TextureRenderTarget2D* CorruptionRenderTarget_69, const struct FVector& InTopLeftWorldCoordinate_69, const struct FVector& InBottomRightWorldCoordinate_69, float CoverageThreshold_69, float DebugDrawDuration_69);
	bool IsLocationCorrupted(const struct FVector& Location_69, float Padding_69);
};


// Class CorruptionGameplayCodeRuntime.FortCorruptionSequenceData
// 0x0020 (0x0050 - 0x0030)
class FortCorruptionSequenceData : public PrimaryDataAsset
{
public:
	TArray<struct FCorruptionCalendarEventData>        CorruptionStartEvents_69;                                 // 0x0030(0x0010) (Edit, ZeroConstructor, DisableEditOnInstance)
	TArray<struct FCorruptionPauseEvent>               CorruptionPauseEvents_69;                                 // 0x0040(0x0010) (Edit, ZeroConstructor, DisableEditOnInstance)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CorruptionGameplayCodeRuntime.FortCorruptionSequenceData"));
		
		return ptr;
	}

};


// Class CorruptionGameplayCodeRuntime.CubeMovementStaticPath
// 0x0030 (0x0510 - 0x04E0)
class CubeMovementStaticPath : public ScriptedObjectMovement_StaticPath
{
public:
	float                                              CubeAngleLimitDegrees_69;                                 // 0x04E0(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x04E4(0x0004) MISSED OFFSET
	class FortCorruptionSequenceData*                  CorruptionSequence_69;                                    // 0x04E8(0x0008) (Edit, ZeroConstructor)
	unsigned char                                      UnknownData01[0x8];                                       // 0x04F0(0x0008) MISSED OFFSET
	TArray<struct FTravelerStepCorruptionOverrideData> TravelerCorruptionStepPercentOverrides_69;                // 0x04F8(0x0010) (Edit, ZeroConstructor, DisableEditOnTemplate)
	unsigned char                                      UnknownData02[0x8];                                       // 0x0508(0x0008) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CorruptionGameplayCodeRuntime.CubeMovementStaticPath"));
		
		return ptr;
	}


	void EditorGetCorruptionGenerationData(struct FCubeMovement_CorruptionGenerationData* OutData_69);
	void ClearAllGeneratedSplinesAndLockedData();
};


// Class CorruptionGameplayCodeRuntime.FortAthenaMutator_WarEffort
// 0x0068 (0x04B8 - 0x0450)
class FortAthenaMutator_WarEffort : public FortAthenaMutator_GameModeBase
{
public:
	unsigned char                                      UnknownData00[0x8];                                       // 0x0450(0x0008) MISSED OFFSET
	struct FWarEffortMutatorMetadata                   MeshNetworkMetadata_69;                                   // 0x0458(0x0020) (BlueprintVisible)
	TArray<struct FWarEffortMutatorChoiceData>         WeaponChoices_69;                                         // 0x0478(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	TArray<struct FPrimaryAssetId>                     PreloadedItemList_69;                                     // 0x0488(0x0010) (Net, ZeroConstructor)
	bool                                               bCanPreloadItems_69;                                      // 0x0498(0x0001) (Net, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x1F];                                      // 0x0499(0x001F) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CorruptionGameplayCodeRuntime.FortAthenaMutator_WarEffort"));
		
		return ptr;
	}


	void SetTryBeforeYouBuyItemState(const struct FGameplayTag& ItemFundingTag_69, bool bIsActive_69);
	void SetItemFundedState(const struct FGameplayTag& ItemFundingTag_69, bool bIsActive_69);
	void SetItemFundedPercent(const struct FGameplayTag& ItemFundingTag_69, float FundingPercent_69);
	void SetItemFundedAmount(const struct FGameplayTag& ItemFundingTag_69, int64_t CurrentFundingAmount_69, int64_t TargetFundingAmount_69);
	void SetFundingManagerReady(bool bIsReady_69);
	void OnRep_PreloadedItemList();
};


// Class CorruptionGameplayCodeRuntime.WarEffortMeshActor
// 0x0088 (0x0310 - 0x0288)
class WarEffortMeshActor : public Info
{
public:
	class MeshNetworkComponent*                        MeshNetworkComponent_69;                                  // 0x0288(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	TArray<struct FGameplayTag>                        ActiveFundedItems_69;                                     // 0x0290(0x0010) (Net, ZeroConstructor)
	TArray<struct FGameplayTag>                        ActiveTryBeforeYouBuyItems_69;                            // 0x02A0(0x0010) (Net, ZeroConstructor)
	TArray<struct FWarEffortFundingData>               CurrentFundingData_69;                                    // 0x02B0(0x0010) (Net, ZeroConstructor)
	unsigned char                                      UnknownData00[0x50];                                      // 0x02C0(0x0050) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CorruptionGameplayCodeRuntime.WarEffortMeshActor"));
		
		return ptr;
	}


	void OnRep_CurrentFundingData();
	void OnRep_ActiveTryBeforeYouBuyItems();
	void OnRep_ActiveFundedItems();
};


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

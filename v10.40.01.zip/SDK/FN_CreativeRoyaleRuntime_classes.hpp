#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Classes
//---------------------------------------------------------------------------

// Class CreativeRoyaleRuntime.CreativeRoyalePlayspaceComponent_LoadingScreen
// 0x0088 (0x0128 - 0x00A0)
class CreativeRoyalePlayspaceComponent_LoadingScreen : public PlayspaceComponent_LoadingScreen
{
public:
	bool                                               bShouldDisplayLoadingScreenDuringPostGame_69;             // 0x00A0(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x00A1(0x0007) MISSED OFFSET
	struct FText                                       PlotNotFinishedLoadingContext_69;                         // 0x00A8(0x0018) (Edit, DisableEditOnInstance)
	struct FText                                       MinigameResetContext_69;                                  // 0x00C0(0x0018) (Edit, DisableEditOnInstance)
	unsigned char                                      UnknownData01[0x18];                                      // 0x00D8(0x0018) MISSED OFFSET
	struct FScalableFloat                              FailsafeTimeoutLength_69;                                 // 0x00F0(0x0028) (Edit, DisableEditOnInstance)
	unsigned char                                      UnknownData02[0x10];                                      // 0x0118(0x0010) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CreativeRoyaleRuntime.CreativeRoyalePlayspaceComponent_LoadingScreen"));
		
		return ptr;
	}


	void OnPlotLoadComplete();
	void OnPlayspaceUserAdded(struct FPlayspaceUser* AddedUser_69);
	void OnMinigameStateChanged(class FortMinigame* Minigame_69, EFortMinigameState MinigameState_69);
};


// Class CreativeRoyaleRuntime.AthenaAIServicePlayerBots_CreativeRoyale
// 0x0020 (0x0EA0 - 0x0E80)
class AthenaAIServicePlayerBots_CreativeRoyale : public AthenaAIServiceCreativePlayerBots
{
public:
	unsigned char                                      UnknownData00[0x20];                                      // 0x0E80(0x0020) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CreativeRoyaleRuntime.AthenaAIServicePlayerBots_CreativeRoyale"));
		
		return ptr;
	}


	void OnPlayerJoiningInProgress(class FortPlayerState* FortPlayerState_69);
};


// Class CreativeRoyaleRuntime.CreativeRoyalePlayspaceComponent_PlayerSpawning
// 0x0000 (0x00B0 - 0x00B0)
class CreativeRoyalePlayspaceComponent_PlayerSpawning : public FortPlayspaceComponent_PlayerSpawning
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CreativeRoyaleRuntime.CreativeRoyalePlayspaceComponent_PlayerSpawning"));
		
		return ptr;
	}

};


// Class CreativeRoyaleRuntime.CreativeRoyaleRootPlayspace
// 0x0038 (0x0658 - 0x0620)
class CreativeRoyaleRootPlayspace : public FortPlayspace
{
public:
	unsigned char                                      UnknownData00[0x18];                                      // 0x0620(0x0018) MISSED OFFSET
	class FortPlayerControllerAthena*                  EditorIslandOwnerPlayerController_69;                     // 0x0638(0x0008) (ZeroConstructor, Transient)
	unsigned char                                      UnknownData01[0x8];                                       // 0x0640(0x0008) MISSED OFFSET
	bool                                               bHasPlotLoaded_69;                                        // 0x0648(0x0001) (Net, ZeroConstructor, Transient, IsPlainOldData)
	unsigned char                                      UnknownData02[0xF];                                       // 0x0649(0x000F) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CreativeRoyaleRuntime.CreativeRoyaleRootPlayspace"));
		
		return ptr;
	}


	void TeleportPlayersToPlayerStarts();
	void OnRep_bHasPlotLoaded();
	void OnPlotLoadComplete();
	void Cheat_LoadEditorIsland();
	bool BuildDataRegistryResolverScope_Implementation(TArray<struct FName>* InOutResolverScopes_69, int* InOutPriority_69);
};


// Class CreativeRoyaleRuntime.FortAthenaMutator_CreativeRoyaleSafeZoneOverride
// 0x0000 (0x0330 - 0x0330)
class FortAthenaMutator_CreativeRoyaleSafeZoneOverride : public FortAthenaMutator
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CreativeRoyaleRuntime.FortAthenaMutator_CreativeRoyaleSafeZoneOverride"));
		
		return ptr;
	}

};


// Class CreativeRoyaleRuntime.FortCheatManager_CreativeRoyale
// 0x0010 (0x0048 - 0x0038)
class FortCheatManager_CreativeRoyale : public FortCheatManager_Coupled
{
public:
	class FortCreativeRealEstatePlotItemDefinition*    CreativeRoyaleEditPlotDefinition_69;                      // 0x0038(0x0008) (Edit, ZeroConstructor, DisableEditOnInstance)
	struct FGameplayTag                                CreativeRoyaleVolumeTag_69;                               // 0x0040(0x0004) (Edit, DisableEditOnInstance)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0044(0x0004) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CreativeRoyaleRuntime.FortCheatManager_CreativeRoyale"));
		
		return ptr;
	}


	void TeleportToPlotAferLoad();
	void CreativeRoyaleTeleportToEditZone();
	void CreativeRoyaleResetIslandFile();
	void CreativeRoyaleLoadEditPlot();
};


// Class CreativeRoyaleRuntime.FortProjectEditComponent_CreativeRoyale
// 0x0010 (0x0430 - 0x0420)
class FortProjectEditComponent_CreativeRoyale : public FortProjectEditComponent
{
public:
	unsigned char                                      UnknownData00[0x8];                                       // 0x0420(0x0008) MISSED OFFSET
	class FortCreativeRealEstatePlotItemDefinition*    CreativeRoyaleEditPlotDefinition_69;                      // 0x0428(0x0008) (Edit, ZeroConstructor, DisableEditOnInstance)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CreativeRoyaleRuntime.FortProjectEditComponent_CreativeRoyale"));
		
		return ptr;
	}


	void OnPlayerLoggedIn(class PlayerController* PlayerController_69);
	void LoadPlotFromProject();
};


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Functions
//---------------------------------------------------------------------------

// Function CRD_GameStreamRuntime.CreativeGameStreamDeviceComponent.RemoveFromEndGameQueue
// (Final, Native, Public, BlueprintCallable)

void CreativeGameStreamDeviceComponent::RemoveFromEndGameQueue()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CRD_GameStreamRuntime.CreativeGameStreamDeviceComponent.RemoveFromEndGameQueue"));

	CreativeGameStreamDeviceComponent_RemoveFromEndGameQueue_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CRD_GameStreamRuntime.CreativeGameStreamDeviceComponent.OnMinigameStateChanged
// (Final, Native, Private)
// Parameters:
// class FortMinigame*            Minigame_69                    (Parm, ZeroConstructor)
// EFortMinigameState             NewMinigameState_69            (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void CreativeGameStreamDeviceComponent::OnMinigameStateChanged(class FortMinigame* Minigame_69, EFortMinigameState NewMinigameState_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CRD_GameStreamRuntime.CreativeGameStreamDeviceComponent.OnMinigameStateChanged"));

	CreativeGameStreamDeviceComponent_OnMinigameStateChanged_Params params;
	params.Minigame_69 = Minigame_69;
	params.NewMinigameState_69 = NewMinigameState_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CRD_GameStreamRuntime.CreativeGameStreamDeviceComponent.IsWithinPublishedPlayspace
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool CreativeGameStreamDeviceComponent::IsWithinPublishedPlayspace()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CRD_GameStreamRuntime.CreativeGameStreamDeviceComponent.IsWithinPublishedPlayspace"));

	CreativeGameStreamDeviceComponent_IsWithinPublishedPlayspace_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CRD_GameStreamRuntime.CreativeGameStreamDeviceComponent.Init
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// class FortMinigameLogicComponent* InMinigameLogicComponent_69    (Parm, ZeroConstructor, InstancedReference)

void CreativeGameStreamDeviceComponent::Init(class FortMinigameLogicComponent* InMinigameLogicComponent_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CRD_GameStreamRuntime.CreativeGameStreamDeviceComponent.Init"));

	CreativeGameStreamDeviceComponent_Init_Params params;
	params.InMinigameLogicComponent_69 = InMinigameLogicComponent_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// SparseDelegateFunction CRD_GameStreamRuntime.CreativeGameStreamDeviceComponent.CreativeGameStreamDeviceComponentSignature__DelegateSignature
// (MulticastDelegate, Public, Delegate)
// Parameters:
// class CreativeGameStreamDeviceComponent* CreativeGameStreamDeviceComponent_69 (Parm, ZeroConstructor, InstancedReference)

void CreativeGameStreamDeviceComponent::CreativeGameStreamDeviceComponentSignature__DelegateSignature(class CreativeGameStreamDeviceComponent* CreativeGameStreamDeviceComponent_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("SparseDelegateFunction CRD_GameStreamRuntime.CreativeGameStreamDeviceComponent.CreativeGameStreamDeviceComponentSignature__DelegateSignature"));

	CreativeGameStreamDeviceComponent_CreativeGameStreamDeviceComponentSignature__DelegateSignature_Params params;
	params.CreativeGameStreamDeviceComponent_69 = CreativeGameStreamDeviceComponent_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CRD_GameStreamRuntime.CreativeGameStreamDeviceComponent.AddToEndGameQueue
// (Final, Native, Public, BlueprintCallable)

void CreativeGameStreamDeviceComponent::AddToEndGameQueue()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CRD_GameStreamRuntime.CreativeGameStreamDeviceComponent.AddToEndGameQueue"));

	CreativeGameStreamDeviceComponent_AddToEndGameQueue_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CRD_GameStreamRuntime.CreativeGameStreamDeviceCoordinatorComponent.OnMinigameStateChanged
// (Final, Native, Private)
// Parameters:
// class FortMinigame*            InMinigame_69                  (Parm, ZeroConstructor)
// EFortMinigameState             NewMinigameState_69            (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void CreativeGameStreamDeviceCoordinatorComponent::OnMinigameStateChanged(class FortMinigame* InMinigame_69, EFortMinigameState NewMinigameState_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CRD_GameStreamRuntime.CreativeGameStreamDeviceCoordinatorComponent.OnMinigameStateChanged"));

	CreativeGameStreamDeviceCoordinatorComponent_OnMinigameStateChanged_Params params;
	params.InMinigame_69 = InMinigame_69;
	params.NewMinigameState_69 = NewMinigameState_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

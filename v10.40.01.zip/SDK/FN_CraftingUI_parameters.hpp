#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function CraftingUI.AthenaCraftingQuickBarButton.OnIsCraftableItemChanged
struct AthenaCraftingQuickBarButton_OnIsCraftableItemChanged_Params
{
	bool                                               bIsCraftableItem_69;                                      // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function CraftingUI.AthenaCraftingQuickBarButton.OnCanCraftNowChanged
struct AthenaCraftingQuickBarButton_OnCanCraftNowChanged_Params
{
	bool                                               bCanCraftNow_69;                                          // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function CraftingUI.AthenaEquippedItemCraftingIndicator.OnIsCraftableItemChanged
struct AthenaEquippedItemCraftingIndicator_OnIsCraftableItemChanged_Params
{
	bool                                               bIsCraftableItem_69;                                      // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function CraftingUI.AthenaEquippedItemCraftingIndicator.OnCanCraftNowChanged
struct AthenaEquippedItemCraftingIndicator_OnCanCraftNowChanged_Params
{
	bool                                               bCanCraftNow_69;                                          // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function CraftingUI.AthenaEquippedItemCraftingIndicator.HandleWeaponEquipped
struct AthenaEquippedItemCraftingIndicator_HandleWeaponEquipped_Params
{
	class FortWeapon*                                  NewWeapon_69;                                             // (Parm, ZeroConstructor)
	class FortWeapon*                                  PrevWeapon_69;                                            // (Parm, ZeroConstructor)
};

// Function CraftingUI.AthenaInventoryItemInfoCraftingIndicator.OnIsCraftableItemChanged
struct AthenaInventoryItemInfoCraftingIndicator_OnIsCraftableItemChanged_Params
{
	bool                                               bIsCraftableItem_69;                                      // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function CraftingUI.AthenaInventoryItemInfoCraftingIndicator.OnCanCraftNowChanged
struct AthenaInventoryItemInfoCraftingIndicator_OnCanCraftNowChanged_Params
{
	bool                                               bCanCraftNow_69;                                          // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function CraftingUI.AthenaInventoryItemInfoCraftingIndicator.HandleInventoryItemSelected
struct AthenaInventoryItemInfoCraftingIndicator_HandleInventoryItemSelected_Params
{
	class FortItem*                                    SelectedItem_69;                                          // (Parm, ZeroConstructor)
};

// Function CraftingUI.AthenaQuickBarSlotCraftingIndicator.OnIsCraftableItemChanged
struct AthenaQuickBarSlotCraftingIndicator_OnIsCraftableItemChanged_Params
{
	bool                                               bIsCraftableItem_69;                                      // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function CraftingUI.AthenaQuickBarSlotCraftingIndicator.OnIngredientChanged
struct AthenaQuickBarSlotCraftingIndicator_OnIngredientChanged_Params
{
	bool                                               bCanCraftNow_69;                                          // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function CraftingUI.AthenaQuickBarSlotCraftingIndicator.OnCanCraftNowChanged
struct AthenaQuickBarSlotCraftingIndicator_OnCanCraftNowChanged_Params
{
	bool                                               bCanCraftNow_69;                                          // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function CraftingUI.AthenaQuickBarSlotCraftingIndicator.HandleWeaponEquipped
struct AthenaQuickBarSlotCraftingIndicator_HandleWeaponEquipped_Params
{
	class FortWeapon*                                  NewWeapon_69;                                             // (Parm, ZeroConstructor)
	class FortWeapon*                                  PrevWeapon_69;                                            // (Parm, ZeroConstructor)
};

// Function CraftingUI.FortCraftingIngredientWidget.OnIngredientWidgetUpdated
struct FortCraftingIngredientWidget_OnIngredientWidgetUpdated_Params
{
	int                                                NumAvailable_69;                                          // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	int                                                NumRequired_69;                                           // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bIsPrimaryIngredient_69;                                  // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bIsLastIngredient_69;                                     // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function CraftingUI.FortCraftingItemInfoWidget.OnItemRaritySet
struct FortCraftingItemInfoWidget_OnItemRaritySet_Params
{
	EFortRarity                                        Rarity_69;                                                // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	struct FFortRarityItemData                         RarityItemData_69;                                        // (ConstParm, Parm)
};

// Function CraftingUI.FortCraftingListEntry.OnCraftingListItemSet
struct FortCraftingListEntry_OnCraftingListItemSet_Params
{
};

// Function CraftingUI.FortCraftingTab.OnFormulaListUpdated
struct FortCraftingTab_OnFormulaListUpdated_Params
{
	int                                                NumFormulas_69;                                           // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function CraftingUI.FortCraftingTab.HandleInventoryItemSelected
struct FortCraftingTab_HandleInventoryItemSelected_Params
{
	class FortItem*                                    Item_69;                                                  // (Parm, ZeroConstructor)
};

// Function CraftingUI.FortPotContentsPopup.SetOwningCraftingObject
struct FortPotContentsPopup_SetOwningCraftingObject_Params
{
	class CraftingObjectBGA*                           InCraftingObject_69;                                      // (Parm, ZeroConstructor)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function CRD_CinematicSequence.CinematicSequenceDeviceBase.Stop
struct CinematicSequenceDeviceBase_Stop_Params
{
};

// Function CRD_CinematicSequence.CinematicSequenceDeviceBase.Play
struct CinematicSequenceDeviceBase_Play_Params
{
};

// Function CRD_CinematicSequence.CinematicSequenceDeviceBase.Pause
struct CinematicSequenceDeviceBase_Pause_Params
{
};

// Function CRD_CinematicSequence.CinematicSequenceDeviceBase.HandleSequencePlayerCreated
struct CinematicSequenceDeviceBase_HandleSequencePlayerCreated_Params
{
	class LevelSequencePlayer*                         Player_69;                                                // (Parm, ZeroConstructor)
};

// Function CRD_CinematicSequence.CinematicSequenceDeviceBase.GetSequencePlayer
struct CinematicSequenceDeviceBase_GetSequencePlayer_Params
{
	class MovieSceneSequencePlayer*                    ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

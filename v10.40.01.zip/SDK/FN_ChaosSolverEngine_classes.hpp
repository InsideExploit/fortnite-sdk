#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Classes
//---------------------------------------------------------------------------

// Class ChaosSolverEngine.ChaosDebugDrawComponent
// 0x0008 (0x00A8 - 0x00A0)
class ChaosDebugDrawComponent : public ActorComponent
{
public:
	unsigned char                                      UnknownData00[0x8];                                       // 0x00A0(0x0008) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class ChaosSolverEngine.ChaosDebugDrawComponent"));
		
		return ptr;
	}

};


// Class ChaosSolverEngine.ChaosEventListenerComponent
// 0x0008 (0x00A8 - 0x00A0)
class ChaosEventListenerComponent : public ActorComponent
{
public:
	unsigned char                                      UnknownData00[0x8];                                       // 0x00A0(0x0008) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class ChaosSolverEngine.ChaosEventListenerComponent"));
		
		return ptr;
	}

};


// Class ChaosSolverEngine.ChaosGameplayEventDispatcher
// 0x0260 (0x0308 - 0x00A8)
class ChaosGameplayEventDispatcher : public ChaosEventListenerComponent
{
public:
	unsigned char                                      UnknownData00[0x110];                                     // 0x00A8(0x0110) MISSED OFFSET
	TMap<class PrimitiveComponent*, struct FChaosHandlerSet> CollisionEventRegistrations_69;                           // 0x01B8(0x0050)
	TMap<class PrimitiveComponent*, struct FBreakEventCallbackWrapper> BreakEventRegistrations_69;                               // 0x0208(0x0050)
	TMap<class PrimitiveComponent*, struct FRemovalEventCallbackWrapper> RemovalEventRegistrations_69;                             // 0x0258(0x0050)
	TMap<class PrimitiveComponent*, struct FCrumblingEventCallbackWrapper> CrumblingEventRegistrations_69;                           // 0x02A8(0x0050)
	unsigned char                                      UnknownData01[0x10];                                      // 0x02F8(0x0010) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class ChaosSolverEngine.ChaosGameplayEventDispatcher"));
		
		return ptr;
	}

};


// Class ChaosSolverEngine.ChaosNotifyHandlerInterface
// 0x0000 (0x0028 - 0x0028)
class ChaosNotifyHandlerInterface : public Interface
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class ChaosSolverEngine.ChaosNotifyHandlerInterface"));
		
		return ptr;
	}

};


// Class ChaosSolverEngine.ChaosSolverEngineBlueprintLibrary
// 0x0000 (0x0028 - 0x0028)
class ChaosSolverEngineBlueprintLibrary : public BlueprintFunctionLibrary
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class ChaosSolverEngine.ChaosSolverEngineBlueprintLibrary"));
		
		return ptr;
	}


	struct FHitResult STATIC_ConvertPhysicsCollisionToHitResult(const struct FChaosPhysicsCollisionInfo& PhysicsCollision_69);
};


// Class ChaosSolverEngine.ChaosSolver
// 0x0000 (0x0028 - 0x0028)
class ChaosSolver : public Object_32759
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class ChaosSolverEngine.ChaosSolver"));
		
		return ptr;
	}

};


// Class ChaosSolverEngine.ChaosSolverActor
// 0x00F8 (0x0380 - 0x0288)
class ChaosSolverActor : public Actor_32759
{
public:
	struct FChaosSolverConfiguration                   Properties_69;                                            // 0x0288(0x0068) (Edit)
	float                                              TimeStepMultiplier_69;                                    // 0x02F0(0x0004) (ZeroConstructor, Deprecated, IsPlainOldData)
	int                                                CollisionIterations_69;                                   // 0x02F4(0x0004) (ZeroConstructor, Deprecated, IsPlainOldData)
	int                                                PushOutIterations_69;                                     // 0x02F8(0x0004) (ZeroConstructor, Deprecated, IsPlainOldData)
	int                                                PushOutPairIterations_69;                                 // 0x02FC(0x0004) (ZeroConstructor, Deprecated, IsPlainOldData)
	float                                              ClusterConnectionFactor_69;                               // 0x0300(0x0004) (ZeroConstructor, Deprecated, IsPlainOldData)
	EClusterConnectionTypeEnum                         ClusterUnionConnectionType_69;                            // 0x0304(0x0001) (ZeroConstructor, Deprecated, IsPlainOldData)
	bool                                               DoGenerateCollisionData_69;                               // 0x0305(0x0001) (ZeroConstructor, Deprecated, IsPlainOldData)
	unsigned char                                      UnknownData00[0x2];                                       // 0x0306(0x0002) MISSED OFFSET
	struct FSolverCollisionFilterSettings              CollisionFilterSettings_69;                               // 0x0308(0x0010) (Deprecated)
	bool                                               DoGenerateBreakingData_69;                                // 0x0318(0x0001) (ZeroConstructor, Deprecated, IsPlainOldData)
	unsigned char                                      UnknownData01[0x3];                                       // 0x0319(0x0003) MISSED OFFSET
	struct FSolverBreakingFilterSettings               BreakingFilterSettings_69;                                // 0x031C(0x0010) (Deprecated)
	bool                                               DoGenerateTrailingData_69;                                // 0x032C(0x0001) (ZeroConstructor, Deprecated, IsPlainOldData)
	unsigned char                                      UnknownData02[0x3];                                       // 0x032D(0x0003) MISSED OFFSET
	struct FSolverTrailingFilterSettings               TrailingFilterSettings_69;                                // 0x0330(0x0010) (Deprecated)
	float                                              MassScale_69;                                             // 0x0340(0x0004) (ZeroConstructor, Deprecated, IsPlainOldData)
	bool                                               bGenerateContactGraph_69;                                 // 0x0344(0x0001) (ZeroConstructor, Deprecated, IsPlainOldData)
	bool                                               bHasFloor_69;                                             // 0x0345(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData03[0x2];                                       // 0x0346(0x0002) MISSED OFFSET
	float                                              FloorHeight_69;                                           // 0x0348(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	struct FChaosDebugSubstepControl                   ChaosDebugSubstepControl_69;                              // 0x034C(0x0003) (Edit)
	unsigned char                                      UnknownData04[0x1];                                       // 0x034F(0x0001) MISSED OFFSET
	class BillboardComponent*                          SpriteComponent_69;                                       // 0x0350(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	unsigned char                                      UnknownData05[0x18];                                      // 0x0358(0x0018) MISSED OFFSET
	class ChaosGameplayEventDispatcher*                GameplayEventDispatcherComponent_69;                      // 0x0370(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	unsigned char                                      UnknownData06[0x8];                                       // 0x0378(0x0008) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class ChaosSolverEngine.ChaosSolverActor"));
		
		return ptr;
	}


	void SetSolverActive(bool bActive_69);
	void SetAsCurrentWorldSolver();
};


// Class ChaosSolverEngine.ChaosSolverSettings
// 0x0020 (0x0050 - 0x0030)
class ChaosSolverSettings : public DeveloperSettings
{
public:
	unsigned char                                      UnknownData00[0x8];                                       // 0x0030(0x0008) MISSED OFFSET
	struct FSoftClassPath                              DefaultChaosSolverActorClass_69;                          // 0x0038(0x0018) (Edit, ZeroConstructor, Config, NoClear)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class ChaosSolverEngine.ChaosSolverSettings"));
		
		return ptr;
	}

};


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

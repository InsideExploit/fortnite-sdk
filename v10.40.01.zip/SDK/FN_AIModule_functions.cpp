// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Functions
//---------------------------------------------------------------------------

// Function AIModule.AIController.UseBlackboard
// (Final, Native, Public, HasOutParms, BlueprintCallable)
// Parameters:
// class BlackboardData*          BlackboardAsset_69             (Parm, ZeroConstructor)
// class BlackboardComponent*     BlackboardComponent_69         (Parm, OutParm, ZeroConstructor, InstancedReference)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool AIController::UseBlackboard(class BlackboardData* BlackboardAsset_69, class BlackboardComponent** BlackboardComponent_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.AIController.UseBlackboard"));

	AIController_UseBlackboard_Params params;
	params.BlackboardAsset_69 = BlackboardAsset_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (BlackboardComponent_69 != nullptr)
		*BlackboardComponent_69 = params.BlackboardComponent_69;

	return params.ReturnValue_69;
}


// Function AIModule.AIController.UnclaimTaskResource
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// class GameplayTaskResource*    ResourceClass_69               (Parm, ZeroConstructor)

void AIController::UnclaimTaskResource(class GameplayTaskResource* ResourceClass_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.AIController.UnclaimTaskResource"));

	AIController_UnclaimTaskResource_Params params;
	params.ResourceClass_69 = ResourceClass_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AIModule.AIController.SetPathFollowingComponent
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// class PathFollowingComponent*  NewPFComponent_69              (Parm, ZeroConstructor, InstancedReference)

void AIController::SetPathFollowingComponent(class PathFollowingComponent* NewPFComponent_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.AIController.SetPathFollowingComponent"));

	AIController_SetPathFollowingComponent_Params params;
	params.NewPFComponent_69 = NewPFComponent_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AIModule.AIController.SetMoveBlockDetection
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// bool                           bEnable_69                     (Parm, ZeroConstructor, IsPlainOldData)

void AIController::SetMoveBlockDetection(bool bEnable_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.AIController.SetMoveBlockDetection"));

	AIController_SetMoveBlockDetection_Params params;
	params.bEnable_69 = bEnable_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AIModule.AIController.RunBehaviorTree
// (Native, Public, BlueprintCallable)
// Parameters:
// class BehaviorTree*            BTAsset_69                     (Parm, ZeroConstructor)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool AIController::RunBehaviorTree(class BehaviorTree* BTAsset_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.AIController.RunBehaviorTree"));

	AIController_RunBehaviorTree_Params params;
	params.BTAsset_69 = BTAsset_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AIModule.AIController.OnUsingBlackBoard
// (Event, Protected, BlueprintEvent)
// Parameters:
// class BlackboardComponent*     BlackboardComp_69              (Parm, ZeroConstructor, InstancedReference)
// class BlackboardData*          BlackboardAsset_69             (Parm, ZeroConstructor)

void AIController::OnUsingBlackBoard(class BlackboardComponent* BlackboardComp_69, class BlackboardData* BlackboardAsset_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.AIController.OnUsingBlackBoard"));

	AIController_OnUsingBlackBoard_Params params;
	params.BlackboardComp_69 = BlackboardComp_69;
	params.BlackboardAsset_69 = BlackboardAsset_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AIModule.AIController.OnGameplayTaskResourcesClaimed
// (Native, Public)
// Parameters:
// struct FGameplayResourceSet    NewlyClaimed_69                (Parm)
// struct FGameplayResourceSet    FreshlyReleased_69             (Parm)

void AIController::OnGameplayTaskResourcesClaimed(const struct FGameplayResourceSet& NewlyClaimed_69, const struct FGameplayResourceSet& FreshlyReleased_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.AIController.OnGameplayTaskResourcesClaimed"));

	AIController_OnGameplayTaskResourcesClaimed_Params params;
	params.NewlyClaimed_69 = NewlyClaimed_69;
	params.FreshlyReleased_69 = FreshlyReleased_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AIModule.AIController.MoveToLocation
// (Final, Native, Public, HasOutParms, HasDefaults, BlueprintCallable)
// Parameters:
// struct FVector                 Dest_69                        (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
// float                          AcceptanceRadius_69            (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bStopOnOverlap_69              (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bUsePathfinding_69             (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bProjectDestinationToNavigation_69 (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bCanStrafe_69                  (Parm, ZeroConstructor, IsPlainOldData)
// class NavigationQueryFilter*   FilterClass_69                 (Parm, ZeroConstructor)
// bool                           bAllowPartialPath_69           (Parm, ZeroConstructor, IsPlainOldData)
// TEnumAsByte<EPathFollowingRequestResult> ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

TEnumAsByte<EPathFollowingRequestResult> AIController::MoveToLocation(const struct FVector& Dest_69, float AcceptanceRadius_69, bool bStopOnOverlap_69, bool bUsePathfinding_69, bool bProjectDestinationToNavigation_69, bool bCanStrafe_69, class NavigationQueryFilter* FilterClass_69, bool bAllowPartialPath_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.AIController.MoveToLocation"));

	AIController_MoveToLocation_Params params;
	params.Dest_69 = Dest_69;
	params.AcceptanceRadius_69 = AcceptanceRadius_69;
	params.bStopOnOverlap_69 = bStopOnOverlap_69;
	params.bUsePathfinding_69 = bUsePathfinding_69;
	params.bProjectDestinationToNavigation_69 = bProjectDestinationToNavigation_69;
	params.bCanStrafe_69 = bCanStrafe_69;
	params.FilterClass_69 = FilterClass_69;
	params.bAllowPartialPath_69 = bAllowPartialPath_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AIModule.AIController.MoveToActor
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// class Actor_32759*             Goal_69                        (Parm, ZeroConstructor)
// float                          AcceptanceRadius_69            (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bStopOnOverlap_69              (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bUsePathfinding_69             (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bCanStrafe_69                  (Parm, ZeroConstructor, IsPlainOldData)
// class NavigationQueryFilter*   FilterClass_69                 (Parm, ZeroConstructor)
// bool                           bAllowPartialPath_69           (Parm, ZeroConstructor, IsPlainOldData)
// TEnumAsByte<EPathFollowingRequestResult> ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

TEnumAsByte<EPathFollowingRequestResult> AIController::MoveToActor(class Actor_32759* Goal_69, float AcceptanceRadius_69, bool bStopOnOverlap_69, bool bUsePathfinding_69, bool bCanStrafe_69, class NavigationQueryFilter* FilterClass_69, bool bAllowPartialPath_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.AIController.MoveToActor"));

	AIController_MoveToActor_Params params;
	params.Goal_69 = Goal_69;
	params.AcceptanceRadius_69 = AcceptanceRadius_69;
	params.bStopOnOverlap_69 = bStopOnOverlap_69;
	params.bUsePathfinding_69 = bUsePathfinding_69;
	params.bCanStrafe_69 = bCanStrafe_69;
	params.FilterClass_69 = FilterClass_69;
	params.bAllowPartialPath_69 = bAllowPartialPath_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AIModule.AIController.K2_SetFocus
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// class Actor_32759*             NewFocus_69                    (Parm, ZeroConstructor)

void AIController::K2_SetFocus(class Actor_32759* NewFocus_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.AIController.K2_SetFocus"));

	AIController_K2_SetFocus_Params params;
	params.NewFocus_69 = NewFocus_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AIModule.AIController.K2_SetFocalPoint
// (Final, Native, Public, HasDefaults, BlueprintCallable)
// Parameters:
// struct FVector                 FP_69                          (Parm, ZeroConstructor, IsPlainOldData)

void AIController::K2_SetFocalPoint(const struct FVector& FP_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.AIController.K2_SetFocalPoint"));

	AIController_K2_SetFocalPoint_Params params;
	params.FP_69 = FP_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AIModule.AIController.K2_ClearFocus
// (Final, Native, Public, BlueprintCallable)

void AIController::K2_ClearFocus()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.AIController.K2_ClearFocus"));

	AIController_K2_ClearFocus_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AIModule.AIController.HasPartialPath
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool AIController::HasPartialPath()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.AIController.HasPartialPath"));

	AIController_HasPartialPath_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AIModule.AIController.GetPathFollowingComponent
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// class PathFollowingComponent*  ReturnValue_69                 (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)

class PathFollowingComponent* AIController::GetPathFollowingComponent()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.AIController.GetPathFollowingComponent"));

	AIController_GetPathFollowingComponent_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AIModule.AIController.GetMoveStatus
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// TEnumAsByte<EPathFollowingStatus> ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

TEnumAsByte<EPathFollowingStatus> AIController::GetMoveStatus()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.AIController.GetMoveStatus"));

	AIController_GetMoveStatus_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AIModule.AIController.GetImmediateMoveDestination
// (Final, Native, Public, HasDefaults, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FVector                 ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

struct FVector AIController::GetImmediateMoveDestination()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.AIController.GetImmediateMoveDestination"));

	AIController_GetImmediateMoveDestination_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AIModule.AIController.GetFocusActor
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// class Actor_32759*             ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

class Actor_32759* AIController::GetFocusActor()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.AIController.GetFocusActor"));

	AIController_GetFocusActor_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AIModule.AIController.GetFocalPointOnActor
// (Native, Public, HasDefaults, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// class Actor_32759*             Actor_69                       (ConstParm, Parm, ZeroConstructor)
// struct FVector                 ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

struct FVector AIController::GetFocalPointOnActor(class Actor_32759* Actor_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.AIController.GetFocalPointOnActor"));

	AIController_GetFocalPointOnActor_Params params;
	params.Actor_69 = Actor_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AIModule.AIController.GetFocalPoint
// (Final, Native, Public, HasDefaults, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FVector                 ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

struct FVector AIController::GetFocalPoint()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.AIController.GetFocalPoint"));

	AIController_GetFocalPoint_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AIModule.AIController.GetAIPerceptionComponent
// (Final, Native, Public, BlueprintCallable, BlueprintPure)
// Parameters:
// class AIPerceptionComponent*   ReturnValue_69                 (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)

class AIPerceptionComponent* AIController::GetAIPerceptionComponent()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.AIController.GetAIPerceptionComponent"));

	AIController_GetAIPerceptionComponent_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AIModule.AIController.ClaimTaskResource
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// class GameplayTaskResource*    ResourceClass_69               (Parm, ZeroConstructor)

void AIController::ClaimTaskResource(class GameplayTaskResource* ResourceClass_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.AIController.ClaimTaskResource"));

	AIController_ClaimTaskResource_Params params;
	params.ResourceClass_69 = ResourceClass_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AIModule.AITask_MoveTo.AIMoveTo
// (Final, Native, Static, Public, HasDefaults, BlueprintCallable)
// Parameters:
// class AIController*            Controller_69                  (Parm, ZeroConstructor)
// struct FVector                 GoalLocation_69                (Parm, ZeroConstructor, IsPlainOldData)
// class Actor_32759*             GoalActor_69                   (Parm, ZeroConstructor)
// float                          AcceptanceRadius_69            (Parm, ZeroConstructor, IsPlainOldData)
// TEnumAsByte<EAIOptionFlag>     StopOnOverlap_69               (Parm, ZeroConstructor, IsPlainOldData)
// TEnumAsByte<EAIOptionFlag>     AcceptPartialPath_69           (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bUsePathfinding_69             (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bLockAILogic_69                (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bUseContinuousGoalTracking_69  (Parm, ZeroConstructor, IsPlainOldData)
// TEnumAsByte<EAIOptionFlag>     ProjectGoalOnNavigation_69     (Parm, ZeroConstructor, IsPlainOldData)
// class AITask_MoveTo*           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

class AITask_MoveTo* AITask_MoveTo::STATIC_AIMoveTo(class AIController* Controller_69, const struct FVector& GoalLocation_69, class Actor_32759* GoalActor_69, float AcceptanceRadius_69, TEnumAsByte<EAIOptionFlag> StopOnOverlap_69, TEnumAsByte<EAIOptionFlag> AcceptPartialPath_69, bool bUsePathfinding_69, bool bLockAILogic_69, bool bUseContinuousGoalTracking_69, TEnumAsByte<EAIOptionFlag> ProjectGoalOnNavigation_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.AITask_MoveTo.AIMoveTo"));

	AITask_MoveTo_AIMoveTo_Params params;
	params.Controller_69 = Controller_69;
	params.GoalLocation_69 = GoalLocation_69;
	params.GoalActor_69 = GoalActor_69;
	params.AcceptanceRadius_69 = AcceptanceRadius_69;
	params.StopOnOverlap_69 = StopOnOverlap_69;
	params.AcceptPartialPath_69 = AcceptPartialPath_69;
	params.bUsePathfinding_69 = bUsePathfinding_69;
	params.bLockAILogic_69 = bLockAILogic_69;
	params.bUseContinuousGoalTracking_69 = bUseContinuousGoalTracking_69;
	params.ProjectGoalOnNavigation_69 = ProjectGoalOnNavigation_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AIModule.AIAsyncTaskBlueprintProxy.OnMoveCompleted
// (Final, Native, Public)
// Parameters:
// struct FAIRequestID            RequestId_69                   (Parm)
// TEnumAsByte<EPathFollowingResult> MovementResult_69              (Parm, ZeroConstructor, IsPlainOldData)

void AIAsyncTaskBlueprintProxy::OnMoveCompleted(const struct FAIRequestID& RequestId_69, TEnumAsByte<EPathFollowingResult> MovementResult_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.AIAsyncTaskBlueprintProxy.OnMoveCompleted"));

	AIAsyncTaskBlueprintProxy_OnMoveCompleted_Params params;
	params.RequestId_69 = RequestId_69;
	params.MovementResult_69 = MovementResult_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AIModule.PawnAction.GetActionPriority
// (Final, Native, Public, BlueprintCallable, BlueprintPure)
// Parameters:
// TEnumAsByte<EAIRequestPriority> ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

TEnumAsByte<EAIRequestPriority> PawnAction::GetActionPriority()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.PawnAction.GetActionPriority"));

	PawnAction_GetActionPriority_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AIModule.PawnAction.Finish
// (Native, Protected, BlueprintCallable)
// Parameters:
// TEnumAsByte<EPawnActionResult> WithResult_69                  (Parm, ZeroConstructor, IsPlainOldData)

void PawnAction::Finish(TEnumAsByte<EPawnActionResult> WithResult_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.PawnAction.Finish"));

	PawnAction_Finish_Params params;
	params.WithResult_69 = WithResult_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AIModule.PawnAction.CreateActionInstance
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// class Object_32759*            WorldContextObject_69          (Parm, ZeroConstructor)
// class PawnAction*              ActionClass_69                 (Parm, ZeroConstructor)
// class PawnAction*              ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

class PawnAction* PawnAction::STATIC_CreateActionInstance(class Object_32759* WorldContextObject_69, class PawnAction* ActionClass_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.PawnAction.CreateActionInstance"));

	PawnAction_CreateActionInstance_Params params;
	params.WorldContextObject_69 = WorldContextObject_69;
	params.ActionClass_69 = ActionClass_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AIModule.PawnActionsComponent.K2_PushAction
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// class PawnAction*              NewAction_69                   (Parm, ZeroConstructor)
// TEnumAsByte<EAIRequestPriority> Priority_69                    (Parm, ZeroConstructor, IsPlainOldData)
// class Object_32759*            Instigator_69                  (Parm, ZeroConstructor)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool PawnActionsComponent::K2_PushAction(class PawnAction* NewAction_69, TEnumAsByte<EAIRequestPriority> Priority_69, class Object_32759* Instigator_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.PawnActionsComponent.K2_PushAction"));

	PawnActionsComponent_K2_PushAction_Params params;
	params.NewAction_69 = NewAction_69;
	params.Priority_69 = Priority_69;
	params.Instigator_69 = Instigator_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AIModule.PawnActionsComponent.K2_PerformAction
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// class Pawn*                    Pawn_69                        (Parm, ZeroConstructor)
// class PawnAction*              Action_69                      (Parm, ZeroConstructor)
// TEnumAsByte<EAIRequestPriority> Priority_69                    (Parm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool PawnActionsComponent::STATIC_K2_PerformAction(class Pawn* Pawn_69, class PawnAction* Action_69, TEnumAsByte<EAIRequestPriority> Priority_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.PawnActionsComponent.K2_PerformAction"));

	PawnActionsComponent_K2_PerformAction_Params params;
	params.Pawn_69 = Pawn_69;
	params.Action_69 = Action_69;
	params.Priority_69 = Priority_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AIModule.PawnActionsComponent.K2_ForceAbortAction
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// class PawnAction*              ActionToAbort_69               (Parm, ZeroConstructor)
// TEnumAsByte<EPawnActionAbortState> ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

TEnumAsByte<EPawnActionAbortState> PawnActionsComponent::K2_ForceAbortAction(class PawnAction* ActionToAbort_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.PawnActionsComponent.K2_ForceAbortAction"));

	PawnActionsComponent_K2_ForceAbortAction_Params params;
	params.ActionToAbort_69 = ActionToAbort_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AIModule.PawnActionsComponent.K2_AbortAction
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// class PawnAction*              ActionToAbort_69               (Parm, ZeroConstructor)
// TEnumAsByte<EPawnActionAbortState> ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

TEnumAsByte<EPawnActionAbortState> PawnActionsComponent::K2_AbortAction(class PawnAction* ActionToAbort_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.PawnActionsComponent.K2_AbortAction"));

	PawnActionsComponent_K2_AbortAction_Params params;
	params.ActionToAbort_69 = ActionToAbort_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AIModule.PawnAction_BlueprintBase.ActionTick
// (Event, Public, BlueprintEvent)
// Parameters:
// class Pawn*                    ControlledPawn_69              (Parm, ZeroConstructor)
// float                          DeltaSeconds_69                (Parm, ZeroConstructor, IsPlainOldData)

void PawnAction_BlueprintBase::ActionTick(class Pawn* ControlledPawn_69, float DeltaSeconds_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.PawnAction_BlueprintBase.ActionTick"));

	PawnAction_BlueprintBase_ActionTick_Params params;
	params.ControlledPawn_69 = ControlledPawn_69;
	params.DeltaSeconds_69 = DeltaSeconds_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AIModule.PawnAction_BlueprintBase.ActionStart
// (Event, Public, BlueprintEvent)
// Parameters:
// class Pawn*                    ControlledPawn_69              (Parm, ZeroConstructor)

void PawnAction_BlueprintBase::ActionStart(class Pawn* ControlledPawn_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.PawnAction_BlueprintBase.ActionStart"));

	PawnAction_BlueprintBase_ActionStart_Params params;
	params.ControlledPawn_69 = ControlledPawn_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AIModule.PawnAction_BlueprintBase.ActionResume
// (Event, Public, BlueprintEvent)
// Parameters:
// class Pawn*                    ControlledPawn_69              (Parm, ZeroConstructor)

void PawnAction_BlueprintBase::ActionResume(class Pawn* ControlledPawn_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.PawnAction_BlueprintBase.ActionResume"));

	PawnAction_BlueprintBase_ActionResume_Params params;
	params.ControlledPawn_69 = ControlledPawn_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AIModule.PawnAction_BlueprintBase.ActionPause
// (Event, Public, BlueprintEvent)
// Parameters:
// class Pawn*                    ControlledPawn_69              (Parm, ZeroConstructor)

void PawnAction_BlueprintBase::ActionPause(class Pawn* ControlledPawn_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.PawnAction_BlueprintBase.ActionPause"));

	PawnAction_BlueprintBase_ActionPause_Params params;
	params.ControlledPawn_69 = ControlledPawn_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AIModule.PawnAction_BlueprintBase.ActionFinished
// (Event, Public, BlueprintEvent)
// Parameters:
// class Pawn*                    ControlledPawn_69              (Parm, ZeroConstructor)
// TEnumAsByte<EPawnActionResult> WithResult_69                  (Parm, ZeroConstructor, IsPlainOldData)

void PawnAction_BlueprintBase::ActionFinished(class Pawn* ControlledPawn_69, TEnumAsByte<EPawnActionResult> WithResult_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.PawnAction_BlueprintBase.ActionFinished"));

	PawnAction_BlueprintBase_ActionFinished_Params params;
	params.ControlledPawn_69 = ControlledPawn_69;
	params.WithResult_69 = WithResult_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AIModule.AISystem.AILoggingVerbose
// (Exec, Native, Public)

void AISystem::AILoggingVerbose()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.AISystem.AILoggingVerbose"));

	AISystem_AILoggingVerbose_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AIModule.AISystem.AIIgnorePlayers
// (Exec, Native, Public)

void AISystem::AIIgnorePlayers()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.AISystem.AIIgnorePlayers"));

	AISystem_AIIgnorePlayers_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AIModule.BrainComponent.StopLogic
// (Native, Public, BlueprintCallable)
// Parameters:
// struct FString                 Reason_69                      (Parm, ZeroConstructor)

void BrainComponent::StopLogic(const struct FString& Reason_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.BrainComponent.StopLogic"));

	BrainComponent_StopLogic_Params params;
	params.Reason_69 = Reason_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AIModule.BrainComponent.StartLogic
// (Native, Public, BlueprintCallable)

void BrainComponent::StartLogic()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.BrainComponent.StartLogic"));

	BrainComponent_StartLogic_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AIModule.BrainComponent.RestartLogic
// (Native, Public, BlueprintCallable)

void BrainComponent::RestartLogic()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.BrainComponent.RestartLogic"));

	BrainComponent_RestartLogic_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AIModule.BrainComponent.IsRunning
// (Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool BrainComponent::IsRunning()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.BrainComponent.IsRunning"));

	BrainComponent_IsRunning_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AIModule.BrainComponent.IsPaused
// (Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool BrainComponent::IsPaused()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.BrainComponent.IsPaused"));

	BrainComponent_IsPaused_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AIModule.BehaviorTreeComponent.SetDynamicSubtree
// (Native, Public, BlueprintCallable)
// Parameters:
// struct FGameplayTag            InjectTag_69                   (Parm)
// class BehaviorTree*            BehaviorAsset_69               (Parm, ZeroConstructor)

void BehaviorTreeComponent::SetDynamicSubtree(const struct FGameplayTag& InjectTag_69, class BehaviorTree* BehaviorAsset_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.BehaviorTreeComponent.SetDynamicSubtree"));

	BehaviorTreeComponent_SetDynamicSubtree_Params params;
	params.InjectTag_69 = InjectTag_69;
	params.BehaviorAsset_69 = BehaviorAsset_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AIModule.BehaviorTreeComponent.GetTagCooldownEndTime
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FGameplayTag            CooldownTag_69                 (Parm)
// float                          ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

float BehaviorTreeComponent::GetTagCooldownEndTime(const struct FGameplayTag& CooldownTag_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.BehaviorTreeComponent.GetTagCooldownEndTime"));

	BehaviorTreeComponent_GetTagCooldownEndTime_Params params;
	params.CooldownTag_69 = CooldownTag_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AIModule.BehaviorTreeComponent.AddCooldownTagDuration
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// struct FGameplayTag            CooldownTag_69                 (Parm)
// float                          CooldownDuration_69            (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bAddToExistingDuration_69      (Parm, ZeroConstructor, IsPlainOldData)

void BehaviorTreeComponent::AddCooldownTagDuration(const struct FGameplayTag& CooldownTag_69, float CooldownDuration_69, bool bAddToExistingDuration_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.BehaviorTreeComponent.AddCooldownTagDuration"));

	BehaviorTreeComponent_AddCooldownTagDuration_Params params;
	params.CooldownTag_69 = CooldownTag_69;
	params.CooldownDuration_69 = CooldownDuration_69;
	params.bAddToExistingDuration_69 = bAddToExistingDuration_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AIModule.BlackboardAssetProvider.GetBlackboardAsset
// (Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// class BlackboardData*          ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

class BlackboardData* BlackboardAssetProvider::GetBlackboardAsset()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.BlackboardAssetProvider.GetBlackboardAsset"));

	BlackboardAssetProvider_GetBlackboardAsset_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AIModule.BlackboardComponent.SetValueAsVector
// (Final, Native, Public, HasOutParms, HasDefaults, BlueprintCallable)
// Parameters:
// struct FName                   KeyName_69                     (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
// struct FVector                 VectorValue_69                 (Parm, ZeroConstructor, IsPlainOldData)

void BlackboardComponent::SetValueAsVector(const struct FName& KeyName_69, const struct FVector& VectorValue_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.BlackboardComponent.SetValueAsVector"));

	BlackboardComponent_SetValueAsVector_Params params;
	params.KeyName_69 = KeyName_69;
	params.VectorValue_69 = VectorValue_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AIModule.BlackboardComponent.SetValueAsString
// (Final, Native, Public, HasOutParms, BlueprintCallable)
// Parameters:
// struct FName                   KeyName_69                     (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
// struct FString                 StringValue_69                 (Parm, ZeroConstructor)

void BlackboardComponent::SetValueAsString(const struct FName& KeyName_69, const struct FString& StringValue_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.BlackboardComponent.SetValueAsString"));

	BlackboardComponent_SetValueAsString_Params params;
	params.KeyName_69 = KeyName_69;
	params.StringValue_69 = StringValue_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AIModule.BlackboardComponent.SetValueAsRotator
// (Final, Native, Public, HasOutParms, HasDefaults, BlueprintCallable)
// Parameters:
// struct FName                   KeyName_69                     (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
// struct FRotator                VectorValue_69                 (Parm, ZeroConstructor, IsPlainOldData)

void BlackboardComponent::SetValueAsRotator(const struct FName& KeyName_69, const struct FRotator& VectorValue_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.BlackboardComponent.SetValueAsRotator"));

	BlackboardComponent_SetValueAsRotator_Params params;
	params.KeyName_69 = KeyName_69;
	params.VectorValue_69 = VectorValue_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AIModule.BlackboardComponent.SetValueAsObject
// (Final, Native, Public, HasOutParms, BlueprintCallable)
// Parameters:
// struct FName                   KeyName_69                     (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
// class Object_32759*            ObjectValue_69                 (Parm, ZeroConstructor)

void BlackboardComponent::SetValueAsObject(const struct FName& KeyName_69, class Object_32759* ObjectValue_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.BlackboardComponent.SetValueAsObject"));

	BlackboardComponent_SetValueAsObject_Params params;
	params.KeyName_69 = KeyName_69;
	params.ObjectValue_69 = ObjectValue_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AIModule.BlackboardComponent.SetValueAsName
// (Final, Native, Public, HasOutParms, BlueprintCallable)
// Parameters:
// struct FName                   KeyName_69                     (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
// struct FName                   NameValue_69                   (Parm, ZeroConstructor, IsPlainOldData)

void BlackboardComponent::SetValueAsName(const struct FName& KeyName_69, const struct FName& NameValue_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.BlackboardComponent.SetValueAsName"));

	BlackboardComponent_SetValueAsName_Params params;
	params.KeyName_69 = KeyName_69;
	params.NameValue_69 = NameValue_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AIModule.BlackboardComponent.SetValueAsInt
// (Final, Native, Public, HasOutParms, BlueprintCallable)
// Parameters:
// struct FName                   KeyName_69                     (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
// int                            IntValue_69                    (Parm, ZeroConstructor, IsPlainOldData)

void BlackboardComponent::SetValueAsInt(const struct FName& KeyName_69, int IntValue_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.BlackboardComponent.SetValueAsInt"));

	BlackboardComponent_SetValueAsInt_Params params;
	params.KeyName_69 = KeyName_69;
	params.IntValue_69 = IntValue_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AIModule.BlackboardComponent.SetValueAsFloat
// (Final, Native, Public, HasOutParms, BlueprintCallable)
// Parameters:
// struct FName                   KeyName_69                     (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
// float                          FloatValue_69                  (Parm, ZeroConstructor, IsPlainOldData)

void BlackboardComponent::SetValueAsFloat(const struct FName& KeyName_69, float FloatValue_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.BlackboardComponent.SetValueAsFloat"));

	BlackboardComponent_SetValueAsFloat_Params params;
	params.KeyName_69 = KeyName_69;
	params.FloatValue_69 = FloatValue_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AIModule.BlackboardComponent.SetValueAsEnum
// (Final, Native, Public, HasOutParms, BlueprintCallable)
// Parameters:
// struct FName                   KeyName_69                     (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
// unsigned char                  EnumValue_69                   (Parm, ZeroConstructor, IsPlainOldData)

void BlackboardComponent::SetValueAsEnum(const struct FName& KeyName_69, unsigned char EnumValue_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.BlackboardComponent.SetValueAsEnum"));

	BlackboardComponent_SetValueAsEnum_Params params;
	params.KeyName_69 = KeyName_69;
	params.EnumValue_69 = EnumValue_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AIModule.BlackboardComponent.SetValueAsClass
// (Final, Native, Public, HasOutParms, BlueprintCallable)
// Parameters:
// struct FName                   KeyName_69                     (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
// class Object_32759*            ClassValue_69                  (Parm, ZeroConstructor)

void BlackboardComponent::SetValueAsClass(const struct FName& KeyName_69, class Object_32759* ClassValue_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.BlackboardComponent.SetValueAsClass"));

	BlackboardComponent_SetValueAsClass_Params params;
	params.KeyName_69 = KeyName_69;
	params.ClassValue_69 = ClassValue_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AIModule.BlackboardComponent.SetValueAsBool
// (Final, Native, Public, HasOutParms, BlueprintCallable)
// Parameters:
// struct FName                   KeyName_69                     (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
// bool                           BoolValue_69                   (Parm, ZeroConstructor, IsPlainOldData)

void BlackboardComponent::SetValueAsBool(const struct FName& KeyName_69, bool BoolValue_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.BlackboardComponent.SetValueAsBool"));

	BlackboardComponent_SetValueAsBool_Params params;
	params.KeyName_69 = KeyName_69;
	params.BoolValue_69 = BoolValue_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AIModule.BlackboardComponent.IsVectorValueSet
// (Final, Native, Public, HasOutParms, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FName                   KeyName_69                     (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool BlackboardComponent::IsVectorValueSet(const struct FName& KeyName_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.BlackboardComponent.IsVectorValueSet"));

	BlackboardComponent_IsVectorValueSet_Params params;
	params.KeyName_69 = KeyName_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AIModule.BlackboardComponent.GetValueAsVector
// (Final, Native, Public, HasOutParms, HasDefaults, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FName                   KeyName_69                     (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
// struct FVector                 ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

struct FVector BlackboardComponent::GetValueAsVector(const struct FName& KeyName_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.BlackboardComponent.GetValueAsVector"));

	BlackboardComponent_GetValueAsVector_Params params;
	params.KeyName_69 = KeyName_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AIModule.BlackboardComponent.GetValueAsString
// (Final, Native, Public, HasOutParms, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FName                   KeyName_69                     (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
// struct FString                 ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString BlackboardComponent::GetValueAsString(const struct FName& KeyName_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.BlackboardComponent.GetValueAsString"));

	BlackboardComponent_GetValueAsString_Params params;
	params.KeyName_69 = KeyName_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AIModule.BlackboardComponent.GetValueAsRotator
// (Final, Native, Public, HasOutParms, HasDefaults, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FName                   KeyName_69                     (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
// struct FRotator                ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

struct FRotator BlackboardComponent::GetValueAsRotator(const struct FName& KeyName_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.BlackboardComponent.GetValueAsRotator"));

	BlackboardComponent_GetValueAsRotator_Params params;
	params.KeyName_69 = KeyName_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AIModule.BlackboardComponent.GetValueAsObject
// (Final, Native, Public, HasOutParms, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FName                   KeyName_69                     (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
// class Object_32759*            ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

class Object_32759* BlackboardComponent::GetValueAsObject(const struct FName& KeyName_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.BlackboardComponent.GetValueAsObject"));

	BlackboardComponent_GetValueAsObject_Params params;
	params.KeyName_69 = KeyName_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AIModule.BlackboardComponent.GetValueAsName
// (Final, Native, Public, HasOutParms, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FName                   KeyName_69                     (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
// struct FName                   ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

struct FName BlackboardComponent::GetValueAsName(const struct FName& KeyName_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.BlackboardComponent.GetValueAsName"));

	BlackboardComponent_GetValueAsName_Params params;
	params.KeyName_69 = KeyName_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AIModule.BlackboardComponent.GetValueAsInt
// (Final, Native, Public, HasOutParms, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FName                   KeyName_69                     (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
// int                            ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int BlackboardComponent::GetValueAsInt(const struct FName& KeyName_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.BlackboardComponent.GetValueAsInt"));

	BlackboardComponent_GetValueAsInt_Params params;
	params.KeyName_69 = KeyName_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AIModule.BlackboardComponent.GetValueAsFloat
// (Final, Native, Public, HasOutParms, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FName                   KeyName_69                     (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
// float                          ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

float BlackboardComponent::GetValueAsFloat(const struct FName& KeyName_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.BlackboardComponent.GetValueAsFloat"));

	BlackboardComponent_GetValueAsFloat_Params params;
	params.KeyName_69 = KeyName_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AIModule.BlackboardComponent.GetValueAsEnum
// (Final, Native, Public, HasOutParms, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FName                   KeyName_69                     (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
// unsigned char                  ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

unsigned char BlackboardComponent::GetValueAsEnum(const struct FName& KeyName_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.BlackboardComponent.GetValueAsEnum"));

	BlackboardComponent_GetValueAsEnum_Params params;
	params.KeyName_69 = KeyName_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AIModule.BlackboardComponent.GetValueAsClass
// (Final, Native, Public, HasOutParms, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FName                   KeyName_69                     (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
// class Object_32759*            ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

class Object_32759* BlackboardComponent::GetValueAsClass(const struct FName& KeyName_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.BlackboardComponent.GetValueAsClass"));

	BlackboardComponent_GetValueAsClass_Params params;
	params.KeyName_69 = KeyName_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AIModule.BlackboardComponent.GetValueAsBool
// (Final, Native, Public, HasOutParms, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FName                   KeyName_69                     (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool BlackboardComponent::GetValueAsBool(const struct FName& KeyName_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.BlackboardComponent.GetValueAsBool"));

	BlackboardComponent_GetValueAsBool_Params params;
	params.KeyName_69 = KeyName_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AIModule.BlackboardComponent.GetRotationFromEntry
// (Final, Native, Public, HasOutParms, HasDefaults, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FName                   KeyName_69                     (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
// struct FRotator                ResultRotation_69              (Parm, OutParm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool BlackboardComponent::GetRotationFromEntry(const struct FName& KeyName_69, struct FRotator* ResultRotation_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.BlackboardComponent.GetRotationFromEntry"));

	BlackboardComponent_GetRotationFromEntry_Params params;
	params.KeyName_69 = KeyName_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (ResultRotation_69 != nullptr)
		*ResultRotation_69 = params.ResultRotation_69;

	return params.ReturnValue_69;
}


// Function AIModule.BlackboardComponent.GetLocationFromEntry
// (Final, Native, Public, HasOutParms, HasDefaults, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FName                   KeyName_69                     (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
// struct FVector                 ResultLocation_69              (Parm, OutParm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool BlackboardComponent::GetLocationFromEntry(const struct FName& KeyName_69, struct FVector* ResultLocation_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.BlackboardComponent.GetLocationFromEntry"));

	BlackboardComponent_GetLocationFromEntry_Params params;
	params.KeyName_69 = KeyName_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (ResultLocation_69 != nullptr)
		*ResultLocation_69 = params.ResultLocation_69;

	return params.ReturnValue_69;
}


// Function AIModule.BlackboardComponent.ClearValue
// (Final, Native, Public, HasOutParms, BlueprintCallable)
// Parameters:
// struct FName                   KeyName_69                     (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)

void BlackboardComponent::ClearValue(const struct FName& KeyName_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.BlackboardComponent.ClearValue"));

	BlackboardComponent_ClearValue_Params params;
	params.KeyName_69 = KeyName_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AIModule.BTFunctionLibrary.StopUsingExternalEvent
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// class BTNode*                  NodeOwner_69                   (Parm, ZeroConstructor)

void BTFunctionLibrary::STATIC_StopUsingExternalEvent(class BTNode* NodeOwner_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.BTFunctionLibrary.StopUsingExternalEvent"));

	BTFunctionLibrary_StopUsingExternalEvent_Params params;
	params.NodeOwner_69 = NodeOwner_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AIModule.BTFunctionLibrary.StartUsingExternalEvent
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// class BTNode*                  NodeOwner_69                   (Parm, ZeroConstructor)
// class Actor_32759*             OwningActor_69                 (Parm, ZeroConstructor)

void BTFunctionLibrary::STATIC_StartUsingExternalEvent(class BTNode* NodeOwner_69, class Actor_32759* OwningActor_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.BTFunctionLibrary.StartUsingExternalEvent"));

	BTFunctionLibrary_StartUsingExternalEvent_Params params;
	params.NodeOwner_69 = NodeOwner_69;
	params.OwningActor_69 = OwningActor_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AIModule.BTFunctionLibrary.SetBlackboardValueAsVector
// (Final, Native, Static, Public, HasOutParms, HasDefaults, BlueprintCallable)
// Parameters:
// class BTNode*                  NodeOwner_69                   (Parm, ZeroConstructor)
// struct FBlackboardKeySelector  Key_69                         (ConstParm, Parm, OutParm, ReferenceParm)
// struct FVector                 Value_69                       (Parm, ZeroConstructor, IsPlainOldData)

void BTFunctionLibrary::STATIC_SetBlackboardValueAsVector(class BTNode* NodeOwner_69, const struct FBlackboardKeySelector& Key_69, const struct FVector& Value_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.BTFunctionLibrary.SetBlackboardValueAsVector"));

	BTFunctionLibrary_SetBlackboardValueAsVector_Params params;
	params.NodeOwner_69 = NodeOwner_69;
	params.Key_69 = Key_69;
	params.Value_69 = Value_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AIModule.BTFunctionLibrary.SetBlackboardValueAsString
// (Final, Native, Static, Public, HasOutParms, BlueprintCallable)
// Parameters:
// class BTNode*                  NodeOwner_69                   (Parm, ZeroConstructor)
// struct FBlackboardKeySelector  Key_69                         (ConstParm, Parm, OutParm, ReferenceParm)
// struct FString                 Value_69                       (Parm, ZeroConstructor)

void BTFunctionLibrary::STATIC_SetBlackboardValueAsString(class BTNode* NodeOwner_69, const struct FBlackboardKeySelector& Key_69, const struct FString& Value_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.BTFunctionLibrary.SetBlackboardValueAsString"));

	BTFunctionLibrary_SetBlackboardValueAsString_Params params;
	params.NodeOwner_69 = NodeOwner_69;
	params.Key_69 = Key_69;
	params.Value_69 = Value_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AIModule.BTFunctionLibrary.SetBlackboardValueAsRotator
// (Final, Native, Static, Public, HasOutParms, HasDefaults, BlueprintCallable)
// Parameters:
// class BTNode*                  NodeOwner_69                   (Parm, ZeroConstructor)
// struct FBlackboardKeySelector  Key_69                         (ConstParm, Parm, OutParm, ReferenceParm)
// struct FRotator                Value_69                       (Parm, ZeroConstructor, IsPlainOldData)

void BTFunctionLibrary::STATIC_SetBlackboardValueAsRotator(class BTNode* NodeOwner_69, const struct FBlackboardKeySelector& Key_69, const struct FRotator& Value_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.BTFunctionLibrary.SetBlackboardValueAsRotator"));

	BTFunctionLibrary_SetBlackboardValueAsRotator_Params params;
	params.NodeOwner_69 = NodeOwner_69;
	params.Key_69 = Key_69;
	params.Value_69 = Value_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AIModule.BTFunctionLibrary.SetBlackboardValueAsObject
// (Final, Native, Static, Public, HasOutParms, BlueprintCallable)
// Parameters:
// class BTNode*                  NodeOwner_69                   (Parm, ZeroConstructor)
// struct FBlackboardKeySelector  Key_69                         (ConstParm, Parm, OutParm, ReferenceParm)
// class Object_32759*            Value_69                       (Parm, ZeroConstructor)

void BTFunctionLibrary::STATIC_SetBlackboardValueAsObject(class BTNode* NodeOwner_69, const struct FBlackboardKeySelector& Key_69, class Object_32759* Value_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.BTFunctionLibrary.SetBlackboardValueAsObject"));

	BTFunctionLibrary_SetBlackboardValueAsObject_Params params;
	params.NodeOwner_69 = NodeOwner_69;
	params.Key_69 = Key_69;
	params.Value_69 = Value_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AIModule.BTFunctionLibrary.SetBlackboardValueAsName
// (Final, Native, Static, Public, HasOutParms, BlueprintCallable)
// Parameters:
// class BTNode*                  NodeOwner_69                   (Parm, ZeroConstructor)
// struct FBlackboardKeySelector  Key_69                         (ConstParm, Parm, OutParm, ReferenceParm)
// struct FName                   Value_69                       (Parm, ZeroConstructor, IsPlainOldData)

void BTFunctionLibrary::STATIC_SetBlackboardValueAsName(class BTNode* NodeOwner_69, const struct FBlackboardKeySelector& Key_69, const struct FName& Value_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.BTFunctionLibrary.SetBlackboardValueAsName"));

	BTFunctionLibrary_SetBlackboardValueAsName_Params params;
	params.NodeOwner_69 = NodeOwner_69;
	params.Key_69 = Key_69;
	params.Value_69 = Value_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AIModule.BTFunctionLibrary.SetBlackboardValueAsInt
// (Final, Native, Static, Public, HasOutParms, BlueprintCallable)
// Parameters:
// class BTNode*                  NodeOwner_69                   (Parm, ZeroConstructor)
// struct FBlackboardKeySelector  Key_69                         (ConstParm, Parm, OutParm, ReferenceParm)
// int                            Value_69                       (Parm, ZeroConstructor, IsPlainOldData)

void BTFunctionLibrary::STATIC_SetBlackboardValueAsInt(class BTNode* NodeOwner_69, const struct FBlackboardKeySelector& Key_69, int Value_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.BTFunctionLibrary.SetBlackboardValueAsInt"));

	BTFunctionLibrary_SetBlackboardValueAsInt_Params params;
	params.NodeOwner_69 = NodeOwner_69;
	params.Key_69 = Key_69;
	params.Value_69 = Value_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AIModule.BTFunctionLibrary.SetBlackboardValueAsFloat
// (Final, Native, Static, Public, HasOutParms, BlueprintCallable)
// Parameters:
// class BTNode*                  NodeOwner_69                   (Parm, ZeroConstructor)
// struct FBlackboardKeySelector  Key_69                         (ConstParm, Parm, OutParm, ReferenceParm)
// float                          Value_69                       (Parm, ZeroConstructor, IsPlainOldData)

void BTFunctionLibrary::STATIC_SetBlackboardValueAsFloat(class BTNode* NodeOwner_69, const struct FBlackboardKeySelector& Key_69, float Value_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.BTFunctionLibrary.SetBlackboardValueAsFloat"));

	BTFunctionLibrary_SetBlackboardValueAsFloat_Params params;
	params.NodeOwner_69 = NodeOwner_69;
	params.Key_69 = Key_69;
	params.Value_69 = Value_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AIModule.BTFunctionLibrary.SetBlackboardValueAsEnum
// (Final, Native, Static, Public, HasOutParms, BlueprintCallable)
// Parameters:
// class BTNode*                  NodeOwner_69                   (Parm, ZeroConstructor)
// struct FBlackboardKeySelector  Key_69                         (ConstParm, Parm, OutParm, ReferenceParm)
// unsigned char                  Value_69                       (Parm, ZeroConstructor, IsPlainOldData)

void BTFunctionLibrary::STATIC_SetBlackboardValueAsEnum(class BTNode* NodeOwner_69, const struct FBlackboardKeySelector& Key_69, unsigned char Value_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.BTFunctionLibrary.SetBlackboardValueAsEnum"));

	BTFunctionLibrary_SetBlackboardValueAsEnum_Params params;
	params.NodeOwner_69 = NodeOwner_69;
	params.Key_69 = Key_69;
	params.Value_69 = Value_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AIModule.BTFunctionLibrary.SetBlackboardValueAsClass
// (Final, Native, Static, Public, HasOutParms, BlueprintCallable)
// Parameters:
// class BTNode*                  NodeOwner_69                   (Parm, ZeroConstructor)
// struct FBlackboardKeySelector  Key_69                         (ConstParm, Parm, OutParm, ReferenceParm)
// class Object_32759*            Value_69                       (Parm, ZeroConstructor)

void BTFunctionLibrary::STATIC_SetBlackboardValueAsClass(class BTNode* NodeOwner_69, const struct FBlackboardKeySelector& Key_69, class Object_32759* Value_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.BTFunctionLibrary.SetBlackboardValueAsClass"));

	BTFunctionLibrary_SetBlackboardValueAsClass_Params params;
	params.NodeOwner_69 = NodeOwner_69;
	params.Key_69 = Key_69;
	params.Value_69 = Value_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AIModule.BTFunctionLibrary.SetBlackboardValueAsBool
// (Final, Native, Static, Public, HasOutParms, BlueprintCallable)
// Parameters:
// class BTNode*                  NodeOwner_69                   (Parm, ZeroConstructor)
// struct FBlackboardKeySelector  Key_69                         (ConstParm, Parm, OutParm, ReferenceParm)
// bool                           Value_69                       (Parm, ZeroConstructor, IsPlainOldData)

void BTFunctionLibrary::STATIC_SetBlackboardValueAsBool(class BTNode* NodeOwner_69, const struct FBlackboardKeySelector& Key_69, bool Value_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.BTFunctionLibrary.SetBlackboardValueAsBool"));

	BTFunctionLibrary_SetBlackboardValueAsBool_Params params;
	params.NodeOwner_69 = NodeOwner_69;
	params.Key_69 = Key_69;
	params.Value_69 = Value_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AIModule.BTFunctionLibrary.GetOwnersBlackboard
// (Final, Native, Static, Public, BlueprintCallable, BlueprintPure)
// Parameters:
// class BTNode*                  NodeOwner_69                   (Parm, ZeroConstructor)
// class BlackboardComponent*     ReturnValue_69                 (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)

class BlackboardComponent* BTFunctionLibrary::STATIC_GetOwnersBlackboard(class BTNode* NodeOwner_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.BTFunctionLibrary.GetOwnersBlackboard"));

	BTFunctionLibrary_GetOwnersBlackboard_Params params;
	params.NodeOwner_69 = NodeOwner_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AIModule.BTFunctionLibrary.GetOwnerComponent
// (Final, Native, Static, Public, BlueprintCallable, BlueprintPure)
// Parameters:
// class BTNode*                  NodeOwner_69                   (Parm, ZeroConstructor)
// class BehaviorTreeComponent*   ReturnValue_69                 (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)

class BehaviorTreeComponent* BTFunctionLibrary::STATIC_GetOwnerComponent(class BTNode* NodeOwner_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.BTFunctionLibrary.GetOwnerComponent"));

	BTFunctionLibrary_GetOwnerComponent_Params params;
	params.NodeOwner_69 = NodeOwner_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AIModule.BTFunctionLibrary.GetBlackboardValueAsVector
// (Final, Native, Static, Public, HasOutParms, HasDefaults, BlueprintCallable, BlueprintPure)
// Parameters:
// class BTNode*                  NodeOwner_69                   (Parm, ZeroConstructor)
// struct FBlackboardKeySelector  Key_69                         (ConstParm, Parm, OutParm, ReferenceParm)
// struct FVector                 ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

struct FVector BTFunctionLibrary::STATIC_GetBlackboardValueAsVector(class BTNode* NodeOwner_69, const struct FBlackboardKeySelector& Key_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.BTFunctionLibrary.GetBlackboardValueAsVector"));

	BTFunctionLibrary_GetBlackboardValueAsVector_Params params;
	params.NodeOwner_69 = NodeOwner_69;
	params.Key_69 = Key_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AIModule.BTFunctionLibrary.GetBlackboardValueAsString
// (Final, Native, Static, Public, HasOutParms, BlueprintCallable, BlueprintPure)
// Parameters:
// class BTNode*                  NodeOwner_69                   (Parm, ZeroConstructor)
// struct FBlackboardKeySelector  Key_69                         (ConstParm, Parm, OutParm, ReferenceParm)
// struct FString                 ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString BTFunctionLibrary::STATIC_GetBlackboardValueAsString(class BTNode* NodeOwner_69, const struct FBlackboardKeySelector& Key_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.BTFunctionLibrary.GetBlackboardValueAsString"));

	BTFunctionLibrary_GetBlackboardValueAsString_Params params;
	params.NodeOwner_69 = NodeOwner_69;
	params.Key_69 = Key_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AIModule.BTFunctionLibrary.GetBlackboardValueAsRotator
// (Final, Native, Static, Public, HasOutParms, HasDefaults, BlueprintCallable, BlueprintPure)
// Parameters:
// class BTNode*                  NodeOwner_69                   (Parm, ZeroConstructor)
// struct FBlackboardKeySelector  Key_69                         (ConstParm, Parm, OutParm, ReferenceParm)
// struct FRotator                ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

struct FRotator BTFunctionLibrary::STATIC_GetBlackboardValueAsRotator(class BTNode* NodeOwner_69, const struct FBlackboardKeySelector& Key_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.BTFunctionLibrary.GetBlackboardValueAsRotator"));

	BTFunctionLibrary_GetBlackboardValueAsRotator_Params params;
	params.NodeOwner_69 = NodeOwner_69;
	params.Key_69 = Key_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AIModule.BTFunctionLibrary.GetBlackboardValueAsObject
// (Final, Native, Static, Public, HasOutParms, BlueprintCallable, BlueprintPure)
// Parameters:
// class BTNode*                  NodeOwner_69                   (Parm, ZeroConstructor)
// struct FBlackboardKeySelector  Key_69                         (ConstParm, Parm, OutParm, ReferenceParm)
// class Object_32759*            ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

class Object_32759* BTFunctionLibrary::STATIC_GetBlackboardValueAsObject(class BTNode* NodeOwner_69, const struct FBlackboardKeySelector& Key_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.BTFunctionLibrary.GetBlackboardValueAsObject"));

	BTFunctionLibrary_GetBlackboardValueAsObject_Params params;
	params.NodeOwner_69 = NodeOwner_69;
	params.Key_69 = Key_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AIModule.BTFunctionLibrary.GetBlackboardValueAsName
// (Final, Native, Static, Public, HasOutParms, BlueprintCallable, BlueprintPure)
// Parameters:
// class BTNode*                  NodeOwner_69                   (Parm, ZeroConstructor)
// struct FBlackboardKeySelector  Key_69                         (ConstParm, Parm, OutParm, ReferenceParm)
// struct FName                   ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

struct FName BTFunctionLibrary::STATIC_GetBlackboardValueAsName(class BTNode* NodeOwner_69, const struct FBlackboardKeySelector& Key_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.BTFunctionLibrary.GetBlackboardValueAsName"));

	BTFunctionLibrary_GetBlackboardValueAsName_Params params;
	params.NodeOwner_69 = NodeOwner_69;
	params.Key_69 = Key_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AIModule.BTFunctionLibrary.GetBlackboardValueAsInt
// (Final, Native, Static, Public, HasOutParms, BlueprintCallable, BlueprintPure)
// Parameters:
// class BTNode*                  NodeOwner_69                   (Parm, ZeroConstructor)
// struct FBlackboardKeySelector  Key_69                         (ConstParm, Parm, OutParm, ReferenceParm)
// int                            ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int BTFunctionLibrary::STATIC_GetBlackboardValueAsInt(class BTNode* NodeOwner_69, const struct FBlackboardKeySelector& Key_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.BTFunctionLibrary.GetBlackboardValueAsInt"));

	BTFunctionLibrary_GetBlackboardValueAsInt_Params params;
	params.NodeOwner_69 = NodeOwner_69;
	params.Key_69 = Key_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AIModule.BTFunctionLibrary.GetBlackboardValueAsFloat
// (Final, Native, Static, Public, HasOutParms, BlueprintCallable, BlueprintPure)
// Parameters:
// class BTNode*                  NodeOwner_69                   (Parm, ZeroConstructor)
// struct FBlackboardKeySelector  Key_69                         (ConstParm, Parm, OutParm, ReferenceParm)
// float                          ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

float BTFunctionLibrary::STATIC_GetBlackboardValueAsFloat(class BTNode* NodeOwner_69, const struct FBlackboardKeySelector& Key_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.BTFunctionLibrary.GetBlackboardValueAsFloat"));

	BTFunctionLibrary_GetBlackboardValueAsFloat_Params params;
	params.NodeOwner_69 = NodeOwner_69;
	params.Key_69 = Key_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AIModule.BTFunctionLibrary.GetBlackboardValueAsEnum
// (Final, Native, Static, Public, HasOutParms, BlueprintCallable, BlueprintPure)
// Parameters:
// class BTNode*                  NodeOwner_69                   (Parm, ZeroConstructor)
// struct FBlackboardKeySelector  Key_69                         (ConstParm, Parm, OutParm, ReferenceParm)
// unsigned char                  ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

unsigned char BTFunctionLibrary::STATIC_GetBlackboardValueAsEnum(class BTNode* NodeOwner_69, const struct FBlackboardKeySelector& Key_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.BTFunctionLibrary.GetBlackboardValueAsEnum"));

	BTFunctionLibrary_GetBlackboardValueAsEnum_Params params;
	params.NodeOwner_69 = NodeOwner_69;
	params.Key_69 = Key_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AIModule.BTFunctionLibrary.GetBlackboardValueAsClass
// (Final, Native, Static, Public, HasOutParms, BlueprintCallable, BlueprintPure)
// Parameters:
// class BTNode*                  NodeOwner_69                   (Parm, ZeroConstructor)
// struct FBlackboardKeySelector  Key_69                         (ConstParm, Parm, OutParm, ReferenceParm)
// class Object_32759*            ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

class Object_32759* BTFunctionLibrary::STATIC_GetBlackboardValueAsClass(class BTNode* NodeOwner_69, const struct FBlackboardKeySelector& Key_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.BTFunctionLibrary.GetBlackboardValueAsClass"));

	BTFunctionLibrary_GetBlackboardValueAsClass_Params params;
	params.NodeOwner_69 = NodeOwner_69;
	params.Key_69 = Key_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AIModule.BTFunctionLibrary.GetBlackboardValueAsBool
// (Final, Native, Static, Public, HasOutParms, BlueprintCallable, BlueprintPure)
// Parameters:
// class BTNode*                  NodeOwner_69                   (Parm, ZeroConstructor)
// struct FBlackboardKeySelector  Key_69                         (ConstParm, Parm, OutParm, ReferenceParm)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool BTFunctionLibrary::STATIC_GetBlackboardValueAsBool(class BTNode* NodeOwner_69, const struct FBlackboardKeySelector& Key_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.BTFunctionLibrary.GetBlackboardValueAsBool"));

	BTFunctionLibrary_GetBlackboardValueAsBool_Params params;
	params.NodeOwner_69 = NodeOwner_69;
	params.Key_69 = Key_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AIModule.BTFunctionLibrary.GetBlackboardValueAsActor
// (Final, Native, Static, Public, HasOutParms, BlueprintCallable, BlueprintPure)
// Parameters:
// class BTNode*                  NodeOwner_69                   (Parm, ZeroConstructor)
// struct FBlackboardKeySelector  Key_69                         (ConstParm, Parm, OutParm, ReferenceParm)
// class Actor_32759*             ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

class Actor_32759* BTFunctionLibrary::STATIC_GetBlackboardValueAsActor(class BTNode* NodeOwner_69, const struct FBlackboardKeySelector& Key_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.BTFunctionLibrary.GetBlackboardValueAsActor"));

	BTFunctionLibrary_GetBlackboardValueAsActor_Params params;
	params.NodeOwner_69 = NodeOwner_69;
	params.Key_69 = Key_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AIModule.BTFunctionLibrary.ClearBlackboardValueAsVector
// (Final, Native, Static, Public, HasOutParms, BlueprintCallable)
// Parameters:
// class BTNode*                  NodeOwner_69                   (Parm, ZeroConstructor)
// struct FBlackboardKeySelector  Key_69                         (ConstParm, Parm, OutParm, ReferenceParm)

void BTFunctionLibrary::STATIC_ClearBlackboardValueAsVector(class BTNode* NodeOwner_69, const struct FBlackboardKeySelector& Key_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.BTFunctionLibrary.ClearBlackboardValueAsVector"));

	BTFunctionLibrary_ClearBlackboardValueAsVector_Params params;
	params.NodeOwner_69 = NodeOwner_69;
	params.Key_69 = Key_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AIModule.BTFunctionLibrary.ClearBlackboardValue
// (Final, Native, Static, Public, HasOutParms, BlueprintCallable)
// Parameters:
// class BTNode*                  NodeOwner_69                   (Parm, ZeroConstructor)
// struct FBlackboardKeySelector  Key_69                         (ConstParm, Parm, OutParm, ReferenceParm)

void BTFunctionLibrary::STATIC_ClearBlackboardValue(class BTNode* NodeOwner_69, const struct FBlackboardKeySelector& Key_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.BTFunctionLibrary.ClearBlackboardValue"));

	BTFunctionLibrary_ClearBlackboardValue_Params params;
	params.NodeOwner_69 = NodeOwner_69;
	params.Key_69 = Key_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AIModule.BTDecorator_BlueprintBase.ReceiveTickAI
// (Event, Protected, BlueprintEvent)
// Parameters:
// class AIController*            OwnerController_69             (Parm, ZeroConstructor)
// class Pawn*                    ControlledPawn_69              (Parm, ZeroConstructor)
// float                          DeltaSeconds_69                (Parm, ZeroConstructor, IsPlainOldData)

void BTDecorator_BlueprintBase::ReceiveTickAI(class AIController* OwnerController_69, class Pawn* ControlledPawn_69, float DeltaSeconds_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.BTDecorator_BlueprintBase.ReceiveTickAI"));

	BTDecorator_BlueprintBase_ReceiveTickAI_Params params;
	params.OwnerController_69 = OwnerController_69;
	params.ControlledPawn_69 = ControlledPawn_69;
	params.DeltaSeconds_69 = DeltaSeconds_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AIModule.BTDecorator_BlueprintBase.ReceiveTick
// (Event, Protected, BlueprintEvent)
// Parameters:
// class Actor_32759*             OwnerActor_69                  (Parm, ZeroConstructor)
// float                          DeltaSeconds_69                (Parm, ZeroConstructor, IsPlainOldData)

void BTDecorator_BlueprintBase::ReceiveTick(class Actor_32759* OwnerActor_69, float DeltaSeconds_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.BTDecorator_BlueprintBase.ReceiveTick"));

	BTDecorator_BlueprintBase_ReceiveTick_Params params;
	params.OwnerActor_69 = OwnerActor_69;
	params.DeltaSeconds_69 = DeltaSeconds_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AIModule.BTDecorator_BlueprintBase.ReceiveObserverDeactivatedAI
// (Event, Protected, BlueprintEvent)
// Parameters:
// class AIController*            OwnerController_69             (Parm, ZeroConstructor)
// class Pawn*                    ControlledPawn_69              (Parm, ZeroConstructor)

void BTDecorator_BlueprintBase::ReceiveObserverDeactivatedAI(class AIController* OwnerController_69, class Pawn* ControlledPawn_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.BTDecorator_BlueprintBase.ReceiveObserverDeactivatedAI"));

	BTDecorator_BlueprintBase_ReceiveObserverDeactivatedAI_Params params;
	params.OwnerController_69 = OwnerController_69;
	params.ControlledPawn_69 = ControlledPawn_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AIModule.BTDecorator_BlueprintBase.ReceiveObserverDeactivated
// (Event, Protected, BlueprintEvent)
// Parameters:
// class Actor_32759*             OwnerActor_69                  (Parm, ZeroConstructor)

void BTDecorator_BlueprintBase::ReceiveObserverDeactivated(class Actor_32759* OwnerActor_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.BTDecorator_BlueprintBase.ReceiveObserverDeactivated"));

	BTDecorator_BlueprintBase_ReceiveObserverDeactivated_Params params;
	params.OwnerActor_69 = OwnerActor_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AIModule.BTDecorator_BlueprintBase.ReceiveObserverActivatedAI
// (Event, Protected, BlueprintEvent)
// Parameters:
// class AIController*            OwnerController_69             (Parm, ZeroConstructor)
// class Pawn*                    ControlledPawn_69              (Parm, ZeroConstructor)

void BTDecorator_BlueprintBase::ReceiveObserverActivatedAI(class AIController* OwnerController_69, class Pawn* ControlledPawn_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.BTDecorator_BlueprintBase.ReceiveObserverActivatedAI"));

	BTDecorator_BlueprintBase_ReceiveObserverActivatedAI_Params params;
	params.OwnerController_69 = OwnerController_69;
	params.ControlledPawn_69 = ControlledPawn_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AIModule.BTDecorator_BlueprintBase.ReceiveObserverActivated
// (Event, Protected, BlueprintEvent)
// Parameters:
// class Actor_32759*             OwnerActor_69                  (Parm, ZeroConstructor)

void BTDecorator_BlueprintBase::ReceiveObserverActivated(class Actor_32759* OwnerActor_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.BTDecorator_BlueprintBase.ReceiveObserverActivated"));

	BTDecorator_BlueprintBase_ReceiveObserverActivated_Params params;
	params.OwnerActor_69 = OwnerActor_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AIModule.BTDecorator_BlueprintBase.ReceiveExecutionStartAI
// (Event, Protected, BlueprintEvent)
// Parameters:
// class AIController*            OwnerController_69             (Parm, ZeroConstructor)
// class Pawn*                    ControlledPawn_69              (Parm, ZeroConstructor)

void BTDecorator_BlueprintBase::ReceiveExecutionStartAI(class AIController* OwnerController_69, class Pawn* ControlledPawn_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.BTDecorator_BlueprintBase.ReceiveExecutionStartAI"));

	BTDecorator_BlueprintBase_ReceiveExecutionStartAI_Params params;
	params.OwnerController_69 = OwnerController_69;
	params.ControlledPawn_69 = ControlledPawn_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AIModule.BTDecorator_BlueprintBase.ReceiveExecutionStart
// (Event, Protected, BlueprintEvent)
// Parameters:
// class Actor_32759*             OwnerActor_69                  (Parm, ZeroConstructor)

void BTDecorator_BlueprintBase::ReceiveExecutionStart(class Actor_32759* OwnerActor_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.BTDecorator_BlueprintBase.ReceiveExecutionStart"));

	BTDecorator_BlueprintBase_ReceiveExecutionStart_Params params;
	params.OwnerActor_69 = OwnerActor_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AIModule.BTDecorator_BlueprintBase.ReceiveExecutionFinishAI
// (Event, Protected, BlueprintEvent)
// Parameters:
// class AIController*            OwnerController_69             (Parm, ZeroConstructor)
// class Pawn*                    ControlledPawn_69              (Parm, ZeroConstructor)
// TEnumAsByte<EBTNodeResult>     NodeResult_69                  (Parm, ZeroConstructor, IsPlainOldData)

void BTDecorator_BlueprintBase::ReceiveExecutionFinishAI(class AIController* OwnerController_69, class Pawn* ControlledPawn_69, TEnumAsByte<EBTNodeResult> NodeResult_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.BTDecorator_BlueprintBase.ReceiveExecutionFinishAI"));

	BTDecorator_BlueprintBase_ReceiveExecutionFinishAI_Params params;
	params.OwnerController_69 = OwnerController_69;
	params.ControlledPawn_69 = ControlledPawn_69;
	params.NodeResult_69 = NodeResult_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AIModule.BTDecorator_BlueprintBase.ReceiveExecutionFinish
// (Event, Protected, BlueprintEvent)
// Parameters:
// class Actor_32759*             OwnerActor_69                  (Parm, ZeroConstructor)
// TEnumAsByte<EBTNodeResult>     NodeResult_69                  (Parm, ZeroConstructor, IsPlainOldData)

void BTDecorator_BlueprintBase::ReceiveExecutionFinish(class Actor_32759* OwnerActor_69, TEnumAsByte<EBTNodeResult> NodeResult_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.BTDecorator_BlueprintBase.ReceiveExecutionFinish"));

	BTDecorator_BlueprintBase_ReceiveExecutionFinish_Params params;
	params.OwnerActor_69 = OwnerActor_69;
	params.NodeResult_69 = NodeResult_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AIModule.BTDecorator_BlueprintBase.PerformConditionCheckAI
// (Event, Protected, BlueprintEvent)
// Parameters:
// class AIController*            OwnerController_69             (Parm, ZeroConstructor)
// class Pawn*                    ControlledPawn_69              (Parm, ZeroConstructor)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool BTDecorator_BlueprintBase::PerformConditionCheckAI(class AIController* OwnerController_69, class Pawn* ControlledPawn_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.BTDecorator_BlueprintBase.PerformConditionCheckAI"));

	BTDecorator_BlueprintBase_PerformConditionCheckAI_Params params;
	params.OwnerController_69 = OwnerController_69;
	params.ControlledPawn_69 = ControlledPawn_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AIModule.BTDecorator_BlueprintBase.PerformConditionCheck
// (Event, Protected, BlueprintEvent)
// Parameters:
// class Actor_32759*             OwnerActor_69                  (Parm, ZeroConstructor)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool BTDecorator_BlueprintBase::PerformConditionCheck(class Actor_32759* OwnerActor_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.BTDecorator_BlueprintBase.PerformConditionCheck"));

	BTDecorator_BlueprintBase_PerformConditionCheck_Params params;
	params.OwnerActor_69 = OwnerActor_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AIModule.BTDecorator_BlueprintBase.IsDecoratorObserverActive
// (Final, Native, Protected, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool BTDecorator_BlueprintBase::IsDecoratorObserverActive()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.BTDecorator_BlueprintBase.IsDecoratorObserverActive"));

	BTDecorator_BlueprintBase_IsDecoratorObserverActive_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AIModule.BTDecorator_BlueprintBase.IsDecoratorExecutionActive
// (Final, Native, Protected, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool BTDecorator_BlueprintBase::IsDecoratorExecutionActive()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.BTDecorator_BlueprintBase.IsDecoratorExecutionActive"));

	BTDecorator_BlueprintBase_IsDecoratorExecutionActive_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AIModule.BTService_BlueprintBase.ReceiveTickAI
// (Event, Protected, BlueprintEvent)
// Parameters:
// class AIController*            OwnerController_69             (Parm, ZeroConstructor)
// class Pawn*                    ControlledPawn_69              (Parm, ZeroConstructor)
// float                          DeltaSeconds_69                (Parm, ZeroConstructor, IsPlainOldData)

void BTService_BlueprintBase::ReceiveTickAI(class AIController* OwnerController_69, class Pawn* ControlledPawn_69, float DeltaSeconds_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.BTService_BlueprintBase.ReceiveTickAI"));

	BTService_BlueprintBase_ReceiveTickAI_Params params;
	params.OwnerController_69 = OwnerController_69;
	params.ControlledPawn_69 = ControlledPawn_69;
	params.DeltaSeconds_69 = DeltaSeconds_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AIModule.BTService_BlueprintBase.ReceiveTick
// (Event, Protected, BlueprintEvent)
// Parameters:
// class Actor_32759*             OwnerActor_69                  (Parm, ZeroConstructor)
// float                          DeltaSeconds_69                (Parm, ZeroConstructor, IsPlainOldData)

void BTService_BlueprintBase::ReceiveTick(class Actor_32759* OwnerActor_69, float DeltaSeconds_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.BTService_BlueprintBase.ReceiveTick"));

	BTService_BlueprintBase_ReceiveTick_Params params;
	params.OwnerActor_69 = OwnerActor_69;
	params.DeltaSeconds_69 = DeltaSeconds_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AIModule.BTService_BlueprintBase.ReceiveSearchStartAI
// (Event, Protected, BlueprintEvent)
// Parameters:
// class AIController*            OwnerController_69             (Parm, ZeroConstructor)
// class Pawn*                    ControlledPawn_69              (Parm, ZeroConstructor)

void BTService_BlueprintBase::ReceiveSearchStartAI(class AIController* OwnerController_69, class Pawn* ControlledPawn_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.BTService_BlueprintBase.ReceiveSearchStartAI"));

	BTService_BlueprintBase_ReceiveSearchStartAI_Params params;
	params.OwnerController_69 = OwnerController_69;
	params.ControlledPawn_69 = ControlledPawn_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AIModule.BTService_BlueprintBase.ReceiveSearchStart
// (Event, Protected, BlueprintEvent)
// Parameters:
// class Actor_32759*             OwnerActor_69                  (Parm, ZeroConstructor)

void BTService_BlueprintBase::ReceiveSearchStart(class Actor_32759* OwnerActor_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.BTService_BlueprintBase.ReceiveSearchStart"));

	BTService_BlueprintBase_ReceiveSearchStart_Params params;
	params.OwnerActor_69 = OwnerActor_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AIModule.BTService_BlueprintBase.ReceiveDeactivationAI
// (Event, Protected, BlueprintEvent)
// Parameters:
// class AIController*            OwnerController_69             (Parm, ZeroConstructor)
// class Pawn*                    ControlledPawn_69              (Parm, ZeroConstructor)

void BTService_BlueprintBase::ReceiveDeactivationAI(class AIController* OwnerController_69, class Pawn* ControlledPawn_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.BTService_BlueprintBase.ReceiveDeactivationAI"));

	BTService_BlueprintBase_ReceiveDeactivationAI_Params params;
	params.OwnerController_69 = OwnerController_69;
	params.ControlledPawn_69 = ControlledPawn_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AIModule.BTService_BlueprintBase.ReceiveDeactivation
// (Event, Protected, BlueprintEvent)
// Parameters:
// class Actor_32759*             OwnerActor_69                  (Parm, ZeroConstructor)

void BTService_BlueprintBase::ReceiveDeactivation(class Actor_32759* OwnerActor_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.BTService_BlueprintBase.ReceiveDeactivation"));

	BTService_BlueprintBase_ReceiveDeactivation_Params params;
	params.OwnerActor_69 = OwnerActor_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AIModule.BTService_BlueprintBase.ReceiveActivationAI
// (Event, Protected, BlueprintEvent)
// Parameters:
// class AIController*            OwnerController_69             (Parm, ZeroConstructor)
// class Pawn*                    ControlledPawn_69              (Parm, ZeroConstructor)

void BTService_BlueprintBase::ReceiveActivationAI(class AIController* OwnerController_69, class Pawn* ControlledPawn_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.BTService_BlueprintBase.ReceiveActivationAI"));

	BTService_BlueprintBase_ReceiveActivationAI_Params params;
	params.OwnerController_69 = OwnerController_69;
	params.ControlledPawn_69 = ControlledPawn_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AIModule.BTService_BlueprintBase.ReceiveActivation
// (Event, Protected, BlueprintEvent)
// Parameters:
// class Actor_32759*             OwnerActor_69                  (Parm, ZeroConstructor)

void BTService_BlueprintBase::ReceiveActivation(class Actor_32759* OwnerActor_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.BTService_BlueprintBase.ReceiveActivation"));

	BTService_BlueprintBase_ReceiveActivation_Params params;
	params.OwnerActor_69 = OwnerActor_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AIModule.BTService_BlueprintBase.IsServiceActive
// (Final, Native, Protected, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool BTService_BlueprintBase::IsServiceActive()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.BTService_BlueprintBase.IsServiceActive"));

	BTService_BlueprintBase_IsServiceActive_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AIModule.BTTask_BlueprintBase.SetFinishOnMessageWithId
// (Final, Native, Protected, BlueprintCallable)
// Parameters:
// struct FName                   MessageName_69                 (Parm, ZeroConstructor, IsPlainOldData)
// int                            RequestId_69                   (Parm, ZeroConstructor, IsPlainOldData)

void BTTask_BlueprintBase::SetFinishOnMessageWithId(const struct FName& MessageName_69, int RequestId_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.BTTask_BlueprintBase.SetFinishOnMessageWithId"));

	BTTask_BlueprintBase_SetFinishOnMessageWithId_Params params;
	params.MessageName_69 = MessageName_69;
	params.RequestId_69 = RequestId_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AIModule.BTTask_BlueprintBase.SetFinishOnMessage
// (Final, Native, Protected, BlueprintCallable)
// Parameters:
// struct FName                   MessageName_69                 (Parm, ZeroConstructor, IsPlainOldData)

void BTTask_BlueprintBase::SetFinishOnMessage(const struct FName& MessageName_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.BTTask_BlueprintBase.SetFinishOnMessage"));

	BTTask_BlueprintBase_SetFinishOnMessage_Params params;
	params.MessageName_69 = MessageName_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AIModule.BTTask_BlueprintBase.ReceiveTickAI
// (Event, Protected, BlueprintEvent)
// Parameters:
// class AIController*            OwnerController_69             (Parm, ZeroConstructor)
// class Pawn*                    ControlledPawn_69              (Parm, ZeroConstructor)
// float                          DeltaSeconds_69                (Parm, ZeroConstructor, IsPlainOldData)

void BTTask_BlueprintBase::ReceiveTickAI(class AIController* OwnerController_69, class Pawn* ControlledPawn_69, float DeltaSeconds_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.BTTask_BlueprintBase.ReceiveTickAI"));

	BTTask_BlueprintBase_ReceiveTickAI_Params params;
	params.OwnerController_69 = OwnerController_69;
	params.ControlledPawn_69 = ControlledPawn_69;
	params.DeltaSeconds_69 = DeltaSeconds_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AIModule.BTTask_BlueprintBase.ReceiveTick
// (Event, Protected, BlueprintEvent)
// Parameters:
// class Actor_32759*             OwnerActor_69                  (Parm, ZeroConstructor)
// float                          DeltaSeconds_69                (Parm, ZeroConstructor, IsPlainOldData)

void BTTask_BlueprintBase::ReceiveTick(class Actor_32759* OwnerActor_69, float DeltaSeconds_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.BTTask_BlueprintBase.ReceiveTick"));

	BTTask_BlueprintBase_ReceiveTick_Params params;
	params.OwnerActor_69 = OwnerActor_69;
	params.DeltaSeconds_69 = DeltaSeconds_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AIModule.BTTask_BlueprintBase.ReceiveExecuteAI
// (Event, Protected, BlueprintEvent)
// Parameters:
// class AIController*            OwnerController_69             (Parm, ZeroConstructor)
// class Pawn*                    ControlledPawn_69              (Parm, ZeroConstructor)

void BTTask_BlueprintBase::ReceiveExecuteAI(class AIController* OwnerController_69, class Pawn* ControlledPawn_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.BTTask_BlueprintBase.ReceiveExecuteAI"));

	BTTask_BlueprintBase_ReceiveExecuteAI_Params params;
	params.OwnerController_69 = OwnerController_69;
	params.ControlledPawn_69 = ControlledPawn_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AIModule.BTTask_BlueprintBase.ReceiveExecute
// (Event, Protected, BlueprintEvent)
// Parameters:
// class Actor_32759*             OwnerActor_69                  (Parm, ZeroConstructor)

void BTTask_BlueprintBase::ReceiveExecute(class Actor_32759* OwnerActor_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.BTTask_BlueprintBase.ReceiveExecute"));

	BTTask_BlueprintBase_ReceiveExecute_Params params;
	params.OwnerActor_69 = OwnerActor_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AIModule.BTTask_BlueprintBase.ReceiveAbortAI
// (Event, Protected, BlueprintEvent)
// Parameters:
// class AIController*            OwnerController_69             (Parm, ZeroConstructor)
// class Pawn*                    ControlledPawn_69              (Parm, ZeroConstructor)

void BTTask_BlueprintBase::ReceiveAbortAI(class AIController* OwnerController_69, class Pawn* ControlledPawn_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.BTTask_BlueprintBase.ReceiveAbortAI"));

	BTTask_BlueprintBase_ReceiveAbortAI_Params params;
	params.OwnerController_69 = OwnerController_69;
	params.ControlledPawn_69 = ControlledPawn_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AIModule.BTTask_BlueprintBase.ReceiveAbort
// (Event, Protected, BlueprintEvent)
// Parameters:
// class Actor_32759*             OwnerActor_69                  (Parm, ZeroConstructor)

void BTTask_BlueprintBase::ReceiveAbort(class Actor_32759* OwnerActor_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.BTTask_BlueprintBase.ReceiveAbort"));

	BTTask_BlueprintBase_ReceiveAbort_Params params;
	params.OwnerActor_69 = OwnerActor_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AIModule.BTTask_BlueprintBase.IsTaskExecuting
// (Final, Native, Protected, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool BTTask_BlueprintBase::IsTaskExecuting()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.BTTask_BlueprintBase.IsTaskExecuting"));

	BTTask_BlueprintBase_IsTaskExecuting_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AIModule.BTTask_BlueprintBase.IsTaskAborting
// (Final, Native, Protected, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool BTTask_BlueprintBase::IsTaskAborting()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.BTTask_BlueprintBase.IsTaskAborting"));

	BTTask_BlueprintBase_IsTaskAborting_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AIModule.BTTask_BlueprintBase.FinishExecute
// (Final, Native, Protected, BlueprintCallable)
// Parameters:
// bool                           bSuccess_69                    (Parm, ZeroConstructor, IsPlainOldData)

void BTTask_BlueprintBase::FinishExecute(bool bSuccess_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.BTTask_BlueprintBase.FinishExecute"));

	BTTask_BlueprintBase_FinishExecute_Params params;
	params.bSuccess_69 = bSuccess_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AIModule.BTTask_BlueprintBase.FinishAbort
// (Final, Native, Protected, BlueprintCallable)

void BTTask_BlueprintBase::FinishAbort()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.BTTask_BlueprintBase.FinishAbort"));

	BTTask_BlueprintBase_FinishAbort_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AIModule.AIBlueprintHelperLibrary.UnlockAIResourcesWithAnimation
// (Final, BlueprintAuthorityOnly, Native, Static, Public, BlueprintCallable)
// Parameters:
// class AnimInstance*            AnimInstance_69                (Parm, ZeroConstructor)
// bool                           bUnlockMovement_69             (Parm, ZeroConstructor, IsPlainOldData)
// bool                           UnlockAILogic_69               (Parm, ZeroConstructor, IsPlainOldData)

void AIBlueprintHelperLibrary::STATIC_UnlockAIResourcesWithAnimation(class AnimInstance* AnimInstance_69, bool bUnlockMovement_69, bool UnlockAILogic_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.AIBlueprintHelperLibrary.UnlockAIResourcesWithAnimation"));

	AIBlueprintHelperLibrary_UnlockAIResourcesWithAnimation_Params params;
	params.AnimInstance_69 = AnimInstance_69;
	params.bUnlockMovement_69 = bUnlockMovement_69;
	params.UnlockAILogic_69 = UnlockAILogic_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AIModule.AIBlueprintHelperLibrary.SpawnAIFromClass
// (Final, Native, Static, Public, HasDefaults, BlueprintCallable)
// Parameters:
// class Object_32759*            WorldContextObject_69          (Parm, ZeroConstructor)
// class Pawn*                    PawnClass_69                   (Parm, ZeroConstructor)
// class BehaviorTree*            BehaviorTree_69                (Parm, ZeroConstructor)
// struct FVector                 Location_69                    (Parm, ZeroConstructor, IsPlainOldData)
// struct FRotator                Rotation_69                    (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bNoCollisionFail_69            (Parm, ZeroConstructor, IsPlainOldData)
// class Actor_32759*             Owner_69                       (Parm, ZeroConstructor)
// class Pawn*                    ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

class Pawn* AIBlueprintHelperLibrary::STATIC_SpawnAIFromClass(class Object_32759* WorldContextObject_69, class Pawn* PawnClass_69, class BehaviorTree* BehaviorTree_69, const struct FVector& Location_69, const struct FRotator& Rotation_69, bool bNoCollisionFail_69, class Actor_32759* Owner_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.AIBlueprintHelperLibrary.SpawnAIFromClass"));

	AIBlueprintHelperLibrary_SpawnAIFromClass_Params params;
	params.WorldContextObject_69 = WorldContextObject_69;
	params.PawnClass_69 = PawnClass_69;
	params.BehaviorTree_69 = BehaviorTree_69;
	params.Location_69 = Location_69;
	params.Rotation_69 = Rotation_69;
	params.bNoCollisionFail_69 = bNoCollisionFail_69;
	params.Owner_69 = Owner_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AIModule.AIBlueprintHelperLibrary.SimpleMoveToLocation
// (Final, Native, Static, Public, HasOutParms, HasDefaults, BlueprintCallable)
// Parameters:
// class Controller*              Controller_69                  (Parm, ZeroConstructor)
// struct FVector                 Goal_69                        (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)

void AIBlueprintHelperLibrary::STATIC_SimpleMoveToLocation(class Controller* Controller_69, const struct FVector& Goal_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.AIBlueprintHelperLibrary.SimpleMoveToLocation"));

	AIBlueprintHelperLibrary_SimpleMoveToLocation_Params params;
	params.Controller_69 = Controller_69;
	params.Goal_69 = Goal_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AIModule.AIBlueprintHelperLibrary.SimpleMoveToActor
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// class Controller*              Controller_69                  (Parm, ZeroConstructor)
// class Actor_32759*             Goal_69                        (ConstParm, Parm, ZeroConstructor)

void AIBlueprintHelperLibrary::STATIC_SimpleMoveToActor(class Controller* Controller_69, class Actor_32759* Goal_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.AIBlueprintHelperLibrary.SimpleMoveToActor"));

	AIBlueprintHelperLibrary_SimpleMoveToActor_Params params;
	params.Controller_69 = Controller_69;
	params.Goal_69 = Goal_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AIModule.AIBlueprintHelperLibrary.SendAIMessage
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// class Pawn*                    Target_69                      (Parm, ZeroConstructor)
// struct FName                   message_69                     (Parm, ZeroConstructor, IsPlainOldData)
// class Object_32759*            MessageSource_69               (Parm, ZeroConstructor)
// bool                           bSuccess_69                    (Parm, ZeroConstructor, IsPlainOldData)

void AIBlueprintHelperLibrary::STATIC_SendAIMessage(class Pawn* Target_69, const struct FName& message_69, class Object_32759* MessageSource_69, bool bSuccess_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.AIBlueprintHelperLibrary.SendAIMessage"));

	AIBlueprintHelperLibrary_SendAIMessage_Params params;
	params.Target_69 = Target_69;
	params.message_69 = message_69;
	params.MessageSource_69 = MessageSource_69;
	params.bSuccess_69 = bSuccess_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AIModule.AIBlueprintHelperLibrary.LockAIResourcesWithAnimation
// (Final, BlueprintAuthorityOnly, Native, Static, Public, BlueprintCallable)
// Parameters:
// class AnimInstance*            AnimInstance_69                (Parm, ZeroConstructor)
// bool                           bLockMovement_69               (Parm, ZeroConstructor, IsPlainOldData)
// bool                           LockAILogic_69                 (Parm, ZeroConstructor, IsPlainOldData)

void AIBlueprintHelperLibrary::STATIC_LockAIResourcesWithAnimation(class AnimInstance* AnimInstance_69, bool bLockMovement_69, bool LockAILogic_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.AIBlueprintHelperLibrary.LockAIResourcesWithAnimation"));

	AIBlueprintHelperLibrary_LockAIResourcesWithAnimation_Params params;
	params.AnimInstance_69 = AnimInstance_69;
	params.bLockMovement_69 = bLockMovement_69;
	params.LockAILogic_69 = LockAILogic_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AIModule.AIBlueprintHelperLibrary.IsValidAIRotation
// (Final, Native, Static, Public, HasDefaults, BlueprintCallable, BlueprintPure)
// Parameters:
// struct FRotator                Rotation_69                    (Parm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool AIBlueprintHelperLibrary::STATIC_IsValidAIRotation(const struct FRotator& Rotation_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.AIBlueprintHelperLibrary.IsValidAIRotation"));

	AIBlueprintHelperLibrary_IsValidAIRotation_Params params;
	params.Rotation_69 = Rotation_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AIModule.AIBlueprintHelperLibrary.IsValidAILocation
// (Final, Native, Static, Public, HasDefaults, BlueprintCallable, BlueprintPure)
// Parameters:
// struct FVector                 Location_69                    (Parm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool AIBlueprintHelperLibrary::STATIC_IsValidAILocation(const struct FVector& Location_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.AIBlueprintHelperLibrary.IsValidAILocation"));

	AIBlueprintHelperLibrary_IsValidAILocation_Params params;
	params.Location_69 = Location_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AIModule.AIBlueprintHelperLibrary.IsValidAIDirection
// (Final, Native, Static, Public, HasDefaults, BlueprintCallable, BlueprintPure)
// Parameters:
// struct FVector                 DirectionVector_69             (Parm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool AIBlueprintHelperLibrary::STATIC_IsValidAIDirection(const struct FVector& DirectionVector_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.AIBlueprintHelperLibrary.IsValidAIDirection"));

	AIBlueprintHelperLibrary_IsValidAIDirection_Params params;
	params.DirectionVector_69 = DirectionVector_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AIModule.AIBlueprintHelperLibrary.GetNextNavLinkIndex
// (Final, Native, Static, Public, BlueprintCallable, BlueprintPure)
// Parameters:
// class Controller*              Controller_69                  (ConstParm, Parm, ZeroConstructor)
// int                            ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int AIBlueprintHelperLibrary::STATIC_GetNextNavLinkIndex(class Controller* Controller_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.AIBlueprintHelperLibrary.GetNextNavLinkIndex"));

	AIBlueprintHelperLibrary_GetNextNavLinkIndex_Params params;
	params.Controller_69 = Controller_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AIModule.AIBlueprintHelperLibrary.GetCurrentPathPoints
// (Final, Native, Static, Public, BlueprintCallable, BlueprintPure)
// Parameters:
// class Controller*              Controller_69                  (Parm, ZeroConstructor)
// TArray<struct FVector>         ReturnValue_69                 (ConstParm, Parm, OutParm, ZeroConstructor, ReturnParm)

TArray<struct FVector> AIBlueprintHelperLibrary::STATIC_GetCurrentPathPoints(class Controller* Controller_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.AIBlueprintHelperLibrary.GetCurrentPathPoints"));

	AIBlueprintHelperLibrary_GetCurrentPathPoints_Params params;
	params.Controller_69 = Controller_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AIModule.AIBlueprintHelperLibrary.GetCurrentPathIndex
// (Final, Native, Static, Public, BlueprintCallable, BlueprintPure)
// Parameters:
// class Controller*              Controller_69                  (ConstParm, Parm, ZeroConstructor)
// int                            ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int AIBlueprintHelperLibrary::STATIC_GetCurrentPathIndex(class Controller* Controller_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.AIBlueprintHelperLibrary.GetCurrentPathIndex"));

	AIBlueprintHelperLibrary_GetCurrentPathIndex_Params params;
	params.Controller_69 = Controller_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AIModule.AIBlueprintHelperLibrary.GetCurrentPath
// (Final, Native, Static, Public, BlueprintCallable, BlueprintPure)
// Parameters:
// class Controller*              Controller_69                  (Parm, ZeroConstructor)
// class NavigationPath*          ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

class NavigationPath* AIBlueprintHelperLibrary::STATIC_GetCurrentPath(class Controller* Controller_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.AIBlueprintHelperLibrary.GetCurrentPath"));

	AIBlueprintHelperLibrary_GetCurrentPath_Params params;
	params.Controller_69 = Controller_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AIModule.AIBlueprintHelperLibrary.GetBlackboard
// (Final, Native, Static, Public, BlueprintCallable, BlueprintPure)
// Parameters:
// class Actor_32759*             Target_69                      (Parm, ZeroConstructor)
// class BlackboardComponent*     ReturnValue_69                 (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)

class BlackboardComponent* AIBlueprintHelperLibrary::STATIC_GetBlackboard(class Actor_32759* Target_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.AIBlueprintHelperLibrary.GetBlackboard"));

	AIBlueprintHelperLibrary_GetBlackboard_Params params;
	params.Target_69 = Target_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AIModule.AIBlueprintHelperLibrary.GetAIController
// (Final, Native, Static, Public, BlueprintCallable, BlueprintPure)
// Parameters:
// class Actor_32759*             ControlledActor_69             (Parm, ZeroConstructor)
// class AIController*            ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

class AIController* AIBlueprintHelperLibrary::STATIC_GetAIController(class Actor_32759* ControlledActor_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.AIBlueprintHelperLibrary.GetAIController"));

	AIBlueprintHelperLibrary_GetAIController_Params params;
	params.ControlledActor_69 = ControlledActor_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AIModule.AIBlueprintHelperLibrary.CreateMoveToProxyObject
// (Final, Native, Static, Public, HasDefaults, BlueprintCallable)
// Parameters:
// class Object_32759*            WorldContextObject_69          (Parm, ZeroConstructor)
// class Pawn*                    Pawn_69                        (Parm, ZeroConstructor)
// struct FVector                 Destination_69                 (Parm, ZeroConstructor, IsPlainOldData)
// class Actor_32759*             TargetActor_69                 (Parm, ZeroConstructor)
// float                          AcceptanceRadius_69            (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bStopOnOverlap_69              (Parm, ZeroConstructor, IsPlainOldData)
// class AIAsyncTaskBlueprintProxy* ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

class AIAsyncTaskBlueprintProxy* AIBlueprintHelperLibrary::STATIC_CreateMoveToProxyObject(class Object_32759* WorldContextObject_69, class Pawn* Pawn_69, const struct FVector& Destination_69, class Actor_32759* TargetActor_69, float AcceptanceRadius_69, bool bStopOnOverlap_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.AIBlueprintHelperLibrary.CreateMoveToProxyObject"));

	AIBlueprintHelperLibrary_CreateMoveToProxyObject_Params params;
	params.WorldContextObject_69 = WorldContextObject_69;
	params.Pawn_69 = Pawn_69;
	params.Destination_69 = Destination_69;
	params.TargetActor_69 = TargetActor_69;
	params.AcceptanceRadius_69 = AcceptanceRadius_69;
	params.bStopOnOverlap_69 = bStopOnOverlap_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AIModule.EnvQueryContext_BlueprintBase.ProvideSingleLocation
// (Event, Public, HasOutParms, HasDefaults, BlueprintEvent, Const)
// Parameters:
// class Object_32759*            QuerierObject_69               (Parm, ZeroConstructor)
// class Actor_32759*             QuerierActor_69                (Parm, ZeroConstructor)
// struct FVector                 ResultingLocation_69           (Parm, OutParm, ZeroConstructor, IsPlainOldData)

void EnvQueryContext_BlueprintBase::ProvideSingleLocation(class Object_32759* QuerierObject_69, class Actor_32759* QuerierActor_69, struct FVector* ResultingLocation_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.EnvQueryContext_BlueprintBase.ProvideSingleLocation"));

	EnvQueryContext_BlueprintBase_ProvideSingleLocation_Params params;
	params.QuerierObject_69 = QuerierObject_69;
	params.QuerierActor_69 = QuerierActor_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (ResultingLocation_69 != nullptr)
		*ResultingLocation_69 = params.ResultingLocation_69;
}


// Function AIModule.EnvQueryContext_BlueprintBase.ProvideSingleActor
// (Event, Public, HasOutParms, BlueprintEvent, Const)
// Parameters:
// class Object_32759*            QuerierObject_69               (Parm, ZeroConstructor)
// class Actor_32759*             QuerierActor_69                (Parm, ZeroConstructor)
// class Actor_32759*             ResultingActor_69              (Parm, OutParm, ZeroConstructor)

void EnvQueryContext_BlueprintBase::ProvideSingleActor(class Object_32759* QuerierObject_69, class Actor_32759* QuerierActor_69, class Actor_32759** ResultingActor_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.EnvQueryContext_BlueprintBase.ProvideSingleActor"));

	EnvQueryContext_BlueprintBase_ProvideSingleActor_Params params;
	params.QuerierObject_69 = QuerierObject_69;
	params.QuerierActor_69 = QuerierActor_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (ResultingActor_69 != nullptr)
		*ResultingActor_69 = params.ResultingActor_69;
}


// Function AIModule.EnvQueryContext_BlueprintBase.ProvideLocationsSet
// (Event, Public, HasOutParms, BlueprintEvent, Const)
// Parameters:
// class Object_32759*            QuerierObject_69               (Parm, ZeroConstructor)
// class Actor_32759*             QuerierActor_69                (Parm, ZeroConstructor)
// TArray<struct FVector>         ResultingLocationSet_69        (Parm, OutParm, ZeroConstructor)

void EnvQueryContext_BlueprintBase::ProvideLocationsSet(class Object_32759* QuerierObject_69, class Actor_32759* QuerierActor_69, TArray<struct FVector>* ResultingLocationSet_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.EnvQueryContext_BlueprintBase.ProvideLocationsSet"));

	EnvQueryContext_BlueprintBase_ProvideLocationsSet_Params params;
	params.QuerierObject_69 = QuerierObject_69;
	params.QuerierActor_69 = QuerierActor_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (ResultingLocationSet_69 != nullptr)
		*ResultingLocationSet_69 = params.ResultingLocationSet_69;
}


// Function AIModule.EnvQueryContext_BlueprintBase.ProvideActorsSet
// (Event, Public, HasOutParms, BlueprintEvent, Const)
// Parameters:
// class Object_32759*            QuerierObject_69               (Parm, ZeroConstructor)
// class Actor_32759*             QuerierActor_69                (Parm, ZeroConstructor)
// TArray<class Actor_32759*>     ResultingActorsSet_69          (Parm, OutParm, ZeroConstructor)

void EnvQueryContext_BlueprintBase::ProvideActorsSet(class Object_32759* QuerierObject_69, class Actor_32759* QuerierActor_69, TArray<class Actor_32759*>* ResultingActorsSet_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.EnvQueryContext_BlueprintBase.ProvideActorsSet"));

	EnvQueryContext_BlueprintBase_ProvideActorsSet_Params params;
	params.QuerierObject_69 = QuerierObject_69;
	params.QuerierActor_69 = QuerierActor_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (ResultingActorsSet_69 != nullptr)
		*ResultingActorsSet_69 = params.ResultingActorsSet_69;
}


// Function AIModule.EnvQueryInstanceBlueprintWrapper.SetNamedParam
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// struct FName                   ParamName_69                   (Parm, ZeroConstructor, IsPlainOldData)
// float                          Value_69                       (Parm, ZeroConstructor, IsPlainOldData)

void EnvQueryInstanceBlueprintWrapper::SetNamedParam(const struct FName& ParamName_69, float Value_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.EnvQueryInstanceBlueprintWrapper.SetNamedParam"));

	EnvQueryInstanceBlueprintWrapper_SetNamedParam_Params params;
	params.ParamName_69 = ParamName_69;
	params.Value_69 = Value_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AIModule.EnvQueryInstanceBlueprintWrapper.GetResultsAsLocations
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// TArray<struct FVector>         ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

TArray<struct FVector> EnvQueryInstanceBlueprintWrapper::GetResultsAsLocations()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.EnvQueryInstanceBlueprintWrapper.GetResultsAsLocations"));

	EnvQueryInstanceBlueprintWrapper_GetResultsAsLocations_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AIModule.EnvQueryInstanceBlueprintWrapper.GetResultsAsActors
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// TArray<class Actor_32759*>     ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

TArray<class Actor_32759*> EnvQueryInstanceBlueprintWrapper::GetResultsAsActors()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.EnvQueryInstanceBlueprintWrapper.GetResultsAsActors"));

	EnvQueryInstanceBlueprintWrapper_GetResultsAsActors_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AIModule.EnvQueryInstanceBlueprintWrapper.GetQueryResultsAsLocations
// (Final, Native, Public, HasOutParms, BlueprintCallable, Const)
// Parameters:
// TArray<struct FVector>         ResultLocations_69             (Parm, OutParm, ZeroConstructor)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool EnvQueryInstanceBlueprintWrapper::GetQueryResultsAsLocations(TArray<struct FVector>* ResultLocations_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.EnvQueryInstanceBlueprintWrapper.GetQueryResultsAsLocations"));

	EnvQueryInstanceBlueprintWrapper_GetQueryResultsAsLocations_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (ResultLocations_69 != nullptr)
		*ResultLocations_69 = params.ResultLocations_69;

	return params.ReturnValue_69;
}


// Function AIModule.EnvQueryInstanceBlueprintWrapper.GetQueryResultsAsActors
// (Final, Native, Public, HasOutParms, BlueprintCallable, Const)
// Parameters:
// TArray<class Actor_32759*>     ResultActors_69                (Parm, OutParm, ZeroConstructor)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool EnvQueryInstanceBlueprintWrapper::GetQueryResultsAsActors(TArray<class Actor_32759*>* ResultActors_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.EnvQueryInstanceBlueprintWrapper.GetQueryResultsAsActors"));

	EnvQueryInstanceBlueprintWrapper_GetQueryResultsAsActors_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (ResultActors_69 != nullptr)
		*ResultActors_69 = params.ResultActors_69;

	return params.ReturnValue_69;
}


// Function AIModule.EnvQueryInstanceBlueprintWrapper.GetItemScore
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// int                            ItemIndex_69                   (Parm, ZeroConstructor, IsPlainOldData)
// float                          ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

float EnvQueryInstanceBlueprintWrapper::GetItemScore(int ItemIndex_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.EnvQueryInstanceBlueprintWrapper.GetItemScore"));

	EnvQueryInstanceBlueprintWrapper_GetItemScore_Params params;
	params.ItemIndex_69 = ItemIndex_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// DelegateFunction AIModule.EnvQueryInstanceBlueprintWrapper.EQSQueryDoneSignature__DelegateSignature
// (MulticastDelegate, Public, Delegate)
// Parameters:
// class EnvQueryInstanceBlueprintWrapper* QueryInstance_69               (Parm, ZeroConstructor)
// TEnumAsByte<EEnvQueryStatus>   QueryStatus_69                 (Parm, ZeroConstructor, IsPlainOldData)

void EnvQueryInstanceBlueprintWrapper::EQSQueryDoneSignature__DelegateSignature(class EnvQueryInstanceBlueprintWrapper* QueryInstance_69, TEnumAsByte<EEnvQueryStatus> QueryStatus_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("DelegateFunction AIModule.EnvQueryInstanceBlueprintWrapper.EQSQueryDoneSignature__DelegateSignature"));

	EnvQueryInstanceBlueprintWrapper_EQSQueryDoneSignature__DelegateSignature_Params params;
	params.QueryInstance_69 = QueryInstance_69;
	params.QueryStatus_69 = QueryStatus_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AIModule.EnvQueryManager.RunEQSQuery
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// class Object_32759*            WorldContextObject_69          (Parm, ZeroConstructor)
// class EnvQuery*                QueryTemplate_69               (Parm, ZeroConstructor)
// class Object_32759*            Querier_69                     (Parm, ZeroConstructor)
// TEnumAsByte<EEnvQueryRunMode>  RunMode_69                     (Parm, ZeroConstructor, IsPlainOldData)
// class EnvQueryInstanceBlueprintWrapper* WrapperClass_69                (Parm, ZeroConstructor)
// class EnvQueryInstanceBlueprintWrapper* ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

class EnvQueryInstanceBlueprintWrapper* EnvQueryManager::STATIC_RunEQSQuery(class Object_32759* WorldContextObject_69, class EnvQuery* QueryTemplate_69, class Object_32759* Querier_69, TEnumAsByte<EEnvQueryRunMode> RunMode_69, class EnvQueryInstanceBlueprintWrapper* WrapperClass_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.EnvQueryManager.RunEQSQuery"));

	EnvQueryManager_RunEQSQuery_Params params;
	params.WorldContextObject_69 = WorldContextObject_69;
	params.QueryTemplate_69 = QueryTemplate_69;
	params.Querier_69 = Querier_69;
	params.RunMode_69 = RunMode_69;
	params.WrapperClass_69 = WrapperClass_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AIModule.EnvQueryGenerator_BlueprintBase.GetQuerier
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// class Object_32759*            ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

class Object_32759* EnvQueryGenerator_BlueprintBase::GetQuerier()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.EnvQueryGenerator_BlueprintBase.GetQuerier"));

	EnvQueryGenerator_BlueprintBase_GetQuerier_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AIModule.EnvQueryGenerator_BlueprintBase.DoItemGenerationFromActors
// (Event, Public, HasOutParms, BlueprintEvent, Const)
// Parameters:
// TArray<class Actor_32759*>     ContextActors_69               (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)

void EnvQueryGenerator_BlueprintBase::DoItemGenerationFromActors(TArray<class Actor_32759*> ContextActors_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.EnvQueryGenerator_BlueprintBase.DoItemGenerationFromActors"));

	EnvQueryGenerator_BlueprintBase_DoItemGenerationFromActors_Params params;
	params.ContextActors_69 = ContextActors_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AIModule.EnvQueryGenerator_BlueprintBase.DoItemGeneration
// (Event, Public, HasOutParms, BlueprintEvent, Const)
// Parameters:
// TArray<struct FVector>         ContextLocations_69            (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)

void EnvQueryGenerator_BlueprintBase::DoItemGeneration(TArray<struct FVector> ContextLocations_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.EnvQueryGenerator_BlueprintBase.DoItemGeneration"));

	EnvQueryGenerator_BlueprintBase_DoItemGeneration_Params params;
	params.ContextLocations_69 = ContextLocations_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AIModule.EnvQueryGenerator_BlueprintBase.AddGeneratedVector
// (Final, Native, Public, HasDefaults, BlueprintCallable, Const)
// Parameters:
// struct FVector                 GeneratedVector_69             (Parm, ZeroConstructor, IsPlainOldData)

void EnvQueryGenerator_BlueprintBase::AddGeneratedVector(const struct FVector& GeneratedVector_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.EnvQueryGenerator_BlueprintBase.AddGeneratedVector"));

	EnvQueryGenerator_BlueprintBase_AddGeneratedVector_Params params;
	params.GeneratedVector_69 = GeneratedVector_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AIModule.EnvQueryGenerator_BlueprintBase.AddGeneratedActor
// (Final, Native, Public, BlueprintCallable, Const)
// Parameters:
// class Actor_32759*             GeneratedActor_69              (Parm, ZeroConstructor)

void EnvQueryGenerator_BlueprintBase::AddGeneratedActor(class Actor_32759* GeneratedActor_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.EnvQueryGenerator_BlueprintBase.AddGeneratedActor"));

	EnvQueryGenerator_BlueprintBase_AddGeneratedActor_Params params;
	params.GeneratedActor_69 = GeneratedActor_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AIModule.PathFollowingComponent.OnNavDataRegistered
// (Final, Native, Protected)
// Parameters:
// class NavigationData*          NavData_69                     (Parm, ZeroConstructor)

void PathFollowingComponent::OnNavDataRegistered(class NavigationData* NavData_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.PathFollowingComponent.OnNavDataRegistered"));

	PathFollowingComponent_OnNavDataRegistered_Params params;
	params.NavData_69 = NavData_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AIModule.PathFollowingComponent.OnActorBump
// (Native, Public, HasOutParms, HasDefaults)
// Parameters:
// class Actor_32759*             SelfActor_69                   (Parm, ZeroConstructor)
// class Actor_32759*             OtherActor_69                  (Parm, ZeroConstructor)
// struct FVector                 NormalImpulse_69               (Parm, ZeroConstructor, IsPlainOldData)
// struct FHitResult              Hit_69                         (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)

void PathFollowingComponent::OnActorBump(class Actor_32759* SelfActor_69, class Actor_32759* OtherActor_69, const struct FVector& NormalImpulse_69, const struct FHitResult& Hit_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.PathFollowingComponent.OnActorBump"));

	PathFollowingComponent_OnActorBump_Params params;
	params.SelfActor_69 = SelfActor_69;
	params.OtherActor_69 = OtherActor_69;
	params.NormalImpulse_69 = NormalImpulse_69;
	params.Hit_69 = Hit_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AIModule.PathFollowingComponent.GetPathDestination
// (Final, Native, Public, HasDefaults, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FVector                 ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

struct FVector PathFollowingComponent::GetPathDestination()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.PathFollowingComponent.GetPathDestination"));

	PathFollowingComponent_GetPathDestination_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AIModule.PathFollowingComponent.GetPathActionType
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// TEnumAsByte<EPathFollowingAction> ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

TEnumAsByte<EPathFollowingAction> PathFollowingComponent::GetPathActionType()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.PathFollowingComponent.GetPathActionType"));

	PathFollowingComponent_GetPathActionType_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AIModule.CrowdFollowingComponent.SuspendCrowdSteering
// (Native, Public, BlueprintCallable)
// Parameters:
// bool                           bSuspend_69                    (Parm, ZeroConstructor, IsPlainOldData)

void CrowdFollowingComponent::SuspendCrowdSteering(bool bSuspend_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.CrowdFollowingComponent.SuspendCrowdSteering"));

	CrowdFollowingComponent_SuspendCrowdSteering_Params params;
	params.bSuspend_69 = bSuspend_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AIModule.NavLinkProxy.SetSmartLinkEnabled
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// bool                           bEnabled_69                    (Parm, ZeroConstructor, IsPlainOldData)

void NavLinkProxy::SetSmartLinkEnabled(bool bEnabled_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.NavLinkProxy.SetSmartLinkEnabled"));

	NavLinkProxy_SetSmartLinkEnabled_Params params;
	params.bEnabled_69 = bEnabled_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AIModule.NavLinkProxy.ResumePathFollowing
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// class Actor_32759*             Agent_69                       (Parm, ZeroConstructor)

void NavLinkProxy::ResumePathFollowing(class Actor_32759* Agent_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.NavLinkProxy.ResumePathFollowing"));

	NavLinkProxy_ResumePathFollowing_Params params;
	params.Agent_69 = Agent_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AIModule.NavLinkProxy.ReceiveSmartLinkReached
// (Event, Public, HasOutParms, HasDefaults, BlueprintEvent)
// Parameters:
// class Actor_32759*             Agent_69                       (Parm, ZeroConstructor)
// struct FVector                 Destination_69                 (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)

void NavLinkProxy::ReceiveSmartLinkReached(class Actor_32759* Agent_69, const struct FVector& Destination_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.NavLinkProxy.ReceiveSmartLinkReached"));

	NavLinkProxy_ReceiveSmartLinkReached_Params params;
	params.Agent_69 = Agent_69;
	params.Destination_69 = Destination_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AIModule.NavLinkProxy.IsSmartLinkEnabled
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool NavLinkProxy::IsSmartLinkEnabled()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.NavLinkProxy.IsSmartLinkEnabled"));

	NavLinkProxy_IsSmartLinkEnabled_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AIModule.NavLinkProxy.HasMovingAgents
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool NavLinkProxy::HasMovingAgents()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.NavLinkProxy.HasMovingAgents"));

	NavLinkProxy_HasMovingAgents_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AIModule.NavLocalGridManager.SetLocalNavigationGridDensity
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// class Object_32759*            WorldContextObject_69          (Parm, ZeroConstructor)
// float                          CellSize_69                    (Parm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool NavLocalGridManager::STATIC_SetLocalNavigationGridDensity(class Object_32759* WorldContextObject_69, float CellSize_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.NavLocalGridManager.SetLocalNavigationGridDensity"));

	NavLocalGridManager_SetLocalNavigationGridDensity_Params params;
	params.WorldContextObject_69 = WorldContextObject_69;
	params.CellSize_69 = CellSize_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AIModule.NavLocalGridManager.RemoveLocalNavigationGrid
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// class Object_32759*            WorldContextObject_69          (Parm, ZeroConstructor)
// int                            GridId_69                      (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bRebuildGrids_69               (Parm, ZeroConstructor, IsPlainOldData)

void NavLocalGridManager::STATIC_RemoveLocalNavigationGrid(class Object_32759* WorldContextObject_69, int GridId_69, bool bRebuildGrids_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.NavLocalGridManager.RemoveLocalNavigationGrid"));

	NavLocalGridManager_RemoveLocalNavigationGrid_Params params;
	params.WorldContextObject_69 = WorldContextObject_69;
	params.GridId_69 = GridId_69;
	params.bRebuildGrids_69 = bRebuildGrids_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AIModule.NavLocalGridManager.FindLocalNavigationGridPath
// (Final, Native, Static, Public, HasOutParms, HasDefaults, BlueprintCallable)
// Parameters:
// class Object_32759*            WorldContextObject_69          (Parm, ZeroConstructor)
// struct FVector                 Start_69                       (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
// struct FVector                 End_69                         (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
// TArray<struct FVector>         PathPoints_69                  (Parm, OutParm, ZeroConstructor)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool NavLocalGridManager::STATIC_FindLocalNavigationGridPath(class Object_32759* WorldContextObject_69, const struct FVector& Start_69, const struct FVector& End_69, TArray<struct FVector>* PathPoints_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.NavLocalGridManager.FindLocalNavigationGridPath"));

	NavLocalGridManager_FindLocalNavigationGridPath_Params params;
	params.WorldContextObject_69 = WorldContextObject_69;
	params.Start_69 = Start_69;
	params.End_69 = End_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (PathPoints_69 != nullptr)
		*PathPoints_69 = params.PathPoints_69;

	return params.ReturnValue_69;
}


// Function AIModule.NavLocalGridManager.AddLocalNavigationGridForPoints
// (Final, Native, Static, Public, HasOutParms, BlueprintCallable)
// Parameters:
// class Object_32759*            WorldContextObject_69          (Parm, ZeroConstructor)
// TArray<struct FVector>         Locations_69                   (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
// int                            Radius2D_69                    (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// float                          Height_69                      (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// bool                           bRebuildGrids_69               (Parm, ZeroConstructor, IsPlainOldData)
// int                            ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int NavLocalGridManager::STATIC_AddLocalNavigationGridForPoints(class Object_32759* WorldContextObject_69, TArray<struct FVector> Locations_69, int Radius2D_69, float Height_69, bool bRebuildGrids_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.NavLocalGridManager.AddLocalNavigationGridForPoints"));

	NavLocalGridManager_AddLocalNavigationGridForPoints_Params params;
	params.WorldContextObject_69 = WorldContextObject_69;
	params.Locations_69 = Locations_69;
	params.Radius2D_69 = Radius2D_69;
	params.Height_69 = Height_69;
	params.bRebuildGrids_69 = bRebuildGrids_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AIModule.NavLocalGridManager.AddLocalNavigationGridForPoint
// (Final, Native, Static, Public, HasOutParms, HasDefaults, BlueprintCallable)
// Parameters:
// class Object_32759*            WorldContextObject_69          (Parm, ZeroConstructor)
// struct FVector                 Location_69                    (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
// int                            Radius2D_69                    (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// float                          Height_69                      (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// bool                           bRebuildGrids_69               (Parm, ZeroConstructor, IsPlainOldData)
// int                            ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int NavLocalGridManager::STATIC_AddLocalNavigationGridForPoint(class Object_32759* WorldContextObject_69, const struct FVector& Location_69, int Radius2D_69, float Height_69, bool bRebuildGrids_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.NavLocalGridManager.AddLocalNavigationGridForPoint"));

	NavLocalGridManager_AddLocalNavigationGridForPoint_Params params;
	params.WorldContextObject_69 = WorldContextObject_69;
	params.Location_69 = Location_69;
	params.Radius2D_69 = Radius2D_69;
	params.Height_69 = Height_69;
	params.bRebuildGrids_69 = bRebuildGrids_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AIModule.NavLocalGridManager.AddLocalNavigationGridForCapsule
// (Final, Native, Static, Public, HasOutParms, HasDefaults, BlueprintCallable)
// Parameters:
// class Object_32759*            WorldContextObject_69          (Parm, ZeroConstructor)
// struct FVector                 Location_69                    (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
// float                          CapsuleRadius_69               (Parm, ZeroConstructor, IsPlainOldData)
// float                          CapsuleHalfHeight_69           (Parm, ZeroConstructor, IsPlainOldData)
// int                            Radius2D_69                    (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// float                          Height_69                      (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// bool                           bRebuildGrids_69               (Parm, ZeroConstructor, IsPlainOldData)
// int                            ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int NavLocalGridManager::STATIC_AddLocalNavigationGridForCapsule(class Object_32759* WorldContextObject_69, const struct FVector& Location_69, float CapsuleRadius_69, float CapsuleHalfHeight_69, int Radius2D_69, float Height_69, bool bRebuildGrids_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.NavLocalGridManager.AddLocalNavigationGridForCapsule"));

	NavLocalGridManager_AddLocalNavigationGridForCapsule_Params params;
	params.WorldContextObject_69 = WorldContextObject_69;
	params.Location_69 = Location_69;
	params.CapsuleRadius_69 = CapsuleRadius_69;
	params.CapsuleHalfHeight_69 = CapsuleHalfHeight_69;
	params.Radius2D_69 = Radius2D_69;
	params.Height_69 = Height_69;
	params.bRebuildGrids_69 = bRebuildGrids_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AIModule.NavLocalGridManager.AddLocalNavigationGridForBox
// (Final, Native, Static, Public, HasOutParms, HasDefaults, BlueprintCallable)
// Parameters:
// class Object_32759*            WorldContextObject_69          (Parm, ZeroConstructor)
// struct FVector                 Location_69                    (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
// struct FVector                 Extent_69                      (Parm, ZeroConstructor, IsPlainOldData)
// struct FRotator                Rotation_69                    (Parm, ZeroConstructor, IsPlainOldData)
// int                            Radius2D_69                    (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// float                          Height_69                      (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// bool                           bRebuildGrids_69               (Parm, ZeroConstructor, IsPlainOldData)
// int                            ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int NavLocalGridManager::STATIC_AddLocalNavigationGridForBox(class Object_32759* WorldContextObject_69, const struct FVector& Location_69, const struct FVector& Extent_69, const struct FRotator& Rotation_69, int Radius2D_69, float Height_69, bool bRebuildGrids_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.NavLocalGridManager.AddLocalNavigationGridForBox"));

	NavLocalGridManager_AddLocalNavigationGridForBox_Params params;
	params.WorldContextObject_69 = WorldContextObject_69;
	params.Location_69 = Location_69;
	params.Extent_69 = Extent_69;
	params.Rotation_69 = Rotation_69;
	params.Radius2D_69 = Radius2D_69;
	params.Height_69 = Height_69;
	params.bRebuildGrids_69 = bRebuildGrids_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AIModule.AIPerceptionComponent.SetSenseEnabled
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// class AISense*                 SenseClass_69                  (Parm, ZeroConstructor)
// bool                           bEnable_69                     (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void AIPerceptionComponent::SetSenseEnabled(class AISense* SenseClass_69, bool bEnable_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.AIPerceptionComponent.SetSenseEnabled"));

	AIPerceptionComponent_SetSenseEnabled_Params params;
	params.SenseClass_69 = SenseClass_69;
	params.bEnable_69 = bEnable_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AIModule.AIPerceptionComponent.RequestStimuliListenerUpdate
// (Final, Native, Public, BlueprintCallable)

void AIPerceptionComponent::RequestStimuliListenerUpdate()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.AIPerceptionComponent.RequestStimuliListenerUpdate"));

	AIPerceptionComponent_RequestStimuliListenerUpdate_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AIModule.AIPerceptionComponent.OnOwnerEndPlay
// (Final, Native, Public)
// Parameters:
// class Actor_32759*             Actor_69                       (Parm, ZeroConstructor)
// TEnumAsByte<EEndPlayReason>    EndPlayReason_69               (Parm, ZeroConstructor, IsPlainOldData)

void AIPerceptionComponent::OnOwnerEndPlay(class Actor_32759* Actor_69, TEnumAsByte<EEndPlayReason> EndPlayReason_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.AIPerceptionComponent.OnOwnerEndPlay"));

	AIPerceptionComponent_OnOwnerEndPlay_Params params;
	params.Actor_69 = Actor_69;
	params.EndPlayReason_69 = EndPlayReason_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AIModule.AIPerceptionComponent.GetPerceivedHostileActorsBySense
// (Final, Native, Public, HasOutParms, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// class AISense*                 SenseToUse_69                  (ConstParm, Parm, ZeroConstructor)
// TArray<class Actor_32759*>     OutActors_69                   (Parm, OutParm, ZeroConstructor)

void AIPerceptionComponent::GetPerceivedHostileActorsBySense(class AISense* SenseToUse_69, TArray<class Actor_32759*>* OutActors_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.AIPerceptionComponent.GetPerceivedHostileActorsBySense"));

	AIPerceptionComponent_GetPerceivedHostileActorsBySense_Params params;
	params.SenseToUse_69 = SenseToUse_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (OutActors_69 != nullptr)
		*OutActors_69 = params.OutActors_69;
}


// Function AIModule.AIPerceptionComponent.GetPerceivedHostileActors
// (Final, Native, Public, HasOutParms, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// TArray<class Actor_32759*>     OutActors_69                   (Parm, OutParm, ZeroConstructor)

void AIPerceptionComponent::GetPerceivedHostileActors(TArray<class Actor_32759*>* OutActors_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.AIPerceptionComponent.GetPerceivedHostileActors"));

	AIPerceptionComponent_GetPerceivedHostileActors_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (OutActors_69 != nullptr)
		*OutActors_69 = params.OutActors_69;
}


// Function AIModule.AIPerceptionComponent.GetPerceivedActors
// (Final, Native, Public, HasOutParms, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// class AISense*                 SenseToUse_69                  (Parm, ZeroConstructor)
// TArray<class Actor_32759*>     OutActors_69                   (Parm, OutParm, ZeroConstructor)

void AIPerceptionComponent::GetPerceivedActors(class AISense* SenseToUse_69, TArray<class Actor_32759*>* OutActors_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.AIPerceptionComponent.GetPerceivedActors"));

	AIPerceptionComponent_GetPerceivedActors_Params params;
	params.SenseToUse_69 = SenseToUse_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (OutActors_69 != nullptr)
		*OutActors_69 = params.OutActors_69;
}


// Function AIModule.AIPerceptionComponent.GetKnownPerceivedActors
// (Final, Native, Public, HasOutParms, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// class AISense*                 SenseToUse_69                  (Parm, ZeroConstructor)
// TArray<class Actor_32759*>     OutActors_69                   (Parm, OutParm, ZeroConstructor)

void AIPerceptionComponent::GetKnownPerceivedActors(class AISense* SenseToUse_69, TArray<class Actor_32759*>* OutActors_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.AIPerceptionComponent.GetKnownPerceivedActors"));

	AIPerceptionComponent_GetKnownPerceivedActors_Params params;
	params.SenseToUse_69 = SenseToUse_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (OutActors_69 != nullptr)
		*OutActors_69 = params.OutActors_69;
}


// Function AIModule.AIPerceptionComponent.GetCurrentlyPerceivedActors
// (Final, Native, Public, HasOutParms, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// class AISense*                 SenseToUse_69                  (Parm, ZeroConstructor)
// TArray<class Actor_32759*>     OutActors_69                   (Parm, OutParm, ZeroConstructor)

void AIPerceptionComponent::GetCurrentlyPerceivedActors(class AISense* SenseToUse_69, TArray<class Actor_32759*>* OutActors_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.AIPerceptionComponent.GetCurrentlyPerceivedActors"));

	AIPerceptionComponent_GetCurrentlyPerceivedActors_Params params;
	params.SenseToUse_69 = SenseToUse_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (OutActors_69 != nullptr)
		*OutActors_69 = params.OutActors_69;
}


// Function AIModule.AIPerceptionComponent.GetActorsPerception
// (Final, Native, Public, HasOutParms, BlueprintCallable)
// Parameters:
// class Actor_32759*             Actor_69                       (Parm, ZeroConstructor)
// struct FActorPerceptionBlueprintInfo Info_69                        (Parm, OutParm)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool AIPerceptionComponent::GetActorsPerception(class Actor_32759* Actor_69, struct FActorPerceptionBlueprintInfo* Info_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.AIPerceptionComponent.GetActorsPerception"));

	AIPerceptionComponent_GetActorsPerception_Params params;
	params.Actor_69 = Actor_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (Info_69 != nullptr)
		*Info_69 = params.Info_69;

	return params.ReturnValue_69;
}


// Function AIModule.AIPerceptionComponent.ForgetAll
// (Final, Native, Public, BlueprintCallable)

void AIPerceptionComponent::ForgetAll()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.AIPerceptionComponent.ForgetAll"));

	AIPerceptionComponent_ForgetAll_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AIModule.AIPerceptionStimuliSourceComponent.UnregisterFromSense
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// class AISense*                 SenseClass_69                  (Parm, ZeroConstructor)

void AIPerceptionStimuliSourceComponent::UnregisterFromSense(class AISense* SenseClass_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.AIPerceptionStimuliSourceComponent.UnregisterFromSense"));

	AIPerceptionStimuliSourceComponent_UnregisterFromSense_Params params;
	params.SenseClass_69 = SenseClass_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AIModule.AIPerceptionStimuliSourceComponent.UnregisterFromPerceptionSystem
// (Final, Native, Public, BlueprintCallable)

void AIPerceptionStimuliSourceComponent::UnregisterFromPerceptionSystem()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.AIPerceptionStimuliSourceComponent.UnregisterFromPerceptionSystem"));

	AIPerceptionStimuliSourceComponent_UnregisterFromPerceptionSystem_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AIModule.AIPerceptionStimuliSourceComponent.RegisterWithPerceptionSystem
// (Final, Native, Public, BlueprintCallable)

void AIPerceptionStimuliSourceComponent::RegisterWithPerceptionSystem()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.AIPerceptionStimuliSourceComponent.RegisterWithPerceptionSystem"));

	AIPerceptionStimuliSourceComponent_RegisterWithPerceptionSystem_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AIModule.AIPerceptionStimuliSourceComponent.RegisterForSense
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// class AISense*                 SenseClass_69                  (Parm, ZeroConstructor)

void AIPerceptionStimuliSourceComponent::RegisterForSense(class AISense* SenseClass_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.AIPerceptionStimuliSourceComponent.RegisterForSense"));

	AIPerceptionStimuliSourceComponent_RegisterForSense_Params params;
	params.SenseClass_69 = SenseClass_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AIModule.AIPerceptionSystem.ReportPerceptionEvent
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// class Object_32759*            WorldContextObject_69          (Parm, ZeroConstructor)
// class AISenseEvent*            PerceptionEvent_69             (Parm, ZeroConstructor)

void AIPerceptionSystem::STATIC_ReportPerceptionEvent(class Object_32759* WorldContextObject_69, class AISenseEvent* PerceptionEvent_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.AIPerceptionSystem.ReportPerceptionEvent"));

	AIPerceptionSystem_ReportPerceptionEvent_Params params;
	params.WorldContextObject_69 = WorldContextObject_69;
	params.PerceptionEvent_69 = PerceptionEvent_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AIModule.AIPerceptionSystem.ReportEvent
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// class AISenseEvent*            PerceptionEvent_69             (Parm, ZeroConstructor)

void AIPerceptionSystem::ReportEvent(class AISenseEvent* PerceptionEvent_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.AIPerceptionSystem.ReportEvent"));

	AIPerceptionSystem_ReportEvent_Params params;
	params.PerceptionEvent_69 = PerceptionEvent_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AIModule.AIPerceptionSystem.RegisterPerceptionStimuliSource
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// class Object_32759*            WorldContextObject_69          (Parm, ZeroConstructor)
// class AISense*                 Sense_69                       (Parm, ZeroConstructor)
// class Actor_32759*             Target_69                      (Parm, ZeroConstructor)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool AIPerceptionSystem::STATIC_RegisterPerceptionStimuliSource(class Object_32759* WorldContextObject_69, class AISense* Sense_69, class Actor_32759* Target_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.AIPerceptionSystem.RegisterPerceptionStimuliSource"));

	AIPerceptionSystem_RegisterPerceptionStimuliSource_Params params;
	params.WorldContextObject_69 = WorldContextObject_69;
	params.Sense_69 = Sense_69;
	params.Target_69 = Target_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AIModule.AIPerceptionSystem.OnPerceptionStimuliSourceEndPlay
// (Final, Native, Protected)
// Parameters:
// class Actor_32759*             Actor_69                       (Parm, ZeroConstructor)
// TEnumAsByte<EEndPlayReason>    EndPlayReason_69               (Parm, ZeroConstructor, IsPlainOldData)

void AIPerceptionSystem::OnPerceptionStimuliSourceEndPlay(class Actor_32759* Actor_69, TEnumAsByte<EEndPlayReason> EndPlayReason_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.AIPerceptionSystem.OnPerceptionStimuliSourceEndPlay"));

	AIPerceptionSystem_OnPerceptionStimuliSourceEndPlay_Params params;
	params.Actor_69 = Actor_69;
	params.EndPlayReason_69 = EndPlayReason_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AIModule.AIPerceptionSystem.GetSenseClassForStimulus
// (Final, Native, Static, Public, HasOutParms, BlueprintCallable)
// Parameters:
// class Object_32759*            WorldContextObject_69          (Parm, ZeroConstructor)
// struct FAIStimulus             Stimulus_69                    (ConstParm, Parm, OutParm, ReferenceParm)
// class AISense*                 ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

class AISense* AIPerceptionSystem::STATIC_GetSenseClassForStimulus(class Object_32759* WorldContextObject_69, const struct FAIStimulus& Stimulus_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.AIPerceptionSystem.GetSenseClassForStimulus"));

	AIPerceptionSystem_GetSenseClassForStimulus_Params params;
	params.WorldContextObject_69 = WorldContextObject_69;
	params.Stimulus_69 = Stimulus_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AIModule.AISense_Blueprint.OnUpdate
// (Event, Public, HasOutParms, BlueprintEvent)
// Parameters:
// TArray<class AISenseEvent*>    EventsToProcess_69             (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
// float                          ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

float AISense_Blueprint::OnUpdate(TArray<class AISenseEvent*> EventsToProcess_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.AISense_Blueprint.OnUpdate"));

	AISense_Blueprint_OnUpdate_Params params;
	params.EventsToProcess_69 = EventsToProcess_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AIModule.AISense_Blueprint.OnListenerUpdated
// (Event, Public, BlueprintEvent)
// Parameters:
// class Actor_32759*             ActorListener_69               (Parm, ZeroConstructor)
// class AIPerceptionComponent*   PerceptionComponent_69         (Parm, ZeroConstructor, InstancedReference)

void AISense_Blueprint::OnListenerUpdated(class Actor_32759* ActorListener_69, class AIPerceptionComponent* PerceptionComponent_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.AISense_Blueprint.OnListenerUpdated"));

	AISense_Blueprint_OnListenerUpdated_Params params;
	params.ActorListener_69 = ActorListener_69;
	params.PerceptionComponent_69 = PerceptionComponent_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AIModule.AISense_Blueprint.OnListenerUnregistered
// (Event, Public, BlueprintEvent)
// Parameters:
// class Actor_32759*             ActorListener_69               (Parm, ZeroConstructor)
// class AIPerceptionComponent*   PerceptionComponent_69         (Parm, ZeroConstructor, InstancedReference)

void AISense_Blueprint::OnListenerUnregistered(class Actor_32759* ActorListener_69, class AIPerceptionComponent* PerceptionComponent_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.AISense_Blueprint.OnListenerUnregistered"));

	AISense_Blueprint_OnListenerUnregistered_Params params;
	params.ActorListener_69 = ActorListener_69;
	params.PerceptionComponent_69 = PerceptionComponent_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AIModule.AISense_Blueprint.OnListenerRegistered
// (Event, Public, BlueprintEvent)
// Parameters:
// class Actor_32759*             ActorListener_69               (Parm, ZeroConstructor)
// class AIPerceptionComponent*   PerceptionComponent_69         (Parm, ZeroConstructor, InstancedReference)

void AISense_Blueprint::OnListenerRegistered(class Actor_32759* ActorListener_69, class AIPerceptionComponent* PerceptionComponent_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.AISense_Blueprint.OnListenerRegistered"));

	AISense_Blueprint_OnListenerRegistered_Params params;
	params.ActorListener_69 = ActorListener_69;
	params.PerceptionComponent_69 = PerceptionComponent_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AIModule.AISense_Blueprint.K2_OnNewPawn
// (Event, Public, BlueprintEvent)
// Parameters:
// class Pawn*                    NewPawn_69                     (Parm, ZeroConstructor)

void AISense_Blueprint::K2_OnNewPawn(class Pawn* NewPawn_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.AISense_Blueprint.K2_OnNewPawn"));

	AISense_Blueprint_K2_OnNewPawn_Params params;
	params.NewPawn_69 = NewPawn_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AIModule.AISense_Blueprint.GetAllListenerComponents
// (Final, Native, Public, HasOutParms, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// TArray<class AIPerceptionComponent*> ListenerComponents_69          (Parm, OutParm, ZeroConstructor)

void AISense_Blueprint::GetAllListenerComponents(TArray<class AIPerceptionComponent*>* ListenerComponents_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.AISense_Blueprint.GetAllListenerComponents"));

	AISense_Blueprint_GetAllListenerComponents_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (ListenerComponents_69 != nullptr)
		*ListenerComponents_69 = params.ListenerComponents_69;
}


// Function AIModule.AISense_Blueprint.GetAllListenerActors
// (Final, Native, Public, HasOutParms, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// TArray<class Actor_32759*>     ListenerActors_69              (Parm, OutParm, ZeroConstructor)

void AISense_Blueprint::GetAllListenerActors(TArray<class Actor_32759*>* ListenerActors_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.AISense_Blueprint.GetAllListenerActors"));

	AISense_Blueprint_GetAllListenerActors_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (ListenerActors_69 != nullptr)
		*ListenerActors_69 = params.ListenerActors_69;
}


// Function AIModule.AISense_Damage.ReportDamageEvent
// (Final, Native, Static, Public, HasDefaults, BlueprintCallable)
// Parameters:
// class Object_32759*            WorldContextObject_69          (Parm, ZeroConstructor)
// class Actor_32759*             DamagedActor_69                (Parm, ZeroConstructor)
// class Actor_32759*             Instigator_69                  (Parm, ZeroConstructor)
// float                          DamageAmount_69                (Parm, ZeroConstructor, IsPlainOldData)
// struct FVector                 EventLocation_69               (Parm, ZeroConstructor, IsPlainOldData)
// struct FVector                 HitLocation_69                 (Parm, ZeroConstructor, IsPlainOldData)
// struct FName                   tag_69                         (Parm, ZeroConstructor, IsPlainOldData)

void AISense_Damage::STATIC_ReportDamageEvent(class Object_32759* WorldContextObject_69, class Actor_32759* DamagedActor_69, class Actor_32759* Instigator_69, float DamageAmount_69, const struct FVector& EventLocation_69, const struct FVector& HitLocation_69, const struct FName& tag_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.AISense_Damage.ReportDamageEvent"));

	AISense_Damage_ReportDamageEvent_Params params;
	params.WorldContextObject_69 = WorldContextObject_69;
	params.DamagedActor_69 = DamagedActor_69;
	params.Instigator_69 = Instigator_69;
	params.DamageAmount_69 = DamageAmount_69;
	params.EventLocation_69 = EventLocation_69;
	params.HitLocation_69 = HitLocation_69;
	params.tag_69 = tag_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AIModule.AISense_Hearing.ReportNoiseEvent
// (Final, Native, Static, Public, HasDefaults, BlueprintCallable)
// Parameters:
// class Object_32759*            WorldContextObject_69          (Parm, ZeroConstructor)
// struct FVector                 NoiseLocation_69               (Parm, ZeroConstructor, IsPlainOldData)
// float                          Loudness_69                    (Parm, ZeroConstructor, IsPlainOldData)
// class Actor_32759*             Instigator_69                  (Parm, ZeroConstructor)
// float                          MaxRange_69                    (Parm, ZeroConstructor, IsPlainOldData)
// struct FName                   tag_69                         (Parm, ZeroConstructor, IsPlainOldData)

void AISense_Hearing::STATIC_ReportNoiseEvent(class Object_32759* WorldContextObject_69, const struct FVector& NoiseLocation_69, float Loudness_69, class Actor_32759* Instigator_69, float MaxRange_69, const struct FName& tag_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.AISense_Hearing.ReportNoiseEvent"));

	AISense_Hearing_ReportNoiseEvent_Params params;
	params.WorldContextObject_69 = WorldContextObject_69;
	params.NoiseLocation_69 = NoiseLocation_69;
	params.Loudness_69 = Loudness_69;
	params.Instigator_69 = Instigator_69;
	params.MaxRange_69 = MaxRange_69;
	params.tag_69 = tag_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AIModule.AISense_Prediction.RequestPawnPredictionEvent
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// class Pawn*                    Requestor_69                   (Parm, ZeroConstructor)
// class Actor_32759*             PredictedActor_69              (Parm, ZeroConstructor)
// float                          PredictionTime_69              (Parm, ZeroConstructor, IsPlainOldData)

void AISense_Prediction::STATIC_RequestPawnPredictionEvent(class Pawn* Requestor_69, class Actor_32759* PredictedActor_69, float PredictionTime_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.AISense_Prediction.RequestPawnPredictionEvent"));

	AISense_Prediction_RequestPawnPredictionEvent_Params params;
	params.Requestor_69 = Requestor_69;
	params.PredictedActor_69 = PredictedActor_69;
	params.PredictionTime_69 = PredictionTime_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AIModule.AISense_Prediction.RequestControllerPredictionEvent
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// class AIController*            Requestor_69                   (Parm, ZeroConstructor)
// class Actor_32759*             PredictedActor_69              (Parm, ZeroConstructor)
// float                          PredictionTime_69              (Parm, ZeroConstructor, IsPlainOldData)

void AISense_Prediction::STATIC_RequestControllerPredictionEvent(class AIController* Requestor_69, class Actor_32759* PredictedActor_69, float PredictionTime_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.AISense_Prediction.RequestControllerPredictionEvent"));

	AISense_Prediction_RequestControllerPredictionEvent_Params params;
	params.Requestor_69 = Requestor_69;
	params.PredictedActor_69 = PredictedActor_69;
	params.PredictionTime_69 = PredictionTime_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AIModule.AISense_Touch.ReportTouchEvent
// (Final, Native, Static, Public, HasDefaults, BlueprintCallable)
// Parameters:
// class Object_32759*            WorldContextObject_69          (Parm, ZeroConstructor)
// class Actor_32759*             TouchReceiver_69               (Parm, ZeroConstructor)
// class Actor_32759*             OtherActor_69                  (Parm, ZeroConstructor)
// struct FVector                 Location_69                    (Parm, ZeroConstructor, IsPlainOldData)

void AISense_Touch::STATIC_ReportTouchEvent(class Object_32759* WorldContextObject_69, class Actor_32759* TouchReceiver_69, class Actor_32759* OtherActor_69, const struct FVector& Location_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.AISense_Touch.ReportTouchEvent"));

	AISense_Touch_ReportTouchEvent_Params params;
	params.WorldContextObject_69 = WorldContextObject_69;
	params.TouchReceiver_69 = TouchReceiver_69;
	params.OtherActor_69 = OtherActor_69;
	params.Location_69 = Location_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AIModule.PawnSensingComponent.SetSensingUpdatesEnabled
// (BlueprintAuthorityOnly, Native, Public, BlueprintCallable)
// Parameters:
// bool                           bEnabled_69                    (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void PawnSensingComponent::SetSensingUpdatesEnabled(bool bEnabled_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.PawnSensingComponent.SetSensingUpdatesEnabled"));

	PawnSensingComponent_SetSensingUpdatesEnabled_Params params;
	params.bEnabled_69 = bEnabled_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AIModule.PawnSensingComponent.SetSensingInterval
// (BlueprintAuthorityOnly, Native, Public, BlueprintCallable)
// Parameters:
// float                          NewSensingInterval_69          (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void PawnSensingComponent::SetSensingInterval(float NewSensingInterval_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.PawnSensingComponent.SetSensingInterval"));

	PawnSensingComponent_SetSensingInterval_Params params;
	params.NewSensingInterval_69 = NewSensingInterval_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AIModule.PawnSensingComponent.SetPeripheralVisionAngle
// (BlueprintAuthorityOnly, Native, Public, BlueprintCallable)
// Parameters:
// float                          NewPeripheralVisionAngle_69    (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void PawnSensingComponent::SetPeripheralVisionAngle(float NewPeripheralVisionAngle_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.PawnSensingComponent.SetPeripheralVisionAngle"));

	PawnSensingComponent_SetPeripheralVisionAngle_Params params;
	params.NewPeripheralVisionAngle_69 = NewPeripheralVisionAngle_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// DelegateFunction AIModule.PawnSensingComponent.SeePawnDelegate__DelegateSignature
// (MulticastDelegate, Public, Delegate)
// Parameters:
// class Pawn*                    Pawn_69                        (Parm, ZeroConstructor)

void PawnSensingComponent::SeePawnDelegate__DelegateSignature(class Pawn* Pawn_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("DelegateFunction AIModule.PawnSensingComponent.SeePawnDelegate__DelegateSignature"));

	PawnSensingComponent_SeePawnDelegate__DelegateSignature_Params params;
	params.Pawn_69 = Pawn_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// DelegateFunction AIModule.PawnSensingComponent.HearNoiseDelegate__DelegateSignature
// (MulticastDelegate, Public, Delegate, HasOutParms, HasDefaults)
// Parameters:
// class Pawn*                    Instigator_69                  (Parm, ZeroConstructor)
// struct FVector                 Location_69                    (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
// float                          Volume_69                      (Parm, ZeroConstructor, IsPlainOldData)

void PawnSensingComponent::HearNoiseDelegate__DelegateSignature(class Pawn* Instigator_69, const struct FVector& Location_69, float Volume_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("DelegateFunction AIModule.PawnSensingComponent.HearNoiseDelegate__DelegateSignature"));

	PawnSensingComponent_HearNoiseDelegate__DelegateSignature_Params params;
	params.Instigator_69 = Instigator_69;
	params.Location_69 = Location_69;
	params.Volume_69 = Volume_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AIModule.PawnSensingComponent.GetPeripheralVisionCosine
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// float                          ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

float PawnSensingComponent::GetPeripheralVisionCosine()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.PawnSensingComponent.GetPeripheralVisionCosine"));

	PawnSensingComponent_GetPeripheralVisionCosine_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AIModule.PawnSensingComponent.GetPeripheralVisionAngle
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// float                          ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

float PawnSensingComponent::GetPeripheralVisionAngle()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.PawnSensingComponent.GetPeripheralVisionAngle"));

	PawnSensingComponent_GetPeripheralVisionAngle_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AIModule.AITask_RunEQS.RunEQS
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// class AIController*            Controller_69                  (Parm, ZeroConstructor)
// class EnvQuery*                QueryTemplate_69               (Parm, ZeroConstructor)
// class AITask_RunEQS*           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

class AITask_RunEQS* AITask_RunEQS::STATIC_RunEQS(class AIController* Controller_69, class EnvQuery* QueryTemplate_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AIModule.AITask_RunEQS.RunEQS"));

	AITask_RunEQS_RunEQS_Params params;
	params.Controller_69 = Controller_69;
	params.QueryTemplate_69 = QueryTemplate_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

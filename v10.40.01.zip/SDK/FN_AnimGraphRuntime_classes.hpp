#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Classes
//---------------------------------------------------------------------------

// Class AnimGraphRuntime.AnimationStateMachineLibrary
// 0x0000 (0x0028 - 0x0028)
class AnimationStateMachineLibrary : public BlueprintFunctionLibrary
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AnimGraphRuntime.AnimationStateMachineLibrary"));
		
		return ptr;
	}


	void STATIC_SetState(const struct FAnimUpdateContext& UpdateContext_69, const struct FAnimationStateMachineReference& Node_69, const struct FName& TargetState_69, float Duration_69, TEnumAsByte<ETransitionLogicType> BlendType_69, class BlendProfile* BlendProfile_69, EAlphaBlendOption AlphaBlendOption_69, class CurveFloat* CustomBlendCurve_69);
	bool STATIC_IsStateBlendingOut(const struct FAnimUpdateContext& UpdateContext_69, const struct FAnimationStateResultReference& Node_69);
	bool STATIC_IsStateBlendingIn(const struct FAnimUpdateContext& UpdateContext_69, const struct FAnimationStateResultReference& Node_69);
	struct FName STATIC_GetState(const struct FAnimUpdateContext& UpdateContext_69, const struct FAnimationStateMachineReference& Node_69);
	float STATIC_GetRelevantAnimTimeRemainingFraction(const struct FAnimUpdateContext& UpdateContext_69, const struct FAnimationStateResultReference& Node_69);
	float STATIC_GetRelevantAnimTimeRemaining(const struct FAnimUpdateContext& UpdateContext_69, const struct FAnimationStateResultReference& Node_69);
	void STATIC_ConvertToAnimationStateResultPure(const struct FAnimNodeReference& Node_69, struct FAnimationStateResultReference* AnimationState_69, bool* Result_69);
	void STATIC_ConvertToAnimationStateResult(const struct FAnimNodeReference& Node_69, struct FAnimationStateResultReference* AnimationState_69, EAnimNodeReferenceConversionResult* Result_69);
	void STATIC_ConvertToAnimationStateMachinePure(const struct FAnimNodeReference& Node_69, struct FAnimationStateMachineReference* AnimationState_69, bool* Result_69);
	void STATIC_ConvertToAnimationStateMachine(const struct FAnimNodeReference& Node_69, struct FAnimationStateMachineReference* AnimationState_69, EAnimNodeReferenceConversionResult* Result_69);
};


// Class AnimGraphRuntime.AnimExecutionContextLibrary
// 0x0000 (0x0028 - 0x0028)
class AnimExecutionContextLibrary : public BlueprintFunctionLibrary
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AnimGraphRuntime.AnimExecutionContextLibrary"));
		
		return ptr;
	}


	float STATIC_GetDeltaTime(const struct FAnimUpdateContext& Context_69);
	float STATIC_GetCurrentWeight(const struct FAnimUpdateContext& Context_69);
	struct FAnimNodeReference STATIC_GetAnimNodeReference(class AnimInstance* Instance_69, int Index_69);
	class AnimInstance* STATIC_GetAnimInstance(const struct FAnimExecutionContext& Context_69);
	struct FAnimUpdateContext STATIC_ConvertToUpdateContext(const struct FAnimExecutionContext& Context_69, EAnimExecutionContextConversionResult* Result_69);
	struct FAnimPoseContext STATIC_ConvertToPoseContext(const struct FAnimExecutionContext& Context_69, EAnimExecutionContextConversionResult* Result_69);
	struct FAnimInitializationContext STATIC_ConvertToInitializationContext(const struct FAnimExecutionContext& Context_69, EAnimExecutionContextConversionResult* Result_69);
	struct FAnimComponentSpacePoseContext STATIC_ConvertToComponentSpacePoseContext(const struct FAnimExecutionContext& Context_69, EAnimExecutionContextConversionResult* Result_69);
};


// Class AnimGraphRuntime.AnimNotify_PlayMontageNotify
// 0x0008 (0x0040 - 0x0038)
class AnimNotify_PlayMontageNotify : public AnimNotify
{
public:
	struct FName                                       NotifyName_69;                                            // 0x0038(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x003C(0x0004) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AnimGraphRuntime.AnimNotify_PlayMontageNotify"));
		
		return ptr;
	}

};


// Class AnimGraphRuntime.AnimNotify_PlayMontageNotifyWindow
// 0x0008 (0x0038 - 0x0030)
class AnimNotify_PlayMontageNotifyWindow : public AnimNotifyState
{
public:
	struct FName                                       NotifyName_69;                                            // 0x0030(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0034(0x0004) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AnimGraphRuntime.AnimNotify_PlayMontageNotifyWindow"));
		
		return ptr;
	}

};


// Class AnimGraphRuntime.AnimSequencerInstance
// 0x0000 (0x0350 - 0x0350)
class AnimSequencerInstance : public AnimInstance
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AnimGraphRuntime.AnimSequencerInstance"));
		
		return ptr;
	}

};


// Class AnimGraphRuntime.KismetAnimationLibrary
// 0x0000 (0x0028 - 0x0028)
class KismetAnimationLibrary : public BlueprintFunctionLibrary
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AnimGraphRuntime.KismetAnimationLibrary"));
		
		return ptr;
	}


	void STATIC_K2_TwoBoneIK(const struct FVector& RootPos_69, const struct FVector& JointPos_69, const struct FVector& EndPos_69, const struct FVector& JointTarget_69, const struct FVector& Effector_69, bool bAllowStretching_69, float StartStretchRatio_69, float MaxStretchScale_69, struct FVector* OutJointPos_69, struct FVector* OutEndPos_69);
	void STATIC_K2_StartProfilingTimer();
	struct FVector STATIC_K2_MakePerlinNoiseVectorAndRemap(float X_69, float Y_69, float Z_69, float RangeOutMinX_69, float RangeOutMaxX_69, float RangeOutMinY_69, float RangeOutMaxY_69, float RangeOutMinZ_69, float RangeOutMaxZ_69);
	float STATIC_K2_MakePerlinNoiseAndRemap(float Value_69, float RangeOutMin_69, float RangeOutMax_69);
	struct FCoreUObject_FTransform STATIC_K2_LookAt(const struct FCoreUObject_FTransform& CurrentTransform_69, const struct FVector& TargetPosition_69, const struct FVector& LookAtVector_69, bool bUseUpVector_69, const struct FVector& UpVector_69, float ClampConeInDegree_69);
	float STATIC_K2_EndProfilingTimer(bool bLog_69, const struct FString& LogPrefix_69);
	float STATIC_K2_DistanceBetweenTwoSocketsAndMapRange(class SkeletalMeshComponent* Component_69, const struct FName& SocketOrBoneNameA_69, TEnumAsByte<ERelativeTransformSpace> SocketSpaceA_69, const struct FName& SocketOrBoneNameB_69, TEnumAsByte<ERelativeTransformSpace> SocketSpaceB_69, bool bRemapRange_69, float InRangeMin_69, float InRangeMax_69, float OutRangeMin_69, float OutRangeMax_69);
	struct FVector STATIC_K2_DirectionBetweenSockets(class SkeletalMeshComponent* Component_69, const struct FName& SocketOrBoneNameFrom_69, const struct FName& SocketOrBoneNameTo_69);
	float STATIC_K2_CalculateVelocityFromSockets(float DeltaSeconds_69, class SkeletalMeshComponent* Component_69, const struct FName& SocketOrBoneName_69, const struct FName& ReferenceSocketOrBone_69, TEnumAsByte<ERelativeTransformSpace> SocketSpace_69, const struct FVector& OffsetInBoneSpace_69, int NumberOfSamples_69, float VelocityMin_69, float VelocityMax_69, EEasingFuncType EasingType_69, const struct FRuntimeFloatCurve& CustomCurve_69, struct FPositionHistory* History_69);
	float STATIC_K2_CalculateVelocityFromPositionHistory(float DeltaSeconds_69, const struct FVector& Position_69, int NumberOfSamples_69, float VelocityMin_69, float VelocityMax_69, struct FPositionHistory* History_69);
	float STATIC_CalculateDirection(const struct FVector& Velocity_69, const struct FRotator& BaseRotation_69);
};


// Class AnimGraphRuntime.LinkedAnimGraphLibrary
// 0x0000 (0x0028 - 0x0028)
class LinkedAnimGraphLibrary : public BlueprintFunctionLibrary
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AnimGraphRuntime.LinkedAnimGraphLibrary"));
		
		return ptr;
	}


	bool STATIC_HasLinkedAnimInstance(const struct FLinkedAnimGraphReference& Node_69);
	class AnimInstance* STATIC_GetLinkedAnimInstance(const struct FLinkedAnimGraphReference& Node_69);
	void STATIC_ConvertToLinkedAnimGraphPure(const struct FAnimNodeReference& Node_69, struct FLinkedAnimGraphReference* LinkedAnimGraph_69, bool* Result_69);
	struct FLinkedAnimGraphReference STATIC_ConvertToLinkedAnimGraph(const struct FAnimNodeReference& Node_69, EAnimNodeReferenceConversionResult* Result_69);
};


// Class AnimGraphRuntime.PlayMontageCallbackProxy
// 0x0080 (0x00A8 - 0x0028)
class PlayMontageCallbackProxy : public Object_32759
{
public:
	unsigned char                                      UnknownData00[0x10];                                      // 0x0028(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty AnimGraphRuntime.PlayMontageCallbackProxy.OnCompleted_69
	unsigned char                                      UnknownData01[0x10];                                      // 0x0038(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty AnimGraphRuntime.PlayMontageCallbackProxy.OnBlendOut_69
	unsigned char                                      UnknownData02[0x10];                                      // 0x0048(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty AnimGraphRuntime.PlayMontageCallbackProxy.OnInterrupted_69
	unsigned char                                      UnknownData03[0x10];                                      // 0x0058(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty AnimGraphRuntime.PlayMontageCallbackProxy.OnNotifyBegin_69
	unsigned char                                      UnknownData04[0x10];                                      // 0x0068(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty AnimGraphRuntime.PlayMontageCallbackProxy.OnNotifyEnd_69
	unsigned char                                      UnknownData05[0x30];                                      // 0x0078(0x0030) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AnimGraphRuntime.PlayMontageCallbackProxy"));
		
		return ptr;
	}


	void OnNotifyEndReceived(const struct FName& NotifyName_69, const struct FBranchingPointNotifyPayload& BranchingPointNotifyPayload_69);
	void OnNotifyBeginReceived(const struct FName& NotifyName_69, const struct FBranchingPointNotifyPayload& BranchingPointNotifyPayload_69);
	void OnMontageEnded(class AnimMontage* Montage_69, bool bInterrupted_69);
	void OnMontageBlendingOut(class AnimMontage* Montage_69, bool bInterrupted_69);
	class PlayMontageCallbackProxy* STATIC_CreateProxyObjectForPlayMontage(class SkeletalMeshComponent* InSkeletalMeshComponent_69, class AnimMontage* MontageToPlay_69, float PlayRate_69, float StartingPosition_69, const struct FName& StartingSection_69);
};


// Class AnimGraphRuntime.SequenceEvaluatorLibrary
// 0x0000 (0x0028 - 0x0028)
class SequenceEvaluatorLibrary : public BlueprintFunctionLibrary
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AnimGraphRuntime.SequenceEvaluatorLibrary"));
		
		return ptr;
	}


	struct FSequenceEvaluatorReference STATIC_SetSequenceWithInertialBlending(const struct FAnimUpdateContext& UpdateContext_69, const struct FSequenceEvaluatorReference& SequenceEvaluator_69, class AnimSequenceBase* Sequence_69, float BlendTime_69);
	struct FSequenceEvaluatorReference STATIC_SetSequence(const struct FSequenceEvaluatorReference& SequenceEvaluator_69, class AnimSequenceBase* Sequence_69);
	struct FSequenceEvaluatorReference STATIC_SetExplicitTime(const struct FSequenceEvaluatorReference& SequenceEvaluator_69, float Time_69);
	class AnimSequenceBase* STATIC_GetSequence(const struct FSequenceEvaluatorReference& SequenceEvaluator_69);
	float STATIC_GetAccumulatedTime(const struct FSequenceEvaluatorReference& SequenceEvaluator_69);
	void STATIC_ConvertToSequenceEvaluatorPure(const struct FAnimNodeReference& Node_69, struct FSequenceEvaluatorReference* SequenceEvaluator_69, bool* Result_69);
	struct FSequenceEvaluatorReference STATIC_ConvertToSequenceEvaluator(const struct FAnimNodeReference& Node_69, EAnimNodeReferenceConversionResult* Result_69);
	struct FSequenceEvaluatorReference STATIC_AdvanceTime(const struct FAnimUpdateContext& UpdateContext_69, const struct FSequenceEvaluatorReference& SequenceEvaluator_69, float PlayRate_69);
};


// Class AnimGraphRuntime.SequencePlayerLibrary
// 0x0000 (0x0028 - 0x0028)
class SequencePlayerLibrary : public BlueprintFunctionLibrary
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AnimGraphRuntime.SequencePlayerLibrary"));
		
		return ptr;
	}


	struct FSequencePlayerReference STATIC_SetStartPosition(const struct FSequencePlayerReference& SequencePlayer_69, float StartPosition_69);
	struct FSequencePlayerReference STATIC_SetSequenceWithInertialBlending(const struct FAnimUpdateContext& UpdateContext_69, const struct FSequencePlayerReference& SequencePlayer_69, class AnimSequenceBase* Sequence_69, float BlendTime_69);
	struct FSequencePlayerReference STATIC_SetSequence(const struct FSequencePlayerReference& SequencePlayer_69, class AnimSequenceBase* Sequence_69);
	struct FSequencePlayerReference STATIC_SetPlayRate(const struct FSequencePlayerReference& SequencePlayer_69, float PlayRate_69);
	struct FSequencePlayerReference STATIC_SetAccumulatedTime(const struct FSequencePlayerReference& SequencePlayer_69, float Time_69);
	float STATIC_GetStartPosition(const struct FSequencePlayerReference& SequencePlayer_69);
	class AnimSequenceBase* STATIC_GetSequencePure(const struct FSequencePlayerReference& SequencePlayer_69);
	struct FSequencePlayerReference STATIC_GetSequence(const struct FSequencePlayerReference& SequencePlayer_69, class AnimSequenceBase** SequenceBase_69);
	float STATIC_GetPlayRate(const struct FSequencePlayerReference& SequencePlayer_69);
	bool STATIC_GetLoopAnimation(const struct FSequencePlayerReference& SequencePlayer_69);
	float STATIC_GetAccumulatedTime(const struct FSequencePlayerReference& SequencePlayer_69);
	void STATIC_ConvertToSequencePlayerPure(const struct FAnimNodeReference& Node_69, struct FSequencePlayerReference* SequencePlayer_69, bool* Result_69);
	struct FSequencePlayerReference STATIC_ConvertToSequencePlayer(const struct FAnimNodeReference& Node_69, EAnimNodeReferenceConversionResult* Result_69);
};


// Class AnimGraphRuntime.SequencerAnimationSupport
// 0x0000 (0x0028 - 0x0028)
class SequencerAnimationSupport : public Interface
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AnimGraphRuntime.SequencerAnimationSupport"));
		
		return ptr;
	}

};


// Class AnimGraphRuntime.SkeletalControlLibrary
// 0x0000 (0x0028 - 0x0028)
class SkeletalControlLibrary : public BlueprintFunctionLibrary
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AnimGraphRuntime.SkeletalControlLibrary"));
		
		return ptr;
	}


	struct FSkeletalControlReference STATIC_SetAlpha(const struct FSkeletalControlReference& SkeletalControl_69, float Alpha_69);
	float STATIC_GetAlpha(const struct FSkeletalControlReference& SkeletalControl_69);
	void STATIC_ConvertToSkeletalControlPure(const struct FAnimNodeReference& Node_69, struct FSkeletalControlReference* SkeletalControl_69, bool* Result_69);
	struct FSkeletalControlReference STATIC_ConvertToSkeletalControl(const struct FAnimNodeReference& Node_69, EAnimNodeReferenceConversionResult* Result_69);
};


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

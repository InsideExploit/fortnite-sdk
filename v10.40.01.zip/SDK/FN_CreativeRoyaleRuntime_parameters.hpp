#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function CreativeRoyaleRuntime.CreativeRoyalePlayspaceComponent_LoadingScreen.OnPlotLoadComplete
struct CreativeRoyalePlayspaceComponent_LoadingScreen_OnPlotLoadComplete_Params
{
};

// Function CreativeRoyaleRuntime.CreativeRoyalePlayspaceComponent_LoadingScreen.OnPlayspaceUserAdded
struct CreativeRoyalePlayspaceComponent_LoadingScreen_OnPlayspaceUserAdded_Params
{
	struct FPlayspaceUser                              AddedUser_69;                                             // (Parm, OutParm)
};

// Function CreativeRoyaleRuntime.CreativeRoyalePlayspaceComponent_LoadingScreen.OnMinigameStateChanged
struct CreativeRoyalePlayspaceComponent_LoadingScreen_OnMinigameStateChanged_Params
{
	class FortMinigame*                                Minigame_69;                                              // (Parm, ZeroConstructor)
	EFortMinigameState                                 MinigameState_69;                                         // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function CreativeRoyaleRuntime.AthenaAIServicePlayerBots_CreativeRoyale.OnPlayerJoiningInProgress
struct AthenaAIServicePlayerBots_CreativeRoyale_OnPlayerJoiningInProgress_Params
{
	class FortPlayerState*                             FortPlayerState_69;                                       // (ConstParm, Parm, ZeroConstructor)
};

// Function CreativeRoyaleRuntime.CreativeRoyaleRootPlayspace.TeleportPlayersToPlayerStarts
struct CreativeRoyaleRootPlayspace_TeleportPlayersToPlayerStarts_Params
{
};

// Function CreativeRoyaleRuntime.CreativeRoyaleRootPlayspace.OnRep_bHasPlotLoaded
struct CreativeRoyaleRootPlayspace_OnRep_bHasPlotLoaded_Params
{
};

// Function CreativeRoyaleRuntime.CreativeRoyaleRootPlayspace.OnPlotLoadComplete
struct CreativeRoyaleRootPlayspace_OnPlotLoadComplete_Params
{
};

// Function CreativeRoyaleRuntime.CreativeRoyaleRootPlayspace.Cheat_LoadEditorIsland
struct CreativeRoyaleRootPlayspace_Cheat_LoadEditorIsland_Params
{
};

// Function CreativeRoyaleRuntime.CreativeRoyaleRootPlayspace.BuildDataRegistryResolverScope_Implementation
struct CreativeRoyaleRootPlayspace_BuildDataRegistryResolverScope_Implementation_Params
{
	TArray<struct FName>                               InOutResolverScopes_69;                                   // (Parm, OutParm, ZeroConstructor)
	int                                                InOutPriority_69;                                         // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CreativeRoyaleRuntime.FortCheatManager_CreativeRoyale.TeleportToPlotAferLoad
struct FortCheatManager_CreativeRoyale_TeleportToPlotAferLoad_Params
{
};

// Function CreativeRoyaleRuntime.FortCheatManager_CreativeRoyale.CreativeRoyaleTeleportToEditZone
struct FortCheatManager_CreativeRoyale_CreativeRoyaleTeleportToEditZone_Params
{
};

// Function CreativeRoyaleRuntime.FortCheatManager_CreativeRoyale.CreativeRoyaleResetIslandFile
struct FortCheatManager_CreativeRoyale_CreativeRoyaleResetIslandFile_Params
{
};

// Function CreativeRoyaleRuntime.FortCheatManager_CreativeRoyale.CreativeRoyaleLoadEditPlot
struct FortCheatManager_CreativeRoyale_CreativeRoyaleLoadEditPlot_Params
{
};

// Function CreativeRoyaleRuntime.FortProjectEditComponent_CreativeRoyale.OnPlayerLoggedIn
struct FortProjectEditComponent_CreativeRoyale_OnPlayerLoggedIn_Params
{
	class PlayerController*                            PlayerController_69;                                      // (Parm, ZeroConstructor)
};

// Function CreativeRoyaleRuntime.FortProjectEditComponent_CreativeRoyale.LoadPlotFromProject
struct FortProjectEditComponent_CreativeRoyale_LoadPlotFromProject_Params
{
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

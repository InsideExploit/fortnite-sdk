// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Functions
//---------------------------------------------------------------------------

// Function AudioWidgets.AudioMeter.SetMeterValueColor
// (Final, Native, Public, HasDefaults, BlueprintCallable)
// Parameters:
// struct FLinearColor            InValue_69                     (Parm, ZeroConstructor, IsPlainOldData)

void AudioMeter::SetMeterValueColor(const struct FLinearColor& InValue_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioWidgets.AudioMeter.SetMeterValueColor"));

	AudioMeter_SetMeterValueColor_Params params;
	params.InValue_69 = InValue_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AudioWidgets.AudioMeter.SetMeterScaleLabelColor
// (Final, Native, Public, HasDefaults, BlueprintCallable)
// Parameters:
// struct FLinearColor            InValue_69                     (Parm, ZeroConstructor, IsPlainOldData)

void AudioMeter::SetMeterScaleLabelColor(const struct FLinearColor& InValue_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioWidgets.AudioMeter.SetMeterScaleLabelColor"));

	AudioMeter_SetMeterScaleLabelColor_Params params;
	params.InValue_69 = InValue_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AudioWidgets.AudioMeter.SetMeterScaleColor
// (Final, Native, Public, HasDefaults, BlueprintCallable)
// Parameters:
// struct FLinearColor            InValue_69                     (Parm, ZeroConstructor, IsPlainOldData)

void AudioMeter::SetMeterScaleColor(const struct FLinearColor& InValue_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioWidgets.AudioMeter.SetMeterScaleColor"));

	AudioMeter_SetMeterScaleColor_Params params;
	params.InValue_69 = InValue_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AudioWidgets.AudioMeter.SetMeterPeakColor
// (Final, Native, Public, HasDefaults, BlueprintCallable)
// Parameters:
// struct FLinearColor            InValue_69                     (Parm, ZeroConstructor, IsPlainOldData)

void AudioMeter::SetMeterPeakColor(const struct FLinearColor& InValue_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioWidgets.AudioMeter.SetMeterPeakColor"));

	AudioMeter_SetMeterPeakColor_Params params;
	params.InValue_69 = InValue_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AudioWidgets.AudioMeter.SetMeterClippingColor
// (Final, Native, Public, HasDefaults, BlueprintCallable)
// Parameters:
// struct FLinearColor            InValue_69                     (Parm, ZeroConstructor, IsPlainOldData)

void AudioMeter::SetMeterClippingColor(const struct FLinearColor& InValue_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioWidgets.AudioMeter.SetMeterClippingColor"));

	AudioMeter_SetMeterClippingColor_Params params;
	params.InValue_69 = InValue_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AudioWidgets.AudioMeter.SetMeterChannelInfo
// (Final, Native, Public, HasOutParms, BlueprintCallable)
// Parameters:
// TArray<struct FMeterChannelInfo> InMeterChannelInfo_69          (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)

void AudioMeter::SetMeterChannelInfo(TArray<struct FMeterChannelInfo> InMeterChannelInfo_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioWidgets.AudioMeter.SetMeterChannelInfo"));

	AudioMeter_SetMeterChannelInfo_Params params;
	params.InMeterChannelInfo_69 = InMeterChannelInfo_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AudioWidgets.AudioMeter.SetMeterBackgroundColor
// (Final, Native, Public, HasDefaults, BlueprintCallable)
// Parameters:
// struct FLinearColor            InValue_69                     (Parm, ZeroConstructor, IsPlainOldData)

void AudioMeter::SetMeterBackgroundColor(const struct FLinearColor& InValue_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioWidgets.AudioMeter.SetMeterBackgroundColor"));

	AudioMeter_SetMeterBackgroundColor_Params params;
	params.InValue_69 = InValue_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AudioWidgets.AudioMeter.SetBackgroundColor
// (Final, Native, Public, HasDefaults, BlueprintCallable)
// Parameters:
// struct FLinearColor            InValue_69                     (Parm, ZeroConstructor, IsPlainOldData)

void AudioMeter::SetBackgroundColor(const struct FLinearColor& InValue_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioWidgets.AudioMeter.SetBackgroundColor"));

	AudioMeter_SetBackgroundColor_Params params;
	params.InValue_69 = InValue_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// DelegateFunction AudioWidgets.AudioMeter.GetMeterChannelInfo__DelegateSignature
// (Public, Delegate)
// Parameters:
// TArray<struct FMeterChannelInfo> ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

TArray<struct FMeterChannelInfo> AudioMeter::GetMeterChannelInfo__DelegateSignature()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("DelegateFunction AudioWidgets.AudioMeter.GetMeterChannelInfo__DelegateSignature"));

	AudioMeter_GetMeterChannelInfo__DelegateSignature_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AudioWidgets.AudioMeter.GetMeterChannelInfo
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// TArray<struct FMeterChannelInfo> ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

TArray<struct FMeterChannelInfo> AudioMeter::GetMeterChannelInfo()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioWidgets.AudioMeter.GetMeterChannelInfo"));

	AudioMeter_GetMeterChannelInfo_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AudioWidgets.AudioRadialSlider.SetWidgetLayout
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// TEnumAsByte<EAudioRadialSliderLayout> InLayout_69                    (Parm, ZeroConstructor, IsPlainOldData)

void AudioRadialSlider::SetWidgetLayout(TEnumAsByte<EAudioRadialSliderLayout> InLayout_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioWidgets.AudioRadialSlider.SetWidgetLayout"));

	AudioRadialSlider_SetWidgetLayout_Params params;
	params.InLayout_69 = InLayout_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AudioWidgets.AudioRadialSlider.SetValueTextReadOnly
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// bool                           bIsReadOnly_69                 (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void AudioRadialSlider::SetValueTextReadOnly(bool bIsReadOnly_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioWidgets.AudioRadialSlider.SetValueTextReadOnly"));

	AudioRadialSlider_SetValueTextReadOnly_Params params;
	params.bIsReadOnly_69 = bIsReadOnly_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AudioWidgets.AudioRadialSlider.SetUnitsTextReadOnly
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// bool                           bIsReadOnly_69                 (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void AudioRadialSlider::SetUnitsTextReadOnly(bool bIsReadOnly_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioWidgets.AudioRadialSlider.SetUnitsTextReadOnly"));

	AudioRadialSlider_SetUnitsTextReadOnly_Params params;
	params.bIsReadOnly_69 = bIsReadOnly_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AudioWidgets.AudioRadialSlider.SetUnitsText
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// struct FText                   Units_69                       (ConstParm, Parm)

void AudioRadialSlider::SetUnitsText(const struct FText& Units_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioWidgets.AudioRadialSlider.SetUnitsText"));

	AudioRadialSlider_SetUnitsText_Params params;
	params.Units_69 = Units_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AudioWidgets.AudioRadialSlider.SetTextLabelBackgroundColor
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// struct FSlateColor             InColor_69                     (Parm)

void AudioRadialSlider::SetTextLabelBackgroundColor(const struct FSlateColor& InColor_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioWidgets.AudioRadialSlider.SetTextLabelBackgroundColor"));

	AudioRadialSlider_SetTextLabelBackgroundColor_Params params;
	params.InColor_69 = InColor_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AudioWidgets.AudioRadialSlider.SetSliderThickness
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// float                          InThickness_69                 (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void AudioRadialSlider::SetSliderThickness(float InThickness_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioWidgets.AudioRadialSlider.SetSliderThickness"));

	AudioRadialSlider_SetSliderThickness_Params params;
	params.InThickness_69 = InThickness_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AudioWidgets.AudioRadialSlider.SetSliderProgressColor
// (Final, Native, Public, HasDefaults, BlueprintCallable)
// Parameters:
// struct FLinearColor            InValue_69                     (Parm, ZeroConstructor, IsPlainOldData)

void AudioRadialSlider::SetSliderProgressColor(const struct FLinearColor& InValue_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioWidgets.AudioRadialSlider.SetSliderProgressColor"));

	AudioRadialSlider_SetSliderProgressColor_Params params;
	params.InValue_69 = InValue_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AudioWidgets.AudioRadialSlider.SetSliderBarColor
// (Final, Native, Public, HasDefaults, BlueprintCallable)
// Parameters:
// struct FLinearColor            InValue_69                     (Parm, ZeroConstructor, IsPlainOldData)

void AudioRadialSlider::SetSliderBarColor(const struct FLinearColor& InValue_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioWidgets.AudioRadialSlider.SetSliderBarColor"));

	AudioRadialSlider_SetSliderBarColor_Params params;
	params.InValue_69 = InValue_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AudioWidgets.AudioRadialSlider.SetShowUnitsText
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// bool                           bShowUnitsText_69              (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void AudioRadialSlider::SetShowUnitsText(bool bShowUnitsText_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioWidgets.AudioRadialSlider.SetShowUnitsText"));

	AudioRadialSlider_SetShowUnitsText_Params params;
	params.bShowUnitsText_69 = bShowUnitsText_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AudioWidgets.AudioRadialSlider.SetShowLabelOnlyOnHover
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// bool                           bShowLabelOnlyOnHover_69       (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void AudioRadialSlider::SetShowLabelOnlyOnHover(bool bShowLabelOnlyOnHover_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioWidgets.AudioRadialSlider.SetShowLabelOnlyOnHover"));

	AudioRadialSlider_SetShowLabelOnlyOnHover_Params params;
	params.bShowLabelOnlyOnHover_69 = bShowLabelOnlyOnHover_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AudioWidgets.AudioRadialSlider.SetOutputRange
// (Final, Native, Public, HasDefaults, BlueprintCallable)
// Parameters:
// struct FVector2D               InOutputRange_69               (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void AudioRadialSlider::SetOutputRange(const struct FVector2D& InOutputRange_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioWidgets.AudioRadialSlider.SetOutputRange"));

	AudioRadialSlider_SetOutputRange_Params params;
	params.InOutputRange_69 = InOutputRange_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AudioWidgets.AudioRadialSlider.SetHandStartEndRatio
// (Final, Native, Public, HasDefaults, BlueprintCallable)
// Parameters:
// struct FVector2D               InHandStartEndRatio_69         (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void AudioRadialSlider::SetHandStartEndRatio(const struct FVector2D& InHandStartEndRatio_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioWidgets.AudioRadialSlider.SetHandStartEndRatio"));

	AudioRadialSlider_SetHandStartEndRatio_Params params;
	params.InHandStartEndRatio_69 = InHandStartEndRatio_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AudioWidgets.AudioRadialSlider.SetCenterBackgroundColor
// (Final, Native, Public, HasDefaults, BlueprintCallable)
// Parameters:
// struct FLinearColor            InValue_69                     (Parm, ZeroConstructor, IsPlainOldData)

void AudioRadialSlider::SetCenterBackgroundColor(const struct FLinearColor& InValue_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioWidgets.AudioRadialSlider.SetCenterBackgroundColor"));

	AudioRadialSlider_SetCenterBackgroundColor_Params params;
	params.InValue_69 = InValue_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AudioWidgets.AudioSliderBase.SetWidgetBackgroundColor
// (Final, Native, Public, HasDefaults, BlueprintCallable)
// Parameters:
// struct FLinearColor            InValue_69                     (Parm, ZeroConstructor, IsPlainOldData)

void AudioSliderBase::SetWidgetBackgroundColor(const struct FLinearColor& InValue_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioWidgets.AudioSliderBase.SetWidgetBackgroundColor"));

	AudioSliderBase_SetWidgetBackgroundColor_Params params;
	params.InValue_69 = InValue_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AudioWidgets.AudioSliderBase.SetValueTextReadOnly
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// bool                           bIsReadOnly_69                 (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void AudioSliderBase::SetValueTextReadOnly(bool bIsReadOnly_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioWidgets.AudioSliderBase.SetValueTextReadOnly"));

	AudioSliderBase_SetValueTextReadOnly_Params params;
	params.bIsReadOnly_69 = bIsReadOnly_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AudioWidgets.AudioSliderBase.SetUnitsTextReadOnly
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// bool                           bIsReadOnly_69                 (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void AudioSliderBase::SetUnitsTextReadOnly(bool bIsReadOnly_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioWidgets.AudioSliderBase.SetUnitsTextReadOnly"));

	AudioSliderBase_SetUnitsTextReadOnly_Params params;
	params.bIsReadOnly_69 = bIsReadOnly_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AudioWidgets.AudioSliderBase.SetUnitsText
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// struct FText                   Units_69                       (ConstParm, Parm)

void AudioSliderBase::SetUnitsText(const struct FText& Units_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioWidgets.AudioSliderBase.SetUnitsText"));

	AudioSliderBase_SetUnitsText_Params params;
	params.Units_69 = Units_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AudioWidgets.AudioSliderBase.SetTextLabelBackgroundColor
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// struct FSlateColor             InColor_69                     (Parm)

void AudioSliderBase::SetTextLabelBackgroundColor(const struct FSlateColor& InColor_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioWidgets.AudioSliderBase.SetTextLabelBackgroundColor"));

	AudioSliderBase_SetTextLabelBackgroundColor_Params params;
	params.InColor_69 = InColor_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AudioWidgets.AudioSliderBase.SetSliderThumbColor
// (Final, Native, Public, HasDefaults, BlueprintCallable)
// Parameters:
// struct FLinearColor            InValue_69                     (Parm, ZeroConstructor, IsPlainOldData)

void AudioSliderBase::SetSliderThumbColor(const struct FLinearColor& InValue_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioWidgets.AudioSliderBase.SetSliderThumbColor"));

	AudioSliderBase_SetSliderThumbColor_Params params;
	params.InValue_69 = InValue_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AudioWidgets.AudioSliderBase.SetSliderBarColor
// (Final, Native, Public, HasDefaults, BlueprintCallable)
// Parameters:
// struct FLinearColor            InValue_69                     (Parm, ZeroConstructor, IsPlainOldData)

void AudioSliderBase::SetSliderBarColor(const struct FLinearColor& InValue_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioWidgets.AudioSliderBase.SetSliderBarColor"));

	AudioSliderBase_SetSliderBarColor_Params params;
	params.InValue_69 = InValue_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AudioWidgets.AudioSliderBase.SetSliderBackgroundColor
// (Final, Native, Public, HasDefaults, BlueprintCallable)
// Parameters:
// struct FLinearColor            InValue_69                     (Parm, ZeroConstructor, IsPlainOldData)

void AudioSliderBase::SetSliderBackgroundColor(const struct FLinearColor& InValue_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioWidgets.AudioSliderBase.SetSliderBackgroundColor"));

	AudioSliderBase_SetSliderBackgroundColor_Params params;
	params.InValue_69 = InValue_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AudioWidgets.AudioSliderBase.SetShowUnitsText
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// bool                           bShowUnitsText_69              (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void AudioSliderBase::SetShowUnitsText(bool bShowUnitsText_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioWidgets.AudioSliderBase.SetShowUnitsText"));

	AudioSliderBase_SetShowUnitsText_Params params;
	params.bShowUnitsText_69 = bShowUnitsText_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AudioWidgets.AudioSliderBase.SetShowLabelOnlyOnHover
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// bool                           bShowLabelOnlyOnHover_69       (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void AudioSliderBase::SetShowLabelOnlyOnHover(bool bShowLabelOnlyOnHover_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioWidgets.AudioSliderBase.SetShowLabelOnlyOnHover"));

	AudioSliderBase_SetShowLabelOnlyOnHover_Params params;
	params.bShowLabelOnlyOnHover_69 = bShowLabelOnlyOnHover_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AudioWidgets.AudioSliderBase.GetOutputValue
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// float                          LinValue_69                    (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// float                          ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

float AudioSliderBase::GetOutputValue(float LinValue_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioWidgets.AudioSliderBase.GetOutputValue"));

	AudioSliderBase_GetOutputValue_Params params;
	params.LinValue_69 = LinValue_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AudioWidgets.AudioSliderBase.GetLinValue
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// float                          OutputValue_69                 (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// float                          ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

float AudioSliderBase::GetLinValue(float OutputValue_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioWidgets.AudioSliderBase.GetLinValue"));

	AudioSliderBase_GetLinValue_Params params;
	params.OutputValue_69 = OutputValue_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Classes
//---------------------------------------------------------------------------

// Class CRD_HSRuntime.FortAthenaMutator_HenchmanSpawner
// 0x0008 (0x0458 - 0x0450)
class FortAthenaMutator_HenchmanSpawner : public FortAthenaMutator_GameModeBase
{
public:
	unsigned char                                      UnknownData00[0x8];                                       // 0x0450(0x0008) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CRD_HSRuntime.FortAthenaMutator_HenchmanSpawner"));
		
		return ptr;
	}

};


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function CowCatcherModCodeRuntime.CowCatcherBarricadeBase.OnPlacementBlockedByPawnChanged
struct CowCatcherBarricadeBase_OnPlacementBlockedByPawnChanged_Params
{
	bool                                               bBlockedByPawn_69;                                        // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function CowCatcherModCodeRuntime.CowCatcherBarricadeBase.BeginCheckingForTouchingPawns
struct CowCatcherBarricadeBase_BeginCheckingForTouchingPawns_Params
{
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

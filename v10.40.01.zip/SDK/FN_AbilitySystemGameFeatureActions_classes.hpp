#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Classes
//---------------------------------------------------------------------------

// Class AbilitySystemGameFeatureActions.GameFeatureAction_AddAttributeDefaults
// 0x0010 (0x0038 - 0x0028)
class GameFeatureAction_AddAttributeDefaults : public GameFeatureAction
{
public:
	TArray<struct FSoftObjectPath>                     AttribDefaultTableNames_69;                               // 0x0028(0x0010) (Edit, ZeroConstructor)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AbilitySystemGameFeatureActions.GameFeatureAction_AddAttributeDefaults"));
		
		return ptr;
	}

};


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

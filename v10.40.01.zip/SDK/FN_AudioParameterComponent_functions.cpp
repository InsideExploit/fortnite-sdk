// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Functions
//---------------------------------------------------------------------------

// Function AudioParameterComponent.AudioParameterComponent_C.UpdateRootParameterComponent
// (Private, BlueprintCallable, BlueprintEvent)

void AudioParameterComponent_C::UpdateRootParameterComponent()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioParameterComponent.AudioParameterComponent_C.UpdateRootParameterComponent"));

	AudioParameterComponent_C_UpdateRootParameterComponent_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AudioParameterComponent.AudioParameterComponent_C.GetParameters
// (Public, HasOutParms, BlueprintCallable, BlueprintEvent, BlueprintPure)
// Parameters:
// TArray<struct FAudioParameter> Parameters_1                   (Parm, OutParm)

void AudioParameterComponent_C::GetParameters(TArray<struct FAudioParameter>* Parameters_1)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioParameterComponent.AudioParameterComponent_C.GetParameters"));

	AudioParameterComponent_C_GetParameters_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (Parameters_1 != nullptr)
		*Parameters_1 = params.Parameters_1;
}


// Function AudioParameterComponent.AudioParameterComponent_C.SetIntParameterInternal
// (Private, BlueprintCallable, BlueprintEvent)
// Parameters:
// struct FName                   Name_1                         (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
// int                            Value_1                        (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)

void AudioParameterComponent_C::SetIntParameterInternal(const struct FName& Name_1, int Value_1)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioParameterComponent.AudioParameterComponent_C.SetIntParameterInternal"));

	AudioParameterComponent_C_SetIntParameterInternal_Params params;
	params.Name_1 = Name_1;
	params.Value_1 = Value_1;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AudioParameterComponent.AudioParameterComponent_C.SetBoolParameterInternal
// (Private, BlueprintCallable, BlueprintEvent)
// Parameters:
// struct FName                   Name_1                         (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
// bool                           Value_1                        (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)

void AudioParameterComponent_C::SetBoolParameterInternal(const struct FName& Name_1, bool Value_1)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioParameterComponent.AudioParameterComponent_C.SetBoolParameterInternal"));

	AudioParameterComponent_C_SetBoolParameterInternal_Params params;
	params.Name_1 = Name_1;
	params.Value_1 = Value_1;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AudioParameterComponent.AudioParameterComponent_C.SetFloatParameterInternal
// (Private, BlueprintCallable, BlueprintEvent)
// Parameters:
// struct FName                   Name_1                         (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
// double                         Value_1                        (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)

void AudioParameterComponent_C::SetFloatParameterInternal(const struct FName& Name_1, double Value_1)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioParameterComponent.AudioParameterComponent_C.SetFloatParameterInternal"));

	AudioParameterComponent_C_SetFloatParameterInternal_Params params;
	params.Name_1 = Name_1;
	params.Value_1 = Value_1;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AudioParameterComponent.AudioParameterComponent_C.GetRootParameterComponent
// (Private, HasOutParms, BlueprintCallable, BlueprintEvent, BlueprintPure)
// Parameters:
// class AudioParameterComponent_C* Component_1                    (Parm, OutParm, ZeroConstructor, InstancedReference)

void AudioParameterComponent_C::GetRootParameterComponent(class AudioParameterComponent_C** Component_1)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioParameterComponent.AudioParameterComponent_C.GetRootParameterComponent"));

	AudioParameterComponent_C_GetRootParameterComponent_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (Component_1 != nullptr)
		*Component_1 = params.Component_1;
}


// Function AudioParameterComponent.AudioParameterComponent_C.FindOrAddGetIndex
// (Private, HasOutParms, HasDefaults, BlueprintCallable, BlueprintEvent)
// Parameters:
// struct FName                   Name_1                         (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
// int                            Index_1                        (Parm, OutParm, ZeroConstructor, IsPlainOldData)

void AudioParameterComponent_C::FindOrAddGetIndex(const struct FName& Name_1, int* Index_1)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioParameterComponent.AudioParameterComponent_C.FindOrAddGetIndex"));

	AudioParameterComponent_C_FindOrAddGetIndex_Params params;
	params.Name_1 = Name_1;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (Index_1 != nullptr)
		*Index_1 = params.Index_1;
}


// Function AudioParameterComponent.AudioParameterComponent_C.SetIntParameter
// (Public, BlueprintCallable, BlueprintEvent)
// Parameters:
// struct FName                   Name_1                         (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
// int                            Value_1                        (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)

void AudioParameterComponent_C::SetIntParameter(const struct FName& Name_1, int Value_1)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioParameterComponent.AudioParameterComponent_C.SetIntParameter"));

	AudioParameterComponent_C_SetIntParameter_Params params;
	params.Name_1 = Name_1;
	params.Value_1 = Value_1;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AudioParameterComponent.AudioParameterComponent_C.SetBoolParameter
// (Public, BlueprintCallable, BlueprintEvent)
// Parameters:
// struct FName                   Name_1                         (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
// bool                           Value_1                        (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)

void AudioParameterComponent_C::SetBoolParameter(const struct FName& Name_1, bool Value_1)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioParameterComponent.AudioParameterComponent_C.SetBoolParameter"));

	AudioParameterComponent_C_SetBoolParameter_Params params;
	params.Name_1 = Name_1;
	params.Value_1 = Value_1;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AudioParameterComponent.AudioParameterComponent_C.SetFloatParameter
// (Public, BlueprintCallable, BlueprintEvent)
// Parameters:
// struct FName                   Name_1                         (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
// double                         Value_1                        (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)

void AudioParameterComponent_C::SetFloatParameter(const struct FName& Name_1, double Value_1)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioParameterComponent.AudioParameterComponent_C.SetFloatParameter"));

	AudioParameterComponent_C_SetFloatParameter_Params params;
	params.Name_1 = Name_1;
	params.Value_1 = Value_1;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

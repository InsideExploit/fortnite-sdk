// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Functions
//---------------------------------------------------------------------------

// Function ChromePlayerUI.ChromePlayerInfoWidget.OnPlayerStateSet
// (Event, Protected, BlueprintEvent)
// Parameters:
// class FortPlayerStateAthena*   InPlayerState_69               (Parm, ZeroConstructor)

void ChromePlayerInfoWidget::OnPlayerStateSet(class FortPlayerStateAthena* InPlayerState_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ChromePlayerUI.ChromePlayerInfoWidget.OnPlayerStateSet"));

	ChromePlayerInfoWidget_OnPlayerStateSet_Params params;
	params.InPlayerState_69 = InPlayerState_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ChromePlayerUI.ChromePlayerInfoWidget.OnPlayerDeadStateChanged
// (Event, Protected, BlueprintEvent)
// Parameters:
// class FortPlayerStateAthena*   PlayerState_69                 (Parm, ZeroConstructor)
// bool                           bIsDead_69                     (Parm, ZeroConstructor, IsPlainOldData)

void ChromePlayerInfoWidget::OnPlayerDeadStateChanged(class FortPlayerStateAthena* PlayerState_69, bool bIsDead_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ChromePlayerUI.ChromePlayerInfoWidget.OnPlayerDeadStateChanged"));

	ChromePlayerInfoWidget_OnPlayerDeadStateChanged_Params params;
	params.PlayerState_69 = PlayerState_69;
	params.bIsDead_69 = bIsDead_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

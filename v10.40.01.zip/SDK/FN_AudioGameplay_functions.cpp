// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Functions
//---------------------------------------------------------------------------

// Function AudioGameplay.AudioGameplayCondition.ConditionMet_Position
// (RequiredAPI, Native, Event, Public, HasOutParms, HasDefaults, BlueprintCallable, BlueprintEvent, BlueprintPure, Const)
// Parameters:
// struct FVector                 Position_69                    (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool AudioGameplayCondition::ConditionMet_Position(const struct FVector& Position_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioGameplay.AudioGameplayCondition.ConditionMet_Position"));

	AudioGameplayCondition_ConditionMet_Position_Params params;
	params.Position_69 = Position_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AudioGameplay.AudioGameplayCondition.ConditionMet
// (RequiredAPI, Native, Event, Public, BlueprintCallable, BlueprintEvent, BlueprintPure, Const)
// Parameters:
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool AudioGameplayCondition::ConditionMet()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioGameplay.AudioGameplayCondition.ConditionMet"));

	AudioGameplayCondition_ConditionMet_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AudioGameplay.AudioGameplayVolumeInteraction.OnListenerExit
// (RequiredAPI, Native, Event, Public, BlueprintCallable, BlueprintEvent)

void AudioGameplayVolumeInteraction::OnListenerExit()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioGameplay.AudioGameplayVolumeInteraction.OnListenerExit"));

	AudioGameplayVolumeInteraction_OnListenerExit_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AudioGameplay.AudioGameplayVolumeInteraction.OnListenerEnter
// (RequiredAPI, Native, Event, Public, BlueprintCallable, BlueprintEvent)

void AudioGameplayVolumeInteraction::OnListenerEnter()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioGameplay.AudioGameplayVolumeInteraction.OnListenerEnter"));

	AudioGameplayVolumeInteraction_OnListenerEnter_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function CrewUI.BattlePassCrewPurchaseButton.OnCurrencyUpdated
struct BattlePassCrewPurchaseButton_OnCurrencyUpdated_Params
{
};

// Function CrewUI.BattlePassCrewPurchaseContainer.OnTriggerIntroAnimation
struct BattlePassCrewPurchaseContainer_OnTriggerIntroAnimation_Params
{
	bool                                               bCanClaimRewards_69;                                      // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function CrewUI.BattlePassCrewPurchaseContainer.OnContentStateUpdated
struct BattlePassCrewPurchaseContainer_OnContentStateUpdated_Params
{
	EBattlePassCrewContentState                        InState_69;                                               // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bInScreenOpened_69;                                       // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function CrewUI.BattlePassPurchaseScreen.OnShowNavButtonNotification
struct BattlePassPurchaseScreen_OnShowNavButtonNotification_Params
{
	bool                                               bShowNotification_69;                                     // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function CrewUI.BattlePassPurchaseScreen.OnSetScreenInteractable
struct BattlePassPurchaseScreen_OnSetScreenInteractable_Params
{
	bool                                               bInteractable_69;                                         // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function CrewUI.BattlePassPurchaseScreen.OnSetNavButtonNotificationText
struct BattlePassPurchaseScreen_OnSetNavButtonNotificationText_Params
{
	struct FText                                       NotificationText_69;                                      // (ConstParm, Parm, OutParm, ReferenceParm)
};

// Function CrewUI.BattlePassPurchaseScreen.OnPurchaseStateChanged
struct BattlePassPurchaseScreen_OnPurchaseStateChanged_Params
{
	EBattlePassPurchaseState                           InCurrentState_69;                                        // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function CrewUI.BattlePassPurchaseScreen.OnPurchaseConfirmed
struct BattlePassPurchaseScreen_OnPurchaseConfirmed_Params
{
};

// Function CrewUI.CrewMultiSubscriptionAlertModal.OnSetHowToCancelURL
struct CrewMultiSubscriptionAlertModal_OnSetHowToCancelURL_Params
{
	struct FString                                     MoreInfoUrl_69;                                           // (Parm, ZeroConstructor)
};

// Function CrewUI.CrewPriceChangeAcknowledgeModal.OnSetPriceChangeAcknowledgeTitle
struct CrewPriceChangeAcknowledgeModal_OnSetPriceChangeAcknowledgeTitle_Params
{
	struct FText                                       Title_69;                                                 // (ConstParm, Parm, OutParm, ReferenceParm)
};

// Function CrewUI.CrewPriceChangeAcknowledgeModal.OnSetPriceChangeAcknowledgeMoreInfoUrl
struct CrewPriceChangeAcknowledgeModal_OnSetPriceChangeAcknowledgeMoreInfoUrl_Params
{
	struct FText                                       MoreInfoUrl_69;                                           // (ConstParm, Parm, OutParm, ReferenceParm)
};

// Function CrewUI.CrewPriceChangeAcknowledgeModal.OnSetPriceChangeAcknowledgeMoreInfoText
struct CrewPriceChangeAcknowledgeModal_OnSetPriceChangeAcknowledgeMoreInfoText_Params
{
	struct FText                                       ConfirmButtonText_69;                                     // (ConstParm, Parm, OutParm, ReferenceParm)
};

// Function CrewUI.CrewPriceChangeAcknowledgeModal.OnSetPriceChangeAcknowledgeConfirmButtonText
struct CrewPriceChangeAcknowledgeModal_OnSetPriceChangeAcknowledgeConfirmButtonText_Params
{
	struct FText                                       ConfirmButtonText_69;                                     // (ConstParm, Parm, OutParm, ReferenceParm)
};

// Function CrewUI.CrewPriceChangeAcknowledgeModal.OnSetPriceChangeAcknowledgeCheckboxText
struct CrewPriceChangeAcknowledgeModal_OnSetPriceChangeAcknowledgeCheckboxText_Params
{
	struct FText                                       CheckboxText_69;                                          // (ConstParm, Parm, OutParm, ReferenceParm)
};

// Function CrewUI.CrewPriceChangeAcknowledgeModal.OnSetPriceChangeAcknowledgeCancelSubscriptionButtonText
struct CrewPriceChangeAcknowledgeModal_OnSetPriceChangeAcknowledgeCancelSubscriptionButtonText_Params
{
	struct FText                                       CancelSubscriptionButtonText_69;                          // (ConstParm, Parm, OutParm, ReferenceParm)
};

// Function CrewUI.CrewPriceChangeAcknowledgeModal.OnSetPriceChangeAcknowledgeBodyText
struct CrewPriceChangeAcknowledgeModal_OnSetPriceChangeAcknowledgeBodyText_Params
{
	struct FText                                       BodyText_69;                                              // (ConstParm, Parm, OutParm, ReferenceParm)
};

// Function CrewUI.CrewPriceChangeAcknowledgeModal.OnSetPriceChangeAcknowledgeBodyTable
struct CrewPriceChangeAcknowledgeModal_OnSetPriceChangeAcknowledgeBodyTable_Params
{
	TArray<struct FCrewTableRow>                       PriceChangeByRegionRows_69;                               // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
};

// Function CrewUI.CrewPriceChangeAcknowledgeModal.OnModalBackout
struct CrewPriceChangeAcknowledgeModal_OnModalBackout_Params
{
};

// Function CrewUI.CrewPriceChangeAcknowledgeModal.ExitModal
struct CrewPriceChangeAcknowledgeModal_ExitModal_Params
{
};

// Function CrewUI.CrewPurchaseScreen.OnUserInformationTextsUpdated
struct CrewPurchaseScreen_OnUserInformationTextsUpdated_Params
{
	struct FText                                       UserInformationText1_69;                                  // (ConstParm, Parm, OutParm, ReferenceParm)
	struct FText                                       UserInformationText2_69;                                  // (ConstParm, Parm, OutParm, ReferenceParm)
	EMcpSubscriptionState                              SubscriptionState_69;                                     // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function CrewUI.CrewPurchaseScreen.OnUpdateVBuckRefundVisibility
struct CrewPurchaseScreen_OnUpdateVBuckRefundVisibility_Params
{
	bool                                               bVisible_69;                                              // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function CrewUI.CrewPurchaseScreen.OnUpdatePurchaseButtonState
struct CrewPurchaseScreen_OnUpdatePurchaseButtonState_Params
{
	ECrewPurchaseButtonState                           ButtonState_69;                                           // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function CrewUI.CrewPurchaseScreen.OnShowNavButtonNotification
struct CrewPurchaseScreen_OnShowNavButtonNotification_Params
{
	bool                                               bShowNotification_69;                                     // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function CrewUI.CrewPurchaseScreen.OnSetNavButtonNotificationText
struct CrewPurchaseScreen_OnSetNavButtonNotificationText_Params
{
	struct FText                                       NotificationText_69;                                      // (ConstParm, Parm, OutParm, ReferenceParm)
};

// Function CrewUI.CrewPurchaseScreen.OnContainerTabVisibilityUpdated
struct CrewPurchaseScreen_OnContainerTabVisibilityUpdated_Params
{
	bool                                               bTabsVisible_69;                                          // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	float                                              SpacingAdjustmentForTabs_69;                              // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function CrewUI.CrewPurchaseScreen.EndProgress
struct CrewPurchaseScreen_EndProgress_Params
{
};

// Function CrewUI.CrewPurchaseScreen.BeginProgress
struct CrewPurchaseScreen_BeginProgress_Params
{
	struct FText                                       ProgressLabel_69;                                         // (ConstParm, Parm, OutParm, ReferenceParm)
};

// Function CrewUI.CrewRewardTile.OnUpdateOwnedState
struct CrewRewardTile_OnUpdateOwnedState_Params
{
	bool                                               bOwned_69;                                                // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function CrewUI.CrewRewardTile.OnStartingDownloadTileImage
struct CrewRewardTile_OnStartingDownloadTileImage_Params
{
};

// Function CrewUI.CrewRewardTile.OnDownloadTileImageComplete
struct CrewRewardTile_OnDownloadTileImageComplete_Params
{
	class Texture2D*                                   Texture_69;                                               // (Parm, ZeroConstructor)
};

// Function CrewUI.CrewRewardTile.IsMonthlyBenefit
struct CrewRewardTile_IsMonthlyBenefit_Params
{
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CrewUI.CrewSubscriptionContentContainer.OnTabSelected
struct CrewSubscriptionContentContainer_OnTabSelected_Params
{
	int                                                TabIndex_69;                                              // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function CrewUI.CrewTileDetailsTag.OnTagSetup
struct CrewTileDetailsTag_OnTagSetup_Params
{
	ECrewDetailsTag                                    RewardTag_69;                                             // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bIsOwnedTag_69;                                           // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function CrewUI.FortProgressiveScreenBase.BP_OnContainerTabVisibilityUpdated
struct FortProgressiveScreenBase_BP_OnContainerTabVisibilityUpdated_Params
{
	bool                                               bTabsVisible_69;                                          // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	float                                              SpacingAdjustmentForTabs_69;                              // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function CrewUI.FortProgressiveItemScreen.OnUpdateSubscriptionState
struct FortProgressiveItemScreen_OnUpdateSubscriptionState_Params
{
	bool                                               bSubscribed_69;                                           // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function CrewUI.FortProgressiveItemScreen.OnSetIsSoloScreen
struct FortProgressiveItemScreen_OnSetIsSoloScreen_Params
{
	bool                                               bInIsSoloScreen_69;                                       // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function CrewUI.FortProgressiveItemScreen.OnItemSelected
struct FortProgressiveItemScreen_OnItemSelected_Params
{
};

// Function CrewUI.FortProgressiveItemScreen.OnErrorStateTextUpdated
struct FortProgressiveItemScreen_OnErrorStateTextUpdated_Params
{
	struct FText                                       ErrorStateText_69;                                        // (ConstParm, Parm, OutParm, ReferenceParm)
};

// Function CrewUI.FortProgressiveItemStateTitleWidget.BP_OnSetHeaderInfo
struct FortProgressiveItemStateTitleWidget_BP_OnSetHeaderInfo_Params
{
	struct FText                                       Subheading_69;                                            // (ConstParm, Parm, OutParm, ReferenceParm)
	bool                                               bSubscribed_69;                                           // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	int                                                UnlockedStages_69;                                        // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	int                                                MaxStages_69;                                             // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function CrewUI.FortProgressiveItemWidget.OnUnhighlighted
struct FortProgressiveItemWidget_OnUnhighlighted_Params
{
};

// Function CrewUI.FortProgressiveItemWidget.OnTileMaterialLoaded
struct FortProgressiveItemWidget_OnTileMaterialLoaded_Params
{
	bool                                               bSubscribed_69;                                           // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function CrewUI.FortProgressiveItemWidget.OnStageItemChanged
struct FortProgressiveItemWidget_OnStageItemChanged_Params
{
	struct FProgressiveStageItemInfo                   InStageItemInfo_69;                                       // (ConstParm, Parm, OutParm, ReferenceParm)
};

// Function CrewUI.FortProgressiveItemWidget.OnPeekStateChanged
struct FortProgressiveItemWidget_OnPeekStateChanged_Params
{
	bool                                               bIsInPeekState_69;                                        // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function CrewUI.FortProgressiveItemWidget.OnHighlighted
struct FortProgressiveItemWidget_OnHighlighted_Params
{
};

// Function CrewUI.FortProgressiveSetDetailsWidget.BP_OnUpdateSetDetails
struct FortProgressiveSetDetailsWidget_BP_OnUpdateSetDetails_Params
{
	struct FText                                       SetName_69;                                               // (ConstParm, Parm, OutParm, ReferenceParm)
	struct FText                                       ExpiringText_69;                                          // (ConstParm, Parm, OutParm, ReferenceParm)
	bool                                               bCompleted_69;                                            // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function CrewUI.FortProgressiveSetList.ClearSetTiles
struct FortProgressiveSetList_ClearSetTiles_Params
{
};

// Function CrewUI.FortProgressiveSetList.AddSetTile
struct FortProgressiveSetList_AddSetTile_Params
{
	class FortProgressiveSetTile*                      ReturnValue_69;                                           // (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)
};

// Function CrewUI.FortProgressiveSetTile.BP_OnTileMaterialLoaded
struct FortProgressiveSetTile_BP_OnTileMaterialLoaded_Params
{
	bool                                               bSubscribed_69;                                           // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function CrewUI.FortProgressiveSetTile.BP_OnInitializeSetInfo
struct FortProgressiveSetTile_BP_OnInitializeSetInfo_Params
{
	struct FProgressiveSetInfo                         InSetInfo_69;                                             // (ConstParm, Parm, OutParm, ReferenceParm)
	struct FText                                       BottomText_69;                                            // (ConstParm, Parm, OutParm, ReferenceParm)
	struct FText                                       BottomSubtext_69;                                         // (ConstParm, Parm, OutParm, ReferenceParm)
	bool                                               bSubscribed_69;                                           // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function CrewUI.FortProgressiveStageList.SelectStageInDirection
struct FortProgressiveStageList_SelectStageInDirection_Params
{
	int                                                Direction_69;                                             // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function CrewUI.FortProgressiveStageList.ClearStageWidgets
struct FortProgressiveStageList_ClearStageWidgets_Params
{
};

// Function CrewUI.FortProgressiveStageList.AddStageWidget
struct FortProgressiveStageList_AddStageWidget_Params
{
	class FortProgressiveStageWidget*                  ReturnValue_69;                                           // (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)
};

// Function CrewUI.FortProgressiveStageWidget.OnSetTooltipVisible
struct FortProgressiveStageWidget_OnSetTooltipVisible_Params
{
	bool                                               bVisible_69;                                              // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function CrewUI.FortProgressiveStageWidget.OnSetTooltipText
struct FortProgressiveStageWidget_OnSetTooltipText_Params
{
	struct FText                                       InToolTipText_69;                                         // (ConstParm, Parm, OutParm, ReferenceParm)
};

// Function CrewUI.FortProgressiveStageWidget.OnPeekStateChanged
struct FortProgressiveStageWidget_OnPeekStateChanged_Params
{
	bool                                               bIsInPeekState_69;                                        // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function CrewUI.FortProgressiveStageWidget.ClearStageItemWidgets
struct FortProgressiveStageWidget_ClearStageItemWidgets_Params
{
};

// Function CrewUI.FortProgressiveStageWidget.AddStageItemWidget
struct FortProgressiveStageWidget_AddStageItemWidget_Params
{
	class FortProgressiveItemWidget*                   ReturnValue_69;                                           // (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)
};

// Function CrewUI.FortProgressiveTableOfContentsScreen.BP_OnUpdateSubscriptionState
struct FortProgressiveTableOfContentsScreen_BP_OnUpdateSubscriptionState_Params
{
	bool                                               bSubscribed_69;                                           // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function CrewUI.FortProgressiveTableOfContentsScreen.BP_OnUpdateNumTilesAvailable
struct FortProgressiveTableOfContentsScreen_BP_OnUpdateNumTilesAvailable_Params
{
	int                                                NumTiles_69;                                              // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function CrewUI.FortProgressiveTableOfContentsScreen.BP_OnUpdateErrorStateText
struct FortProgressiveTableOfContentsScreen_BP_OnUpdateErrorStateText_Params
{
	struct FText                                       ErrorStateText_69;                                        // (ConstParm, Parm, OutParm, ReferenceParm)
};

// Function CrewUI.FortProgressiveTableOfContentsScreen.BP_OnUpdateBanner
struct FortProgressiveTableOfContentsScreen_BP_OnUpdateBanner_Params
{
	struct FText                                       BannerText_69;                                            // (ConstParm, Parm, OutParm, ReferenceParm)
	bool                                               bAllSetsCompleted_69;                                     // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bSubscribed_69;                                           // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function CrewUI.FortProgressiveTableOfContentsScreen.BP_OnSetDescriptionText
struct FortProgressiveTableOfContentsScreen_BP_OnSetDescriptionText_Params
{
	struct FText                                       ProductDescription_69;                                    // (ConstParm, Parm, OutParm, ReferenceParm)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

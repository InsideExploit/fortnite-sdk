#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Classes
//---------------------------------------------------------------------------

// Class AssetTags.AssetTagsSubsystem
// 0x0000 (0x0030 - 0x0030)
class AssetTagsSubsystem : public EngineSubsystem
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AssetTags.AssetTagsSubsystem"));
		
		return ptr;
	}


	TArray<struct FName> GetCollectionsContainingAssetPtr(class Object_32759* AssetPtr_69);
	TArray<struct FName> GetCollectionsContainingAssetData(const struct FAssetData& AssetData_69);
	TArray<struct FName> GetCollectionsContainingAsset(const struct FName& AssetPathName_69);
	TArray<struct FName> GetCollections();
	TArray<struct FAssetData> GetAssetsInCollection(const struct FName& Name_69);
	bool CollectionExists(const struct FName& Name_69);
};


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

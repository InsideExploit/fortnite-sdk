#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Classes
//---------------------------------------------------------------------------

// Class ControlRig.ControlRig
// 0x0530 (0x0558 - 0x0028)
class ControlRig : public Object_32759
{
public:
	unsigned char                                      UnknownData00[0x1E];                                      // 0x0028(0x001E) MISSED OFFSET
	ERigExecutionType                                  ExecutionType_69;                                         // 0x0046(0x0001) (ZeroConstructor, Transient, IsPlainOldData)
	unsigned char                                      UnknownData01[0x1];                                       // 0x0047(0x0001) MISSED OFFSET
	struct FRigHierarchySettings                       HierarchySettings_69;                                     // 0x0048(0x0004)
	unsigned char                                      UnknownData02[0x4];                                       // 0x004C(0x0004) MISSED OFFSET
	struct FRigVMRuntimeSettings                       VMRuntimeSettings_69;                                     // 0x0050(0x0018)
	TMap<struct FRigElementKey, struct FRigControlElementCustomization> ControlCustomizations_69;                                 // 0x0068(0x0050)
	class RigVM*                                       VM_69;                                                    // 0x00B8(0x0008) (ZeroConstructor)
	TMap<uint32_t, class RigVM*>                       InitializedVMSnapshots_69;                                // 0x00C0(0x0050) (Transient)
	unsigned char                                      UnknownData03[0x8];                                       // 0x0110(0x0008) MISSED OFFSET
	class RigHierarchy*                                DynamicHierarchy_69;                                      // 0x0118(0x0008) (ZeroConstructor)
	unsigned char                                      UnknownData04[0x28];                                      // 0x0120(0x0028) UNKNOWN PROPERTY: SoftObjectProperty ControlRig.ControlRig.GizmoLibrary_69
	unsigned char                                      UnknownData05[0x10];                                      // 0x0148(0x0010) UNKNOWN PROPERTY: ArrayProperty ControlRig.ControlRig.ShapeLibraries_69
	unsigned char                                      UnknownData06[0x10];                                      // 0x0158(0x0010) MISSED OFFSET
	TMap<struct FName, struct FCachedPropertyPath>     InputProperties_69;                                       // 0x0168(0x0050) (Deprecated)
	TMap<struct FName, struct FCachedPropertyPath>     OutputProperties_69;                                      // 0x01B8(0x0050) (Deprecated)
	unsigned char                                      UnknownData07[0xA8];                                      // 0x0208(0x00A8) MISSED OFFSET
	struct FControlRigDrawContainer                    DrawContainer_69;                                         // 0x02B0(0x0018)
	unsigned char                                      UnknownData08[0x18];                                      // 0x02C8(0x0018) MISSED OFFSET
	class AnimationDataSourceRegistry*                 DataSourceRegistry_69;                                    // 0x02E0(0x0008) (ZeroConstructor, Transient)
	TArray<struct FName>                               EventQueue_69;                                            // 0x02E8(0x0010) (ZeroConstructor, Transient)
	unsigned char                                      UnknownData09[0xD0];                                      // 0x02F8(0x00D0) MISSED OFFSET
	struct FRigInfluenceMapPerEvent                    Influences_69;                                            // 0x03C8(0x0060)
	class ControlRig*                                  InteractionRig_69;                                        // 0x0428(0x0008) (BlueprintVisible, ZeroConstructor, Transient)
	class ControlRig*                                  InteractionRigClass_69;                                   // 0x0430(0x0008) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnTemplate, Transient)
	TArray<class AssetUserData*>                       AssetUserData_69;                                         // 0x0438(0x0010) (Edit, ExportObject, ZeroConstructor)
	unsigned char                                      UnknownData10[0xC8];                                      // 0x0448(0x00C8) MISSED OFFSET
	unsigned char                                      UnknownData11[0x1];                                       // 0x0448(0x0001) UNKNOWN PROPERTY: MulticastSparseDelegateProperty ControlRig.ControlRig.OnControlSelected_BP_69
	unsigned char                                      UnknownData12[0x47];                                      // 0x0511(0x0047) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class ControlRig.ControlRig"));
		
		return ptr;
	}


	bool SupportsEvent(const struct FName& InEventName_69);
	bool SetVariableFromString(const struct FName& InVariableName_69, const struct FString& InValue_69);
	void SetInteractionRigClass(class ControlRig* InInteractionRigClass_69);
	void SetInteractionRig(class ControlRig* InInteractionRig_69);
	void SetFramesPerSecond(float InFramesPerSecond_69);
	void SetDeltaTime(float InDeltaTime_69);
	void SetAbsoluteTime(float InAbsoluteTime_69, bool InSetDeltaTimeZero_69);
	void SetAbsoluteAndDeltaTime(float InAbsoluteTime_69, float InDeltaTime_69);
	void SelectControl(const struct FName& InControlName_69, bool bSelect_69);
	void RequestInit();
	void RequestConstruction();
	void OnControlSelectedBP__DelegateSignature(class ControlRig* Rig_69, const struct FRigControlElement& Control_69, bool bSelected_69);
	bool IsControlSelected(const struct FName& InControlName_69);
	class RigVM* GetVM();
	struct FName GetVariableType(const struct FName& InVariableName_69);
	struct FString GetVariableAsString(const struct FName& InVariableName_69);
	TArray<struct FName> GetSupportedEvents();
	TArray<struct FName> GetScriptAccessibleVariables();
	class ControlRig* GetInteractionRigClass();
	class ControlRig* GetInteractionRig();
	class Actor_32759* GetHostingActor();
	class RigHierarchy* GetHierarchy();
	TArray<struct FName> GetEvents();
	float GetCurrentFramesPerSecond();
	float GetAbsoluteTime();
	TArray<class ControlRig*> STATIC_FindControlRigs(class Object_32759* Outer_69, class ControlRig* OptionalClass_69);
	bool ExecuteEvent(const struct FName& InEventName_69);
	bool Execute(EControlRigState State_69, const struct FName& InEventName_69);
	TArray<struct FName> CurrentControlSelection();
	class TransformableControlHandle_32759* CreateTransformableControlHandle(class Object_32759* Outer_69, const struct FName& ControlName_69);
	bool ContainsEvent(const struct FName& InEventName_69);
	bool ClearControlSelection();
	bool CanExecute();
};


// Class ControlRig.RigHierarchy
// 0x02F8 (0x0320 - 0x0028)
class RigHierarchy : public Object_32759
{
public:
	unsigned char                                      UnknownData00[0x60];                                      // 0x0028(0x0060) MISSED OFFSET
	uint16_t                                           TopologyVersion_69;                                       // 0x0088(0x0002) (ZeroConstructor, Transient, IsPlainOldData)
	uint16_t                                           MetadataVersion_69;                                       // 0x008A(0x0002) (ZeroConstructor, Transient, IsPlainOldData)
	uint16_t                                           MetadataTagVersion_69;                                    // 0x008C(0x0002) (ZeroConstructor, Transient, IsPlainOldData)
	bool                                               bEnableDirtyPropagation_69;                               // 0x008E(0x0001) (ZeroConstructor, Transient, IsPlainOldData)
	unsigned char                                      UnknownData01[0x71];                                      // 0x008F(0x0071) MISSED OFFSET
	int                                                TransformStackIndex_69;                                   // 0x0100(0x0004) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData02[0x6C];                                      // 0x0104(0x006C) MISSED OFFSET
	class RigHierarchyController*                      HierarchyController_69;                                   // 0x0170(0x0008) (ZeroConstructor, Transient)
	unsigned char                                      UnknownData03[0x58];                                      // 0x0178(0x0058) MISSED OFFSET
	TMap<struct FRigElementKey, struct FRigElementKey> PreviousNameMap_69;                                       // 0x01D0(0x0050)
	unsigned char                                      UnknownData04[0x80];                                      // 0x0220(0x0080) MISSED OFFSET
	class RigHierarchy*                                HierarchyForCacheValidation_69;                           // 0x02A0(0x0008) (ZeroConstructor, Transient)
	unsigned char                                      UnknownData05[0x78];                                      // 0x02A8(0x0078) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class ControlRig.RigHierarchy"));
		
		return ptr;
	}


	void UnsetCurveValueByIndex(int InElementIndex_69, bool bSetupUndo_69);
	void UnsetCurveValue(const struct FRigElementKey& InKey_69, bool bSetupUndo_69);
	bool SwitchToWorldSpace(const struct FRigElementKey& InChild_69, bool bInitial_69, bool bAffectChildren_69);
	bool SwitchToParent(const struct FRigElementKey& InChild_69, const struct FRigElementKey& InParent_69, bool bInitial_69, bool bAffectChildren_69);
	bool SwitchToDefaultParent(const struct FRigElementKey& InChild_69, bool bInitial_69, bool bAffectChildren_69);
	TArray<struct FRigElementKey> SortKeys(TArray<struct FRigElementKey> InKeys_69);
	bool SetVectorMetadata(const struct FRigElementKey& InItem_69, const struct FName& InMetadataName_69, const struct FVector& InValue_69);
	bool SetVectorArrayMetadata(const struct FRigElementKey& InItem_69, const struct FName& InMetadataName_69, TArray<struct FVector> InValue_69);
	bool SetTransformMetadata(const struct FRigElementKey& InItem_69, const struct FName& InMetadataName_69, const struct FCoreUObject_FTransform& InValue_69);
	bool SetTransformArrayMetadata(const struct FRigElementKey& InItem_69, const struct FName& InMetadataName_69, TArray<struct FCoreUObject_FTransform> InValue_69);
	bool SetTag(const struct FRigElementKey& InItem_69, const struct FName& InTag_69);
	bool SetRotatorMetadata(const struct FRigElementKey& InItem_69, const struct FName& InMetadataName_69, const struct FRotator& InValue_69);
	bool SetRotatorArrayMetadata(const struct FRigElementKey& InItem_69, const struct FName& InMetadataName_69, TArray<struct FRotator> InValue_69);
	bool SetRigElementKeyMetadata(const struct FRigElementKey& InItem_69, const struct FName& InMetadataName_69, const struct FRigElementKey& InValue_69);
	bool SetRigElementKeyArrayMetadata(const struct FRigElementKey& InItem_69, const struct FName& InMetadataName_69, TArray<struct FRigElementKey> InValue_69);
	bool SetQuatMetadata(const struct FRigElementKey& InItem_69, const struct FName& InMetadataName_69, const struct FQuat& InValue_69);
	bool SetQuatArrayMetadata(const struct FRigElementKey& InItem_69, const struct FName& InMetadataName_69, TArray<struct FQuat> InValue_69);
	void SetPose_ForBlueprint(const struct FRigPose& InPose_69);
	bool SetParentWeightArray(const struct FRigElementKey& InChild_69, TArray<struct FRigElementWeight> InWeights_69, bool bInitial_69, bool bAffectChildren_69);
	bool SetParentWeight(const struct FRigElementKey& InChild_69, const struct FRigElementKey& InParent_69, const struct FRigElementWeight& InWeight_69, bool bInitial_69, bool bAffectChildren_69);
	bool SetNameMetadata(const struct FRigElementKey& InItem_69, const struct FName& InMetadataName_69, const struct FName& InValue_69);
	bool SetNameArrayMetadata(const struct FRigElementKey& InItem_69, const struct FName& InMetadataName_69, TArray<struct FName> InValue_69);
	void SetLocalTransformByIndex(int InElementIndex_69, const struct FCoreUObject_FTransform& InTransform_69, bool bInitial_69, bool bAffectChildren_69, bool bSetupUndo_69, bool bPrintPythonCommands_69);
	void SetLocalTransform(const struct FRigElementKey& InKey_69, const struct FCoreUObject_FTransform& InTransform_69, bool bInitial_69, bool bAffectChildren_69, bool bSetupUndo_69, bool bPrintPythonCommands_69);
	bool SetLinearColorMetadata(const struct FRigElementKey& InItem_69, const struct FName& InMetadataName_69, const struct FLinearColor& InValue_69);
	bool SetLinearColorArrayMetadata(const struct FRigElementKey& InItem_69, const struct FName& InMetadataName_69, TArray<struct FLinearColor> InValue_69);
	bool SetInt32Metadata(const struct FRigElementKey& InItem_69, const struct FName& InMetadataName_69, int InValue_69);
	bool SetInt32ArrayMetadata(const struct FRigElementKey& InItem_69, const struct FName& InMetadataName_69, TArray<int> InValue_69);
	void SetGlobalTransformByIndex(int InElementIndex_69, const struct FCoreUObject_FTransform& InTransform_69, bool bInitial_69, bool bAffectChildren_69, bool bSetupUndo_69, bool bPrintPythonCommand_69);
	void SetGlobalTransform(const struct FRigElementKey& InKey_69, const struct FCoreUObject_FTransform& InTransform_69, bool bInitial_69, bool bAffectChildren_69, bool bSetupUndo_69, bool bPrintPythonCommand_69);
	bool SetFloatMetadata(const struct FRigElementKey& InItem_69, const struct FName& InMetadataName_69, float InValue_69);
	bool SetFloatArrayMetadata(const struct FRigElementKey& InItem_69, const struct FName& InMetadataName_69, TArray<float> InValue_69);
	void SetCurveValueByIndex(int InElementIndex_69, float InValue_69, bool bSetupUndo_69);
	void SetCurveValue(const struct FRigElementKey& InKey_69, float InValue_69, bool bSetupUndo_69);
	void SetControlVisibilityByIndex(int InElementIndex_69, bool bVisibility_69);
	void SetControlVisibility(const struct FRigElementKey& InKey_69, bool bVisibility_69);
	void SetControlValueByIndex(int InElementIndex_69, const struct FRigControlValue& InValue_69, ERigControlValueType InValueType_69, bool bSetupUndo_69, bool bPrintPythonCommands_69);
	void SetControlValue(const struct FRigElementKey& InKey_69, const struct FRigControlValue& InValue_69, ERigControlValueType InValueType_69, bool bSetupUndo_69, bool bPrintPythonCommands_69);
	void SetControlShapeTransformByIndex(int InElementIndex_69, const struct FCoreUObject_FTransform& InTransform_69, bool bInitial_69, bool bSetupUndo_69);
	void SetControlShapeTransform(const struct FRigElementKey& InKey_69, const struct FCoreUObject_FTransform& InTransform_69, bool bInitial_69, bool bSetupUndo_69);
	void SetControlSettingsByIndex(int InElementIndex_69, const struct FRigControlSettings& InSettings_69, bool bSetupUndo_69, bool bForce_69, bool bPrintPythonCommands_69);
	void SetControlSettings(const struct FRigElementKey& InKey_69, const struct FRigControlSettings& InSettings_69, bool bSetupUndo_69, bool bForce_69, bool bPrintPythonCommands_69);
	void SetControlPreferredRotatorByIndex(int InElementIndex_69, const struct FRotator& InValue_69, bool bInitial_69, bool bFixEulerFlips_69);
	void SetControlPreferredRotator(const struct FRigElementKey& InKey_69, const struct FRotator& InValue_69, bool bInitial_69, bool bFixEulerFlips_69);
	void SetControlOffsetTransformByIndex(int InElementIndex_69, const struct FCoreUObject_FTransform& InTransform_69, bool bInitial_69, bool bAffectChildren_69, bool bSetupUndo_69, bool bPrintPythonCommands_69);
	void SetControlOffsetTransform(const struct FRigElementKey& InKey_69, const struct FCoreUObject_FTransform& InTransform_69, bool bInitial_69, bool bAffectChildren_69, bool bSetupUndo_69, bool bPrintPythonCommands_69);
	bool SetBoolMetadata(const struct FRigElementKey& InItem_69, const struct FName& InMetadataName_69, bool InValue_69);
	bool SetBoolArrayMetadata(const struct FRigElementKey& InItem_69, const struct FName& InMetadataName_69, TArray<bool> InValue_69);
	void SendAutoKeyEvent(const struct FRigElementKey& InElement_69, float InOffsetInSeconds_69, bool bAsynchronous_69);
	void ResetToDefault();
	void ResetPoseToInitial(ERigElementType InTypeFilter_69);
	void ResetCurveValues();
	void Reset();
	bool RemoveMetadata(const struct FRigElementKey& InItem_69, const struct FName& InMetadataName_69);
	bool RemoveAllMetadata(const struct FRigElementKey& InItem_69);
	int Num();
	struct FRigControlValue STATIC_MakeControlValueFromVector2D(const struct FVector2D& InValue_69);
	struct FRigControlValue STATIC_MakeControlValueFromVector(const struct FVector& InValue_69);
	struct FRigControlValue STATIC_MakeControlValueFromTransformNoScale(const struct FTransformNoScale& InValue_69);
	struct FRigControlValue STATIC_MakeControlValueFromTransform(const struct FCoreUObject_FTransform& InValue_69);
	struct FRigControlValue STATIC_MakeControlValueFromRotator(const struct FRotator& InValue_69);
	struct FRigControlValue STATIC_MakeControlValueFromInt(int InValue_69);
	struct FRigControlValue STATIC_MakeControlValueFromFloat(float InValue_69);
	struct FRigControlValue STATIC_MakeControlValueFromEulerTransform(const struct FEulerTransform& InValue_69);
	struct FRigControlValue STATIC_MakeControlValueFromBool(bool InValue_69);
	bool IsValidIndex(int InElementIndex_69);
	bool IsSelectedByIndex(int InIndex_69);
	bool IsSelected(const struct FRigElementKey& InKey_69);
	bool IsProcedural(const struct FRigElementKey& InKey_69);
	bool IsParentedTo(const struct FRigElementKey& InChild_69, const struct FRigElementKey& InParent_69);
	bool IsCurveValueSetByIndex(int InElementIndex_69);
	bool IsCurveValueSet(const struct FRigElementKey& InKey_69);
	bool IsControllerAvailable();
	bool HasTag(const struct FRigElementKey& InItem_69, const struct FName& InTag_69);
	struct FVector GetVectorMetadata(const struct FRigElementKey& InItem_69, const struct FName& InMetadataName_69, const struct FVector& DefaultValue_69);
	struct FVector STATIC_GetVectorFromControlValue(const struct FRigControlValue& InValue_69);
	TArray<struct FVector> GetVectorArrayMetadata(const struct FRigElementKey& InItem_69, const struct FName& InMetadataName_69);
	struct FVector2D STATIC_GetVector2DFromControlValue(const struct FRigControlValue& InValue_69);
	struct FTransformNoScale STATIC_GetTransformNoScaleFromControlValue(const struct FRigControlValue& InValue_69);
	struct FCoreUObject_FTransform GetTransformMetadata(const struct FRigElementKey& InItem_69, const struct FName& InMetadataName_69, const struct FCoreUObject_FTransform& DefaultValue_69);
	struct FCoreUObject_FTransform STATIC_GetTransformFromControlValue(const struct FRigControlValue& InValue_69);
	TArray<struct FCoreUObject_FTransform> GetTransformArrayMetadata(const struct FRigElementKey& InItem_69, const struct FName& InMetadataName_69);
	TArray<struct FName> GetTags(const struct FRigElementKey& InItem_69);
	TArray<struct FRigElementKey> GetSelectedKeys(ERigElementType InTypeFilter_69);
	struct FRotator GetRotatorMetadata(const struct FRigElementKey& InItem_69, const struct FName& InMetadataName_69, const struct FRotator& DefaultValue_69);
	struct FRotator STATIC_GetRotatorFromControlValue(const struct FRigControlValue& InValue_69);
	TArray<struct FRotator> GetRotatorArrayMetadata(const struct FRigElementKey& InItem_69, const struct FName& InMetadataName_69);
	TArray<struct FRigElementKey> GetRigidBodyKeys(bool bTraverse_69);
	struct FRigElementKey GetRigElementKeyMetadata(const struct FRigElementKey& InItem_69, const struct FName& InMetadataName_69, const struct FRigElementKey& DefaultValue_69);
	TArray<struct FRigElementKey> GetRigElementKeyArrayMetadata(const struct FRigElementKey& InItem_69, const struct FName& InMetadataName_69);
	TArray<struct FRigElementKey> GetReferenceKeys(bool bTraverse_69);
	struct FQuat GetQuatMetadata(const struct FRigElementKey& InItem_69, const struct FName& InMetadataName_69, const struct FQuat& DefaultValue_69);
	TArray<struct FQuat> GetQuatArrayMetadata(const struct FRigElementKey& InItem_69, const struct FName& InMetadataName_69);
	struct FRigElementKey GetPreviousParent(const struct FRigElementKey& InKey_69);
	struct FName GetPreviousName(const struct FRigElementKey& InKey_69);
	struct FRigPose GetPose(bool bInitial_69);
	TArray<struct FRigElementWeight> GetParentWeightArray(const struct FRigElementKey& InChild_69, bool bInitial_69);
	struct FRigElementWeight GetParentWeight(const struct FRigElementKey& InChild_69, const struct FRigElementKey& InParent_69, bool bInitial_69);
	struct FCoreUObject_FTransform GetParentTransformByIndex(int InElementIndex_69, bool bInitial_69);
	struct FCoreUObject_FTransform GetParentTransform(const struct FRigElementKey& InKey_69, bool bInitial_69);
	TArray<struct FRigElementKey> GetParents(const struct FRigElementKey& InKey_69, bool bRecursive_69);
	int GetNumberOfParents(const struct FRigElementKey& InKey_69);
	TArray<struct FRigElementKey> GetNullKeys(bool bTraverse_69);
	struct FName GetNameMetadata(const struct FRigElementKey& InItem_69, const struct FName& InMetadataName_69, const struct FName& DefaultValue_69);
	TArray<struct FName> GetNameArrayMetadata(const struct FRigElementKey& InItem_69, const struct FName& InMetadataName_69);
	ERigMetadataType GetMetadataType(const struct FRigElementKey& InItem_69, const struct FName& InMetadataName_69);
	TArray<struct FName> GetMetadataNames(const struct FRigElementKey& InItem_69);
	struct FCoreUObject_FTransform GetLocalTransformByIndex(int InElementIndex_69, bool bInitial_69);
	struct FCoreUObject_FTransform GetLocalTransform(const struct FRigElementKey& InKey_69, bool bInitial_69);
	struct FCoreUObject_FTransform GetLocalControlShapeTransformByIndex(int InElementIndex_69, bool bInitial_69);
	struct FCoreUObject_FTransform GetLocalControlShapeTransform(const struct FRigElementKey& InKey_69, bool bInitial_69);
	struct FLinearColor GetLinearColorMetadata(const struct FRigElementKey& InItem_69, const struct FName& InMetadataName_69, const struct FLinearColor& DefaultValue_69);
	TArray<struct FLinearColor> GetLinearColorArrayMetadata(const struct FRigElementKey& InItem_69, const struct FName& InMetadataName_69);
	TArray<struct FRigElementKey> GetKeys(TArray<int> InElementIndices_69);
	struct FRigElementKey GetKey(int InElementIndex_69);
	int STATIC_GetIntFromControlValue(const struct FRigControlValue& InValue_69);
	int GetInt32Metadata(const struct FRigElementKey& InItem_69, const struct FName& InMetadataName_69, int DefaultValue_69);
	TArray<int> GetInt32ArrayMetadata(const struct FRigElementKey& InItem_69, const struct FName& InMetadataName_69);
	int GetIndex_ForBlueprint(const struct FRigElementKey& InKey_69);
	struct FCoreUObject_FTransform GetGlobalTransformByIndex(int InElementIndex_69, bool bInitial_69);
	struct FCoreUObject_FTransform GetGlobalTransform(const struct FRigElementKey& InKey_69, bool bInitial_69);
	struct FCoreUObject_FTransform GetGlobalControlShapeTransformByIndex(int InElementIndex_69, bool bInitial_69);
	struct FCoreUObject_FTransform GetGlobalControlShapeTransform(const struct FRigElementKey& InKey_69, bool bInitial_69);
	struct FCoreUObject_FTransform GetGlobalControlOffsetTransformByIndex(int InElementIndex_69, bool bInitial_69);
	struct FCoreUObject_FTransform GetGlobalControlOffsetTransform(const struct FRigElementKey& InKey_69, bool bInitial_69);
	float GetFloatMetadata(const struct FRigElementKey& InItem_69, const struct FName& InMetadataName_69, float DefaultValue_69);
	float STATIC_GetFloatFromControlValue(const struct FRigControlValue& InValue_69);
	TArray<float> GetFloatArrayMetadata(const struct FRigElementKey& InItem_69, const struct FName& InMetadataName_69);
	struct FRigElementKey GetFirstParent(const struct FRigElementKey& InKey_69);
	struct FEulerTransform STATIC_GetEulerTransformFromControlValue(const struct FRigControlValue& InValue_69);
	struct FRigElementKey GetDefaultParent(const struct FRigElementKey& InKey_69);
	float GetCurveValueByIndex(int InElementIndex_69);
	float GetCurveValue(const struct FRigElementKey& InKey_69);
	TArray<struct FRigElementKey> GetCurveKeys();
	struct FRigControlValue GetControlValueByIndex(int InElementIndex_69, ERigControlValueType InValueType_69);
	struct FRigControlValue GetControlValue(const struct FRigElementKey& InKey_69, ERigControlValueType InValueType_69);
	struct FRotator GetControlPreferredRotatorByIndex(int InElementIndex_69, bool bInitial_69);
	struct FRotator GetControlPreferredRotator(const struct FRigElementKey& InKey_69, bool bInitial_69);
	class RigHierarchyController* GetController(bool bCreateIfNeeded_69);
	TArray<struct FRigElementKey> GetControlKeys(bool bTraverse_69);
	TArray<struct FRigElementKey> GetChildren(const struct FRigElementKey& InKey_69, bool bRecursive_69);
	bool GetBoolMetadata(const struct FRigElementKey& InItem_69, const struct FName& InMetadataName_69, bool DefaultValue_69);
	TArray<bool> GetBoolArrayMetadata(const struct FRigElementKey& InItem_69, const struct FName& InMetadataName_69);
	TArray<struct FRigElementKey> GetBoneKeys(bool bTraverse_69);
	TArray<struct FRigElementKey> GetAllKeys_ForBlueprint(bool bTraverse_69);
	struct FRigNullElement FindNull_ForBlueprintOnly(const struct FRigElementKey& InKey_69);
	struct FRigControlElement FindControl_ForBlueprintOnly(const struct FRigElementKey& InKey_69);
	struct FRigBoneElement FindBone_ForBlueprintOnly(const struct FRigElementKey& InKey_69);
	void CopyPose(class RigHierarchy* InHierarchy_69, bool bCurrent_69, bool bInitial_69, bool bWeights_69, bool bMatchPoseInGlobalIfNeeded_69);
	void CopyHierarchy(class RigHierarchy* InHierarchy_69);
	bool Contains_ForBlueprint(const struct FRigElementKey& InKey_69);
};


// Class ControlRig.TransformableControlHandle_32759
// 0x0030 (0x0070 - 0x0040)
class TransformableControlHandle_32759 : public TransformableHandle
{
public:
	unsigned char                                      UnknownData00[0x28];                                      // 0x0040(0x0028) UNKNOWN PROPERTY: SoftObjectProperty ControlRig.TransformableControlHandle_32759.ControlRig_69
	struct FName                                       ControlName_69;                                           // 0x0068(0x0008) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x4];                                       // 0x006C(0x0004) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class ControlRig.TransformableControlHandle_32759"));
		
		return ptr;
	}

};


// Class ControlRig.ControlRigAnimInstance
// 0x0000 (0x0350 - 0x0350)
class ControlRigAnimInstance : public AnimInstance
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class ControlRig.ControlRigAnimInstance"));
		
		return ptr;
	}

};


// Class ControlRig.ControlRigBlueprintGeneratedClass
// 0x0000 (0x0380 - 0x0380)
class ControlRigBlueprintGeneratedClass : public BlueprintGeneratedClass
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class ControlRig.ControlRigBlueprintGeneratedClass"));
		
		return ptr;
	}

};


// Class ControlRig.ControlRigComponent
// 0x0160 (0x0690 - 0x0530)
class ControlRigComponent : public PrimitiveComponent
{
public:
	class ControlRig*                                  ControlRigClass_69;                                       // 0x0530(0x0008) (Edit, BlueprintVisible, ZeroConstructor)
	unsigned char                                      UnknownData00[0x10];                                      // 0x0538(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty ControlRig.ControlRigComponent.OnPreInitializeDelegate_69
	unsigned char                                      UnknownData01[0x10];                                      // 0x0548(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty ControlRig.ControlRigComponent.OnPostInitializeDelegate_69
	unsigned char                                      UnknownData02[0x10];                                      // 0x0558(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty ControlRig.ControlRigComponent.OnPreConstructionDelegate_69
	unsigned char                                      UnknownData03[0x10];                                      // 0x0568(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty ControlRig.ControlRigComponent.OnPostConstructionDelegate_69
	unsigned char                                      UnknownData04[0x10];                                      // 0x0578(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty ControlRig.ControlRigComponent.OnPreForwardsSolveDelegate_69
	unsigned char                                      UnknownData05[0x10];                                      // 0x0588(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty ControlRig.ControlRigComponent.OnPostForwardsSolveDelegate_69
	TArray<struct FControlRigComponentMappedElement>   UserDefinedElements_69;                                   // 0x0598(0x0010) (Edit, ZeroConstructor)
	TArray<struct FControlRigComponentMappedElement>   MappedElements_69;                                        // 0x05A8(0x0010) (Edit, ZeroConstructor, EditConst)
	bool                                               bEnableLazyEvaluation_69;                                 // 0x05B8(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData06[0x3];                                       // 0x05B9(0x0003) MISSED OFFSET
	float                                              LazyEvaluationPositionThreshold_69;                       // 0x05BC(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	float                                              LazyEvaluationRotationThreshold_69;                       // 0x05C0(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	float                                              LazyEvaluationScaleThreshold_69;                          // 0x05C4(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	bool                                               bResetTransformBeforeTick_69;                             // 0x05C8(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	bool                                               bResetInitialsBeforeConstruction_69;                      // 0x05C9(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	bool                                               bUpdateRigOnTick_69;                                      // 0x05CA(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	bool                                               bUpdateInEditor_69;                                       // 0x05CB(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	bool                                               bDrawBones_69;                                            // 0x05CC(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	bool                                               bShowDebugDrawing_69;                                     // 0x05CD(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData07[0x2];                                       // 0x05CE(0x0002) MISSED OFFSET
	class ControlRig*                                  ControlRig_69;                                            // 0x05D0(0x0008) (ZeroConstructor, Transient)
	unsigned char                                      UnknownData08[0xB8];                                      // 0x05D8(0x00B8) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class ControlRig.ControlRigComponent"));
		
		return ptr;
	}


	void Update(float DeltaTime_69);
	void SetObjectBinding(class Object_32759* InObjectToBind_69);
	void SetMappedElements(TArray<struct FControlRigComponentMappedElement> NewMappedElements_69);
	void SetInitialSpaceTransform(const struct FName& SpaceName_69, const struct FCoreUObject_FTransform& InitialTransform_69, EControlRigComponentSpace Space_69);
	void SetInitialBoneTransform(const struct FName& BoneName_69, const struct FCoreUObject_FTransform& InitialTransform_69, EControlRigComponentSpace Space_69, bool bPropagateToChildren_69);
	void SetControlVector2D(const struct FName& ControlName_69, const struct FVector2D& Value_69);
	void SetControlTransform(const struct FName& ControlName_69, const struct FCoreUObject_FTransform& Value_69, EControlRigComponentSpace Space_69);
	void SetControlScale(const struct FName& ControlName_69, const struct FVector& Value_69, EControlRigComponentSpace Space_69);
	void SetControlRotator(const struct FName& ControlName_69, const struct FRotator& Value_69, EControlRigComponentSpace Space_69);
	void SetControlRigClass(class ControlRig* InControlRigClass_69);
	void SetControlPosition(const struct FName& ControlName_69, const struct FVector& Value_69, EControlRigComponentSpace Space_69);
	void SetControlOffset(const struct FName& ControlName_69, const struct FCoreUObject_FTransform& OffsetTransform_69, EControlRigComponentSpace Space_69);
	void SetControlInt(const struct FName& ControlName_69, int Value_69);
	void SetControlFloat(const struct FName& ControlName_69, float Value_69);
	void SetControlBool(const struct FName& ControlName_69, bool Value_69);
	void SetBoneTransform(const struct FName& BoneName_69, const struct FCoreUObject_FTransform& Transform_69, EControlRigComponentSpace Space_69, float Weight_69, bool bPropagateToChildren_69);
	void SetBoneInitialTransformsFromSkeletalMesh(class SkeletalMesh* InSkeletalMesh_69);
	void OnPreInitialize(class ControlRigComponent* Component_69);
	void OnPreForwardsSolve(class ControlRigComponent* Component_69);
	void OnPreConstruction(class ControlRigComponent* Component_69);
	void OnPostInitialize(class ControlRigComponent* Component_69);
	void OnPostForwardsSolve(class ControlRigComponent* Component_69);
	void OnPostConstruction(class ControlRigComponent* Component_69);
	void Initialize();
	struct FCoreUObject_FTransform GetSpaceTransform(const struct FName& SpaceName_69, EControlRigComponentSpace Space_69);
	struct FCoreUObject_FTransform GetInitialSpaceTransform(const struct FName& SpaceName_69, EControlRigComponentSpace Space_69);
	struct FCoreUObject_FTransform GetInitialBoneTransform(const struct FName& BoneName_69, EControlRigComponentSpace Space_69);
	TArray<struct FName> GetElementNames(ERigElementType ElementType_69);
	struct FVector2D GetControlVector2D(const struct FName& ControlName_69);
	struct FCoreUObject_FTransform GetControlTransform(const struct FName& ControlName_69, EControlRigComponentSpace Space_69);
	struct FVector GetControlScale(const struct FName& ControlName_69, EControlRigComponentSpace Space_69);
	struct FRotator GetControlRotator(const struct FName& ControlName_69, EControlRigComponentSpace Space_69);
	class ControlRig* GetControlRig();
	struct FVector GetControlPosition(const struct FName& ControlName_69, EControlRigComponentSpace Space_69);
	struct FCoreUObject_FTransform GetControlOffset(const struct FName& ControlName_69, EControlRigComponentSpace Space_69);
	int GetControlInt(const struct FName& ControlName_69);
	float GetControlFloat(const struct FName& ControlName_69);
	bool GetControlBool(const struct FName& ControlName_69);
	struct FCoreUObject_FTransform GetBoneTransform(const struct FName& BoneName_69, EControlRigComponentSpace Space_69);
	float GetAbsoluteTime();
	bool DoesElementExist(const struct FName& Name_69, ERigElementType ElementType_69);
	void ClearMappedElements();
	bool CanExecute();
	void AddMappedSkeletalMesh(class SkeletalMeshComponent* SkeletalMeshComponent_69, TArray<struct FControlRigComponentMappedBone> Bones_69, TArray<struct FControlRigComponentMappedCurve> Curves_69);
	void AddMappedElements(TArray<struct FControlRigComponentMappedElement> NewMappedElements_69);
	void AddMappedComponents(TArray<struct FControlRigComponentMappedComponent> Components_69);
	void AddMappedCompleteSkeletalMesh(class SkeletalMeshComponent* SkeletalMeshComponent_69);
};


// Class ControlRig.ControlRigControlActor_32759
// 0x00B8 (0x0340 - 0x0288)
class ControlRigControlActor_32759 : public Actor_32759
{
public:
	class Actor_32759*                                 ActorToTrack_69;                                          // 0x0288(0x0008) (Edit, BlueprintVisible, ZeroConstructor)
	class ControlRig*                                  ControlRigClass_69;                                       // 0x0290(0x0008) (Edit, BlueprintVisible, ZeroConstructor)
	bool                                               bRefreshOnTick_69;                                        // 0x0298(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bIsSelectable_69;                                         // 0x0299(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x6];                                       // 0x029A(0x0006) MISSED OFFSET
	class MaterialInterface*                           MaterialOverride_69;                                      // 0x02A0(0x0008) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     ColorParameter_69;                                        // 0x02A8(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	bool                                               bCastShadows_69;                                          // 0x02B8(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x7];                                       // 0x02B9(0x0007) MISSED OFFSET
	class SceneComponent*                              ActorRootComponent_69;                                    // 0x02C0(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	unsigned char                                      UnknownData02[0x28];                                      // 0x02C8(0x0028) UNKNOWN PROPERTY: SoftObjectProperty ControlRig.ControlRigControlActor_32759.ControlRig_69
	TArray<struct FName>                               ControlNames_69;                                          // 0x02F0(0x0010) (ZeroConstructor, Transient)
	TArray<struct FCoreUObject_FTransform>             ShapeTransforms_69;                                       // 0x0300(0x0010) (ZeroConstructor, Transient)
	TArray<class StaticMeshComponent*>                 Components_69;                                            // 0x0310(0x0010) (ExportObject, ZeroConstructor, Transient)
	TArray<class MaterialInstanceDynamic*>             Materials_69;                                             // 0x0320(0x0010) (ZeroConstructor, Transient)
	struct FName                                       ColorParameterName_69;                                    // 0x0330(0x0008) (ZeroConstructor, Transient, IsPlainOldData)
	unsigned char                                      UnknownData03[0xC];                                       // 0x0334(0x000C) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class ControlRig.ControlRigControlActor_32759"));
		
		return ptr;
	}


	void Refresh();
	void Clear();
};


// Class ControlRig.ControlRigShapeActor
// 0x0040 (0x02C8 - 0x0288)
class ControlRigShapeActor : public Actor_32759
{
public:
	class SceneComponent*                              ActorRootComponent_69;                                    // 0x0288(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	class StaticMeshComponent*                         StaticMeshComponent_69;                                   // 0x0290(0x0008) (Edit, BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, EditConst, InstancedReference)
	uint32_t                                           ControlRigIndex_69;                                       // 0x0298(0x0004) (ZeroConstructor, IsPlainOldData)
	TWeakObjectPtr<class ControlRig>                   ControlRig_69;                                            // 0x029C(0x0008) (ZeroConstructor, IsPlainOldData)
	struct FName                                       ControlName_69;                                           // 0x02A4(0x0008) (ZeroConstructor, IsPlainOldData)
	struct FName                                       ShapeName_69;                                             // 0x02A8(0x0008) (ZeroConstructor, IsPlainOldData)
	struct FName                                       ColorParameterName_69;                                    // 0x02AC(0x0008) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x10];                                      // 0x02B0(0x0010) MISSED OFFSET
	unsigned char                                      bSelected_69 : 1;                                         // 0x02C0(0x0001) (BlueprintVisible)
	unsigned char                                      bHovered_69 : 1;                                          // 0x02C0(0x0001) (BlueprintVisible)
	unsigned char                                      UnknownData01[0x7];                                       // 0x02C1(0x0007) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class ControlRig.ControlRigShapeActor"));
		
		return ptr;
	}


	void SetSelected(bool bInSelected_69);
	void SetSelectable(bool bInSelectable_69);
	void SetHovered(bool bInHovered_69);
	void SetGlobalTransform(const struct FCoreUObject_FTransform& InTransform_69);
	void SetEnabled(bool bInEnabled_69);
	void OnTransformChanged(const struct FCoreUObject_FTransform& NewTransform_69);
	void OnSelectionChanged(bool bIsSelected_69);
	void OnManipulatingChanged(bool bIsManipulating_69);
	void OnHoveredChanged(bool bIsSelected_69);
	void OnEnabledChanged(bool bIsEnabled_69);
	bool IsSelectedInEditor();
	bool IsHovered();
	bool IsEnabled();
	struct FCoreUObject_FTransform GetGlobalTransform();
};


// Class ControlRig.ControlRigShapeLibrary
// 0x0128 (0x0150 - 0x0028)
class ControlRigShapeLibrary : public Object_32759
{
public:
	unsigned char                                      UnknownData00[0x8];                                       // 0x0028(0x0008) MISSED OFFSET
	struct FControlRigShapeDefinition                  DefaultShape_69;                                          // 0x0030(0x00A0) (Edit)
	unsigned char                                      UnknownData01[0x28];                                      // 0x00D0(0x0028) UNKNOWN PROPERTY: SoftObjectProperty ControlRig.ControlRigShapeLibrary.DefaultMaterial_69
	unsigned char                                      UnknownData02[0x28];                                      // 0x00F8(0x0028) UNKNOWN PROPERTY: SoftObjectProperty ControlRig.ControlRigShapeLibrary.XRayMaterial_69
	struct FName                                       MaterialColorParameter_69;                                // 0x0120(0x0008) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData03[0x4];                                       // 0x0124(0x0004) MISSED OFFSET
	TArray<struct FControlRigShapeDefinition>          Shapes_69;                                                // 0x0128(0x0010) (Edit, ZeroConstructor)
	unsigned char                                      UnknownData04[0x18];                                      // 0x0138(0x0018) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class ControlRig.ControlRigShapeLibrary"));
		
		return ptr;
	}

};


// Class ControlRig.ControlRigValidator
// 0x0040 (0x0068 - 0x0028)
class ControlRigValidator : public Object_32759
{
public:
	TArray<class ControlRigValidationPass*>            Passes_69;                                                // 0x0028(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData00[0x30];                                      // 0x0038(0x0030) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class ControlRig.ControlRigValidator"));
		
		return ptr;
	}

};


// Class ControlRig.ControlRigValidationPass
// 0x0000 (0x0028 - 0x0028)
class ControlRigValidationPass : public Object_32759
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class ControlRig.ControlRigValidationPass"));
		
		return ptr;
	}

};


// Class ControlRig.AdditiveControlRig
// 0x0010 (0x0568 - 0x0558)
class AdditiveControlRig : public ControlRig
{
public:
	unsigned char                                      UnknownData00[0x10];                                      // 0x0558(0x0010) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class ControlRig.AdditiveControlRig"));
		
		return ptr;
	}

};


// Class ControlRig.FKControlRig
// 0x0040 (0x0598 - 0x0558)
class FKControlRig : public ControlRig
{
public:
	TArray<bool>                                       IsControlActive_69;                                       // 0x0558(0x0010) (ZeroConstructor)
	EControlRigFKRigExecuteMode                        ApplyMode_69;                                             // 0x0568(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x2F];                                      // 0x0569(0x002F) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class ControlRig.FKControlRig"));
		
		return ptr;
	}

};


// Class ControlRig.RigHierarchyController
// 0x0078 (0x00A0 - 0x0028)
class RigHierarchyController : public Object_32759
{
public:
	bool                                               bReportWarningsAndErrors_69;                              // 0x0028(0x0001) (ZeroConstructor, Transient, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0029(0x0003) MISSED OFFSET
	TWeakObjectPtr<class RigHierarchy>                 Hierarchy_69;                                             // 0x002C(0x0008) (ZeroConstructor, Transient, IsPlainOldData)
	unsigned char                                      UnknownData01[0x6C];                                      // 0x0034(0x006C) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class ControlRig.RigHierarchyController"));
		
		return ptr;
	}


	bool SetSelection(TArray<struct FRigElementKey> InKeys_69, bool bPrintPythonCommand_69);
	bool SetParent(const struct FRigElementKey& InChild_69, const struct FRigElementKey& InParent_69, bool bMaintainGlobalTransform_69, bool bSetupUndo_69, bool bPrintPythonCommand_69);
	void SetHierarchy(class RigHierarchy* InHierarchy_69);
	struct FName SetDisplayName(const struct FRigElementKey& InControl_69, const struct FName& InDisplayName_69, bool bRenameElement_69, bool bSetupUndo_69, bool bPrintPythonCommand_69);
	bool SetControlSettings(const struct FRigElementKey& InKey_69, const struct FRigControlSettings& InSettings_69, bool bSetupUndo_69);
	bool SelectElement(const struct FRigElementKey& InKey_69, bool bSelect_69, bool bClearSelection_69);
	struct FRigElementKey RenameElement(const struct FRigElementKey& InElement_69, const struct FName& InName_69, bool bSetupUndo_69, bool bPrintPythonCommand_69, bool bClearSelection_69);
	bool RemoveParent(const struct FRigElementKey& InChild_69, const struct FRigElementKey& InParent_69, bool bMaintainGlobalTransform_69, bool bSetupUndo_69, bool bPrintPythonCommand_69);
	bool RemoveElement(const struct FRigElementKey& InElement_69, bool bSetupUndo_69, bool bPrintPythonCommand_69);
	bool RemoveAllParents(const struct FRigElementKey& InChild_69, bool bMaintainGlobalTransform_69, bool bSetupUndo_69, bool bPrintPythonCommand_69);
	TArray<struct FRigElementKey> MirrorElements(TArray<struct FRigElementKey> InKeys_69, const struct FRigMirrorSettings& InSettings_69, bool bSelectNewElements_69, bool bSetupUndo_69, bool bPrintPythonCommands_69);
	TArray<struct FRigElementKey> ImportFromText(const struct FString& InContent_69, bool bReplaceExistingElements_69, bool bSelectNewElements_69, bool bSetupUndo_69, bool bPrintPythonCommands_69);
	TArray<struct FRigElementKey> ImportCurves(class Skeleton* InSkeleton_69, const struct FName& InNameSpace_69, bool bSelectCurves_69, bool bSetupUndo_69, bool bPrintPythonCommand_69);
	TArray<struct FRigElementKey> ImportBones(class Skeleton* InSkeleton_69, const struct FName& InNameSpace_69, bool bReplaceExistingBones_69, bool bRemoveObsoleteBones_69, bool bSelectBones_69, bool bSetupUndo_69, bool bPrintPythonCommand_69);
	class RigHierarchy* GetHierarchy();
	struct FRigControlSettings GetControlSettings(const struct FRigElementKey& InKey_69);
	struct FString ExportToText(TArray<struct FRigElementKey> InKeys_69);
	struct FString ExportSelectionToText();
	TArray<struct FRigElementKey> DuplicateElements(TArray<struct FRigElementKey> InKeys_69, bool bSelectNewElements_69, bool bSetupUndo_69, bool bPrintPythonCommands_69);
	bool DeselectElement(const struct FRigElementKey& InKey_69);
	bool ClearSelection();
	struct FRigElementKey AddRigidBody(const struct FName& InName_69, const struct FRigElementKey& InParent_69, const struct FRigRigidBodySettings& InSettings_69, const struct FCoreUObject_FTransform& InLocalTransform_69, bool bSetupUndo_69, bool bPrintPythonCommand_69);
	bool AddParent(const struct FRigElementKey& InChild_69, const struct FRigElementKey& InParent_69, float InWeight_69, bool bMaintainGlobalTransform_69, bool bSetupUndo_69);
	struct FRigElementKey AddNull(const struct FName& InName_69, const struct FRigElementKey& InParent_69, const struct FCoreUObject_FTransform& InTransform_69, bool bTransformInGlobal_69, bool bSetupUndo_69, bool bPrintPythonCommand_69);
	struct FRigElementKey AddCurve(const struct FName& InName_69, float InValue_69, bool bSetupUndo_69, bool bPrintPythonCommand_69);
	struct FRigElementKey AddControl_ForBlueprint(const struct FName& InName_69, const struct FRigElementKey& InParent_69, const struct FRigControlSettings& InSettings_69, const struct FRigControlValue& InValue_69, bool bSetupUndo_69, bool bPrintPythonCommand_69);
	struct FRigElementKey AddBone(const struct FName& InName_69, const struct FRigElementKey& InParent_69, const struct FCoreUObject_FTransform& InTransform_69, bool bTransformInGlobal_69, ERigBoneType InBoneType_69, bool bSetupUndo_69, bool bPrintPythonCommand_69);
	struct FRigElementKey AddAnimationChannel_ForBlueprint(const struct FName& InName_69, const struct FRigElementKey& InParentControl_69, const struct FRigControlSettings& InSettings_69, bool bSetupUndo_69, bool bPrintPythonCommand_69);
};


// Class ControlRig.ControlRigLayerInstance
// 0x0000 (0x0350 - 0x0350)
class ControlRigLayerInstance : public AnimInstance
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class ControlRig.ControlRigLayerInstance"));
		
		return ptr;
	}

};


// Class ControlRig.ControlRigObjectHolder
// 0x0010 (0x0038 - 0x0028)
class ControlRigObjectHolder : public Object_32759
{
public:
	TArray<class Object_32759*>                        Objects_69;                                               // 0x0028(0x0010) (ZeroConstructor)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class ControlRig.ControlRigObjectHolder"));
		
		return ptr;
	}

};


// Class ControlRig.ControlRigSequence
// 0x0058 (0x0228 - 0x01D0)
class ControlRigSequence : public LevelSequence
{
public:
	unsigned char                                      UnknownData00[0x28];                                      // 0x01D0(0x0028) UNKNOWN PROPERTY: SoftObjectProperty ControlRig.ControlRigSequence.LastExportedToAnimationSequence_69
	unsigned char                                      UnknownData01[0x28];                                      // 0x01F8(0x0028) UNKNOWN PROPERTY: SoftObjectProperty ControlRig.ControlRigSequence.LastExportedUsingSkeletalMesh_69
	float                                              LastExportedFrameRate_69;                                 // 0x0220(0x0004) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData02[0x4];                                       // 0x0224(0x0004) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class ControlRig.ControlRigSequence"));
		
		return ptr;
	}

};


// Class ControlRig.MovieSceneControlRigParameterSection
// 0x0248 (0x03A0 - 0x0158)
class MovieSceneControlRigParameterSection : public MovieSceneParameterSection
{
public:
	unsigned char                                      UnknownData00[0x40];                                      // 0x0158(0x0040) MISSED OFFSET
	class ControlRig*                                  ControlRig_69;                                            // 0x0198(0x0008) (ZeroConstructor)
	class ControlRig*                                  ControlRigClass_69;                                       // 0x01A0(0x0008) (Edit, ZeroConstructor)
	TArray<bool>                                       ControlsMask_69;                                          // 0x01A8(0x0010) (ZeroConstructor)
	struct FMovieSceneTransformMask                    TransformMask_69;                                         // 0x01B8(0x0004)
	unsigned char                                      UnknownData01[0x4];                                       // 0x01BC(0x0004) MISSED OFFSET
	struct FMovieSceneFloatChannel                     Weight_69;                                                // 0x01C0(0x00E8)
	TMap<struct FName, struct FChannelMapInfo>         ControlChannelMap_69;                                     // 0x02A8(0x0050)
	TArray<struct FEnumParameterNameAndCurve>          EnumParameterNamesAndCurves_69;                           // 0x02F8(0x0010) (ZeroConstructor)
	TArray<struct FIntegerParameterNameAndCurve>       IntegerParameterNamesAndCurves_69;                        // 0x0308(0x0010) (ZeroConstructor)
	TArray<struct FSpaceControlNameAndChannel>         SpaceChannels_69;                                         // 0x0318(0x0010) (ZeroConstructor)
	TArray<struct FConstraintAndActiveChannel>         ConstraintsChannels_69;                                   // 0x0328(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData02[0x68];                                      // 0x0338(0x0068) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class ControlRig.MovieSceneControlRigParameterSection"));
		
		return ptr;
	}

};


// Class ControlRig.MovieSceneControlRigParameterTrack
// 0x0068 (0x0100 - 0x0098)
class MovieSceneControlRigParameterTrack : public MovieSceneNameableTrack
{
public:
	unsigned char                                      UnknownData00[0x40];                                      // 0x0098(0x0040) MISSED OFFSET
	class ControlRig*                                  ControlRig_69;                                            // 0x00D8(0x0008) (ZeroConstructor)
	class MovieSceneSection*                           SectionToKey_69;                                          // 0x00E0(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	TArray<class MovieSceneSection*>                   Sections_69;                                              // 0x00E8(0x0010) (ExportObject, ZeroConstructor)
	struct FName                                       TrackName_69;                                             // 0x00F8(0x0008) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x4];                                       // 0x00FC(0x0004) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class ControlRig.MovieSceneControlRigParameterTrack"));
		
		return ptr;
	}

};


// Class ControlRig.ControlRigSettings
// 0x0000 (0x0030 - 0x0030)
class ControlRigSettings : public DeveloperSettings
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class ControlRig.ControlRigSettings"));
		
		return ptr;
	}

};


// Class ControlRig.ControlRigEditorSettings
// 0x0000 (0x0030 - 0x0030)
class ControlRigEditorSettings : public DeveloperSettings
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class ControlRig.ControlRigEditorSettings"));
		
		return ptr;
	}

};


// Class ControlRig.ControlRigPoseAsset
// 0x0060 (0x0088 - 0x0028)
class ControlRigPoseAsset : public Object_32759
{
public:
	struct FControlRigControlPose                      Pose_69;                                                  // 0x0028(0x0060) (Edit, BlueprintVisible)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class ControlRig.ControlRigPoseAsset"));
		
		return ptr;
	}


	void SelectControls(class ControlRig* InControlRig_69, bool bDoMirror_69);
	void SavePose(class ControlRig* InControlRig_69, bool bUseAll_69);
	void ReplaceControlName(const struct FName& CurrentName_69, const struct FName& NewName_69);
	void PastePose(class ControlRig* InControlRig_69, bool bDoKey_69, bool bDoMirror_69);
	void GetCurrentPose(class ControlRig* InControlRig_69, struct FControlRigControlPose* OutPose_69);
	TArray<struct FName> GetControlNames();
	bool DoesMirrorMatch(class ControlRig* ControlRig_69, const struct FName& ControlName_69);
};


// Class ControlRig.ControlRigPoseMirrorSettings
// 0x0028 (0x0050 - 0x0028)
class ControlRigPoseMirrorSettings : public Object_32759
{
public:
	struct FString                                     RightSide_69;                                             // 0x0028(0x0010) (Edit, BlueprintVisible, ZeroConstructor, Config)
	struct FString                                     LeftSide_69;                                              // 0x0038(0x0010) (Edit, BlueprintVisible, ZeroConstructor, Config)
	TEnumAsByte<EAxis>                                 MirrorAxis_69;                                            // 0x0048(0x0001) (Edit, BlueprintVisible, ZeroConstructor, Config, IsPlainOldData)
	TEnumAsByte<EAxis>                                 AxisToFlip_69;                                            // 0x0049(0x0001) (Edit, BlueprintVisible, ZeroConstructor, Config, IsPlainOldData)
	unsigned char                                      UnknownData00[0x6];                                       // 0x004A(0x0006) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class ControlRig.ControlRigPoseMirrorSettings"));
		
		return ptr;
	}

};


// Class ControlRig.ControlRigPoseProjectSettings
// 0x0010 (0x0038 - 0x0028)
class ControlRigPoseProjectSettings : public Object_32759
{
public:
	TArray<struct FDirectoryPath>                      RootSaveDirs_69;                                          // 0x0028(0x0010) (Edit, BlueprintVisible, ZeroConstructor, Config)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class ControlRig.ControlRigPoseProjectSettings"));
		
		return ptr;
	}

};


// Class ControlRig.ControlRigSnapSettings
// 0x0008 (0x0030 - 0x0028)
class ControlRigSnapSettings : public Object_32759
{
public:
	bool                                               bKeepOffset_69;                                           // 0x0028(0x0001) (Edit, BlueprintVisible, ZeroConstructor, Config, IsPlainOldData)
	bool                                               bSnapPosition_69;                                         // 0x0029(0x0001) (Edit, BlueprintVisible, ZeroConstructor, Config, IsPlainOldData)
	bool                                               bSnapRotation_69;                                         // 0x002A(0x0001) (Edit, BlueprintVisible, ZeroConstructor, Config, IsPlainOldData)
	bool                                               bSnapScale_69;                                            // 0x002B(0x0001) (Edit, BlueprintVisible, ZeroConstructor, Config, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x002C(0x0004) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class ControlRig.ControlRigSnapSettings"));
		
		return ptr;
	}

};


// Class ControlRig.ControlRigWorkflowOptions
// 0x0018 (0x00B0 - 0x0098)
class ControlRigWorkflowOptions : public RigVMUserWorkflowOptions
{
public:
	class RigHierarchy*                                Hierarchy_69;                                             // 0x0098(0x0008) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance)
	TArray<struct FRigElementKey>                      Selection_69;                                             // 0x00A0(0x0010) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class ControlRig.ControlRigWorkflowOptions"));
		
		return ptr;
	}


	bool EnsureAtLeastOneRigElementSelected();
};


// Class ControlRig.ControlRigTransformWorkflowOptions
// 0x0008 (0x00B8 - 0x00B0)
class ControlRigTransformWorkflowOptions : public ControlRigWorkflowOptions
{
public:
	TEnumAsByte<ERigTransformType>                     TransformType_69;                                         // 0x00B0(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x00B1(0x0007) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class ControlRig.ControlRigTransformWorkflowOptions"));
		
		return ptr;
	}


	TArray<struct FRigVMUserWorkflow> ProvideWorkflows(class Object_32759* InSubject_69);
};


// Class ControlRig.ControlRigNumericalValidationPass
// 0x0090 (0x00B8 - 0x0028)
class ControlRigNumericalValidationPass : public ControlRigValidationPass
{
public:
	bool                                               bCheckControls_69;                                        // 0x0028(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	bool                                               bCheckBones_69;                                           // 0x0029(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	bool                                               bCheckCurves_69;                                          // 0x002A(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x1];                                       // 0x002B(0x0001) MISSED OFFSET
	float                                              TranslationPrecision_69;                                  // 0x002C(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	float                                              RotationPrecision_69;                                     // 0x0030(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	float                                              ScalePrecision_69;                                        // 0x0034(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	float                                              CurvePrecision_69;                                        // 0x0038(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	struct FName                                       EventNameA_69;                                            // 0x003C(0x0008) (ZeroConstructor, Transient, IsPlainOldData)
	struct FName                                       EventNameB_69;                                            // 0x0040(0x0008) (ZeroConstructor, Transient, IsPlainOldData)
	unsigned char                                      UnknownData01[0x4];                                       // 0x0044(0x0004) MISSED OFFSET
	struct FRigPose                                    Pose_69;                                                  // 0x0048(0x0070) (Transient)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class ControlRig.ControlRigNumericalValidationPass"));
		
		return ptr;
	}

};


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

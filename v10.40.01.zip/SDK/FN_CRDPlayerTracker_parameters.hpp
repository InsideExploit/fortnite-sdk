#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function CRDPlayerTracker.CRDPlayerTrackerMarker.DestroyPlayerTrackerWidget
struct CRDPlayerTrackerMarker_DestroyPlayerTrackerWidget_Params
{
	class FortPlayerControllerGameplay*                InFortPlayerControllerGameplay_69;                        // (Parm, ZeroConstructor)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CRDPlayerTracker.CRDPlayerTrackerMarker.CreatePlayerTrackerWidget
struct CRDPlayerTrackerMarker_CreatePlayerTrackerWidget_Params
{
	class FortPlayerControllerGameplay*                InFortPlayerControllerGameplay_69;                        // (Parm, ZeroConstructor)
	class FortPlayerStateAthena*                       AssociatedPSA_69;                                         // (Parm, ZeroConstructor)
	class UserWidget*                                  ReturnValue_69;                                           // (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

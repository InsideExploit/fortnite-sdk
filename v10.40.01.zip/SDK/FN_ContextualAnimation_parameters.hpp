#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function ContextualAnimation.ContextualAnimActorInterface.GetMesh
struct ContextualAnimActorInterface_GetMesh_Params
{
	class SkeletalMeshComponent*                       ReturnValue_69;                                           // (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)
};

// Function ContextualAnimation.ContextualAnimManager.TryStopSceneWithActor
struct ContextualAnimManager_TryStopSceneWithActor_Params
{
	class Actor_32759*                                 Actor_69;                                                 // (Parm, ZeroConstructor)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function ContextualAnimation.ContextualAnimManager.OnSceneInstanceEnded
struct ContextualAnimManager_OnSceneInstanceEnded_Params
{
	class ContextualAnimSceneInstance*                 SceneInstance_69;                                         // (Parm, ZeroConstructor)
};

// Function ContextualAnimation.ContextualAnimManager.IsActorInAnyScene
struct ContextualAnimManager_IsActorInAnyScene_Params
{
	class Actor_32759*                                 Actor_69;                                                 // (Parm, ZeroConstructor)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function ContextualAnimation.ContextualAnimManager.GetSceneWithActor
struct ContextualAnimManager_GetSceneWithActor_Params
{
	class Actor_32759*                                 Actor_69;                                                 // (Parm, ZeroConstructor)
	class ContextualAnimSceneInstance*                 ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function ContextualAnimation.ContextualAnimManager.GetContextualAnimManager
struct ContextualAnimManager_GetContextualAnimManager_Params
{
	class Object_32759*                                WorldContextObject_69;                                    // (Parm, ZeroConstructor)
	class ContextualAnimManager*                       ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function ContextualAnimation.ContextualAnimManager.BP_TryStartScene
struct ContextualAnimManager_BP_TryStartScene_Params
{
	class ContextualAnimSceneAsset*                    SceneAsset_69;                                            // (ConstParm, Parm, ZeroConstructor)
	struct FContextualAnimStartSceneParams             Params_69;                                                // (ConstParm, Parm, OutParm, ReferenceParm)
	class ContextualAnimSceneInstance*                 ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function ContextualAnimation.ContextualAnimSceneActorComponent.OnTickPose
struct ContextualAnimSceneActorComponent_OnTickPose_Params
{
	class SkinnedMeshComponent*                        SkinnedMeshComponent_69;                                  // (Parm, ZeroConstructor, InstancedReference)
	float                                              DeltaTime_69;                                             // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bNeedsValidRootMotion_69;                                 // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function ContextualAnimation.ContextualAnimSceneActorComponent.GetIKTargets
struct ContextualAnimSceneActorComponent_GetIKTargets_Params
{
	TArray<struct FContextualAnimIKTarget>             ReturnValue_69;                                           // (ConstParm, Parm, OutParm, ZeroConstructor, ReturnParm, ReferenceParm)
};

// Function ContextualAnimation.ContextualAnimSceneActorComponent.GetIKTargetByGoalName
struct ContextualAnimSceneActorComponent_GetIKTargetByGoalName_Params
{
	struct FName                                       GoalName_69;                                              // (Parm, ZeroConstructor, IsPlainOldData)
	struct FContextualAnimIKTarget                     ReturnValue_69;                                           // (ConstParm, Parm, OutParm, ReturnParm, ReferenceParm)
};

// Function ContextualAnimation.ContextualAnimSceneAsset.Query
struct ContextualAnimSceneAsset_Query_Params
{
	struct FName                                       Role_69;                                                  // (Parm, ZeroConstructor, IsPlainOldData)
	struct FContextualAnimQueryResult                  OutResult_69;                                             // (Parm, OutParm)
	struct FContextualAnimQueryParams                  QueryParams_69;                                           // (ConstParm, Parm, OutParm, ReferenceParm)
	struct FCoreUObject_FTransform                     ToWorldTransform_69;                                      // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function ContextualAnimation.ContextualAnimSceneAsset.GetRoles
struct ContextualAnimSceneAsset_GetRoles_Params
{
	TArray<struct FName>                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function ContextualAnimation.ContextualAnimSceneAsset.BP_GetStartAndEndTimeForWarpSection
struct ContextualAnimSceneAsset_BP_GetStartAndEndTimeForWarpSection_Params
{
	int                                                SectionIdx_69;                                            // (Parm, ZeroConstructor, IsPlainOldData)
	int                                                AnimSetIdx_69;                                            // (Parm, ZeroConstructor, IsPlainOldData)
	struct FName                                       Role_69;                                                  // (Parm, ZeroConstructor, IsPlainOldData)
	struct FName                                       WarpSectionName_69;                                       // (Parm, ZeroConstructor, IsPlainOldData)
	float                                              OutStartTime_69;                                          // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	float                                              OutEndTime_69;                                            // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
};

// Function ContextualAnimation.ContextualAnimSceneAsset.BP_GetIKTargetTransformForRoleAtTime
struct ContextualAnimSceneAsset_BP_GetIKTargetTransformForRoleAtTime_Params
{
	int                                                SectionIdx_69;                                            // (Parm, ZeroConstructor, IsPlainOldData)
	int                                                AnimSetIdx_69;                                            // (Parm, ZeroConstructor, IsPlainOldData)
	struct FName                                       Role_69;                                                  // (Parm, ZeroConstructor, IsPlainOldData)
	struct FName                                       TrackName_69;                                             // (Parm, ZeroConstructor, IsPlainOldData)
	float                                              Time_69;                                                  // (Parm, ZeroConstructor, IsPlainOldData)
	struct FCoreUObject_FTransform                     ReturnValue_69;                                           // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function ContextualAnimation.ContextualAnimSceneAsset.BP_GetAlignmentTransformForRoleRelativeToPivot
struct ContextualAnimSceneAsset_BP_GetAlignmentTransformForRoleRelativeToPivot_Params
{
	int                                                SectionIdx_69;                                            // (Parm, ZeroConstructor, IsPlainOldData)
	int                                                AnimSetIdx_69;                                            // (Parm, ZeroConstructor, IsPlainOldData)
	struct FName                                       Role_69;                                                  // (Parm, ZeroConstructor, IsPlainOldData)
	float                                              Time_69;                                                  // (Parm, ZeroConstructor, IsPlainOldData)
	struct FCoreUObject_FTransform                     ReturnValue_69;                                           // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function ContextualAnimation.ContextualAnimSceneAsset.BP_FindAnimSetIndexByAnimation
struct ContextualAnimSceneAsset_BP_FindAnimSetIndexByAnimation_Params
{
	int                                                SectionIdx_69;                                            // (Parm, ZeroConstructor, IsPlainOldData)
	class AnimSequenceBase*                            Animation_69;                                             // (ConstParm, Parm, ZeroConstructor)
	int                                                ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function ContextualAnimation.ContextualAnimSceneAsset.BP_FindAnimationForRole
struct ContextualAnimSceneAsset_BP_FindAnimationForRole_Params
{
	int                                                SectionIdx_69;                                            // (Parm, ZeroConstructor, IsPlainOldData)
	int                                                AnimSetIdx_69;                                            // (Parm, ZeroConstructor, IsPlainOldData)
	struct FName                                       Role_69;                                                  // (Parm, ZeroConstructor, IsPlainOldData)
	class AnimSequenceBase*                            ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function ContextualAnimation.ContextualAnimSceneInstance.OnNotifyEndReceived
struct ContextualAnimSceneInstance_OnNotifyEndReceived_Params
{
	struct FName                                       NotifyName_69;                                            // (Parm, ZeroConstructor, IsPlainOldData)
	struct FBranchingPointNotifyPayload                BranchingPointNotifyPayload_69;                           // (ConstParm, Parm, OutParm, ReferenceParm)
};

// Function ContextualAnimation.ContextualAnimSceneInstance.OnNotifyBeginReceived
struct ContextualAnimSceneInstance_OnNotifyBeginReceived_Params
{
	struct FName                                       NotifyName_69;                                            // (Parm, ZeroConstructor, IsPlainOldData)
	struct FBranchingPointNotifyPayload                BranchingPointNotifyPayload_69;                           // (ConstParm, Parm, OutParm, ReferenceParm)
};

// Function ContextualAnimation.ContextualAnimSceneInstance.OnMontageBlendingOut
struct ContextualAnimSceneInstance_OnMontageBlendingOut_Params
{
	class AnimMontage*                                 Montage_69;                                               // (Parm, ZeroConstructor)
	bool                                               bInterrupted_69;                                          // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function ContextualAnimation.ContextualAnimSceneInstance.GetActorByRole
struct ContextualAnimSceneInstance_GetActorByRole_Params
{
	struct FName                                       Role_69;                                                  // (Parm, ZeroConstructor, IsPlainOldData)
	class Actor_32759*                                 ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function ContextualAnimation.ContextualAnimSelectionCriterion_Blueprint.GetSceneAsset
struct ContextualAnimSelectionCriterion_Blueprint_GetSceneAsset_Params
{
	class ContextualAnimSceneAsset*                    ReturnValue_69;                                           // (ConstParm, Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function ContextualAnimation.ContextualAnimSelectionCriterion_Blueprint.BP_DoesQuerierPassCondition
struct ContextualAnimSelectionCriterion_Blueprint_BP_DoesQuerierPassCondition_Params
{
	struct FContextualAnimSceneBindingContext          Primary_69;                                               // (ConstParm, Parm, OutParm, ReferenceParm)
	struct FContextualAnimSceneBindingContext          Querier_69;                                               // (ConstParm, Parm, OutParm, ReferenceParm)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function ContextualAnimation.ContextualAnimTransition.CanEnterTransition
struct ContextualAnimTransition_CanEnterTransition_Params
{
	class ContextualAnimSceneInstance*                 SceneInstance_69;                                         // (ConstParm, Parm, ZeroConstructor)
	struct FName                                       FromSection_69;                                           // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
	struct FName                                       ToSection_69;                                             // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function ContextualAnimation.ContextualAnimUtilities.BP_SceneBindings_GetSectionAndAnimSetIndices
struct ContextualAnimUtilities_BP_SceneBindings_GetSectionAndAnimSetIndices_Params
{
	struct FContextualAnimSceneBindings                Bindings_69;                                              // (ConstParm, Parm, OutParm, ReferenceParm)
	int                                                SectionIdx_69;                                            // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	int                                                AnimSetIdx_69;                                            // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
};

// Function ContextualAnimation.ContextualAnimUtilities.BP_SceneBindings_GetSceneAsset
struct ContextualAnimUtilities_BP_SceneBindings_GetSceneAsset_Params
{
	struct FContextualAnimSceneBindings                Bindings_69;                                              // (ConstParm, Parm, OutParm, ReferenceParm)
	class ContextualAnimSceneAsset*                    ReturnValue_69;                                           // (ConstParm, Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function ContextualAnimation.ContextualAnimUtilities.BP_SceneBindings_GetBindings
struct ContextualAnimUtilities_BP_SceneBindings_GetBindings_Params
{
	struct FContextualAnimSceneBindings                Bindings_69;                                              // (ConstParm, Parm, OutParm, ReferenceParm)
	TArray<struct FContextualAnimSceneBinding>         ReturnValue_69;                                           // (ConstParm, Parm, OutParm, ZeroConstructor, ReturnParm, ReferenceParm)
};

// Function ContextualAnimation.ContextualAnimUtilities.BP_SceneBindings_GetBindingByRole
struct ContextualAnimUtilities_BP_SceneBindings_GetBindingByRole_Params
{
	struct FContextualAnimSceneBindings                Bindings_69;                                              // (ConstParm, Parm, OutParm, ReferenceParm)
	struct FName                                       Role_69;                                                  // (Parm, ZeroConstructor, IsPlainOldData)
	struct FContextualAnimSceneBinding                 ReturnValue_69;                                           // (ConstParm, Parm, OutParm, ReturnParm, ReferenceParm)
};

// Function ContextualAnimation.ContextualAnimUtilities.BP_SceneBindings_GetBindingByActor
struct ContextualAnimUtilities_BP_SceneBindings_GetBindingByActor_Params
{
	struct FContextualAnimSceneBindings                Bindings_69;                                              // (ConstParm, Parm, OutParm, ReferenceParm)
	class Actor_32759*                                 Actor_69;                                                 // (ConstParm, Parm, ZeroConstructor)
	struct FContextualAnimSceneBinding                 ReturnValue_69;                                           // (ConstParm, Parm, OutParm, ReturnParm, ReferenceParm)
};

// Function ContextualAnimation.ContextualAnimUtilities.BP_SceneBindings_GetAlignmentTransformForRoleRelativeToPivot
struct ContextualAnimUtilities_BP_SceneBindings_GetAlignmentTransformForRoleRelativeToPivot_Params
{
	struct FContextualAnimSceneBindings                Bindings_69;                                              // (ConstParm, Parm, OutParm, ReferenceParm)
	struct FName                                       Role_69;                                                  // (Parm, ZeroConstructor, IsPlainOldData)
	struct FContextualAnimSetPivot                     Pivot_69;                                                 // (ConstParm, Parm, OutParm, ReferenceParm)
	float                                              Time_69;                                                  // (Parm, ZeroConstructor, IsPlainOldData)
	struct FCoreUObject_FTransform                     ReturnValue_69;                                           // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function ContextualAnimation.ContextualAnimUtilities.BP_SceneBindings_GetAlignmentTransformForRoleRelativeToOtherRole
struct ContextualAnimUtilities_BP_SceneBindings_GetAlignmentTransformForRoleRelativeToOtherRole_Params
{
	struct FContextualAnimSceneBindings                Bindings_69;                                              // (ConstParm, Parm, OutParm, ReferenceParm)
	struct FName                                       Role_69;                                                  // (Parm, ZeroConstructor, IsPlainOldData)
	struct FName                                       RelativeToRole_69;                                        // (Parm, ZeroConstructor, IsPlainOldData)
	float                                              Time_69;                                                  // (Parm, ZeroConstructor, IsPlainOldData)
	struct FCoreUObject_FTransform                     ReturnValue_69;                                           // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function ContextualAnimation.ContextualAnimUtilities.BP_SceneBindings_CalculateAnimSetPivots
struct ContextualAnimUtilities_BP_SceneBindings_CalculateAnimSetPivots_Params
{
	struct FContextualAnimSceneBindings                Bindings_69;                                              // (ConstParm, Parm, OutParm, ReferenceParm)
	TArray<struct FContextualAnimSetPivot>             OutPivots_69;                                             // (Parm, OutParm, ZeroConstructor)
};

// Function ContextualAnimation.ContextualAnimUtilities.BP_SceneBindings_AddOrUpdateWarpTargetsForBindings
struct ContextualAnimUtilities_BP_SceneBindings_AddOrUpdateWarpTargetsForBindings_Params
{
	struct FContextualAnimSceneBindings                Bindings_69;                                              // (ConstParm, Parm, OutParm, ReferenceParm)
};

// Function ContextualAnimation.ContextualAnimUtilities.BP_SceneBindingContext_MakeFromActorWithExternalTransform
struct ContextualAnimUtilities_BP_SceneBindingContext_MakeFromActorWithExternalTransform_Params
{
	class Actor_32759*                                 Actor_69;                                                 // (Parm, ZeroConstructor)
	struct FCoreUObject_FTransform                     ExternalTransform_69;                                     // (Parm, IsPlainOldData)
	struct FContextualAnimSceneBindingContext          ReturnValue_69;                                           // (Parm, OutParm, ReturnParm)
};

// Function ContextualAnimation.ContextualAnimUtilities.BP_SceneBindingContext_MakeFromActor
struct ContextualAnimUtilities_BP_SceneBindingContext_MakeFromActor_Params
{
	class Actor_32759*                                 Actor_69;                                                 // (Parm, ZeroConstructor)
	struct FContextualAnimSceneBindingContext          ReturnValue_69;                                           // (Parm, OutParm, ReturnParm)
};

// Function ContextualAnimation.ContextualAnimUtilities.BP_SceneBindingContext_GetVelocity
struct ContextualAnimUtilities_BP_SceneBindingContext_GetVelocity_Params
{
	struct FContextualAnimSceneBindingContext          BindingContext_69;                                        // (ConstParm, Parm, OutParm, ReferenceParm)
	struct FVector                                     ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function ContextualAnimation.ContextualAnimUtilities.BP_SceneBindingContext_GetTransform
struct ContextualAnimUtilities_BP_SceneBindingContext_GetTransform_Params
{
	struct FContextualAnimSceneBindingContext          BindingContext_69;                                        // (ConstParm, Parm, OutParm, ReferenceParm)
	struct FCoreUObject_FTransform                     ReturnValue_69;                                           // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function ContextualAnimation.ContextualAnimUtilities.BP_SceneBindingContext_GetActor
struct ContextualAnimUtilities_BP_SceneBindingContext_GetActor_Params
{
	struct FContextualAnimSceneBindingContext          BindingContext_69;                                        // (ConstParm, Parm, OutParm, ReferenceParm)
	class Actor_32759*                                 ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function ContextualAnimation.ContextualAnimUtilities.BP_SceneBinding_GetSkeletalMesh
struct ContextualAnimUtilities_BP_SceneBinding_GetSkeletalMesh_Params
{
	struct FContextualAnimSceneBinding                 Binding_69;                                               // (ConstParm, Parm, OutParm, ReferenceParm)
	class SkeletalMeshComponent*                       ReturnValue_69;                                           // (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)
};

// Function ContextualAnimation.ContextualAnimUtilities.BP_SceneBinding_GetRole
struct ContextualAnimUtilities_BP_SceneBinding_GetRole_Params
{
	struct FContextualAnimSceneBinding                 Binding_69;                                               // (ConstParm, Parm, OutParm, ReferenceParm)
	struct FName                                       ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function ContextualAnimation.ContextualAnimUtilities.BP_SceneBinding_GetAnimationToPlay
struct ContextualAnimUtilities_BP_SceneBinding_GetAnimationToPlay_Params
{
	struct FContextualAnimSceneBinding                 Binding_69;                                               // (ConstParm, Parm, OutParm, ReferenceParm)
	class AnimSequenceBase*                            ReturnValue_69;                                           // (ConstParm, Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function ContextualAnimation.ContextualAnimUtilities.BP_SceneBinding_GetActor
struct ContextualAnimUtilities_BP_SceneBinding_GetActor_Params
{
	struct FContextualAnimSceneBinding                 Binding_69;                                               // (ConstParm, Parm, OutParm, ReferenceParm)
	class Actor_32759*                                 ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function ContextualAnimation.ContextualAnimUtilities.BP_Montage_GetSectionTimeLeftFromPos
struct ContextualAnimUtilities_BP_Montage_GetSectionTimeLeftFromPos_Params
{
	class AnimMontage*                                 Montage_69;                                               // (ConstParm, Parm, ZeroConstructor)
	float                                              Position_69;                                              // (Parm, ZeroConstructor, IsPlainOldData)
	float                                              ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function ContextualAnimation.ContextualAnimUtilities.BP_Montage_GetSectionStartAndEndTime
struct ContextualAnimUtilities_BP_Montage_GetSectionStartAndEndTime_Params
{
	class AnimMontage*                                 Montage_69;                                               // (ConstParm, Parm, ZeroConstructor)
	int                                                SectionIndex_69;                                          // (Parm, ZeroConstructor, IsPlainOldData)
	float                                              OutStartTime_69;                                          // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	float                                              OutEndTime_69;                                            // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
};

// Function ContextualAnimation.ContextualAnimUtilities.BP_Montage_GetSectionLength
struct ContextualAnimUtilities_BP_Montage_GetSectionLength_Params
{
	class AnimMontage*                                 Montage_69;                                               // (ConstParm, Parm, ZeroConstructor)
	int                                                SectionIndex_69;                                          // (Parm, ZeroConstructor, IsPlainOldData)
	float                                              ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function ContextualAnimation.ContextualAnimUtilities.BP_DrawDebugPose
struct ContextualAnimUtilities_BP_DrawDebugPose_Params
{
	class Object_32759*                                WorldContextObject_69;                                    // (ConstParm, Parm, ZeroConstructor)
	class AnimSequenceBase*                            Animation_69;                                             // (ConstParm, Parm, ZeroConstructor)
	float                                              Time_69;                                                  // (Parm, ZeroConstructor, IsPlainOldData)
	struct FCoreUObject_FTransform                     LocalToWorldTransform_69;                                 // (Parm, IsPlainOldData)
	struct FLinearColor                                Color_69;                                                 // (Parm, ZeroConstructor, IsPlainOldData)
	float                                              LifeTime_69;                                              // (Parm, ZeroConstructor, IsPlainOldData)
	float                                              Thickness_69;                                             // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function ContextualAnimation.ContextualAnimUtilities.BP_CreateContextualAnimSceneBindingsForTwoActors
struct ContextualAnimUtilities_BP_CreateContextualAnimSceneBindingsForTwoActors_Params
{
	class ContextualAnimSceneAsset*                    SceneAsset_69;                                            // (ConstParm, Parm, ZeroConstructor)
	struct FContextualAnimSceneBindingContext          Primary_69;                                               // (ConstParm, Parm, OutParm, ReferenceParm)
	struct FContextualAnimSceneBindingContext          Secondary_69;                                             // (ConstParm, Parm, OutParm, ReferenceParm)
	struct FContextualAnimSceneBindings                OutBindings_69;                                           // (Parm, OutParm)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function ContextualAnimation.ContextualAnimUtilities.BP_CreateContextualAnimSceneBindings
struct ContextualAnimUtilities_BP_CreateContextualAnimSceneBindings_Params
{
	class ContextualAnimSceneAsset*                    SceneAsset_69;                                            // (ConstParm, Parm, ZeroConstructor)
	TMap<struct FName, struct FContextualAnimSceneBindingContext> Params_69;                                                // (ConstParm, Parm, OutParm, ReferenceParm)
	struct FContextualAnimSceneBindings                OutBindings_69;                                           // (Parm, OutParm)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

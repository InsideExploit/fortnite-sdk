#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function CompanionAI.companion_ai.WaitForEntityMovement_L_Nentity_M_Nfloat_R
struct companion_ai_WaitForEntityMovement_L_Nentity_M_Nfloat_R_Params
{
	class task_t_*                                     __verse_0xC1E81372_CallingTask;                           // (ExportObject, Parm, ZeroConstructor, InstancedReference)
	int64_t                                            __verse_0xA3A00DDB_CallerResumeState;                     // (Parm, ZeroConstructor, IsPlainOldData)
	int64_t                                            __verse_0x2AC0E4D8_CallerCancelState;                     // (Parm, ZeroConstructor, IsPlainOldData)
	struct Ftuple_Lentity_Mfloat_R                     __verse_0xB2CDDD72_Argument;                              // (Parm)
	class task_t_*                                     RetVal;                                                   // (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)
};

// Function CompanionAI.companion_ai.WaitForDamage
struct companion_ai_WaitForDamage_Params
{
	class task_t_*                                     __verse_0xC1E81372_CallingTask;                           // (ExportObject, Parm, ZeroConstructor, InstancedReference)
	int64_t                                            __verse_0xA3A00DDB_CallerResumeState;                     // (Parm, ZeroConstructor, IsPlainOldData)
	int64_t                                            __verse_0x2AC0E4D8_CallerCancelState;                     // (Parm, ZeroConstructor, IsPlainOldData)
	struct FCompanionAI_Ftuple_L_R                     __verse_0xB2CDDD72_Argument;                              // (Parm)
	class task_t_*                                     RetVal;                                                   // (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)
};

// Function CompanionAI.companion_ai.TacticalSprintService
struct companion_ai_TacticalSprintService_Params
{
	class task_t_*                                     __verse_0xC1E81372_CallingTask;                           // (ExportObject, Parm, ZeroConstructor, InstancedReference)
	int64_t                                            __verse_0xA3A00DDB_CallerResumeState;                     // (Parm, ZeroConstructor, IsPlainOldData)
	int64_t                                            __verse_0x2AC0E4D8_CallerCancelState;                     // (Parm, ZeroConstructor, IsPlainOldData)
	struct FCompanionAI_Ftuple_L_R                     __verse_0xB2CDDD72_Argument;                              // (Parm)
	class task_t_*                                     RetVal;                                                   // (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)
};

// Function CompanionAI.companion_ai.SprintService
struct companion_ai_SprintService_Params
{
	class task_t_*                                     __verse_0xC1E81372_CallingTask;                           // (ExportObject, Parm, ZeroConstructor, InstancedReference)
	int64_t                                            __verse_0xA3A00DDB_CallerResumeState;                     // (Parm, ZeroConstructor, IsPlainOldData)
	int64_t                                            __verse_0x2AC0E4D8_CallerCancelState;                     // (Parm, ZeroConstructor, IsPlainOldData)
	struct FCompanionAI_Ftuple_L_R                     __verse_0xB2CDDD72_Argument;                              // (Parm)
	class task_t_*                                     RetVal;                                                   // (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)
};

// Function CompanionAI.companion_ai.ShootTargetService_L_Nfloat_R
struct companion_ai_ShootTargetService_L_Nfloat_R_Params
{
	class task_t_*                                     __verse_0xC1E81372_CallingTask;                           // (ExportObject, Parm, ZeroConstructor, InstancedReference)
	int64_t                                            __verse_0xA3A00DDB_CallerResumeState;                     // (Parm, ZeroConstructor, IsPlainOldData)
	int64_t                                            __verse_0x2AC0E4D8_CallerCancelState;                     // (Parm, ZeroConstructor, IsPlainOldData)
	double                                             __verse_0xB2CDDD72_Argument;                              // (Parm, ZeroConstructor, IsPlainOldData)
	class task_t_*                                     RetVal;                                                   // (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)
};

// Function CompanionAI.companion_ai.SetLeashPosition_L_Nvector3_M_Nfloat_M_Nentity_R
struct companion_ai_SetLeashPosition_L_Nvector3_M_Nfloat_M_Nentity_R_Params
{
	class task_t_*                                     __verse_0xC1E81372_CallingTask;                           // (ExportObject, Parm, ZeroConstructor, InstancedReference)
	int64_t                                            __verse_0xA3A00DDB_CallerResumeState;                     // (Parm, ZeroConstructor, IsPlainOldData)
	int64_t                                            __verse_0x2AC0E4D8_CallerCancelState;                     // (Parm, ZeroConstructor, IsPlainOldData)
	struct Ftuple_Lvector3_Mfloat_Mentity_R            __verse_0xB2CDDD72_Argument;                              // (Parm)
	class task_t_*                                     RetVal;                                                   // (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)
};

// Function CompanionAI.companion_ai.ReviveCommand_L_Nfort__character_R
struct companion_ai_ReviveCommand_L_Nfort__character_R_Params
{
	class task_t_*                                     __verse_0xC1E81372_CallingTask;                           // (ExportObject, Parm, ZeroConstructor, InstancedReference)
	int64_t                                            __verse_0xA3A00DDB_CallerResumeState;                     // (Parm, ZeroConstructor, IsPlainOldData)
	int64_t                                            __verse_0x2AC0E4D8_CallerCancelState;                     // (Parm, ZeroConstructor, IsPlainOldData)
	class Object_32759*                                __verse_0xB2CDDD72_Argument;                              // (ExportObject, Parm, ZeroConstructor, InstancedReference)
	class task_t_*                                     RetVal;                                                   // (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)
};

// Function CompanionAI.companion_ai._L_2fFortnite_2ecom_2fAI_2fCompanionAI_2fcompanion__ai_N_ROnUnconverted
struct companion_ai__L_2fFortnite_2ecom_2fAI_2fCompanionAI_2fcompanion__ai_N_ROnUnconverted_Params
{
	struct FCompanionAI_Ftuple_L_R                     __verse_0xB2CDDD72_Argument;                              // (Parm)
};

// Function CompanionAI.companion_ai._L_2fFortnite_2ecom_2fAI_2fCompanionAI_2fcompanion__ai_N_ROnUnconverted_L_Nany_R_Nvoid
struct companion_ai__L_2fFortnite_2ecom_2fAI_2fCompanionAI_2fcompanion__ai_N_ROnUnconverted_L_Nany_R_Nvoid_Params
{
};

// Function CompanionAI.companion_ai._L_2fFortnite_2ecom_2fAI_2fCompanionAI_2fcompanion__ai_N_ROnConverted
struct companion_ai__L_2fFortnite_2ecom_2fAI_2fCompanionAI_2fcompanion__ai_N_ROnConverted_Params
{
	struct FCompanionAI_Ftuple_L_R                     __verse_0xB2CDDD72_Argument;                              // (Parm)
};

// Function CompanionAI.companion_ai._L_2fFortnite_2ecom_2fAI_2fCompanionAI_2fcompanion__ai_N_ROnConverted_L_Nany_R_Nvoid
struct companion_ai__L_2fFortnite_2ecom_2fAI_2fCompanionAI_2fcompanion__ai_N_ROnConverted_L_Nany_R_Nvoid_Params
{
};

// Function CompanionAI.companion_ai.OnBegin
struct companion_ai_OnBegin_Params
{
	class task_t_*                                     __verse_0xC1E81372_CallingTask;                           // (ExportObject, Parm, ZeroConstructor, InstancedReference)
	int64_t                                            __verse_0xA3A00DDB_CallerResumeState;                     // (Parm, ZeroConstructor, IsPlainOldData)
	int64_t                                            __verse_0x2AC0E4D8_CallerCancelState;                     // (Parm, ZeroConstructor, IsPlainOldData)
	struct FCompanionAI_Ftuple_L_R                     __verse_0xB2CDDD72_Argument;                              // (Parm)
	class task_t_*                                     RetVal;                                                   // (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)
};

// Function CompanionAI.companion_ai.LookAtThreatTask
struct companion_ai_LookAtThreatTask_Params
{
	class task_t_*                                     __verse_0xC1E81372_CallingTask;                           // (ExportObject, Parm, ZeroConstructor, InstancedReference)
	int64_t                                            __verse_0xA3A00DDB_CallerResumeState;                     // (Parm, ZeroConstructor, IsPlainOldData)
	int64_t                                            __verse_0x2AC0E4D8_CallerCancelState;                     // (Parm, ZeroConstructor, IsPlainOldData)
	struct FCompanionAI_Ftuple_L_R                     __verse_0xB2CDDD72_Argument;                              // (Parm)
	class task_t_*                                     RetVal;                                                   // (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)
};

// Function CompanionAI.companion_ai.LookAtOrAttackTarget
struct companion_ai_LookAtOrAttackTarget_Params
{
	class task_t_*                                     __verse_0xC1E81372_CallingTask;                           // (ExportObject, Parm, ZeroConstructor, InstancedReference)
	int64_t                                            __verse_0xA3A00DDB_CallerResumeState;                     // (Parm, ZeroConstructor, IsPlainOldData)
	int64_t                                            __verse_0x2AC0E4D8_CallerCancelState;                     // (Parm, ZeroConstructor, IsPlainOldData)
	struct FCompanionAI_Ftuple_L_R                     __verse_0xB2CDDD72_Argument;                              // (Parm)
	class task_t_*                                     RetVal;                                                   // (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)
};

// Function CompanionAI.companion_ai.LookAroundTask_L_Nvector3_M_Nfloat_M_Nfloat_R
struct companion_ai_LookAroundTask_L_Nvector3_M_Nfloat_M_Nfloat_R_Params
{
	class task_t_*                                     __verse_0xC1E81372_CallingTask;                           // (ExportObject, Parm, ZeroConstructor, InstancedReference)
	int64_t                                            __verse_0xA3A00DDB_CallerResumeState;                     // (Parm, ZeroConstructor, IsPlainOldData)
	int64_t                                            __verse_0x2AC0E4D8_CallerCancelState;                     // (Parm, ZeroConstructor, IsPlainOldData)
	struct FCompanionAI_Ftuple_Lvector3_Mfloat_Mfloat_R __verse_0xB2CDDD72_Argument;                              // (Parm)
	class task_t_*                                     RetVal;                                                   // (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)
};

// Function CompanionAI.companion_ai._L_2fFortnite_2ecom_2fAI_2fCompanionAI_2fcompanion__ai_N_RLogAndDisplayOnScreen_L_N_Kchar_R
struct companion_ai__L_2fFortnite_2ecom_2fAI_2fCompanionAI_2fcompanion__ai_N_RLogAndDisplayOnScreen_L_N_Kchar_R_Params
{
};

// Function CompanionAI.companion_ai.HandleReviveCommand_L_Nping__info_R
struct companion_ai_HandleReviveCommand_L_Nping__info_R_Params
{
	class task_t_*                                     __verse_0xC1E81372_CallingTask;                           // (ExportObject, Parm, ZeroConstructor, InstancedReference)
	int64_t                                            __verse_0xA3A00DDB_CallerResumeState;                     // (Parm, ZeroConstructor, IsPlainOldData)
	int64_t                                            __verse_0x2AC0E4D8_CallerCancelState;                     // (Parm, ZeroConstructor, IsPlainOldData)
	struct Fping_info                                  __verse_0xB2CDDD72_Argument;                              // (Parm)
	class task_t_*                                     RetVal;                                                   // (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)
};

// Function CompanionAI.companion_ai.HandleObstacleTask_L_N_Qentity_R
struct companion_ai_HandleObstacleTask_L_N_Qentity_R_Params
{
	class task_t_*                                     __verse_0xC1E81372_CallingTask;                           // (ExportObject, Parm, ZeroConstructor, InstancedReference)
	int64_t                                            __verse_0xA3A00DDB_CallerResumeState;                     // (Parm, ZeroConstructor, IsPlainOldData)
	int64_t                                            __verse_0x2AC0E4D8_CallerCancelState;                     // (Parm, ZeroConstructor, IsPlainOldData)
	class task_t_*                                     RetVal;                                                   // (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)
};

// Function CompanionAI.companion_ai.HandleNPCCommand_L_Nping__info_R
struct companion_ai_HandleNPCCommand_L_Nping__info_R_Params
{
	class task_t_*                                     __verse_0xC1E81372_CallingTask;                           // (ExportObject, Parm, ZeroConstructor, InstancedReference)
	int64_t                                            __verse_0xA3A00DDB_CallerResumeState;                     // (Parm, ZeroConstructor, IsPlainOldData)
	int64_t                                            __verse_0x2AC0E4D8_CallerCancelState;                     // (Parm, ZeroConstructor, IsPlainOldData)
	struct Fping_info                                  __verse_0xB2CDDD72_Argument;                              // (Parm)
	class task_t_*                                     RetVal;                                                   // (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)
};

// Function CompanionAI.companion_ai.HandleHoldPositionCommand_L_Nping__info_R
struct companion_ai_HandleHoldPositionCommand_L_Nping__info_R_Params
{
	class task_t_*                                     __verse_0xC1E81372_CallingTask;                           // (ExportObject, Parm, ZeroConstructor, InstancedReference)
	int64_t                                            __verse_0xA3A00DDB_CallerResumeState;                     // (Parm, ZeroConstructor, IsPlainOldData)
	int64_t                                            __verse_0x2AC0E4D8_CallerCancelState;                     // (Parm, ZeroConstructor, IsPlainOldData)
	struct Fping_info                                  __verse_0xB2CDDD72_Argument;                              // (Parm)
	class task_t_*                                     RetVal;                                                   // (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)
};

// Function CompanionAI.companion_ai.HandleGoToCommand_L_Nping__info_R
struct companion_ai_HandleGoToCommand_L_Nping__info_R_Params
{
	class task_t_*                                     __verse_0xC1E81372_CallingTask;                           // (ExportObject, Parm, ZeroConstructor, InstancedReference)
	int64_t                                            __verse_0xA3A00DDB_CallerResumeState;                     // (Parm, ZeroConstructor, IsPlainOldData)
	int64_t                                            __verse_0x2AC0E4D8_CallerCancelState;                     // (Parm, ZeroConstructor, IsPlainOldData)
	struct Fping_info                                  __verse_0xB2CDDD72_Argument;                              // (Parm)
	class task_t_*                                     RetVal;                                                   // (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)
};

// Function CompanionAI.companion_ai.HandleGoTo_L_Nping__info_R
struct companion_ai_HandleGoTo_L_Nping__info_R_Params
{
	class task_t_*                                     __verse_0xC1E81372_CallingTask;                           // (ExportObject, Parm, ZeroConstructor, InstancedReference)
	int64_t                                            __verse_0xA3A00DDB_CallerResumeState;                     // (Parm, ZeroConstructor, IsPlainOldData)
	int64_t                                            __verse_0x2AC0E4D8_CallerCancelState;                     // (Parm, ZeroConstructor, IsPlainOldData)
	struct Fping_info                                  __verse_0xB2CDDD72_Argument;                              // (Parm)
	class task_t_*                                     RetVal;                                                   // (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)
};

// Function CompanionAI.companion_ai.HandleBackToMeCommand_L_Nping__info_R
struct companion_ai_HandleBackToMeCommand_L_Nping__info_R_Params
{
	class task_t_*                                     __verse_0xC1E81372_CallingTask;                           // (ExportObject, Parm, ZeroConstructor, InstancedReference)
	int64_t                                            __verse_0xA3A00DDB_CallerResumeState;                     // (Parm, ZeroConstructor, IsPlainOldData)
	int64_t                                            __verse_0x2AC0E4D8_CallerCancelState;                     // (Parm, ZeroConstructor, IsPlainOldData)
	struct Fping_info                                  __verse_0xB2CDDD72_Argument;                              // (Parm)
	class task_t_*                                     RetVal;                                                   // (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)
};

// Function CompanionAI.companion_ai.GoToPositionTask_L_Nvector3_M_N_Qfort__character_M_Nlogic_M_Nnavigation__parameters_R
struct companion_ai_GoToPositionTask_L_Nvector3_M_N_Qfort__character_M_Nlogic_M_Nnavigation__parameters_R_Params
{
	class task_t_*                                     __verse_0xC1E81372_CallingTask;                           // (ExportObject, Parm, ZeroConstructor, InstancedReference)
	int64_t                                            __verse_0xA3A00DDB_CallerResumeState;                     // (Parm, ZeroConstructor, IsPlainOldData)
	int64_t                                            __verse_0x2AC0E4D8_CallerCancelState;                     // (Parm, ZeroConstructor, IsPlainOldData)
	struct Ftuple_Lvector3_M_Qfort__character_Mlogic_M_QNavigationParameters_Nnavigation__parameters_20_3d_20_2e_2e_2e_R __verse_0xB2CDDD72_Argument;                              // (Parm)
	class task_t_*                                     RetVal;                                                   // (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)
};

// Function CompanionAI.companion_ai.GoToAndAttackTask_L_Nthreat__info_R
struct companion_ai_GoToAndAttackTask_L_Nthreat__info_R_Params
{
	class task_t_*                                     __verse_0xC1E81372_CallingTask;                           // (ExportObject, Parm, ZeroConstructor, InstancedReference)
	int64_t                                            __verse_0xA3A00DDB_CallerResumeState;                     // (Parm, ZeroConstructor, IsPlainOldData)
	int64_t                                            __verse_0x2AC0E4D8_CallerCancelState;                     // (Parm, ZeroConstructor, IsPlainOldData)
	struct Fthreat_info                                __verse_0xB2CDDD72_Argument;                              // (Parm)
	class task_t_*                                     RetVal;                                                   // (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)
};

// Function CompanionAI.companion_ai.GetThreat
struct companion_ai_GetThreat_Params
{
	class task_t_*                                     __verse_0xC1E81372_CallingTask;                           // (ExportObject, Parm, ZeroConstructor, InstancedReference)
	int64_t                                            __verse_0xA3A00DDB_CallerResumeState;                     // (Parm, ZeroConstructor, IsPlainOldData)
	int64_t                                            __verse_0x2AC0E4D8_CallerCancelState;                     // (Parm, ZeroConstructor, IsPlainOldData)
	struct FCompanionAI_Ftuple_L_R                     __verse_0xB2CDDD72_Argument;                              // (Parm)
	class task_t_*                                     RetVal;                                                   // (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)
};

// Function CompanionAI.companion_ai.GetObstacle
struct companion_ai_GetObstacle_Params
{
	class task_t_*                                     __verse_0xC1E81372_CallingTask;                           // (ExportObject, Parm, ZeroConstructor, InstancedReference)
	int64_t                                            __verse_0xA3A00DDB_CallerResumeState;                     // (Parm, ZeroConstructor, IsPlainOldData)
	int64_t                                            __verse_0x2AC0E4D8_CallerCancelState;                     // (Parm, ZeroConstructor, IsPlainOldData)
	struct FCompanionAI_Ftuple_L_R                     __verse_0xB2CDDD72_Argument;                              // (Parm)
	class task_t_*                                     RetVal;                                                   // (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)
};

// Function CompanionAI.companion_ai.GetNewThreat
struct companion_ai_GetNewThreat_Params
{
	class task_t_*                                     __verse_0xC1E81372_CallingTask;                           // (ExportObject, Parm, ZeroConstructor, InstancedReference)
	int64_t                                            __verse_0xA3A00DDB_CallerResumeState;                     // (Parm, ZeroConstructor, IsPlainOldData)
	int64_t                                            __verse_0x2AC0E4D8_CallerCancelState;                     // (Parm, ZeroConstructor, IsPlainOldData)
	struct FCompanionAI_Ftuple_L_R                     __verse_0xB2CDDD72_Argument;                              // (Parm)
	class task_t_*                                     RetVal;                                                   // (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)
};

// Function CompanionAI.companion_ai.GetNewTargetPerception_L_N_Qthreat__info_R
struct companion_ai_GetNewTargetPerception_L_N_Qthreat__info_R_Params
{
	class task_t_*                                     __verse_0xC1E81372_CallingTask;                           // (ExportObject, Parm, ZeroConstructor, InstancedReference)
	int64_t                                            __verse_0xA3A00DDB_CallerResumeState;                     // (Parm, ZeroConstructor, IsPlainOldData)
	int64_t                                            __verse_0x2AC0E4D8_CallerCancelState;                     // (Parm, ZeroConstructor, IsPlainOldData)
	class task_t_*                                     RetVal;                                                   // (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)
};

// Function CompanionAI.companion_ai.GetNewObstacle
struct companion_ai_GetNewObstacle_Params
{
	class task_t_*                                     __verse_0xC1E81372_CallingTask;                           // (ExportObject, Parm, ZeroConstructor, InstancedReference)
	int64_t                                            __verse_0xA3A00DDB_CallerResumeState;                     // (Parm, ZeroConstructor, IsPlainOldData)
	int64_t                                            __verse_0x2AC0E4D8_CallerCancelState;                     // (Parm, ZeroConstructor, IsPlainOldData)
	struct FCompanionAI_Ftuple_L_R                     __verse_0xB2CDDD72_Argument;                              // (Parm)
	class task_t_*                                     RetVal;                                                   // (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)
};

// Function CompanionAI.companion_ai.GameLoop
struct companion_ai_GameLoop_Params
{
	class task_t_*                                     __verse_0xC1E81372_CallingTask;                           // (ExportObject, Parm, ZeroConstructor, InstancedReference)
	int64_t                                            __verse_0xA3A00DDB_CallerResumeState;                     // (Parm, ZeroConstructor, IsPlainOldData)
	int64_t                                            __verse_0x2AC0E4D8_CallerCancelState;                     // (Parm, ZeroConstructor, IsPlainOldData)
	struct FCompanionAI_Ftuple_L_R                     __verse_0xB2CDDD72_Argument;                              // (Parm)
	class task_t_*                                     RetVal;                                                   // (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)
};

// Function CompanionAI.companion_ai.DrawSphere_L_Nvector3_M_Nfloat_M_Ncolor_R
struct companion_ai_DrawSphere_L_Nvector3_M_Nfloat_M_Ncolor_R_Params
{
	class task_t_*                                     __verse_0xC1E81372_CallingTask;                           // (ExportObject, Parm, ZeroConstructor, InstancedReference)
	int64_t                                            __verse_0xA3A00DDB_CallerResumeState;                     // (Parm, ZeroConstructor, IsPlainOldData)
	int64_t                                            __verse_0x2AC0E4D8_CallerCancelState;                     // (Parm, ZeroConstructor, IsPlainOldData)
	struct Ftuple_Lvector3_Mfloat_Mcolor_R             __verse_0xB2CDDD72_Argument;                              // (Parm)
	class task_t_*                                     RetVal;                                                   // (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)
};

// Function CompanionAI.companion_ai.CrouchUntilHit
struct companion_ai_CrouchUntilHit_Params
{
	class task_t_*                                     __verse_0xC1E81372_CallingTask;                           // (ExportObject, Parm, ZeroConstructor, InstancedReference)
	int64_t                                            __verse_0xA3A00DDB_CallerResumeState;                     // (Parm, ZeroConstructor, IsPlainOldData)
	int64_t                                            __verse_0x2AC0E4D8_CallerCancelState;                     // (Parm, ZeroConstructor, IsPlainOldData)
	struct FCompanionAI_Ftuple_L_R                     __verse_0xB2CDDD72_Argument;                              // (Parm)
	class task_t_*                                     RetVal;                                                   // (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)
};

// Function CompanionAI.companion_ai.CrouchService
struct companion_ai_CrouchService_Params
{
	class task_t_*                                     __verse_0xC1E81372_CallingTask;                           // (ExportObject, Parm, ZeroConstructor, InstancedReference)
	int64_t                                            __verse_0xA3A00DDB_CallerResumeState;                     // (Parm, ZeroConstructor, IsPlainOldData)
	int64_t                                            __verse_0x2AC0E4D8_CallerCancelState;                     // (Parm, ZeroConstructor, IsPlainOldData)
	struct FCompanionAI_Ftuple_L_R                     __verse_0xB2CDDD72_Argument;                              // (Parm)
	class task_t_*                                     RetVal;                                                   // (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)
};

// Function CompanionAI.companion_ai.$InitInstance
struct companion_ai_$InitInstance_Params
{
};

// Function CompanionAI.companion_ai.$Block
struct companion_ai_$Block_Params
{
};

// Function CompanionAI.companion_ai.$InitCDO
struct companion_ai_$InitCDO_Params
{
};

// Function CompanionAI.CompanionAI._L_2fFortnite_2ecom_2fAI_2fCompanionAI_N_RToString_L_Ncommand__type_R
struct CompanionAI__L_2fFortnite_2ecom_2fAI_2fCompanionAI_N_RToString_L_Ncommand__type_R_Params
{
	Ecommand_type                                      __verse_0xB2CDDD72_Argument;                              // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function CompanionAI.CompanionAI._L_2fFortnite_2ecom_2fAI_2fCompanionAI_N_RToString_L_Nentity__type_R
struct CompanionAI__L_2fFortnite_2ecom_2fAI_2fCompanionAI_N_RToString_L_Nentity__type_R_Params
{
	Eentity_type                                       __verse_0xB2CDDD72_Argument;                              // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function CompanionAI.CompanionAI._L_2fFortnite_2ecom_2fAI_2fCompanionAI_N_RGetFortCharacter_L_Nentity_R
struct CompanionAI__L_2fFortnite_2ecom_2fAI_2fCompanionAI_N_RGetFortCharacter_L_Nentity_R_Params
{
	class Entity*                                      __verse_0xB2CDDD72_Argument;                              // (ExportObject, Parm, ZeroConstructor, InstancedReference)
};

// Function CompanionAI.CompanionAI._L_2fFortnite_2ecom_2fAI_2fCompanionAI_N_RCompare_L_Nobstacle__info_M_Nentity_R
struct CompanionAI__L_2fFortnite_2ecom_2fAI_2fCompanionAI_N_RCompare_L_Nobstacle__info_M_Nentity_R_Params
{
	struct Ftuple_Lobstacle__info_Mentity_R            __verse_0xB2CDDD72_Argument;                              // (Parm)
	bool                                               RetVal;                                                   // (Parm, OutParm, ReturnParm)
};

// Function CompanionAI.CompanionAI.ping_info$Factory
struct CompanionAI_ping_info$Factory_Params
{
	struct Fping_info                                  RetVal;                                                   // (Parm, OutParm, ReturnParm)
};

// Function CompanionAI.CompanionAI.$InitCDO
struct CompanionAI_$InitCDO_Params
{
};

// Function CompanionAI.fort_br_ai_actions_interface.RunDefaultBehavior
struct fort_br_ai_actions_interface_RunDefaultBehavior_Params
{
	class task_t_*                                     __verse_0xC1E81372_CallingTask;                           // (ExportObject, Parm, ZeroConstructor, InstancedReference)
	int64_t                                            __verse_0xA3A00DDB_CallerResumeState;                     // (Parm, ZeroConstructor, IsPlainOldData)
	int64_t                                            __verse_0x2AC0E4D8_CallerCancelState;                     // (Parm, ZeroConstructor, IsPlainOldData)
	struct FCompanionAI_Ftuple_L_R                     __verse_0xB2CDDD72_Argument;                              // (Parm)
	class task_t_*                                     RetVal;                                                   // (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)
};

// Function CompanionAI.fort_br_ai_movement_interface._L_2fFortnite_2ecom_2fAI_2fCompanionAI_2ffort__br__ai__movement__interface_N_RSetLeashActor_L_Nentity_R
struct fort_br_ai_movement_interface__L_2fFortnite_2ecom_2fAI_2fCompanionAI_2ffort__br__ai__movement__interface_N_RSetLeashActor_L_Nentity_R_Params
{
	class Entity*                                      __verse_0xB2CDDD72_Argument;                              // (ExportObject, Parm, ZeroConstructor, InstancedReference)
};

// Function CompanionAI.fort_npc_component._L_2fFortnite_2ecom_2fAI_2fCompanionAI_2ffort__br__ai__movement__interface_N_RSetLeashActor_L_Nentity_R
struct fort_npc_component__L_2fFortnite_2ecom_2fAI_2fCompanionAI_2ffort__br__ai__movement__interface_N_RSetLeashActor_L_Nentity_R_Params
{
	class Entity*                                      __verse_0xB2CDDD72_Argument;                              // (ExportObject, Parm, ZeroConstructor, InstancedReference)
};

// Function CompanionAI.fort_npc_component.RunDefaultBehavior
struct fort_npc_component_RunDefaultBehavior_Params
{
	class task_t_*                                     __verse_0xC1E81372_CallingTask;                           // (ExportObject, Parm, ZeroConstructor, InstancedReference)
	int64_t                                            __verse_0xA3A00DDB_CallerResumeState;                     // (Parm, ZeroConstructor, IsPlainOldData)
	int64_t                                            __verse_0x2AC0E4D8_CallerCancelState;                     // (Parm, ZeroConstructor, IsPlainOldData)
	struct FCompanionAI_Ftuple_L_R                     __verse_0xB2CDDD72_Argument;                              // (Parm)
	class task_t_*                                     RetVal;                                                   // (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)
};

// Function CompanionAI.fort_npc_component.$InitInstance
struct fort_npc_component_$InitInstance_Params
{
};

// Function CompanionAI.fort_npc_component.$Block
struct fort_npc_component_$Block_Params
{
};

// Function CompanionAI.fort_npc_component.$InitCDO
struct fort_npc_component_$InitCDO_Params
{
};

// Function CompanionAI.fort_ping_interface._L_2fFortnite_2ecom_2fAI_2fCompanionAI_2ffort__ping__interface_N_RUnconvertedEvent
struct fort_ping_interface__L_2fFortnite_2ecom_2fAI_2fCompanionAI_2ffort__ping__interface_N_RUnconvertedEvent_Params
{
	struct FCompanionAI_Ftuple_L_R                     __verse_0xB2CDDD72_Argument;                              // (Parm)
	class Object_32759*                                RetVal;                                                   // (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)
};

// Function CompanionAI.fort_ping_interface.OnNPCCommand
struct fort_ping_interface_OnNPCCommand_Params
{
	class task_t_*                                     __verse_0xC1E81372_CallingTask;                           // (ExportObject, Parm, ZeroConstructor, InstancedReference)
	int64_t                                            __verse_0xA3A00DDB_CallerResumeState;                     // (Parm, ZeroConstructor, IsPlainOldData)
	int64_t                                            __verse_0x2AC0E4D8_CallerCancelState;                     // (Parm, ZeroConstructor, IsPlainOldData)
	struct FCompanionAI_Ftuple_L_R                     __verse_0xB2CDDD72_Argument;                              // (Parm)
	class task_t_*                                     RetVal;                                                   // (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)
};

// Function CompanionAI.fort_ping_interface._L_2fFortnite_2ecom_2fAI_2fCompanionAI_2ffort__ping__interface_N_RGetCurrentNPCCommand
struct fort_ping_interface__L_2fFortnite_2ecom_2fAI_2fCompanionAI_2ffort__ping__interface_N_RGetCurrentNPCCommand_Params
{
	struct FCompanionAI_Ftuple_L_R                     __verse_0xB2CDDD72_Argument;                              // (Parm)
};

// Function CompanionAI.fort_ping_interface._L_2fFortnite_2ecom_2fAI_2fCompanionAI_2ffort__ping__interface_N_REnableCommandWheel_L_Nlogic_R
struct fort_ping_interface__L_2fFortnite_2ecom_2fAI_2fCompanionAI_2ffort__ping__interface_N_REnableCommandWheel_L_Nlogic_R_Params
{
	bool                                               __verse_0xB2CDDD72_Argument;                              // (Parm)
};

// Function CompanionAI.fort_ping_interface._L_2fFortnite_2ecom_2fAI_2fCompanionAI_2ffort__ping__interface_N_RDeclineNPCCommand_L_Nlogic_R
struct fort_ping_interface__L_2fFortnite_2ecom_2fAI_2fCompanionAI_2ffort__ping__interface_N_RDeclineNPCCommand_L_Nlogic_R_Params
{
	bool                                               __verse_0xB2CDDD72_Argument;                              // (Parm)
};

// Function CompanionAI.fort_ping_interface._L_2fFortnite_2ecom_2fAI_2fCompanionAI_2ffort__ping__interface_N_RConvertedEvent
struct fort_ping_interface__L_2fFortnite_2ecom_2fAI_2fCompanionAI_2ffort__ping__interface_N_RConvertedEvent_Params
{
	struct FCompanionAI_Ftuple_L_R                     __verse_0xB2CDDD72_Argument;                              // (Parm)
	class Object_32759*                                RetVal;                                                   // (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)
};

// Function CompanionAI.fort_ping_interface._L_2fFortnite_2ecom_2fAI_2fCompanionAI_2ffort__ping__interface_N_RAreNPCCommandsEnabled
struct fort_ping_interface__L_2fFortnite_2ecom_2fAI_2fCompanionAI_2ffort__ping__interface_N_RAreNPCCommandsEnabled_Params
{
	struct FCompanionAI_Ftuple_L_R                     __verse_0xB2CDDD72_Argument;                              // (Parm)
	bool                                               RetVal;                                                   // (Parm, OutParm, ReturnParm)
};

// Function CompanionAI.log_companion_ai.$InitInstance
struct log_companion_ai_$InitInstance_Params
{
};

// Function CompanionAI.log_companion_ai.$Block
struct log_companion_ai_$Block_Params
{
};

// Function CompanionAI.log_companion_ai.$InitCDO
struct log_companion_ai_$InitCDO_Params
{
};

// Function CompanionAI.ping_component._L_2fFortnite_2ecom_2fAI_2fCompanionAI_2ffort__ping__interface_N_RUnconvertedEvent
struct ping_component__L_2fFortnite_2ecom_2fAI_2fCompanionAI_2ffort__ping__interface_N_RUnconvertedEvent_Params
{
	struct FCompanionAI_Ftuple_L_R                     __verse_0xB2CDDD72_Argument;                              // (Parm)
	class Object_32759*                                RetVal;                                                   // (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)
};

// Function CompanionAI.ping_component.OnNPCCommand
struct ping_component_OnNPCCommand_Params
{
	class task_t_*                                     __verse_0xC1E81372_CallingTask;                           // (ExportObject, Parm, ZeroConstructor, InstancedReference)
	int64_t                                            __verse_0xA3A00DDB_CallerResumeState;                     // (Parm, ZeroConstructor, IsPlainOldData)
	int64_t                                            __verse_0x2AC0E4D8_CallerCancelState;                     // (Parm, ZeroConstructor, IsPlainOldData)
	struct FCompanionAI_Ftuple_L_R                     __verse_0xB2CDDD72_Argument;                              // (Parm)
	class task_t_*                                     RetVal;                                                   // (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)
};

// Function CompanionAI.ping_component._L_2fFortnite_2ecom_2fAI_2fCompanionAI_2ffort__ping__interface_N_RGetCurrentNPCCommand
struct ping_component__L_2fFortnite_2ecom_2fAI_2fCompanionAI_2ffort__ping__interface_N_RGetCurrentNPCCommand_Params
{
	struct FCompanionAI_Ftuple_L_R                     __verse_0xB2CDDD72_Argument;                              // (Parm)
};

// Function CompanionAI.ping_component._L_2fFortnite_2ecom_2fAI_2fCompanionAI_2ffort__ping__interface_N_REnableCommandWheel_L_Nlogic_R
struct ping_component__L_2fFortnite_2ecom_2fAI_2fCompanionAI_2ffort__ping__interface_N_REnableCommandWheel_L_Nlogic_R_Params
{
	bool                                               __verse_0xB2CDDD72_Argument;                              // (Parm)
};

// Function CompanionAI.ping_component._L_2fFortnite_2ecom_2fAI_2fCompanionAI_2ffort__ping__interface_N_RDeclineNPCCommand_L_Nlogic_R
struct ping_component__L_2fFortnite_2ecom_2fAI_2fCompanionAI_2ffort__ping__interface_N_RDeclineNPCCommand_L_Nlogic_R_Params
{
	bool                                               __verse_0xB2CDDD72_Argument;                              // (Parm)
};

// Function CompanionAI.ping_component._L_2fFortnite_2ecom_2fAI_2fCompanionAI_2ffort__ping__interface_N_RConvertedEvent
struct ping_component__L_2fFortnite_2ecom_2fAI_2fCompanionAI_2ffort__ping__interface_N_RConvertedEvent_Params
{
	struct FCompanionAI_Ftuple_L_R                     __verse_0xB2CDDD72_Argument;                              // (Parm)
	class Object_32759*                                RetVal;                                                   // (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)
};

// Function CompanionAI.ping_component._L_2fFortnite_2ecom_2fAI_2fCompanionAI_2ffort__ping__interface_N_RAreNPCCommandsEnabled
struct ping_component__L_2fFortnite_2ecom_2fAI_2fCompanionAI_2ffort__ping__interface_N_RAreNPCCommandsEnabled_Params
{
	struct FCompanionAI_Ftuple_L_R                     __verse_0xB2CDDD72_Argument;                              // (Parm)
	bool                                               RetVal;                                                   // (Parm, OutParm, ReturnParm)
};

// Function CompanionAI.ping_component.$InitInstance
struct ping_component_$InitInstance_Params
{
};

// Function CompanionAI.ping_component.$Block
struct ping_component_$Block_Params
{
};

// Function CompanionAI.ping_component.$InitCDO
struct ping_component_$InitCDO_Params
{
};

// Function CompanionAI.task_companion_ai$CrouchService.Update
struct task_companion_ai$CrouchService_Update_Params
{
	int64_t                                            RetVal;                                                   // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CompanionAI.task_companion_ai$CrouchUntilHit.Update
struct task_companion_ai$CrouchUntilHit_Update_Params
{
	int64_t                                            RetVal;                                                   // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CompanionAI.task_companion_ai$DrawSphere_L_Nvector3_M_Nfloat_M_Ncolor_R.Update
struct task_companion_ai$DrawSphere_L_Nvector3_M_Nfloat_M_Ncolor_R_Update_Params
{
	int64_t                                            RetVal;                                                   // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CompanionAI.task_companion_ai$GameLoop.Update
struct task_companion_ai$GameLoop_Update_Params
{
	int64_t                                            RetVal;                                                   // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CompanionAI.task_companion_ai$GetNewObstacle.Update
struct task_companion_ai$GetNewObstacle_Update_Params
{
	int64_t                                            RetVal;                                                   // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CompanionAI.task_companion_ai$GetNewTargetPerception_L_N_Qthreat__info_R.Update
struct task_companion_ai$GetNewTargetPerception_L_N_Qthreat__info_R_Update_Params
{
	int64_t                                            RetVal;                                                   // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CompanionAI.task_companion_ai$GetNewThreat.Update
struct task_companion_ai$GetNewThreat_Update_Params
{
	int64_t                                            RetVal;                                                   // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CompanionAI.task_companion_ai$GetObstacle.Update
struct task_companion_ai$GetObstacle_Update_Params
{
	int64_t                                            RetVal;                                                   // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CompanionAI.task_companion_ai$GetThreat.Update
struct task_companion_ai$GetThreat_Update_Params
{
	int64_t                                            RetVal;                                                   // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CompanionAI.task_companion_ai$GoToAndAttackTask_L_Nthreat__info_R.Update
struct task_companion_ai$GoToAndAttackTask_L_Nthreat__info_R_Update_Params
{
	int64_t                                            RetVal;                                                   // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CompanionAI.task_companion_ai$GoToPositionTask_L_Nvector3_M_N_Qfort__character_M_Nlogic_M_Nnavigation__parameters_R.Update
struct task_companion_ai$GoToPositionTask_L_Nvector3_M_N_Qfort__character_M_Nlogic_M_Nnavigation__parameters_R_Update_Params
{
	int64_t                                            RetVal;                                                   // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CompanionAI.task_companion_ai$HandleBackToMeCommand_L_Nping__info_R.Update
struct task_companion_ai$HandleBackToMeCommand_L_Nping__info_R_Update_Params
{
	int64_t                                            RetVal;                                                   // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CompanionAI.task_companion_ai$HandleGoTo_L_Nping__info_R.Update
struct task_companion_ai$HandleGoTo_L_Nping__info_R_Update_Params
{
	int64_t                                            RetVal;                                                   // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CompanionAI.task_companion_ai$HandleGoToCommand_L_Nping__info_R.Update
struct task_companion_ai$HandleGoToCommand_L_Nping__info_R_Update_Params
{
	int64_t                                            RetVal;                                                   // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CompanionAI.task_companion_ai$HandleHoldPositionCommand_L_Nping__info_R.Update
struct task_companion_ai$HandleHoldPositionCommand_L_Nping__info_R_Update_Params
{
	int64_t                                            RetVal;                                                   // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CompanionAI.task_companion_ai$HandleNPCCommand_L_Nping__info_R.Update
struct task_companion_ai$HandleNPCCommand_L_Nping__info_R_Update_Params
{
	int64_t                                            RetVal;                                                   // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CompanionAI.task_companion_ai$HandleObstacleTask_L_N_Qentity_R.Update
struct task_companion_ai$HandleObstacleTask_L_N_Qentity_R_Update_Params
{
	int64_t                                            RetVal;                                                   // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CompanionAI.task_companion_ai$HandleReviveCommand_L_Nping__info_R.Update
struct task_companion_ai$HandleReviveCommand_L_Nping__info_R_Update_Params
{
	int64_t                                            RetVal;                                                   // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CompanionAI.task_companion_ai$LookAroundTask_L_Nvector3_M_Nfloat_M_Nfloat_R.Update
struct task_companion_ai$LookAroundTask_L_Nvector3_M_Nfloat_M_Nfloat_R_Update_Params
{
	int64_t                                            RetVal;                                                   // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CompanionAI.task_companion_ai$LookAtOrAttackTarget.Update
struct task_companion_ai$LookAtOrAttackTarget_Update_Params
{
	int64_t                                            RetVal;                                                   // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CompanionAI.task_companion_ai$LookAtThreatTask.Update
struct task_companion_ai$LookAtThreatTask_Update_Params
{
	int64_t                                            RetVal;                                                   // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CompanionAI.task_companion_ai$OnBegin.Update
struct task_companion_ai$OnBegin_Update_Params
{
	int64_t                                            RetVal;                                                   // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CompanionAI.task_companion_ai$ReviveCommand_L_Nfort__character_R.Update
struct task_companion_ai$ReviveCommand_L_Nfort__character_R_Update_Params
{
	int64_t                                            RetVal;                                                   // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CompanionAI.task_companion_ai$SetLeashPosition_L_Nvector3_M_Nfloat_M_Nentity_R.Update
struct task_companion_ai$SetLeashPosition_L_Nvector3_M_Nfloat_M_Nentity_R_Update_Params
{
	int64_t                                            RetVal;                                                   // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CompanionAI.task_companion_ai$ShootTargetService_L_Nfloat_R.Update
struct task_companion_ai$ShootTargetService_L_Nfloat_R_Update_Params
{
	int64_t                                            RetVal;                                                   // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CompanionAI.task_companion_ai$SprintService.Update
struct task_companion_ai$SprintService_Update_Params
{
	int64_t                                            RetVal;                                                   // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CompanionAI.task_companion_ai$TacticalSprintService.Update
struct task_companion_ai$TacticalSprintService_Update_Params
{
	int64_t                                            RetVal;                                                   // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CompanionAI.task_companion_ai$WaitForDamage.Update
struct task_companion_ai$WaitForDamage_Update_Params
{
	int64_t                                            RetVal;                                                   // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CompanionAI.task_companion_ai$WaitForEntityMovement_L_Nentity_M_Nfloat_R.Update
struct task_companion_ai$WaitForEntityMovement_L_Nentity_M_Nfloat_R_Update_Params
{
	int64_t                                            RetVal;                                                   // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CompanionAI.task_fort_br_ai_actions_interface$RunDefaultBehavior.Update
struct task_fort_br_ai_actions_interface$RunDefaultBehavior_Update_Params
{
	int64_t                                            RetVal;                                                   // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CompanionAI.task_fort_npc_component$RunDefaultBehavior.Update
struct task_fort_npc_component$RunDefaultBehavior_Update_Params
{
	int64_t                                            RetVal;                                                   // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CompanionAI.task_fort_ping_interface$OnNPCCommand.Update
struct task_fort_ping_interface$OnNPCCommand_Update_Params
{
	int64_t                                            RetVal;                                                   // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CompanionAI.task_ping_component$OnNPCCommand.Update
struct task_ping_component$OnNPCCommand_Update_Params
{
	int64_t                                            RetVal;                                                   // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Functions
//---------------------------------------------------------------------------

// Function CRDPlayerTracker.CRDPlayerTrackerMarker.DestroyPlayerTrackerWidget
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// class FortPlayerControllerGameplay* InFortPlayerControllerGameplay_69 (Parm, ZeroConstructor)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool CRDPlayerTrackerMarker::DestroyPlayerTrackerWidget(class FortPlayerControllerGameplay* InFortPlayerControllerGameplay_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CRDPlayerTracker.CRDPlayerTrackerMarker.DestroyPlayerTrackerWidget"));

	CRDPlayerTrackerMarker_DestroyPlayerTrackerWidget_Params params;
	params.InFortPlayerControllerGameplay_69 = InFortPlayerControllerGameplay_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CRDPlayerTracker.CRDPlayerTrackerMarker.CreatePlayerTrackerWidget
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// class FortPlayerControllerGameplay* InFortPlayerControllerGameplay_69 (Parm, ZeroConstructor)
// class FortPlayerStateAthena*   AssociatedPSA_69               (Parm, ZeroConstructor)
// class UserWidget*              ReturnValue_69                 (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)

class UserWidget* CRDPlayerTrackerMarker::CreatePlayerTrackerWidget(class FortPlayerControllerGameplay* InFortPlayerControllerGameplay_69, class FortPlayerStateAthena* AssociatedPSA_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CRDPlayerTracker.CRDPlayerTrackerMarker.CreatePlayerTrackerWidget"));

	CRDPlayerTrackerMarker_CreatePlayerTrackerWidget_Params params;
	params.InFortPlayerControllerGameplay_69 = InFortPlayerControllerGameplay_69;
	params.AssociatedPSA_69 = AssociatedPSA_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Enums
//---------------------------------------------------------------------------

// Enum CustomizableObjectPopulation.EPopulationConstraintType
enum class EPopulationConstraintType : uint8_t
{
	NONE                           = 0,
	BOOL                           = 1,
	DISCRETE                       = 2,
	DISCRETE_FLOAT                 = 3,
	DISCRETE_COLOR                 = 4,
	TAG                            = 5,
	RANGE                          = 6,
	CURVE                          = 7,
	CURVE_COLOR                    = 8,
	EPopulationConstraintType_MAX  = 9
};


// Enum CustomizableObjectPopulation.ECurveColor
enum class ECurveColor : uint8_t
{
	RED                            = 0,
	GREEN                          = 1,
	BLUE                           = 2,
	ALPHA                          = 3,
	ECurveColor_MAX                = 4
};



//---------------------------------------------------------------------------
//Script Structs
//---------------------------------------------------------------------------

// ScriptStruct CustomizableObjectPopulation.ClassWeightPair
// 0x0010
struct FClassWeightPair
{
	class CustomizableObjectPopulationClass*           Class_69;                                                 // 0x0000(0x0008) (Edit, ZeroConstructor)
	int                                                ClassWeight_69;                                           // 0x0008(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x000C(0x0004) MISSED OFFSET
};

// ScriptStruct CustomizableObjectPopulation.ConstraintRanges
// 0x000C
struct FConstraintRanges
{
	float                                              MinimumValue_69;                                          // 0x0000(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	float                                              MaximumValue_69;                                          // 0x0004(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	int                                                RangeWeight_69;                                           // 0x0008(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct CustomizableObjectPopulation.CustomizableObjectPopulationConstraint
// 0x0070
struct FCustomizableObjectPopulationConstraint
{
	EPopulationConstraintType                          Type_69;                                                  // 0x0000(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0001(0x0003) MISSED OFFSET
	int                                                ConstraintWeight_69;                                      // 0x0004(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	int                                                TrueWeight_69;                                            // 0x0008(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	int                                                FalseWeight_69;                                           // 0x000C(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	struct FString                                     DiscreteValue_69;                                         // 0x0010(0x0010) (Edit, ZeroConstructor)
	struct FLinearColor                                DiscreteColor_69;                                         // 0x0020(0x0010) (Edit, ZeroConstructor, IsPlainOldData)
	TArray<struct FString>                             Allowlist_69;                                             // 0x0030(0x0010) (Edit, ZeroConstructor)
	TArray<struct FString>                             Blocklist_69;                                             // 0x0040(0x0010) (Edit, ZeroConstructor)
	TArray<struct FConstraintRanges>                   Ranges_69;                                                // 0x0050(0x0010) (Edit, ZeroConstructor)
	class CurveBase*                                   Curve_69;                                                 // 0x0060(0x0008) (Edit, ZeroConstructor)
	ECurveColor                                        CurveColor_69;                                            // 0x0068(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x7];                                       // 0x0069(0x0007) MISSED OFFSET
};

// ScriptStruct CustomizableObjectPopulation.CustomizableObjectPopulationCharacteristic
// 0x0020
struct FCustomizableObjectPopulationCharacteristic
{
	struct FString                                     ParameterName_69;                                         // 0x0000(0x0010) (Edit, ZeroConstructor)
	TArray<struct FCustomizableObjectPopulationConstraint> Constraints_69;                                           // 0x0010(0x0010) (Edit, ZeroConstructor)
};

// ScriptStruct CustomizableObjectPopulation.PopulationClassParameterOptions
// 0x0010
struct FPopulationClassParameterOptions
{
	TArray<struct FString>                             Tags_69;                                                  // 0x0000(0x0010) (Edit, ZeroConstructor)
};

// ScriptStruct CustomizableObjectPopulation.PopulationClassParameter
// 0x0060
struct FPopulationClassParameter
{
	TArray<struct FString>                             Tags_69;                                                  // 0x0000(0x0010) (Edit, ZeroConstructor)
	TMap<struct FString, struct FPopulationClassParameterOptions> ParameterOptions_69;                                      // 0x0010(0x0050) (Edit)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

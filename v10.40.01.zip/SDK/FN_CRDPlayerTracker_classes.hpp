#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Classes
//---------------------------------------------------------------------------

// Class CRDPlayerTracker.CRDPlayerTrackerComponent
// 0x0000 (0x00A0 - 0x00A0)
class CRDPlayerTrackerComponent : public ActorComponent
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CRDPlayerTracker.CRDPlayerTrackerComponent"));
		
		return ptr;
	}

};


// Class CRDPlayerTracker.CRDPlayerTrackerMarker
// 0x0010 (0x0298 - 0x0288)
class CRDPlayerTrackerMarker : public Actor_32759
{
public:
	class UserWidget*                                  WidgetClass_69;                                           // 0x0288(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance)
	class ActorComponent*                              PlayerTrackerUIActorComponent_69;                         // 0x0290(0x0008) (ExportObject, ZeroConstructor, Transient, InstancedReference)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CRDPlayerTracker.CRDPlayerTrackerMarker"));
		
		return ptr;
	}


	bool DestroyPlayerTrackerWidget(class FortPlayerControllerGameplay* InFortPlayerControllerGameplay_69);
	class UserWidget* CreatePlayerTrackerWidget(class FortPlayerControllerGameplay* InFortPlayerControllerGameplay_69, class FortPlayerStateAthena* AssociatedPSA_69);
};


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function BattlePassS22UI.BattlePassLandingPageS22.OnBattlePassSubscriptionAllowed
struct BattlePassLandingPageS22_OnBattlePassSubscriptionAllowed_Params
{
	bool                                               bSubscriptionAllowed_69;                                  // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function BattlePassS22UI.BattlePassLandingPageS22.OnBattlePassOwned
struct BattlePassLandingPageS22_OnBattlePassOwned_Params
{
};

// Function BattlePassS22UI.BattlePassLandingPageS22.OnBattlePassGiftingAllowed
struct BattlePassLandingPageS22_OnBattlePassGiftingAllowed_Params
{
	bool                                               bGiftingAllowed_69;                                       // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function BattlePassS22UI.BattlePassRewardPageS22.OnPageChanged
struct BattlePassRewardPageS22_OnPageChanged_Params
{
	int                                                PageNumber_69;                                            // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function BattlePassS22UI.BattlePassRewardPageS22.OnInputMethodChanged
struct BattlePassRewardPageS22_OnInputMethodChanged_Params
{
	ECommonInputType                                   InputType_69;                                             // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function BattlePassS22UI.BattlePassRewardPageS22.OnInitForPageType
struct BattlePassRewardPageS22_OnInitForPageType_Params
{
	ERewardPageType                                    InRewardPageType_69;                                      // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function BattlePassS22UI.BattlePassScreenS22.OverviewShowAnimationFinished
struct BattlePassScreenS22_OverviewShowAnimationFinished_Params
{
};

// Function BattlePassS22UI.BattlePassScreenS22.OnTransitionItemDetails
struct BattlePassScreenS22_OnTransitionItemDetails_Params
{
	bool                                               bTransitionForward_69;                                    // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function BattlePassS22UI.BattlePassScreenS22.OnSetResourcePrice
struct BattlePassScreenS22_OnSetResourcePrice_Params
{
	int                                                Cost_69;                                                  // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	class FortPersistentResourceItemDefinition*        PersistentResource_69;                                    // (ConstParm, Parm, ZeroConstructor)
};

// Function BattlePassS22UI.BattlePassScreenS22.OnSetPrerequisiteInfo
struct BattlePassScreenS22_OnSetPrerequisiteInfo_Params
{
	struct FText                                       Description_69;                                           // (ConstParm, Parm, OutParm, ReferenceParm)
	int                                                OwnedRewards_69;                                          // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	int                                                NeededRewards_69;                                         // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bShowPrerequisiteLock_69;                                 // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function BattlePassS22UI.BattlePassScreenS22.OnSetItemPrice
struct BattlePassScreenS22_OnSetItemPrice_Params
{
	int                                                Cost_69;                                                  // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	EBattlePassCurrencyType                            CurrencyType_69;                                          // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function BattlePassS22UI.BattlePassScreenS22.OnSetDynamicInput
struct BattlePassScreenS22_OnSetDynamicInput_Params
{
	EBattlePassInputs                                  InputType_69;                                             // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	class BattlePassInputData*                         InputData_69;                                             // (ConstParm, Parm, ZeroConstructor)
};

// Function BattlePassS22UI.BattlePassScreenS22.OnSetClaimedRewardInfo
struct BattlePassScreenS22_OnSetClaimedRewardInfo_Params
{
	int                                                OwnedRewards_69;                                          // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	int                                                TotalRewards_69;                                          // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function BattlePassS22UI.BattlePassScreenS22.OnLevelChanged
struct BattlePassScreenS22_OnLevelChanged_Params
{
	int                                                Level_69;                                                 // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function BattlePassS22UI.BattlePassScreenS22.OnItemDelayed
struct BattlePassScreenS22_OnItemDelayed_Params
{
	struct FTimespan                                   Delay_69;                                                 // (ConstParm, Parm, ZeroConstructor)
};

// Function BattlePassS22UI.BattlePassScreenS22.OnInsufficientResource
struct BattlePassScreenS22_OnInsufficientResource_Params
{
	class FortPersistentResourceItemDefinition*        PersistentResource_69;                                    // (ConstParm, Parm, ZeroConstructor)
};

// Function BattlePassS22UI.BattlePassScreenS22.OnInsufficientFunds
struct BattlePassScreenS22_OnInsufficientFunds_Params
{
	EBattlePassCurrencyType                            CurrencyType_69;                                          // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function BattlePassS22UI.BattlePassScreenS22.OnBattlePassOwned
struct BattlePassScreenS22_OnBattlePassOwned_Params
{
};

// Function BattlePassS22UI.BattlePassScreenS22.IsSeasonalCustomizationItemOwned
struct BattlePassScreenS22_IsSeasonalCustomizationItemOwned_Params
{
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function BattlePassS22UI.BattlePassScreenS22.HandleSwitcherVisibilityShown
struct BattlePassScreenS22_HandleSwitcherVisibilityShown_Params
{
};

// Function BattlePassS22UI.BattlePassScreenS22.HandleClaimRewardComplete
struct BattlePassScreenS22_HandleClaimRewardComplete_Params
{
	bool                                               bSuccess_69;                                              // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	TArray<struct FString>                             OfferTemplateIdList_69;                                   // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
};

// Function BattlePassS22UI.BattlePassScreenS22.GetQuestPageDelay
struct BattlePassScreenS22_GetQuestPageDelay_Params
{
	struct FTimespan                                   ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function BattlePassS22UI.FortBattlePassResourcesWidgetS22.OnStylePointsRewardsSet
struct FortBattlePassResourcesWidgetS22_OnStylePointsRewardsSet_Params
{
	int                                                Rewards_69;                                               // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function BattlePassS22UI.FortBattlePassResourcesWidgetS22.OnBattleStarRewardsSet
struct FortBattlePassResourcesWidgetS22_OnBattleStarRewardsSet_Params
{
	int                                                Rewards_69;                                               // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function BattlePassS22UI.FortBattlePassTutorialTooltipS22.ShowTooltip
struct FortBattlePassTutorialTooltipS22_ShowTooltip_Params
{
};

// Function BattlePassS22UI.FortBattlePassTutorialTooltipS22.SetText
struct FortBattlePassTutorialTooltipS22_SetText_Params
{
	struct FText                                       Text_69;                                                  // (Parm)
};

// Function BattlePassS22UI.FortBattlePassTutorialTooltipS22.HideTooltip
struct FortBattlePassTutorialTooltipS22_HideTooltip_Params
{
};

// Function BattlePassS22UI.RebootRallyQuestPanel.OnRebootRallyEligibilityUpdated
struct RebootRallyQuestPanel_OnRebootRallyEligibilityUpdated_Params
{
	bool                                               bEligible_69;                                             // (Parm, ZeroConstructor, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

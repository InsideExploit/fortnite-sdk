#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Classes
//---------------------------------------------------------------------------

// WidgetBlueprintGeneratedClass ArrowCursorWidget.ArrowCursorWidget_C
// 0x0000 (0x0268 - 0x0268)
class ArrowCursorWidget_C : public UserWidget
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("WidgetBlueprintGeneratedClass ArrowCursorWidget.ArrowCursorWidget_C"));
		
		return ptr;
	}


	struct FSlateBrush GetBackground_0();
};


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

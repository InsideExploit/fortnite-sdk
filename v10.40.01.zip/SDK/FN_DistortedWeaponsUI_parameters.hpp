#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function DistortedWeaponsUI.ChromeWeaponInfoWidget.OnWeaponUpgraded
struct ChromeWeaponInfoWidget_OnWeaponUpgraded_Params
{
};

// Function DistortedWeaponsUI.ChromeWeaponInfoWidget.OnWeaponStartUpgrading
struct ChromeWeaponInfoWidget_OnWeaponStartUpgrading_Params
{
};

// Function DistortedWeaponsUI.ChromeWeaponInfoWidget.OnWeaponRemoved
struct ChromeWeaponInfoWidget_OnWeaponRemoved_Params
{
};

// Function DistortedWeaponsUI.ChromeWeaponInfoWidget.OnWeaponEquipped
struct ChromeWeaponInfoWidget_OnWeaponEquipped_Params
{
};

// Function DistortedWeaponsUI.ChromeWeaponInfoWidget.OnReadyToUpgradeWeapon
struct ChromeWeaponInfoWidget_OnReadyToUpgradeWeapon_Params
{
	EFortRarity                                        NextRarity_69;                                            // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function DistortedWeaponsUI.ChromeWeaponInfoWidget.OnGainedXp
struct ChromeWeaponInfoWidget_OnGainedXp_Params
{
	float                                              CurrentXPPercentage_69;                                   // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function DistortedWeaponsUI.ChromeWeaponInfoWidget.HandleXpChanged
struct ChromeWeaponInfoWidget_HandleXpChanged_Params
{
	float                                              XPDelta_69;                                               // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	float                                              CurrentXPPercentage_69;                                   // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function DistortedWeaponsUI.ChromeWeaponInfoWidget.HandleWeaponUpgraded
struct ChromeWeaponInfoWidget_HandleWeaponUpgraded_Params
{
};

// Function DistortedWeaponsUI.ChromeWeaponInfoWidget.HandleWeaponUnEquipped
struct ChromeWeaponInfoWidget_HandleWeaponUnEquipped_Params
{
};

// Function DistortedWeaponsUI.ChromeWeaponInfoWidget.HandleWeaponEquipped
struct ChromeWeaponInfoWidget_HandleWeaponEquipped_Params
{
	class FortWeapon*                                  NewWeapon_69;                                             // (Parm, ZeroConstructor)
	class FortWeapon*                                  PrevWeapon_69;                                            // (Parm, ZeroConstructor)
};

// Function DistortedWeaponsUI.ChromeWeaponInfoWidget.HandleUpgradeTriggered
struct ChromeWeaponInfoWidget_HandleUpgradeTriggered_Params
{
	float                                              ReloadTime_69;                                            // (Parm, ZeroConstructor, IsPlainOldData)
	EFortWeaponReloadType                              ReloadType_69;                                            // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function DistortedWeaponsUI.ChromeWeaponInfoWidget.HandlePowerUpPending
struct ChromeWeaponInfoWidget_HandlePowerUpPending_Params
{
};

// Function DistortedWeaponsUI.ChromeWeaponInfoWidget.GetCurrentWeaponRarity
struct ChromeWeaponInfoWidget_GetCurrentWeaponRarity_Params
{
	EFortRarity                                        ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

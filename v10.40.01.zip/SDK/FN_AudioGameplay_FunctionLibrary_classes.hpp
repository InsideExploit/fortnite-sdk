#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Classes
//---------------------------------------------------------------------------

// BlueprintGeneratedClass AudioGameplay_FunctionLibrary.AudioGameplay_FunctionLibrary_C
// 0x0000 (0x0028 - 0x0028)
class AudioGameplay_FunctionLibrary_C : public BlueprintFunctionLibrary
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("BlueprintGeneratedClass AudioGameplay_FunctionLibrary.AudioGameplay_FunctionLibrary_C"));
		
		return ptr;
	}


	void STATIC_GetAudioForPlayerEvent(class Actor_32759* Target_1, class SoundBase* _1P_Sound_1, class SoundBase* _3P_Sound_1, class Object_32759* __WorldContext_1, class SoundBase** AudioAsset_1);
	bool STATIC_IsActorLocal(class Actor_32759* Actor_1, class Object_32759* __WorldContext_1);
	void STATIC_GetAudioForDamageEvent(class Actor_32759* Receiver_1, class Actor_32759* Instigator_1, class SoundBase* ReceiverSound_1, class SoundBase* InstigatorSound_1, class SoundBase* ObserverSound_1, class Object_32759* __WorldContext_1, class SoundBase** AudioAsset_1);
};


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

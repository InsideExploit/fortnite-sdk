#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Classes
//---------------------------------------------------------------------------

// Class AudioMotorSim.AudioMotorModelComponent
// 0x0060 (0x0100 - 0x00A0)
class AudioMotorModelComponent : public ActorComponent
{
public:
	TArray<struct FMotorSimEntry>                      SimComponents_69;                                         // 0x00A0(0x0010) (ZeroConstructor, Transient)
	TArray<TScriptInterface<class AudioMotorSimOutput>> AudioComponents_69;                                       // 0x00B0(0x0010) (ZeroConstructor, Transient)
	unsigned char                                      UnknownData00[0x40];                                      // 0x00C0(0x0040) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AudioMotorSim.AudioMotorModelComponent"));
		
		return ptr;
	}


	void Update(const struct FAudioMotorSimInputContext& Input_69);
	void StopOutput();
	void StartOutput();
	void Reset();
	void RemoveMotorSimComponent(const TScriptInterface<class AudioMotorSim>& InComponent_69);
	void RemoveMotorAudioComponent(const TScriptInterface<class AudioMotorSimOutput>& InComponent_69);
	struct FAudioMotorSimRuntimeContext GetRuntimeInfo();
	float GetRpm();
	int GetGear();
	struct FAudioMotorSimInputContext GetCachedInputData();
	void AddMotorSimComponent(const TScriptInterface<class AudioMotorSim>& InComponent_69, int SortOrder_69);
	void AddMotorAudioComponent(const TScriptInterface<class AudioMotorSimOutput>& InComponent_69);
};


// Class AudioMotorSim.AudioMotorSim
// 0x0000 (0x0028 - 0x0028)
class AudioMotorSim : public Interface
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AudioMotorSim.AudioMotorSim"));
		
		return ptr;
	}

};


// Class AudioMotorSim.AudioMotorSimComponent
// 0x0008 (0x00A8 - 0x00A0)
class AudioMotorSimComponent : public ActorComponent
{
public:
	unsigned char                                      UnknownData00[0x8];                                       // 0x00A0(0x0008) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AudioMotorSim.AudioMotorSimComponent"));
		
		return ptr;
	}

};


// Class AudioMotorSim.AudioMotorSimOutput
// 0x0000 (0x0028 - 0x0028)
class AudioMotorSimOutput : public Interface
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AudioMotorSim.AudioMotorSimOutput"));
		
		return ptr;
	}

};


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

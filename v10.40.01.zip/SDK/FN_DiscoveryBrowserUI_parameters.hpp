#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function DiscoveryBrowserUI.FortActivityBrowserTabButton.OnFavoriteChanged
struct FortActivityBrowserTabButton_OnFavoriteChanged_Params
{
	bool                                               bIsFavorite_69;                                           // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function DiscoveryBrowserUI.FortActivityBrowserView.OnSurfaceDataDirty
struct FortActivityBrowserView_OnSurfaceDataDirty_Params
{
};

// Function DiscoveryBrowserUI.FortActivityBrowserView.GetInvalidActivityReason
struct FortActivityBrowserView_GetInvalidActivityReason_Params
{
	EFortInvalidActivityReason                         ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function DiscoveryBrowserUI.FortActivityPlayerBrowserView.PlayViewIntro
struct FortActivityPlayerBrowserView_PlayViewIntro_Params
{
};

// Function DiscoveryBrowserUI.FortActivityPlayerBrowserView.OnPlayViewIntro
struct FortActivityPlayerBrowserView_OnPlayViewIntro_Params
{
};

// Function DiscoveryBrowserUI.FortActivityPlayerBrowserView.BP_OnTileViewUpdated
struct FortActivityPlayerBrowserView_BP_OnTileViewUpdated_Params
{
};

// Function DiscoveryBrowserUI.FortActivityCreatorPageView.OnPlayerQueueTypeChanged
struct FortActivityCreatorPageView_OnPlayerQueueTypeChanged_Params
{
	EPlayerQueueType                                   PlayerQueueType_69;                                       // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function DiscoveryBrowserUI.FortActivityCreatorPageView.OnCreatorActivitiesQueryFinished
struct FortActivityCreatorPageView_OnCreatorActivitiesQueryFinished_Params
{
};

// Function DiscoveryBrowserUI.FortActivityBrowser.OnUpdateCategoryPage
struct FortActivityBrowser_OnUpdateCategoryPage_Params
{
	bool                                               bShowCategoryPage_69;                                     // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function DiscoveryBrowserUI.FortActivityBrowser.OnSwapColorScheme
struct FortActivityBrowser_OnSwapColorScheme_Params
{
	bool                                               bInIsUsingAlternateColorScheme_69;                        // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function DiscoveryBrowserUI.FortActivityBrowser.OnPlayerQueueTypeChanged
struct FortActivityBrowser_OnPlayerQueueTypeChanged_Params
{
	EPlayerQueueType                                   PlayerQueueType_69;                                       // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function DiscoveryBrowserUI.FortActivityBrowser.OnEnableColorScheme
struct FortActivityBrowser_OnEnableColorScheme_Params
{
	bool                                               bIsColorSchemeActive_69;                                  // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function DiscoveryBrowserUI.FortActivityBrowser.OnActivitySelected
struct FortActivityBrowser_OnActivitySelected_Params
{
};

// Function DiscoveryBrowserUI.FortActivityBrowser.HandleTabChanged
struct FortActivityBrowser_HandleTabChanged_Params
{
	struct FName                                       TabId_69;                                                 // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function DiscoveryBrowserUI.FortActivityBrowserRow.OnRowPeekStateChanged
struct FortActivityBrowserRow_OnRowPeekStateChanged_Params
{
	bool                                               bIsInPeekState_69;                                        // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function DiscoveryBrowserUI.FortActivityBrowserRow.OnRowMoveUp
struct FortActivityBrowserRow_OnRowMoveUp_Params
{
	bool                                               bMovingOffscreen_69;                                      // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function DiscoveryBrowserUI.FortActivityBrowserRow.OnRowMoveDown
struct FortActivityBrowserRow_OnRowMoveDown_Params
{
	bool                                               bMovingOffscreen_69;                                      // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function DiscoveryBrowserUI.FortActivityBrowserRow.OnRowIsSelectedChanged
struct FortActivityBrowserRow_OnRowIsSelectedChanged_Params
{
	bool                                               bIsSelected_69;                                           // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function DiscoveryBrowserUI.FortActivityBrowserRow.OnRowIsActiveChanged
struct FortActivityBrowserRow_OnRowIsActiveChanged_Params
{
	bool                                               bIsActive_69;                                             // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function DiscoveryBrowserUI.FortActivityBrowserRow.OnCategoryItemChanged
struct FortActivityBrowserRow_OnCategoryItemChanged_Params
{
	bool                                               bPlayAnimation_69;                                        // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function DiscoveryBrowserUI.FortActivityBrowserRow.GetIsSelected
struct FortActivityBrowserRow_GetIsSelected_Params
{
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function DiscoveryBrowserUI.FortActivityBrowserRow.GetIsInPeekState
struct FortActivityBrowserRow_GetIsInPeekState_Params
{
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function DiscoveryBrowserUI.FortActivityBrowserRow.GetIsActive
struct FortActivityBrowserRow_GetIsActive_Params
{
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function DiscoveryBrowserUI.FortActivityBrowserRowHero.OnVideoStarted
struct FortActivityBrowserRowHero_OnVideoStarted_Params
{
};

// Function DiscoveryBrowserUI.FortActivityBrowserRowHero.OnVideoEndReached
struct FortActivityBrowserRowHero_OnVideoEndReached_Params
{
};

// Function DiscoveryBrowserUI.FortActivityBrowserRowHero.OnUpdateDetailsDisplay
struct FortActivityBrowserRowHero_OnUpdateDetailsDisplay_Params
{
};

// Function DiscoveryBrowserUI.FortActivityBrowserRowHero.OnRowHeroFocusChanged
struct FortActivityBrowserRowHero_OnRowHeroFocusChanged_Params
{
	bool                                               bHasFocus_69;                                             // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function DiscoveryBrowserUI.FortActivityBrowserRowHero.OnQueryStatusChanged
struct FortActivityBrowserRowHero_OnQueryStatusChanged_Params
{
	bool                                               bIsActive_69;                                             // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function DiscoveryBrowserUI.FortActivityBrowserRowHero.OnQueryActivitiesFinished
struct FortActivityBrowserRowHero_OnQueryActivitiesFinished_Params
{
};

// Function DiscoveryBrowserUI.FortActivityBrowserRowHero.OnPreviewImageChanged
struct FortActivityBrowserRowHero_OnPreviewImageChanged_Params
{
	bool                                               bIsLoading_69;                                            // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	class Texture*                                     Texture_69;                                               // (ConstParm, Parm, ZeroConstructor)
};

// Function DiscoveryBrowserUI.FortActivityBrowserRowHero.OnPlayKeyArtOutro
struct FortActivityBrowserRowHero_OnPlayKeyArtOutro_Params
{
};

// Function DiscoveryBrowserUI.FortActivityBrowserRowHero.OnPlayKeyArtIntro
struct FortActivityBrowserRowHero_OnPlayKeyArtIntro_Params
{
};

// Function DiscoveryBrowserUI.FortActivityBrowserRowHero.OnActivityUpdated
struct FortActivityBrowserRowHero_OnActivityUpdated_Params
{
};

// Function DiscoveryBrowserUI.FortActivityBrowserRowHero.IsShowingSeasonalContent
struct FortActivityBrowserRowHero_IsShowingSeasonalContent_Params
{
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function DiscoveryBrowserUI.FortActivityBrowserRowHero.IsInOutroState
struct FortActivityBrowserRowHero_IsInOutroState_Params
{
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function DiscoveryBrowserUI.FortActivityBrowserRowHero.IsImageLoading
struct FortActivityBrowserRowHero_IsImageLoading_Params
{
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function DiscoveryBrowserUI.FortActivityBrowserRowHero.HandleActivityVideoCycleStarted
struct FortActivityBrowserRowHero_HandleActivityVideoCycleStarted_Params
{
};

// Function DiscoveryBrowserUI.FortActivityBrowserRowHero.HandleActivityVideoCycleEndReached
struct FortActivityBrowserRowHero_HandleActivityVideoCycleEndReached_Params
{
};

// Function DiscoveryBrowserUI.FortActivityBrowserRowHero.GetKeyArtOutroAnimation
struct FortActivityBrowserRowHero_GetKeyArtOutroAnimation_Params
{
	class WidgetAnimation*                             ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function DiscoveryBrowserUI.FortActivityBrowserRowHero.GetCurrentTexture
struct FortActivityBrowserRowHero_GetCurrentTexture_Params
{
	class Texture*                                     ReturnValue_69;                                           // (ConstParm, Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function DiscoveryBrowserUI.FortActivityBrowserRowHero.CycleNextActivity
struct FortActivityBrowserRowHero_CycleNextActivity_Params
{
};

// Function DiscoveryBrowserUI.FortActivityBrowserRowHero.CheckUpdateDetailsDelay
struct FortActivityBrowserRowHero_CheckUpdateDetailsDelay_Params
{
};

// Function DiscoveryBrowserUI.FortActivityBrowserRowList.OnQueryStatusChanged
struct FortActivityBrowserRowList_OnQueryStatusChanged_Params
{
	bool                                               bIsActive_69;                                             // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function DiscoveryBrowserUI.FortActivityBrowserRowPromoted.OnPreviewImageChanged
struct FortActivityBrowserRowPromoted_OnPreviewImageChanged_Params
{
	bool                                               bIsLoading_69;                                            // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	class Texture*                                     Texture_69;                                               // (ConstParm, Parm, ZeroConstructor)
};

// Function DiscoveryBrowserUI.FortActivityBrowserRowView.OnRowChanged
struct FortActivityBrowserRowView_OnRowChanged_Params
{
	int                                                NewCategoryIndex_69;                                      // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function DiscoveryBrowserUI.FortActivityBrowserRowView.OnQueryActivitiesFinished
struct FortActivityBrowserRowView_OnQueryActivitiesFinished_Params
{
};

// Function DiscoveryBrowserUI.FortActivityBrowserRowView.OnActivityUpdated
struct FortActivityBrowserRowView_OnActivityUpdated_Params
{
};

// Function DiscoveryBrowserUI.FortActivityBrowserTile.HandleActivitySelected
struct FortActivityBrowserTile_HandleActivitySelected_Params
{
};

// Function DiscoveryBrowserUI.FortActivityCategoryTile.OnTileActiveSet
struct FortActivityCategoryTile_OnTileActiveSet_Params
{
	bool                                               bIsTileActive_69;                                         // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function DiscoveryBrowserUI.FortActivityCategoryView.OnSurfaceDataReady
struct FortActivityCategoryView_OnSurfaceDataReady_Params
{
};

// Function DiscoveryBrowserUI.FortActivityCategoryView.OnCategoryTilePanelSelected
struct FortActivityCategoryView_OnCategoryTilePanelSelected_Params
{
	class FortActivityCategoryTilePanel*               SelectedPanel_69;                                         // (ConstParm, Parm, ZeroConstructor, InstancedReference)
};

// Function DiscoveryBrowserUI.FortActivityCategoryView.NavigateFromPanel
struct FortActivityCategoryView_NavigateFromPanel_Params
{
	EUINavigation                                      Direction_69;                                             // (Parm, ZeroConstructor, IsPlainOldData)
	class FortActivityCategoryTilePanel*               NavigatingPanel_69;                                       // (Parm, ZeroConstructor, InstancedReference)
	class FortActivityCategoryTilePanel*               ReturnValue_69;                                           // (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)
};

// Function DiscoveryBrowserUI.FortActivityCategoryView.GetTopMostVisiblePanel
struct FortActivityCategoryView_GetTopMostVisiblePanel_Params
{
	class FortActivityCategoryTilePanel*               ReturnValue_69;                                           // (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)
};

// Function DiscoveryBrowserUI.FortActivityCategoryView.GetCurrentSelectedPanel
struct FortActivityCategoryView_GetCurrentSelectedPanel_Params
{
	class FortActivityCategoryTilePanel*               ReturnValue_69;                                           // (ConstParm, ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)
};

// Function DiscoveryBrowserUI.FortActivityCreateView.OnCreativeActivityUpdated
struct FortActivityCreateView_OnCreativeActivityUpdated_Params
{
};

// Function DiscoveryBrowserUI.FortActivityCreateView.GetInvalidCreativeActivityReason
struct FortActivityCreateView_GetInvalidCreativeActivityReason_Params
{
	EFortInvalidActivityReason                         ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function DiscoveryBrowserUI.FortActivityDiscoverView.OnUpdateDetailsDisplay
struct FortActivityDiscoverView_OnUpdateDetailsDisplay_Params
{
};

// Function DiscoveryBrowserUI.FortActivityDiscoverView.OnPreviewImageChanged
struct FortActivityDiscoverView_OnPreviewImageChanged_Params
{
	bool                                               bIsLoading_69;                                            // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	class Texture*                                     Texture_69;                                               // (ConstParm, Parm, ZeroConstructor)
};

// Function DiscoveryBrowserUI.FortActivityDiscoverView.OnPlayKeyArtOutro
struct FortActivityDiscoverView_OnPlayKeyArtOutro_Params
{
};

// Function DiscoveryBrowserUI.FortActivityDiscoverView.OnPlayKeyArtIntro
struct FortActivityDiscoverView_OnPlayKeyArtIntro_Params
{
};

// Function DiscoveryBrowserUI.FortActivityDiscoverView.OnMoviePreEndEvent
struct FortActivityDiscoverView_OnMoviePreEndEvent_Params
{
};

// Function DiscoveryBrowserUI.FortActivityDiscoverView.OnMoviePlayingChanged
struct FortActivityDiscoverView_OnMoviePlayingChanged_Params
{
	bool                                               bIsPlaying_69;                                            // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function DiscoveryBrowserUI.FortActivityDiscoverView.IsShowingSeasonalContent
struct FortActivityDiscoverView_IsShowingSeasonalContent_Params
{
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function DiscoveryBrowserUI.FortActivityDiscoverView.IsShowingPromotedContent
struct FortActivityDiscoverView_IsShowingPromotedContent_Params
{
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function DiscoveryBrowserUI.FortActivityDiscoverView.IsInOutroState
struct FortActivityDiscoverView_IsInOutroState_Params
{
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function DiscoveryBrowserUI.FortActivityDiscoverView.IsImageLoading
struct FortActivityDiscoverView_IsImageLoading_Params
{
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function DiscoveryBrowserUI.FortActivityDiscoverView.HandleMovieWidgetMediaStarted
struct FortActivityDiscoverView_HandleMovieWidgetMediaStarted_Params
{
};

// Function DiscoveryBrowserUI.FortActivityDiscoverView.HandleMovieWidgetMediaPreEndEvent
struct FortActivityDiscoverView_HandleMovieWidgetMediaPreEndEvent_Params
{
};

// Function DiscoveryBrowserUI.FortActivityDiscoverView.GetPromotedMovieWidget
struct FortActivityDiscoverView_GetPromotedMovieWidget_Params
{
	class FortActivatableMovieWidget*                  ReturnValue_69;                                           // (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)
};

// Function DiscoveryBrowserUI.FortActivityDiscoverView.GetMovieWidget
struct FortActivityDiscoverView_GetMovieWidget_Params
{
	class FortActivatableMovieWidget*                  ReturnValue_69;                                           // (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)
};

// Function DiscoveryBrowserUI.FortActivityDiscoverView.GetKeyArtOutroAnimation
struct FortActivityDiscoverView_GetKeyArtOutroAnimation_Params
{
	class WidgetAnimation*                             ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function DiscoveryBrowserUI.FortActivityDiscoverView.GetCurrentTexture
struct FortActivityDiscoverView_GetCurrentTexture_Params
{
	class Texture*                                     ReturnValue_69;                                           // (ConstParm, Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function DiscoveryBrowserUI.FortActivityDiscoverView.CheckUpdateDetailsDelay
struct FortActivityDiscoverView_CheckUpdateDetailsDelay_Params
{
};

// Function DiscoveryBrowserUI.FortActivityDiscoverViewV2.IsShowingSeasonalContent
struct FortActivityDiscoverViewV2_IsShowingSeasonalContent_Params
{
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function DiscoveryBrowserUI.FortActivityDiscoverViewV2.IsShowingPromotedContent
struct FortActivityDiscoverViewV2_IsShowingPromotedContent_Params
{
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function DiscoveryBrowserUI.FortActivityListView.GetInViewCount
struct FortActivityListView_GetInViewCount_Params
{
	int                                                ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function DiscoveryBrowserUI.FortActivityLobbyTile.TrySendFirstTimeNotification
struct FortActivityLobbyTile_TrySendFirstTimeNotification_Params
{
};

// Function DiscoveryBrowserUI.FortActivityLobbyTile.ShowModeSetSelectionModal
struct FortActivityLobbyTile_ShowModeSetSelectionModal_Params
{
};

// Function DiscoveryBrowserUI.FortActivityLobbyTile.OnShowChildActivityFirstTimeNotification
struct FortActivityLobbyTile_OnShowChildActivityFirstTimeNotification_Params
{
};

// Function DiscoveryBrowserUI.FortActivityLobbyTile.OnShowChildActivityChangedNotification
struct FortActivityLobbyTile_OnShowChildActivityChangedNotification_Params
{
	struct FText                                       DisplayName_69;                                           // (ConstParm, Parm, OutParm, ReferenceParm)
};

// Function DiscoveryBrowserUI.FortActivityLobbyTile.OnPreviewImageChanged
struct FortActivityLobbyTile_OnPreviewImageChanged_Params
{
	bool                                               bIsLoading_69;                                            // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	class Texture*                                     Texture_69;                                               // (ConstParm, Parm, ZeroConstructor)
};

// Function DiscoveryBrowserUI.FortActivityLobbyTile.OnHideChildActivityFirstTimeNotification
struct FortActivityLobbyTile_OnHideChildActivityFirstTimeNotification_Params
{
};

// Function DiscoveryBrowserUI.FortActivityLobbyTile.OnDetailsUpdated
struct FortActivityLobbyTile_OnDetailsUpdated_Params
{
};

// Function DiscoveryBrowserUI.FortActivityLobbyTile.IsModeSetActivity
struct FortActivityLobbyTile_IsModeSetActivity_Params
{
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function DiscoveryBrowserUI.FortActivityLobbyTile.IsActivityEpicCreated
struct FortActivityLobbyTile_IsActivityEpicCreated_Params
{
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function DiscoveryBrowserUI.FortActivityLobbyTile.GetChildActivityDisplayName
struct FortActivityLobbyTile_GetChildActivityDisplayName_Params
{
	struct FText                                       ReturnValue_69;                                           // (Parm, OutParm, ReturnParm)
};

// Function DiscoveryBrowserUI.FortActivityModeSetSelectionModal.SaveSelectionAndClose
struct FortActivityModeSetSelectionModal_SaveSelectionAndClose_Params
{
};

// Function DiscoveryBrowserUI.FortActivityModeSetSelectionModal.OnSubModeSelectionChanged
struct FortActivityModeSetSelectionModal_OnSubModeSelectionChanged_Params
{
};

// Function DiscoveryBrowserUI.FortActivityModeSetSelectionModal.OnSubModeSelected
struct FortActivityModeSetSelectionModal_OnSubModeSelected_Params
{
};

// Function DiscoveryBrowserUI.FortActivityModeSetSelectionModal.OnPreviewImageChanged
struct FortActivityModeSetSelectionModal_OnPreviewImageChanged_Params
{
	bool                                               bIsLoading_69;                                            // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	class Texture*                                     Texture_69;                                               // (ConstParm, Parm, ZeroConstructor)
};

// Function DiscoveryBrowserUI.FortActivityModeSetSelectionModal.OnActivityChanged
struct FortActivityModeSetSelectionModal_OnActivityChanged_Params
{
	class FortGameActivity*                            GameActivity_69;                                          // (ConstParm, Parm, ZeroConstructor)
	struct FString                                     StartingSelectedMnemonic_69;                              // (Parm, ZeroConstructor)
};

// Function DiscoveryBrowserUI.FortActivityPlayerBrowserTile.HandleActivitySelected
struct FortActivityPlayerBrowserTile_HandleActivitySelected_Params
{
};

// Function DiscoveryBrowserUI.FortActivitySearchView.OnActivityValidated
struct FortActivitySearchView_OnActivityValidated_Params
{
	EFortActivityValidationResult                      ValidateResult_69;                                        // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function DiscoveryBrowserUI.FortActivitySearchView.OnActivityClear
struct FortActivitySearchView_OnActivityClear_Params
{
};

// Function DiscoveryBrowserUI.FortActivitySearchView.HandleTextCommitted
struct FortActivitySearchView_HandleTextCommitted_Params
{
	struct FText                                       InText_69;                                                // (ConstParm, Parm, OutParm, ReferenceParm)
	TEnumAsByte<ETextCommit>                           CommitInfo_69;                                            // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function DiscoveryBrowserUI.FortActivitySearchView.HandleTextChanged
struct FortActivitySearchView_HandleTextChanged_Params
{
	struct FText                                       Text_69;                                                  // (ConstParm, Parm, OutParm, ReferenceParm)
};

// Function DiscoveryBrowserUI.FortActivityTileDetailsDisplay.OnUpdateColumnSize
struct FortActivityTileDetailsDisplay_OnUpdateColumnSize_Params
{
	int                                                NewColumnSize_69;                                         // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function DiscoveryBrowserUI.FortActivityTileDetailsDisplay.OnTileActiveSet
struct FortActivityTileDetailsDisplay_OnTileActiveSet_Params
{
	bool                                               bIsTileActive_69;                                         // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function DiscoveryBrowserUI.FortActivityTileDetailsDisplay.OnSocialUsersPlayingChanged
struct FortActivityTileDetailsDisplay_OnSocialUsersPlayingChanged_Params
{
	int                                                NumPlaying_69;                                            // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function DiscoveryBrowserUI.FortActivityTileDetailsDisplay.OnRequiresPurchaseChanged
struct FortActivityTileDetailsDisplay_OnRequiresPurchaseChanged_Params
{
	bool                                               bRequiresPurchase_69;                                     // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function DiscoveryBrowserUI.FortActivityTileDetailsDisplay.OnPreviewImageChanged
struct FortActivityTileDetailsDisplay_OnPreviewImageChanged_Params
{
	bool                                               bIsLoading_69;                                            // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	class Texture*                                     Texture_69;                                               // (ConstParm, Parm, ZeroConstructor)
};

// Function DiscoveryBrowserUI.FortActivityTileDetailsDisplay.OnPartySizeChanged
struct FortActivityTileDetailsDisplay_OnPartySizeChanged_Params
{
	int                                                PartySize_69;                                             // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function DiscoveryBrowserUI.FortActivityTileDetailsDisplay.OnLocalPlayerPromotedToLeader
struct FortActivityTileDetailsDisplay_OnLocalPlayerPromotedToLeader_Params
{
};

// Function DiscoveryBrowserUI.FortActivityTileDetailsDisplay.OnLocalPlayerDemoted
struct FortActivityTileDetailsDisplay_OnLocalPlayerDemoted_Params
{
};

// Function DiscoveryBrowserUI.FortActivityTileDetailsDisplay.OnIsFavoriteChanged
struct FortActivityTileDetailsDisplay_OnIsFavoriteChanged_Params
{
	bool                                               bIsFavorite_69;                                           // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function DiscoveryBrowserUI.FortActivityTileDetailsDisplay.OnDetailsUpdated
struct FortActivityTileDetailsDisplay_OnDetailsUpdated_Params
{
};

// DelegateFunction DiscoveryBrowserUI.FortActivityTileDetailsDisplay.OnActivityUnSelected__DelegateSignature
struct FortActivityTileDetailsDisplay_OnActivityUnSelected__DelegateSignature_Params
{
};

// DelegateFunction DiscoveryBrowserUI.FortActivityTileDetailsDisplay.OnActivitySelected__DelegateSignature
struct FortActivityTileDetailsDisplay_OnActivitySelected__DelegateSignature_Params
{
};

// Function DiscoveryBrowserUI.FortActivityTileDetailsDisplay.IsModeSetActivity
struct FortActivityTileDetailsDisplay_IsModeSetActivity_Params
{
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function DiscoveryBrowserUI.FortActivityTileDetailsDisplay.IsActivityFavorited
struct FortActivityTileDetailsDisplay_IsActivityFavorited_Params
{
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function DiscoveryBrowserUI.FortActivityTileDetailsDisplay.IsActivityEpicCreated
struct FortActivityTileDetailsDisplay_IsActivityEpicCreated_Params
{
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function DiscoveryBrowserUI.FortActivityTileDetailsDisplay.GetInvalidActivityReason
struct FortActivityTileDetailsDisplay_GetInvalidActivityReason_Params
{
	EFortInvalidActivityReason                         ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function DiscoveryBrowserUI.FortActivityTileDetailsDisplay.DoesActivityRequirePurchase
struct FortActivityTileDetailsDisplay_DoesActivityRequirePurchase_Params
{
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function DiscoveryBrowserUI.FortActivityTileView.SetListenForMouseWheelInput
struct FortActivityTileView_SetListenForMouseWheelInput_Params
{
	bool                                               bListenForInput_69;                                       // (Parm, ZeroConstructor, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

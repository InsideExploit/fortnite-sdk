#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Classes
//---------------------------------------------------------------------------

// Class ChromeSharedRuntime.ChromeSoundComponentBase
// 0x0000 (0x00A0 - 0x00A0)
class ChromeSoundComponentBase : public ActorComponent
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class ChromeSharedRuntime.ChromeSoundComponentBase"));
		
		return ptr;
	}


	void SetupChromeAudio(class Actor_32759* Actor_69, bool bAdd_69, ELacklusterChromeType ChromeType_69);
};


// Class ChromeSharedRuntime.ChromeBlobAnimInstance
// 0x0060 (0x0750 - 0x06F0)
class ChromeBlobAnimInstance : public CustomCharacterPartAnimInstance
{
public:
	struct FFortAnimInput_Zipline                      ZiplineInput_69;                                          // 0x06F0(0x0038) (Edit, BlueprintVisible, BlueprintReadOnly)
	float                                              LocalVelocityAngle_69;                                    // 0x0728(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              LeanAngle_69;                                             // 0x072C(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              LeanAngleMultiplier_69;                                   // 0x0730(0x0004) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	float                                              LeanInterpolationSpeed_69;                                // 0x0734(0x0004) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	struct FRotator                                    ActorRotationLastTick_69;                                 // 0x0738(0x0018) (ZeroConstructor, IsPlainOldData)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class ChromeSharedRuntime.ChromeBlobAnimInstance"));
		
		return ptr;
	}

};


// Class ChromeSharedRuntime.ChromeGameFeatureData
// 0x0010 (0x0530 - 0x0520)
class ChromeGameFeatureData : public FortGameFeatureData
{
public:
	TArray<struct FFortChromeComponentData>            ChromeComponents_69;                                      // 0x0520(0x0010) (Edit, ZeroConstructor, DisableEditOnInstance)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class ChromeSharedRuntime.ChromeGameFeatureData"));
		
		return ptr;
	}

};


// Class ChromeSharedRuntime.ApplyChromeComponent
// 0x0010 (0x00B0 - 0x00A0)
class ApplyChromeComponent : public ActorComponent
{
public:
	TArray<class ActorComponent*>                      NativePredefinedMeshComponents_69;                        // 0x00A0(0x0010) (Edit, ExportObject, ZeroConstructor, DisableEditOnInstance)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class ChromeSharedRuntime.ApplyChromeComponent"));
		
		return ptr;
	}

};


// Class ChromeSharedRuntime.FortChromeSubsystem
// 0x0568 (0x0598 - 0x0030)
class FortChromeSubsystem : public WorldSubsystem
{
public:
	TArray<struct FLacklusterMaterialData>             ChromeMaterialData_69;                                    // 0x0030(0x0010) (BlueprintVisible, ZeroConstructor, Transient)
	TArray<struct FLacklusterOriginalMaterialData>     OriginalMaterialData_69;                                  // 0x0040(0x0010) (BlueprintVisible, ZeroConstructor, Transient)
	TMap<struct FName, float>                          ContainerMatScalarParamMap_69;                            // 0x0050(0x0050) (Edit, BlueprintVisible, Transient, DisableEditOnInstance)
	TMap<struct FName, struct FLinearColor>            ContainerMatVectorParamMap_69;                            // 0x00A0(0x0050) (Edit, BlueprintVisible, Transient, DisableEditOnInstance)
	struct FGameplayTag                                CurieFireTag_69;                                          // 0x00F0(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, Transient, DisableEditOnInstance)
	ELacklusterActorType                               NativeNativeActorType_69;                                 // 0x00F4(0x0001) (BlueprintVisible, ZeroConstructor, Transient, IsPlainOldData)
	ELacklusterChromeType                              NativeNativeChromeType_69;                                // 0x00F5(0x0001) (BlueprintVisible, ZeroConstructor, Transient, IsPlainOldData)
	unsigned char                                      UnknownData00[0xA];                                       // 0x00F6(0x000A) MISSED OFFSET
	TArray<class BuildingFoundation*>                  StreamedInBuildingFoundations_69;                         // 0x0100(0x0010) (ZeroConstructor, Transient)
	TArray<class BuildingFoundation*>                  FullyChromedPreviewFoundations_69;                        // 0x0110(0x0010) (ZeroConstructor, Transient)
	struct FName                                       ChromeTagName_69;                                         // 0x0120(0x0008) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData01[0x4];                                       // 0x0124(0x0004) MISSED OFFSET
	struct FGameplayTagQuery                           ApplyChromeMaterialsTagQuery_69;                          // 0x0128(0x0048) (Edit, DisableEditOnInstance)
	TArray<struct FFortChromeComponentData>            ChromeComponents_69;                                      // 0x0170(0x0010) (Edit, ZeroConstructor, DisableEditOnInstance)
	struct FLacklusterData                             LacklusterData_69;                                        // 0x0180(0x0360) (Edit, BlueprintVisible, DisableEditOnInstance)
	TArray<class Actor_32759*>                         ActorsWaitingForChromeSetup_69;                           // 0x04E0(0x0010) (ZeroConstructor, Transient)
	TMap<class BuildingFoundation*, bool>              FoundationsWithChromeActors_69;                           // 0x04F0(0x0050) (Transient)
	unsigned char                                      UnknownData02[0x28];                                      // 0x0540(0x0028) MISSED OFFSET
	unsigned char                                      UnknownData03[0x10];                                      // 0x0540(0x0010) UNKNOWN PROPERTY: ArrayProperty ChromeSharedRuntime.FortChromeSubsystem.ChromableActorClassDenyList_69
	unsigned char                                      UnknownData04[0x10];                                      // 0x0578(0x0010) UNKNOWN PROPERTY: ArrayProperty ChromeSharedRuntime.FortChromeSubsystem.PhaseableActorClassDenyList_69
	unsigned char                                      UnknownData05[0x10];                                      // 0x0588(0x0010) UNKNOWN PROPERTY: ArrayProperty ChromeSharedRuntime.FortChromeSubsystem.SharedChromeMIDClassDenyList_69

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class ChromeSharedRuntime.FortChromeSubsystem"));
		
		return ptr;
	}


	bool STATIC_ShouldDelayASCCreation();
	void SetupChromeOnActor(class Actor_32759* Actor_69);
	void RestoreActorOriginalMaterials(class Actor_32759* Actor_69);
	void PawnHitActor(class FortPlayerPawn* Pawn_69, const struct FHitResult& HitResult_69, class Actor_32759* HitActor_69);
	void OnPlaylistDataReady(class FortGameStateAthena* GameState_69, class FortPlaylist* Playlist_69, const struct FGameplayTagContainer& PlaylistContextTags_69);
	void NativeSetupChromeOnActor(class Actor_32759* Actor_69);
	void NativeHandleVehicleModUpdated(class FortAthenaVehicle* Vehicle_69, const struct FGameplayTag& ModTag_69);
	void NativeHandleContainerSearchedStateChanged(class BuildingContainer* BuildingContainer_69, bool bSearched_69);
	void NativeHandleContainerRandomUpgradeApplied(class BuildingContainer* BuildingContainer_69, int UpgradeIndex_69, const struct FName& UpgradeLootTierGroup_69);
	void NativeHandleContainerMeshSetChanged(class BuildingSMActor* BuildingSMActor_69, const struct FMeshSet& NewMeshSet_69);
	bool STATIC_IsActorPhaseable(class Actor_32759* Actor_69);
	bool STATIC_IsActorChromable(class Actor_32759* Actor_69);
	void InitLacklusterFunctionLibrary();
	class MaterialInstanceDynamic* STATIC_GetSharedChromeMID(class Actor_32759* Actor_69, class MaterialInterface* Parent_69, TMap<struct FName, class Texture*>* NamesToTexturesMap_69);
	void GetOverlappingActorsOfClass(class Actor_32759* Actor_69, class Actor_32759* Class_69, TArray<class Actor_32759*>* OutOverlappingActors_69);
	void ApplyChromeToActor(class Actor_32759* Actor_69);
};


// Class ChromeSharedRuntime.FortGameFeatureAction_AddChromeSubsystem
// 0x0000 (0x0050 - 0x0050)
class FortGameFeatureAction_AddChromeSubsystem : public FortGameFeatureAction_AddWorldSubsystem
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class ChromeSharedRuntime.FortGameFeatureAction_AddChromeSubsystem"));
		
		return ptr;
	}

};


// Class ChromeSharedRuntime.LacklusterFunctionLibrary
// 0x0000 (0x0028 - 0x0028)
class LacklusterFunctionLibrary : public BlueprintFunctionLibrary
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class ChromeSharedRuntime.LacklusterFunctionLibrary"));
		
		return ptr;
	}


	bool STATIC_UseNativeFunctions();
	void STATIC_NativeUnbindChromeEvents(class Actor_32759* Actor_69);
	void STATIC_NativeStopBuildingAudio(class BuildingActor* BuildingActor_69);
	bool STATIC_NativeShouldIgnoreMaterial(class MaterialInterface* Material_69);
	void STATIC_NativeSetupChromeOnActor(class Actor_32759* Actor_69, ELacklusterActorType* ActorType_69, ELacklusterChromeType* ChromeType_69, TArray<struct FLacklusterMaterialData>* ChromeMaterialData_69, TArray<struct FLacklusterOriginalMaterialData>* OriginalMaterialData_69, TMap<struct FName, float>* ContainerMatScalarParamMap_69, TMap<struct FName, struct FLinearColor>* ContainerMatVectorParamMap_69);
	void STATIC_NativeSetChromeMaterials(ELacklusterChromeType ChromeType_69, TArray<struct FLacklusterMaterialData>* ChromeMaterialStructs_69);
	void STATIC_NativeSetChromeAudio(class Actor_32759* Actor_69, bool bAdd_69, ELacklusterChromeType ChromeType_69);
	void STATIC_NativeRestoreOriginalMaterials(class Actor_32759* Actor_69, TArray<struct FLacklusterOriginalMaterialData> OriginalMaterialDataArray_69);
	bool STATIC_NativeIsMaskedBlendMode(class MaterialInterface* MaterialInterface_69);
	ELacklusterActorType STATIC_NativeHandleActorTypeSpecialCases(ELacklusterActorType ActorType_69, bool bIsMaskedMaterial_69, bool bIsChonkers_69);
	class ApplyChromeComponent* STATIC_NativeGetChromeVisualComponent(class Actor_32759* Actor_69, bool bCreateComponentIfNotFound_69);
	class MaterialInstance* STATIC_NativeGetChromeTieredChestMaterial(class Actor_32759* Actor_69);
	class ChromeSoundComponentBase* STATIC_NativeGetChromeSoundComponent(class Actor_32759* Actor_69, bool bCreateComponentIfNotFound_69);
	class MaterialInterface* STATIC_NativeGetChromeMaterialOverride(bool bIsMaskedMaterial_69, bool bIsChonkers_69, ELacklusterActorType ActorType_69, class Actor_32759* Actor_69, ELacklusterChromeType ChromeType_69);
	bool STATIC_NativeGetChromeChonkerTires(class MeshComponent* MeshComponent_69);
	void STATIC_NativeGetChromeActorType(class Actor_32759* Actor_69, ELacklusterChromeType* ChromeTypeOut_69, ELacklusterActorType* ActorTypeOut_69);
	void STATIC_NativeFindTexturesFromComponents(ELacklusterActorType ActorType_69, class Actor_32759* Actor_69, TArray<struct FLacklusterMaterialData>* ChromeMaterialStructs_69, TArray<struct FLacklusterOriginalMaterialData>* OriginalMaterialStructs_69);
	struct FName STATIC_NativeFindSetParameterName(ELacklusterTextureGroup TextureGroup_69);
	TArray<struct FLacklusterTextureSet> STATIC_NativeFindGetSetParameters(bool bIsMaskedMaterial_69, bool bIsChonkers_69, ELacklusterActorType ActorType_69, class MeshComponent* MeshComponent_69);
	void STATIC_NativeExecuteOwnerTypeFunctionality_PreChrome_Container(class Actor_32759* Actor_69, const struct FGameplayTagContainer& ContainerTags_69, TMap<struct FName, float>* ContainerMatScalarParamMap_69, TMap<struct FName, struct FLinearColor>* ContainerMatVectorParamMap_69);
	void STATIC_NativeExecuteOwnerTypeFunctionality_PreChrome(class Actor_32759* Actor_69, ELacklusterActorType ActorType_69, const struct FGameplayTagContainer& ContainerTags_69, TMap<struct FName, float>* ContainerMatScalarParamMap_69, TMap<struct FName, struct FLinearColor>* ContainerMatVectorParamMap_69);
	void STATIC_NativeExecuteOwnerTypeFunctionality_PostChrome_Vehicle(class Actor_32759* Actor_69);
	void STATIC_NativeExecuteOwnerTypeFunctionality_PostChrome_Container(class Actor_32759* Actor_69, const struct FGameplayTagContainer& ContainerTags_69, TMap<struct FName, float> ContainerMatScalarParamMap_69, TMap<struct FName, struct FLinearColor> ContainerMatVectorParamMap_69);
	void STATIC_NativeExecuteOwnerTypeFunctionality_PostChrome(class Actor_32759* Actor_69, ELacklusterActorType ActorType_69, const struct FGameplayTagContainer& ContainerTags_69, TMap<struct FName, float> ContainerMatScalarParamMap_69, TMap<struct FName, struct FLinearColor> ContainerMatVectorParamMap_69);
	bool STATIC_NativeExcludeFromChroming(class SceneComponent* Component_69);
	bool STATIC_NativeDoesActorSupportChromeSoundComponent(class Actor_32759* Actor_69);
	void STATIC_NativeDisableShadowProxyWPO(class Actor_32759* Actor_69);
	bool STATIC_NativeCastToSpecificClasses(class Actor_32759* Actor_69, ELacklusterChromeType ChromeTypeIn_69, ELacklusterChromeType* ChromeTypeOut_69, ELacklusterActorType* ActorTypeOut_69);
	bool STATIC_NativeCastToParentClasses(class Actor_32759* Actor_69, ELacklusterActorType* ActorTypeOut_69);
	void STATIC_NativeBindChromeEvents(class Actor_32759* Actor_69);
	bool STATIC_NativeAreWeOverridingAudio(class Actor_32759* Actor_69);
	void STATIC_NativeApplyChromeToActor(class Actor_32759* Actor_69, ELacklusterActorType* ActorType_69, ELacklusterChromeType* ChromeType_69, TArray<struct FLacklusterMaterialData>* ChromeMaterialData_69, TArray<struct FLacklusterOriginalMaterialData>* OriginalMaterialData_69, TMap<struct FName, float>* ContainerMatScalarParamMap_69, TMap<struct FName, struct FLinearColor>* ContainerMatVectorParamMap_69);
	void STATIC_NativeApplyChromeMaterial(class Actor_32759* Actor_69, ELacklusterChromeType ChromeType_69, ELacklusterActorType OverrideActorType_69, TArray<struct FLacklusterMaterialData>* ChromeMaterialStructs_69, TArray<struct FLacklusterOriginalMaterialData>* OriginalMaterialStructs_69);
	void STATIC_NativeAddTextureData(ELacklusterActorType ActorType_69, class Actor_32759* Actor_69, int MaterialIndex_69, class MaterialInterface* Material_69, class MeshComponent* MeshComponent_69, TArray<struct FLacklusterMaterialData>* ChromeMaterialStructs_69, TArray<struct FLacklusterOriginalMaterialData>* OriginalMaterialStructs_69);
};


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

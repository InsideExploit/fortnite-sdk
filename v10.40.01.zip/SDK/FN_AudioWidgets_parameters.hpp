#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function AudioWidgets.AudioMeter.SetMeterValueColor
struct AudioMeter_SetMeterValueColor_Params
{
	struct FLinearColor                                InValue_69;                                               // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function AudioWidgets.AudioMeter.SetMeterScaleLabelColor
struct AudioMeter_SetMeterScaleLabelColor_Params
{
	struct FLinearColor                                InValue_69;                                               // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function AudioWidgets.AudioMeter.SetMeterScaleColor
struct AudioMeter_SetMeterScaleColor_Params
{
	struct FLinearColor                                InValue_69;                                               // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function AudioWidgets.AudioMeter.SetMeterPeakColor
struct AudioMeter_SetMeterPeakColor_Params
{
	struct FLinearColor                                InValue_69;                                               // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function AudioWidgets.AudioMeter.SetMeterClippingColor
struct AudioMeter_SetMeterClippingColor_Params
{
	struct FLinearColor                                InValue_69;                                               // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function AudioWidgets.AudioMeter.SetMeterChannelInfo
struct AudioMeter_SetMeterChannelInfo_Params
{
	TArray<struct FMeterChannelInfo>                   InMeterChannelInfo_69;                                    // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
};

// Function AudioWidgets.AudioMeter.SetMeterBackgroundColor
struct AudioMeter_SetMeterBackgroundColor_Params
{
	struct FLinearColor                                InValue_69;                                               // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function AudioWidgets.AudioMeter.SetBackgroundColor
struct AudioMeter_SetBackgroundColor_Params
{
	struct FLinearColor                                InValue_69;                                               // (Parm, ZeroConstructor, IsPlainOldData)
};

// DelegateFunction AudioWidgets.AudioMeter.GetMeterChannelInfo__DelegateSignature
struct AudioMeter_GetMeterChannelInfo__DelegateSignature_Params
{
	TArray<struct FMeterChannelInfo>                   ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function AudioWidgets.AudioMeter.GetMeterChannelInfo
struct AudioMeter_GetMeterChannelInfo_Params
{
	TArray<struct FMeterChannelInfo>                   ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function AudioWidgets.AudioRadialSlider.SetWidgetLayout
struct AudioRadialSlider_SetWidgetLayout_Params
{
	TEnumAsByte<EAudioRadialSliderLayout>              InLayout_69;                                              // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function AudioWidgets.AudioRadialSlider.SetValueTextReadOnly
struct AudioRadialSlider_SetValueTextReadOnly_Params
{
	bool                                               bIsReadOnly_69;                                           // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function AudioWidgets.AudioRadialSlider.SetUnitsTextReadOnly
struct AudioRadialSlider_SetUnitsTextReadOnly_Params
{
	bool                                               bIsReadOnly_69;                                           // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function AudioWidgets.AudioRadialSlider.SetUnitsText
struct AudioRadialSlider_SetUnitsText_Params
{
	struct FText                                       Units_69;                                                 // (ConstParm, Parm)
};

// Function AudioWidgets.AudioRadialSlider.SetTextLabelBackgroundColor
struct AudioRadialSlider_SetTextLabelBackgroundColor_Params
{
	struct FSlateColor                                 InColor_69;                                               // (Parm)
};

// Function AudioWidgets.AudioRadialSlider.SetSliderThickness
struct AudioRadialSlider_SetSliderThickness_Params
{
	float                                              InThickness_69;                                           // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function AudioWidgets.AudioRadialSlider.SetSliderProgressColor
struct AudioRadialSlider_SetSliderProgressColor_Params
{
	struct FLinearColor                                InValue_69;                                               // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function AudioWidgets.AudioRadialSlider.SetSliderBarColor
struct AudioRadialSlider_SetSliderBarColor_Params
{
	struct FLinearColor                                InValue_69;                                               // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function AudioWidgets.AudioRadialSlider.SetShowUnitsText
struct AudioRadialSlider_SetShowUnitsText_Params
{
	bool                                               bShowUnitsText_69;                                        // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function AudioWidgets.AudioRadialSlider.SetShowLabelOnlyOnHover
struct AudioRadialSlider_SetShowLabelOnlyOnHover_Params
{
	bool                                               bShowLabelOnlyOnHover_69;                                 // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function AudioWidgets.AudioRadialSlider.SetOutputRange
struct AudioRadialSlider_SetOutputRange_Params
{
	struct FVector2D                                   InOutputRange_69;                                         // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function AudioWidgets.AudioRadialSlider.SetHandStartEndRatio
struct AudioRadialSlider_SetHandStartEndRatio_Params
{
	struct FVector2D                                   InHandStartEndRatio_69;                                   // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function AudioWidgets.AudioRadialSlider.SetCenterBackgroundColor
struct AudioRadialSlider_SetCenterBackgroundColor_Params
{
	struct FLinearColor                                InValue_69;                                               // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function AudioWidgets.AudioSliderBase.SetWidgetBackgroundColor
struct AudioSliderBase_SetWidgetBackgroundColor_Params
{
	struct FLinearColor                                InValue_69;                                               // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function AudioWidgets.AudioSliderBase.SetValueTextReadOnly
struct AudioSliderBase_SetValueTextReadOnly_Params
{
	bool                                               bIsReadOnly_69;                                           // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function AudioWidgets.AudioSliderBase.SetUnitsTextReadOnly
struct AudioSliderBase_SetUnitsTextReadOnly_Params
{
	bool                                               bIsReadOnly_69;                                           // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function AudioWidgets.AudioSliderBase.SetUnitsText
struct AudioSliderBase_SetUnitsText_Params
{
	struct FText                                       Units_69;                                                 // (ConstParm, Parm)
};

// Function AudioWidgets.AudioSliderBase.SetTextLabelBackgroundColor
struct AudioSliderBase_SetTextLabelBackgroundColor_Params
{
	struct FSlateColor                                 InColor_69;                                               // (Parm)
};

// Function AudioWidgets.AudioSliderBase.SetSliderThumbColor
struct AudioSliderBase_SetSliderThumbColor_Params
{
	struct FLinearColor                                InValue_69;                                               // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function AudioWidgets.AudioSliderBase.SetSliderBarColor
struct AudioSliderBase_SetSliderBarColor_Params
{
	struct FLinearColor                                InValue_69;                                               // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function AudioWidgets.AudioSliderBase.SetSliderBackgroundColor
struct AudioSliderBase_SetSliderBackgroundColor_Params
{
	struct FLinearColor                                InValue_69;                                               // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function AudioWidgets.AudioSliderBase.SetShowUnitsText
struct AudioSliderBase_SetShowUnitsText_Params
{
	bool                                               bShowUnitsText_69;                                        // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function AudioWidgets.AudioSliderBase.SetShowLabelOnlyOnHover
struct AudioSliderBase_SetShowLabelOnlyOnHover_Params
{
	bool                                               bShowLabelOnlyOnHover_69;                                 // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function AudioWidgets.AudioSliderBase.GetOutputValue
struct AudioSliderBase_GetOutputValue_Params
{
	float                                              LinValue_69;                                              // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	float                                              ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AudioWidgets.AudioSliderBase.GetLinValue
struct AudioSliderBase_GetLinValue_Params
{
	float                                              OutputValue_69;                                           // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	float                                              ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

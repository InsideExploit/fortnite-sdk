#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function AudioGameplay.AudioGameplayCondition.ConditionMet_Position
struct AudioGameplayCondition_ConditionMet_Position_Params
{
	struct FVector                                     Position_69;                                              // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AudioGameplay.AudioGameplayCondition.ConditionMet
struct AudioGameplayCondition_ConditionMet_Params
{
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AudioGameplay.AudioGameplayVolumeInteraction.OnListenerExit
struct AudioGameplayVolumeInteraction_OnListenerExit_Params
{
};

// Function AudioGameplay.AudioGameplayVolumeInteraction.OnListenerEnter
struct AudioGameplayVolumeInteraction_OnListenerEnter_Params
{
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

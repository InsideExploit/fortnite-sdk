// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Functions
//---------------------------------------------------------------------------

// Function ChromeWildlifeRuntime.FortAthenaChromeWildlifeTelemetryData.SetIsChromed
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// bool                           bInIsChromed_69                (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void FortAthenaChromeWildlifeTelemetryData::SetIsChromed(bool bInIsChromed_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ChromeWildlifeRuntime.FortAthenaChromeWildlifeTelemetryData.SetIsChromed"));

	FortAthenaChromeWildlifeTelemetryData_SetIsChromed_Params params;
	params.bInIsChromed_69 = bInIsChromed_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

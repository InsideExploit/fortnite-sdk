#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function CinematicCamera.CineCameraActor.GetCineCameraComponent
struct CineCameraActor_GetCineCameraComponent_Params
{
	class CineCameraComponent*                         ReturnValue_69;                                           // (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)
};

// Function CinematicCamera.CineCameraComponent.SetLensPresetByName
struct CineCameraComponent_SetLensPresetByName_Params
{
	struct FString                                     InPresetName_69;                                          // (Parm, ZeroConstructor)
};

// Function CinematicCamera.CineCameraComponent.SetFilmbackPresetByName
struct CineCameraComponent_SetFilmbackPresetByName_Params
{
	struct FString                                     InPresetName_69;                                          // (Parm, ZeroConstructor)
};

// Function CinematicCamera.CineCameraComponent.SetCurrentFocalLength
struct CineCameraComponent_SetCurrentFocalLength_Params
{
	float                                              InFocalLength_69;                                         // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function CinematicCamera.CineCameraComponent.GetVerticalFieldOfView
struct CineCameraComponent_GetVerticalFieldOfView_Params
{
	float                                              ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CinematicCamera.CineCameraComponent.GetLensPresetsCopy
struct CineCameraComponent_GetLensPresetsCopy_Params
{
	TArray<struct FNamedLensPreset>                    ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function CinematicCamera.CineCameraComponent.GetLensPresetName
struct CineCameraComponent_GetLensPresetName_Params
{
	struct FString                                     ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function CinematicCamera.CineCameraComponent.GetHorizontalFieldOfView
struct CineCameraComponent_GetHorizontalFieldOfView_Params
{
	float                                              ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function CinematicCamera.CineCameraComponent.GetFilmbackPresetsCopy
struct CineCameraComponent_GetFilmbackPresetsCopy_Params
{
	TArray<struct FNamedFilmbackPreset>                ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function CinematicCamera.CineCameraComponent.GetFilmbackPresetName
struct CineCameraComponent_GetFilmbackPresetName_Params
{
	struct FString                                     ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function CinematicCamera.CineCameraComponent.GetDefaultFilmbackPresetName
struct CineCameraComponent_GetDefaultFilmbackPresetName_Params
{
	struct FString                                     ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function CinematicCamera.CameraRig_Rail.GetRailSplineComponent
struct CameraRig_Rail_GetRailSplineComponent_Params
{
	class SplineComponent*                             ReturnValue_69;                                           // (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

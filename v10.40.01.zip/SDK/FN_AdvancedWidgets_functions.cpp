// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Functions
//---------------------------------------------------------------------------

// Function AdvancedWidgets.RadialSlider.SetValueTags
// (Final, Native, Public, HasOutParms, BlueprintCallable)
// Parameters:
// TArray<float>                  InValueTags_69                 (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)

void RadialSlider::SetValueTags(TArray<float> InValueTags_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AdvancedWidgets.RadialSlider.SetValueTags"));

	RadialSlider_SetValueTags_Params params;
	params.InValueTags_69 = InValueTags_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AdvancedWidgets.RadialSlider.SetValue
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// float                          InValue_69                     (Parm, ZeroConstructor, IsPlainOldData)

void RadialSlider::SetValue(float InValue_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AdvancedWidgets.RadialSlider.SetValue"));

	RadialSlider_SetValue_Params params;
	params.InValue_69 = InValue_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AdvancedWidgets.RadialSlider.SetUseVerticalDrag
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// bool                           InUseVerticalDrag_69           (Parm, ZeroConstructor, IsPlainOldData)

void RadialSlider::SetUseVerticalDrag(bool InUseVerticalDrag_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AdvancedWidgets.RadialSlider.SetUseVerticalDrag"));

	RadialSlider_SetUseVerticalDrag_Params params;
	params.InUseVerticalDrag_69 = InUseVerticalDrag_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AdvancedWidgets.RadialSlider.SetStepSize
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// float                          InValue_69                     (Parm, ZeroConstructor, IsPlainOldData)

void RadialSlider::SetStepSize(float InValue_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AdvancedWidgets.RadialSlider.SetStepSize"));

	RadialSlider_SetStepSize_Params params;
	params.InValue_69 = InValue_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AdvancedWidgets.RadialSlider.SetSliderRange
// (Final, Native, Public, HasOutParms, BlueprintCallable)
// Parameters:
// struct FRuntimeFloatCurve      InSliderRange_69               (ConstParm, Parm, OutParm, ReferenceParm)

void RadialSlider::SetSliderRange(const struct FRuntimeFloatCurve& InSliderRange_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AdvancedWidgets.RadialSlider.SetSliderRange"));

	RadialSlider_SetSliderRange_Params params;
	params.InSliderRange_69 = InSliderRange_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AdvancedWidgets.RadialSlider.SetSliderProgressColor
// (Final, Native, Public, HasDefaults, BlueprintCallable)
// Parameters:
// struct FLinearColor            InValue_69                     (Parm, ZeroConstructor, IsPlainOldData)

void RadialSlider::SetSliderProgressColor(const struct FLinearColor& InValue_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AdvancedWidgets.RadialSlider.SetSliderProgressColor"));

	RadialSlider_SetSliderProgressColor_Params params;
	params.InValue_69 = InValue_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AdvancedWidgets.RadialSlider.SetSliderHandleStartAngle
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// float                          InValue_69                     (Parm, ZeroConstructor, IsPlainOldData)

void RadialSlider::SetSliderHandleStartAngle(float InValue_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AdvancedWidgets.RadialSlider.SetSliderHandleStartAngle"));

	RadialSlider_SetSliderHandleStartAngle_Params params;
	params.InValue_69 = InValue_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AdvancedWidgets.RadialSlider.SetSliderHandleEndAngle
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// float                          InValue_69                     (Parm, ZeroConstructor, IsPlainOldData)

void RadialSlider::SetSliderHandleEndAngle(float InValue_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AdvancedWidgets.RadialSlider.SetSliderHandleEndAngle"));

	RadialSlider_SetSliderHandleEndAngle_Params params;
	params.InValue_69 = InValue_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AdvancedWidgets.RadialSlider.SetSliderHandleColor
// (Final, Native, Public, HasDefaults, BlueprintCallable)
// Parameters:
// struct FLinearColor            InValue_69                     (Parm, ZeroConstructor, IsPlainOldData)

void RadialSlider::SetSliderHandleColor(const struct FLinearColor& InValue_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AdvancedWidgets.RadialSlider.SetSliderHandleColor"));

	RadialSlider_SetSliderHandleColor_Params params;
	params.InValue_69 = InValue_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AdvancedWidgets.RadialSlider.SetSliderBarColor
// (Final, Native, Public, HasDefaults, BlueprintCallable)
// Parameters:
// struct FLinearColor            InValue_69                     (Parm, ZeroConstructor, IsPlainOldData)

void RadialSlider::SetSliderBarColor(const struct FLinearColor& InValue_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AdvancedWidgets.RadialSlider.SetSliderBarColor"));

	RadialSlider_SetSliderBarColor_Params params;
	params.InValue_69 = InValue_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AdvancedWidgets.RadialSlider.SetShowSliderHandle
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// bool                           InShowSliderHandle_69          (Parm, ZeroConstructor, IsPlainOldData)

void RadialSlider::SetShowSliderHandle(bool InShowSliderHandle_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AdvancedWidgets.RadialSlider.SetShowSliderHandle"));

	RadialSlider_SetShowSliderHandle_Params params;
	params.InShowSliderHandle_69 = InShowSliderHandle_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AdvancedWidgets.RadialSlider.SetShowSliderHand
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// bool                           InShowSliderHand_69            (Parm, ZeroConstructor, IsPlainOldData)

void RadialSlider::SetShowSliderHand(bool InShowSliderHand_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AdvancedWidgets.RadialSlider.SetShowSliderHand"));

	RadialSlider_SetShowSliderHand_Params params;
	params.InShowSliderHand_69 = InShowSliderHand_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AdvancedWidgets.RadialSlider.SetLocked
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// bool                           InValue_69                     (Parm, ZeroConstructor, IsPlainOldData)

void RadialSlider::SetLocked(bool InValue_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AdvancedWidgets.RadialSlider.SetLocked"));

	RadialSlider_SetLocked_Params params;
	params.InValue_69 = InValue_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AdvancedWidgets.RadialSlider.SetHandStartEndRatio
// (Final, Native, Public, HasDefaults, BlueprintCallable)
// Parameters:
// struct FVector2D               InValue_69                     (Parm, ZeroConstructor, IsPlainOldData)

void RadialSlider::SetHandStartEndRatio(const struct FVector2D& InValue_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AdvancedWidgets.RadialSlider.SetHandStartEndRatio"));

	RadialSlider_SetHandStartEndRatio_Params params;
	params.InValue_69 = InValue_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AdvancedWidgets.RadialSlider.SetCustomDefaultValue
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// float                          InValue_69                     (Parm, ZeroConstructor, IsPlainOldData)

void RadialSlider::SetCustomDefaultValue(float InValue_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AdvancedWidgets.RadialSlider.SetCustomDefaultValue"));

	RadialSlider_SetCustomDefaultValue_Params params;
	params.InValue_69 = InValue_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AdvancedWidgets.RadialSlider.SetCenterBackgroundColor
// (Final, Native, Public, HasDefaults, BlueprintCallable)
// Parameters:
// struct FLinearColor            InValue_69                     (Parm, ZeroConstructor, IsPlainOldData)

void RadialSlider::SetCenterBackgroundColor(const struct FLinearColor& InValue_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AdvancedWidgets.RadialSlider.SetCenterBackgroundColor"));

	RadialSlider_SetCenterBackgroundColor_Params params;
	params.InValue_69 = InValue_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AdvancedWidgets.RadialSlider.SetAngularOffset
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// float                          InValue_69                     (Parm, ZeroConstructor, IsPlainOldData)

void RadialSlider::SetAngularOffset(float InValue_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AdvancedWidgets.RadialSlider.SetAngularOffset"));

	RadialSlider_SetAngularOffset_Params params;
	params.InValue_69 = InValue_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AdvancedWidgets.RadialSlider.GetValue
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// float                          ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

float RadialSlider::GetValue()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AdvancedWidgets.RadialSlider.GetValue"));

	RadialSlider_GetValue_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AdvancedWidgets.RadialSlider.GetNormalizedSliderHandlePosition
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// float                          ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

float RadialSlider::GetNormalizedSliderHandlePosition()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AdvancedWidgets.RadialSlider.GetNormalizedSliderHandlePosition"));

	RadialSlider_GetNormalizedSliderHandlePosition_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AdvancedWidgets.RadialSlider.GetCustomDefaultValue
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// float                          ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

float RadialSlider::GetCustomDefaultValue()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AdvancedWidgets.RadialSlider.GetCustomDefaultValue"));

	RadialSlider_GetCustomDefaultValue_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

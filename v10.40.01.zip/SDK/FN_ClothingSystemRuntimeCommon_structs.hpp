#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Enums
//---------------------------------------------------------------------------

// Enum ClothingSystemRuntimeCommon.EClothingWindMethod_Legacy
enum class EClothingWindMethod_Legacy : uint8_t
{
	Legacy                         = 0,
	Accurate                       = 1,
	EClothingWindMethod_MAX        = 2
};


// Enum ClothingSystemRuntimeCommon.EWeightMapTargetCommon
enum class EWeightMapTargetCommon : uint8_t
{
	None                           = 0,
	MaxDistance                    = 1,
	BackstopDistance               = 2,
	BackstopRadius                 = 3,
	AnimDriveStiffness             = 4,
	AnimDriveDamping_DEPRECATED    = 5,
	EWeightMapTargetCommon_MAX     = 6
};


// Enum ClothingSystemRuntimeCommon.EClothMassMode
enum class EClothMassMode : uint8_t
{
	UniformMass                    = 0,
	TotalMass                      = 1,
	Density                        = 2,
	MaxClothMassMode               = 3,
	EClothMassMode_MAX             = 4
};



//---------------------------------------------------------------------------
//Script Structs
//---------------------------------------------------------------------------

// ScriptStruct ClothingSystemRuntimeCommon.PointWeightMap
// 0x0010
struct FPointWeightMap
{
	TArray<float>                                      Values_69;                                                // 0x0000(0x0010) (ZeroConstructor)
};

// ScriptStruct ClothingSystemRuntimeCommon.ClothTetherData
// 0x0010
struct FClothTetherData
{
	unsigned char                                      UnknownData00[0x10];                                      // 0x0000(0x0010) MISSED OFFSET
};

// ScriptStruct ClothingSystemRuntimeCommon.ClothPhysicalMeshData
// 0x00D8
struct FClothPhysicalMeshData
{
	TArray<struct FVector3f>                           Vertices_69;                                              // 0x0000(0x0010) (Edit, ZeroConstructor)
	TArray<struct FVector3f>                           Normals_69;                                               // 0x0010(0x0010) (Edit, ZeroConstructor)
	TArray<uint32_t>                                   Indices_69;                                               // 0x0020(0x0010) (Edit, ZeroConstructor)
	TMap<uint32_t, struct FPointWeightMap>             WeightMaps_69;                                            // 0x0030(0x0050) (Edit)
	TArray<float>                                      InverseMasses_69;                                         // 0x0080(0x0010) (Edit, ZeroConstructor)
	TArray<struct FClothVertBoneData>                  BoneData_69;                                              // 0x0090(0x0010) (Edit, ZeroConstructor)
	TArray<uint32_t>                                   SelfCollisionIndices_69;                                  // 0x00A0(0x0010) (Edit, ZeroConstructor)
	struct FClothTetherData                            EuclideanTethers_69;                                      // 0x00B0(0x0010) (Edit)
	struct FClothTetherData                            GeodesicTethers_69;                                       // 0x00C0(0x0010) (Edit)
	int                                                MaxBoneWeights_69;                                        // 0x00D0(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	int                                                NumFixedVerts_69;                                         // 0x00D4(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct ClothingSystemRuntimeCommon.ClothLODDataCommon
// 0x0148
struct FClothLODDataCommon
{
	struct FClothPhysicalMeshData                      PhysicalMeshData_69;                                      // 0x0000(0x00D8) (Edit)
	struct FClothCollisionData                         CollisionData_69;                                         // 0x00D8(0x0040) (Edit)
	bool                                               bUseMultipleInfluences_69;                                // 0x0118(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0119(0x0003) MISSED OFFSET
	float                                              SkinningKernelRadius_69;                                  // 0x011C(0x0004) (ZeroConstructor, IsPlainOldData)
	bool                                               bSmoothTransition_69;                                     // 0x0120(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x27];                                      // 0x0121(0x0027) MISSED OFFSET
};

// ScriptStruct ClothingSystemRuntimeCommon.ClothConstraintSetup_Legacy
// 0x0010
struct FClothConstraintSetup_Legacy
{
	float                                              Stiffness_69;                                             // 0x0000(0x0004) (ZeroConstructor, IsPlainOldData)
	float                                              StiffnessMultiplier_69;                                   // 0x0004(0x0004) (ZeroConstructor, IsPlainOldData)
	float                                              StretchLimit_69;                                          // 0x0008(0x0004) (ZeroConstructor, IsPlainOldData)
	float                                              CompressionLimit_69;                                      // 0x000C(0x0004) (ZeroConstructor, IsPlainOldData)
};

// ScriptStruct ClothingSystemRuntimeCommon.ClothConfig_Legacy
// 0x0130
struct FClothConfig_Legacy
{
	EClothingWindMethod_Legacy                         WindMethod_69;                                            // 0x0000(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0001(0x0003) MISSED OFFSET
	struct FClothConstraintSetup_Legacy                VerticalConstraintConfig_69;                              // 0x0004(0x0010)
	struct FClothConstraintSetup_Legacy                HorizontalConstraintConfig_69;                            // 0x0014(0x0010)
	struct FClothConstraintSetup_Legacy                BendConstraintConfig_69;                                  // 0x0024(0x0010)
	struct FClothConstraintSetup_Legacy                ShearConstraintConfig_69;                                 // 0x0034(0x0010)
	float                                              SelfCollisionRadius_69;                                   // 0x0044(0x0004) (ZeroConstructor, IsPlainOldData)
	float                                              SelfCollisionStiffness_69;                                // 0x0048(0x0004) (ZeroConstructor, IsPlainOldData)
	float                                              SelfCollisionCullScale_69;                                // 0x004C(0x0004) (ZeroConstructor, IsPlainOldData)
	struct FVector                                     Damping_69;                                               // 0x0050(0x0018) (ZeroConstructor, IsPlainOldData)
	float                                              Friction_69;                                              // 0x0068(0x0004) (ZeroConstructor, IsPlainOldData)
	float                                              WindDragCoefficient_69;                                   // 0x006C(0x0004) (ZeroConstructor, IsPlainOldData)
	float                                              WindLiftCoefficient_69;                                   // 0x0070(0x0004) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x4];                                       // 0x0074(0x0004) MISSED OFFSET
	struct FVector                                     LinearDrag_69;                                            // 0x0078(0x0018) (ZeroConstructor, IsPlainOldData)
	struct FVector                                     AngularDrag_69;                                           // 0x0090(0x0018) (ZeroConstructor, IsPlainOldData)
	struct FVector                                     LinearInertiaScale_69;                                    // 0x00A8(0x0018) (ZeroConstructor, IsPlainOldData)
	struct FVector                                     AngularInertiaScale_69;                                   // 0x00C0(0x0018) (ZeroConstructor, IsPlainOldData)
	struct FVector                                     CentrifugalInertiaScale_69;                               // 0x00D8(0x0018) (ZeroConstructor, IsPlainOldData)
	float                                              SolverFrequency_69;                                       // 0x00F0(0x0004) (ZeroConstructor, IsPlainOldData)
	float                                              StiffnessFrequency_69;                                    // 0x00F4(0x0004) (ZeroConstructor, IsPlainOldData)
	float                                              GravityScale_69;                                          // 0x00F8(0x0004) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData02[0x4];                                       // 0x00FC(0x0004) MISSED OFFSET
	struct FVector                                     GravityOverride_69;                                       // 0x0100(0x0018) (ZeroConstructor, IsPlainOldData)
	bool                                               bUseGravityOverride_69;                                   // 0x0118(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData03[0x3];                                       // 0x0119(0x0003) MISSED OFFSET
	float                                              TetherStiffness_69;                                       // 0x011C(0x0004) (ZeroConstructor, IsPlainOldData)
	float                                              TetherLimit_69;                                           // 0x0120(0x0004) (ZeroConstructor, IsPlainOldData)
	float                                              CollisionThickness_69;                                    // 0x0124(0x0004) (ZeroConstructor, IsPlainOldData)
	float                                              AnimDriveSpringStiffness_69;                              // 0x0128(0x0004) (ZeroConstructor, IsPlainOldData)
	float                                              AnimDriveDamperStiffness_69;                              // 0x012C(0x0004) (ZeroConstructor, IsPlainOldData)
};

// ScriptStruct ClothingSystemRuntimeCommon.ClothParameterMask_Legacy
// 0x0028
struct FClothParameterMask_Legacy
{
	struct FName                                       MaskName_69;                                              // 0x0000(0x0008) (ZeroConstructor, IsPlainOldData)
	EWeightMapTargetCommon                             CurrentTarget_69;                                         // 0x0004(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0005(0x0003) MISSED OFFSET
	float                                              MaxValue_69;                                              // 0x0008(0x0004) (ZeroConstructor, Deprecated, IsPlainOldData)
	float                                              MinValue_69;                                              // 0x000C(0x0004) (ZeroConstructor, Deprecated, IsPlainOldData)
	TArray<float>                                      Values_69;                                                // 0x0010(0x0010) (ZeroConstructor)
	bool                                               bEnabled_69;                                              // 0x0020(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x7];                                       // 0x0021(0x0007) MISSED OFFSET
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

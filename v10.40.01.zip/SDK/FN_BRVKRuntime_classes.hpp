#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Classes
//---------------------------------------------------------------------------

// Class BRVKRuntime.FortBRVKLoadingData
// 0x0028 (0x0058 - 0x0030)
class FortBRVKLoadingData : public PrimaryDataAsset
{
public:
	unsigned char                                      UnknownData00[0x8];                                       // 0x0030(0x0008) MISSED OFFSET
	struct FString                                     VKProjectGUID_69;                                         // 0x0038(0x0010) (Edit, ZeroConstructor, DisableEditOnInstance)
	bool                                               bReplacesPlaceHolderContent_69;                           // 0x0048(0x0001) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData01[0x3];                                       // 0x0049(0x0003) MISSED OFFSET
	struct FName                                       FoundationToReplaceTag_69;                                // 0x004C(0x0008) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	bool                                               bReplaceWithCalendarEventInstead_69;                      // 0x0050(0x0001) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData02[0x7];                                       // 0x0051(0x0007) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class BRVKRuntime.FortBRVKLoadingData"));
		
		return ptr;
	}

};


// Class BRVKRuntime.FortBRVKDADAssetManager
// 0x0018 (0x0040 - 0x0028)
class FortBRVKDADAssetManager : public Object_32759
{
public:
	unsigned char                                      UnknownData00[0x8];                                       // 0x0028(0x0008) MISSED OFFSET
	TArray<class Object_32759*>                        BRVKAssetDataInstances_69;                                // 0x0030(0x0010) (ZeroConstructor, Transient)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class BRVKRuntime.FortBRVKDADAssetManager"));
		
		return ptr;
	}

};


// Class BRVKRuntime.FortBRVKGameFeatureAction_HotfixableAddToPlaylist
// 0x0040 (0x0068 - 0x0028)
class FortBRVKGameFeatureAction_HotfixableAddToPlaylist : public GameFeatureAction
{
public:
	struct FGameplayTagContainer                       BRPlaylistTags_69;                                        // 0x0028(0x0020) (Edit, Config)
	struct FGameplayTagContainer                       BRPlaylistTagsToExclude_69;                               // 0x0048(0x0020) (Edit, Config)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class BRVKRuntime.FortBRVKGameFeatureAction_HotfixableAddToPlaylist"));
		
		return ptr;
	}

};


// Class BRVKRuntime.FortBRVKGameFeatureAction_LoadVKProject
// 0x0028 (0x0050 - 0x0028)
class FortBRVKGameFeatureAction_LoadVKProject : public GameFeatureAction
{
public:
	class FortBRVKLoadingData*                         VKLoadingData_69;                                         // 0x0028(0x0008) (ZeroConstructor, Transient)
	unsigned char                                      UnknownData00[0x20];                                      // 0x0030(0x0020) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class BRVKRuntime.FortBRVKGameFeatureAction_LoadVKProject"));
		
		return ptr;
	}

};


// Class BRVKRuntime.FortBRVKGameFeatureAction_RegisterContentErrorHandler
// 0x0008 (0x0030 - 0x0028)
class FortBRVKGameFeatureAction_RegisterContentErrorHandler : public GameFeatureAction
{
public:
	unsigned char                                      UnknownData00[0x8];                                       // 0x0028(0x0008) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class BRVKRuntime.FortBRVKGameFeatureAction_RegisterContentErrorHandler"));
		
		return ptr;
	}

};


// Class BRVKRuntime.FortBRVKGameFeatureObserver
// 0x0000 (0x0028 - 0x0028)
class FortBRVKGameFeatureObserver : public GameFeatureAction
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class BRVKRuntime.FortBRVKGameFeatureObserver"));
		
		return ptr;
	}

};


// Class BRVKRuntime.FortBRVKPlayspace
// 0x0010 (0x0630 - 0x0620)
class FortBRVKPlayspace : public FortPlayspace
{
public:
	class FortLevelStreamComponent*                    LevelStreamComponent_69;                                  // 0x0620(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	class FortProjectPlayComponent*                    ProjectPlayComponent_69;                                  // 0x0628(0x0008) (ExportObject, ZeroConstructor, InstancedReference)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class BRVKRuntime.FortBRVKPlayspace"));
		
		return ptr;
	}

};


// Class BRVKRuntime.FortBRVKTheBlockMutator
// 0x0030 (0x0480 - 0x0450)
class FortBRVKTheBlockMutator : public FortAthenaMutator_GameModeBase
{
public:
	bool                                               bContentIsReadyOrFailed_69;                               // 0x0450(0x0001) (Net, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x27];                                      // 0x0451(0x0027) MISSED OFFSET
	class FortGameModeAthena*                          CachedGameModeAthena_69;                                  // 0x0478(0x0008) (ZeroConstructor, Transient)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class BRVKRuntime.FortBRVKTheBlockMutator"));
		
		return ptr;
	}

};


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

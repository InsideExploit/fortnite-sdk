#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Script Structs
//---------------------------------------------------------------------------

// ScriptStruct AudioMotorSimStandardComponents.MotorSimGearCurve
// 0x0090
struct FMotorSimGearCurve
{
	struct FRuntimeFloatCurve                          RpmCurve_69;                                              // 0x0000(0x0088) (Edit)
	float                                              SpeedTopThreshold_69;                                     // 0x0088(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x008C(0x0004) MISSED OFFSET
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Functions
//---------------------------------------------------------------------------

// Function AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary.StartSessionWithAttributes
// (Final, Native, Static, Public, HasOutParms, BlueprintCallable)
// Parameters:
// TArray<struct FAnalyticsEventAttr> Attributes_69                  (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool AnalyticsBlueprintLibrary::STATIC_StartSessionWithAttributes(TArray<struct FAnalyticsEventAttr> Attributes_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary.StartSessionWithAttributes"));

	AnalyticsBlueprintLibrary_StartSessionWithAttributes_Params params;
	params.Attributes_69 = Attributes_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary.StartSession
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool AnalyticsBlueprintLibrary::STATIC_StartSession()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary.StartSession"));

	AnalyticsBlueprintLibrary_StartSession_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary.SetUserId
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// struct FString                 UserId_69                      (Parm, ZeroConstructor)

void AnalyticsBlueprintLibrary::STATIC_SetUserId(const struct FString& UserId_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary.SetUserId"));

	AnalyticsBlueprintLibrary_SetUserId_Params params;
	params.UserId_69 = UserId_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary.SetSessionId
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// struct FString                 SessionId_69                   (Parm, ZeroConstructor)

void AnalyticsBlueprintLibrary::STATIC_SetSessionId(const struct FString& SessionId_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary.SetSessionId"));

	AnalyticsBlueprintLibrary_SetSessionId_Params params;
	params.SessionId_69 = SessionId_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary.SetLocation
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// struct FString                 Location_69                    (Parm, ZeroConstructor)

void AnalyticsBlueprintLibrary::STATIC_SetLocation(const struct FString& Location_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary.SetLocation"));

	AnalyticsBlueprintLibrary_SetLocation_Params params;
	params.Location_69 = Location_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary.SetGender
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// struct FString                 Gender_69                      (Parm, ZeroConstructor)

void AnalyticsBlueprintLibrary::STATIC_SetGender(const struct FString& Gender_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary.SetGender"));

	AnalyticsBlueprintLibrary_SetGender_Params params;
	params.Gender_69 = Gender_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary.SetBuildInfo
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// struct FString                 BuildInfo_69                   (Parm, ZeroConstructor)

void AnalyticsBlueprintLibrary::STATIC_SetBuildInfo(const struct FString& BuildInfo_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary.SetBuildInfo"));

	AnalyticsBlueprintLibrary_SetBuildInfo_Params params;
	params.BuildInfo_69 = BuildInfo_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary.SetAge
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// int                            Age_69                         (Parm, ZeroConstructor, IsPlainOldData)

void AnalyticsBlueprintLibrary::STATIC_SetAge(int Age_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary.SetAge"));

	AnalyticsBlueprintLibrary_SetAge_Params params;
	params.Age_69 = Age_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary.RecordSimpleItemPurchaseWithAttributes
// (Final, Native, Static, Public, HasOutParms, BlueprintCallable)
// Parameters:
// struct FString                 ItemId_69                      (Parm, ZeroConstructor)
// int                            ItemQuantity_69                (Parm, ZeroConstructor, IsPlainOldData)
// TArray<struct FAnalyticsEventAttr> Attributes_69                  (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)

void AnalyticsBlueprintLibrary::STATIC_RecordSimpleItemPurchaseWithAttributes(const struct FString& ItemId_69, int ItemQuantity_69, TArray<struct FAnalyticsEventAttr> Attributes_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary.RecordSimpleItemPurchaseWithAttributes"));

	AnalyticsBlueprintLibrary_RecordSimpleItemPurchaseWithAttributes_Params params;
	params.ItemId_69 = ItemId_69;
	params.ItemQuantity_69 = ItemQuantity_69;
	params.Attributes_69 = Attributes_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary.RecordSimpleItemPurchase
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// struct FString                 ItemId_69                      (Parm, ZeroConstructor)
// int                            ItemQuantity_69                (Parm, ZeroConstructor, IsPlainOldData)

void AnalyticsBlueprintLibrary::STATIC_RecordSimpleItemPurchase(const struct FString& ItemId_69, int ItemQuantity_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary.RecordSimpleItemPurchase"));

	AnalyticsBlueprintLibrary_RecordSimpleItemPurchase_Params params;
	params.ItemId_69 = ItemId_69;
	params.ItemQuantity_69 = ItemQuantity_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary.RecordSimpleCurrencyPurchaseWithAttributes
// (Final, Native, Static, Public, HasOutParms, BlueprintCallable)
// Parameters:
// struct FString                 GameCurrencyType_69            (Parm, ZeroConstructor)
// int                            GameCurrencyAmount_69          (Parm, ZeroConstructor, IsPlainOldData)
// TArray<struct FAnalyticsEventAttr> Attributes_69                  (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)

void AnalyticsBlueprintLibrary::STATIC_RecordSimpleCurrencyPurchaseWithAttributes(const struct FString& GameCurrencyType_69, int GameCurrencyAmount_69, TArray<struct FAnalyticsEventAttr> Attributes_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary.RecordSimpleCurrencyPurchaseWithAttributes"));

	AnalyticsBlueprintLibrary_RecordSimpleCurrencyPurchaseWithAttributes_Params params;
	params.GameCurrencyType_69 = GameCurrencyType_69;
	params.GameCurrencyAmount_69 = GameCurrencyAmount_69;
	params.Attributes_69 = Attributes_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary.RecordSimpleCurrencyPurchase
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// struct FString                 GameCurrencyType_69            (Parm, ZeroConstructor)
// int                            GameCurrencyAmount_69          (Parm, ZeroConstructor, IsPlainOldData)

void AnalyticsBlueprintLibrary::STATIC_RecordSimpleCurrencyPurchase(const struct FString& GameCurrencyType_69, int GameCurrencyAmount_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary.RecordSimpleCurrencyPurchase"));

	AnalyticsBlueprintLibrary_RecordSimpleCurrencyPurchase_Params params;
	params.GameCurrencyType_69 = GameCurrencyType_69;
	params.GameCurrencyAmount_69 = GameCurrencyAmount_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary.RecordProgressWithFullHierarchyAndAttributes
// (Final, Native, Static, Public, HasOutParms, BlueprintCallable)
// Parameters:
// struct FString                 ProgressType_69                (Parm, ZeroConstructor)
// TArray<struct FString>         ProgressNames_69               (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
// TArray<struct FAnalyticsEventAttr> Attributes_69                  (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)

void AnalyticsBlueprintLibrary::STATIC_RecordProgressWithFullHierarchyAndAttributes(const struct FString& ProgressType_69, TArray<struct FString> ProgressNames_69, TArray<struct FAnalyticsEventAttr> Attributes_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary.RecordProgressWithFullHierarchyAndAttributes"));

	AnalyticsBlueprintLibrary_RecordProgressWithFullHierarchyAndAttributes_Params params;
	params.ProgressType_69 = ProgressType_69;
	params.ProgressNames_69 = ProgressNames_69;
	params.Attributes_69 = Attributes_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary.RecordProgressWithAttributes
// (Final, Native, Static, Public, HasOutParms, BlueprintCallable)
// Parameters:
// struct FString                 ProgressType_69                (Parm, ZeroConstructor)
// struct FString                 ProgressName_69                (Parm, ZeroConstructor)
// TArray<struct FAnalyticsEventAttr> Attributes_69                  (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)

void AnalyticsBlueprintLibrary::STATIC_RecordProgressWithAttributes(const struct FString& ProgressType_69, const struct FString& ProgressName_69, TArray<struct FAnalyticsEventAttr> Attributes_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary.RecordProgressWithAttributes"));

	AnalyticsBlueprintLibrary_RecordProgressWithAttributes_Params params;
	params.ProgressType_69 = ProgressType_69;
	params.ProgressName_69 = ProgressName_69;
	params.Attributes_69 = Attributes_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary.RecordProgress
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// struct FString                 ProgressType_69                (Parm, ZeroConstructor)
// struct FString                 ProgressName_69                (Parm, ZeroConstructor)

void AnalyticsBlueprintLibrary::STATIC_RecordProgress(const struct FString& ProgressType_69, const struct FString& ProgressName_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary.RecordProgress"));

	AnalyticsBlueprintLibrary_RecordProgress_Params params;
	params.ProgressType_69 = ProgressType_69;
	params.ProgressName_69 = ProgressName_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary.RecordItemPurchase
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// struct FString                 ItemId_69                      (Parm, ZeroConstructor)
// struct FString                 Currency_69                    (Parm, ZeroConstructor)
// int                            PerItemCost_69                 (Parm, ZeroConstructor, IsPlainOldData)
// int                            ItemQuantity_69                (Parm, ZeroConstructor, IsPlainOldData)

void AnalyticsBlueprintLibrary::STATIC_RecordItemPurchase(const struct FString& ItemId_69, const struct FString& Currency_69, int PerItemCost_69, int ItemQuantity_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary.RecordItemPurchase"));

	AnalyticsBlueprintLibrary_RecordItemPurchase_Params params;
	params.ItemId_69 = ItemId_69;
	params.Currency_69 = Currency_69;
	params.PerItemCost_69 = PerItemCost_69;
	params.ItemQuantity_69 = ItemQuantity_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary.RecordEventWithAttributes
// (Final, Native, Static, Public, HasOutParms, BlueprintCallable)
// Parameters:
// struct FString                 EventName_69                   (Parm, ZeroConstructor)
// TArray<struct FAnalyticsEventAttr> Attributes_69                  (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)

void AnalyticsBlueprintLibrary::STATIC_RecordEventWithAttributes(const struct FString& EventName_69, TArray<struct FAnalyticsEventAttr> Attributes_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary.RecordEventWithAttributes"));

	AnalyticsBlueprintLibrary_RecordEventWithAttributes_Params params;
	params.EventName_69 = EventName_69;
	params.Attributes_69 = Attributes_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary.RecordEventWithAttribute
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// struct FString                 EventName_69                   (Parm, ZeroConstructor)
// struct FString                 AttributeName_69               (Parm, ZeroConstructor)
// struct FString                 AttributeValue_69              (Parm, ZeroConstructor)

void AnalyticsBlueprintLibrary::STATIC_RecordEventWithAttribute(const struct FString& EventName_69, const struct FString& AttributeName_69, const struct FString& AttributeValue_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary.RecordEventWithAttribute"));

	AnalyticsBlueprintLibrary_RecordEventWithAttribute_Params params;
	params.EventName_69 = EventName_69;
	params.AttributeName_69 = AttributeName_69;
	params.AttributeValue_69 = AttributeValue_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary.RecordEvent
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// struct FString                 EventName_69                   (Parm, ZeroConstructor)

void AnalyticsBlueprintLibrary::STATIC_RecordEvent(const struct FString& EventName_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary.RecordEvent"));

	AnalyticsBlueprintLibrary_RecordEvent_Params params;
	params.EventName_69 = EventName_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary.RecordErrorWithAttributes
// (Final, Native, Static, Public, HasOutParms, BlueprintCallable)
// Parameters:
// struct FString                 Error_69                       (Parm, ZeroConstructor)
// TArray<struct FAnalyticsEventAttr> Attributes_69                  (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)

void AnalyticsBlueprintLibrary::STATIC_RecordErrorWithAttributes(const struct FString& Error_69, TArray<struct FAnalyticsEventAttr> Attributes_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary.RecordErrorWithAttributes"));

	AnalyticsBlueprintLibrary_RecordErrorWithAttributes_Params params;
	params.Error_69 = Error_69;
	params.Attributes_69 = Attributes_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary.RecordError
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// struct FString                 Error_69                       (Parm, ZeroConstructor)

void AnalyticsBlueprintLibrary::STATIC_RecordError(const struct FString& Error_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary.RecordError"));

	AnalyticsBlueprintLibrary_RecordError_Params params;
	params.Error_69 = Error_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary.RecordCurrencyPurchase
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// struct FString                 GameCurrencyType_69            (Parm, ZeroConstructor)
// int                            GameCurrencyAmount_69          (Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 RealCurrencyType_69            (Parm, ZeroConstructor)
// float                          RealMoneyCost_69               (Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 PaymentProvider_69             (Parm, ZeroConstructor)

void AnalyticsBlueprintLibrary::STATIC_RecordCurrencyPurchase(const struct FString& GameCurrencyType_69, int GameCurrencyAmount_69, const struct FString& RealCurrencyType_69, float RealMoneyCost_69, const struct FString& PaymentProvider_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary.RecordCurrencyPurchase"));

	AnalyticsBlueprintLibrary_RecordCurrencyPurchase_Params params;
	params.GameCurrencyType_69 = GameCurrencyType_69;
	params.GameCurrencyAmount_69 = GameCurrencyAmount_69;
	params.RealCurrencyType_69 = RealCurrencyType_69;
	params.RealMoneyCost_69 = RealMoneyCost_69;
	params.PaymentProvider_69 = PaymentProvider_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary.RecordCurrencyGivenWithAttributes
// (Final, Native, Static, Public, HasOutParms, BlueprintCallable)
// Parameters:
// struct FString                 GameCurrencyType_69            (Parm, ZeroConstructor)
// int                            GameCurrencyAmount_69          (Parm, ZeroConstructor, IsPlainOldData)
// TArray<struct FAnalyticsEventAttr> Attributes_69                  (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)

void AnalyticsBlueprintLibrary::STATIC_RecordCurrencyGivenWithAttributes(const struct FString& GameCurrencyType_69, int GameCurrencyAmount_69, TArray<struct FAnalyticsEventAttr> Attributes_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary.RecordCurrencyGivenWithAttributes"));

	AnalyticsBlueprintLibrary_RecordCurrencyGivenWithAttributes_Params params;
	params.GameCurrencyType_69 = GameCurrencyType_69;
	params.GameCurrencyAmount_69 = GameCurrencyAmount_69;
	params.Attributes_69 = Attributes_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary.RecordCurrencyGiven
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// struct FString                 GameCurrencyType_69            (Parm, ZeroConstructor)
// int                            GameCurrencyAmount_69          (Parm, ZeroConstructor, IsPlainOldData)

void AnalyticsBlueprintLibrary::STATIC_RecordCurrencyGiven(const struct FString& GameCurrencyType_69, int GameCurrencyAmount_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary.RecordCurrencyGiven"));

	AnalyticsBlueprintLibrary_RecordCurrencyGiven_Params params;
	params.GameCurrencyType_69 = GameCurrencyType_69;
	params.GameCurrencyAmount_69 = GameCurrencyAmount_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary.MakeEventAttribute
// (Final, Native, Static, Public, BlueprintCallable, BlueprintPure)
// Parameters:
// struct FString                 AttributeName_69               (Parm, ZeroConstructor)
// struct FString                 AttributeValue_69              (Parm, ZeroConstructor)
// struct FAnalyticsEventAttr     ReturnValue_69                 (Parm, OutParm, ReturnParm)

struct FAnalyticsEventAttr AnalyticsBlueprintLibrary::STATIC_MakeEventAttribute(const struct FString& AttributeName_69, const struct FString& AttributeValue_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary.MakeEventAttribute"));

	AnalyticsBlueprintLibrary_MakeEventAttribute_Params params;
	params.AttributeName_69 = AttributeName_69;
	params.AttributeValue_69 = AttributeValue_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary.GetUserId
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// struct FString                 ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString AnalyticsBlueprintLibrary::STATIC_GetUserId()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary.GetUserId"));

	AnalyticsBlueprintLibrary_GetUserId_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary.GetSessionId
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// struct FString                 ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString AnalyticsBlueprintLibrary::STATIC_GetSessionId()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary.GetSessionId"));

	AnalyticsBlueprintLibrary_GetSessionId_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary.FlushEvents
// (Final, Native, Static, Public, BlueprintCallable)

void AnalyticsBlueprintLibrary::STATIC_FlushEvents()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary.FlushEvents"));

	AnalyticsBlueprintLibrary_FlushEvents_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary.EndSession
// (Final, Native, Static, Public, BlueprintCallable)

void AnalyticsBlueprintLibrary::STATIC_EndSession()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary.EndSession"));

	AnalyticsBlueprintLibrary_EndSession_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

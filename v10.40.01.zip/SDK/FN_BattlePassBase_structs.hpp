#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Enums
//---------------------------------------------------------------------------

// Enum BattlePassBase.EBattlePassLandingPageSpecialEntryType
enum class EBattlePassLandingPageSpecialEntryType : uint8_t
{
	None                           = 0,
	Subscription                   = 1,
	CharacterCustomizer            = 2,
	SpecialCharacter               = 3,
	COUNT                          = 4,
	EBattlePassLandingPageSpecialEntryType_MAX = 5
};


// Enum BattlePassBase.BattlePassTileAvailabilityStates
enum class EBattlePassTileAvailabilityStates : uint8_t
{
	Invalid                        = 0,
	Available                      = 1,
	Owned                          = 2,
	Locked                         = 3,
	BattlePassTileAvailabilityStates_MAX = 4
};



//---------------------------------------------------------------------------
//Script Structs
//---------------------------------------------------------------------------

// ScriptStruct BattlePassBase.BattlePassLandingPageEntryPreviewInfo
// 0x0038
struct FBattlePassLandingPageEntryPreviewInfo
{
	EBattlePassLandingPageSpecialEntryType             SpecialEntryType_69;                                      // 0x0000(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0001(0x0007) MISSED OFFSET
	TArray<EFortItemType>                              SubscriptionItemTypesToDisplay_69;                        // 0x0008(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
	struct FGameplayTag                                SpecialCharacterVariantChannelToModify_69;                // 0x0018(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly)
	struct FGameplayTag                                SpecialCharacterActiveVariantTag_69;                      // 0x001C(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly)
	unsigned char                                      UnknownData01[0x10];                                      // 0x0020(0x0010) UNKNOWN PROPERTY: ArrayProperty BattlePassBase.BattlePassLandingPageEntryPreviewInfo.PreviewItems_69
	float                                              TransitionTime_69;                                        // 0x0030(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData02[0x4];                                       // 0x0034(0x0004) MISSED OFFSET
};

// ScriptStruct BattlePassBase.BattlePassLandingPageButtonTexts
// 0x0048
struct FBattlePassLandingPageButtonTexts
{
	struct FText                                       TileText_69;                                              // 0x0000(0x0018) (Edit, BlueprintVisible, BlueprintReadOnly)
	struct FText                                       LandingPageTitleText_69;                                  // 0x0018(0x0018) (Edit, BlueprintVisible, BlueprintReadOnly)
	struct FText                                       LandingPageDescriptionText_69;                            // 0x0030(0x0018) (Edit, BlueprintVisible, BlueprintReadOnly)
};

// ScriptStruct BattlePassBase.BattlePassLandingPageButtonDisplayDetails
// 0x0070
struct FBattlePassLandingPageButtonDisplayDetails
{
	struct FBattlePassLandingPageButtonTexts           ButtonTexts_69;                                           // 0x0000(0x0048) (Edit, BlueprintVisible, BlueprintReadOnly)
	bool                                               bIsBPLocked_69;                                           // 0x0048(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0049(0x0007) MISSED OFFSET
	struct FText                                       MissingCosmeticNameText_69;                               // 0x0050(0x0018) (Edit, BlueprintVisible, BlueprintReadOnly)
	struct FTimespan                                   DelayTimespan_69;                                         // 0x0068(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
};

// ScriptStruct BattlePassBase.SeasonalResourceList
// 0x0010
struct FSeasonalResourceList
{
	TArray<class FortPersistentResourceItemDefinition*> SeasonalResources_69;                                     // 0x0000(0x0010) (ZeroConstructor)
};

// ScriptStruct BattlePassBase.BattlePassEntrySelectedParams
// 0x0058
struct FBattlePassEntrySelectedParams
{
	unsigned char                                      UnknownData00[0x58];                                      // 0x0000(0x0058) MISSED OFFSET
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

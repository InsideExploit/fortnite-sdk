#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Script Structs
//---------------------------------------------------------------------------

// ScriptStruct DeveloperSettings.PlatformSettingsInstances
// 0x0058
struct FPlatformSettingsInstances
{
	class PlatformSettings*                            PlatformInstance_69;                                      // 0x0000(0x0008) (ZeroConstructor, Transient)
	TMap<struct FName, class PlatformSettings*>        OtherPlatforms_69;                                        // 0x0008(0x0050) (Transient)
};

// ScriptStruct DeveloperSettings.PerPlatformSettings
// 0x0010
struct FPerPlatformSettings
{
	TArray<class PlatformSettings*>                    Settings_69;                                              // 0x0000(0x0010) (Edit, ExportObject, EditFixedSize, ZeroConstructor, Transient)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

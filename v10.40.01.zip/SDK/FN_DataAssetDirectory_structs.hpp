#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Enums
//---------------------------------------------------------------------------

// Enum DataAssetDirectory.EDataAssetDirectoryUpdateStatus
enum class EDataAssetDirectoryUpdateStatus : uint8_t
{
	Failed                         = 0,
	Success                        = 1,
	SuccessNoChange                = 2,
	EDataAssetDirectoryUpdateStatus_MAX = 3
};


// Enum DataAssetDirectory.EDataAssetDirectoryTestEnum
enum class EDataAssetDirectoryTestEnum : uint8_t
{
	A                              = 0,
	B                              = 1,
	C                              = 2,
	D                              = 3,
	EDataAssetDirectoryTestEnum_MAX = 4
};



//---------------------------------------------------------------------------
//Script Structs
//---------------------------------------------------------------------------

// ScriptStruct DataAssetDirectory.DataAssetDirectoryTestPODStruct
// 0x0040
struct FDataAssetDirectoryTestPODStruct
{
	EDataAssetDirectoryTestEnum                        EnumProperty_69;                                          // 0x0000(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0001(0x0003) MISSED OFFSET
	int                                                IntProperty_69;                                           // 0x0004(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	float                                              FloatProperty_69;                                         // 0x0008(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	bool                                               BoolProperty_69;                                          // 0x000C(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData01[0x3];                                       // 0x000D(0x0003) MISSED OFFSET
	struct FString                                     StringProperty_69;                                        // 0x0010(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance)
	struct FName                                       NameProperty_69;                                          // 0x0020(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData02[0x4];                                       // 0x0024(0x0004) MISSED OFFSET
	struct FText                                       TextProperty_69;                                          // 0x0028(0x0018) (Edit, BlueprintVisible, BlueprintReadOnly, DisableEditOnInstance)
};

// ScriptStruct DataAssetDirectory.DataAssetDirectoryTestSimpleStruct
// 0x0004
struct FDataAssetDirectoryTestSimpleStruct
{
	int                                                IntProperty_69;                                           // 0x0000(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

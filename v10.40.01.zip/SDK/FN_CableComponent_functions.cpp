// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Functions
//---------------------------------------------------------------------------

// Function CableComponent.CableComponent.SetAttachEndToComponent
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// class SceneComponent*          Component_69                   (Parm, ZeroConstructor, InstancedReference)
// struct FName                   SocketName_69                  (Parm, ZeroConstructor, IsPlainOldData)

void CableComponent::SetAttachEndToComponent(class SceneComponent* Component_69, const struct FName& SocketName_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CableComponent.CableComponent.SetAttachEndToComponent"));

	CableComponent_SetAttachEndToComponent_Params params;
	params.Component_69 = Component_69;
	params.SocketName_69 = SocketName_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CableComponent.CableComponent.SetAttachEndTo
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// class Actor_32759*             Actor_69                       (Parm, ZeroConstructor)
// struct FName                   ComponentProperty_69           (Parm, ZeroConstructor, IsPlainOldData)
// struct FName                   SocketName_69                  (Parm, ZeroConstructor, IsPlainOldData)

void CableComponent::SetAttachEndTo(class Actor_32759* Actor_69, const struct FName& ComponentProperty_69, const struct FName& SocketName_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CableComponent.CableComponent.SetAttachEndTo"));

	CableComponent_SetAttachEndTo_Params params;
	params.Actor_69 = Actor_69;
	params.ComponentProperty_69 = ComponentProperty_69;
	params.SocketName_69 = SocketName_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CableComponent.CableComponent.GetCableParticleLocations
// (Final, Native, Public, HasOutParms, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// TArray<struct FVector>         Locations_69                   (Parm, OutParm, ZeroConstructor)

void CableComponent::GetCableParticleLocations(TArray<struct FVector>* Locations_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CableComponent.CableComponent.GetCableParticleLocations"));

	CableComponent_GetCableParticleLocations_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (Locations_69 != nullptr)
		*Locations_69 = params.Locations_69;
}


// Function CableComponent.CableComponent.GetAttachedComponent
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// class SceneComponent*          ReturnValue_69                 (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)

class SceneComponent* CableComponent::GetAttachedComponent()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CableComponent.CableComponent.GetAttachedComponent"));

	CableComponent_GetAttachedComponent_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CableComponent.CableComponent.GetAttachedActor
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// class Actor_32759*             ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

class Actor_32759* CableComponent::GetAttachedActor()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CableComponent.CableComponent.GetAttachedActor"));

	CableComponent_GetAttachedActor_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

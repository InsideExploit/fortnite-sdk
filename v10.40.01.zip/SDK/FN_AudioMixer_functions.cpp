// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Functions
//---------------------------------------------------------------------------

// Function AudioMixer.SynthComponent.Stop
// (Final, Native, Public, BlueprintCallable)

void SynthComponent::Stop()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioMixer.SynthComponent.Stop"));

	SynthComponent_Stop_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AudioMixer.SynthComponent.Start
// (Final, Native, Public, BlueprintCallable)

void SynthComponent::Start()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioMixer.SynthComponent.Start"));

	SynthComponent_Start_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AudioMixer.SynthComponent.SetVolumeMultiplier
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// float                          VolumeMultiplier_69            (Parm, ZeroConstructor, IsPlainOldData)

void SynthComponent::SetVolumeMultiplier(float VolumeMultiplier_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioMixer.SynthComponent.SetVolumeMultiplier"));

	SynthComponent_SetVolumeMultiplier_Params params;
	params.VolumeMultiplier_69 = VolumeMultiplier_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AudioMixer.SynthComponent.SetSubmixSend
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// class SoundSubmixBase*         Submix_69                      (Parm, ZeroConstructor)
// float                          SendLevel_69                   (Parm, ZeroConstructor, IsPlainOldData)

void SynthComponent::SetSubmixSend(class SoundSubmixBase* Submix_69, float SendLevel_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioMixer.SynthComponent.SetSubmixSend"));

	SynthComponent_SetSubmixSend_Params params;
	params.Submix_69 = Submix_69;
	params.SendLevel_69 = SendLevel_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AudioMixer.SynthComponent.SetOutputToBusOnly
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// bool                           bInOutputToBusOnly_69          (Parm, ZeroConstructor, IsPlainOldData)

void SynthComponent::SetOutputToBusOnly(bool bInOutputToBusOnly_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioMixer.SynthComponent.SetOutputToBusOnly"));

	SynthComponent_SetOutputToBusOnly_Params params;
	params.bInOutputToBusOnly_69 = bInOutputToBusOnly_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AudioMixer.SynthComponent.SetLowPassFilterFrequency
// (Native, Public, BlueprintCallable)
// Parameters:
// float                          InLowPassFilterFrequency_69    (Parm, ZeroConstructor, IsPlainOldData)

void SynthComponent::SetLowPassFilterFrequency(float InLowPassFilterFrequency_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioMixer.SynthComponent.SetLowPassFilterFrequency"));

	SynthComponent_SetLowPassFilterFrequency_Params params;
	params.InLowPassFilterFrequency_69 = InLowPassFilterFrequency_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AudioMixer.SynthComponent.SetLowPassFilterEnabled
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// bool                           InLowPassFilterEnabled_69      (Parm, ZeroConstructor, IsPlainOldData)

void SynthComponent::SetLowPassFilterEnabled(bool InLowPassFilterEnabled_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioMixer.SynthComponent.SetLowPassFilterEnabled"));

	SynthComponent_SetLowPassFilterEnabled_Params params;
	params.InLowPassFilterEnabled_69 = InLowPassFilterEnabled_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AudioMixer.SynthComponent.IsPlaying
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool SynthComponent::IsPlaying()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioMixer.SynthComponent.IsPlaying"));

	SynthComponent_IsPlaying_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AudioMixer.SynthComponent.FadeOut
// (Final, Native, Public, BlueprintCallable, Const)
// Parameters:
// float                          FadeOutDuration_69             (Parm, ZeroConstructor, IsPlainOldData)
// float                          FadeVolumeLevel_69             (Parm, ZeroConstructor, IsPlainOldData)
// EAudioFaderCurve               FadeCurve_69                   (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void SynthComponent::FadeOut(float FadeOutDuration_69, float FadeVolumeLevel_69, EAudioFaderCurve FadeCurve_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioMixer.SynthComponent.FadeOut"));

	SynthComponent_FadeOut_Params params;
	params.FadeOutDuration_69 = FadeOutDuration_69;
	params.FadeVolumeLevel_69 = FadeVolumeLevel_69;
	params.FadeCurve_69 = FadeCurve_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AudioMixer.SynthComponent.FadeIn
// (Final, Native, Public, BlueprintCallable, Const)
// Parameters:
// float                          FadeInDuration_69              (Parm, ZeroConstructor, IsPlainOldData)
// float                          FadeVolumeLevel_69             (Parm, ZeroConstructor, IsPlainOldData)
// float                          StartTime_69                   (Parm, ZeroConstructor, IsPlainOldData)
// EAudioFaderCurve               FadeCurve_69                   (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void SynthComponent::FadeIn(float FadeInDuration_69, float FadeVolumeLevel_69, float StartTime_69, EAudioFaderCurve FadeCurve_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioMixer.SynthComponent.FadeIn"));

	SynthComponent_FadeIn_Params params;
	params.FadeInDuration_69 = FadeInDuration_69;
	params.FadeVolumeLevel_69 = FadeVolumeLevel_69;
	params.StartTime_69 = StartTime_69;
	params.FadeCurve_69 = FadeCurve_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AudioMixer.SynthComponent.AdjustVolume
// (Final, Native, Public, BlueprintCallable, Const)
// Parameters:
// float                          AdjustVolumeDuration_69        (Parm, ZeroConstructor, IsPlainOldData)
// float                          AdjustVolumeLevel_69           (Parm, ZeroConstructor, IsPlainOldData)
// EAudioFaderCurve               FadeCurve_69                   (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void SynthComponent::AdjustVolume(float AdjustVolumeDuration_69, float AdjustVolumeLevel_69, EAudioFaderCurve FadeCurve_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioMixer.SynthComponent.AdjustVolume"));

	SynthComponent_AdjustVolume_Params params;
	params.AdjustVolumeDuration_69 = AdjustVolumeDuration_69;
	params.AdjustVolumeLevel_69 = AdjustVolumeLevel_69;
	params.FadeCurve_69 = FadeCurve_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AudioMixer.AudioMixerBlueprintLibrary.TrimAudioCache
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// float                          InMegabytesToFree_69           (Parm, ZeroConstructor, IsPlainOldData)
// float                          ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

float AudioMixerBlueprintLibrary::STATIC_TrimAudioCache(float InMegabytesToFree_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioMixer.AudioMixerBlueprintLibrary.TrimAudioCache"));

	AudioMixerBlueprintLibrary_TrimAudioCache_Params params;
	params.InMegabytesToFree_69 = InMegabytesToFree_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AudioMixer.AudioMixerBlueprintLibrary.SwapAudioOutputDevice
// (Final, Native, Static, Public, HasOutParms, BlueprintCallable)
// Parameters:
// class Object_32759*            WorldContextObject_69          (ConstParm, Parm, ZeroConstructor)
// struct FString                 NewDeviceId_69                 (Parm, ZeroConstructor)
// struct FScriptDelegate         OnCompletedDeviceSwap_69       (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)

void AudioMixerBlueprintLibrary::STATIC_SwapAudioOutputDevice(class Object_32759* WorldContextObject_69, const struct FString& NewDeviceId_69, const struct FScriptDelegate& OnCompletedDeviceSwap_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioMixer.AudioMixerBlueprintLibrary.SwapAudioOutputDevice"));

	AudioMixerBlueprintLibrary_SwapAudioOutputDevice_Params params;
	params.WorldContextObject_69 = WorldContextObject_69;
	params.NewDeviceId_69 = NewDeviceId_69;
	params.OnCompletedDeviceSwap_69 = OnCompletedDeviceSwap_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AudioMixer.AudioMixerBlueprintLibrary.StopRecordingOutput
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// class Object_32759*            WorldContextObject_69          (ConstParm, Parm, ZeroConstructor)
// EAudioRecordingExportType      ExportType_69                  (Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 Name_69                        (Parm, ZeroConstructor)
// struct FString                 Path_69                        (Parm, ZeroConstructor)
// class SoundSubmix*             SubmixToRecord_69              (Parm, ZeroConstructor)
// class SoundWave*               ExistingSoundWaveToOverwrite_69 (Parm, ZeroConstructor)
// class SoundWave*               ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

class SoundWave* AudioMixerBlueprintLibrary::STATIC_StopRecordingOutput(class Object_32759* WorldContextObject_69, EAudioRecordingExportType ExportType_69, const struct FString& Name_69, const struct FString& Path_69, class SoundSubmix* SubmixToRecord_69, class SoundWave* ExistingSoundWaveToOverwrite_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioMixer.AudioMixerBlueprintLibrary.StopRecordingOutput"));

	AudioMixerBlueprintLibrary_StopRecordingOutput_Params params;
	params.WorldContextObject_69 = WorldContextObject_69;
	params.ExportType_69 = ExportType_69;
	params.Name_69 = Name_69;
	params.Path_69 = Path_69;
	params.SubmixToRecord_69 = SubmixToRecord_69;
	params.ExistingSoundWaveToOverwrite_69 = ExistingSoundWaveToOverwrite_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AudioMixer.AudioMixerBlueprintLibrary.StopAudioBus
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// class Object_32759*            WorldContextObject_69          (ConstParm, Parm, ZeroConstructor)
// class AudioBus*                AudioBus_69                    (Parm, ZeroConstructor)

void AudioMixerBlueprintLibrary::STATIC_StopAudioBus(class Object_32759* WorldContextObject_69, class AudioBus* AudioBus_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioMixer.AudioMixerBlueprintLibrary.StopAudioBus"));

	AudioMixerBlueprintLibrary_StopAudioBus_Params params;
	params.WorldContextObject_69 = WorldContextObject_69;
	params.AudioBus_69 = AudioBus_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AudioMixer.AudioMixerBlueprintLibrary.StopAnalyzingOutput
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// class Object_32759*            WorldContextObject_69          (ConstParm, Parm, ZeroConstructor)
// class SoundSubmix*             SubmixToStopAnalyzing_69       (Parm, ZeroConstructor)

void AudioMixerBlueprintLibrary::STATIC_StopAnalyzingOutput(class Object_32759* WorldContextObject_69, class SoundSubmix* SubmixToStopAnalyzing_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioMixer.AudioMixerBlueprintLibrary.StopAnalyzingOutput"));

	AudioMixerBlueprintLibrary_StopAnalyzingOutput_Params params;
	params.WorldContextObject_69 = WorldContextObject_69;
	params.SubmixToStopAnalyzing_69 = SubmixToStopAnalyzing_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AudioMixer.AudioMixerBlueprintLibrary.StartRecordingOutput
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// class Object_32759*            WorldContextObject_69          (ConstParm, Parm, ZeroConstructor)
// float                          ExpectedDuration_69            (Parm, ZeroConstructor, IsPlainOldData)
// class SoundSubmix*             SubmixToRecord_69              (Parm, ZeroConstructor)

void AudioMixerBlueprintLibrary::STATIC_StartRecordingOutput(class Object_32759* WorldContextObject_69, float ExpectedDuration_69, class SoundSubmix* SubmixToRecord_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioMixer.AudioMixerBlueprintLibrary.StartRecordingOutput"));

	AudioMixerBlueprintLibrary_StartRecordingOutput_Params params;
	params.WorldContextObject_69 = WorldContextObject_69;
	params.ExpectedDuration_69 = ExpectedDuration_69;
	params.SubmixToRecord_69 = SubmixToRecord_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AudioMixer.AudioMixerBlueprintLibrary.StartAudioBus
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// class Object_32759*            WorldContextObject_69          (ConstParm, Parm, ZeroConstructor)
// class AudioBus*                AudioBus_69                    (Parm, ZeroConstructor)

void AudioMixerBlueprintLibrary::STATIC_StartAudioBus(class Object_32759* WorldContextObject_69, class AudioBus* AudioBus_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioMixer.AudioMixerBlueprintLibrary.StartAudioBus"));

	AudioMixerBlueprintLibrary_StartAudioBus_Params params;
	params.WorldContextObject_69 = WorldContextObject_69;
	params.AudioBus_69 = AudioBus_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AudioMixer.AudioMixerBlueprintLibrary.StartAnalyzingOutput
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// class Object_32759*            WorldContextObject_69          (ConstParm, Parm, ZeroConstructor)
// class SoundSubmix*             SubmixToAnalyze_69             (Parm, ZeroConstructor)
// EFFTSize                       FFTSize_69                     (Parm, ZeroConstructor, IsPlainOldData)
// EFFTPeakInterpolationMethod    InterpolationMethod_69         (Parm, ZeroConstructor, IsPlainOldData)
// EFFTWindowType                 WindowType_69                  (Parm, ZeroConstructor, IsPlainOldData)
// float                          HopSize_69                     (Parm, ZeroConstructor, IsPlainOldData)
// EAudioSpectrumType             SpectrumType_69                (Parm, ZeroConstructor, IsPlainOldData)

void AudioMixerBlueprintLibrary::STATIC_StartAnalyzingOutput(class Object_32759* WorldContextObject_69, class SoundSubmix* SubmixToAnalyze_69, EFFTSize FFTSize_69, EFFTPeakInterpolationMethod InterpolationMethod_69, EFFTWindowType WindowType_69, float HopSize_69, EAudioSpectrumType SpectrumType_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioMixer.AudioMixerBlueprintLibrary.StartAnalyzingOutput"));

	AudioMixerBlueprintLibrary_StartAnalyzingOutput_Params params;
	params.WorldContextObject_69 = WorldContextObject_69;
	params.SubmixToAnalyze_69 = SubmixToAnalyze_69;
	params.FFTSize_69 = FFTSize_69;
	params.InterpolationMethod_69 = InterpolationMethod_69;
	params.WindowType_69 = WindowType_69;
	params.HopSize_69 = HopSize_69;
	params.SpectrumType_69 = SpectrumType_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AudioMixer.AudioMixerBlueprintLibrary.SetSubmixEffectChainOverride
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// class Object_32759*            WorldContextObject_69          (ConstParm, Parm, ZeroConstructor)
// class SoundSubmix*             SoundSubmix_69                 (Parm, ZeroConstructor)
// TArray<class SoundEffectSubmixPreset*> SubmixEffectPresetChain_69     (Parm, ZeroConstructor)
// float                          FadeTimeSec_69                 (Parm, ZeroConstructor, IsPlainOldData)

void AudioMixerBlueprintLibrary::STATIC_SetSubmixEffectChainOverride(class Object_32759* WorldContextObject_69, class SoundSubmix* SoundSubmix_69, TArray<class SoundEffectSubmixPreset*> SubmixEffectPresetChain_69, float FadeTimeSec_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioMixer.AudioMixerBlueprintLibrary.SetSubmixEffectChainOverride"));

	AudioMixerBlueprintLibrary_SetSubmixEffectChainOverride_Params params;
	params.WorldContextObject_69 = WorldContextObject_69;
	params.SoundSubmix_69 = SoundSubmix_69;
	params.SubmixEffectPresetChain_69 = SubmixEffectPresetChain_69;
	params.FadeTimeSec_69 = FadeTimeSec_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AudioMixer.AudioMixerBlueprintLibrary.SetBypassSourceEffectChainEntry
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// class Object_32759*            WorldContextObject_69          (ConstParm, Parm, ZeroConstructor)
// class SoundEffectSourcePresetChain* PresetChain_69                 (Parm, ZeroConstructor)
// int                            EntryIndex_69                  (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bBypassed_69                   (Parm, ZeroConstructor, IsPlainOldData)

void AudioMixerBlueprintLibrary::STATIC_SetBypassSourceEffectChainEntry(class Object_32759* WorldContextObject_69, class SoundEffectSourcePresetChain* PresetChain_69, int EntryIndex_69, bool bBypassed_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioMixer.AudioMixerBlueprintLibrary.SetBypassSourceEffectChainEntry"));

	AudioMixerBlueprintLibrary_SetBypassSourceEffectChainEntry_Params params;
	params.WorldContextObject_69 = WorldContextObject_69;
	params.PresetChain_69 = PresetChain_69;
	params.EntryIndex_69 = EntryIndex_69;
	params.bBypassed_69 = bBypassed_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AudioMixer.AudioMixerBlueprintLibrary.ResumeRecordingOutput
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// class Object_32759*            WorldContextObject_69          (ConstParm, Parm, ZeroConstructor)
// class SoundSubmix*             SubmixToPause_69               (Parm, ZeroConstructor)

void AudioMixerBlueprintLibrary::STATIC_ResumeRecordingOutput(class Object_32759* WorldContextObject_69, class SoundSubmix* SubmixToPause_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioMixer.AudioMixerBlueprintLibrary.ResumeRecordingOutput"));

	AudioMixerBlueprintLibrary_ResumeRecordingOutput_Params params;
	params.WorldContextObject_69 = WorldContextObject_69;
	params.SubmixToPause_69 = SubmixToPause_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AudioMixer.AudioMixerBlueprintLibrary.ReplaceSubmixEffect
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// class Object_32759*            WorldContextObject_69          (ConstParm, Parm, ZeroConstructor)
// class SoundSubmix*             InSoundSubmix_69               (Parm, ZeroConstructor)
// int                            SubmixChainIndex_69            (Parm, ZeroConstructor, IsPlainOldData)
// class SoundEffectSubmixPreset* SubmixEffectPreset_69          (Parm, ZeroConstructor)

void AudioMixerBlueprintLibrary::STATIC_ReplaceSubmixEffect(class Object_32759* WorldContextObject_69, class SoundSubmix* InSoundSubmix_69, int SubmixChainIndex_69, class SoundEffectSubmixPreset* SubmixEffectPreset_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioMixer.AudioMixerBlueprintLibrary.ReplaceSubmixEffect"));

	AudioMixerBlueprintLibrary_ReplaceSubmixEffect_Params params;
	params.WorldContextObject_69 = WorldContextObject_69;
	params.InSoundSubmix_69 = InSoundSubmix_69;
	params.SubmixChainIndex_69 = SubmixChainIndex_69;
	params.SubmixEffectPreset_69 = SubmixEffectPreset_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AudioMixer.AudioMixerBlueprintLibrary.ReplaceSoundEffectSubmix
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// class Object_32759*            WorldContextObject_69          (ConstParm, Parm, ZeroConstructor)
// class SoundSubmix*             InSoundSubmix_69               (Parm, ZeroConstructor)
// int                            SubmixChainIndex_69            (Parm, ZeroConstructor, IsPlainOldData)
// class SoundEffectSubmixPreset* SubmixEffectPreset_69          (Parm, ZeroConstructor)

void AudioMixerBlueprintLibrary::STATIC_ReplaceSoundEffectSubmix(class Object_32759* WorldContextObject_69, class SoundSubmix* InSoundSubmix_69, int SubmixChainIndex_69, class SoundEffectSubmixPreset* SubmixEffectPreset_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioMixer.AudioMixerBlueprintLibrary.ReplaceSoundEffectSubmix"));

	AudioMixerBlueprintLibrary_ReplaceSoundEffectSubmix_Params params;
	params.WorldContextObject_69 = WorldContextObject_69;
	params.InSoundSubmix_69 = InSoundSubmix_69;
	params.SubmixChainIndex_69 = SubmixChainIndex_69;
	params.SubmixEffectPreset_69 = SubmixEffectPreset_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AudioMixer.AudioMixerBlueprintLibrary.RemoveSubmixEffectPresetAtIndex
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// class Object_32759*            WorldContextObject_69          (ConstParm, Parm, ZeroConstructor)
// class SoundSubmix*             SoundSubmix_69                 (Parm, ZeroConstructor)
// int                            SubmixChainIndex_69            (Parm, ZeroConstructor, IsPlainOldData)

void AudioMixerBlueprintLibrary::STATIC_RemoveSubmixEffectPresetAtIndex(class Object_32759* WorldContextObject_69, class SoundSubmix* SoundSubmix_69, int SubmixChainIndex_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioMixer.AudioMixerBlueprintLibrary.RemoveSubmixEffectPresetAtIndex"));

	AudioMixerBlueprintLibrary_RemoveSubmixEffectPresetAtIndex_Params params;
	params.WorldContextObject_69 = WorldContextObject_69;
	params.SoundSubmix_69 = SoundSubmix_69;
	params.SubmixChainIndex_69 = SubmixChainIndex_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AudioMixer.AudioMixerBlueprintLibrary.RemoveSubmixEffectPreset
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// class Object_32759*            WorldContextObject_69          (ConstParm, Parm, ZeroConstructor)
// class SoundSubmix*             SoundSubmix_69                 (Parm, ZeroConstructor)
// class SoundEffectSubmixPreset* SubmixEffectPreset_69          (Parm, ZeroConstructor)

void AudioMixerBlueprintLibrary::STATIC_RemoveSubmixEffectPreset(class Object_32759* WorldContextObject_69, class SoundSubmix* SoundSubmix_69, class SoundEffectSubmixPreset* SubmixEffectPreset_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioMixer.AudioMixerBlueprintLibrary.RemoveSubmixEffectPreset"));

	AudioMixerBlueprintLibrary_RemoveSubmixEffectPreset_Params params;
	params.WorldContextObject_69 = WorldContextObject_69;
	params.SoundSubmix_69 = SoundSubmix_69;
	params.SubmixEffectPreset_69 = SubmixEffectPreset_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AudioMixer.AudioMixerBlueprintLibrary.RemoveSubmixEffectAtIndex
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// class Object_32759*            WorldContextObject_69          (ConstParm, Parm, ZeroConstructor)
// class SoundSubmix*             SoundSubmix_69                 (Parm, ZeroConstructor)
// int                            SubmixChainIndex_69            (Parm, ZeroConstructor, IsPlainOldData)

void AudioMixerBlueprintLibrary::STATIC_RemoveSubmixEffectAtIndex(class Object_32759* WorldContextObject_69, class SoundSubmix* SoundSubmix_69, int SubmixChainIndex_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioMixer.AudioMixerBlueprintLibrary.RemoveSubmixEffectAtIndex"));

	AudioMixerBlueprintLibrary_RemoveSubmixEffectAtIndex_Params params;
	params.WorldContextObject_69 = WorldContextObject_69;
	params.SoundSubmix_69 = SoundSubmix_69;
	params.SubmixChainIndex_69 = SubmixChainIndex_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AudioMixer.AudioMixerBlueprintLibrary.RemoveSubmixEffect
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// class Object_32759*            WorldContextObject_69          (ConstParm, Parm, ZeroConstructor)
// class SoundSubmix*             SoundSubmix_69                 (Parm, ZeroConstructor)
// class SoundEffectSubmixPreset* SubmixEffectPreset_69          (Parm, ZeroConstructor)

void AudioMixerBlueprintLibrary::STATIC_RemoveSubmixEffect(class Object_32759* WorldContextObject_69, class SoundSubmix* SoundSubmix_69, class SoundEffectSubmixPreset* SubmixEffectPreset_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioMixer.AudioMixerBlueprintLibrary.RemoveSubmixEffect"));

	AudioMixerBlueprintLibrary_RemoveSubmixEffect_Params params;
	params.WorldContextObject_69 = WorldContextObject_69;
	params.SoundSubmix_69 = SoundSubmix_69;
	params.SubmixEffectPreset_69 = SubmixEffectPreset_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AudioMixer.AudioMixerBlueprintLibrary.RemoveSourceEffectFromPresetChain
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// class Object_32759*            WorldContextObject_69          (ConstParm, Parm, ZeroConstructor)
// class SoundEffectSourcePresetChain* PresetChain_69                 (Parm, ZeroConstructor)
// int                            EntryIndex_69                  (Parm, ZeroConstructor, IsPlainOldData)

void AudioMixerBlueprintLibrary::STATIC_RemoveSourceEffectFromPresetChain(class Object_32759* WorldContextObject_69, class SoundEffectSourcePresetChain* PresetChain_69, int EntryIndex_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioMixer.AudioMixerBlueprintLibrary.RemoveSourceEffectFromPresetChain"));

	AudioMixerBlueprintLibrary_RemoveSourceEffectFromPresetChain_Params params;
	params.WorldContextObject_69 = WorldContextObject_69;
	params.PresetChain_69 = PresetChain_69;
	params.EntryIndex_69 = EntryIndex_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AudioMixer.AudioMixerBlueprintLibrary.RemoveMasterSubmixEffect
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// class Object_32759*            WorldContextObject_69          (ConstParm, Parm, ZeroConstructor)
// class SoundEffectSubmixPreset* SubmixEffectPreset_69          (Parm, ZeroConstructor)

void AudioMixerBlueprintLibrary::STATIC_RemoveMasterSubmixEffect(class Object_32759* WorldContextObject_69, class SoundEffectSubmixPreset* SubmixEffectPreset_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioMixer.AudioMixerBlueprintLibrary.RemoveMasterSubmixEffect"));

	AudioMixerBlueprintLibrary_RemoveMasterSubmixEffect_Params params;
	params.WorldContextObject_69 = WorldContextObject_69;
	params.SubmixEffectPreset_69 = SubmixEffectPreset_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AudioMixer.AudioMixerBlueprintLibrary.PrimeSoundForPlayback
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// class SoundWave*               SoundWave_69                   (Parm, ZeroConstructor)
// struct FScriptDelegate         OnLoadCompletion_69            (ConstParm, Parm, ZeroConstructor)

void AudioMixerBlueprintLibrary::STATIC_PrimeSoundForPlayback(class SoundWave* SoundWave_69, const struct FScriptDelegate& OnLoadCompletion_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioMixer.AudioMixerBlueprintLibrary.PrimeSoundForPlayback"));

	AudioMixerBlueprintLibrary_PrimeSoundForPlayback_Params params;
	params.SoundWave_69 = SoundWave_69;
	params.OnLoadCompletion_69 = OnLoadCompletion_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AudioMixer.AudioMixerBlueprintLibrary.PrimeSoundCueForPlayback
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// class SoundCue*                SoundCue_69                    (Parm, ZeroConstructor)

void AudioMixerBlueprintLibrary::STATIC_PrimeSoundCueForPlayback(class SoundCue* SoundCue_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioMixer.AudioMixerBlueprintLibrary.PrimeSoundCueForPlayback"));

	AudioMixerBlueprintLibrary_PrimeSoundCueForPlayback_Params params;
	params.SoundCue_69 = SoundCue_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AudioMixer.AudioMixerBlueprintLibrary.PauseRecordingOutput
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// class Object_32759*            WorldContextObject_69          (ConstParm, Parm, ZeroConstructor)
// class SoundSubmix*             SubmixToPause_69               (Parm, ZeroConstructor)

void AudioMixerBlueprintLibrary::STATIC_PauseRecordingOutput(class Object_32759* WorldContextObject_69, class SoundSubmix* SubmixToPause_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioMixer.AudioMixerBlueprintLibrary.PauseRecordingOutput"));

	AudioMixerBlueprintLibrary_PauseRecordingOutput_Params params;
	params.WorldContextObject_69 = WorldContextObject_69;
	params.SubmixToPause_69 = SubmixToPause_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AudioMixer.AudioMixerBlueprintLibrary.MakePresetSpectralAnalysisBandSettings
// (Final, Native, Static, Public, BlueprintCallable, BlueprintPure)
// Parameters:
// EAudioSpectrumBandPresetType   InBandPresetType_69            (Parm, ZeroConstructor, IsPlainOldData)
// int                            InNumBands_69                  (Parm, ZeroConstructor, IsPlainOldData)
// int                            InAttackTimeMsec_69            (Parm, ZeroConstructor, IsPlainOldData)
// int                            InReleaseTimeMsec_69           (Parm, ZeroConstructor, IsPlainOldData)
// TArray<struct FSoundSubmixSpectralAnalysisBandSettings> ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

TArray<struct FSoundSubmixSpectralAnalysisBandSettings> AudioMixerBlueprintLibrary::STATIC_MakePresetSpectralAnalysisBandSettings(EAudioSpectrumBandPresetType InBandPresetType_69, int InNumBands_69, int InAttackTimeMsec_69, int InReleaseTimeMsec_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioMixer.AudioMixerBlueprintLibrary.MakePresetSpectralAnalysisBandSettings"));

	AudioMixerBlueprintLibrary_MakePresetSpectralAnalysisBandSettings_Params params;
	params.InBandPresetType_69 = InBandPresetType_69;
	params.InNumBands_69 = InNumBands_69;
	params.InAttackTimeMsec_69 = InAttackTimeMsec_69;
	params.InReleaseTimeMsec_69 = InReleaseTimeMsec_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AudioMixer.AudioMixerBlueprintLibrary.MakeMusicalSpectralAnalysisBandSettings
// (Final, Native, Static, Public, BlueprintCallable, BlueprintPure)
// Parameters:
// int                            InNumSemitones_69              (Parm, ZeroConstructor, IsPlainOldData)
// EMusicalNoteName               InStartingMusicalNote_69       (Parm, ZeroConstructor, IsPlainOldData)
// int                            InStartingOctave_69            (Parm, ZeroConstructor, IsPlainOldData)
// int                            InAttackTimeMsec_69            (Parm, ZeroConstructor, IsPlainOldData)
// int                            InReleaseTimeMsec_69           (Parm, ZeroConstructor, IsPlainOldData)
// TArray<struct FSoundSubmixSpectralAnalysisBandSettings> ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

TArray<struct FSoundSubmixSpectralAnalysisBandSettings> AudioMixerBlueprintLibrary::STATIC_MakeMusicalSpectralAnalysisBandSettings(int InNumSemitones_69, EMusicalNoteName InStartingMusicalNote_69, int InStartingOctave_69, int InAttackTimeMsec_69, int InReleaseTimeMsec_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioMixer.AudioMixerBlueprintLibrary.MakeMusicalSpectralAnalysisBandSettings"));

	AudioMixerBlueprintLibrary_MakeMusicalSpectralAnalysisBandSettings_Params params;
	params.InNumSemitones_69 = InNumSemitones_69;
	params.InStartingMusicalNote_69 = InStartingMusicalNote_69;
	params.InStartingOctave_69 = InStartingOctave_69;
	params.InAttackTimeMsec_69 = InAttackTimeMsec_69;
	params.InReleaseTimeMsec_69 = InReleaseTimeMsec_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AudioMixer.AudioMixerBlueprintLibrary.MakeFullSpectrumSpectralAnalysisBandSettings
// (Final, Native, Static, Public, BlueprintCallable, BlueprintPure)
// Parameters:
// int                            InNumBands_69                  (Parm, ZeroConstructor, IsPlainOldData)
// float                          InMinimumFrequency_69          (Parm, ZeroConstructor, IsPlainOldData)
// float                          InMaximumFrequency_69          (Parm, ZeroConstructor, IsPlainOldData)
// int                            InAttackTimeMsec_69            (Parm, ZeroConstructor, IsPlainOldData)
// int                            InReleaseTimeMsec_69           (Parm, ZeroConstructor, IsPlainOldData)
// TArray<struct FSoundSubmixSpectralAnalysisBandSettings> ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

TArray<struct FSoundSubmixSpectralAnalysisBandSettings> AudioMixerBlueprintLibrary::STATIC_MakeFullSpectrumSpectralAnalysisBandSettings(int InNumBands_69, float InMinimumFrequency_69, float InMaximumFrequency_69, int InAttackTimeMsec_69, int InReleaseTimeMsec_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioMixer.AudioMixerBlueprintLibrary.MakeFullSpectrumSpectralAnalysisBandSettings"));

	AudioMixerBlueprintLibrary_MakeFullSpectrumSpectralAnalysisBandSettings_Params params;
	params.InNumBands_69 = InNumBands_69;
	params.InMinimumFrequency_69 = InMinimumFrequency_69;
	params.InMaximumFrequency_69 = InMaximumFrequency_69;
	params.InAttackTimeMsec_69 = InAttackTimeMsec_69;
	params.InReleaseTimeMsec_69 = InReleaseTimeMsec_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AudioMixer.AudioMixerBlueprintLibrary.IsAudioBusActive
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// class Object_32759*            WorldContextObject_69          (ConstParm, Parm, ZeroConstructor)
// class AudioBus*                AudioBus_69                    (Parm, ZeroConstructor)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool AudioMixerBlueprintLibrary::STATIC_IsAudioBusActive(class Object_32759* WorldContextObject_69, class AudioBus* AudioBus_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioMixer.AudioMixerBlueprintLibrary.IsAudioBusActive"));

	AudioMixerBlueprintLibrary_IsAudioBusActive_Params params;
	params.WorldContextObject_69 = WorldContextObject_69;
	params.AudioBus_69 = AudioBus_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AudioMixer.AudioMixerBlueprintLibrary.GetPhaseForFrequencies
// (Final, Native, Static, Public, HasOutParms, BlueprintCallable)
// Parameters:
// class Object_32759*            WorldContextObject_69          (ConstParm, Parm, ZeroConstructor)
// TArray<float>                  Frequencies_69                 (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
// TArray<float>                  Phases_69                      (Parm, OutParm, ZeroConstructor)
// class SoundSubmix*             SubmixToAnalyze_69             (Parm, ZeroConstructor)

void AudioMixerBlueprintLibrary::STATIC_GetPhaseForFrequencies(class Object_32759* WorldContextObject_69, TArray<float> Frequencies_69, class SoundSubmix* SubmixToAnalyze_69, TArray<float>* Phases_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioMixer.AudioMixerBlueprintLibrary.GetPhaseForFrequencies"));

	AudioMixerBlueprintLibrary_GetPhaseForFrequencies_Params params;
	params.WorldContextObject_69 = WorldContextObject_69;
	params.Frequencies_69 = Frequencies_69;
	params.SubmixToAnalyze_69 = SubmixToAnalyze_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (Phases_69 != nullptr)
		*Phases_69 = params.Phases_69;
}


// Function AudioMixer.AudioMixerBlueprintLibrary.GetNumberOfEntriesInSourceEffectChain
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// class Object_32759*            WorldContextObject_69          (ConstParm, Parm, ZeroConstructor)
// class SoundEffectSourcePresetChain* PresetChain_69                 (Parm, ZeroConstructor)
// int                            ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int AudioMixerBlueprintLibrary::STATIC_GetNumberOfEntriesInSourceEffectChain(class Object_32759* WorldContextObject_69, class SoundEffectSourcePresetChain* PresetChain_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioMixer.AudioMixerBlueprintLibrary.GetNumberOfEntriesInSourceEffectChain"));

	AudioMixerBlueprintLibrary_GetNumberOfEntriesInSourceEffectChain_Params params;
	params.WorldContextObject_69 = WorldContextObject_69;
	params.PresetChain_69 = PresetChain_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AudioMixer.AudioMixerBlueprintLibrary.GetMagnitudeForFrequencies
// (Final, Native, Static, Public, HasOutParms, BlueprintCallable)
// Parameters:
// class Object_32759*            WorldContextObject_69          (ConstParm, Parm, ZeroConstructor)
// TArray<float>                  Frequencies_69                 (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
// TArray<float>                  Magnitudes_69                  (Parm, OutParm, ZeroConstructor)
// class SoundSubmix*             SubmixToAnalyze_69             (Parm, ZeroConstructor)

void AudioMixerBlueprintLibrary::STATIC_GetMagnitudeForFrequencies(class Object_32759* WorldContextObject_69, TArray<float> Frequencies_69, class SoundSubmix* SubmixToAnalyze_69, TArray<float>* Magnitudes_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioMixer.AudioMixerBlueprintLibrary.GetMagnitudeForFrequencies"));

	AudioMixerBlueprintLibrary_GetMagnitudeForFrequencies_Params params;
	params.WorldContextObject_69 = WorldContextObject_69;
	params.Frequencies_69 = Frequencies_69;
	params.SubmixToAnalyze_69 = SubmixToAnalyze_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (Magnitudes_69 != nullptr)
		*Magnitudes_69 = params.Magnitudes_69;
}


// Function AudioMixer.AudioMixerBlueprintLibrary.GetCurrentAudioOutputDeviceName
// (Final, Native, Static, Public, HasOutParms, BlueprintCallable)
// Parameters:
// class Object_32759*            WorldContextObject_69          (ConstParm, Parm, ZeroConstructor)
// struct FScriptDelegate         OnObtainCurrentDeviceEvent_69  (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)

void AudioMixerBlueprintLibrary::STATIC_GetCurrentAudioOutputDeviceName(class Object_32759* WorldContextObject_69, const struct FScriptDelegate& OnObtainCurrentDeviceEvent_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioMixer.AudioMixerBlueprintLibrary.GetCurrentAudioOutputDeviceName"));

	AudioMixerBlueprintLibrary_GetCurrentAudioOutputDeviceName_Params params;
	params.WorldContextObject_69 = WorldContextObject_69;
	params.OnObtainCurrentDeviceEvent_69 = OnObtainCurrentDeviceEvent_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AudioMixer.AudioMixerBlueprintLibrary.GetAvailableAudioOutputDevices
// (Final, Native, Static, Public, HasOutParms, BlueprintCallable)
// Parameters:
// class Object_32759*            WorldContextObject_69          (ConstParm, Parm, ZeroConstructor)
// struct FScriptDelegate         OnObtainDevicesEvent_69        (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)

void AudioMixerBlueprintLibrary::STATIC_GetAvailableAudioOutputDevices(class Object_32759* WorldContextObject_69, const struct FScriptDelegate& OnObtainDevicesEvent_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioMixer.AudioMixerBlueprintLibrary.GetAvailableAudioOutputDevices"));

	AudioMixerBlueprintLibrary_GetAvailableAudioOutputDevices_Params params;
	params.WorldContextObject_69 = WorldContextObject_69;
	params.OnObtainDevicesEvent_69 = OnObtainDevicesEvent_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AudioMixer.AudioMixerBlueprintLibrary.Conv_AudioOutputDeviceInfoToString
// (Final, Native, Static, Public, HasOutParms, BlueprintCallable, BlueprintPure)
// Parameters:
// struct FAudioOutputDeviceInfo  Info_69                        (ConstParm, Parm, OutParm, ReferenceParm)
// struct FString                 ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString AudioMixerBlueprintLibrary::STATIC_Conv_AudioOutputDeviceInfoToString(const struct FAudioOutputDeviceInfo& Info_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioMixer.AudioMixerBlueprintLibrary.Conv_AudioOutputDeviceInfoToString"));

	AudioMixerBlueprintLibrary_Conv_AudioOutputDeviceInfoToString_Params params;
	params.Info_69 = Info_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AudioMixer.AudioMixerBlueprintLibrary.ClearSubmixEffects
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// class Object_32759*            WorldContextObject_69          (ConstParm, Parm, ZeroConstructor)
// class SoundSubmix*             SoundSubmix_69                 (Parm, ZeroConstructor)

void AudioMixerBlueprintLibrary::STATIC_ClearSubmixEffects(class Object_32759* WorldContextObject_69, class SoundSubmix* SoundSubmix_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioMixer.AudioMixerBlueprintLibrary.ClearSubmixEffects"));

	AudioMixerBlueprintLibrary_ClearSubmixEffects_Params params;
	params.WorldContextObject_69 = WorldContextObject_69;
	params.SoundSubmix_69 = SoundSubmix_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AudioMixer.AudioMixerBlueprintLibrary.ClearSubmixEffectChainOverride
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// class Object_32759*            WorldContextObject_69          (ConstParm, Parm, ZeroConstructor)
// class SoundSubmix*             SoundSubmix_69                 (Parm, ZeroConstructor)
// float                          FadeTimeSec_69                 (Parm, ZeroConstructor, IsPlainOldData)

void AudioMixerBlueprintLibrary::STATIC_ClearSubmixEffectChainOverride(class Object_32759* WorldContextObject_69, class SoundSubmix* SoundSubmix_69, float FadeTimeSec_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioMixer.AudioMixerBlueprintLibrary.ClearSubmixEffectChainOverride"));

	AudioMixerBlueprintLibrary_ClearSubmixEffectChainOverride_Params params;
	params.WorldContextObject_69 = WorldContextObject_69;
	params.SoundSubmix_69 = SoundSubmix_69;
	params.FadeTimeSec_69 = FadeTimeSec_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AudioMixer.AudioMixerBlueprintLibrary.ClearMasterSubmixEffects
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// class Object_32759*            WorldContextObject_69          (ConstParm, Parm, ZeroConstructor)

void AudioMixerBlueprintLibrary::STATIC_ClearMasterSubmixEffects(class Object_32759* WorldContextObject_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioMixer.AudioMixerBlueprintLibrary.ClearMasterSubmixEffects"));

	AudioMixerBlueprintLibrary_ClearMasterSubmixEffects_Params params;
	params.WorldContextObject_69 = WorldContextObject_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AudioMixer.AudioMixerBlueprintLibrary.AddSubmixEffect
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// class Object_32759*            WorldContextObject_69          (ConstParm, Parm, ZeroConstructor)
// class SoundSubmix*             SoundSubmix_69                 (Parm, ZeroConstructor)
// class SoundEffectSubmixPreset* SubmixEffectPreset_69          (Parm, ZeroConstructor)
// int                            ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int AudioMixerBlueprintLibrary::STATIC_AddSubmixEffect(class Object_32759* WorldContextObject_69, class SoundSubmix* SoundSubmix_69, class SoundEffectSubmixPreset* SubmixEffectPreset_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioMixer.AudioMixerBlueprintLibrary.AddSubmixEffect"));

	AudioMixerBlueprintLibrary_AddSubmixEffect_Params params;
	params.WorldContextObject_69 = WorldContextObject_69;
	params.SoundSubmix_69 = SoundSubmix_69;
	params.SubmixEffectPreset_69 = SubmixEffectPreset_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AudioMixer.AudioMixerBlueprintLibrary.AddSourceEffectToPresetChain
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// class Object_32759*            WorldContextObject_69          (ConstParm, Parm, ZeroConstructor)
// class SoundEffectSourcePresetChain* PresetChain_69                 (Parm, ZeroConstructor)
// struct FSourceEffectChainEntry Entry_69                       (Parm)

void AudioMixerBlueprintLibrary::STATIC_AddSourceEffectToPresetChain(class Object_32759* WorldContextObject_69, class SoundEffectSourcePresetChain* PresetChain_69, const struct FSourceEffectChainEntry& Entry_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioMixer.AudioMixerBlueprintLibrary.AddSourceEffectToPresetChain"));

	AudioMixerBlueprintLibrary_AddSourceEffectToPresetChain_Params params;
	params.WorldContextObject_69 = WorldContextObject_69;
	params.PresetChain_69 = PresetChain_69;
	params.Entry_69 = Entry_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AudioMixer.AudioMixerBlueprintLibrary.AddMasterSubmixEffect
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// class Object_32759*            WorldContextObject_69          (ConstParm, Parm, ZeroConstructor)
// class SoundEffectSubmixPreset* SubmixEffectPreset_69          (Parm, ZeroConstructor)

void AudioMixerBlueprintLibrary::STATIC_AddMasterSubmixEffect(class Object_32759* WorldContextObject_69, class SoundEffectSubmixPreset* SubmixEffectPreset_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioMixer.AudioMixerBlueprintLibrary.AddMasterSubmixEffect"));

	AudioMixerBlueprintLibrary_AddMasterSubmixEffect_Params params;
	params.WorldContextObject_69 = WorldContextObject_69;
	params.SubmixEffectPreset_69 = SubmixEffectPreset_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AudioMixer.SubmixEffectDynamicsProcessorPreset.SetSettings
// (Final, Native, Public, HasOutParms, BlueprintCallable)
// Parameters:
// struct FSubmixEffectDynamicsProcessorSettings Settings_69                    (ConstParm, Parm, OutParm, ReferenceParm)

void SubmixEffectDynamicsProcessorPreset::SetSettings(const struct FSubmixEffectDynamicsProcessorSettings& Settings_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioMixer.SubmixEffectDynamicsProcessorPreset.SetSettings"));

	SubmixEffectDynamicsProcessorPreset_SetSettings_Params params;
	params.Settings_69 = Settings_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AudioMixer.SubmixEffectDynamicsProcessorPreset.SetExternalSubmix
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// class SoundSubmix*             Submix_69                      (Parm, ZeroConstructor)

void SubmixEffectDynamicsProcessorPreset::SetExternalSubmix(class SoundSubmix* Submix_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioMixer.SubmixEffectDynamicsProcessorPreset.SetExternalSubmix"));

	SubmixEffectDynamicsProcessorPreset_SetExternalSubmix_Params params;
	params.Submix_69 = Submix_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AudioMixer.SubmixEffectDynamicsProcessorPreset.SetAudioBus
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// class AudioBus*                AudioBus_69                    (Parm, ZeroConstructor)

void SubmixEffectDynamicsProcessorPreset::SetAudioBus(class AudioBus* AudioBus_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioMixer.SubmixEffectDynamicsProcessorPreset.SetAudioBus"));

	SubmixEffectDynamicsProcessorPreset_SetAudioBus_Params params;
	params.AudioBus_69 = AudioBus_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AudioMixer.SubmixEffectDynamicsProcessorPreset.ResetKey
// (Final, Native, Public, BlueprintCallable)

void SubmixEffectDynamicsProcessorPreset::ResetKey()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioMixer.SubmixEffectDynamicsProcessorPreset.ResetKey"));

	SubmixEffectDynamicsProcessorPreset_ResetKey_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AudioMixer.SubmixEffectSubmixEQPreset.SetSettings
// (Final, Native, Public, HasOutParms, BlueprintCallable)
// Parameters:
// struct FSubmixEffectSubmixEQSettings InSettings_69                  (ConstParm, Parm, OutParm, ReferenceParm)

void SubmixEffectSubmixEQPreset::SetSettings(const struct FSubmixEffectSubmixEQSettings& InSettings_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioMixer.SubmixEffectSubmixEQPreset.SetSettings"));

	SubmixEffectSubmixEQPreset_SetSettings_Params params;
	params.InSettings_69 = InSettings_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AudioMixer.SubmixEffectReverbPreset.SetSettingsWithReverbEffect
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// class ReverbEffect*            InReverbEffect_69              (ConstParm, Parm, ZeroConstructor)
// float                          WetLevel_69                    (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// float                          DryLevel_69                    (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void SubmixEffectReverbPreset::SetSettingsWithReverbEffect(class ReverbEffect* InReverbEffect_69, float WetLevel_69, float DryLevel_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioMixer.SubmixEffectReverbPreset.SetSettingsWithReverbEffect"));

	SubmixEffectReverbPreset_SetSettingsWithReverbEffect_Params params;
	params.InReverbEffect_69 = InReverbEffect_69;
	params.WetLevel_69 = WetLevel_69;
	params.DryLevel_69 = DryLevel_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AudioMixer.SubmixEffectReverbPreset.SetSettings
// (Final, Native, Public, HasOutParms, BlueprintCallable)
// Parameters:
// struct FSubmixEffectReverbSettings InSettings_69                  (ConstParm, Parm, OutParm, ReferenceParm)

void SubmixEffectReverbPreset::SetSettings(const struct FSubmixEffectReverbSettings& InSettings_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioMixer.SubmixEffectReverbPreset.SetSettings"));

	SubmixEffectReverbPreset_SetSettings_Params params;
	params.InSettings_69 = InSettings_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AudioMixer.QuartzClockHandle.UnsubscribeFromTimeDivision
// (Final, Native, Public, HasOutParms, BlueprintCallable)
// Parameters:
// class Object_32759*            WorldContextObject_69          (ConstParm, Parm, ZeroConstructor)
// EQuartzCommandQuantization     InQuantizationBoundary_69      (Parm, ZeroConstructor, IsPlainOldData)
// class QuartzClockHandle*       ClockHandle_69                 (Parm, OutParm, ZeroConstructor)

void QuartzClockHandle::UnsubscribeFromTimeDivision(class Object_32759* WorldContextObject_69, EQuartzCommandQuantization InQuantizationBoundary_69, class QuartzClockHandle** ClockHandle_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioMixer.QuartzClockHandle.UnsubscribeFromTimeDivision"));

	QuartzClockHandle_UnsubscribeFromTimeDivision_Params params;
	params.WorldContextObject_69 = WorldContextObject_69;
	params.InQuantizationBoundary_69 = InQuantizationBoundary_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (ClockHandle_69 != nullptr)
		*ClockHandle_69 = params.ClockHandle_69;
}


// Function AudioMixer.QuartzClockHandle.UnsubscribeFromAllTimeDivisions
// (Final, Native, Public, HasOutParms, BlueprintCallable)
// Parameters:
// class Object_32759*            WorldContextObject_69          (ConstParm, Parm, ZeroConstructor)
// class QuartzClockHandle*       ClockHandle_69                 (Parm, OutParm, ZeroConstructor)

void QuartzClockHandle::UnsubscribeFromAllTimeDivisions(class Object_32759* WorldContextObject_69, class QuartzClockHandle** ClockHandle_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioMixer.QuartzClockHandle.UnsubscribeFromAllTimeDivisions"));

	QuartzClockHandle_UnsubscribeFromAllTimeDivisions_Params params;
	params.WorldContextObject_69 = WorldContextObject_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (ClockHandle_69 != nullptr)
		*ClockHandle_69 = params.ClockHandle_69;
}


// Function AudioMixer.QuartzClockHandle.SubscribeToQuantizationEvent
// (Final, Native, Public, HasOutParms, BlueprintCallable)
// Parameters:
// class Object_32759*            WorldContextObject_69          (ConstParm, Parm, ZeroConstructor)
// EQuartzCommandQuantization     InQuantizationBoundary_69      (Parm, ZeroConstructor, IsPlainOldData)
// struct FScriptDelegate         OnQuantizationEvent_69         (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
// class QuartzClockHandle*       ClockHandle_69                 (Parm, OutParm, ZeroConstructor)

void QuartzClockHandle::SubscribeToQuantizationEvent(class Object_32759* WorldContextObject_69, EQuartzCommandQuantization InQuantizationBoundary_69, const struct FScriptDelegate& OnQuantizationEvent_69, class QuartzClockHandle** ClockHandle_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioMixer.QuartzClockHandle.SubscribeToQuantizationEvent"));

	QuartzClockHandle_SubscribeToQuantizationEvent_Params params;
	params.WorldContextObject_69 = WorldContextObject_69;
	params.InQuantizationBoundary_69 = InQuantizationBoundary_69;
	params.OnQuantizationEvent_69 = OnQuantizationEvent_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (ClockHandle_69 != nullptr)
		*ClockHandle_69 = params.ClockHandle_69;
}


// Function AudioMixer.QuartzClockHandle.SubscribeToAllQuantizationEvents
// (Final, Native, Public, HasOutParms, BlueprintCallable)
// Parameters:
// class Object_32759*            WorldContextObject_69          (ConstParm, Parm, ZeroConstructor)
// struct FScriptDelegate         OnQuantizationEvent_69         (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
// class QuartzClockHandle*       ClockHandle_69                 (Parm, OutParm, ZeroConstructor)

void QuartzClockHandle::SubscribeToAllQuantizationEvents(class Object_32759* WorldContextObject_69, const struct FScriptDelegate& OnQuantizationEvent_69, class QuartzClockHandle** ClockHandle_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioMixer.QuartzClockHandle.SubscribeToAllQuantizationEvents"));

	QuartzClockHandle_SubscribeToAllQuantizationEvents_Params params;
	params.WorldContextObject_69 = WorldContextObject_69;
	params.OnQuantizationEvent_69 = OnQuantizationEvent_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (ClockHandle_69 != nullptr)
		*ClockHandle_69 = params.ClockHandle_69;
}


// Function AudioMixer.QuartzClockHandle.StopClock
// (Final, Native, Public, HasOutParms, BlueprintCallable)
// Parameters:
// class Object_32759*            WorldContextObject_69          (ConstParm, Parm, ZeroConstructor)
// bool                           CancelPendingEvents_69         (Parm, ZeroConstructor, IsPlainOldData)
// class QuartzClockHandle*       ClockHandle_69                 (Parm, OutParm, ZeroConstructor)

void QuartzClockHandle::StopClock(class Object_32759* WorldContextObject_69, bool CancelPendingEvents_69, class QuartzClockHandle** ClockHandle_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioMixer.QuartzClockHandle.StopClock"));

	QuartzClockHandle_StopClock_Params params;
	params.WorldContextObject_69 = WorldContextObject_69;
	params.CancelPendingEvents_69 = CancelPendingEvents_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (ClockHandle_69 != nullptr)
		*ClockHandle_69 = params.ClockHandle_69;
}


// Function AudioMixer.QuartzClockHandle.StartOtherClock
// (Final, Native, Public, HasOutParms, BlueprintCallable)
// Parameters:
// class Object_32759*            WorldContextObject_69          (ConstParm, Parm, ZeroConstructor)
// struct FName                   OtherClockName_69              (Parm, ZeroConstructor, IsPlainOldData)
// struct FQuartzQuantizationBoundary InQuantizationBoundary_69      (Parm)
// struct FScriptDelegate         InDelegate_69                  (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)

void QuartzClockHandle::StartOtherClock(class Object_32759* WorldContextObject_69, const struct FName& OtherClockName_69, const struct FQuartzQuantizationBoundary& InQuantizationBoundary_69, const struct FScriptDelegate& InDelegate_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioMixer.QuartzClockHandle.StartOtherClock"));

	QuartzClockHandle_StartOtherClock_Params params;
	params.WorldContextObject_69 = WorldContextObject_69;
	params.OtherClockName_69 = OtherClockName_69;
	params.InQuantizationBoundary_69 = InQuantizationBoundary_69;
	params.InDelegate_69 = InDelegate_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AudioMixer.QuartzClockHandle.StartClock
// (Final, Native, Public, HasOutParms, BlueprintCallable)
// Parameters:
// class Object_32759*            WorldContextObject_69          (ConstParm, Parm, ZeroConstructor)
// class QuartzClockHandle*       ClockHandle_69                 (Parm, OutParm, ZeroConstructor)

void QuartzClockHandle::StartClock(class Object_32759* WorldContextObject_69, class QuartzClockHandle** ClockHandle_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioMixer.QuartzClockHandle.StartClock"));

	QuartzClockHandle_StartClock_Params params;
	params.WorldContextObject_69 = WorldContextObject_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (ClockHandle_69 != nullptr)
		*ClockHandle_69 = params.ClockHandle_69;
}


// Function AudioMixer.QuartzClockHandle.SetTicksPerSecond
// (Final, Native, Public, HasOutParms, BlueprintCallable)
// Parameters:
// class Object_32759*            WorldContextObject_69          (ConstParm, Parm, ZeroConstructor)
// struct FQuartzQuantizationBoundary QuantizationBoundary_69        (ConstParm, Parm, OutParm, ReferenceParm)
// struct FScriptDelegate         Delegate_69                    (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
// class QuartzClockHandle*       ClockHandle_69                 (Parm, OutParm, ZeroConstructor)
// float                          TicksPerSecond_69              (Parm, ZeroConstructor, IsPlainOldData)

void QuartzClockHandle::SetTicksPerSecond(class Object_32759* WorldContextObject_69, const struct FQuartzQuantizationBoundary& QuantizationBoundary_69, const struct FScriptDelegate& Delegate_69, float TicksPerSecond_69, class QuartzClockHandle** ClockHandle_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioMixer.QuartzClockHandle.SetTicksPerSecond"));

	QuartzClockHandle_SetTicksPerSecond_Params params;
	params.WorldContextObject_69 = WorldContextObject_69;
	params.QuantizationBoundary_69 = QuantizationBoundary_69;
	params.Delegate_69 = Delegate_69;
	params.TicksPerSecond_69 = TicksPerSecond_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (ClockHandle_69 != nullptr)
		*ClockHandle_69 = params.ClockHandle_69;
}


// Function AudioMixer.QuartzClockHandle.SetThirtySecondNotesPerMinute
// (Final, Native, Public, HasOutParms, BlueprintCallable)
// Parameters:
// class Object_32759*            WorldContextObject_69          (ConstParm, Parm, ZeroConstructor)
// struct FQuartzQuantizationBoundary QuantizationBoundary_69        (ConstParm, Parm, OutParm, ReferenceParm)
// struct FScriptDelegate         Delegate_69                    (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
// class QuartzClockHandle*       ClockHandle_69                 (Parm, OutParm, ZeroConstructor)
// float                          ThirtySecondsNotesPerMinute_69 (Parm, ZeroConstructor, IsPlainOldData)

void QuartzClockHandle::SetThirtySecondNotesPerMinute(class Object_32759* WorldContextObject_69, const struct FQuartzQuantizationBoundary& QuantizationBoundary_69, const struct FScriptDelegate& Delegate_69, float ThirtySecondsNotesPerMinute_69, class QuartzClockHandle** ClockHandle_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioMixer.QuartzClockHandle.SetThirtySecondNotesPerMinute"));

	QuartzClockHandle_SetThirtySecondNotesPerMinute_Params params;
	params.WorldContextObject_69 = WorldContextObject_69;
	params.QuantizationBoundary_69 = QuantizationBoundary_69;
	params.Delegate_69 = Delegate_69;
	params.ThirtySecondsNotesPerMinute_69 = ThirtySecondsNotesPerMinute_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (ClockHandle_69 != nullptr)
		*ClockHandle_69 = params.ClockHandle_69;
}


// Function AudioMixer.QuartzClockHandle.SetSecondsPerTick
// (Final, Native, Public, HasOutParms, BlueprintCallable)
// Parameters:
// class Object_32759*            WorldContextObject_69          (ConstParm, Parm, ZeroConstructor)
// struct FQuartzQuantizationBoundary QuantizationBoundary_69        (ConstParm, Parm, OutParm, ReferenceParm)
// struct FScriptDelegate         Delegate_69                    (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
// class QuartzClockHandle*       ClockHandle_69                 (Parm, OutParm, ZeroConstructor)
// float                          SecondsPerTick_69              (Parm, ZeroConstructor, IsPlainOldData)

void QuartzClockHandle::SetSecondsPerTick(class Object_32759* WorldContextObject_69, const struct FQuartzQuantizationBoundary& QuantizationBoundary_69, const struct FScriptDelegate& Delegate_69, float SecondsPerTick_69, class QuartzClockHandle** ClockHandle_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioMixer.QuartzClockHandle.SetSecondsPerTick"));

	QuartzClockHandle_SetSecondsPerTick_Params params;
	params.WorldContextObject_69 = WorldContextObject_69;
	params.QuantizationBoundary_69 = QuantizationBoundary_69;
	params.Delegate_69 = Delegate_69;
	params.SecondsPerTick_69 = SecondsPerTick_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (ClockHandle_69 != nullptr)
		*ClockHandle_69 = params.ClockHandle_69;
}


// Function AudioMixer.QuartzClockHandle.SetMillisecondsPerTick
// (Final, Native, Public, HasOutParms, BlueprintCallable)
// Parameters:
// class Object_32759*            WorldContextObject_69          (ConstParm, Parm, ZeroConstructor)
// struct FQuartzQuantizationBoundary QuantizationBoundary_69        (ConstParm, Parm, OutParm, ReferenceParm)
// struct FScriptDelegate         Delegate_69                    (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
// class QuartzClockHandle*       ClockHandle_69                 (Parm, OutParm, ZeroConstructor)
// float                          MillisecondsPerTick_69         (Parm, ZeroConstructor, IsPlainOldData)

void QuartzClockHandle::SetMillisecondsPerTick(class Object_32759* WorldContextObject_69, const struct FQuartzQuantizationBoundary& QuantizationBoundary_69, const struct FScriptDelegate& Delegate_69, float MillisecondsPerTick_69, class QuartzClockHandle** ClockHandle_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioMixer.QuartzClockHandle.SetMillisecondsPerTick"));

	QuartzClockHandle_SetMillisecondsPerTick_Params params;
	params.WorldContextObject_69 = WorldContextObject_69;
	params.QuantizationBoundary_69 = QuantizationBoundary_69;
	params.Delegate_69 = Delegate_69;
	params.MillisecondsPerTick_69 = MillisecondsPerTick_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (ClockHandle_69 != nullptr)
		*ClockHandle_69 = params.ClockHandle_69;
}


// Function AudioMixer.QuartzClockHandle.SetBeatsPerMinute
// (Final, Native, Public, HasOutParms, BlueprintCallable)
// Parameters:
// class Object_32759*            WorldContextObject_69          (ConstParm, Parm, ZeroConstructor)
// struct FQuartzQuantizationBoundary QuantizationBoundary_69        (ConstParm, Parm, OutParm, ReferenceParm)
// struct FScriptDelegate         Delegate_69                    (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
// class QuartzClockHandle*       ClockHandle_69                 (Parm, OutParm, ZeroConstructor)
// float                          BeatsPerMinute_69              (Parm, ZeroConstructor, IsPlainOldData)

void QuartzClockHandle::SetBeatsPerMinute(class Object_32759* WorldContextObject_69, const struct FQuartzQuantizationBoundary& QuantizationBoundary_69, const struct FScriptDelegate& Delegate_69, float BeatsPerMinute_69, class QuartzClockHandle** ClockHandle_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioMixer.QuartzClockHandle.SetBeatsPerMinute"));

	QuartzClockHandle_SetBeatsPerMinute_Params params;
	params.WorldContextObject_69 = WorldContextObject_69;
	params.QuantizationBoundary_69 = QuantizationBoundary_69;
	params.Delegate_69 = Delegate_69;
	params.BeatsPerMinute_69 = BeatsPerMinute_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (ClockHandle_69 != nullptr)
		*ClockHandle_69 = params.ClockHandle_69;
}


// Function AudioMixer.QuartzClockHandle.ResumeClock
// (Final, Native, Public, HasOutParms, BlueprintCallable)
// Parameters:
// class Object_32759*            WorldContextObject_69          (ConstParm, Parm, ZeroConstructor)
// class QuartzClockHandle*       ClockHandle_69                 (Parm, OutParm, ZeroConstructor)

void QuartzClockHandle::ResumeClock(class Object_32759* WorldContextObject_69, class QuartzClockHandle** ClockHandle_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioMixer.QuartzClockHandle.ResumeClock"));

	QuartzClockHandle_ResumeClock_Params params;
	params.WorldContextObject_69 = WorldContextObject_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (ClockHandle_69 != nullptr)
		*ClockHandle_69 = params.ClockHandle_69;
}


// Function AudioMixer.QuartzClockHandle.ResetTransportQuantized
// (Final, Native, Public, HasOutParms, BlueprintCallable)
// Parameters:
// class Object_32759*            WorldContextObject_69          (ConstParm, Parm, ZeroConstructor)
// struct FQuartzQuantizationBoundary InQuantizationBoundary_69      (Parm)
// struct FScriptDelegate         InDelegate_69                  (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
// class QuartzClockHandle*       ClockHandle_69                 (Parm, OutParm, ZeroConstructor)

void QuartzClockHandle::ResetTransportQuantized(class Object_32759* WorldContextObject_69, const struct FQuartzQuantizationBoundary& InQuantizationBoundary_69, const struct FScriptDelegate& InDelegate_69, class QuartzClockHandle** ClockHandle_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioMixer.QuartzClockHandle.ResetTransportQuantized"));

	QuartzClockHandle_ResetTransportQuantized_Params params;
	params.WorldContextObject_69 = WorldContextObject_69;
	params.InQuantizationBoundary_69 = InQuantizationBoundary_69;
	params.InDelegate_69 = InDelegate_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (ClockHandle_69 != nullptr)
		*ClockHandle_69 = params.ClockHandle_69;
}


// Function AudioMixer.QuartzClockHandle.ResetTransport
// (Final, Native, Public, HasOutParms, BlueprintCallable)
// Parameters:
// class Object_32759*            WorldContextObject_69          (ConstParm, Parm, ZeroConstructor)
// struct FScriptDelegate         InDelegate_69                  (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)

void QuartzClockHandle::ResetTransport(class Object_32759* WorldContextObject_69, const struct FScriptDelegate& InDelegate_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioMixer.QuartzClockHandle.ResetTransport"));

	QuartzClockHandle_ResetTransport_Params params;
	params.WorldContextObject_69 = WorldContextObject_69;
	params.InDelegate_69 = InDelegate_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AudioMixer.QuartzClockHandle.PauseClock
// (Final, Native, Public, HasOutParms, BlueprintCallable)
// Parameters:
// class Object_32759*            WorldContextObject_69          (ConstParm, Parm, ZeroConstructor)
// class QuartzClockHandle*       ClockHandle_69                 (Parm, OutParm, ZeroConstructor)

void QuartzClockHandle::PauseClock(class Object_32759* WorldContextObject_69, class QuartzClockHandle** ClockHandle_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioMixer.QuartzClockHandle.PauseClock"));

	QuartzClockHandle_PauseClock_Params params;
	params.WorldContextObject_69 = WorldContextObject_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (ClockHandle_69 != nullptr)
		*ClockHandle_69 = params.ClockHandle_69;
}


// Function AudioMixer.QuartzClockHandle.IsClockRunning
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// class Object_32759*            WorldContextObject_69          (ConstParm, Parm, ZeroConstructor)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool QuartzClockHandle::IsClockRunning(class Object_32759* WorldContextObject_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioMixer.QuartzClockHandle.IsClockRunning"));

	QuartzClockHandle_IsClockRunning_Params params;
	params.WorldContextObject_69 = WorldContextObject_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AudioMixer.QuartzClockHandle.GetTicksPerSecond
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// class Object_32759*            WorldContextObject_69          (ConstParm, Parm, ZeroConstructor)
// float                          ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

float QuartzClockHandle::GetTicksPerSecond(class Object_32759* WorldContextObject_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioMixer.QuartzClockHandle.GetTicksPerSecond"));

	QuartzClockHandle_GetTicksPerSecond_Params params;
	params.WorldContextObject_69 = WorldContextObject_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AudioMixer.QuartzClockHandle.GetThirtySecondNotesPerMinute
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// class Object_32759*            WorldContextObject_69          (ConstParm, Parm, ZeroConstructor)
// float                          ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

float QuartzClockHandle::GetThirtySecondNotesPerMinute(class Object_32759* WorldContextObject_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioMixer.QuartzClockHandle.GetThirtySecondNotesPerMinute"));

	QuartzClockHandle_GetThirtySecondNotesPerMinute_Params params;
	params.WorldContextObject_69 = WorldContextObject_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AudioMixer.QuartzClockHandle.GetSecondsPerTick
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// class Object_32759*            WorldContextObject_69          (ConstParm, Parm, ZeroConstructor)
// float                          ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

float QuartzClockHandle::GetSecondsPerTick(class Object_32759* WorldContextObject_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioMixer.QuartzClockHandle.GetSecondsPerTick"));

	QuartzClockHandle_GetSecondsPerTick_Params params;
	params.WorldContextObject_69 = WorldContextObject_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AudioMixer.QuartzClockHandle.GetMillisecondsPerTick
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// class Object_32759*            WorldContextObject_69          (ConstParm, Parm, ZeroConstructor)
// float                          ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

float QuartzClockHandle::GetMillisecondsPerTick(class Object_32759* WorldContextObject_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioMixer.QuartzClockHandle.GetMillisecondsPerTick"));

	QuartzClockHandle_GetMillisecondsPerTick_Params params;
	params.WorldContextObject_69 = WorldContextObject_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AudioMixer.QuartzClockHandle.GetEstimatedRunTime
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// class Object_32759*            WorldContextObject_69          (ConstParm, Parm, ZeroConstructor)
// float                          ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

float QuartzClockHandle::GetEstimatedRunTime(class Object_32759* WorldContextObject_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioMixer.QuartzClockHandle.GetEstimatedRunTime"));

	QuartzClockHandle_GetEstimatedRunTime_Params params;
	params.WorldContextObject_69 = WorldContextObject_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AudioMixer.QuartzClockHandle.GetDurationOfQuantizationTypeInSeconds
// (Final, Native, Public, HasOutParms, BlueprintCallable)
// Parameters:
// class Object_32759*            WorldContextObject_69          (ConstParm, Parm, ZeroConstructor)
// EQuartzCommandQuantization     QuantizationType_69            (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
// float                          Multiplier_69                  (Parm, ZeroConstructor, IsPlainOldData)
// float                          ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

float QuartzClockHandle::GetDurationOfQuantizationTypeInSeconds(class Object_32759* WorldContextObject_69, EQuartzCommandQuantization QuantizationType_69, float Multiplier_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioMixer.QuartzClockHandle.GetDurationOfQuantizationTypeInSeconds"));

	QuartzClockHandle_GetDurationOfQuantizationTypeInSeconds_Params params;
	params.WorldContextObject_69 = WorldContextObject_69;
	params.QuantizationType_69 = QuantizationType_69;
	params.Multiplier_69 = Multiplier_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AudioMixer.QuartzClockHandle.GetCurrentTimestamp
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// class Object_32759*            WorldContextObject_69          (ConstParm, Parm, ZeroConstructor)
// struct FQuartzTransportTimeStamp ReturnValue_69                 (Parm, OutParm, ReturnParm)

struct FQuartzTransportTimeStamp QuartzClockHandle::GetCurrentTimestamp(class Object_32759* WorldContextObject_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioMixer.QuartzClockHandle.GetCurrentTimestamp"));

	QuartzClockHandle_GetCurrentTimestamp_Params params;
	params.WorldContextObject_69 = WorldContextObject_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AudioMixer.QuartzClockHandle.GetBeatsPerMinute
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// class Object_32759*            WorldContextObject_69          (ConstParm, Parm, ZeroConstructor)
// float                          ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

float QuartzClockHandle::GetBeatsPerMinute(class Object_32759* WorldContextObject_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioMixer.QuartzClockHandle.GetBeatsPerMinute"));

	QuartzClockHandle_GetBeatsPerMinute_Params params;
	params.WorldContextObject_69 = WorldContextObject_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AudioMixer.QuartzSubsystem.IsQuartzEnabled
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool QuartzSubsystem::IsQuartzEnabled()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioMixer.QuartzSubsystem.IsQuartzEnabled"));

	QuartzSubsystem_IsQuartzEnabled_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AudioMixer.QuartzSubsystem.IsClockRunning
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// class Object_32759*            WorldContextObject_69          (ConstParm, Parm, ZeroConstructor)
// struct FName                   ClockName_69                   (Parm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool QuartzSubsystem::IsClockRunning(class Object_32759* WorldContextObject_69, const struct FName& ClockName_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioMixer.QuartzSubsystem.IsClockRunning"));

	QuartzSubsystem_IsClockRunning_Params params;
	params.WorldContextObject_69 = WorldContextObject_69;
	params.ClockName_69 = ClockName_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AudioMixer.QuartzSubsystem.GetRoundTripMinLatency
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// class Object_32759*            WorldContextObject_69          (ConstParm, Parm, ZeroConstructor)
// float                          ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

float QuartzSubsystem::GetRoundTripMinLatency(class Object_32759* WorldContextObject_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioMixer.QuartzSubsystem.GetRoundTripMinLatency"));

	QuartzSubsystem_GetRoundTripMinLatency_Params params;
	params.WorldContextObject_69 = WorldContextObject_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AudioMixer.QuartzSubsystem.GetRoundTripMaxLatency
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// class Object_32759*            WorldContextObject_69          (ConstParm, Parm, ZeroConstructor)
// float                          ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

float QuartzSubsystem::GetRoundTripMaxLatency(class Object_32759* WorldContextObject_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioMixer.QuartzSubsystem.GetRoundTripMaxLatency"));

	QuartzSubsystem_GetRoundTripMaxLatency_Params params;
	params.WorldContextObject_69 = WorldContextObject_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AudioMixer.QuartzSubsystem.GetRoundTripAverageLatency
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// class Object_32759*            WorldContextObject_69          (ConstParm, Parm, ZeroConstructor)
// float                          ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

float QuartzSubsystem::GetRoundTripAverageLatency(class Object_32759* WorldContextObject_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioMixer.QuartzSubsystem.GetRoundTripAverageLatency"));

	QuartzSubsystem_GetRoundTripAverageLatency_Params params;
	params.WorldContextObject_69 = WorldContextObject_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AudioMixer.QuartzSubsystem.GetHandleForClock
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// class Object_32759*            WorldContextObject_69          (ConstParm, Parm, ZeroConstructor)
// struct FName                   ClockName_69                   (Parm, ZeroConstructor, IsPlainOldData)
// class QuartzClockHandle*       ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

class QuartzClockHandle* QuartzSubsystem::GetHandleForClock(class Object_32759* WorldContextObject_69, const struct FName& ClockName_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioMixer.QuartzSubsystem.GetHandleForClock"));

	QuartzSubsystem_GetHandleForClock_Params params;
	params.WorldContextObject_69 = WorldContextObject_69;
	params.ClockName_69 = ClockName_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AudioMixer.QuartzSubsystem.GetGameThreadToAudioRenderThreadMinLatency
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// class Object_32759*            WorldContextObject_69          (ConstParm, Parm, ZeroConstructor)
// float                          ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

float QuartzSubsystem::GetGameThreadToAudioRenderThreadMinLatency(class Object_32759* WorldContextObject_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioMixer.QuartzSubsystem.GetGameThreadToAudioRenderThreadMinLatency"));

	QuartzSubsystem_GetGameThreadToAudioRenderThreadMinLatency_Params params;
	params.WorldContextObject_69 = WorldContextObject_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AudioMixer.QuartzSubsystem.GetGameThreadToAudioRenderThreadMaxLatency
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// class Object_32759*            WorldContextObject_69          (ConstParm, Parm, ZeroConstructor)
// float                          ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

float QuartzSubsystem::GetGameThreadToAudioRenderThreadMaxLatency(class Object_32759* WorldContextObject_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioMixer.QuartzSubsystem.GetGameThreadToAudioRenderThreadMaxLatency"));

	QuartzSubsystem_GetGameThreadToAudioRenderThreadMaxLatency_Params params;
	params.WorldContextObject_69 = WorldContextObject_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AudioMixer.QuartzSubsystem.GetGameThreadToAudioRenderThreadAverageLatency
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// class Object_32759*            WorldContextObject_69          (ConstParm, Parm, ZeroConstructor)
// float                          ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

float QuartzSubsystem::GetGameThreadToAudioRenderThreadAverageLatency(class Object_32759* WorldContextObject_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioMixer.QuartzSubsystem.GetGameThreadToAudioRenderThreadAverageLatency"));

	QuartzSubsystem_GetGameThreadToAudioRenderThreadAverageLatency_Params params;
	params.WorldContextObject_69 = WorldContextObject_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AudioMixer.QuartzSubsystem.GetEstimatedClockRunTime
// (Final, Native, Public, HasOutParms, BlueprintCallable)
// Parameters:
// class Object_32759*            WorldContextObject_69          (ConstParm, Parm, ZeroConstructor)
// struct FName                   InClockName_69                 (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
// float                          ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

float QuartzSubsystem::GetEstimatedClockRunTime(class Object_32759* WorldContextObject_69, const struct FName& InClockName_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioMixer.QuartzSubsystem.GetEstimatedClockRunTime"));

	QuartzSubsystem_GetEstimatedClockRunTime_Params params;
	params.WorldContextObject_69 = WorldContextObject_69;
	params.InClockName_69 = InClockName_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AudioMixer.QuartzSubsystem.GetDurationOfQuantizationTypeInSeconds
// (Final, Native, Public, HasOutParms, BlueprintCallable)
// Parameters:
// class Object_32759*            WorldContextObject_69          (ConstParm, Parm, ZeroConstructor)
// struct FName                   ClockName_69                   (Parm, ZeroConstructor, IsPlainOldData)
// EQuartzCommandQuantization     QuantizationType_69            (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
// float                          Multiplier_69                  (Parm, ZeroConstructor, IsPlainOldData)
// float                          ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

float QuartzSubsystem::GetDurationOfQuantizationTypeInSeconds(class Object_32759* WorldContextObject_69, const struct FName& ClockName_69, EQuartzCommandQuantization QuantizationType_69, float Multiplier_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioMixer.QuartzSubsystem.GetDurationOfQuantizationTypeInSeconds"));

	QuartzSubsystem_GetDurationOfQuantizationTypeInSeconds_Params params;
	params.WorldContextObject_69 = WorldContextObject_69;
	params.ClockName_69 = ClockName_69;
	params.QuantizationType_69 = QuantizationType_69;
	params.Multiplier_69 = Multiplier_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AudioMixer.QuartzSubsystem.GetCurrentClockTimestamp
// (Final, Native, Public, HasOutParms, BlueprintCallable)
// Parameters:
// class Object_32759*            WorldContextObject_69          (ConstParm, Parm, ZeroConstructor)
// struct FName                   InClockName_69                 (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
// struct FQuartzTransportTimeStamp ReturnValue_69                 (Parm, OutParm, ReturnParm)

struct FQuartzTransportTimeStamp QuartzSubsystem::GetCurrentClockTimestamp(class Object_32759* WorldContextObject_69, const struct FName& InClockName_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioMixer.QuartzSubsystem.GetCurrentClockTimestamp"));

	QuartzSubsystem_GetCurrentClockTimestamp_Params params;
	params.WorldContextObject_69 = WorldContextObject_69;
	params.InClockName_69 = InClockName_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AudioMixer.QuartzSubsystem.GetAudioRenderThreadToGameThreadMinLatency
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// float                          ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

float QuartzSubsystem::GetAudioRenderThreadToGameThreadMinLatency()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioMixer.QuartzSubsystem.GetAudioRenderThreadToGameThreadMinLatency"));

	QuartzSubsystem_GetAudioRenderThreadToGameThreadMinLatency_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AudioMixer.QuartzSubsystem.GetAudioRenderThreadToGameThreadMaxLatency
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// float                          ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

float QuartzSubsystem::GetAudioRenderThreadToGameThreadMaxLatency()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioMixer.QuartzSubsystem.GetAudioRenderThreadToGameThreadMaxLatency"));

	QuartzSubsystem_GetAudioRenderThreadToGameThreadMaxLatency_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AudioMixer.QuartzSubsystem.GetAudioRenderThreadToGameThreadAverageLatency
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// float                          ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

float QuartzSubsystem::GetAudioRenderThreadToGameThreadAverageLatency()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioMixer.QuartzSubsystem.GetAudioRenderThreadToGameThreadAverageLatency"));

	QuartzSubsystem_GetAudioRenderThreadToGameThreadAverageLatency_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AudioMixer.QuartzSubsystem.DoesClockExist
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// class Object_32759*            WorldContextObject_69          (ConstParm, Parm, ZeroConstructor)
// struct FName                   ClockName_69                   (Parm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool QuartzSubsystem::DoesClockExist(class Object_32759* WorldContextObject_69, const struct FName& ClockName_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioMixer.QuartzSubsystem.DoesClockExist"));

	QuartzSubsystem_DoesClockExist_Params params;
	params.WorldContextObject_69 = WorldContextObject_69;
	params.ClockName_69 = ClockName_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AudioMixer.QuartzSubsystem.DeleteClockByName
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// class Object_32759*            WorldContextObject_69          (ConstParm, Parm, ZeroConstructor)
// struct FName                   ClockName_69                   (Parm, ZeroConstructor, IsPlainOldData)

void QuartzSubsystem::DeleteClockByName(class Object_32759* WorldContextObject_69, const struct FName& ClockName_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioMixer.QuartzSubsystem.DeleteClockByName"));

	QuartzSubsystem_DeleteClockByName_Params params;
	params.WorldContextObject_69 = WorldContextObject_69;
	params.ClockName_69 = ClockName_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AudioMixer.QuartzSubsystem.DeleteClockByHandle
// (Final, Native, Public, HasOutParms, BlueprintCallable)
// Parameters:
// class Object_32759*            WorldContextObject_69          (ConstParm, Parm, ZeroConstructor)
// class QuartzClockHandle*       InClockHandle_69               (Parm, OutParm, ZeroConstructor, ReferenceParm)

void QuartzSubsystem::DeleteClockByHandle(class Object_32759* WorldContextObject_69, class QuartzClockHandle** InClockHandle_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioMixer.QuartzSubsystem.DeleteClockByHandle"));

	QuartzSubsystem_DeleteClockByHandle_Params params;
	params.WorldContextObject_69 = WorldContextObject_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (InClockHandle_69 != nullptr)
		*InClockHandle_69 = params.InClockHandle_69;
}


// Function AudioMixer.QuartzSubsystem.CreateNewClock
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// class Object_32759*            WorldContextObject_69          (ConstParm, Parm, ZeroConstructor)
// struct FName                   ClockName_69                   (Parm, ZeroConstructor, IsPlainOldData)
// struct FQuartzClockSettings    InSettings_69                  (Parm)
// bool                           bOverrideSettingsIfClockExists_69 (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bUseAudioEngineClockManager_69 (Parm, ZeroConstructor, IsPlainOldData)
// class QuartzClockHandle*       ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

class QuartzClockHandle* QuartzSubsystem::CreateNewClock(class Object_32759* WorldContextObject_69, const struct FName& ClockName_69, const struct FQuartzClockSettings& InSettings_69, bool bOverrideSettingsIfClockExists_69, bool bUseAudioEngineClockManager_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioMixer.QuartzSubsystem.CreateNewClock"));

	QuartzSubsystem_CreateNewClock_Params params;
	params.WorldContextObject_69 = WorldContextObject_69;
	params.ClockName_69 = ClockName_69;
	params.InSettings_69 = InSettings_69;
	params.bOverrideSettingsIfClockExists_69 = bOverrideSettingsIfClockExists_69;
	params.bUseAudioEngineClockManager_69 = bUseAudioEngineClockManager_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Classes
//---------------------------------------------------------------------------

// Class AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary
// 0x0000 (0x0028 - 0x0028)
class AnalyticsBlueprintLibrary : public BlueprintFunctionLibrary
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary"));
		
		return ptr;
	}


	bool STATIC_StartSessionWithAttributes(TArray<struct FAnalyticsEventAttr> Attributes_69);
	bool STATIC_StartSession();
	void STATIC_SetUserId(const struct FString& UserId_69);
	void STATIC_SetSessionId(const struct FString& SessionId_69);
	void STATIC_SetLocation(const struct FString& Location_69);
	void STATIC_SetGender(const struct FString& Gender_69);
	void STATIC_SetBuildInfo(const struct FString& BuildInfo_69);
	void STATIC_SetAge(int Age_69);
	void STATIC_RecordSimpleItemPurchaseWithAttributes(const struct FString& ItemId_69, int ItemQuantity_69, TArray<struct FAnalyticsEventAttr> Attributes_69);
	void STATIC_RecordSimpleItemPurchase(const struct FString& ItemId_69, int ItemQuantity_69);
	void STATIC_RecordSimpleCurrencyPurchaseWithAttributes(const struct FString& GameCurrencyType_69, int GameCurrencyAmount_69, TArray<struct FAnalyticsEventAttr> Attributes_69);
	void STATIC_RecordSimpleCurrencyPurchase(const struct FString& GameCurrencyType_69, int GameCurrencyAmount_69);
	void STATIC_RecordProgressWithFullHierarchyAndAttributes(const struct FString& ProgressType_69, TArray<struct FString> ProgressNames_69, TArray<struct FAnalyticsEventAttr> Attributes_69);
	void STATIC_RecordProgressWithAttributes(const struct FString& ProgressType_69, const struct FString& ProgressName_69, TArray<struct FAnalyticsEventAttr> Attributes_69);
	void STATIC_RecordProgress(const struct FString& ProgressType_69, const struct FString& ProgressName_69);
	void STATIC_RecordItemPurchase(const struct FString& ItemId_69, const struct FString& Currency_69, int PerItemCost_69, int ItemQuantity_69);
	void STATIC_RecordEventWithAttributes(const struct FString& EventName_69, TArray<struct FAnalyticsEventAttr> Attributes_69);
	void STATIC_RecordEventWithAttribute(const struct FString& EventName_69, const struct FString& AttributeName_69, const struct FString& AttributeValue_69);
	void STATIC_RecordEvent(const struct FString& EventName_69);
	void STATIC_RecordErrorWithAttributes(const struct FString& Error_69, TArray<struct FAnalyticsEventAttr> Attributes_69);
	void STATIC_RecordError(const struct FString& Error_69);
	void STATIC_RecordCurrencyPurchase(const struct FString& GameCurrencyType_69, int GameCurrencyAmount_69, const struct FString& RealCurrencyType_69, float RealMoneyCost_69, const struct FString& PaymentProvider_69);
	void STATIC_RecordCurrencyGivenWithAttributes(const struct FString& GameCurrencyType_69, int GameCurrencyAmount_69, TArray<struct FAnalyticsEventAttr> Attributes_69);
	void STATIC_RecordCurrencyGiven(const struct FString& GameCurrencyType_69, int GameCurrencyAmount_69);
	struct FAnalyticsEventAttr STATIC_MakeEventAttribute(const struct FString& AttributeName_69, const struct FString& AttributeValue_69);
	struct FString STATIC_GetUserId();
	struct FString STATIC_GetSessionId();
	void STATIC_FlushEvents();
	void STATIC_EndSession();
};


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

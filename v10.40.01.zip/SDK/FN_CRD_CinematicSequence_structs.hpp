#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Enums
//---------------------------------------------------------------------------

// Enum CRD_CinematicSequence.ECinematicSequenceVisibility
enum class ECinematicSequenceVisibility : uint8_t
{
	InstigatorOnly                 = 0,
	InstigatingTeam                = 1,
	Everyone                       = 2,
	ECinematicSequenceVisibility_MAX = 3
};



}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

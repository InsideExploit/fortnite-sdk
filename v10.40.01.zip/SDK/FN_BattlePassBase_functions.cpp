// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Functions
//---------------------------------------------------------------------------

// Function BattlePassBase.BattlePassSubPageInterface.OnEnterSubPage
// (Event, Public, BlueprintEvent)

void BattlePassSubPageInterface::OnEnterSubPage()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function BattlePassBase.BattlePassSubPageInterface.OnEnterSubPage"));

	BattlePassSubPageInterface_OnEnterSubPage_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function BattlePassBase.BattlePassLandingPageButton.OnSubscriptionTextureLoaded
// (Event, Protected, BlueprintEvent)
// Parameters:
// class Texture2D*               Texture_69                     (Parm, ZeroConstructor)

void BattlePassLandingPageButton::OnSubscriptionTextureLoaded(class Texture2D* Texture_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function BattlePassBase.BattlePassLandingPageButton.OnSubscriptionTextureLoaded"));

	BattlePassLandingPageButton_OnSubscriptionTextureLoaded_Params params;
	params.Texture_69 = Texture_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function BattlePassBase.BattlePassLandingPageButton.OnSubscriptionOwnershipUpdated
// (RequiredAPI, Event, Public, BlueprintEvent)
// Parameters:
// bool                           bOwnsSubsciption_69            (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void BattlePassLandingPageButton::OnSubscriptionOwnershipUpdated(bool bOwnsSubsciption_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function BattlePassBase.BattlePassLandingPageButton.OnSubscriptionOwnershipUpdated"));

	BattlePassLandingPageButton_OnSubscriptionOwnershipUpdated_Params params;
	params.bOwnsSubsciption_69 = bOwnsSubsciption_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function BattlePassBase.BattlePassLandingPageButton.OnDisplayDetailsUpdated
// (Event, Public, HasOutParms, BlueprintEvent)
// Parameters:
// struct FBattlePassLandingPageButtonDisplayDetails NewDisplayDetails_69           (ConstParm, Parm, OutParm, ReferenceParm)

void BattlePassLandingPageButton::OnDisplayDetailsUpdated(const struct FBattlePassLandingPageButtonDisplayDetails& NewDisplayDetails_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function BattlePassBase.BattlePassLandingPageButton.OnDisplayDetailsUpdated"));

	BattlePassLandingPageButton_OnDisplayDetailsUpdated_Params params;
	params.NewDisplayDetails_69 = NewDisplayDetails_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function BattlePassBase.BattlePassLandingPageButton.GetBattlePassDisplayDetails
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FBattlePassLandingPageButtonDisplayDetails ReturnValue_69                 (ConstParm, Parm, OutParm, ReturnParm, ReferenceParm)

struct FBattlePassLandingPageButtonDisplayDetails BattlePassLandingPageButton::GetBattlePassDisplayDetails()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function BattlePassBase.BattlePassLandingPageButton.GetBattlePassDisplayDetails"));

	BattlePassLandingPageButton_GetBattlePassDisplayDetails_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function BattlePassBase.FortBattlePassCustomSkinCategoryTile.SetPreviewedTile
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// int                            Index_69                       (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void FortBattlePassCustomSkinCategoryTile::SetPreviewedTile(int Index_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function BattlePassBase.FortBattlePassCustomSkinCategoryTile.SetPreviewedTile"));

	FortBattlePassCustomSkinCategoryTile_SetPreviewedTile_Params params;
	params.Index_69 = Index_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function BattlePassBase.FortBattlePassCustomSkinCategoryTile.OnOwnedTilesUpdated
// (Event, Protected, BlueprintEvent)
// Parameters:
// int                            CurrentlyOwnedRewards_69       (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// int                            TotalRewards_69                (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// float                          CategoryProgress_69            (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void FortBattlePassCustomSkinCategoryTile::OnOwnedTilesUpdated(int CurrentlyOwnedRewards_69, int TotalRewards_69, float CategoryProgress_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function BattlePassBase.FortBattlePassCustomSkinCategoryTile.OnOwnedTilesUpdated"));

	FortBattlePassCustomSkinCategoryTile_OnOwnedTilesUpdated_Params params;
	params.CurrentlyOwnedRewards_69 = CurrentlyOwnedRewards_69;
	params.TotalRewards_69 = TotalRewards_69;
	params.CategoryProgress_69 = CategoryProgress_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function BattlePassBase.FortBattlePassCustomSkinCategoryTile.OnLockedStateChanged
// (Event, Protected, BlueprintEvent)
// Parameters:
// bool                           bCategoryLocked_69             (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void FortBattlePassCustomSkinCategoryTile::OnLockedStateChanged(bool bCategoryLocked_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function BattlePassBase.FortBattlePassCustomSkinCategoryTile.OnLockedStateChanged"));

	FortBattlePassCustomSkinCategoryTile_OnLockedStateChanged_Params params;
	params.bCategoryLocked_69 = bCategoryLocked_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function BattlePassBase.FortBattlePassCustomSkinCategoryTile.OnLockedProgressUpdated
// (Event, Protected, BlueprintEvent)
// Parameters:
// int                            CurrentlyOwnedBeforeCategory_69 (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// int                            TotalRewardsBeforeCategory_69  (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// float                          LockedProgress_69              (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void FortBattlePassCustomSkinCategoryTile::OnLockedProgressUpdated(int CurrentlyOwnedBeforeCategory_69, int TotalRewardsBeforeCategory_69, float LockedProgress_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function BattlePassBase.FortBattlePassCustomSkinCategoryTile.OnLockedProgressUpdated"));

	FortBattlePassCustomSkinCategoryTile_OnLockedProgressUpdated_Params params;
	params.CurrentlyOwnedBeforeCategory_69 = CurrentlyOwnedBeforeCategory_69;
	params.TotalRewardsBeforeCategory_69 = TotalRewardsBeforeCategory_69;
	params.LockedProgress_69 = LockedProgress_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function BattlePassBase.FortBattlePassCustomSkinCategoryTile.FocusTile
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// int                            Index_69                       (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void FortBattlePassCustomSkinCategoryTile::FocusTile(int Index_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function BattlePassBase.FortBattlePassCustomSkinCategoryTile.FocusTile"));

	FortBattlePassCustomSkinCategoryTile_FocusTile_Params params;
	params.Index_69 = Index_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function BattlePassBase.FortBattlePassBulkBuyPageBase.OnRewardCountChanged
// (Event, Public, BlueprintEvent)
// Parameters:
// int                            Count_69                       (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void FortBattlePassBulkBuyPageBase::OnRewardCountChanged(int Count_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function BattlePassBase.FortBattlePassBulkBuyPageBase.OnRewardCountChanged"));

	FortBattlePassBulkBuyPageBase_OnRewardCountChanged_Params params;
	params.Count_69 = Count_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function BattlePassBase.FortBattlePassBulkBuyPageBase.OnPageRangeChanged
// (Event, Public, BlueprintEvent)
// Parameters:
// int                            FromPage_69                    (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// int                            ToPage_69                      (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void FortBattlePassBulkBuyPageBase::OnPageRangeChanged(int FromPage_69, int ToPage_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function BattlePassBase.FortBattlePassBulkBuyPageBase.OnPageRangeChanged"));

	FortBattlePassBulkBuyPageBase_OnPageRangeChanged_Params params;
	params.FromPage_69 = FromPage_69;
	params.ToPage_69 = ToPage_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function BattlePassBase.FortBattlePassBulkBuyPageBase.OnCostChanged
// (Event, Public, BlueprintEvent)
// Parameters:
// int                            Cost_69                        (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void FortBattlePassBulkBuyPageBase::OnCostChanged(int Cost_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function BattlePassBase.FortBattlePassBulkBuyPageBase.OnCostChanged"));

	FortBattlePassBulkBuyPageBase_OnCostChanged_Params params;
	params.Cost_69 = Cost_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function BattlePassBase.FortBattlePassBulkBuyPageBase.HandleUserScrolled
// (Final, Native, Protected)
// Parameters:
// float                          ScrollAmount_69                (Parm, ZeroConstructor, IsPlainOldData)

void FortBattlePassBulkBuyPageBase::HandleUserScrolled(float ScrollAmount_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function BattlePassBase.FortBattlePassBulkBuyPageBase.HandleUserScrolled"));

	FortBattlePassBulkBuyPageBase_HandleUserScrolled_Params params;
	params.ScrollAmount_69 = ScrollAmount_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function BattlePassBase.FortBattlePassCheckBoxButton.OnStateChanged
// (Event, Protected, BlueprintEvent)
// Parameters:
// bool                           bNewIsChecked_69               (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void FortBattlePassCheckBoxButton::OnStateChanged(bool bNewIsChecked_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function BattlePassBase.FortBattlePassCheckBoxButton.OnStateChanged"));

	FortBattlePassCheckBoxButton_OnStateChanged_Params params;
	params.bNewIsChecked_69 = bNewIsChecked_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function BattlePassBase.FortBattlePassContext.GetSeasonalCurrencies
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// TArray<struct FSeasonCurrencyMcpData> ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

TArray<struct FSeasonCurrencyMcpData> FortBattlePassContext::GetSeasonalCurrencies()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function BattlePassBase.FortBattlePassContext.GetSeasonalCurrencies"));

	FortBattlePassContext_GetSeasonalCurrencies_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function BattlePassBase.FortBattlePassContext.GetLevelPurchaseDisclaimerText
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FText                   ReturnValue_69                 (Parm, OutParm, ReturnParm)

struct FText FortBattlePassContext::GetLevelPurchaseDisclaimerText()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function BattlePassBase.FortBattlePassContext.GetLevelPurchaseDisclaimerText"));

	FortBattlePassContext_GetLevelPurchaseDisclaimerText_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function BattlePassBase.FortBattlePassContext.GetDefaultDisclaimerText
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FText                   ReturnValue_69                 (Parm, OutParm, ReturnParm)

struct FText FortBattlePassContext::GetDefaultDisclaimerText()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function BattlePassBase.FortBattlePassContext.GetDefaultDisclaimerText"));

	FortBattlePassContext_GetDefaultDisclaimerText_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function BattlePassBase.FortBattlePassContext.GetCurrentSeasonNumberAsText
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// bool                           bFullText_69                   (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// struct FText                   ReturnValue_69                 (Parm, OutParm, ReturnParm)

struct FText FortBattlePassContext::GetCurrentSeasonNumberAsText(bool bFullText_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function BattlePassBase.FortBattlePassContext.GetCurrentSeasonNumberAsText"));

	FortBattlePassContext_GetCurrentSeasonNumberAsText_Params params;
	params.bFullText_69 = bFullText_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function BattlePassBase.FortBattlePassContext.GetCurrentChapterAsText
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// bool                           bFullText_69                   (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// struct FText                   ReturnValue_69                 (Parm, OutParm, ReturnParm)

struct FText FortBattlePassContext::GetCurrentChapterAsText(bool bFullText_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function BattlePassBase.FortBattlePassContext.GetCurrentChapterAsText"));

	FortBattlePassContext_GetCurrentChapterAsText_Params params;
	params.bFullText_69 = bFullText_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function BattlePassBase.FortBattlePassContext.CanPurchaseBattlePassLevel
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool FortBattlePassContext::CanPurchaseBattlePassLevel()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function BattlePassBase.FortBattlePassContext.CanPurchaseBattlePassLevel"));

	FortBattlePassContext_CanPurchaseBattlePassLevel_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function BattlePassBase.FortBattlePassResourcesWidgetBase.ShowResourcesInfoModal
// (Final, Native, Protected, BlueprintCallable)

void FortBattlePassResourcesWidgetBase::ShowResourcesInfoModal()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function BattlePassBase.FortBattlePassResourcesWidgetBase.ShowResourcesInfoModal"));

	FortBattlePassResourcesWidgetBase_ShowResourcesInfoModal_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function BattlePassBase.FortBattlePassResourcesWidgetBase.OnShowMoreInfo
// (Event, Protected, BlueprintEvent)
// Parameters:
// bool                           bShouldShowMoreInfo_69         (Parm, ZeroConstructor, IsPlainOldData)

void FortBattlePassResourcesWidgetBase::OnShowMoreInfo(bool bShouldShowMoreInfo_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function BattlePassBase.FortBattlePassResourcesWidgetBase.OnShowMoreInfo"));

	FortBattlePassResourcesWidgetBase_OnShowMoreInfo_Params params;
	params.bShouldShowMoreInfo_69 = bShouldShowMoreInfo_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function BattlePassBase.FortBattlePassPurchaseResourcesWidget.OnTotalPriceChanged
// (Event, Protected, BlueprintEvent)
// Parameters:
// int                            NewPrice_69                    (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void FortBattlePassPurchaseResourcesWidget::OnTotalPriceChanged(int NewPrice_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function BattlePassBase.FortBattlePassPurchaseResourcesWidget.OnTotalPriceChanged"));

	FortBattlePassPurchaseResourcesWidget_OnTotalPriceChanged_Params params;
	params.NewPrice_69 = NewPrice_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function BattlePassBase.FortBattlePassPurchaseResourcesWidget.OnPurchaseAmountChanged
// (Event, Protected, BlueprintEvent)
// Parameters:
// int                            NewAmount_69                   (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// int                            LevelsLeft_69                  (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void FortBattlePassPurchaseResourcesWidget::OnPurchaseAmountChanged(int NewAmount_69, int LevelsLeft_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function BattlePassBase.FortBattlePassPurchaseResourcesWidget.OnPurchaseAmountChanged"));

	FortBattlePassPurchaseResourcesWidget_OnPurchaseAmountChanged_Params params;
	params.NewAmount_69 = NewAmount_69;
	params.LevelsLeft_69 = LevelsLeft_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function BattlePassBase.FortBattlePassPurchaseResourcesWidget.OnOfferUnavailable
// (Event, Protected, BlueprintEvent)

void FortBattlePassPurchaseResourcesWidget::OnOfferUnavailable()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function BattlePassBase.FortBattlePassPurchaseResourcesWidget.OnOfferUnavailable"));

	FortBattlePassPurchaseResourcesWidget_OnOfferUnavailable_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function BattlePassBase.FortBattlePassPurchaseResourcesWidget.OnAmountChangeButtonClicked
// (Event, Protected, BlueprintEvent)

void FortBattlePassPurchaseResourcesWidget::OnAmountChangeButtonClicked()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function BattlePassBase.FortBattlePassPurchaseResourcesWidget.OnAmountChangeButtonClicked"));

	FortBattlePassPurchaseResourcesWidget_OnAmountChangeButtonClicked_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function BattlePassBase.FortBattlePassPurchaseResourcesWidget.IsReloadMtxEnabled
// (Final, Native, Protected, BlueprintCallable)
// Parameters:
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool FortBattlePassPurchaseResourcesWidget::IsReloadMtxEnabled()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function BattlePassBase.FortBattlePassPurchaseResourcesWidget.IsReloadMtxEnabled"));

	FortBattlePassPurchaseResourcesWidget_IsReloadMtxEnabled_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function BattlePassBase.FortBattlePassPurchaseResourcesWidget.HandlePurchaseMultiComplete
// (Final, Native, Private, HasOutParms)
// Parameters:
// bool                           bSuccess_69                    (Parm, ZeroConstructor, IsPlainOldData)
// TArray<struct FPurchasedItemInfo> PurchasedItems_69              (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
// TArray<struct FString>         OfferIdList_69                 (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)

void FortBattlePassPurchaseResourcesWidget::HandlePurchaseMultiComplete(bool bSuccess_69, TArray<struct FPurchasedItemInfo> PurchasedItems_69, TArray<struct FString> OfferIdList_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function BattlePassBase.FortBattlePassPurchaseResourcesWidget.HandlePurchaseMultiComplete"));

	FortBattlePassPurchaseResourcesWidget_HandlePurchaseMultiComplete_Params params;
	params.bSuccess_69 = bSuccess_69;
	params.PurchasedItems_69 = PurchasedItems_69;
	params.OfferIdList_69 = OfferIdList_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function BattlePassBase.FortBattlePassPurchaseResourcesWidget.HandlePurchaseComplete
// (Final, Native, Private, HasOutParms)
// Parameters:
// bool                           bSuccess_69                    (Parm, ZeroConstructor, IsPlainOldData)
// TArray<struct FPurchasedItemInfo> PurchasedItems_69              (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
// struct FString                 OfferId_69                     (Parm, ZeroConstructor)

void FortBattlePassPurchaseResourcesWidget::HandlePurchaseComplete(bool bSuccess_69, TArray<struct FPurchasedItemInfo> PurchasedItems_69, const struct FString& OfferId_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function BattlePassBase.FortBattlePassPurchaseResourcesWidget.HandlePurchaseComplete"));

	FortBattlePassPurchaseResourcesWidget_HandlePurchaseComplete_Params params;
	params.bSuccess_69 = bSuccess_69;
	params.PurchasedItems_69 = PurchasedItems_69;
	params.OfferId_69 = OfferId_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function BattlePassBase.FortBattlePassRewardGrid.OnPageUnselected
// (Event, Public, BlueprintEvent)

void FortBattlePassRewardGrid::OnPageUnselected()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function BattlePassBase.FortBattlePassRewardGrid.OnPageUnselected"));

	FortBattlePassRewardGrid_OnPageUnselected_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function BattlePassBase.FortBattlePassRewardGrid.OnPageSelected
// (Event, Public, BlueprintEvent)

void FortBattlePassRewardGrid::OnPageSelected()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function BattlePassBase.FortBattlePassRewardGrid.OnPageSelected"));

	FortBattlePassRewardGrid_OnPageSelected_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function BattlePassBase.FortBattlePassRewardGridHeader.OnSetPageType
// (Event, Public, BlueprintEvent)
// Parameters:
// ERewardPageType                PageType_69                    (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void FortBattlePassRewardGridHeader::OnSetPageType(ERewardPageType PageType_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function BattlePassBase.FortBattlePassRewardGridHeader.OnSetPageType"));

	FortBattlePassRewardGridHeader_OnSetPageType_Params params;
	params.PageType_69 = PageType_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function BattlePassBase.FortBattlePassRewardGridHeader.OnSetPageCustomName
// (Event, Public, HasOutParms, BlueprintEvent)
// Parameters:
// struct FText                   CustomName_69                  (ConstParm, Parm, OutParm, ReferenceParm)

void FortBattlePassRewardGridHeader::OnSetPageCustomName(const struct FText& CustomName_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function BattlePassBase.FortBattlePassRewardGridHeader.OnSetPageCustomName"));

	FortBattlePassRewardGridHeader_OnSetPageCustomName_Params params;
	params.CustomName_69 = CustomName_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function BattlePassBase.FortBattlePassRewardGridHeader.OnPageUnlocked
// (Event, Public, BlueprintEvent)
// Parameters:
// int                            PurchasedRewards_69            (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// int                            TotalRewards_69                (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void FortBattlePassRewardGridHeader::OnPageUnlocked(int PurchasedRewards_69, int TotalRewards_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function BattlePassBase.FortBattlePassRewardGridHeader.OnPageUnlocked"));

	FortBattlePassRewardGridHeader_OnPageUnlocked_Params params;
	params.PurchasedRewards_69 = PurchasedRewards_69;
	params.TotalRewards_69 = TotalRewards_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function BattlePassBase.FortBattlePassRewardGridHeader.OnPageNumberSet
// (Event, Public, BlueprintEvent)
// Parameters:
// int                            InPageNumber_69                (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void FortBattlePassRewardGridHeader::OnPageNumberSet(int InPageNumber_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function BattlePassBase.FortBattlePassRewardGridHeader.OnPageNumberSet"));

	FortBattlePassRewardGridHeader_OnPageNumberSet_Params params;
	params.InPageNumber_69 = InPageNumber_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function BattlePassBase.FortBattlePassRewardGridHeader.OnPageLocked
// (Event, Public, HasDefaults, BlueprintEvent)
// Parameters:
// int                            RequiredLevel_69               (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// int                            RequiredRewards_69             (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// bool                           IsTimeLocked_69                (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// struct FTimespan               TimeRemaining_69               (Parm, ZeroConstructor)

void FortBattlePassRewardGridHeader::OnPageLocked(int RequiredLevel_69, int RequiredRewards_69, bool IsTimeLocked_69, const struct FTimespan& TimeRemaining_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function BattlePassBase.FortBattlePassRewardGridHeader.OnPageLocked"));

	FortBattlePassRewardGridHeader_OnPageLocked_Params params;
	params.RequiredLevel_69 = RequiredLevel_69;
	params.RequiredRewards_69 = RequiredRewards_69;
	params.IsTimeLocked_69 = IsTimeLocked_69;
	params.TimeRemaining_69 = TimeRemaining_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function BattlePassBase.FortBattlePassRewardGridHeader.OnBattlePassLevelSet
// (Event, Public, BlueprintEvent)
// Parameters:
// int                            BattlePassLevel_69             (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void FortBattlePassRewardGridHeader::OnBattlePassLevelSet(int BattlePassLevel_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function BattlePassBase.FortBattlePassRewardGridHeader.OnBattlePassLevelSet"));

	FortBattlePassRewardGridHeader_OnBattlePassLevelSet_Params params;
	params.BattlePassLevel_69 = BattlePassLevel_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function BattlePassBase.FortBattlePassRewardGridHeader.GetPageNumber
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// int                            ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int FortBattlePassRewardGridHeader::GetPageNumber()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function BattlePassBase.FortBattlePassRewardGridHeader.GetPageNumber"));

	FortBattlePassRewardGridHeader_GetPageNumber_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function BattlePassBase.FortBattlePassRewardTrack.OnPageUnselected
// (Event, Public, BlueprintEvent)

void FortBattlePassRewardTrack::OnPageUnselected()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function BattlePassBase.FortBattlePassRewardTrack.OnPageUnselected"));

	FortBattlePassRewardTrack_OnPageUnselected_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function BattlePassBase.FortBattlePassRewardTrack.OnPageSelected
// (Event, Public, BlueprintEvent)

void FortBattlePassRewardTrack::OnPageSelected()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function BattlePassBase.FortBattlePassRewardTrack.OnPageSelected"));

	FortBattlePassRewardTrack_OnPageSelected_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function BattlePassBase.FortBattlePassTileBase.SetState
// (Final, Native, Protected, BlueprintCallable)
// Parameters:
// EBattlePassTileAvailabilityStates NewState_69                    (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void FortBattlePassTileBase::SetState(EBattlePassTileAvailabilityStates NewState_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function BattlePassBase.FortBattlePassTileBase.SetState"));

	FortBattlePassTileBase_SetState_Params params;
	params.NewState_69 = NewState_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function BattlePassBase.FortBattlePassTileBase.SetSize
// (Final, Native, Protected, HasOutParms, HasDefaults, BlueprintCallable)
// Parameters:
// EPageItemTileSize              TileSize_69                    (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// struct FVector2D               CellSpacing_69                 (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)

void FortBattlePassTileBase::SetSize(EPageItemTileSize TileSize_69, const struct FVector2D& CellSpacing_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function BattlePassBase.FortBattlePassTileBase.SetSize"));

	FortBattlePassTileBase_SetSize_Params params;
	params.TileSize_69 = TileSize_69;
	params.CellSpacing_69 = CellSpacing_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function BattlePassBase.FortBattlePassTileBase.OnStateChanged
// (Event, Protected, BlueprintEvent)
// Parameters:
// EBattlePassTileAvailabilityStates NewState_69                    (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void FortBattlePassTileBase::OnStateChanged(EBattlePassTileAvailabilityStates NewState_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function BattlePassBase.FortBattlePassTileBase.OnStateChanged"));

	FortBattlePassTileBase_OnStateChanged_Params params;
	params.NewState_69 = NewState_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function BattlePassBase.FortBattlePassTileBase.OnSizeChanged
// (Event, Protected, HasOutParms, HasDefaults, BlueprintEvent)
// Parameters:
// struct FVector2D               NewSize_69                     (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)

void FortBattlePassTileBase::OnSizeChanged(const struct FVector2D& NewSize_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function BattlePassBase.FortBattlePassTileBase.OnSizeChanged"));

	FortBattlePassTileBase_OnSizeChanged_Params params;
	params.NewSize_69 = NewSize_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function BattlePassBase.FortBattlePassTileBase.OnSetTileColors
// (Event, Protected, BlueprintEvent)

void FortBattlePassTileBase::OnSetTileColors()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function BattlePassBase.FortBattlePassTileBase.OnSetTileColors"));

	FortBattlePassTileBase_OnSetTileColors_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function BattlePassBase.FortBattlePassTileBase.OnSetRequiresBattlePass
// (Event, Protected, BlueprintEvent)
// Parameters:
// bool                           bRequiresBP_69                 (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void FortBattlePassTileBase::OnSetRequiresBattlePass(bool bRequiresBP_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function BattlePassBase.FortBattlePassTileBase.OnSetRequiresBattlePass"));

	FortBattlePassTileBase_OnSetRequiresBattlePass_Params params;
	params.bRequiresBP_69 = bRequiresBP_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function BattlePassBase.FortBattlePassTileBase.OnRevealed
// (Event, Public, BlueprintEvent)

void FortBattlePassTileBase::OnRevealed()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function BattlePassBase.FortBattlePassTileBase.OnRevealed"));

	FortBattlePassTileBase_OnRevealed_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function BattlePassBase.FortBattlePassTileBase.OnPeeked
// (Event, Public, BlueprintEvent)

void FortBattlePassTileBase::OnPeeked()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function BattlePassBase.FortBattlePassTileBase.OnPeeked"));

	FortBattlePassTileBase_OnPeeked_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function BattlePassBase.FortBattlePassTileBase.IsOwned
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool FortBattlePassTileBase::IsOwned()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function BattlePassBase.FortBattlePassTileBase.IsOwned"));

	FortBattlePassTileBase_IsOwned_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function BattlePassBase.FortBattlePassTileBase.IsLocked
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool FortBattlePassTileBase::IsLocked()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function BattlePassBase.FortBattlePassTileBase.IsLocked"));

	FortBattlePassTileBase_IsLocked_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function BattlePassBase.FortBattlePassTileBase.IsAvailable
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool FortBattlePassTileBase::IsAvailable()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function BattlePassBase.FortBattlePassTileBase.IsAvailable"));

	FortBattlePassTileBase_IsAvailable_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function BattlePassBase.FortBattlePassTileBase.GetState
// (Final, Native, Protected, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// EBattlePassTileAvailabilityStates ReturnValue_69                 (ConstParm, Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

EBattlePassTileAvailabilityStates FortBattlePassTileBase::GetState()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function BattlePassBase.FortBattlePassTileBase.GetState"));

	FortBattlePassTileBase_GetState_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function BattlePassBase.FortBattlePassTile.OnUnpreviewed
// (Event, Public, BlueprintEvent)

void FortBattlePassTile::OnUnpreviewed()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function BattlePassBase.FortBattlePassTile.OnUnpreviewed"));

	FortBattlePassTile_OnUnpreviewed_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function BattlePassBase.FortBattlePassTile.OnUnhighlighted
// (Event, Protected, BlueprintEvent)

void FortBattlePassTile::OnUnhighlighted()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function BattlePassBase.FortBattlePassTile.OnUnhighlighted"));

	FortBattlePassTile_OnUnhighlighted_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function BattlePassBase.FortBattlePassTile.OnTilePreviewCycled
// (Event, Protected, BlueprintEvent)

void FortBattlePassTile::OnTilePreviewCycled()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function BattlePassBase.FortBattlePassTile.OnTilePreviewCycled"));

	FortBattlePassTile_OnTilePreviewCycled_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function BattlePassBase.FortBattlePassTile.OnSetTrack
// (Event, Protected, BlueprintEvent)
// Parameters:
// bool                           bIsFreeTrack_69                (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// bool                           bOwnsBattlePass_69             (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void FortBattlePassTile::OnSetTrack(bool bIsFreeTrack_69, bool bOwnsBattlePass_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function BattlePassBase.FortBattlePassTile.OnSetTrack"));

	FortBattlePassTile_OnSetTrack_Params params;
	params.bIsFreeTrack_69 = bIsFreeTrack_69;
	params.bOwnsBattlePass_69 = bOwnsBattlePass_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function BattlePassBase.FortBattlePassTile.OnSetCurrencyAndPrice
// (Event, Protected, BlueprintEvent)
// Parameters:
// EBattlePassCurrencyType        Currency_69                    (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// int                            Price_69                       (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void FortBattlePassTile::OnSetCurrencyAndPrice(EBattlePassCurrencyType Currency_69, int Price_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function BattlePassBase.FortBattlePassTile.OnSetCurrencyAndPrice"));

	FortBattlePassTile_OnSetCurrencyAndPrice_Params params;
	params.Currency_69 = Currency_69;
	params.Price_69 = Price_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function BattlePassBase.FortBattlePassTile.OnPreviewed
// (Event, Public, BlueprintEvent)

void FortBattlePassTile::OnPreviewed()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function BattlePassBase.FortBattlePassTile.OnPreviewed"));

	FortBattlePassTile_OnPreviewed_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function BattlePassBase.FortBattlePassTile.OnLockedStateUpdated
// (Event, Protected, BlueprintEvent)
// Parameters:
// bool                           OwnsBattlePass_69              (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// bool                           ParentUnlocked_69              (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// bool                           HasRemainingPrerequisites_69   (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// bool                           bIsDelayed_69                  (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void FortBattlePassTile::OnLockedStateUpdated(bool OwnsBattlePass_69, bool ParentUnlocked_69, bool HasRemainingPrerequisites_69, bool bIsDelayed_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function BattlePassBase.FortBattlePassTile.OnLockedStateUpdated"));

	FortBattlePassTile_OnLockedStateUpdated_Params params;
	params.OwnsBattlePass_69 = OwnsBattlePass_69;
	params.ParentUnlocked_69 = ParentUnlocked_69;
	params.HasRemainingPrerequisites_69 = HasRemainingPrerequisites_69;
	params.bIsDelayed_69 = bIsDelayed_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function BattlePassBase.FortBattlePassTile.OnLockedProgressUpdated
// (Event, Protected, BlueprintEvent)
// Parameters:
// float                          Progress_69                    (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// int                            CurrentlyOwnedRewards_69       (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// int                            NeededRewards_69               (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void FortBattlePassTile::OnLockedProgressUpdated(float Progress_69, int CurrentlyOwnedRewards_69, int NeededRewards_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function BattlePassBase.FortBattlePassTile.OnLockedProgressUpdated"));

	FortBattlePassTile_OnLockedProgressUpdated_Params params;
	params.Progress_69 = Progress_69;
	params.CurrentlyOwnedRewards_69 = CurrentlyOwnedRewards_69;
	params.NeededRewards_69 = NeededRewards_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function BattlePassBase.FortBattlePassTile.OnHighlighted
// (Event, Protected, BlueprintEvent)

void FortBattlePassTile::OnHighlighted()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function BattlePassBase.FortBattlePassTile.OnHighlighted"));

	FortBattlePassTile_OnHighlighted_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function BattlePassBase.FortBattlePassTile.OnAffordabilityChanged
// (Event, Protected, BlueprintEvent)
// Parameters:
// bool                           bHasEnougCurrency_69           (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void FortBattlePassTile::OnAffordabilityChanged(bool bHasEnougCurrency_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function BattlePassBase.FortBattlePassTile.OnAffordabilityChanged"));

	FortBattlePassTile_OnAffordabilityChanged_Params params;
	params.bHasEnougCurrency_69 = bHasEnougCurrency_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function BattlePassBase.FortBattlePassTile.IsAffordable
// (Final, Native, Protected, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool FortBattlePassTile::IsAffordable()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function BattlePassBase.FortBattlePassTile.IsAffordable"));

	FortBattlePassTile_IsAffordable_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function BattlePassBase.FortBattlePassTile.HasPrerequisites
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool FortBattlePassTile::HasPrerequisites()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function BattlePassBase.FortBattlePassTile.HasPrerequisites"));

	FortBattlePassTile_HasPrerequisites_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function BattlePassBase.FortBattlePassTutorialTooltip.ShowTooltip
// (Event, Protected, BlueprintEvent)

void FortBattlePassTutorialTooltip::ShowTooltip()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function BattlePassBase.FortBattlePassTutorialTooltip.ShowTooltip"));

	FortBattlePassTutorialTooltip_ShowTooltip_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function BattlePassBase.FortBattlePassTutorialTooltip.SetTooltipEnabled
// (Final, RequiredAPI, Native, Public, BlueprintCallable)
// Parameters:
// bool                           bEnable_69                     (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void FortBattlePassTutorialTooltip::SetTooltipEnabled(bool bEnable_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function BattlePassBase.FortBattlePassTutorialTooltip.SetTooltipEnabled"));

	FortBattlePassTutorialTooltip_SetTooltipEnabled_Params params;
	params.bEnable_69 = bEnable_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function BattlePassBase.FortBattlePassTutorialTooltip.SetText
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// struct FText                   Text_69                        (Parm)

void FortBattlePassTutorialTooltip::SetText(const struct FText& Text_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function BattlePassBase.FortBattlePassTutorialTooltip.SetText"));

	FortBattlePassTutorialTooltip_SetText_Params params;
	params.Text_69 = Text_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function BattlePassBase.FortBattlePassTutorialTooltip.HideTooltip
// (Event, Protected, BlueprintEvent)

void FortBattlePassTutorialTooltip::HideTooltip()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function BattlePassBase.FortBattlePassTutorialTooltip.HideTooltip"));

	FortBattlePassTutorialTooltip_HideTooltip_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

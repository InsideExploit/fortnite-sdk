#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function AugmentedReality.ARActor.AddARComponent
struct ARActor_AddARComponent_Params
{
	class ARComponent*                                 InComponentClass_69;                                      // (Parm, ZeroConstructor)
	struct FGuid                                       NativeID_69;                                              // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
	class ARComponent*                                 ReturnValue_69;                                           // (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)
};

// Function AugmentedReality.ARBlueprintLibrary.UnpinComponent
struct ARBlueprintLibrary_UnpinComponent_Params
{
	class SceneComponent*                              ComponentToUnpin_69;                                      // (Parm, ZeroConstructor, InstancedReference)
};

// Function AugmentedReality.ARBlueprintLibrary.ToggleARCapture
struct ARBlueprintLibrary_ToggleARCapture_Params
{
	bool                                               bOnOff_69;                                                // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	EARCaptureType                                     CaptureType_69;                                           // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AugmentedReality.ARBlueprintLibrary.StopARSession
struct ARBlueprintLibrary_StopARSession_Params
{
};

// Function AugmentedReality.ARBlueprintLibrary.StartARSession
struct ARBlueprintLibrary_StartARSession_Params
{
	class ARSessionConfig*                             SessionConfig_69;                                         // (Parm, ZeroConstructor)
};

// Function AugmentedReality.ARBlueprintLibrary.SetEnabledXRCamera
struct ARBlueprintLibrary_SetEnabledXRCamera_Params
{
	bool                                               bOnOff_69;                                                // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function AugmentedReality.ARBlueprintLibrary.SetARWorldScale
struct ARBlueprintLibrary_SetARWorldScale_Params
{
	float                                              InWorldScale_69;                                          // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function AugmentedReality.ARBlueprintLibrary.SetARWorldOriginLocationAndRotation
struct ARBlueprintLibrary_SetARWorldOriginLocationAndRotation_Params
{
	struct FVector                                     OriginLocation_69;                                        // (Parm, ZeroConstructor, IsPlainOldData)
	struct FRotator                                    OriginRotation_69;                                        // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bIsTransformInWorldSpace_69;                              // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bMaintainUpDirection_69;                                  // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function AugmentedReality.ARBlueprintLibrary.SetAlignmentTransform
struct ARBlueprintLibrary_SetAlignmentTransform_Params
{
	struct FCoreUObject_FTransform                     InAlignmentTransform_69;                                  // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
};

// Function AugmentedReality.ARBlueprintLibrary.SaveARPinToLocalStore
struct ARBlueprintLibrary_SaveARPinToLocalStore_Params
{
	struct FName                                       InSaveName_69;                                            // (Parm, ZeroConstructor, IsPlainOldData)
	class ARPin*                                       InPin_69;                                                 // (Parm, ZeroConstructor)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AugmentedReality.ARBlueprintLibrary.ResizeXRCamera
struct ARBlueprintLibrary_ResizeXRCamera_Params
{
	struct FIntPoint                                   InSize_69;                                                // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
	struct FIntPoint                                   ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AugmentedReality.ARBlueprintLibrary.RemovePin
struct ARBlueprintLibrary_RemovePin_Params
{
	class ARPin*                                       PinToRemove_69;                                           // (Parm, ZeroConstructor)
};

// Function AugmentedReality.ARBlueprintLibrary.RemoveARPinFromLocalStore
struct ARBlueprintLibrary_RemoveARPinFromLocalStore_Params
{
	struct FName                                       InSaveName_69;                                            // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function AugmentedReality.ARBlueprintLibrary.RemoveAllARPinsFromLocalStore
struct ARBlueprintLibrary_RemoveAllARPinsFromLocalStore_Params
{
};

// Function AugmentedReality.ARBlueprintLibrary.PinComponentToTraceResult
struct ARBlueprintLibrary_PinComponentToTraceResult_Params
{
	class SceneComponent*                              ComponentToPin_69;                                        // (Parm, ZeroConstructor, InstancedReference)
	struct FARTraceResult                              TraceResult_69;                                           // (ConstParm, Parm, OutParm, ReferenceParm)
	struct FName                                       DebugName_69;                                             // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	class ARPin*                                       ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function AugmentedReality.ARBlueprintLibrary.PinComponentToARPin
struct ARBlueprintLibrary_PinComponentToARPin_Params
{
	class SceneComponent*                              ComponentToPin_69;                                        // (Parm, ZeroConstructor, InstancedReference)
	class ARPin*                                       Pin_69;                                                   // (Parm, ZeroConstructor)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AugmentedReality.ARBlueprintLibrary.PinComponent
struct ARBlueprintLibrary_PinComponent_Params
{
	class SceneComponent*                              ComponentToPin_69;                                        // (Parm, ZeroConstructor, InstancedReference)
	struct FCoreUObject_FTransform                     PinToWorldTransform_69;                                   // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	class ARTrackedGeometry*                           TrackedGeometry_69;                                       // (Parm, ZeroConstructor)
	struct FName                                       DebugName_69;                                             // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	class ARPin*                                       ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function AugmentedReality.ARBlueprintLibrary.PauseARSession
struct ARBlueprintLibrary_PauseARSession_Params
{
};

// Function AugmentedReality.ARBlueprintLibrary.LoadARPinsFromLocalStore
struct ARBlueprintLibrary_LoadARPinsFromLocalStore_Params
{
	TMap<struct FName, class ARPin*>                   ReturnValue_69;                                           // (Parm, OutParm, ReturnParm)
};

// Function AugmentedReality.ARBlueprintLibrary.LineTraceTrackedObjects3D
struct ARBlueprintLibrary_LineTraceTrackedObjects3D_Params
{
	struct FVector                                     Start_69;                                                 // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	struct FVector                                     End_69;                                                   // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bTestFeaturePoints_69;                                    // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bTestGroundPlane_69;                                      // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bTestPlaneExtents_69;                                     // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bTestPlaneBoundaryPolygon_69;                             // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<struct FARTraceResult>                      ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function AugmentedReality.ARBlueprintLibrary.LineTraceTrackedObjects
struct ARBlueprintLibrary_LineTraceTrackedObjects_Params
{
	struct FVector2D                                   ScreenCoord_69;                                           // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bTestFeaturePoints_69;                                    // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bTestGroundPlane_69;                                      // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bTestPlaneExtents_69;                                     // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bTestPlaneBoundaryPolygon_69;                             // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<struct FARTraceResult>                      ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function AugmentedReality.ARBlueprintLibrary.IsSessionTypeSupported
struct ARBlueprintLibrary_IsSessionTypeSupported_Params
{
	EARSessionType                                     SessionType_69;                                           // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AugmentedReality.ARBlueprintLibrary.IsSessionTrackingFeatureSupported
struct ARBlueprintLibrary_IsSessionTrackingFeatureSupported_Params
{
	EARSessionType                                     SessionType_69;                                           // (Parm, ZeroConstructor, IsPlainOldData)
	EARSessionTrackingFeature                          SessionTrackingFeature_69;                                // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AugmentedReality.ARBlueprintLibrary.IsSceneReconstructionSupported
struct ARBlueprintLibrary_IsSceneReconstructionSupported_Params
{
	EARSessionType                                     SessionType_69;                                           // (Parm, ZeroConstructor, IsPlainOldData)
	EARSceneReconstruction                             SceneReconstructionMethod_69;                             // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AugmentedReality.ARBlueprintLibrary.IsARSupported
struct ARBlueprintLibrary_IsARSupported_Params
{
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AugmentedReality.ARBlueprintLibrary.IsARPinLocalStoreSupported
struct ARBlueprintLibrary_IsARPinLocalStoreSupported_Params
{
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AugmentedReality.ARBlueprintLibrary.IsARPinLocalStoreReady
struct ARBlueprintLibrary_IsARPinLocalStoreReady_Params
{
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AugmentedReality.ARBlueprintLibrary.GetWorldMappingStatus
struct ARBlueprintLibrary_GetWorldMappingStatus_Params
{
	EARWorldMappingState                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AugmentedReality.ARBlueprintLibrary.GetTrackingQualityReason
struct ARBlueprintLibrary_GetTrackingQualityReason_Params
{
	EARTrackingQualityReason                           ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AugmentedReality.ARBlueprintLibrary.GetTrackingQuality
struct ARBlueprintLibrary_GetTrackingQuality_Params
{
	EARTrackingQuality                                 ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AugmentedReality.ARBlueprintLibrary.GetSupportedVideoFormats
struct ARBlueprintLibrary_GetSupportedVideoFormats_Params
{
	EARSessionType                                     SessionType_69;                                           // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<struct FARVideoFormat>                      ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function AugmentedReality.ARBlueprintLibrary.GetSessionConfig
struct ARBlueprintLibrary_GetSessionConfig_Params
{
	class ARSessionConfig*                             ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function AugmentedReality.ARBlueprintLibrary.GetPointCloud
struct ARBlueprintLibrary_GetPointCloud_Params
{
	TArray<struct FVector>                             ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function AugmentedReality.ARBlueprintLibrary.GetPersonSegmentationImage
struct ARBlueprintLibrary_GetPersonSegmentationImage_Params
{
	class ARTexture*                                   ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function AugmentedReality.ARBlueprintLibrary.GetPersonSegmentationDepthImage
struct ARBlueprintLibrary_GetPersonSegmentationDepthImage_Params
{
	class ARTexture*                                   ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function AugmentedReality.ARBlueprintLibrary.GetObjectClassificationAtLocation
struct ARBlueprintLibrary_GetObjectClassificationAtLocation_Params
{
	struct FVector                                     InWorldLocation_69;                                       // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
	EARObjectClassification                            OutClassification_69;                                     // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	struct FVector                                     OutClassificationLocation_69;                             // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	float                                              MaxLocationDiff_69;                                       // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AugmentedReality.ARBlueprintLibrary.GetNumberOfTrackedFacesSupported
struct ARBlueprintLibrary_GetNumberOfTrackedFacesSupported_Params
{
	int                                                ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AugmentedReality.ARBlueprintLibrary.GetCurrentLightEstimate
struct ARBlueprintLibrary_GetCurrentLightEstimate_Params
{
	class ARLightEstimate*                             ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function AugmentedReality.ARBlueprintLibrary.GetCameraIntrinsics
struct ARBlueprintLibrary_GetCameraIntrinsics_Params
{
	struct FARCameraIntrinsics                         OutCameraIntrinsics_69;                                   // (Parm, OutParm)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AugmentedReality.ARBlueprintLibrary.GetCameraImage
struct ARBlueprintLibrary_GetCameraImage_Params
{
	class ARTextureCameraImage*                        ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function AugmentedReality.ARBlueprintLibrary.GetCameraDepth
struct ARBlueprintLibrary_GetCameraDepth_Params
{
	class ARTextureCameraDepth*                        ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function AugmentedReality.ARBlueprintLibrary.GetARWorldScale
struct ARBlueprintLibrary_GetARWorldScale_Params
{
	float                                              ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AugmentedReality.ARBlueprintLibrary.GetARTexture
struct ARBlueprintLibrary_GetARTexture_Params
{
	EARTextureType                                     TextureType_69;                                           // (Parm, ZeroConstructor, IsPlainOldData)
	class ARTexture*                                   ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function AugmentedReality.ARBlueprintLibrary.GetARSessionStatus
struct ARBlueprintLibrary_GetARSessionStatus_Params
{
	struct FARSessionStatus                            ReturnValue_69;                                           // (Parm, OutParm, ReturnParm)
};

// Function AugmentedReality.ARBlueprintLibrary.GetAllTrackedPoses
struct ARBlueprintLibrary_GetAllTrackedPoses_Params
{
	TArray<class ARTrackedPose*>                       ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function AugmentedReality.ARBlueprintLibrary.GetAllTrackedPoints
struct ARBlueprintLibrary_GetAllTrackedPoints_Params
{
	TArray<class ARTrackedPoint*>                      ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function AugmentedReality.ARBlueprintLibrary.GetAllTrackedPlanes
struct ARBlueprintLibrary_GetAllTrackedPlanes_Params
{
	TArray<class ARPlaneGeometry*>                     ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function AugmentedReality.ARBlueprintLibrary.GetAllTrackedImages
struct ARBlueprintLibrary_GetAllTrackedImages_Params
{
	TArray<class ARTrackedImage*>                      ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function AugmentedReality.ARBlueprintLibrary.GetAllTrackedEnvironmentCaptureProbes
struct ARBlueprintLibrary_GetAllTrackedEnvironmentCaptureProbes_Params
{
	TArray<class AREnvironmentCaptureProbe*>           ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function AugmentedReality.ARBlueprintLibrary.GetAllTracked2DPoses
struct ARBlueprintLibrary_GetAllTracked2DPoses_Params
{
	TArray<struct FARPose2D>                           ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function AugmentedReality.ARBlueprintLibrary.GetAllPins
struct ARBlueprintLibrary_GetAllPins_Params
{
	TArray<class ARPin*>                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function AugmentedReality.ARBlueprintLibrary.GetAllGeometriesByClass
struct ARBlueprintLibrary_GetAllGeometriesByClass_Params
{
	class ARTrackedGeometry*                           GeometryClass_69;                                         // (Parm, ZeroConstructor)
	TArray<class ARTrackedGeometry*>                   ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function AugmentedReality.ARBlueprintLibrary.GetAllGeometries
struct ARBlueprintLibrary_GetAllGeometries_Params
{
	TArray<class ARTrackedGeometry*>                   ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function AugmentedReality.ARBlueprintLibrary.GetAlignmentTransform
struct ARBlueprintLibrary_GetAlignmentTransform_Params
{
	struct FCoreUObject_FTransform                     ReturnValue_69;                                           // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function AugmentedReality.ARBlueprintLibrary.FindTrackedPointsByName
struct ARBlueprintLibrary_FindTrackedPointsByName_Params
{
	struct FString                                     PointName_69;                                             // (Parm, ZeroConstructor)
	TArray<class ARTrackedPoint*>                      ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function AugmentedReality.ARBlueprintLibrary.DebugDrawTrackedGeometry
struct ARBlueprintLibrary_DebugDrawTrackedGeometry_Params
{
	class ARTrackedGeometry*                           TrackedGeometry_69;                                       // (Parm, ZeroConstructor)
	class Object_32759*                                WorldContextObject_69;                                    // (Parm, ZeroConstructor)
	struct FLinearColor                                Color_69;                                                 // (Parm, ZeroConstructor, IsPlainOldData)
	float                                              OutlineThickness_69;                                      // (Parm, ZeroConstructor, IsPlainOldData)
	float                                              PersistForSeconds_69;                                     // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function AugmentedReality.ARBlueprintLibrary.DebugDrawPin
struct ARBlueprintLibrary_DebugDrawPin_Params
{
	class ARPin*                                       ARPin_69;                                                 // (Parm, ZeroConstructor)
	class Object_32759*                                WorldContextObject_69;                                    // (Parm, ZeroConstructor)
	struct FLinearColor                                Color_69;                                                 // (Parm, ZeroConstructor, IsPlainOldData)
	float                                              Scale_69;                                                 // (Parm, ZeroConstructor, IsPlainOldData)
	float                                              PersistForSeconds_69;                                     // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function AugmentedReality.ARBlueprintLibrary.CalculateClosestIntersection
struct ARBlueprintLibrary_CalculateClosestIntersection_Params
{
	TArray<struct FVector>                             StartPoints_69;                                           // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	TArray<struct FVector>                             EndPoints_69;                                             // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	struct FVector                                     ClosestIntersection_69;                                   // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
};

// Function AugmentedReality.ARBlueprintLibrary.CalculateAlignmentTransform
struct ARBlueprintLibrary_CalculateAlignmentTransform_Params
{
	struct FCoreUObject_FTransform                     TransformInFirstCoordinateSystem_69;                      // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	struct FCoreUObject_FTransform                     TransformInSecondCoordinateSystem_69;                     // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	struct FCoreUObject_FTransform                     AlignmentTransform_69;                                    // (Parm, OutParm, IsPlainOldData)
};

// Function AugmentedReality.ARBlueprintLibrary.AddTrackedPointWithName
struct ARBlueprintLibrary_AddTrackedPointWithName_Params
{
	struct FCoreUObject_FTransform                     WorldTransform_69;                                        // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	struct FString                                     PointName_69;                                             // (Parm, ZeroConstructor)
	bool                                               bDeletePointsWithSameName_69;                             // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AugmentedReality.ARBlueprintLibrary.AddRuntimeCandidateImage
struct ARBlueprintLibrary_AddRuntimeCandidateImage_Params
{
	class ARSessionConfig*                             SessionConfig_69;                                         // (Parm, ZeroConstructor)
	class Texture2D*                                   CandidateTexture_69;                                      // (Parm, ZeroConstructor)
	struct FString                                     FriendlyName_69;                                          // (Parm, ZeroConstructor)
	float                                              PhysicalWidth_69;                                         // (Parm, ZeroConstructor, IsPlainOldData)
	class ARCandidateImage*                            ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function AugmentedReality.ARBlueprintLibrary.AddManualEnvironmentCaptureProbe
struct ARBlueprintLibrary_AddManualEnvironmentCaptureProbe_Params
{
	struct FVector                                     Location_69;                                              // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector                                     Extent_69;                                                // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AugmentedReality.ARTraceResultLibrary_32759.GetTrackedGeometry
struct ARTraceResultLibrary_32759_GetTrackedGeometry_Params
{
	struct FARTraceResult                              TraceResult_69;                                           // (ConstParm, Parm, OutParm, ReferenceParm)
	class ARTrackedGeometry*                           ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function AugmentedReality.ARTraceResultLibrary_32759.GetTraceChannel
struct ARTraceResultLibrary_32759_GetTraceChannel_Params
{
	struct FARTraceResult                              TraceResult_69;                                           // (ConstParm, Parm, OutParm, ReferenceParm)
	EARLineTraceChannels                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AugmentedReality.ARTraceResultLibrary_32759.GetLocalTransform
struct ARTraceResultLibrary_32759_GetLocalTransform_Params
{
	struct FARTraceResult                              TraceResult_69;                                           // (ConstParm, Parm, OutParm, ReferenceParm)
	struct FCoreUObject_FTransform                     ReturnValue_69;                                           // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function AugmentedReality.ARTraceResultLibrary_32759.GetLocalToWorldTransform
struct ARTraceResultLibrary_32759_GetLocalToWorldTransform_Params
{
	struct FARTraceResult                              TraceResult_69;                                           // (ConstParm, Parm, OutParm, ReferenceParm)
	struct FCoreUObject_FTransform                     ReturnValue_69;                                           // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function AugmentedReality.ARTraceResultLibrary_32759.GetLocalToTrackingTransform
struct ARTraceResultLibrary_32759_GetLocalToTrackingTransform_Params
{
	struct FARTraceResult                              TraceResult_69;                                           // (ConstParm, Parm, OutParm, ReferenceParm)
	struct FCoreUObject_FTransform                     ReturnValue_69;                                           // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function AugmentedReality.ARTraceResultLibrary_32759.GetDistanceFromCamera
struct ARTraceResultLibrary_32759_GetDistanceFromCamera_Params
{
	struct FARTraceResult                              TraceResult_69;                                           // (ConstParm, Parm, OutParm, ReferenceParm)
	float                                              ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AugmentedReality.ARSaveWorldAsyncTaskBlueprintProxy.ARSaveWorld
struct ARSaveWorldAsyncTaskBlueprintProxy_ARSaveWorld_Params
{
	class Object_32759*                                WorldContextObject_69;                                    // (Parm, ZeroConstructor)
	class ARSaveWorldAsyncTaskBlueprintProxy*          ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function AugmentedReality.ARGetCandidateObjectAsyncTaskBlueprintProxy.ARGetCandidateObject
struct ARGetCandidateObjectAsyncTaskBlueprintProxy_ARGetCandidateObject_Params
{
	class Object_32759*                                WorldContextObject_69;                                    // (Parm, ZeroConstructor)
	struct FVector                                     Location_69;                                              // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector                                     Extent_69;                                                // (Parm, ZeroConstructor, IsPlainOldData)
	class ARGetCandidateObjectAsyncTaskBlueprintProxy* ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function AugmentedReality.ARComponent.UpdateVisualization
struct ARComponent_UpdateVisualization_Params
{
};

// Function AugmentedReality.ARComponent.SetNativeID
struct ARComponent_SetNativeID_Params
{
	struct FGuid                                       NativeID_69;                                              // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function AugmentedReality.ARComponent.ReceiveRemove
struct ARComponent_ReceiveRemove_Params
{
};

// Function AugmentedReality.ARComponent.OnRep_Payload
struct ARComponent_OnRep_Payload_Params
{
};

// Function AugmentedReality.ARComponent.GetMRMesh
struct ARComponent_GetMRMesh_Params
{
	class MRMeshComponent*                             ReturnValue_69;                                           // (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)
};

// Function AugmentedReality.ARPlaneComponent.SetPlaneComponentDebugMode
struct ARPlaneComponent_SetPlaneComponentDebugMode_Params
{
	EPlaneComponentDebugMode                           NewDebugMode_69;                                          // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function AugmentedReality.ARPlaneComponent.SetObjectClassificationDebugColors
struct ARPlaneComponent_SetObjectClassificationDebugColors_Params
{
	TMap<EARObjectClassification, struct FLinearColor> InColors_69;                                              // (ConstParm, Parm, OutParm, ReferenceParm)
};

// Function AugmentedReality.ARPlaneComponent.ServerUpdatePayload
struct ARPlaneComponent_ServerUpdatePayload_Params
{
	struct FARPlaneUpdatePayload                       NewPayload_69;                                            // (ConstParm, Parm, ReferenceParm)
};

// Function AugmentedReality.ARPlaneComponent.ReceiveUpdate
struct ARPlaneComponent_ReceiveUpdate_Params
{
	struct FARPlaneUpdatePayload                       Payload_69;                                               // (ConstParm, Parm, OutParm, ReferenceParm)
};

// Function AugmentedReality.ARPlaneComponent.ReceiveAdd
struct ARPlaneComponent_ReceiveAdd_Params
{
	struct FARPlaneUpdatePayload                       Payload_69;                                               // (ConstParm, Parm, OutParm, ReferenceParm)
};

// Function AugmentedReality.ARPlaneComponent.GetObjectClassificationDebugColors
struct ARPlaneComponent_GetObjectClassificationDebugColors_Params
{
	TMap<EARObjectClassification, struct FLinearColor> ReturnValue_69;                                           // (ConstParm, Parm, OutParm, ReturnParm, ReferenceParm)
};

// Function AugmentedReality.ARPointComponent.ServerUpdatePayload
struct ARPointComponent_ServerUpdatePayload_Params
{
	struct FARPointUpdatePayload                       NewPayload_69;                                            // (ConstParm, Parm, ZeroConstructor, ReferenceParm, IsPlainOldData)
};

// Function AugmentedReality.ARPointComponent.ReceiveUpdate
struct ARPointComponent_ReceiveUpdate_Params
{
	struct FARPointUpdatePayload                       Payload_69;                                               // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
};

// Function AugmentedReality.ARPointComponent.ReceiveAdd
struct ARPointComponent_ReceiveAdd_Params
{
	struct FARPointUpdatePayload                       Payload_69;                                               // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
};

// Function AugmentedReality.ARFaceComponent.SetFaceComponentDebugMode
struct ARFaceComponent_SetFaceComponentDebugMode_Params
{
	EFaceComponentDebugMode                            NewDebugMode_69;                                          // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function AugmentedReality.ARFaceComponent.ServerUpdatePayload
struct ARFaceComponent_ServerUpdatePayload_Params
{
	struct FARFaceUpdatePayload                        NewPayload_69;                                            // (ConstParm, Parm, ReferenceParm)
};

// Function AugmentedReality.ARFaceComponent.ReceiveUpdate
struct ARFaceComponent_ReceiveUpdate_Params
{
	struct FARFaceUpdatePayload                        Payload_69;                                               // (ConstParm, Parm, OutParm, ReferenceParm)
};

// Function AugmentedReality.ARFaceComponent.ReceiveAdd
struct ARFaceComponent_ReceiveAdd_Params
{
	struct FARFaceUpdatePayload                        Payload_69;                                               // (ConstParm, Parm, OutParm, ReferenceParm)
};

// Function AugmentedReality.ARImageComponent.SetImageComponentDebugMode
struct ARImageComponent_SetImageComponentDebugMode_Params
{
	EImageComponentDebugMode                           NewDebugMode_69;                                          // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function AugmentedReality.ARImageComponent.ServerUpdatePayload
struct ARImageComponent_ServerUpdatePayload_Params
{
	struct FARImageUpdatePayload                       NewPayload_69;                                            // (ConstParm, Parm, ReferenceParm)
};

// Function AugmentedReality.ARImageComponent.ReceiveUpdate
struct ARImageComponent_ReceiveUpdate_Params
{
	struct FARImageUpdatePayload                       Payload_69;                                               // (ConstParm, Parm, OutParm, ReferenceParm)
};

// Function AugmentedReality.ARImageComponent.ReceiveAdd
struct ARImageComponent_ReceiveAdd_Params
{
	struct FARImageUpdatePayload                       Payload_69;                                               // (ConstParm, Parm, OutParm, ReferenceParm)
};

// Function AugmentedReality.ARQRCodeComponent.SetQRCodeComponentDebugMode
struct ARQRCodeComponent_SetQRCodeComponentDebugMode_Params
{
	EQRCodeComponentDebugMode                          NewDebugMode_69;                                          // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function AugmentedReality.ARQRCodeComponent.ServerUpdatePayload
struct ARQRCodeComponent_ServerUpdatePayload_Params
{
	struct FARQRCodeUpdatePayload                      NewPayload_69;                                            // (ConstParm, Parm, ReferenceParm)
};

// Function AugmentedReality.ARQRCodeComponent.ReceiveUpdate
struct ARQRCodeComponent_ReceiveUpdate_Params
{
	struct FARQRCodeUpdatePayload                      Payload_69;                                               // (ConstParm, Parm, OutParm, ReferenceParm)
};

// Function AugmentedReality.ARQRCodeComponent.ReceiveAdd
struct ARQRCodeComponent_ReceiveAdd_Params
{
	struct FARQRCodeUpdatePayload                      Payload_69;                                               // (ConstParm, Parm, OutParm, ReferenceParm)
};

// Function AugmentedReality.ARPoseComponent.SetPoseComponentDebugMode
struct ARPoseComponent_SetPoseComponentDebugMode_Params
{
	EPoseComponentDebugMode                            NewDebugMode_69;                                          // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function AugmentedReality.ARPoseComponent.ServerUpdatePayload
struct ARPoseComponent_ServerUpdatePayload_Params
{
	struct FARPoseUpdatePayload                        NewPayload_69;                                            // (ConstParm, Parm, ReferenceParm)
};

// Function AugmentedReality.ARPoseComponent.ReceiveUpdate
struct ARPoseComponent_ReceiveUpdate_Params
{
	struct FARPoseUpdatePayload                        Payload_69;                                               // (ConstParm, Parm, OutParm, ReferenceParm)
};

// Function AugmentedReality.ARPoseComponent.ReceiveAdd
struct ARPoseComponent_ReceiveAdd_Params
{
	struct FARPoseUpdatePayload                        Payload_69;                                               // (ConstParm, Parm, OutParm, ReferenceParm)
};

// Function AugmentedReality.AREnvironmentProbeComponent.ServerUpdatePayload
struct AREnvironmentProbeComponent_ServerUpdatePayload_Params
{
	struct FAREnvironmentProbeUpdatePayload            NewPayload_69;                                            // (ConstParm, Parm, ReferenceParm)
};

// Function AugmentedReality.AREnvironmentProbeComponent.ReceiveUpdate
struct AREnvironmentProbeComponent_ReceiveUpdate_Params
{
	struct FAREnvironmentProbeUpdatePayload            Payload_69;                                               // (ConstParm, Parm, OutParm, ReferenceParm)
};

// Function AugmentedReality.AREnvironmentProbeComponent.ReceiveAdd
struct AREnvironmentProbeComponent_ReceiveAdd_Params
{
	struct FAREnvironmentProbeUpdatePayload            Payload_69;                                               // (ConstParm, Parm, OutParm, ReferenceParm)
};

// Function AugmentedReality.ARObjectComponent.ServerUpdatePayload
struct ARObjectComponent_ServerUpdatePayload_Params
{
	struct FARObjectUpdatePayload                      NewPayload_69;                                            // (ConstParm, Parm, ReferenceParm)
};

// Function AugmentedReality.ARObjectComponent.ReceiveUpdate
struct ARObjectComponent_ReceiveUpdate_Params
{
	struct FARObjectUpdatePayload                      Payload_69;                                               // (ConstParm, Parm, OutParm, ReferenceParm)
};

// Function AugmentedReality.ARObjectComponent.ReceiveAdd
struct ARObjectComponent_ReceiveAdd_Params
{
	struct FARObjectUpdatePayload                      Payload_69;                                               // (ConstParm, Parm, OutParm, ReferenceParm)
};

// Function AugmentedReality.ARMeshComponent.ServerUpdatePayload
struct ARMeshComponent_ServerUpdatePayload_Params
{
	struct FARMeshUpdatePayload                        NewPayload_69;                                            // (ConstParm, Parm, ReferenceParm)
};

// Function AugmentedReality.ARMeshComponent.ReceiveUpdate
struct ARMeshComponent_ReceiveUpdate_Params
{
	struct FARMeshUpdatePayload                        Payload_69;                                               // (ConstParm, Parm, OutParm, ReferenceParm)
};

// Function AugmentedReality.ARMeshComponent.ReceiveAdd
struct ARMeshComponent_ReceiveAdd_Params
{
	struct FARMeshUpdatePayload                        Payload_69;                                               // (ConstParm, Parm, OutParm, ReferenceParm)
};

// Function AugmentedReality.ARGeoAnchorComponent.SetGeoAnchorComponentDebugMode
struct ARGeoAnchorComponent_SetGeoAnchorComponentDebugMode_Params
{
	EGeoAnchorComponentDebugMode                       NewDebugMode_69;                                          // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function AugmentedReality.ARGeoAnchorComponent.ServerUpdatePayload
struct ARGeoAnchorComponent_ServerUpdatePayload_Params
{
	struct FARGeoAnchorUpdatePayload                   NewPayload_69;                                            // (ConstParm, Parm, ReferenceParm)
};

// Function AugmentedReality.ARGeoAnchorComponent.ReceiveUpdate
struct ARGeoAnchorComponent_ReceiveUpdate_Params
{
	struct FARGeoAnchorUpdatePayload                   Payload_69;                                               // (ConstParm, Parm, OutParm, ReferenceParm)
};

// Function AugmentedReality.ARGeoAnchorComponent.ReceiveAdd
struct ARGeoAnchorComponent_ReceiveAdd_Params
{
	struct FARGeoAnchorUpdatePayload                   Payload_69;                                               // (ConstParm, Parm, OutParm, ReferenceParm)
};

// Function AugmentedReality.ARDependencyHandler.StartARSessionLatent
struct ARDependencyHandler_StartARSessionLatent_Params
{
	class Object_32759*                                WorldContextObject_69;                                    // (Parm, ZeroConstructor)
	class ARSessionConfig*                             SessionConfig_69;                                         // (Parm, ZeroConstructor)
	struct FLatentActionInfo                           LatentInfo_69;                                            // (Parm)
};

// Function AugmentedReality.ARDependencyHandler.RequestARSessionPermission
struct ARDependencyHandler_RequestARSessionPermission_Params
{
	class Object_32759*                                WorldContextObject_69;                                    // (Parm, ZeroConstructor)
	class ARSessionConfig*                             SessionConfig_69;                                         // (Parm, ZeroConstructor)
	struct FLatentActionInfo                           LatentInfo_69;                                            // (Parm)
	EARServicePermissionRequestResult                  OutPermissionResult_69;                                   // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
};

// Function AugmentedReality.ARDependencyHandler.InstallARService
struct ARDependencyHandler_InstallARService_Params
{
	class Object_32759*                                WorldContextObject_69;                                    // (Parm, ZeroConstructor)
	struct FLatentActionInfo                           LatentInfo_69;                                            // (Parm)
	EARServiceInstallRequestResult                     OutInstallResult_69;                                      // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
};

// Function AugmentedReality.ARDependencyHandler.GetARDependencyHandler
struct ARDependencyHandler_GetARDependencyHandler_Params
{
	class ARDependencyHandler*                         ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function AugmentedReality.ARDependencyHandler.CheckARServiceAvailability
struct ARDependencyHandler_CheckARServiceAvailability_Params
{
	class Object_32759*                                WorldContextObject_69;                                    // (Parm, ZeroConstructor)
	struct FLatentActionInfo                           LatentInfo_69;                                            // (Parm)
	EARServiceAvailability                             OutAvailability_69;                                       // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
};

// Function AugmentedReality.ARGeoTrackingSupport.GetGeoTrackingSupport
struct ARGeoTrackingSupport_GetGeoTrackingSupport_Params
{
	class ARGeoTrackingSupport*                        ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function AugmentedReality.ARGeoTrackingSupport.GetGeoTrackingStateReason
struct ARGeoTrackingSupport_GetGeoTrackingStateReason_Params
{
	EARGeoTrackingStateReason                          ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AugmentedReality.ARGeoTrackingSupport.GetGeoTrackingState
struct ARGeoTrackingSupport_GetGeoTrackingState_Params
{
	EARGeoTrackingState                                ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AugmentedReality.ARGeoTrackingSupport.GetGeoTrackingAccuracy
struct ARGeoTrackingSupport_GetGeoTrackingAccuracy_Params
{
	EARGeoTrackingAccuracy                             ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AugmentedReality.ARGeoTrackingSupport.AddGeoAnchorAtLocationWithAltitude
struct ARGeoTrackingSupport_AddGeoAnchorAtLocationWithAltitude_Params
{
	float                                              Longitude_69;                                             // (Parm, ZeroConstructor, IsPlainOldData)
	float                                              Latitude_69;                                              // (Parm, ZeroConstructor, IsPlainOldData)
	float                                              AltitudeMeters_69;                                        // (Parm, ZeroConstructor, IsPlainOldData)
	struct FString                                     OptionalAnchorName_69;                                    // (Parm, ZeroConstructor)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AugmentedReality.ARGeoTrackingSupport.AddGeoAnchorAtLocation
struct ARGeoTrackingSupport_AddGeoAnchorAtLocation_Params
{
	float                                              Longitude_69;                                             // (Parm, ZeroConstructor, IsPlainOldData)
	float                                              Latitude_69;                                              // (Parm, ZeroConstructor, IsPlainOldData)
	struct FString                                     OptionalAnchorName_69;                                    // (Parm, ZeroConstructor)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// DelegateFunction AugmentedReality.CheckGeoTrackingAvailabilityAsyncTaskBlueprintProxy.GeoTrackingAvailabilityDelegate__DelegateSignature
struct CheckGeoTrackingAvailabilityAsyncTaskBlueprintProxy_GeoTrackingAvailabilityDelegate__DelegateSignature_Params
{
	bool                                               bIsAvailable_69;                                          // (Parm, ZeroConstructor, IsPlainOldData)
	struct FString                                     Error_69;                                                 // (Parm, ZeroConstructor)
};

// Function AugmentedReality.CheckGeoTrackingAvailabilityAsyncTaskBlueprintProxy.CheckGeoTrackingAvailabilityAtLocation
struct CheckGeoTrackingAvailabilityAsyncTaskBlueprintProxy_CheckGeoTrackingAvailabilityAtLocation_Params
{
	class Object_32759*                                WorldContextObject_69;                                    // (Parm, ZeroConstructor)
	float                                              Longitude_69;                                             // (Parm, ZeroConstructor, IsPlainOldData)
	float                                              Latitude_69;                                              // (Parm, ZeroConstructor, IsPlainOldData)
	class CheckGeoTrackingAvailabilityAsyncTaskBlueprintProxy* ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function AugmentedReality.CheckGeoTrackingAvailabilityAsyncTaskBlueprintProxy.CheckGeoTrackingAvailability
struct CheckGeoTrackingAvailabilityAsyncTaskBlueprintProxy_CheckGeoTrackingAvailability_Params
{
	class Object_32759*                                WorldContextObject_69;                                    // (Parm, ZeroConstructor)
	class CheckGeoTrackingAvailabilityAsyncTaskBlueprintProxy* ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// DelegateFunction AugmentedReality.GetGeoLocationAsyncTaskBlueprintProxy.GetGeoLocationDelegate__DelegateSignature
struct GetGeoLocationAsyncTaskBlueprintProxy_GetGeoLocationDelegate__DelegateSignature_Params
{
	float                                              Longitude_69;                                             // (Parm, ZeroConstructor, IsPlainOldData)
	float                                              Latitude_69;                                              // (Parm, ZeroConstructor, IsPlainOldData)
	float                                              Altitude_69;                                              // (Parm, ZeroConstructor, IsPlainOldData)
	struct FString                                     Error_69;                                                 // (Parm, ZeroConstructor)
};

// Function AugmentedReality.GetGeoLocationAsyncTaskBlueprintProxy.GetGeoLocationAtWorldPosition
struct GetGeoLocationAsyncTaskBlueprintProxy_GetGeoLocationAtWorldPosition_Params
{
	class Object_32759*                                WorldContextObject_69;                                    // (Parm, ZeroConstructor)
	struct FVector                                     WorldPosition_69;                                         // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
	class GetGeoLocationAsyncTaskBlueprintProxy*       ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function AugmentedReality.ARLifeCycleComponent.ServerSpawnARActor
struct ARLifeCycleComponent_ServerSpawnARActor_Params
{
	class Object_32759*                                ComponentClass_69;                                        // (Parm, ZeroConstructor)
	struct FGuid                                       NativeID_69;                                              // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function AugmentedReality.ARLifeCycleComponent.ServerDestroyARActor
struct ARLifeCycleComponent_ServerDestroyARActor_Params
{
	class ARActor*                                     Actor_69;                                                 // (Parm, ZeroConstructor)
};

// DelegateFunction AugmentedReality.ARLifeCycleComponent.InstanceARActorToBeDestroyedDelegate__DelegateSignature
struct ARLifeCycleComponent_InstanceARActorToBeDestroyedDelegate__DelegateSignature_Params
{
	class ARActor*                                     Actor_69;                                                 // (Parm, ZeroConstructor)
};

// DelegateFunction AugmentedReality.ARLifeCycleComponent.InstanceARActorSpawnedDelegate__DelegateSignature
struct ARLifeCycleComponent_InstanceARActorSpawnedDelegate__DelegateSignature_Params
{
	class Object_32759*                                ComponentClass_69;                                        // (Parm, ZeroConstructor)
	struct FGuid                                       NativeID_69;                                              // (Parm, ZeroConstructor, IsPlainOldData)
	class ARActor*                                     SpawnedActor_69;                                          // (Parm, ZeroConstructor)
};

// Function AugmentedReality.ARBasicLightEstimate.GetAmbientIntensityLumens
struct ARBasicLightEstimate_GetAmbientIntensityLumens_Params
{
	float                                              ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AugmentedReality.ARBasicLightEstimate.GetAmbientColorTemperatureKelvin
struct ARBasicLightEstimate_GetAmbientColorTemperatureKelvin_Params
{
	float                                              ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AugmentedReality.ARBasicLightEstimate.GetAmbientColor
struct ARBasicLightEstimate_GetAmbientColor_Params
{
	struct FLinearColor                                ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AugmentedReality.ARPin.GetTrackingState
struct ARPin_GetTrackingState_Params
{
	EARTrackingState                                   ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AugmentedReality.ARPin.GetTrackedGeometry
struct ARPin_GetTrackedGeometry_Params
{
	class ARTrackedGeometry*                           ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function AugmentedReality.ARPin.GetPinnedComponent
struct ARPin_GetPinnedComponent_Params
{
	class SceneComponent*                              ReturnValue_69;                                           // (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)
};

// Function AugmentedReality.ARPin.GetLocalToWorldTransform
struct ARPin_GetLocalToWorldTransform_Params
{
	struct FCoreUObject_FTransform                     ReturnValue_69;                                           // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function AugmentedReality.ARPin.GetLocalToTrackingTransform
struct ARPin_GetLocalToTrackingTransform_Params
{
	struct FCoreUObject_FTransform                     ReturnValue_69;                                           // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function AugmentedReality.ARPin.GetDebugName
struct ARPin_GetDebugName_Params
{
	struct FName                                       ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AugmentedReality.ARPin.DebugDraw
struct ARPin_DebugDraw_Params
{
	class World*                                       World_69;                                                 // (Parm, ZeroConstructor)
	struct FLinearColor                                Color_69;                                                 // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
	float                                              Scale_69;                                                 // (Parm, ZeroConstructor, IsPlainOldData)
	float                                              PersistForSeconds_69;                                     // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function AugmentedReality.ARSessionConfig.ShouldResetTrackedObjects
struct ARSessionConfig_ShouldResetTrackedObjects_Params
{
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AugmentedReality.ARSessionConfig.ShouldResetCameraTracking
struct ARSessionConfig_ShouldResetCameraTracking_Params
{
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AugmentedReality.ARSessionConfig.ShouldRenderCameraOverlay
struct ARSessionConfig_ShouldRenderCameraOverlay_Params
{
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AugmentedReality.ARSessionConfig.ShouldEnableCameraTracking
struct ARSessionConfig_ShouldEnableCameraTracking_Params
{
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AugmentedReality.ARSessionConfig.ShouldEnableAutoFocus
struct ARSessionConfig_ShouldEnableAutoFocus_Params
{
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AugmentedReality.ARSessionConfig.SetWorldMapData
struct ARSessionConfig_SetWorldMapData_Params
{
	TArray<unsigned char>                              WorldMapData_69;                                          // (Parm, ZeroConstructor)
};

// Function AugmentedReality.ARSessionConfig.SetSessionTrackingFeatureToEnable
struct ARSessionConfig_SetSessionTrackingFeatureToEnable_Params
{
	EARSessionTrackingFeature                          InSessionTrackingFeature_69;                              // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function AugmentedReality.ARSessionConfig.SetSceneReconstructionMethod
struct ARSessionConfig_SetSceneReconstructionMethod_Params
{
	EARSceneReconstruction                             InSceneReconstructionMethod_69;                           // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function AugmentedReality.ARSessionConfig.SetResetTrackedObjects
struct ARSessionConfig_SetResetTrackedObjects_Params
{
	bool                                               bNewValue_69;                                             // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function AugmentedReality.ARSessionConfig.SetResetCameraTracking
struct ARSessionConfig_SetResetCameraTracking_Params
{
	bool                                               bNewValue_69;                                             // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function AugmentedReality.ARSessionConfig.SetFaceTrackingUpdate
struct ARSessionConfig_SetFaceTrackingUpdate_Params
{
	EARFaceTrackingUpdate                              InUpdate_69;                                              // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function AugmentedReality.ARSessionConfig.SetFaceTrackingDirection
struct ARSessionConfig_SetFaceTrackingDirection_Params
{
	EARFaceTrackingDirection                           InDirection_69;                                           // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function AugmentedReality.ARSessionConfig.SetEnableAutoFocus
struct ARSessionConfig_SetEnableAutoFocus_Params
{
	bool                                               bNewValue_69;                                             // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function AugmentedReality.ARSessionConfig.SetDesiredVideoFormat
struct ARSessionConfig_SetDesiredVideoFormat_Params
{
	struct FARVideoFormat                              NewFormat_69;                                             // (Parm)
};

// Function AugmentedReality.ARSessionConfig.SetCandidateObjectList
struct ARSessionConfig_SetCandidateObjectList_Params
{
	TArray<class ARCandidateObject*>                   InCandidateObjects_69;                                    // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
};

// Function AugmentedReality.ARSessionConfig.GetWorldMapData
struct ARSessionConfig_GetWorldMapData_Params
{
	TArray<unsigned char>                              ReturnValue_69;                                           // (ConstParm, Parm, OutParm, ZeroConstructor, ReturnParm, ReferenceParm)
};

// Function AugmentedReality.ARSessionConfig.GetWorldAlignment
struct ARSessionConfig_GetWorldAlignment_Params
{
	EARWorldAlignment                                  ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AugmentedReality.ARSessionConfig.GetSessionType
struct ARSessionConfig_GetSessionType_Params
{
	EARSessionType                                     ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AugmentedReality.ARSessionConfig.GetSceneReconstructionMethod
struct ARSessionConfig_GetSceneReconstructionMethod_Params
{
	EARSceneReconstruction                             ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AugmentedReality.ARSessionConfig.GetPlaneDetectionMode
struct ARSessionConfig_GetPlaneDetectionMode_Params
{
	EARPlaneDetectionMode                              ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AugmentedReality.ARSessionConfig.GetMaxNumSimultaneousImagesTracked
struct ARSessionConfig_GetMaxNumSimultaneousImagesTracked_Params
{
	int                                                ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AugmentedReality.ARSessionConfig.GetLightEstimationMode
struct ARSessionConfig_GetLightEstimationMode_Params
{
	EARLightEstimationMode                             ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AugmentedReality.ARSessionConfig.GetFrameSyncMode
struct ARSessionConfig_GetFrameSyncMode_Params
{
	EARFrameSyncMode                                   ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AugmentedReality.ARSessionConfig.GetFaceTrackingUpdate
struct ARSessionConfig_GetFaceTrackingUpdate_Params
{
	EARFaceTrackingUpdate                              ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AugmentedReality.ARSessionConfig.GetFaceTrackingDirection
struct ARSessionConfig_GetFaceTrackingDirection_Params
{
	EARFaceTrackingDirection                           ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AugmentedReality.ARSessionConfig.GetEnvironmentCaptureProbeType
struct ARSessionConfig_GetEnvironmentCaptureProbeType_Params
{
	EAREnvironmentCaptureProbeType                     ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AugmentedReality.ARSessionConfig.GetEnabledSessionTrackingFeature
struct ARSessionConfig_GetEnabledSessionTrackingFeature_Params
{
	EARSessionTrackingFeature                          ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AugmentedReality.ARSessionConfig.GetDesiredVideoFormat
struct ARSessionConfig_GetDesiredVideoFormat_Params
{
	struct FARVideoFormat                              ReturnValue_69;                                           // (Parm, OutParm, ReturnParm)
};

// Function AugmentedReality.ARSessionConfig.GetCandidateObjectList
struct ARSessionConfig_GetCandidateObjectList_Params
{
	TArray<class ARCandidateObject*>                   ReturnValue_69;                                           // (ConstParm, Parm, OutParm, ZeroConstructor, ReturnParm, ReferenceParm)
};

// Function AugmentedReality.ARSessionConfig.GetCandidateImageList
struct ARSessionConfig_GetCandidateImageList_Params
{
	TArray<class ARCandidateImage*>                    ReturnValue_69;                                           // (ConstParm, Parm, OutParm, ZeroConstructor, ReturnParm, ReferenceParm)
};

// Function AugmentedReality.ARSessionConfig.AddCandidateObject
struct ARSessionConfig_AddCandidateObject_Params
{
	class ARCandidateObject*                           CandidateObject_69;                                       // (Parm, ZeroConstructor)
};

// Function AugmentedReality.ARSessionConfig.AddCandidateImage
struct ARSessionConfig_AddCandidateImage_Params
{
	class ARCandidateImage*                            NewCandidateImage_69;                                     // (Parm, ZeroConstructor)
};

// Function AugmentedReality.ARSharedWorldGameMode.SetPreviewImageData
struct ARSharedWorldGameMode_SetPreviewImageData_Params
{
	TArray<unsigned char>                              ImageData_69;                                             // (Parm, ZeroConstructor)
};

// Function AugmentedReality.ARSharedWorldGameMode.SetARWorldSharingIsReady
struct ARSharedWorldGameMode_SetARWorldSharingIsReady_Params
{
};

// Function AugmentedReality.ARSharedWorldGameMode.SetARSharedWorldData
struct ARSharedWorldGameMode_SetARSharedWorldData_Params
{
	TArray<unsigned char>                              ARWorldData_69;                                           // (Parm, ZeroConstructor)
};

// Function AugmentedReality.ARSharedWorldGameMode.GetARSharedWorldGameState
struct ARSharedWorldGameMode_GetARSharedWorldGameState_Params
{
	class ARSharedWorldGameState*                      ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function AugmentedReality.ARSharedWorldGameState.K2_OnARWorldMapIsReady
struct ARSharedWorldGameState_K2_OnARWorldMapIsReady_Params
{
};

// Function AugmentedReality.ARSharedWorldPlayerController.ServerMarkReadyForReceiving
struct ARSharedWorldPlayerController_ServerMarkReadyForReceiving_Params
{
};

// Function AugmentedReality.ARSharedWorldPlayerController.ClientUpdatePreviewImageData
struct ARSharedWorldPlayerController_ClientUpdatePreviewImageData_Params
{
	int                                                Offset_69;                                                // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<unsigned char>                              Buffer_69;                                                // (ConstParm, Parm, ZeroConstructor, ReferenceParm)
};

// Function AugmentedReality.ARSharedWorldPlayerController.ClientUpdateARWorldData
struct ARSharedWorldPlayerController_ClientUpdateARWorldData_Params
{
	int                                                Offset_69;                                                // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<unsigned char>                              Buffer_69;                                                // (ConstParm, Parm, ZeroConstructor, ReferenceParm)
};

// Function AugmentedReality.ARSharedWorldPlayerController.ClientInitSharedWorld
struct ARSharedWorldPlayerController_ClientInitSharedWorld_Params
{
	int                                                PreviewImageSize_69;                                      // (Parm, ZeroConstructor, IsPlainOldData)
	int                                                ARWorldDataSize_69;                                       // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function AugmentedReality.ARSkyLight.SetEnvironmentCaptureProbe
struct ARSkyLight_SetEnvironmentCaptureProbe_Params
{
	class AREnvironmentCaptureProbe*                   InCaptureProbe_69;                                        // (Parm, ZeroConstructor)
};

// Function AugmentedReality.ARTrackedGeometry.IsTracked
struct ARTrackedGeometry_IsTracked_Params
{
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AugmentedReality.ARTrackedGeometry.HasSpatialMeshUsageFlag
struct ARTrackedGeometry_HasSpatialMeshUsageFlag_Params
{
	EARSpatialMeshUsageFlags                           InFlag_69;                                                // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AugmentedReality.ARTrackedGeometry.GetUnderlyingMesh
struct ARTrackedGeometry_GetUnderlyingMesh_Params
{
	class MRMeshComponent*                             ReturnValue_69;                                           // (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)
};

// Function AugmentedReality.ARTrackedGeometry.GetTrackingState
struct ARTrackedGeometry_GetTrackingState_Params
{
	EARTrackingState                                   ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AugmentedReality.ARTrackedGeometry.GetObjectClassification
struct ARTrackedGeometry_GetObjectClassification_Params
{
	EARObjectClassification                            ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AugmentedReality.ARTrackedGeometry.GetName
struct ARTrackedGeometry_GetName_Params
{
	struct FString                                     ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function AugmentedReality.ARTrackedGeometry.GetLocalToWorldTransform
struct ARTrackedGeometry_GetLocalToWorldTransform_Params
{
	struct FCoreUObject_FTransform                     ReturnValue_69;                                           // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function AugmentedReality.ARTrackedGeometry.GetLocalToTrackingTransform
struct ARTrackedGeometry_GetLocalToTrackingTransform_Params
{
	struct FCoreUObject_FTransform                     ReturnValue_69;                                           // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function AugmentedReality.ARTrackedGeometry.GetLastUpdateTimestamp
struct ARTrackedGeometry_GetLastUpdateTimestamp_Params
{
	float                                              ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AugmentedReality.ARTrackedGeometry.GetLastUpdateFrameNumber
struct ARTrackedGeometry_GetLastUpdateFrameNumber_Params
{
	int                                                ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AugmentedReality.ARTrackedGeometry.GetDebugName
struct ARTrackedGeometry_GetDebugName_Params
{
	struct FName                                       ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AugmentedReality.ARPlaneGeometry.GetSubsumedBy
struct ARPlaneGeometry_GetSubsumedBy_Params
{
	class ARPlaneGeometry*                             ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function AugmentedReality.ARPlaneGeometry.GetOrientation
struct ARPlaneGeometry_GetOrientation_Params
{
	EARPlaneOrientation                                ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AugmentedReality.ARPlaneGeometry.GetExtent
struct ARPlaneGeometry_GetExtent_Params
{
	struct FVector                                     ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AugmentedReality.ARPlaneGeometry.GetCenter
struct ARPlaneGeometry_GetCenter_Params
{
	struct FVector                                     ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AugmentedReality.ARPlaneGeometry.GetBoundaryPolygonInLocalSpace
struct ARPlaneGeometry_GetBoundaryPolygonInLocalSpace_Params
{
	TArray<struct FVector>                             ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function AugmentedReality.ARTrackedImage.GetEstimateSize
struct ARTrackedImage_GetEstimateSize_Params
{
	struct FVector2D                                   ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AugmentedReality.ARTrackedImage.GetDetectedImage
struct ARTrackedImage_GetDetectedImage_Params
{
	class ARCandidateImage*                            ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function AugmentedReality.ARFaceGeometry.GetWorldSpaceEyeTransform
struct ARFaceGeometry_GetWorldSpaceEyeTransform_Params
{
	EAREye                                             Eye_69;                                                   // (Parm, ZeroConstructor, IsPlainOldData)
	struct FCoreUObject_FTransform                     ReturnValue_69;                                           // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function AugmentedReality.ARFaceGeometry.GetLocalSpaceEyeTransform
struct ARFaceGeometry_GetLocalSpaceEyeTransform_Params
{
	EAREye                                             Eye_69;                                                   // (Parm, ZeroConstructor, IsPlainOldData)
	struct FCoreUObject_FTransform                     ReturnValue_69;                                           // (ConstParm, Parm, OutParm, ReturnParm, ReferenceParm, IsPlainOldData)
};

// Function AugmentedReality.ARFaceGeometry.GetBlendShapeValue
struct ARFaceGeometry_GetBlendShapeValue_Params
{
	EARFaceBlendShape                                  BlendShape_69;                                            // (Parm, ZeroConstructor, IsPlainOldData)
	float                                              ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AugmentedReality.ARFaceGeometry.GetBlendShapes
struct ARFaceGeometry_GetBlendShapes_Params
{
	TMap<EARFaceBlendShape, float>                     ReturnValue_69;                                           // (ConstParm, Parm, OutParm, ReturnParm)
};

// Function AugmentedReality.AREnvironmentCaptureProbe.GetExtent
struct AREnvironmentCaptureProbe_GetExtent_Params
{
	struct FVector                                     ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AugmentedReality.AREnvironmentCaptureProbe.GetEnvironmentCaptureTexture
struct AREnvironmentCaptureProbe_GetEnvironmentCaptureTexture_Params
{
	class AREnvironmentCaptureProbeTexture*            ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function AugmentedReality.ARTrackedObject.GetDetectedObject
struct ARTrackedObject_GetDetectedObject_Params
{
	class ARCandidateObject*                           ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function AugmentedReality.ARTrackedPose.GetTrackedPoseData
struct ARTrackedPose_GetTrackedPoseData_Params
{
	struct FARPose3D                                   ReturnValue_69;                                           // (ConstParm, Parm, OutParm, ReturnParm, ReferenceParm)
};

// Function AugmentedReality.ARMeshGeometry.GetObjectClassificationAtLocation
struct ARMeshGeometry_GetObjectClassificationAtLocation_Params
{
	struct FVector                                     InWorldLocation_69;                                       // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
	EARObjectClassification                            OutClassification_69;                                     // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	struct FVector                                     OutClassificationLocation_69;                             // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	float                                              MaxLocationDiff_69;                                       // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AugmentedReality.ARGeoAnchor.GetLongitude
struct ARGeoAnchor_GetLongitude_Params
{
	float                                              ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AugmentedReality.ARGeoAnchor.GetLatitude
struct ARGeoAnchor_GetLatitude_Params
{
	float                                              ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AugmentedReality.ARGeoAnchor.GetAltitudeSource
struct ARGeoAnchor_GetAltitudeSource_Params
{
	EARAltitudeSource                                  ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AugmentedReality.ARGeoAnchor.GetAltitudeMeters
struct ARGeoAnchor_GetAltitudeMeters_Params
{
	float                                              ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AugmentedReality.ARCandidateImage.GetPhysicalWidth
struct ARCandidateImage_GetPhysicalWidth_Params
{
	float                                              ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AugmentedReality.ARCandidateImage.GetPhysicalHeight
struct ARCandidateImage_GetPhysicalHeight_Params
{
	float                                              ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AugmentedReality.ARCandidateImage.GetOrientation
struct ARCandidateImage_GetOrientation_Params
{
	EARCandidateImageOrientation                       ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AugmentedReality.ARCandidateImage.GetFriendlyName
struct ARCandidateImage_GetFriendlyName_Params
{
	struct FString                                     ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function AugmentedReality.ARCandidateImage.GetCandidateTexture
struct ARCandidateImage_GetCandidateTexture_Params
{
	class Texture2D*                                   ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function AugmentedReality.ARCandidateObject.SetFriendlyName
struct ARCandidateObject_SetFriendlyName_Params
{
	struct FString                                     NewName_69;                                               // (Parm, ZeroConstructor)
};

// Function AugmentedReality.ARCandidateObject.SetCandidateObjectData
struct ARCandidateObject_SetCandidateObjectData_Params
{
	TArray<unsigned char>                              InCandidateObject_69;                                     // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
};

// Function AugmentedReality.ARCandidateObject.SetBoundingBox
struct ARCandidateObject_SetBoundingBox_Params
{
	struct FBox                                        InBoundingBox_69;                                         // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
};

// Function AugmentedReality.ARCandidateObject.GetFriendlyName
struct ARCandidateObject_GetFriendlyName_Params
{
	struct FString                                     ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function AugmentedReality.ARCandidateObject.GetCandidateObjectData
struct ARCandidateObject_GetCandidateObjectData_Params
{
	TArray<unsigned char>                              ReturnValue_69;                                           // (ConstParm, Parm, OutParm, ZeroConstructor, ReturnParm, ReferenceParm)
};

// Function AugmentedReality.ARCandidateObject.GetBoundingBox
struct ARCandidateObject_GetBoundingBox_Params
{
	struct FBox                                        ReturnValue_69;                                           // (ConstParm, Parm, OutParm, ZeroConstructor, ReturnParm, ReferenceParm, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

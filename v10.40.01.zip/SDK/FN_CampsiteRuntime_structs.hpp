#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Enums
//---------------------------------------------------------------------------

// Enum CampsiteRuntime.EAbandonedCampsiteSpawnType
enum class EAbandonedCampsiteSpawnType : uint8_t
{
	None                           = 0,
	PlacedInLevel                  = 1,
	EnvironmentalQuery             = 2,
	FromPlayerProfile              = 3,
	Max                            = 4
};


// Enum CampsiteRuntime.ECampsiteActionType
enum class ECampsiteActionType : uint8_t
{
	None                           = 0,
	Stash                          = 1,
	Unstash                        = 2,
	Swap                           = 3,
	Clear                          = 4,
	Max                            = 5
};



//---------------------------------------------------------------------------
//Script Structs
//---------------------------------------------------------------------------

// ScriptStruct CampsiteRuntime.AbandonedCampsiteAnalytics
// 0x0020
struct FAbandonedCampsiteAnalytics
{
	unsigned char                                      UnknownData00[0x20];                                      // 0x0000(0x0020) MISSED OFFSET
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Functions
//---------------------------------------------------------------------------

// Function AndroidPermission.AndroidPermissionFunctionLibrary.CheckPermission
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// struct FString                 Permission_69                  (Parm, ZeroConstructor)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool AndroidPermissionFunctionLibrary::STATIC_CheckPermission(const struct FString& Permission_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AndroidPermission.AndroidPermissionFunctionLibrary.CheckPermission"));

	AndroidPermissionFunctionLibrary_CheckPermission_Params params;
	params.Permission_69 = Permission_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function AndroidPermission.AndroidPermissionFunctionLibrary.AcquirePermissions
// (Final, Native, Static, Public, HasOutParms, BlueprintCallable)
// Parameters:
// TArray<struct FString>         Permissions_69                 (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
// class AndroidPermissionCallbackProxy* ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

class AndroidPermissionCallbackProxy* AndroidPermissionFunctionLibrary::STATIC_AcquirePermissions(TArray<struct FString> Permissions_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AndroidPermission.AndroidPermissionFunctionLibrary.AcquirePermissions"));

	AndroidPermissionFunctionLibrary_AcquirePermissions_Params params;
	params.Permissions_69 = Permissions_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

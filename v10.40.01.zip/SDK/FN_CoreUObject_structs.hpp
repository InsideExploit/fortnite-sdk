#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Enums
//---------------------------------------------------------------------------

// Enum CoreUObject.EAutomationEventType
enum class EAutomationEventType : uint8_t
{
	Info                           = 0,
	Warning                        = 1,
	Error                          = 2,
	EAutomationEventType_MAX       = 3
};


// Enum CoreUObject.ERangeBoundTypes
enum class ERangeBoundTypes : uint8_t
{
	Exclusive                      = 0,
	Inclusive                      = 1,
	Open                           = 2,
	ERangeBoundTypes_MAX           = 3
};


// Enum CoreUObject.EInterpCurveMode
enum class EInterpCurveMode : uint8_t
{
	CIM_Linear                     = 0,
	CIM_CurveAuto                  = 1,
	CIM_Constant                   = 2,
	CIM_CurveUser                  = 3,
	CIM_CurveBreak                 = 4,
	CIM_CurveAutoClamped           = 5,
	CIM_MAX                        = 6
};


// Enum CoreUObject.EInputDeviceConnectionState
enum class EInputDeviceConnectionState : uint8_t
{
	Invalid                        = 0,
	Unknown                        = 1,
	Disconnected                   = 2,
	Connected                      = 3,
	EInputDeviceConnectionState_MAX = 4
};


// Enum CoreUObject.ELocalizedTextSourceCategory
enum class ELocalizedTextSourceCategory : uint8_t
{
	Game                           = 0,
	Engine                         = 1,
	Editor                         = 2,
	ELocalizedTextSourceCategory_MAX = 3
};


// Enum CoreUObject.EMouseCursor
enum class EMouseCursor : uint8_t
{
	None                           = 0,
	Default                        = 1,
	TextEditBeam                   = 2,
	ResizeLeftRight                = 3,
	ResizeUpDown                   = 4,
	ResizeSouthEast                = 5,
	ResizeSouthWest                = 6,
	CardinalCross                  = 7,
	Crosshairs                     = 8,
	Hand                           = 9,
	GrabHand                       = 10,
	GrabHandClosed                 = 11,
	SlashedCircle                  = 12,
	EyeDropper                     = 13,
	EMouseCursor_MAX               = 14
};


// Enum CoreUObject.ELifetimeCondition
enum class ELifetimeCondition : uint8_t
{
	COND_None                      = 0,
	COND_InitialOnly               = 1,
	COND_OwnerOnly                 = 2,
	COND_SkipOwner                 = 3,
	COND_SimulatedOnly             = 4,
	COND_AutonomousOnly            = 5,
	COND_SimulatedOrPhysics        = 6,
	COND_InitialOrOwner            = 7,
	COND_Custom                    = 8,
	COND_ReplayOrOwner             = 9,
	COND_ReplayOnly                = 10,
	COND_SimulatedOnlyNoReplay     = 11,
	COND_SimulatedOrPhysicsNoReplay = 12,
	COND_SkipReplay                = 13,
	COND_Never                     = 14,
	COND_NetGroup                  = 15,
	COND_Max                       = 16
};


// Enum CoreUObject.ESearchCase
enum class ESearchCase : uint8_t
{
	CaseSensitive                  = 0,
	IgnoreCase                     = 1,
	ESearchCase_MAX                = 2
};


// Enum CoreUObject.ESearchDir
enum class ESearchDir : uint8_t
{
	FromStart                      = 0,
	FromEnd                        = 1,
	ESearchDir_MAX                 = 2
};


// Enum CoreUObject.ELogTimes
enum class ELogTimes : uint8_t
{
	None                           = 0,
	UTC                            = 1,
	SinceGStartTime                = 2,
	Local                          = 3,
	ELogTimes_MAX                  = 4
};


// Enum CoreUObject.EAxis
enum class EAxis : uint8_t
{
	None                           = 0,
	X                              = 1,
	Y                              = 2,
	Z                              = 3,
	EAxis_MAX                      = 4
};


// Enum CoreUObject.EAxisList
enum class EAxisList : uint8_t
{
	None                           = 0,
	X                              = 1,
	Y                              = 2,
	Z                              = 3,
	Screen                         = 4,
	XY                             = 5,
	XZ                             = 6,
	YZ                             = 7,
	XYZ                            = 8,
	All                            = 9,
	ZRotation                      = 10,
	Rotate2D                       = 11,
	EAxisList_MAX                  = 12
};


// Enum CoreUObject.EPixelFormat
enum class EPixelFormat : uint8_t
{
	PF_Unknown                     = 0,
	PF_A32B32G32R32F               = 1,
	PF_B8G8R8A8                    = 2,
	PF_G8                          = 3,
	PF_G16                         = 4,
	PF_DXT1                        = 5,
	PF_DXT3                        = 6,
	PF_DXT5                        = 7,
	PF_UYVY                        = 8,
	PF_FloatRGB                    = 9,
	PF_FloatRGBA                   = 10,
	PF_DepthStencil                = 11,
	PF_ShadowDepth                 = 12,
	PF_R32_FLOAT                   = 13,
	PF_G16R16                      = 14,
	PF_G16R16F                     = 15,
	PF_G16R16F_FILTER              = 16,
	PF_G32R32F                     = 17,
	PF_A2B10G10R10                 = 18,
	PF_A16B16G16R16                = 19,
	PF_D24                         = 20,
	PF_R16F                        = 21,
	PF_R16F_FILTER                 = 22,
	PF_BC5                         = 23,
	PF_V8U8                        = 24,
	PF_A1                          = 25,
	PF_FloatR11G11B10              = 26,
	PF_A8                          = 27,
	PF_R32_UINT                    = 28,
	PF_R32_SINT                    = 29,
	PF_PVRTC2                      = 30,
	PF_PVRTC4                      = 31,
	PF_R16_UINT                    = 32,
	PF_R16_SINT                    = 33,
	PF_R16G16B16A16_UINT           = 34,
	PF_R16G16B16A16_SINT           = 35,
	PF_R5G6B5_UNORM                = 36,
	PF_R8G8B8A8                    = 37,
	PF_A8R8G8B8                    = 38,
	PF_BC4                         = 39,
	PF_R8G8                        = 40,
	PF_ATC_RGB                     = 41,
	PF_ATC_RGBA_E                  = 42,
	PF_ATC_RGBA_I                  = 43,
	PF_X24_G8                      = 44,
	PF_ETC1                        = 45,
	PF_ETC2_RGB                    = 46,
	PF_ETC2_RGBA                   = 47,
	PF_R32G32B32A32_UINT           = 48,
	PF_R16G16_UINT                 = 49,
	PF_ASTC_4x4                    = 50,
	PF_ASTC_6x6                    = 51,
	PF_ASTC_8x8                    = 52,
	PF_ASTC_10x10                  = 53,
	PF_ASTC_12x12                  = 54,
	PF_BC6H                        = 55,
	PF_BC7                         = 56,
	PF_R8_UINT                     = 57,
	PF_L8                          = 58,
	PF_XGXR8                       = 59,
	PF_R8G8B8A8_UINT               = 60,
	PF_R8G8B8A8_SNORM              = 61,
	PF_R16G16B16A16_UNORM          = 62,
	PF_R16G16B16A16_SNORM          = 63,
	PF_PLATFORM_HDR_0              = 64,
	PF_PLATFORM_HDR_1              = 65,
	PF_PLATFORM_HDR_2              = 66,
	PF_NV12                        = 67,
	PF_R32G32_UINT                 = 68,
	PF_ETC2_R11_EAC                = 69,
	PF_ETC2_RG11_EAC               = 70,
	PF_R8                          = 71,
	PF_B5G5R5A1_UNORM              = 72,
	PF_G16R16_SNORM                = 73,
	PF_R8G8_UINT                   = 74,
	PF_R32G32B32_UINT              = 75,
	PF_R32G32B32_SINT              = 76,
	PF_R32G32B32F                  = 77,
	PF_R8_SINT                     = 78,
	PF_R64_UINT                    = 79,
	PF_MAX                         = 80
};


// Enum CoreUObject.EUnit
enum class EUnit : uint8_t
{
	Micrometers                    = 0,
	Millimeters                    = 1,
	Centimeters                    = 2,
	Meters                         = 3,
	Kilometers                     = 4,
	Inches                         = 5,
	Feet                           = 6,
	Yards                          = 7,
	Miles                          = 8,
	Lightyears                     = 9,
	Degrees                        = 10,
	Radians                        = 11,
	CentimetersPerSecond           = 12,
	MetersPerSecond                = 13,
	KilometersPerHour              = 14,
	MilesPerHour                   = 15,
	Celsius                        = 16,
	Farenheit                      = 17,
	Kelvin                         = 18,
	Micrograms                     = 19,
	Milligrams                     = 20,
	Grams                          = 21,
	Kilograms                      = 22,
	MetricTons                     = 23,
	Ounces                         = 24,
	Pounds                         = 25,
	Stones                         = 26,
	Newtons                        = 27,
	PoundsForce                    = 28,
	KilogramsForce                 = 29,
	Hertz                          = 30,
	Kilohertz                      = 31,
	Megahertz                      = 32,
	Gigahertz                      = 33,
	RevolutionsPerMinute           = 34,
	Bytes                          = 35,
	Kilobytes                      = 36,
	Megabytes                      = 37,
	Gigabytes                      = 38,
	Terabytes                      = 39,
	Lumens                         = 40,
	Milliseconds                   = 41,
	Seconds                        = 42,
	Minutes                        = 43,
	Hours                          = 44,
	Days                           = 45,
	Months                         = 46,
	Years                          = 47,
	Multiplier                     = 48,
	Percentage                     = 49,
	Unspecified                    = 50,
	EUnit_MAX                      = 51
};


// Enum CoreUObject.EPropertyAccessChangeNotifyMode
enum class EPropertyAccessChangeNotifyMode : uint8_t
{
	Default                        = 0,
	Never                          = 1,
	Always                         = 2,
	EPropertyAccessChangeNotifyMode_MAX = 3
};


// Enum CoreUObject.EAppReturnType
enum class EAppReturnType : uint8_t
{
	No                             = 0,
	Yes                            = 1,
	YesAll                         = 2,
	NoAll                          = 3,
	Cancel                         = 4,
	Ok                             = 5,
	Retry                          = 6,
	Continue                       = 7,
	EAppReturnType_MAX             = 8
};


// Enum CoreUObject.EAppMsgType
enum class EAppMsgType : uint8_t
{
	Ok                             = 0,
	YesNo                          = 1,
	OkCancel                       = 2,
	YesNoCancel                    = 3,
	CancelRetryContinue            = 4,
	YesNoYesAllNoAll               = 5,
	YesNoYesAllNoAllCancel         = 6,
	YesNoYesAll                    = 7,
	EAppMsgType_MAX                = 8
};


// Enum CoreUObject.EDataValidationResult
enum class EDataValidationResult : uint8_t
{
	Invalid                        = 0,
	Valid                          = 1,
	NotValidated                   = 2,
	EDataValidationResult_MAX      = 3
};



//---------------------------------------------------------------------------
//Script Structs
//---------------------------------------------------------------------------

// ScriptStruct CoreUObject.TopLevelAssetPath
// 0x0008
struct FTopLevelAssetPath
{
	struct FName                                       PackageName_69;                                           // 0x0000(0x0008) (Edit, BlueprintVisible, ZeroConstructor, SaveGame, IsPlainOldData)
	struct FName                                       AssetName_69;                                             // 0x0004(0x0008) (Edit, BlueprintVisible, ZeroConstructor, SaveGame, IsPlainOldData)
};

// ScriptStruct CoreUObject.ARFilter
// 0x0150
struct FARFilter
{
	TArray<struct FName>                               PackageNames_69;                                          // 0x0000(0x0010) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance)
	TArray<struct FName>                               PackagePaths_69;                                          // 0x0010(0x0010) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance)
	TArray<struct FName>                               ObjectPaths_69;                                           // 0x0020(0x0010) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance)
	TArray<struct FName>                               ClassNames_69;                                            // 0x0030(0x0010) (BlueprintVisible, ZeroConstructor)
	TArray<struct FTopLevelAssetPath>                  ClassPaths_69;                                            // 0x0040(0x0010) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance)
	unsigned char                                      UnknownData00[0x50];                                      // 0x0050(0x0050) MISSED OFFSET
	unsigned char                                      UnknownData01[0x50];                                      // 0x0050(0x0050) UNKNOWN PROPERTY: SetProperty CoreUObject.ARFilter.RecursiveClassesExclusionSet_69
	unsigned char                                      UnknownData02[0x50];                                      // 0x00F0(0x0050) UNKNOWN PROPERTY: SetProperty CoreUObject.ARFilter.RecursiveClassPathsExclusionSet_69
	bool                                               bRecursivePaths_69;                                       // 0x0140(0x0001) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	bool                                               bRecursiveClasses_69;                                     // 0x0141(0x0001) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	bool                                               bIncludeOnlyOnDiskAssets_69;                              // 0x0142(0x0001) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData03[0xD];                                       // 0x0143(0x000D) MISSED OFFSET
};

// ScriptStruct CoreUObject.SoftObjectPath
// 0x0018
struct FSoftObjectPath
{
	struct FName                                       AssetPathName_69;                                         // 0x0000(0x0008) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0004(0x0004) MISSED OFFSET
	struct FString                                     SubPathString_69;                                         // 0x0008(0x0010) (ZeroConstructor)
};

// ScriptStruct CoreUObject.AssetBundleEntry
// 0x0018
struct FAssetBundleEntry
{
	struct FName                                       BundleName_69;                                            // 0x0000(0x0008) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0004(0x0004) MISSED OFFSET
	TArray<struct FSoftObjectPath>                     BundleAssets_69;                                          // 0x0008(0x0010) (ZeroConstructor)
};

// ScriptStruct CoreUObject.AssetBundleData
// 0x0010
struct FAssetBundleData
{
	TArray<struct FAssetBundleEntry>                   Bundles_69;                                               // 0x0000(0x0010) (ZeroConstructor)
};

// ScriptStruct CoreUObject.AssetData
// 0x0040
struct FAssetData
{
	struct FName                                       ObjectPath_69;                                            // 0x0000(0x0008) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, Transient, IsPlainOldData)
	struct FName                                       PackageName_69;                                           // 0x0004(0x0008) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, Transient, IsPlainOldData)
	struct FName                                       PackagePath_69;                                           // 0x0008(0x0008) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, Transient, IsPlainOldData)
	struct FName                                       AssetName_69;                                             // 0x000C(0x0008) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, Transient, IsPlainOldData)
	struct FName                                       AssetClass_69;                                            // 0x0010(0x0008) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, Transient, IsPlainOldData)
	struct FTopLevelAssetPath                          AssetClassPath_69;                                        // 0x0014(0x0008) (BlueprintVisible, BlueprintReadOnly, Transient)
	unsigned char                                      UnknownData00[0x24];                                      // 0x001C(0x0024) MISSED OFFSET
};

// ScriptStruct CoreUObject.Guid
// 0x0010
struct FGuid
{
	int                                                A_69;                                                     // 0x0000(0x0004) (Edit, ZeroConstructor, SaveGame, IsPlainOldData)
	int                                                B_69;                                                     // 0x0004(0x0004) (Edit, ZeroConstructor, SaveGame, IsPlainOldData)
	int                                                C_69;                                                     // 0x0008(0x0004) (Edit, ZeroConstructor, SaveGame, IsPlainOldData)
	int                                                D_69;                                                     // 0x000C(0x0004) (Edit, ZeroConstructor, SaveGame, IsPlainOldData)
};

// ScriptStruct CoreUObject.AutomationEvent
// 0x0038
struct FAutomationEvent
{
	EAutomationEventType                               Type_69;                                                  // 0x0000(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0001(0x0007) MISSED OFFSET
	struct FString                                     message_69;                                               // 0x0008(0x0010) (ZeroConstructor)
	struct FString                                     Context_69;                                               // 0x0018(0x0010) (ZeroConstructor)
	struct FGuid                                       Artifact_69;                                              // 0x0028(0x0010) (ZeroConstructor, IsPlainOldData)
};

// ScriptStruct CoreUObject.DateTime
// 0x0008
struct FDateTime
{
	unsigned char                                      UnknownData00[0x8];                                       // 0x0000(0x0008) MISSED OFFSET
};

// ScriptStruct CoreUObject.AutomationExecutionEntry
// 0x0058
struct FAutomationExecutionEntry
{
	struct FAutomationEvent                            Event_69;                                                 // 0x0000(0x0038) (ZeroConstructor)
	struct FString                                     Filename_69;                                              // 0x0038(0x0010) (ZeroConstructor)
	int                                                LineNumber_69;                                            // 0x0048(0x0004) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x004C(0x0004) MISSED OFFSET
	struct FDateTime                                   Timestamp_69;                                             // 0x0050(0x0008) (ZeroConstructor)
};

// ScriptStruct CoreUObject.Vector
// 0x0018
struct FVector
{
	double                                             X_69;                                                     // 0x0000(0x0008) (Edit, BlueprintVisible, ZeroConstructor, SaveGame, IsPlainOldData)
	double                                             Y_69;                                                     // 0x0008(0x0008) (Edit, BlueprintVisible, ZeroConstructor, SaveGame, IsPlainOldData)
	double                                             Z_69;                                                     // 0x0010(0x0008) (Edit, BlueprintVisible, ZeroConstructor, SaveGame, IsPlainOldData)

	inline FVector()
		: X(0), Y(0), Z(0)
	{ }

	inline FVector(float x, float y, float z)
		: X(x),
		  Y(y),
		  Z(z)
	{ }

	FVector operator-(FVector v)
	{
		return FVector(X - v.X, Y - v.Y, Z - v.Z);
	}

	FVector operator+(FVector v)
	{
		return FVector(X + v.X, Y + v.Y, Z + v.Z);
	}

	FVector operator*(float s)
	{
		return FVector(X * s, Y * s, Z * s);
	}

	float Distance(FVector v)
	{
		return ((X - v.X) * (X - v.X) +
			(Y - v.Y) * (Y - v.Y) +
			(Z - v.Z) * (Z - v.Z));
	}

};

// ScriptStruct CoreUObject.Box
// 0x0038
struct FBox
{
	struct FVector                                     min_69;                                                   // 0x0000(0x0018) (Edit, BlueprintVisible, ZeroConstructor, SaveGame, IsPlainOldData)
	struct FVector                                     max_69;                                                   // 0x0018(0x0018) (Edit, BlueprintVisible, ZeroConstructor, SaveGame, IsPlainOldData)
	unsigned char                                      IsValid_69;                                               // 0x0030(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0031(0x0007) MISSED OFFSET
};

// ScriptStruct CoreUObject.Vector2D
// 0x0010
struct FVector2D
{
	double                                             X_69;                                                     // 0x0000(0x0008) (Edit, BlueprintVisible, ZeroConstructor, SaveGame, IsPlainOldData)
	double                                             Y_69;                                                     // 0x0008(0x0008) (Edit, BlueprintVisible, ZeroConstructor, SaveGame, IsPlainOldData)

	inline FVector2D()
		: X(0), Y(0)
	{ }

	inline FVector2D(float x, float y)
		: X(x),
		  Y(y)
	{ }

};

// ScriptStruct CoreUObject.Box2D
// 0x0028
struct FBox2D
{
	struct FVector2D                                   min_69;                                                   // 0x0000(0x0010) (Edit, BlueprintVisible, ZeroConstructor, SaveGame, IsPlainOldData)
	struct FVector2D                                   max_69;                                                   // 0x0010(0x0010) (Edit, BlueprintVisible, ZeroConstructor, SaveGame, IsPlainOldData)
	unsigned char                                      bIsValid_69;                                              // 0x0020(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0021(0x0007) MISSED OFFSET
};

// ScriptStruct CoreUObject.Vector2f
// 0x0008
struct FVector2f
{
	float                                              X_69;                                                     // 0x0000(0x0004) (Edit, ZeroConstructor, SaveGame, IsPlainOldData)
	float                                              Y_69;                                                     // 0x0004(0x0004) (Edit, ZeroConstructor, SaveGame, IsPlainOldData)
};

// ScriptStruct CoreUObject.Box2f
// 0x0014
struct FBox2f
{
	struct FVector2f                                   min_69;                                                   // 0x0000(0x0008) (Edit, ZeroConstructor, SaveGame, IsPlainOldData)
	struct FVector2f                                   max_69;                                                   // 0x0008(0x0008) (Edit, ZeroConstructor, SaveGame, IsPlainOldData)
	unsigned char                                      bIsValid_69;                                              // 0x0010(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0011(0x0003) MISSED OFFSET
};

// ScriptStruct CoreUObject.Vector3d
// 0x0018
struct FVector3d
{
	double                                             X_69;                                                     // 0x0000(0x0008) (Edit, ZeroConstructor, SaveGame, IsPlainOldData)
	double                                             Y_69;                                                     // 0x0008(0x0008) (Edit, ZeroConstructor, SaveGame, IsPlainOldData)
	double                                             Z_69;                                                     // 0x0010(0x0008) (Edit, ZeroConstructor, SaveGame, IsPlainOldData)
};

// ScriptStruct CoreUObject.Box3d
// 0x0038
struct FBox3d
{
	struct FVector3d                                   min_69;                                                   // 0x0000(0x0018) (Edit, ZeroConstructor, SaveGame, IsPlainOldData)
	struct FVector3d                                   max_69;                                                   // 0x0018(0x0018) (Edit, ZeroConstructor, SaveGame, IsPlainOldData)
	unsigned char                                      IsValid_69;                                               // 0x0030(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0031(0x0007) MISSED OFFSET
};

// ScriptStruct CoreUObject.Vector3f
// 0x000C
struct FVector3f
{
	float                                              X_69;                                                     // 0x0000(0x0004) (Edit, ZeroConstructor, SaveGame, IsPlainOldData)
	float                                              Y_69;                                                     // 0x0004(0x0004) (Edit, ZeroConstructor, SaveGame, IsPlainOldData)
	float                                              Z_69;                                                     // 0x0008(0x0004) (Edit, ZeroConstructor, SaveGame, IsPlainOldData)
};

// ScriptStruct CoreUObject.Box3f
// 0x001C
struct FBox3f
{
	struct FVector3f                                   min_69;                                                   // 0x0000(0x000C) (Edit, ZeroConstructor, SaveGame, IsPlainOldData)
	struct FVector3f                                   max_69;                                                   // 0x000C(0x000C) (Edit, ZeroConstructor, SaveGame, IsPlainOldData)
	unsigned char                                      IsValid_69;                                               // 0x0018(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0019(0x0003) MISSED OFFSET
};

// ScriptStruct CoreUObject.BoxSphereBounds
// 0x0038
struct FBoxSphereBounds
{
	struct FVector                                     Origin_69;                                                // 0x0000(0x0018) (Edit, BlueprintVisible, ZeroConstructor, SaveGame, IsPlainOldData)
	struct FVector                                     BoxExtent_69;                                             // 0x0018(0x0018) (Edit, BlueprintVisible, ZeroConstructor, SaveGame, IsPlainOldData)
	double                                             SphereRadius_69;                                          // 0x0030(0x0008) (Edit, BlueprintVisible, ZeroConstructor, SaveGame, IsPlainOldData)
};

// ScriptStruct CoreUObject.BoxSphereBounds3d
// 0x0038
struct FBoxSphereBounds3d
{
	struct FVector3d                                   Origin_69;                                                // 0x0000(0x0018) (Edit, ZeroConstructor, SaveGame, IsPlainOldData)
	struct FVector3d                                   BoxExtent_69;                                             // 0x0018(0x0018) (Edit, ZeroConstructor, SaveGame, IsPlainOldData)
	double                                             SphereRadius_69;                                          // 0x0030(0x0008) (Edit, ZeroConstructor, SaveGame, IsPlainOldData)
};

// ScriptStruct CoreUObject.BoxSphereBounds3f
// 0x001C
struct FBoxSphereBounds3f
{
	struct FVector3f                                   Origin_69;                                                // 0x0000(0x000C) (Edit, ZeroConstructor, SaveGame, IsPlainOldData)
	struct FVector3f                                   BoxExtent_69;                                             // 0x000C(0x000C) (Edit, ZeroConstructor, SaveGame, IsPlainOldData)
	float                                              SphereRadius_69;                                          // 0x0018(0x0004) (Edit, ZeroConstructor, SaveGame, IsPlainOldData)
};

// ScriptStruct CoreUObject.Color
// 0x0004
struct FCoreUObject_FColor
{
	unsigned char                                      B_69;                                                     // 0x0000(0x0001) (Edit, BlueprintVisible, ZeroConstructor, SaveGame, IsPlainOldData)
	unsigned char                                      G_69;                                                     // 0x0001(0x0001) (Edit, BlueprintVisible, ZeroConstructor, SaveGame, IsPlainOldData)
	unsigned char                                      R_69;                                                     // 0x0002(0x0001) (Edit, BlueprintVisible, ZeroConstructor, SaveGame, IsPlainOldData)
	unsigned char                                      A_69;                                                     // 0x0003(0x0001) (Edit, BlueprintVisible, ZeroConstructor, SaveGame, IsPlainOldData)
};

// ScriptStruct CoreUObject.DirectoryPath
// 0x0010
struct FDirectoryPath
{
	struct FString                                     Path_69;                                                  // 0x0000(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
};

// ScriptStruct CoreUObject.DoubleRangeBound
// 0x0010
struct FDoubleRangeBound
{
	TEnumAsByte<ERangeBoundTypes>                      Type_69;                                                  // 0x0000(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0001(0x0007) MISSED OFFSET
	double                                             Value_69;                                                 // 0x0008(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct CoreUObject.DoubleRange
// 0x0020
struct FDoubleRange
{
	struct FDoubleRangeBound                           LowerBound_69;                                            // 0x0000(0x0010) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FDoubleRangeBound                           UpperBound_69;                                            // 0x0010(0x0010) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct CoreUObject.FallbackStruct
// 0x0001
struct FFallbackStruct
{
	unsigned char                                      UnknownData00[0x1];                                       // 0x0000(0x0001) MISSED OFFSET
};

// ScriptStruct CoreUObject.FilePath
// 0x0010
struct FFilePath
{
	struct FString                                     FilePath_69;                                              // 0x0000(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
};

// ScriptStruct CoreUObject.FloatInterval
// 0x0008
struct FFloatInterval
{
	float                                              min_69;                                                   // 0x0000(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              max_69;                                                   // 0x0004(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct CoreUObject.FloatRangeBound
// 0x0008
struct FFloatRangeBound
{
	TEnumAsByte<ERangeBoundTypes>                      Type_69;                                                  // 0x0000(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0001(0x0003) MISSED OFFSET
	float                                              Value_69;                                                 // 0x0004(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct CoreUObject.FloatRange
// 0x0010
struct FFloatRange
{
	struct FFloatRangeBound                            LowerBound_69;                                            // 0x0000(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FFloatRangeBound                            UpperBound_69;                                            // 0x0008(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct CoreUObject.FrameNumber
// 0x0004
struct FFrameNumber
{
	int                                                Value_69;                                                 // 0x0000(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct CoreUObject.FrameNumberRangeBound
// 0x0008
struct FFrameNumberRangeBound
{
	TEnumAsByte<ERangeBoundTypes>                      Type_69;                                                  // 0x0000(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0001(0x0003) MISSED OFFSET
	struct FFrameNumber                                Value_69;                                                 // 0x0004(0x0004) (Edit, BlueprintVisible)
};

// ScriptStruct CoreUObject.FrameNumberRange
// 0x0010
struct FFrameNumberRange
{
	struct FFrameNumberRangeBound                      LowerBound_69;                                            // 0x0000(0x0008) (Edit, BlueprintVisible)
	struct FFrameNumberRangeBound                      UpperBound_69;                                            // 0x0008(0x0008) (Edit, BlueprintVisible)
};

// ScriptStruct CoreUObject.FrameRate
// 0x0008
struct FFrameRate
{
	int                                                Numerator_69;                                             // 0x0000(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                Denominator_69;                                           // 0x0004(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct CoreUObject.FrameTime
// 0x0008
struct FFrameTime
{
	struct FFrameNumber                                FrameNumber_69;                                           // 0x0000(0x0004) (BlueprintVisible)
	float                                              SubFrame_69;                                              // 0x0004(0x0004) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct CoreUObject.InputDeviceId
// 0x0004
struct FInputDeviceId
{
	int                                                InternalId_69;                                            // 0x0000(0x0004) (Edit, ZeroConstructor, EditConst, IsPlainOldData)
};

// ScriptStruct CoreUObject.Int32Interval
// 0x0008
struct FInt32Interval
{
	int                                                min_69;                                                   // 0x0000(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                max_69;                                                   // 0x0004(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct CoreUObject.Int32RangeBound
// 0x0008
struct FInt32RangeBound
{
	TEnumAsByte<ERangeBoundTypes>                      Type_69;                                                  // 0x0000(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0001(0x0003) MISSED OFFSET
	int                                                Value_69;                                                 // 0x0004(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct CoreUObject.Int32Range
// 0x0010
struct FInt32Range
{
	struct FInt32RangeBound                            LowerBound_69;                                            // 0x0000(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FInt32RangeBound                            UpperBound_69;                                            // 0x0008(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct CoreUObject.InterpCurvePointFloat
// 0x0014
struct FInterpCurvePointFloat
{
	float                                              InVal_69;                                                 // 0x0000(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              OutVal_69;                                                // 0x0004(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              ArriveTangent_69;                                         // 0x0008(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              LeaveTangent_69;                                          // 0x000C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<EInterpCurveMode>                      InterpMode_69;                                            // 0x0010(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0011(0x0003) MISSED OFFSET
};

// ScriptStruct CoreUObject.InterpCurveFloat
// 0x0018
struct FInterpCurveFloat
{
	TArray<struct FInterpCurvePointFloat>              Points_69;                                                // 0x0000(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	bool                                               bIsLooped_69;                                             // 0x0010(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0011(0x0003) MISSED OFFSET
	float                                              LoopKeyOffset_69;                                         // 0x0014(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct CoreUObject.LinearColor
// 0x0010
struct FLinearColor
{
	float                                              R_69;                                                     // 0x0000(0x0004) (Edit, BlueprintVisible, ZeroConstructor, SaveGame, IsPlainOldData)
	float                                              G_69;                                                     // 0x0004(0x0004) (Edit, BlueprintVisible, ZeroConstructor, SaveGame, IsPlainOldData)
	float                                              B_69;                                                     // 0x0008(0x0004) (Edit, BlueprintVisible, ZeroConstructor, SaveGame, IsPlainOldData)
	float                                              A_69;                                                     // 0x000C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, SaveGame, IsPlainOldData)

	inline FLinearColor()
		: R(0), G(0), B(0), A(0)
	{ }

	inline FLinearColor(float r, float g, float b, float a)
		: R(r / 255.0f),
		  G(g / 255.0f),
		  B(b / 255.0f),
		  A(a)
	{ }

};

// ScriptStruct CoreUObject.InterpCurvePointLinearColor
// 0x0038
struct FInterpCurvePointLinearColor
{
	float                                              InVal_69;                                                 // 0x0000(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FLinearColor                                OutVal_69;                                                // 0x0004(0x0010) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FLinearColor                                ArriveTangent_69;                                         // 0x0014(0x0010) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FLinearColor                                LeaveTangent_69;                                          // 0x0024(0x0010) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<EInterpCurveMode>                      InterpMode_69;                                            // 0x0034(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0035(0x0003) MISSED OFFSET
};

// ScriptStruct CoreUObject.InterpCurveLinearColor
// 0x0018
struct FInterpCurveLinearColor
{
	TArray<struct FInterpCurvePointLinearColor>        Points_69;                                                // 0x0000(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	bool                                               bIsLooped_69;                                             // 0x0010(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0011(0x0003) MISSED OFFSET
	float                                              LoopKeyOffset_69;                                         // 0x0014(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct CoreUObject.Quat
// 0x0020
struct alignas(16) FQuat
{
	double                                             X_69;                                                     // 0x0000(0x0008) (Edit, BlueprintVisible, ZeroConstructor, SaveGame, IsPlainOldData)
	double                                             Y_69;                                                     // 0x0008(0x0008) (Edit, BlueprintVisible, ZeroConstructor, SaveGame, IsPlainOldData)
	double                                             Z_69;                                                     // 0x0010(0x0008) (Edit, BlueprintVisible, ZeroConstructor, SaveGame, IsPlainOldData)
	double                                             W_69;                                                     // 0x0018(0x0008) (Edit, BlueprintVisible, ZeroConstructor, SaveGame, IsPlainOldData)
};

// ScriptStruct CoreUObject.InterpCurvePointQuat
// 0x0080
struct FInterpCurvePointQuat
{
	float                                              InVal_69;                                                 // 0x0000(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0xC];                                       // 0x0004(0x000C) MISSED OFFSET
	struct FQuat                                       OutVal_69;                                                // 0x0010(0x0020) (Edit, BlueprintVisible, IsPlainOldData)
	struct FQuat                                       ArriveTangent_69;                                         // 0x0030(0x0020) (Edit, BlueprintVisible, IsPlainOldData)
	struct FQuat                                       LeaveTangent_69;                                          // 0x0050(0x0020) (Edit, BlueprintVisible, IsPlainOldData)
	TEnumAsByte<EInterpCurveMode>                      InterpMode_69;                                            // 0x0070(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0xF];                                       // 0x0071(0x000F) MISSED OFFSET
};

// ScriptStruct CoreUObject.TwoVectors
// 0x0030
struct FTwoVectors
{
	struct FVector                                     v1_69;                                                    // 0x0000(0x0018) (Edit, BlueprintVisible, ZeroConstructor, SaveGame, IsPlainOldData)
	struct FVector                                     v2_69;                                                    // 0x0018(0x0018) (Edit, BlueprintVisible, ZeroConstructor, SaveGame, IsPlainOldData)
};

// ScriptStruct CoreUObject.InterpCurvePointTwoVectors
// 0x00A0
struct FInterpCurvePointTwoVectors
{
	float                                              InVal_69;                                                 // 0x0000(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0004(0x0004) MISSED OFFSET
	struct FTwoVectors                                 OutVal_69;                                                // 0x0008(0x0030) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FTwoVectors                                 ArriveTangent_69;                                         // 0x0038(0x0030) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FTwoVectors                                 LeaveTangent_69;                                          // 0x0068(0x0030) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<EInterpCurveMode>                      InterpMode_69;                                            // 0x0098(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x7];                                       // 0x0099(0x0007) MISSED OFFSET
};

// ScriptStruct CoreUObject.InterpCurvePointVector
// 0x0058
struct FInterpCurvePointVector
{
	float                                              InVal_69;                                                 // 0x0000(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0004(0x0004) MISSED OFFSET
	struct FVector                                     OutVal_69;                                                // 0x0008(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FVector                                     ArriveTangent_69;                                         // 0x0020(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FVector                                     LeaveTangent_69;                                          // 0x0038(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<EInterpCurveMode>                      InterpMode_69;                                            // 0x0050(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x7];                                       // 0x0051(0x0007) MISSED OFFSET
};

// ScriptStruct CoreUObject.InterpCurvePointVector2D
// 0x0040
struct FInterpCurvePointVector2D
{
	float                                              InVal_69;                                                 // 0x0000(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0004(0x0004) MISSED OFFSET
	struct FVector2D                                   OutVal_69;                                                // 0x0008(0x0010) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FVector2D                                   ArriveTangent_69;                                         // 0x0018(0x0010) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FVector2D                                   LeaveTangent_69;                                          // 0x0028(0x0010) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<EInterpCurveMode>                      InterpMode_69;                                            // 0x0038(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x7];                                       // 0x0039(0x0007) MISSED OFFSET
};

// ScriptStruct CoreUObject.InterpCurveQuat
// 0x0018
struct FInterpCurveQuat
{
	TArray<struct FInterpCurvePointQuat>               Points_69;                                                // 0x0000(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	bool                                               bIsLooped_69;                                             // 0x0010(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0011(0x0003) MISSED OFFSET
	float                                              LoopKeyOffset_69;                                         // 0x0014(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct CoreUObject.InterpCurveTwoVectors
// 0x0018
struct FInterpCurveTwoVectors
{
	TArray<struct FInterpCurvePointTwoVectors>         Points_69;                                                // 0x0000(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	bool                                               bIsLooped_69;                                             // 0x0010(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0011(0x0003) MISSED OFFSET
	float                                              LoopKeyOffset_69;                                         // 0x0014(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct CoreUObject.InterpCurveVector
// 0x0018
struct FInterpCurveVector
{
	TArray<struct FInterpCurvePointVector>             Points_69;                                                // 0x0000(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	bool                                               bIsLooped_69;                                             // 0x0010(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0011(0x0003) MISSED OFFSET
	float                                              LoopKeyOffset_69;                                         // 0x0014(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct CoreUObject.InterpCurveVector2D
// 0x0018
struct FInterpCurveVector2D
{
	TArray<struct FInterpCurvePointVector2D>           Points_69;                                                // 0x0000(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	bool                                               bIsLooped_69;                                             // 0x0010(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0011(0x0003) MISSED OFFSET
	float                                              LoopKeyOffset_69;                                         // 0x0014(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct CoreUObject.IntPoint
// 0x0008
struct FIntPoint
{
	int                                                X_69;                                                     // 0x0000(0x0004) (Edit, BlueprintVisible, ZeroConstructor, SaveGame, IsPlainOldData)
	int                                                Y_69;                                                     // 0x0004(0x0004) (Edit, BlueprintVisible, ZeroConstructor, SaveGame, IsPlainOldData)
};

// ScriptStruct CoreUObject.IntVector
// 0x000C
struct FIntVector
{
	int                                                X_69;                                                     // 0x0000(0x0004) (Edit, BlueprintVisible, ZeroConstructor, SaveGame, IsPlainOldData)
	int                                                Y_69;                                                     // 0x0004(0x0004) (Edit, BlueprintVisible, ZeroConstructor, SaveGame, IsPlainOldData)
	int                                                Z_69;                                                     // 0x0008(0x0004) (Edit, BlueprintVisible, ZeroConstructor, SaveGame, IsPlainOldData)
};

// ScriptStruct CoreUObject.IntVector4
// 0x0010
struct FIntVector4
{
	int                                                X_69;                                                     // 0x0000(0x0004) (Edit, BlueprintVisible, ZeroConstructor, SaveGame, IsPlainOldData)
	int                                                Y_69;                                                     // 0x0004(0x0004) (Edit, BlueprintVisible, ZeroConstructor, SaveGame, IsPlainOldData)
	int                                                Z_69;                                                     // 0x0008(0x0004) (Edit, BlueprintVisible, ZeroConstructor, SaveGame, IsPlainOldData)
	int                                                W_69;                                                     // 0x000C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, SaveGame, IsPlainOldData)
};

// ScriptStruct CoreUObject.Plane
// 0x0008 (0x0020 - 0x0018)
struct alignas(16) FPlane : public FVector
{
	double                                             W_69;                                                     // 0x0018(0x0008) (Edit, BlueprintVisible, ZeroConstructor, SaveGame, IsPlainOldData)
};

// ScriptStruct CoreUObject.Matrix
// 0x0080
struct FMatrix
{
	struct FPlane                                      XPlane_69;                                                // 0x0000(0x0020) (Edit, BlueprintVisible, ZeroConstructor, SaveGame, IsPlainOldData)
	struct FPlane                                      YPlane_69;                                                // 0x0020(0x0020) (Edit, BlueprintVisible, ZeroConstructor, SaveGame, IsPlainOldData)
	struct FPlane                                      ZPlane_69;                                                // 0x0040(0x0020) (Edit, BlueprintVisible, ZeroConstructor, SaveGame, IsPlainOldData)
	struct FPlane                                      WPlane_69;                                                // 0x0060(0x0020) (Edit, BlueprintVisible, ZeroConstructor, SaveGame, IsPlainOldData)
};

// ScriptStruct CoreUObject.Plane4d
// 0x0008 (0x0020 - 0x0018)
struct FPlane4d : public FVector3d
{
	double                                             W_69;                                                     // 0x0018(0x0008) (Edit, ZeroConstructor, SaveGame, IsPlainOldData)
};

// ScriptStruct CoreUObject.Matrix44d
// 0x0080
struct FMatrix44d
{
	struct FPlane4d                                    XPlane_69;                                                // 0x0000(0x0020) (Edit, ZeroConstructor, SaveGame, IsPlainOldData)
	struct FPlane4d                                    YPlane_69;                                                // 0x0020(0x0020) (Edit, ZeroConstructor, SaveGame, IsPlainOldData)
	struct FPlane4d                                    ZPlane_69;                                                // 0x0040(0x0020) (Edit, ZeroConstructor, SaveGame, IsPlainOldData)
	struct FPlane4d                                    WPlane_69;                                                // 0x0060(0x0020) (Edit, ZeroConstructor, SaveGame, IsPlainOldData)
};

// ScriptStruct CoreUObject.Plane4f
// 0x0004 (0x0010 - 0x000C)
struct FPlane4f : public FVector3f
{
	float                                              W_69;                                                     // 0x000C(0x0004) (Edit, ZeroConstructor, SaveGame, IsPlainOldData)
};

// ScriptStruct CoreUObject.Matrix44f
// 0x0040
struct FMatrix44f
{
	struct FPlane4f                                    XPlane_69;                                                // 0x0000(0x0010) (Edit, ZeroConstructor, SaveGame, IsPlainOldData)
	struct FPlane4f                                    YPlane_69;                                                // 0x0010(0x0010) (Edit, ZeroConstructor, SaveGame, IsPlainOldData)
	struct FPlane4f                                    ZPlane_69;                                                // 0x0020(0x0010) (Edit, ZeroConstructor, SaveGame, IsPlainOldData)
	struct FPlane4f                                    WPlane_69;                                                // 0x0030(0x0010) (Edit, ZeroConstructor, SaveGame, IsPlainOldData)
};

// ScriptStruct CoreUObject.OrientedBox
// 0x0078
struct FOrientedBox
{
	struct FVector                                     Center_69;                                                // 0x0000(0x0018) (Edit, ZeroConstructor, SaveGame, IsPlainOldData)
	struct FVector                                     AxisX_69;                                                 // 0x0018(0x0018) (Edit, ZeroConstructor, SaveGame, IsPlainOldData)
	struct FVector                                     AxisY_69;                                                 // 0x0030(0x0018) (Edit, ZeroConstructor, SaveGame, IsPlainOldData)
	struct FVector                                     AxisZ_69;                                                 // 0x0048(0x0018) (Edit, ZeroConstructor, SaveGame, IsPlainOldData)
	double                                             ExtentX_69;                                               // 0x0060(0x0008) (Edit, ZeroConstructor, SaveGame, IsPlainOldData)
	double                                             ExtentY_69;                                               // 0x0068(0x0008) (Edit, ZeroConstructor, SaveGame, IsPlainOldData)
	double                                             ExtentZ_69;                                               // 0x0070(0x0008) (Edit, ZeroConstructor, SaveGame, IsPlainOldData)
};

// ScriptStruct CoreUObject.PackedNormal
// 0x0004
struct FPackedNormal
{
	unsigned char                                      X_69;                                                     // 0x0000(0x0001) (Edit, ZeroConstructor, SaveGame, IsPlainOldData)
	unsigned char                                      Y_69;                                                     // 0x0001(0x0001) (Edit, ZeroConstructor, SaveGame, IsPlainOldData)
	unsigned char                                      Z_69;                                                     // 0x0002(0x0001) (Edit, ZeroConstructor, SaveGame, IsPlainOldData)
	unsigned char                                      W_69;                                                     // 0x0003(0x0001) (Edit, ZeroConstructor, SaveGame, IsPlainOldData)
};

// ScriptStruct CoreUObject.PackedRGB10A2N
// 0x0004
struct FPackedRGB10A2N
{
	int                                                Packed_69;                                                // 0x0000(0x0004) (Edit, ZeroConstructor, SaveGame, IsPlainOldData)
};

// ScriptStruct CoreUObject.PackedRGBA16N
// 0x0008
struct FPackedRGBA16N
{
	int                                                XY_69;                                                    // 0x0000(0x0004) (Edit, ZeroConstructor, SaveGame, IsPlainOldData)
	int                                                ZW_69;                                                    // 0x0004(0x0004) (Edit, ZeroConstructor, SaveGame, IsPlainOldData)
};

// ScriptStruct CoreUObject.PlatformUserId
// 0x0004
struct FPlatformUserId
{
	int                                                InternalId_69;                                            // 0x0000(0x0004) (Edit, ZeroConstructor, EditConst, IsPlainOldData)
};

// ScriptStruct CoreUObject.PlatformInputDeviceState
// 0x0008
struct FPlatformInputDeviceState
{
	struct FPlatformUserId                             OwningPlatformUser_69;                                    // 0x0000(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, EditConst, IsPlainOldData)
	EInputDeviceConnectionState                        ConnectionState_69;                                       // 0x0004(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, EditConst, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0005(0x0003) MISSED OFFSET
};

// ScriptStruct CoreUObject.PolyglotTextData
// 0x00B8
struct FPolyglotTextData
{
	ELocalizedTextSourceCategory                       category_69;                                              // 0x0000(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0001(0x0007) MISSED OFFSET
	struct FString                                     NativeCulture_69;                                         // 0x0008(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     Namespace_69;                                             // 0x0018(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     Key_69;                                                   // 0x0028(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     NativeString_69;                                          // 0x0038(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	TMap<struct FString, struct FString>               LocalizedStrings_69;                                      // 0x0048(0x0050) (Edit, BlueprintVisible)
	bool                                               bIsMinimalPatch_69;                                       // 0x0098(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x7];                                       // 0x0099(0x0007) MISSED OFFSET
	struct FText                                       CachedText_69;                                            // 0x00A0(0x0018) (Transient)
};

// ScriptStruct CoreUObject.PrimaryAssetType
// 0x0004
struct FPrimaryAssetType
{
	struct FName                                       Name_69;                                                  // 0x0000(0x0008) (Edit, BlueprintVisible, ZeroConstructor, SaveGame, IsPlainOldData)
};

// ScriptStruct CoreUObject.PrimaryAssetId
// 0x0008
struct FPrimaryAssetId
{
	struct FPrimaryAssetType                           PrimaryAssetType_69;                                      // 0x0000(0x0004) (Edit, BlueprintVisible, ZeroConstructor, SaveGame)
	struct FName                                       PrimaryAssetName_69;                                      // 0x0004(0x0008) (Edit, BlueprintVisible, ZeroConstructor, SaveGame, IsPlainOldData)
};

// ScriptStruct CoreUObject.QualifiedFrameTime
// 0x0010
struct FQualifiedFrameTime
{
	struct FFrameTime                                  Time_69;                                                  // 0x0000(0x0008) (BlueprintVisible)
	struct FFrameRate                                  Rate_69;                                                  // 0x0008(0x0008) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct CoreUObject.Quat4d
// 0x0020
struct FQuat4d
{
	double                                             X_69;                                                     // 0x0000(0x0008) (Edit, ZeroConstructor, SaveGame, IsPlainOldData)
	double                                             Y_69;                                                     // 0x0008(0x0008) (Edit, ZeroConstructor, SaveGame, IsPlainOldData)
	double                                             Z_69;                                                     // 0x0010(0x0008) (Edit, ZeroConstructor, SaveGame, IsPlainOldData)
	double                                             W_69;                                                     // 0x0018(0x0008) (Edit, ZeroConstructor, SaveGame, IsPlainOldData)
};

// ScriptStruct CoreUObject.Quat4f
// 0x0010
struct FQuat4f
{
	float                                              X_69;                                                     // 0x0000(0x0004) (Edit, ZeroConstructor, SaveGame, IsPlainOldData)
	float                                              Y_69;                                                     // 0x0004(0x0004) (Edit, ZeroConstructor, SaveGame, IsPlainOldData)
	float                                              Z_69;                                                     // 0x0008(0x0004) (Edit, ZeroConstructor, SaveGame, IsPlainOldData)
	float                                              W_69;                                                     // 0x000C(0x0004) (Edit, ZeroConstructor, SaveGame, IsPlainOldData)
};

// ScriptStruct CoreUObject.RandomStream
// 0x0008
struct FRandomStream
{
	int                                                InitialSeed_69;                                           // 0x0000(0x0004) (Edit, BlueprintVisible, ZeroConstructor, SaveGame, IsPlainOldData)
	int                                                Seed_69;                                                  // 0x0004(0x0004) (ZeroConstructor, IsPlainOldData)
};

// ScriptStruct CoreUObject.Rotator
// 0x0018
struct FRotator
{
	double                                             Pitch_69;                                                 // 0x0000(0x0008) (Edit, BlueprintVisible, ZeroConstructor, SaveGame, IsPlainOldData)
	double                                             Yaw_69;                                                   // 0x0008(0x0008) (Edit, BlueprintVisible, ZeroConstructor, SaveGame, IsPlainOldData)
	double                                             Roll_69;                                                  // 0x0010(0x0008) (Edit, BlueprintVisible, ZeroConstructor, SaveGame, IsPlainOldData)
};

// ScriptStruct CoreUObject.Rotator3d
// 0x0018
struct FRotator3d
{
	double                                             Pitch_69;                                                 // 0x0000(0x0008) (Edit, ZeroConstructor, SaveGame, IsPlainOldData)
	double                                             Yaw_69;                                                   // 0x0008(0x0008) (Edit, ZeroConstructor, SaveGame, IsPlainOldData)
	double                                             Roll_69;                                                  // 0x0010(0x0008) (Edit, ZeroConstructor, SaveGame, IsPlainOldData)
};

// ScriptStruct CoreUObject.Rotator3f
// 0x000C
struct FRotator3f
{
	float                                              Pitch_69;                                                 // 0x0000(0x0004) (Edit, ZeroConstructor, SaveGame, IsPlainOldData)
	float                                              Yaw_69;                                                   // 0x0004(0x0004) (Edit, ZeroConstructor, SaveGame, IsPlainOldData)
	float                                              Roll_69;                                                  // 0x0008(0x0004) (Edit, ZeroConstructor, SaveGame, IsPlainOldData)
};

// ScriptStruct CoreUObject.SoftClassPath
// 0x0000 (0x0018 - 0x0018)
struct FSoftClassPath : public FSoftObjectPath
{

};

// ScriptStruct CoreUObject.TemplateString
// 0x0010
struct FTemplateString
{
	struct FString                                     Template_69;                                              // 0x0000(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
};

// ScriptStruct CoreUObject.TestUninitializedScriptStructMembersTest
// 0x0018
struct FTestUninitializedScriptStructMembersTest
{
	class Object_32759*                                UninitializedObjectReference_69;                          // 0x0000(0x0008) (ZeroConstructor, Transient)
	class Object_32759*                                InitializedObjectReference_69;                            // 0x0008(0x0008) (ZeroConstructor, Transient)
	float                                              UnusedValue_69;                                           // 0x0010(0x0004) (ZeroConstructor, Transient, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0014(0x0004) MISSED OFFSET
};

// ScriptStruct CoreUObject.Timecode
// 0x0014
struct FTimecode
{
	int                                                Hours_69;                                                 // 0x0000(0x0004) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                Minutes_69;                                               // 0x0004(0x0004) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                Seconds_69;                                               // 0x0008(0x0004) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                Frames_69;                                                // 0x000C(0x0004) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bDropFrameFormat_69;                                      // 0x0010(0x0001) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0011(0x0003) MISSED OFFSET
};

// ScriptStruct CoreUObject.Timespan
// 0x0008
struct FTimespan
{
	unsigned char                                      UnknownData00[0x8];                                       // 0x0000(0x0008) MISSED OFFSET
};

// ScriptStruct CoreUObject.Transform
// 0x0060
struct alignas(16) FCoreUObject_FTransform
{
	struct FQuat                                       Rotation_69;                                              // 0x0000(0x0020) (Edit, BlueprintVisible, SaveGame, IsPlainOldData)
	struct FVector                                     Translation_69;                                           // 0x0020(0x0018) (Edit, BlueprintVisible, ZeroConstructor, SaveGame, IsPlainOldData)
	unsigned char                                      UnknownData00[0x8];                                       // 0x0038(0x0008) MISSED OFFSET
	struct FVector                                     Scale3D_69;                                               // 0x0040(0x0018) (Edit, BlueprintVisible, ZeroConstructor, SaveGame, IsPlainOldData)
	unsigned char                                      UnknownData01[0x8];                                       // 0x0058(0x0008) MISSED OFFSET
};

// ScriptStruct CoreUObject.Transform3d
// 0x0060
struct FTransform3d
{
	struct FQuat4d                                     Rotation_69;                                              // 0x0000(0x0020) (Edit, SaveGame, IsPlainOldData)
	struct FVector3d                                   Translation_69;                                           // 0x0020(0x0018) (Edit, ZeroConstructor, SaveGame, IsPlainOldData)
	unsigned char                                      UnknownData00[0x8];                                       // 0x0038(0x0008) MISSED OFFSET
	struct FVector3d                                   Scale3D_69;                                               // 0x0040(0x0018) (Edit, ZeroConstructor, SaveGame, IsPlainOldData)
	unsigned char                                      UnknownData01[0x8];                                       // 0x0058(0x0008) MISSED OFFSET
};

// ScriptStruct CoreUObject.Transform3f
// 0x0030
struct FTransform3f
{
	struct FQuat4f                                     Rotation_69;                                              // 0x0000(0x0010) (Edit, SaveGame, IsPlainOldData)
	struct FVector3f                                   Translation_69;                                           // 0x0010(0x000C) (Edit, ZeroConstructor, SaveGame, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x001C(0x0004) MISSED OFFSET
	struct FVector3f                                   Scale3D_69;                                               // 0x0020(0x000C) (Edit, ZeroConstructor, SaveGame, IsPlainOldData)
	unsigned char                                      UnknownData01[0x4];                                       // 0x002C(0x0004) MISSED OFFSET
};

// ScriptStruct CoreUObject.Vector4
// 0x0020
struct alignas(16) FVector4
{
	double                                             X_69;                                                     // 0x0000(0x0008) (Edit, BlueprintVisible, ZeroConstructor, SaveGame, IsPlainOldData)
	double                                             Y_69;                                                     // 0x0008(0x0008) (Edit, BlueprintVisible, ZeroConstructor, SaveGame, IsPlainOldData)
	double                                             Z_69;                                                     // 0x0010(0x0008) (Edit, BlueprintVisible, ZeroConstructor, SaveGame, IsPlainOldData)
	double                                             W_69;                                                     // 0x0018(0x0008) (Edit, BlueprintVisible, ZeroConstructor, SaveGame, IsPlainOldData)
};

// ScriptStruct CoreUObject.Vector4d
// 0x0020
struct FVector4d
{
	double                                             X_69;                                                     // 0x0000(0x0008) (Edit, ZeroConstructor, SaveGame, IsPlainOldData)
	double                                             Y_69;                                                     // 0x0008(0x0008) (Edit, ZeroConstructor, SaveGame, IsPlainOldData)
	double                                             Z_69;                                                     // 0x0010(0x0008) (Edit, ZeroConstructor, SaveGame, IsPlainOldData)
	double                                             W_69;                                                     // 0x0018(0x0008) (Edit, ZeroConstructor, SaveGame, IsPlainOldData)
};

// ScriptStruct CoreUObject.Vector4f
// 0x0010
struct FVector4f
{
	float                                              X_69;                                                     // 0x0000(0x0004) (Edit, ZeroConstructor, SaveGame, IsPlainOldData)
	float                                              Y_69;                                                     // 0x0004(0x0004) (Edit, ZeroConstructor, SaveGame, IsPlainOldData)
	float                                              Z_69;                                                     // 0x0008(0x0004) (Edit, ZeroConstructor, SaveGame, IsPlainOldData)
	float                                              W_69;                                                     // 0x000C(0x0004) (Edit, ZeroConstructor, SaveGame, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

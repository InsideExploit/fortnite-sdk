#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Enums
//---------------------------------------------------------------------------

// Enum ControlRig.EControlRigState
enum class EControlRigState : uint8_t
{
	Init                           = 0,
	Update                         = 1,
	Invalid                        = 2,
	EControlRigState_MAX           = 3
};


// Enum ControlRig.ERigElementType
enum class ERigElementType : uint8_t
{
	None                           = 0,
	Bone                           = 1,
	Null                           = 2,
	Space                          = 3,
	Control                        = 4,
	Curve                          = 5,
	RigidBody                      = 6,
	Reference                      = 7,
	Last                           = 8,
	All                            = 9,
	ToResetAfterConstructionEvent  = 10,
	ERigElementType_MAX            = 11
};


// Enum ControlRig.ERigControlVisibility
enum class ERigControlVisibility : uint8_t
{
	UserDefined                    = 0,
	BasedOnSelection               = 1,
	ERigControlVisibility_MAX      = 2
};


// Enum ControlRig.ERigControlAxis
enum class ERigControlAxis : uint8_t
{
	X                              = 0,
	Y                              = 1,
	Z                              = 2,
	ERigControlAxis_MAX            = 3
};


// Enum ControlRig.ERigControlType
enum class ERigControlType : uint8_t
{
	Bool                           = 0,
	Float                          = 1,
	Integer                        = 2,
	Vector2D                       = 3,
	Position                       = 4,
	Scale                          = 5,
	Rotator                        = 6,
	Transform                      = 7,
	TransformNoScale               = 8,
	EulerTransform                 = 9,
	ERigControlType_MAX            = 10
};


// Enum ControlRig.ERigControlAnimationType
enum class ERigControlAnimationType : uint8_t
{
	AnimationControl               = 0,
	AnimationChannel               = 1,
	ProxyControl                   = 2,
	VisualCue                      = 3,
	ERigControlAnimationType_MAX   = 4
};


// Enum ControlRig.EControlRigDrawSettings
enum class EControlRigDrawSettings : uint8_t
{
	Points                         = 0,
	Lines                          = 1,
	LineStrip                      = 2,
	DynamicMesh                    = 3,
	EControlRigDrawSettings_MAX    = 4
};


// Enum ControlRig.ERigExecutionType
enum class ERigExecutionType : uint8_t
{
	Runtime                        = 0,
	Editing                        = 1,
	Max                            = 2
};


// Enum ControlRig.ERigTransformStackEntryType
enum class ERigTransformStackEntryType : uint8_t
{
	TransformPose                  = 0,
	ControlOffset                  = 1,
	ControlShape                   = 2,
	CurveValue                     = 3,
	ERigTransformStackEntryType_MAX = 4
};


// Enum ControlRig.ERigTransformType
enum class ERigTransformType : uint8_t
{
	InitialLocal                   = 0,
	CurrentLocal                   = 1,
	InitialGlobal                  = 2,
	CurrentGlobal                  = 3,
	NumTransformTypes              = 4,
	ERigTransformType_MAX          = 5
};


// Enum ControlRig.EControlRigInteractionType
enum class EControlRigInteractionType : uint8_t
{
	None                           = 0,
	Translate                      = 1,
	Rotate                         = 2,
	Scale                          = 3,
	All                            = 4,
	EControlRigInteractionType_MAX = 5
};


// Enum ControlRig.EControlRigVectorKind
enum class EControlRigVectorKind : uint8_t
{
	Direction                      = 0,
	Location                       = 1,
	EControlRigVectorKind_MAX      = 2
};


// Enum ControlRig.EControlRigComponentSpace
enum class EControlRigComponentSpace : uint8_t
{
	WorldSpace                     = 0,
	ActorSpace                     = 1,
	ComponentSpace                 = 2,
	RigSpace                       = 3,
	LocalSpace                     = 4,
	Max                            = 5
};


// Enum ControlRig.EControlRigComponentMapDirection
enum class EControlRigComponentMapDirection : uint8_t
{
	Input                          = 0,
	Output                         = 1,
	EControlRigComponentMapDirection_MAX = 2
};


// Enum ControlRig.ETransformSpaceMode
enum class ETransformSpaceMode : uint8_t
{
	LocalSpace                     = 0,
	GlobalSpace                    = 1,
	BaseSpace                      = 2,
	BaseJoint                      = 3,
	Max                            = 4
};


// Enum ControlRig.EControlRigClampSpatialMode
enum class EControlRigClampSpatialMode : uint8_t
{
	Plane                          = 0,
	Cylinder                       = 1,
	Sphere                         = 2,
	EControlRigClampSpatialMode_MAX = 3
};


// Enum ControlRig.ETransformGetterType
enum class ETransformGetterType : uint8_t
{
	Initial                        = 0,
	Current                        = 1,
	Max                            = 2
};


// Enum ControlRig.EBoneGetterSetterMode
enum class EBoneGetterSetterMode : uint8_t
{
	LocalSpace                     = 0,
	GlobalSpace                    = 1,
	Max                            = 2
};


// Enum ControlRig.EControlRigDrawHierarchyMode
enum class EControlRigDrawHierarchyMode : uint8_t
{
	Axes                           = 0,
	Max                            = 1
};


// Enum ControlRig.EControlRigAnimEasingType
enum class EControlRigAnimEasingType : uint8_t
{
	Linear                         = 0,
	QuadraticEaseIn                = 1,
	QuadraticEaseOut               = 2,
	QuadraticEaseInOut             = 3,
	CubicEaseIn                    = 4,
	CubicEaseOut                   = 5,
	CubicEaseInOut                 = 6,
	QuarticEaseIn                  = 7,
	QuarticEaseOut                 = 8,
	QuarticEaseInOut               = 9,
	QuinticEaseIn                  = 10,
	QuinticEaseOut                 = 11,
	QuinticEaseInOut               = 12,
	SineEaseIn                     = 13,
	SineEaseOut                    = 14,
	SineEaseInOut                  = 15,
	CircularEaseIn                 = 16,
	CircularEaseOut                = 17,
	CircularEaseInOut              = 18,
	ExponentialEaseIn              = 19,
	ExponentialEaseOut             = 20,
	ExponentialEaseInOut           = 21,
	ElasticEaseIn                  = 22,
	ElasticEaseOut                 = 23,
	ElasticEaseInOut               = 24,
	BackEaseIn                     = 25,
	BackEaseOut                    = 26,
	BackEaseInOut                  = 27,
	BounceEaseIn                   = 28,
	BounceEaseOut                  = 29,
	BounceEaseInOut                = 30,
	EControlRigAnimEasingType_MAX  = 31
};


// Enum ControlRig.ECRSimPointIntegrateType
enum class ECRSimPointIntegrateType : uint8_t
{
	Verlet                         = 0,
	SemiExplicitEuler              = 1,
	ECRSimPointIntegrateType_MAX   = 2
};


// Enum ControlRig.ECRSimConstraintType
enum class ECRSimConstraintType : uint8_t
{
	Distance                       = 0,
	DistanceFromA                  = 1,
	DistanceFromB                  = 2,
	Plane                          = 3,
	ECRSimConstraintType_MAX       = 4
};


// Enum ControlRig.ECRSimPointForceType
enum class ECRSimPointForceType : uint8_t
{
	Direction                      = 0,
	ECRSimPointForceType_MAX       = 1
};


// Enum ControlRig.ECRSimSoftCollisionType
enum class ECRSimSoftCollisionType : uint8_t
{
	Plane                          = 0,
	Sphere                         = 1,
	Cone                           = 2,
	ECRSimSoftCollisionType_MAX    = 3
};


// Enum ControlRig.EControlRigFKRigExecuteMode
enum class EControlRigFKRigExecuteMode : uint8_t
{
	Replace                        = 0,
	Additive                       = 1,
	Direct                         = 2,
	Max                            = 3
};


// Enum ControlRig.ERigBoneType
enum class ERigBoneType : uint8_t
{
	Imported                       = 0,
	User                           = 1,
	ERigBoneType_MAX               = 2
};


// Enum ControlRig.ERigMetadataType
enum class ERigMetadataType : uint8_t
{
	Bool                           = 0,
	BoolArray                      = 1,
	Float                          = 2,
	FloatArray                     = 3,
	Int32                          = 4,
	Int32Array                     = 5,
	Name                           = 6,
	NameArray                      = 7,
	Vector                         = 8,
	VectorArray                    = 9,
	Rotator                        = 10,
	RotatorArray                   = 11,
	Quat                           = 12,
	QuatArray                      = 13,
	Transform                      = 14,
	TransformArray                 = 15,
	LinearColor                    = 16,
	LinearColorArray               = 17,
	RigElementKey                  = 18,
	RigElementKeyArray             = 19,
	Invalid                        = 20,
	ERigMetadataType_MAX           = 21
};


// Enum ControlRig.ERigHierarchyNotification
enum class ERigHierarchyNotification : uint8_t
{
	ElementAdded                   = 0,
	ElementRemoved                 = 1,
	ElementRenamed                 = 2,
	ElementSelected                = 3,
	ElementDeselected              = 4,
	ParentChanged                  = 5,
	HierarchyReset                 = 6,
	ControlSettingChanged          = 7,
	ControlVisibilityChanged       = 8,
	ControlDrivenListChanged       = 9,
	ControlShapeTransformChanged   = 10,
	ParentWeightsChanged           = 11,
	InteractionBracketOpened       = 12,
	InteractionBracketClosed       = 13,
	Max                            = 14
};


// Enum ControlRig.ERigEvent
enum class ERigEvent : uint8_t
{
	None                           = 0,
	RequestAutoKey                 = 1,
	OpenUndoBracket                = 2,
	CloseUndoBracket               = 3,
	Max                            = 4
};


// Enum ControlRig.EControlRigSetKey
enum class EControlRigSetKey : uint8_t
{
	DoNotCare                      = 0,
	Always                         = 1,
	Never                          = 2,
	EControlRigSetKey_MAX          = 3
};


// Enum ControlRig.ERigControlValueType
enum class ERigControlValueType : uint8_t
{
	Initial                        = 0,
	Current                        = 1,
	Minimum                        = 2,
	Maximum                        = 3,
	ERigControlValueType_MAX       = 4
};


// Enum ControlRig.ERigSpaceType
enum class ERigSpaceType : uint8_t
{
	Global                         = 0,
	Bone                           = 1,
	Control                        = 2,
	Space                          = 3,
	ERigSpaceType_MAX              = 4
};


// Enum ControlRig.EMovieSceneControlRigSpaceType
enum class EMovieSceneControlRigSpaceType : uint8_t
{
	Parent                         = 0,
	World                          = 1,
	ControlRig                     = 2,
	EMovieSceneControlRigSpaceType_MAX = 3
};


// Enum ControlRig.ERigUnitDebugPointMode
enum class ERigUnitDebugPointMode : uint8_t
{
	Point                          = 0,
	Vector                         = 1,
	Max                            = 2
};


// Enum ControlRig.ERigUnitDebugTransformMode
enum class ERigUnitDebugTransformMode : uint8_t
{
	Point                          = 0,
	Axes                           = 1,
	Box                            = 2,
	Max                            = 3
};


// Enum ControlRig.ERigUnitVisualDebugPointMode
enum class ERigUnitVisualDebugPointMode : uint8_t
{
	Point                          = 0,
	Vector                         = 1,
	Max                            = 2
};


// Enum ControlRig.EAimMode
enum class EAimMode : uint8_t
{
	AimAtTarget                    = 0,
	OrientToTarget                 = 1,
	MAX                            = 2
};


// Enum ControlRig.EApplyTransformMode
enum class EApplyTransformMode : uint8_t
{
	Override                       = 0,
	Additive                       = 1,
	Max                            = 2
};


// Enum ControlRig.ERigSwitchParentMode
enum class ERigSwitchParentMode : uint8_t
{
	World                          = 0,
	DefaultParent                  = 1,
	ParentItem                     = 2,
	ERigSwitchParentMode_MAX       = 3
};


// Enum ControlRig.EControlRigCurveAlignment
enum class EControlRigCurveAlignment : uint8_t
{
	Front                          = 0,
	Stretched                      = 1,
	EControlRigCurveAlignment_MAX  = 2
};


// Enum ControlRig.EControlRigModifyBoneMode
enum class EControlRigModifyBoneMode : uint8_t
{
	OverrideLocal                  = 0,
	OverrideGlobal                 = 1,
	AdditiveLocal                  = 2,
	AdditiveGlobal                 = 3,
	Max                            = 4
};


// Enum ControlRig.EConstraintInterpType
enum class EConstraintInterpType : uint8_t
{
	Average                        = 0,
	Shortest                       = 1,
	Max                            = 2
};


// Enum ControlRig.ERBFKernelType
enum class ERBFKernelType : uint8_t
{
	Gaussian                       = 0,
	Exponential                    = 1,
	Linear                         = 2,
	Cubic                          = 3,
	Quintic                        = 4,
	ERBFKernelType_MAX             = 5
};


// Enum ControlRig.ERBFQuatDistanceType
enum class ERBFQuatDistanceType : uint8_t
{
	Euclidean                      = 0,
	ArcLength                      = 1,
	SwingAngle                     = 2,
	TwistAngle                     = 3,
	ERBFQuatDistanceType_MAX       = 4
};


// Enum ControlRig.ERBFVectorDistanceType
enum class ERBFVectorDistanceType : uint8_t
{
	Euclidean                      = 0,
	Manhattan                      = 1,
	ArcLength                      = 2,
	ERBFVectorDistanceType_MAX     = 3
};



//---------------------------------------------------------------------------
//Script Structs
//---------------------------------------------------------------------------

// ScriptStruct ControlRig.RigHierarchySettings
// 0x0004
struct FRigHierarchySettings
{
	int                                                ProceduralElementLimit_69;                                // 0x0000(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct ControlRig.RigElementKey
// 0x0008
struct FRigElementKey
{
	ERigElementType                                    Type_69;                                                  // 0x0000(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0001(0x0003) MISSED OFFSET
	struct FName                                       Name_69;                                                  // 0x0004(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct ControlRig.RigControlElementCustomization
// 0x0020
struct FRigControlElementCustomization
{
	TArray<struct FRigElementKey>                      AvailableSpaces_69;                                       // 0x0000(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
	TArray<struct FRigElementKey>                      RemovedSpaces_69;                                         // 0x0010(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
};

// ScriptStruct ControlRig.ControlRigDrawInstruction
// 0x00C0
struct FControlRigDrawInstruction
{
	struct FName                                       Name_69;                                                  // 0x0000(0x0008) (Edit, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<EControlRigDrawSettings>               PrimitiveType_69;                                         // 0x0004(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0005(0x0003) MISSED OFFSET
	TArray<struct FVector>                             Positions_69;                                             // 0x0008(0x0010) (Edit, ZeroConstructor)
	struct FLinearColor                                Color_69;                                                 // 0x0018(0x0010) (Edit, ZeroConstructor, IsPlainOldData)
	float                                              Thickness_69;                                             // 0x0028(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x4];                                       // 0x002C(0x0004) MISSED OFFSET
	struct FCoreUObject_FTransform                     Transform_69;                                             // 0x0030(0x0060) (Edit, IsPlainOldData)
	unsigned char                                      UnknownData02[0x30];                                      // 0x0090(0x0030) MISSED OFFSET
};

// ScriptStruct ControlRig.ControlRigDrawContainer
// 0x0018
struct FControlRigDrawContainer
{
	unsigned char                                      UnknownData00[0x8];                                       // 0x0000(0x0008) MISSED OFFSET
	TArray<struct FControlRigDrawInstruction>          Instructions_69;                                          // 0x0008(0x0010) (Edit, ZeroConstructor)
};

// ScriptStruct ControlRig.RigInfluenceEntry
// 0x0018
struct FRigInfluenceEntry
{
	struct FRigElementKey                              Source_69;                                                // 0x0000(0x0008)
	TArray<struct FRigElementKey>                      AffectedList_69;                                          // 0x0008(0x0010) (ZeroConstructor)
};

// ScriptStruct ControlRig.RigInfluenceMap
// 0x0068
struct FRigInfluenceMap
{
	struct FName                                       EventName_69;                                             // 0x0000(0x0008) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0004(0x0004) MISSED OFFSET
	TArray<struct FRigInfluenceEntry>                  Entries_69;                                               // 0x0008(0x0010) (ZeroConstructor)
	TMap<struct FRigElementKey, int>                   KeyToIndex_69;                                            // 0x0018(0x0050)
};

// ScriptStruct ControlRig.RigInfluenceMapPerEvent
// 0x0060
struct FRigInfluenceMapPerEvent
{
	TArray<struct FRigInfluenceMap>                    Maps_69;                                                  // 0x0000(0x0010) (ZeroConstructor)
	TMap<struct FName, int>                            EventToIndex_69;                                          // 0x0010(0x0050)
};

// ScriptStruct ControlRig.RigBaseElement
// 0x00E8
struct FRigBaseElement
{
	unsigned char                                      UnknownData00[0x8];                                       // 0x0000(0x0008) MISSED OFFSET
	struct FRigElementKey                              Key_69;                                                   // 0x0008(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, EditConst)
	struct FString                                     NameString_69;                                            // 0x0010(0x0010) (ZeroConstructor, Transient)
	int                                                Index_69;                                                 // 0x0020(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, EditConst, IsPlainOldData)
	int                                                SubIndex_69;                                              // 0x0024(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, EditConst, IsPlainOldData)
	bool                                               bSelected_69;                                             // 0x0028(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, Transient, IsPlainOldData)
	unsigned char                                      UnknownData01[0x3];                                       // 0x0029(0x0003) MISSED OFFSET
	int                                                CreatedAtInstructionIndex_69;                             // 0x002C(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, Transient, IsPlainOldData)
	unsigned char                                      UnknownData02[0xB8];                                      // 0x0030(0x00B8) MISSED OFFSET
};

// ScriptStruct ControlRig.RigComputedTransform
// 0x0070
struct FRigComputedTransform
{
	struct FCoreUObject_FTransform                     Transform_69;                                             // 0x0000(0x0060) (Edit, BlueprintVisible, BlueprintReadOnly, IsPlainOldData)
	unsigned char                                      UnknownData00[0x10];                                      // 0x0060(0x0010) MISSED OFFSET
};

// ScriptStruct ControlRig.RigLocalAndGlobalTransform
// 0x00E0
struct FRigLocalAndGlobalTransform
{
	struct FRigComputedTransform                       Local_69;                                                 // 0x0000(0x0070) (Edit, BlueprintVisible, BlueprintReadOnly)
	struct FRigComputedTransform                       Global_69;                                                // 0x0070(0x0070) (Edit, BlueprintVisible, BlueprintReadOnly)
};

// ScriptStruct ControlRig.RigCurrentAndInitialTransform
// 0x01C0
struct FRigCurrentAndInitialTransform
{
	struct FRigLocalAndGlobalTransform                 Current_69;                                               // 0x0000(0x00E0) (Edit, BlueprintVisible, BlueprintReadOnly)
	struct FRigLocalAndGlobalTransform                 Initial_69;                                               // 0x00E0(0x00E0) (Edit, BlueprintVisible, BlueprintReadOnly)
};

// ScriptStruct ControlRig.RigTransformElement
// 0x0208 (0x02F0 - 0x00E8)
struct FRigTransformElement : public FRigBaseElement
{
	unsigned char                                      UnknownData00[0x8];                                       // 0x00E8(0x0008) MISSED OFFSET
	struct FRigCurrentAndInitialTransform              Pose_69;                                                  // 0x00F0(0x01C0) (Edit, BlueprintVisible, BlueprintReadOnly)
	unsigned char                                      UnknownData01[0x40];                                      // 0x02B0(0x0040) MISSED OFFSET
};

// ScriptStruct ControlRig.RigMultiParentElement
// 0x0100 (0x03F0 - 0x02F0)
struct FRigMultiParentElement : public FRigTransformElement
{
	unsigned char                                      UnknownData00[0x100];                                     // 0x02F0(0x0100) MISSED OFFSET
};

// ScriptStruct ControlRig.RigControlLimitEnabled
// 0x0002
struct FRigControlLimitEnabled
{
	bool                                               bMinimum_69;                                              // 0x0000(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bMaximum_69;                                              // 0x0001(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct ControlRig.RigControlValueStorage
// 0x0084
struct FRigControlValueStorage
{
	float                                              Float00_69;                                               // 0x0000(0x0004) (ZeroConstructor, IsPlainOldData)
	float                                              Float01_69;                                               // 0x0004(0x0004) (ZeroConstructor, IsPlainOldData)
	float                                              Float02_69;                                               // 0x0008(0x0004) (ZeroConstructor, IsPlainOldData)
	float                                              Float03_69;                                               // 0x000C(0x0004) (ZeroConstructor, IsPlainOldData)
	float                                              Float10_69;                                               // 0x0010(0x0004) (ZeroConstructor, IsPlainOldData)
	float                                              Float11_69;                                               // 0x0014(0x0004) (ZeroConstructor, IsPlainOldData)
	float                                              Float12_69;                                               // 0x0018(0x0004) (ZeroConstructor, IsPlainOldData)
	float                                              Float13_69;                                               // 0x001C(0x0004) (ZeroConstructor, IsPlainOldData)
	float                                              Float20_69;                                               // 0x0020(0x0004) (ZeroConstructor, IsPlainOldData)
	float                                              Float21_69;                                               // 0x0024(0x0004) (ZeroConstructor, IsPlainOldData)
	float                                              Float22_69;                                               // 0x0028(0x0004) (ZeroConstructor, IsPlainOldData)
	float                                              Float23_69;                                               // 0x002C(0x0004) (ZeroConstructor, IsPlainOldData)
	float                                              Float30_69;                                               // 0x0030(0x0004) (ZeroConstructor, IsPlainOldData)
	float                                              Float31_69;                                               // 0x0034(0x0004) (ZeroConstructor, IsPlainOldData)
	float                                              Float32_69;                                               // 0x0038(0x0004) (ZeroConstructor, IsPlainOldData)
	float                                              Float33_69;                                               // 0x003C(0x0004) (ZeroConstructor, IsPlainOldData)
	float                                              Float00_2_69;                                             // 0x0040(0x0004) (ZeroConstructor, IsPlainOldData)
	float                                              Float01_2_69;                                             // 0x0044(0x0004) (ZeroConstructor, IsPlainOldData)
	float                                              Float02_2_69;                                             // 0x0048(0x0004) (ZeroConstructor, IsPlainOldData)
	float                                              Float03_2_69;                                             // 0x004C(0x0004) (ZeroConstructor, IsPlainOldData)
	float                                              Float10_2_69;                                             // 0x0050(0x0004) (ZeroConstructor, IsPlainOldData)
	float                                              Float11_2_69;                                             // 0x0054(0x0004) (ZeroConstructor, IsPlainOldData)
	float                                              Float12_2_69;                                             // 0x0058(0x0004) (ZeroConstructor, IsPlainOldData)
	float                                              Float13_2_69;                                             // 0x005C(0x0004) (ZeroConstructor, IsPlainOldData)
	float                                              Float20_2_69;                                             // 0x0060(0x0004) (ZeroConstructor, IsPlainOldData)
	float                                              Float21_2_69;                                             // 0x0064(0x0004) (ZeroConstructor, IsPlainOldData)
	float                                              Float22_2_69;                                             // 0x0068(0x0004) (ZeroConstructor, IsPlainOldData)
	float                                              Float23_2_69;                                             // 0x006C(0x0004) (ZeroConstructor, IsPlainOldData)
	float                                              Float30_2_69;                                             // 0x0070(0x0004) (ZeroConstructor, IsPlainOldData)
	float                                              Float31_2_69;                                             // 0x0074(0x0004) (ZeroConstructor, IsPlainOldData)
	float                                              Float32_2_69;                                             // 0x0078(0x0004) (ZeroConstructor, IsPlainOldData)
	float                                              Float33_2_69;                                             // 0x007C(0x0004) (ZeroConstructor, IsPlainOldData)
	bool                                               bValid_69;                                                // 0x0080(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0081(0x0003) MISSED OFFSET
};

// ScriptStruct ControlRig.RigControlValue
// 0x00F0
struct FRigControlValue
{
	struct FRigControlValueStorage                     FloatStorage_69;                                          // 0x0000(0x0084)
	unsigned char                                      UnknownData00[0xC];                                       // 0x0084(0x000C) MISSED OFFSET
	struct FCoreUObject_FTransform                     Storage_69;                                               // 0x0090(0x0060) (Deprecated, IsPlainOldData)
};

// ScriptStruct ControlRig.RigControlSettings
// 0x0280
struct FRigControlSettings
{
	ERigControlAnimationType                           AnimationType_69;                                         // 0x0000(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	ERigControlType                                    ControlType_69;                                           // 0x0001(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x2];                                       // 0x0002(0x0002) MISSED OFFSET
	struct FName                                       DisplayName_69;                                           // 0x0004(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	ERigControlAxis                                    PrimaryAxis_69;                                           // 0x0008(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bIsCurve_69;                                              // 0x0009(0x0001) (ZeroConstructor, Transient, IsPlainOldData)
	unsigned char                                      UnknownData01[0x6];                                       // 0x000A(0x0006) MISSED OFFSET
	TArray<struct FRigControlLimitEnabled>             LimitEnabled_69;                                          // 0x0010(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	bool                                               bDrawLimits_69;                                           // 0x0020(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData02[0xF];                                       // 0x0021(0x000F) MISSED OFFSET
	struct FRigControlValue                            MinimumValue_69;                                          // 0x0030(0x00F0) (BlueprintVisible)
	struct FRigControlValue                            MaximumValue_69;                                          // 0x0120(0x00F0) (BlueprintVisible)
	bool                                               bShapeVisible_69;                                         // 0x0210(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	ERigControlVisibility                              ShapeVisibility_69;                                       // 0x0211(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData03[0x2];                                       // 0x0212(0x0002) MISSED OFFSET
	struct FName                                       ShapeName_69;                                             // 0x0214(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FLinearColor                                ShapeColor_69;                                            // 0x0218(0x0010) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bIsTransientControl_69;                                   // 0x0228(0x0001) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData04[0x7];                                       // 0x0229(0x0007) MISSED OFFSET
	class Enum*                                        ControlEnum_69;                                           // 0x0230(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
	struct FRigControlElementCustomization             Customization_69;                                         // 0x0238(0x0020) (Edit, BlueprintVisible, BlueprintReadOnly)
	TArray<struct FRigElementKey>                      DrivenControls_69;                                        // 0x0258(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
	unsigned char                                      UnknownData05[0x10];                                      // 0x0268(0x0010) MISSED OFFSET
	bool                                               bGroupWithParentControl_69;                               // 0x0278(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData06[0x7];                                       // 0x0279(0x0007) MISSED OFFSET
};

// ScriptStruct ControlRig.RigPreferredEulerAngles
// 0x0038
struct FRigPreferredEulerAngles
{
	EEulerRotationOrder                                RotationOrder_69;                                         // 0x0000(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0001(0x0007) MISSED OFFSET
	struct FVector                                     Current_69;                                               // 0x0008(0x0018) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	struct FVector                                     Initial_69;                                               // 0x0020(0x0018) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct ControlRig.RigControlElement
// 0x0640 (0x0A30 - 0x03F0)
struct FRigControlElement : public FRigMultiParentElement
{
	struct FRigControlSettings                         Settings_69;                                              // 0x03F0(0x0280) (Edit, BlueprintVisible, BlueprintReadOnly)
	struct FRigCurrentAndInitialTransform              Offset_69;                                                // 0x0670(0x01C0) (Edit, BlueprintVisible, BlueprintReadOnly)
	struct FRigCurrentAndInitialTransform              Shape_69;                                                 // 0x0830(0x01C0) (Edit, BlueprintVisible, BlueprintReadOnly)
	struct FRigPreferredEulerAngles                    PreferredEulerAngles_69;                                  // 0x09F0(0x0038) (Edit, BlueprintVisible, BlueprintReadOnly)
	unsigned char                                      UnknownData00[0x8];                                       // 0x0A28(0x0008) MISSED OFFSET
};

// ScriptStruct ControlRig.CachedRigElement
// 0x0018
struct FCachedRigElement
{
	struct FRigElementKey                              Key_69;                                                   // 0x0000(0x0008)
	uint16_t                                           Index_69;                                                 // 0x0008(0x0002) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x2];                                       // 0x000A(0x0002) MISSED OFFSET
	int                                                ContainerVersion_69;                                      // 0x000C(0x0004) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x8];                                       // 0x0010(0x0008) MISSED OFFSET
};

// ScriptStruct ControlRig.RigPoseElement
// 0x00F0
struct FRigPoseElement
{
	struct FCachedRigElement                           Index_69;                                                 // 0x0000(0x0018)
	unsigned char                                      UnknownData00[0x8];                                       // 0x0018(0x0008) MISSED OFFSET
	struct FCoreUObject_FTransform                     GlobalTransform_69;                                       // 0x0020(0x0060) (IsPlainOldData)
	struct FCoreUObject_FTransform                     LocalTransform_69;                                        // 0x0080(0x0060) (IsPlainOldData)
	float                                              CurveValue_69;                                            // 0x00E0(0x0004) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0xC];                                       // 0x00E4(0x000C) MISSED OFFSET
};

// ScriptStruct ControlRig.RigPose
// 0x0070
struct FRigPose
{
	TArray<struct FRigPoseElement>                     Elements_69;                                              // 0x0000(0x0010) (ZeroConstructor)
	int                                                HierarchyTopologyVersion_69;                              // 0x0010(0x0004) (ZeroConstructor, IsPlainOldData)
	int                                                PoseHash_69;                                              // 0x0014(0x0004) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x58];                                      // 0x0018(0x0058) MISSED OFFSET
};

// ScriptStruct ControlRig.RigElementWeight
// 0x000C
struct FRigElementWeight
{
	float                                              Location_69;                                              // 0x0000(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              Rotation_69;                                              // 0x0004(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              Scale_69;                                                 // 0x0008(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct ControlRig.RigNullElement
// 0x0000 (0x03F0 - 0x03F0)
struct FRigNullElement : public FRigMultiParentElement
{

};

// ScriptStruct ControlRig.RigSingleParentElement
// 0x0010 (0x0300 - 0x02F0)
struct FRigSingleParentElement : public FRigTransformElement
{
	unsigned char                                      UnknownData00[0x10];                                      // 0x02F0(0x0010) MISSED OFFSET
};

// ScriptStruct ControlRig.RigBoneElement
// 0x0000 (0x0300 - 0x0300)
struct FRigBoneElement : public FRigSingleParentElement
{
	ERigBoneType                                       BoneType_69;                                              // 0x02F8(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, EditConst, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x02F9(0x0007) MISSED OFFSET
};

// ScriptStruct ControlRig.ControlRigComponentMappedElement
// 0x00C0
struct FControlRigComponentMappedElement
{
	struct FComponentReference                         ComponentReference_69;                                    // 0x0000(0x0028) (Edit, BlueprintVisible)
	int                                                TransformIndex_69;                                        // 0x0028(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FName                                       TransformName_69;                                         // 0x002C(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	ERigElementType                                    ElementType_69;                                           // 0x0030(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0031(0x0003) MISSED OFFSET
	struct FName                                       ElementName_69;                                           // 0x0034(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	EControlRigComponentMapDirection                   Direction_69;                                             // 0x0038(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x7];                                       // 0x0039(0x0007) MISSED OFFSET
	struct FCoreUObject_FTransform                     Offset_69;                                                // 0x0040(0x0060) (Edit, BlueprintVisible, IsPlainOldData)
	float                                              Weight_69;                                                // 0x00A0(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	EControlRigComponentSpace                          Space_69;                                                 // 0x00A4(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData02[0x3];                                       // 0x00A5(0x0003) MISSED OFFSET
	class SceneComponent*                              SceneComponent_69;                                        // 0x00A8(0x0008) (ExportObject, ZeroConstructor, Transient, InstancedReference)
	int                                                ElementIndex_69;                                          // 0x00B0(0x0004) (ZeroConstructor, Transient, IsPlainOldData)
	int                                                SubIndex_69;                                              // 0x00B4(0x0004) (ZeroConstructor, Transient, IsPlainOldData)
	unsigned char                                      UnknownData03[0x8];                                       // 0x00B8(0x0008) MISSED OFFSET
};

// ScriptStruct ControlRig.ControlRigComponentMappedBone
// 0x0008
struct FControlRigComponentMappedBone
{
	struct FName                                       Source_69;                                                // 0x0000(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FName                                       Target_69;                                                // 0x0004(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct ControlRig.ControlRigComponentMappedCurve
// 0x0008
struct FControlRigComponentMappedCurve
{
	struct FName                                       Source_69;                                                // 0x0000(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FName                                       Target_69;                                                // 0x0004(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct ControlRig.ControlRigComponentMappedComponent
// 0x0010
struct FControlRigComponentMappedComponent
{
	class SceneComponent*                              Component_69;                                             // 0x0000(0x0008) (Edit, BlueprintVisible, ExportObject, ZeroConstructor, InstancedReference)
	struct FName                                       ElementName_69;                                           // 0x0008(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	ERigElementType                                    ElementType_69;                                           // 0x000C(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	EControlRigComponentMapDirection                   Direction_69;                                             // 0x000D(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x2];                                       // 0x000E(0x0002) MISSED OFFSET
};

// ScriptStruct ControlRig.ControlRigShapeDefinition
// 0x00A0
struct FControlRigShapeDefinition
{
	struct FName                                       ShapeName_69;                                             // 0x0000(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0004(0x0004) MISSED OFFSET
	unsigned char                                      UnknownData01[0x28];                                      // 0x0004(0x0028) UNKNOWN PROPERTY: SoftObjectProperty ControlRig.ControlRigShapeDefinition.StaticMesh_69
	struct FCoreUObject_FTransform                     Transform_69;                                             // 0x0030(0x0060) (Edit, BlueprintVisible, BlueprintReadOnly, IsPlainOldData)
	unsigned char                                      UnknownData02[0x10];                                      // 0x0090(0x0010) MISSED OFFSET
};

// ScriptStruct ControlRig.RigMirrorSettings
// 0x0028
struct FRigMirrorSettings
{
	TEnumAsByte<EAxis>                                 MirrorAxis_69;                                            // 0x0000(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<EAxis>                                 AxisToFlip_69;                                            // 0x0001(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x6];                                       // 0x0002(0x0006) MISSED OFFSET
	struct FString                                     SearchString_69;                                          // 0x0008(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     ReplaceString_69;                                         // 0x0018(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
};

// ScriptStruct ControlRig.RigRigidBodySettings
// 0x0004
struct FRigRigidBodySettings
{
	float                                              Mass_69;                                                  // 0x0000(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct ControlRig.ChannelMapInfo
// 0x0038
struct FChannelMapInfo
{
	int                                                ControlIndex_69;                                          // 0x0000(0x0004) (ZeroConstructor, IsPlainOldData)
	int                                                TotalChannelIndex_69;                                     // 0x0004(0x0004) (ZeroConstructor, IsPlainOldData)
	int                                                ChannelIndex_69;                                          // 0x0008(0x0004) (ZeroConstructor, IsPlainOldData)
	int                                                ParentControlIndex_69;                                    // 0x000C(0x0004) (ZeroConstructor, IsPlainOldData)
	struct FName                                       ChannelTypeName_69;                                       // 0x0010(0x0008) (ZeroConstructor, IsPlainOldData)
	bool                                               bDoesHaveSpace_69;                                        // 0x0014(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0015(0x0003) MISSED OFFSET
	int                                                SpaceChannelIndex_69;                                     // 0x0018(0x0004) (ZeroConstructor, IsPlainOldData)
	int                                                MaskIndex_69;                                             // 0x001C(0x0004) (ZeroConstructor, IsPlainOldData)
	int                                                CategoryIndex_69;                                         // 0x0020(0x0004) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x4];                                       // 0x0024(0x0004) MISSED OFFSET
	TArray<uint32_t>                                   ConstraintsIndex_69;                                      // 0x0028(0x0010) (ZeroConstructor)
};

// ScriptStruct ControlRig.EnumParameterNameAndCurve
// 0x00E8
struct FEnumParameterNameAndCurve
{
	struct FName                                       ParameterName_69;                                         // 0x0000(0x0008) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0004(0x0004) MISSED OFFSET
	struct FMovieSceneByteChannel                      ParameterCurve_69;                                        // 0x0008(0x00E0)
};

// ScriptStruct ControlRig.IntegerParameterNameAndCurve
// 0x00E0
struct FIntegerParameterNameAndCurve
{
	struct FName                                       ParameterName_69;                                         // 0x0000(0x0008) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0004(0x0004) MISSED OFFSET
	struct FMovieSceneIntegerChannel                   ParameterCurve_69;                                        // 0x0008(0x00D8)
};

// ScriptStruct ControlRig.MovieSceneControlRigSpaceBaseKey
// 0x000C
struct FMovieSceneControlRigSpaceBaseKey
{
	EMovieSceneControlRigSpaceType                     SpaceType_69;                                             // 0x0000(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0001(0x0003) MISSED OFFSET
	struct FRigElementKey                              ControlRigElement_69;                                     // 0x0004(0x0008) (Edit)
};

// ScriptStruct ControlRig.MovieSceneControlRigSpaceChannel
// 0x0098 (0x00E8 - 0x0050)
struct FMovieSceneControlRigSpaceChannel : public FMovieSceneChannel
{
	TArray<struct FFrameNumber>                        KeyTimes_69;                                              // 0x0050(0x0010) (ZeroConstructor)
	TArray<struct FMovieSceneControlRigSpaceBaseKey>   KeyValues_69;                                             // 0x0060(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData00[0x78];                                      // 0x0070(0x0078) MISSED OFFSET
};

// ScriptStruct ControlRig.SpaceControlNameAndChannel
// 0x00F0
struct FSpaceControlNameAndChannel
{
	struct FName                                       ControlName_69;                                           // 0x0000(0x0008) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0004(0x0004) MISSED OFFSET
	struct FMovieSceneControlRigSpaceChannel           SpaceCurve_69;                                            // 0x0008(0x00E8)
};

// ScriptStruct ControlRig.RigControlCopy
// 0x02A0
struct FRigControlCopy
{
	unsigned char                                      UnknownData00[0x10];                                      // 0x0000(0x0010) MISSED OFFSET
	struct FName                                       Name_69;                                                  // 0x0010(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	ERigControlType                                    ControlType_69;                                           // 0x0014(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0xB];                                       // 0x0015(0x000B) MISSED OFFSET
	struct FRigControlValue                            Value_69;                                                 // 0x0020(0x00F0)
	struct FRigElementKey                              ParentKey_69;                                             // 0x0110(0x0008) (Edit, BlueprintVisible)
	unsigned char                                      UnknownData02[0x8];                                       // 0x0118(0x0008) MISSED OFFSET
	struct FCoreUObject_FTransform                     OffsetTransform_69;                                       // 0x0120(0x0060) (Edit, BlueprintVisible, IsPlainOldData)
	struct FCoreUObject_FTransform                     ParentTransform_69;                                       // 0x0180(0x0060) (Edit, BlueprintVisible, IsPlainOldData)
	struct FCoreUObject_FTransform                     LocalTransform_69;                                        // 0x01E0(0x0060) (Edit, BlueprintVisible, IsPlainOldData)
	struct FCoreUObject_FTransform                     GlobalTransform_69;                                       // 0x0240(0x0060) (Edit, BlueprintVisible, IsPlainOldData)
};

// ScriptStruct ControlRig.ControlRigControlPose
// 0x0060
struct FControlRigControlPose
{
	TArray<struct FRigControlCopy>                     CopyOfControls_69;                                        // 0x0000(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	unsigned char                                      UnknownData00[0x50];                                      // 0x0010(0x0050) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit
// 0x0000 (0x0008 - 0x0008)
struct FRigUnit : public FRigVMStruct
{

};

// ScriptStruct ControlRig.ControlRigExecuteContext
// 0x0008 (0x0030 - 0x0028)
struct FControlRigExecuteContext : public FRigVMExecuteContext
{
	unsigned char                                      UnknownData00[0x8];                                       // 0x0028(0x0008) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnitMutable
// 0x0030 (0x0038 - 0x0008)
struct FRigUnitMutable : public FRigUnit
{
	struct FControlRigExecuteContext                   ExecuteContext_69;                                        // 0x0008(0x0030) (Edit, BlueprintVisible, Transient)
};

// ScriptStruct ControlRig.MovieSceneControlRigInstanceData
// 0x0118 (0x0120 - 0x0008)
struct FMovieSceneControlRigInstanceData : public FMovieSceneSequenceInstanceData
{
	bool                                               bAdditive_69;                                             // 0x0008(0x0001) (ZeroConstructor, IsPlainOldData)
	bool                                               bApplyBoneFilter_69;                                      // 0x0009(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x6];                                       // 0x000A(0x0006) MISSED OFFSET
	struct FInputBlendPose                             BoneFilter_69;                                            // 0x0010(0x0010)
	struct FMovieSceneFloatChannel                     Weight_69;                                                // 0x0020(0x00E8)
	struct FMovieSceneEvaluationOperand                Operand_69;                                               // 0x0108(0x0014)
	unsigned char                                      UnknownData01[0x4];                                       // 0x011C(0x0004) MISSED OFFSET
};

// ScriptStruct ControlRig.RigTransformStackEntry
// 0x00F0
struct FRigTransformStackEntry
{
	struct FRigElementKey                              Key_69;                                                   // 0x0000(0x0008)
	TEnumAsByte<ERigTransformStackEntryType>           EntryType_69;                                             // 0x0008(0x0001) (ZeroConstructor, IsPlainOldData)
	TEnumAsByte<ERigTransformType>                     TransformType_69;                                         // 0x0009(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x6];                                       // 0x000A(0x0006) MISSED OFFSET
	struct FCoreUObject_FTransform                     OldTransform_69;                                          // 0x0010(0x0060) (IsPlainOldData)
	struct FCoreUObject_FTransform                     NewTransform_69;                                          // 0x0070(0x0060) (IsPlainOldData)
	bool                                               bAffectChildren_69;                                       // 0x00D0(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x7];                                       // 0x00D1(0x0007) MISSED OFFSET
	TArray<struct FString>                             Callstack_69;                                             // 0x00D8(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData02[0x8];                                       // 0x00E8(0x0008) MISSED OFFSET
};

// ScriptStruct ControlRig.RigElementParentConstraint
// 0x0090
struct FRigElementParentConstraint
{
	unsigned char                                      UnknownData00[0x90];                                      // 0x0000(0x0090) MISSED OFFSET
};

// ScriptStruct ControlRig.RigCurveElement
// 0x0008 (0x00F0 - 0x00E8)
struct FRigCurveElement : public FRigBaseElement
{
	unsigned char                                      UnknownData00[0x8];                                       // 0x00E8(0x0008) MISSED OFFSET
};

// ScriptStruct ControlRig.RigRigidBodyElement
// 0x0000 (0x0300 - 0x0300)
struct FRigRigidBodyElement : public FRigSingleParentElement
{
	struct FRigRigidBodySettings                       Settings_69;                                              // 0x02F8(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly)
	unsigned char                                      UnknownData00[0x4];                                       // 0x02FC(0x0004) MISSED OFFSET
};

// ScriptStruct ControlRig.RigReferenceElement
// 0x0010 (0x0310 - 0x0300)
struct FRigReferenceElement : public FRigSingleParentElement
{
	unsigned char                                      UnknownData00[0x10];                                      // 0x0300(0x0010) MISSED OFFSET
};

// ScriptStruct ControlRig.RigHierarchyCopyPasteContentPerElement
// 0x0200
struct FRigHierarchyCopyPasteContentPerElement
{
	struct FRigElementKey                              Key_69;                                                   // 0x0000(0x0008)
	struct FString                                     Content_69;                                               // 0x0008(0x0010) (ZeroConstructor)
	TArray<struct FRigElementKey>                      Parents_69;                                               // 0x0018(0x0010) (ZeroConstructor)
	TArray<struct FRigElementWeight>                   ParentWeights_69;                                         // 0x0028(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData00[0x8];                                       // 0x0038(0x0008) MISSED OFFSET
	struct FRigCurrentAndInitialTransform              Pose_69;                                                  // 0x0040(0x01C0)
};

// ScriptStruct ControlRig.RigHierarchyCopyPasteContent
// 0x0050
struct FRigHierarchyCopyPasteContent
{
	TArray<struct FRigHierarchyCopyPasteContentPerElement> Elements_69;                                              // 0x0000(0x0010) (ZeroConstructor)
	TArray<ERigElementType>                            Types_69;                                                 // 0x0010(0x0010) (ZeroConstructor)
	TArray<struct FString>                             Contents_69;                                              // 0x0020(0x0010) (ZeroConstructor)
	TArray<struct FCoreUObject_FTransform>             LocalTransforms_69;                                       // 0x0030(0x0010) (ZeroConstructor)
	TArray<struct FCoreUObject_FTransform>             GlobalTransforms_69;                                      // 0x0040(0x0010) (ZeroConstructor)
};

// ScriptStruct ControlRig.RigUnit_AnimBase
// 0x0000 (0x0008 - 0x0008)
struct FRigUnit_AnimBase : public FRigUnit
{

};

// ScriptStruct ControlRig.RigUnit_DebugBase
// 0x0000 (0x0008 - 0x0008)
struct FRigUnit_DebugBase : public FRigUnit
{

};

// ScriptStruct ControlRig.RigUnit_DebugBaseMutable
// 0x0000 (0x0038 - 0x0038)
struct FRigUnit_DebugBaseMutable : public FRigUnitMutable
{

};

// ScriptStruct ControlRig.RigUnit_HighlevelBase
// 0x0000 (0x0008 - 0x0008)
struct FRigUnit_HighlevelBase : public FRigUnit
{

};

// ScriptStruct ControlRig.RigUnit_HighlevelBaseMutable
// 0x0000 (0x0038 - 0x0038)
struct FRigUnit_HighlevelBaseMutable : public FRigUnitMutable
{

};

// ScriptStruct ControlRig.RigUnit_MathBase
// 0x0000 (0x0008 - 0x0008)
struct FRigUnit_MathBase : public FRigUnit
{

};

// ScriptStruct ControlRig.RigUnit_MathMutableBase
// 0x0000 (0x0038 - 0x0038)
struct FRigUnit_MathMutableBase : public FRigUnitMutable
{

};

// ScriptStruct ControlRig.RigUnit_SimBase
// 0x0000 (0x0008 - 0x0008)
struct FRigUnit_SimBase : public FRigUnit
{

};

// ScriptStruct ControlRig.RigUnit_SimBaseMutable
// 0x0000 (0x0038 - 0x0038)
struct FRigUnit_SimBaseMutable : public FRigUnitMutable
{

};

// ScriptStruct ControlRig.StructReference
// 0x0008
struct FStructReference
{
	unsigned char                                      UnknownData00[0x8];                                       // 0x0000(0x0008) MISSED OFFSET
};

// ScriptStruct ControlRig.ControlRigIOSettings
// 0x0002
struct FControlRigIOSettings
{
	bool                                               bUpdatePose_69;                                           // 0x0000(0x0001) (ZeroConstructor, IsPlainOldData)
	bool                                               bUpdateCurves_69;                                         // 0x0001(0x0001) (ZeroConstructor, IsPlainOldData)
};

// ScriptStruct ControlRig.ControlRigAnimNodeEventName
// 0x0004
struct FControlRigAnimNodeEventName
{
	struct FName                                       EventName_69;                                             // 0x0000(0x0008) (Edit, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct ControlRig.AnimNode_ControlRigBase
// 0x0218 (0x0270 - 0x0058)
struct FAnimNode_ControlRigBase : public FAnimNode_CustomProperty
{
	struct FPoseLink                                   Source_69;                                                // 0x0058(0x0010) (Edit)
	bool                                               bResetInputPoseToInitial_69;                              // 0x0068(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	bool                                               bTransferInputPose_69;                                    // 0x0069(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	bool                                               bTransferInputCurves_69;                                  // 0x006A(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	bool                                               bTransferPoseInGlobalSpace_69;                            // 0x006B(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x006C(0x0004) MISSED OFFSET
	TArray<struct FBoneReference>                      InputBonesToTransfer_69;                                  // 0x0070(0x0010) (Edit, ZeroConstructor)
	unsigned char                                      UnknownData01[0x1C0];                                     // 0x0080(0x01C0) MISSED OFFSET
	TWeakObjectPtr<class NodeMappingContainer>         NodeMappingContainer_69;                                  // 0x0240(0x0008) (ZeroConstructor, Transient, IsPlainOldData)
	struct FControlRigIOSettings                       InputSettings_69;                                         // 0x0248(0x0002) (Transient)
	struct FControlRigIOSettings                       OutputSettings_69;                                        // 0x024A(0x0002) (Transient)
	bool                                               bExecute_69;                                              // 0x024C(0x0001) (ZeroConstructor, Transient, IsPlainOldData)
	unsigned char                                      UnknownData02[0xB];                                       // 0x024D(0x000B) MISSED OFFSET
	TArray<struct FControlRigAnimNodeEventName>        EventQueue_69;                                            // 0x0258(0x0010) (Edit, ZeroConstructor)
	unsigned char                                      UnknownData03[0x8];                                       // 0x0268(0x0008) MISSED OFFSET
};

// ScriptStruct ControlRig.AnimNode_ControlRig
// 0x0200 (0x0470 - 0x0270)
struct FAnimNode_ControlRig : public FAnimNode_ControlRigBase
{
	class ControlRig*                                  ControlRigClass_69;                                       // 0x0270(0x0008) (Edit, ZeroConstructor)
	class ControlRig*                                  ControlRig_69;                                            // 0x0278(0x0008) (ZeroConstructor, Transient)
	float                                              Alpha_69;                                                 // 0x0280(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	EAnimAlphaInputType                                AlphaInputType_69;                                        // 0x0284(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      bAlphaBoolEnabled_69 : 1;                                 // 0x0285(0x0001) (Edit)
	unsigned char                                      bSetRefPoseFromSkeleton_69 : 1;                           // 0x0285(0x0001) (Edit)
	unsigned char                                      UnknownData00[0x2];                                       // 0x0286(0x0002) MISSED OFFSET
	struct FInputScaleBias                             AlphaScaleBias_69;                                        // 0x0288(0x0008) (Edit)
	struct FInputAlphaBoolBlend                        AlphaBoolBlend_69;                                        // 0x0290(0x0048) (Edit)
	struct FName                                       AlphaCurveName_69;                                        // 0x02D8(0x0008) (Edit, ZeroConstructor, IsPlainOldData)
	struct FInputScaleBiasClamp                        AlphaScaleBiasClamp_69;                                   // 0x02DC(0x0030) (Edit)
	unsigned char                                      UnknownData01[0x4];                                       // 0x030C(0x0004) MISSED OFFSET
	TMap<struct FName, struct FName>                   InputMapping_69;                                          // 0x0310(0x0050)
	TMap<struct FName, struct FName>                   OutputMapping_69;                                         // 0x0360(0x0050)
	unsigned char                                      UnknownData02[0xB0];                                      // 0x03B0(0x00B0) MISSED OFFSET
	int                                                LODThreshold_69;                                          // 0x0460(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData03[0xC];                                       // 0x0464(0x000C) MISSED OFFSET
};

// ScriptStruct ControlRig.AnimNode_ControlRig_ExternalSource
// 0x0008 (0x0278 - 0x0270)
struct FAnimNode_ControlRig_ExternalSource : public FAnimNode_ControlRigBase
{
	TWeakObjectPtr<class ControlRig>                   ControlRig_69;                                            // 0x0270(0x0008) (ZeroConstructor, Transient, IsPlainOldData)
};

// ScriptStruct ControlRig.ControlRigAnimInstanceProxy
// 0x00A0 (0x0920 - 0x0880)
struct FControlRigAnimInstanceProxy : public FAnimInstanceProxy
{
	unsigned char                                      UnknownData00[0xA0];                                      // 0x0880(0x00A0) MISSED OFFSET
};

// ScriptStruct ControlRig.ControlShapeActorCreationParam
// 0x01B0
struct FControlShapeActorCreationParam
{
	unsigned char                                      UnknownData00[0x1B0];                                     // 0x0000(0x01B0) MISSED OFFSET
};

// ScriptStruct ControlRig.ControlRigValidationContext
// 0x0028
struct FControlRigValidationContext
{
	unsigned char                                      UnknownData00[0x28];                                      // 0x0000(0x0028) MISSED OFFSET
};

// ScriptStruct ControlRig.ControlRigDrawInterface
// 0x0000 (0x0018 - 0x0018)
struct FControlRigDrawInterface : public FControlRigDrawContainer
{

};

// ScriptStruct ControlRig.CRFourPointBezier
// 0x0060
struct FCRFourPointBezier
{
	struct FVector                                     A_69;                                                     // 0x0000(0x0018) (Edit, ZeroConstructor, IsPlainOldData)
	struct FVector                                     B_69;                                                     // 0x0018(0x0018) (Edit, ZeroConstructor, IsPlainOldData)
	struct FVector                                     C_69;                                                     // 0x0030(0x0018) (Edit, ZeroConstructor, IsPlainOldData)
	struct FVector                                     D_69;                                                     // 0x0048(0x0018) (Edit, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct ControlRig.CRSimContainer
// 0x0018
struct FCRSimContainer
{
	unsigned char                                      UnknownData00[0x8];                                       // 0x0000(0x0008) MISSED OFFSET
	float                                              TimeStep_69;                                              // 0x0008(0x0004) (ZeroConstructor, IsPlainOldData)
	float                                              AccumulatedTime_69;                                       // 0x000C(0x0004) (ZeroConstructor, IsPlainOldData)
	float                                              TimeLeftForStep_69;                                       // 0x0010(0x0004) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x4];                                       // 0x0014(0x0004) MISSED OFFSET
};

// ScriptStruct ControlRig.CRSimLinearSpring
// 0x0010
struct FCRSimLinearSpring
{
	int                                                SubjectA_69;                                              // 0x0000(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	int                                                SubjectB_69;                                              // 0x0004(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	float                                              Coefficient_69;                                           // 0x0008(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	float                                              Equilibrium_69;                                           // 0x000C(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct ControlRig.CRSimPoint
// 0x0040
struct FCRSimPoint
{
	float                                              Mass_69;                                                  // 0x0000(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	float                                              Size_69;                                                  // 0x0004(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	float                                              LinearDamping_69;                                         // 0x0008(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	float                                              InheritMotion_69;                                         // 0x000C(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	struct FVector                                     Position_69;                                              // 0x0010(0x0018) (Edit, ZeroConstructor, IsPlainOldData)
	struct FVector                                     LinearVelocity_69;                                        // 0x0028(0x0018) (Edit, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct ControlRig.CRSimPointConstraint
// 0x0040
struct FCRSimPointConstraint
{
	ECRSimConstraintType                               Type_69;                                                  // 0x0000(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0001(0x0003) MISSED OFFSET
	int                                                SubjectA_69;                                              // 0x0004(0x0004) (ZeroConstructor, IsPlainOldData)
	int                                                SubjectB_69;                                              // 0x0008(0x0004) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x4];                                       // 0x000C(0x0004) MISSED OFFSET
	struct FVector                                     DataA_69;                                                 // 0x0010(0x0018) (ZeroConstructor, IsPlainOldData)
	struct FVector                                     DataB_69;                                                 // 0x0028(0x0018) (ZeroConstructor, IsPlainOldData)
};

// ScriptStruct ControlRig.CRSimPointForce
// 0x0028
struct FCRSimPointForce
{
	ECRSimPointForceType                               ForceType_69;                                             // 0x0000(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0001(0x0007) MISSED OFFSET
	struct FVector                                     Vector_69;                                                // 0x0008(0x0018) (Edit, ZeroConstructor, IsPlainOldData)
	float                                              Coefficient_69;                                           // 0x0020(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	bool                                               bNormalize_69;                                            // 0x0024(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x3];                                       // 0x0025(0x0003) MISSED OFFSET
};

// ScriptStruct ControlRig.CRSimSoftCollision
// 0x0080
struct FCRSimSoftCollision
{
	struct FCoreUObject_FTransform                     Transform_69;                                             // 0x0000(0x0060) (Edit, IsPlainOldData)
	ECRSimSoftCollisionType                            ShapeType_69;                                             // 0x0060(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0061(0x0003) MISSED OFFSET
	float                                              MinimumDistance_69;                                       // 0x0064(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	float                                              MaximumDistance_69;                                       // 0x0068(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	EControlRigAnimEasingType                          FalloffType_69;                                           // 0x006C(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x3];                                       // 0x006D(0x0003) MISSED OFFSET
	float                                              Coefficient_69;                                           // 0x0070(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	bool                                               bInverted_69;                                             // 0x0074(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData02[0xB];                                       // 0x0075(0x000B) MISSED OFFSET
};

// ScriptStruct ControlRig.CRSimPointContainer
// 0x0060 (0x0078 - 0x0018)
struct FCRSimPointContainer : public FCRSimContainer
{
	TArray<struct FCRSimPoint>                         Points_69;                                                // 0x0018(0x0010) (ZeroConstructor)
	TArray<struct FCRSimLinearSpring>                  Springs_69;                                               // 0x0028(0x0010) (ZeroConstructor)
	TArray<struct FCRSimPointForce>                    Forces_69;                                                // 0x0038(0x0010) (ZeroConstructor)
	TArray<struct FCRSimSoftCollision>                 CollisionVolumes_69;                                      // 0x0048(0x0010) (ZeroConstructor)
	TArray<struct FCRSimPointConstraint>               Constraints_69;                                           // 0x0058(0x0010) (ZeroConstructor)
	TArray<struct FCRSimPoint>                         PreviousStep_69;                                          // 0x0068(0x0010) (ZeroConstructor)
};

// ScriptStruct ControlRig.ConstraintNodeData
// 0x0140
struct FConstraintNodeData
{
	struct FCoreUObject_FTransform                     RelativeParent_69;                                        // 0x0000(0x0060) (IsPlainOldData)
	struct FConstraintOffset                           ConstraintOffset_69;                                      // 0x0060(0x00C0)
	struct FName                                       LinkedNode_69;                                            // 0x0120(0x0008) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0124(0x0004) MISSED OFFSET
	TArray<struct FTransformConstraint>                Constraints_69;                                           // 0x0128(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData01[0x8];                                       // 0x0138(0x0008) MISSED OFFSET
};

// ScriptStruct ControlRig.AnimationHierarchy
// 0x0010 (0x0088 - 0x0078)
struct FAnimationHierarchy : public FNodeHierarchyWithUserData
{
	TArray<struct FConstraintNodeData>                 UserData_69;                                              // 0x0078(0x0010) (ZeroConstructor)
};

// ScriptStruct ControlRig.RigElement
// 0x0010
struct FRigElement
{
	unsigned char                                      UnknownData00[0x8];                                       // 0x0000(0x0008) MISSED OFFSET
	struct FName                                       Name_69;                                                  // 0x0008(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                Index_69;                                                 // 0x000C(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, EditConst, IsPlainOldData)
};

// ScriptStruct ControlRig.RigBone
// 0x0150 (0x0160 - 0x0010)
struct FRigBone : public FRigElement
{
	struct FName                                       ParentName_69;                                            // 0x0010(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, EditConst, IsPlainOldData)
	int                                                ParentIndex_69;                                           // 0x0014(0x0004) (ZeroConstructor, Transient, IsPlainOldData)
	unsigned char                                      UnknownData00[0x8];                                       // 0x0018(0x0008) MISSED OFFSET
	struct FCoreUObject_FTransform                     InitialTransform_69;                                      // 0x0020(0x0060) (Edit, BlueprintVisible, BlueprintReadOnly, IsPlainOldData)
	struct FCoreUObject_FTransform                     GlobalTransform_69;                                       // 0x0080(0x0060) (Edit, BlueprintVisible, BlueprintReadOnly, Transient, IsPlainOldData)
	struct FCoreUObject_FTransform                     LocalTransform_69;                                        // 0x00E0(0x0060) (Edit, BlueprintVisible, BlueprintReadOnly, Transient, IsPlainOldData)
	TArray<int>                                        Dependents_69;                                            // 0x0140(0x0010) (ZeroConstructor, Transient)
	ERigBoneType                                       Type_69;                                                  // 0x0150(0x0001) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	unsigned char                                      UnknownData01[0xF];                                       // 0x0151(0x000F) MISSED OFFSET
};

// ScriptStruct ControlRig.RigBoneHierarchy
// 0x0010
struct FRigBoneHierarchy
{
	TArray<struct FRigBone>                            Bones_69;                                                 // 0x0000(0x0010) (Edit, ZeroConstructor)
};

// ScriptStruct ControlRig.RigControl
// 0x04F0 (0x0500 - 0x0010)
struct FRigControl : public FRigElement
{
	ERigControlType                                    ControlType_69;                                           // 0x0010(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0011(0x0003) MISSED OFFSET
	struct FName                                       DisplayName_69;                                           // 0x0014(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FName                                       ParentName_69;                                            // 0x0018(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, EditConst, IsPlainOldData)
	int                                                ParentIndex_69;                                           // 0x001C(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, Transient, IsPlainOldData)
	struct FName                                       SpaceName_69;                                             // 0x0020(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, EditConst, IsPlainOldData)
	int                                                SpaceIndex_69;                                            // 0x0024(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, Transient, IsPlainOldData)
	unsigned char                                      UnknownData01[0x8];                                       // 0x0028(0x0008) MISSED OFFSET
	struct FCoreUObject_FTransform                     OffsetTransform_69;                                       // 0x0030(0x0060) (Edit, BlueprintVisible, IsPlainOldData)
	struct FRigControlValue                            InitialValue_69;                                          // 0x0090(0x00F0) (Edit, BlueprintVisible, BlueprintReadOnly, EditConst)
	struct FRigControlValue                            Value_69;                                                 // 0x0180(0x00F0) (Edit, BlueprintVisible, BlueprintReadOnly, Transient, EditConst)
	ERigControlAxis                                    PrimaryAxis_69;                                           // 0x0270(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bIsCurve_69;                                              // 0x0271(0x0001) (ZeroConstructor, Transient, IsPlainOldData)
	bool                                               bAnimatable_69;                                           // 0x0272(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bLimitTranslation_69;                                     // 0x0273(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bLimitRotation_69;                                        // 0x0274(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bLimitScale_69;                                           // 0x0275(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bDrawLimits_69;                                           // 0x0276(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData02[0x9];                                       // 0x0277(0x0009) MISSED OFFSET
	struct FRigControlValue                            MinimumValue_69;                                          // 0x0280(0x00F0) (Edit, BlueprintVisible)
	struct FRigControlValue                            MaximumValue_69;                                          // 0x0370(0x00F0) (Edit, BlueprintVisible)
	bool                                               bGizmoEnabled_69;                                         // 0x0460(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bGizmoVisible_69;                                         // 0x0461(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData03[0x2];                                       // 0x0462(0x0002) MISSED OFFSET
	struct FName                                       GizmoName_69;                                             // 0x0464(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData04[0x8];                                       // 0x0468(0x0008) MISSED OFFSET
	struct FCoreUObject_FTransform                     GizmoTransform_69;                                        // 0x0470(0x0060) (Edit, BlueprintVisible, IsPlainOldData)
	struct FLinearColor                                GizmoColor_69;                                            // 0x04D0(0x0010) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	TArray<int>                                        Dependents_69;                                            // 0x04E0(0x0010) (ZeroConstructor, Transient)
	bool                                               bIsTransientControl_69;                                   // 0x04F0(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData05[0x7];                                       // 0x04F1(0x0007) MISSED OFFSET
	class Enum*                                        ControlEnum_69;                                           // 0x04F8(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
};

// ScriptStruct ControlRig.RigControlHierarchy
// 0x0010
struct FRigControlHierarchy
{
	TArray<struct FRigControl>                         Controls_69;                                              // 0x0000(0x0010) (Edit, ZeroConstructor)
};

// ScriptStruct ControlRig.RigCurve
// 0x0008 (0x0018 - 0x0010)
struct FRigCurve : public FRigElement
{
	float                                              Value_69;                                                 // 0x0010(0x0004) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0014(0x0004) MISSED OFFSET
};

// ScriptStruct ControlRig.RigCurveContainer
// 0x0010
struct FRigCurveContainer
{
	TArray<struct FRigCurve>                           Curves_69;                                                // 0x0000(0x0010) (Edit, ZeroConstructor)
};

// ScriptStruct ControlRig.RigSpace
// 0x00D0 (0x00E0 - 0x0010)
struct FRigSpace : public FRigElement
{
	ERigSpaceType                                      SpaceType_69;                                             // 0x0010(0x0001) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0011(0x0003) MISSED OFFSET
	struct FName                                       ParentName_69;                                            // 0x0014(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, EditConst, IsPlainOldData)
	int                                                ParentIndex_69;                                           // 0x0018(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, Transient, IsPlainOldData)
	unsigned char                                      UnknownData01[0x4];                                       // 0x001C(0x0004) MISSED OFFSET
	struct FCoreUObject_FTransform                     InitialTransform_69;                                      // 0x0020(0x0060) (Edit, BlueprintVisible, BlueprintReadOnly, IsPlainOldData)
	struct FCoreUObject_FTransform                     LocalTransform_69;                                        // 0x0080(0x0060) (Edit, BlueprintVisible, BlueprintReadOnly, Transient, IsPlainOldData)
};

// ScriptStruct ControlRig.RigSpaceHierarchy
// 0x0010
struct FRigSpaceHierarchy
{
	TArray<struct FRigSpace>                           Spaces_69;                                                // 0x0000(0x0010) (Edit, ZeroConstructor)
};

// ScriptStruct ControlRig.RigHierarchyContainer
// 0x0040
struct FRigHierarchyContainer
{
	struct FRigBoneHierarchy                           BoneHierarchy_69;                                         // 0x0000(0x0010)
	struct FRigSpaceHierarchy                          SpaceHierarchy_69;                                        // 0x0010(0x0010)
	struct FRigControlHierarchy                        ControlHierarchy_69;                                      // 0x0020(0x0010)
	struct FRigCurveContainer                          CurveContainer_69;                                        // 0x0030(0x0010)
};

// ScriptStruct ControlRig.RigHierarchyRef
// 0x0001
struct FRigHierarchyRef
{
	unsigned char                                      UnknownData00[0x1];                                       // 0x0000(0x0001) MISSED OFFSET
};

// ScriptStruct ControlRig.RigControlModifiedContext
// 0x0014
struct FRigControlModifiedContext
{
	unsigned char                                      UnknownData00[0x14];                                      // 0x0000(0x0014) MISSED OFFSET
};

// ScriptStruct ControlRig.RigElementKeyCollection
// 0x0010
struct FRigElementKeyCollection
{
	TArray<struct FRigElementKey>                      Keys_69;                                                  // 0x0000(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
};

// ScriptStruct ControlRig.RigEventContext
// 0x0020
struct FRigEventContext
{
	unsigned char                                      UnknownData00[0x20];                                      // 0x0000(0x0020) MISSED OFFSET
};

// ScriptStruct ControlRig.RigBaseMetadata
// 0x0020
struct FRigBaseMetadata
{
	unsigned char                                      UnknownData00[0x10];                                      // 0x0000(0x0010) MISSED OFFSET
	struct FName                                       Name_69;                                                  // 0x0010(0x0008) (ZeroConstructor, IsPlainOldData)
	ERigMetadataType                                   Type_69;                                                  // 0x0014(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0xB];                                       // 0x0015(0x000B) MISSED OFFSET
};

// ScriptStruct ControlRig.RigBoolMetadata
// 0x0008 (0x0028 - 0x0020)
struct FRigBoolMetadata : public FRigBaseMetadata
{
	bool                                               Value_69;                                                 // 0x0020(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0021(0x0007) MISSED OFFSET
};

// ScriptStruct ControlRig.RigBoolArrayMetadata
// 0x0010 (0x0030 - 0x0020)
struct FRigBoolArrayMetadata : public FRigBaseMetadata
{
	TArray<bool>                                       Value_69;                                                 // 0x0020(0x0010) (ZeroConstructor)
};

// ScriptStruct ControlRig.RigFloatMetadata
// 0x0008 (0x0028 - 0x0020)
struct FRigFloatMetadata : public FRigBaseMetadata
{
	float                                              Value_69;                                                 // 0x0020(0x0004) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0024(0x0004) MISSED OFFSET
};

// ScriptStruct ControlRig.RigFloatArrayMetadata
// 0x0010 (0x0030 - 0x0020)
struct FRigFloatArrayMetadata : public FRigBaseMetadata
{
	TArray<float>                                      Value_69;                                                 // 0x0020(0x0010) (ZeroConstructor)
};

// ScriptStruct ControlRig.RigInt32Metadata
// 0x0008 (0x0028 - 0x0020)
struct FRigInt32Metadata : public FRigBaseMetadata
{
	int                                                Value_69;                                                 // 0x0020(0x0004) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0024(0x0004) MISSED OFFSET
};

// ScriptStruct ControlRig.RigInt32ArrayMetadata
// 0x0010 (0x0030 - 0x0020)
struct FRigInt32ArrayMetadata : public FRigBaseMetadata
{
	TArray<int>                                        Value_69;                                                 // 0x0020(0x0010) (ZeroConstructor)
};

// ScriptStruct ControlRig.RigNameMetadata
// 0x0008 (0x0028 - 0x0020)
struct FRigNameMetadata : public FRigBaseMetadata
{
	struct FName                                       Value_69;                                                 // 0x0020(0x0008) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0024(0x0004) MISSED OFFSET
};

// ScriptStruct ControlRig.RigNameArrayMetadata
// 0x0010 (0x0030 - 0x0020)
struct FRigNameArrayMetadata : public FRigBaseMetadata
{
	TArray<struct FName>                               Value_69;                                                 // 0x0020(0x0010) (ZeroConstructor)
};

// ScriptStruct ControlRig.RigVectorMetadata
// 0x0018 (0x0038 - 0x0020)
struct FRigVectorMetadata : public FRigBaseMetadata
{
	struct FVector                                     Value_69;                                                 // 0x0020(0x0018) (ZeroConstructor, IsPlainOldData)
};

// ScriptStruct ControlRig.RigVectorArrayMetadata
// 0x0010 (0x0030 - 0x0020)
struct FRigVectorArrayMetadata : public FRigBaseMetadata
{
	TArray<struct FVector>                             Value_69;                                                 // 0x0020(0x0010) (ZeroConstructor)
};

// ScriptStruct ControlRig.RigRotatorMetadata
// 0x0018 (0x0038 - 0x0020)
struct FRigRotatorMetadata : public FRigBaseMetadata
{
	struct FRotator                                    Value_69;                                                 // 0x0020(0x0018) (ZeroConstructor, IsPlainOldData)
};

// ScriptStruct ControlRig.RigRotatorArrayMetadata
// 0x0010 (0x0030 - 0x0020)
struct FRigRotatorArrayMetadata : public FRigBaseMetadata
{
	TArray<struct FRotator>                            Value_69;                                                 // 0x0020(0x0010) (ZeroConstructor)
};

// ScriptStruct ControlRig.RigQuatMetadata
// 0x0020 (0x0040 - 0x0020)
struct FRigQuatMetadata : public FRigBaseMetadata
{
	struct FQuat                                       Value_69;                                                 // 0x0020(0x0020) (IsPlainOldData)
};

// ScriptStruct ControlRig.RigQuatArrayMetadata
// 0x0010 (0x0030 - 0x0020)
struct FRigQuatArrayMetadata : public FRigBaseMetadata
{
	TArray<struct FQuat>                               Value_69;                                                 // 0x0020(0x0010) (ZeroConstructor)
};

// ScriptStruct ControlRig.RigTransformMetadata
// 0x0060 (0x0080 - 0x0020)
struct FRigTransformMetadata : public FRigBaseMetadata
{
	struct FCoreUObject_FTransform                     Value_69;                                                 // 0x0020(0x0060) (IsPlainOldData)
};

// ScriptStruct ControlRig.RigTransformArrayMetadata
// 0x0010 (0x0030 - 0x0020)
struct FRigTransformArrayMetadata : public FRigBaseMetadata
{
	TArray<struct FCoreUObject_FTransform>             Value_69;                                                 // 0x0020(0x0010) (ZeroConstructor)
};

// ScriptStruct ControlRig.RigLinearColorMetadata
// 0x0010 (0x0030 - 0x0020)
struct FRigLinearColorMetadata : public FRigBaseMetadata
{
	struct FLinearColor                                Value_69;                                                 // 0x0020(0x0010) (ZeroConstructor, IsPlainOldData)
};

// ScriptStruct ControlRig.RigLinearColorArrayMetadata
// 0x0010 (0x0030 - 0x0020)
struct FRigLinearColorArrayMetadata : public FRigBaseMetadata
{
	TArray<struct FLinearColor>                        Value_69;                                                 // 0x0020(0x0010) (ZeroConstructor)
};

// ScriptStruct ControlRig.RigElementKeyMetadata
// 0x0008 (0x0028 - 0x0020)
struct FRigElementKeyMetadata : public FRigBaseMetadata
{
	struct FRigElementKey                              Value_69;                                                 // 0x0020(0x0008)
};

// ScriptStruct ControlRig.RigElementKeyArrayMetadata
// 0x0010 (0x0030 - 0x0020)
struct FRigElementKeyArrayMetadata : public FRigBaseMetadata
{
	TArray<struct FRigElementKey>                      Value_69;                                                 // 0x0020(0x0010) (ZeroConstructor)
};

// ScriptStruct ControlRig.RigInfluenceEntryModifier
// 0x0010
struct FRigInfluenceEntryModifier
{
	TArray<struct FRigElementKey>                      AffectedList_69;                                          // 0x0000(0x0010) (Edit, ZeroConstructor)
};

// ScriptStruct ControlRig.AnimNode_ControlRigInputPose
// 0x0020 (0x0030 - 0x0010)
struct FAnimNode_ControlRigInputPose : public FAnimNode_Base
{
	struct FPoseLink                                   InputPose_69;                                             // 0x0010(0x0010)
	unsigned char                                      UnknownData00[0x10];                                      // 0x0020(0x0010) MISSED OFFSET
};

// ScriptStruct ControlRig.ControlRigLayerInstanceProxy
// 0x00A0 (0x0920 - 0x0880)
struct FControlRigLayerInstanceProxy : public FAnimInstanceProxy
{
	unsigned char                                      UnknownData00[0xA0];                                      // 0x0880(0x00A0) MISSED OFFSET
};

// ScriptStruct ControlRig.ControlRigSequenceObjectReference
// 0x0008
struct FControlRigSequenceObjectReference
{
	class ControlRig*                                  ControlRigClass_69;                                       // 0x0000(0x0008) (ZeroConstructor)
};

// ScriptStruct ControlRig.ControlRigSequenceObjectReferences
// 0x0010
struct FControlRigSequenceObjectReferences
{
	TArray<struct FControlRigSequenceObjectReference>  Array_69;                                                 // 0x0000(0x0010) (ZeroConstructor)
};

// ScriptStruct ControlRig.ControlRigSequenceObjectReferenceMap
// 0x0020
struct FControlRigSequenceObjectReferenceMap
{
	TArray<struct FGuid>                               BindingIds_69;                                            // 0x0000(0x0010) (ZeroConstructor)
	TArray<struct FControlRigSequenceObjectReferences> References_69;                                            // 0x0010(0x0010) (ZeroConstructor)
};

// ScriptStruct ControlRig.MovieSceneControlRigParameterTemplate
// 0x0040 (0x00C0 - 0x0080)
struct FMovieSceneControlRigParameterTemplate : public FMovieSceneParameterSectionTemplate
{
	TArray<struct FEnumParameterNameAndCurve>          Enums_69;                                                 // 0x0080(0x0010) (ZeroConstructor)
	TArray<struct FIntegerParameterNameAndCurve>       Integers_69;                                              // 0x0090(0x0010) (ZeroConstructor)
	TArray<struct FSpaceControlNameAndChannel>         Spaces_69;                                                // 0x00A0(0x0010) (ZeroConstructor)
	TArray<struct FConstraintAndActiveChannel>         Constraints_69;                                           // 0x00B0(0x0010) (ZeroConstructor)
};

// ScriptStruct ControlRig.ControlRigSettingsPerPinBool
// 0x0050
struct FControlRigSettingsPerPinBool
{
	TMap<struct FString, bool>                         Values_69;                                                // 0x0000(0x0050) (Edit)
};

// ScriptStruct ControlRig.RigDispatchFactory
// 0x0000 (0x0018 - 0x0018)
struct FRigDispatchFactory : public FRigVMDispatchFactory
{

};

// ScriptStruct ControlRig.RigDispatch_AnimAttributeBase
// 0x0038 (0x0050 - 0x0018)
struct FRigDispatch_AnimAttributeBase : public FRigDispatchFactory
{
	unsigned char                                      UnknownData00[0x38];                                      // 0x0018(0x0038) MISSED OFFSET
};

// ScriptStruct ControlRig.RigDispatch_GetAnimAttribute
// 0x0000 (0x0050 - 0x0050)
struct FRigDispatch_GetAnimAttribute : public FRigDispatch_AnimAttributeBase
{

};

// ScriptStruct ControlRig.RigDispatch_SetAnimAttribute
// 0x0000 (0x0050 - 0x0050)
struct FRigDispatch_SetAnimAttribute : public FRigDispatch_AnimAttributeBase
{

};

// ScriptStruct ControlRig.RigUnit_AnimEasingType
// 0x0008 (0x0010 - 0x0008)
struct FRigUnit_AnimEasingType : public FRigUnit_AnimBase
{
	EControlRigAnimEasingType                          Type_69;                                                  // 0x0008(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0009(0x0007) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_AnimEasing
// 0x0020 (0x0028 - 0x0008)
struct FRigUnit_AnimEasing : public FRigUnit_AnimBase
{
	float                                              Value_69;                                                 // 0x0008(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	EControlRigAnimEasingType                          Type_69;                                                  // 0x000C(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x000D(0x0003) MISSED OFFSET
	float                                              SourceMinimum_69;                                         // 0x0010(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              SourceMaximum_69;                                         // 0x0014(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              TargetMinimum_69;                                         // 0x0018(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              TargetMaximum_69;                                         // 0x001C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              Result_69;                                                // 0x0020(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x4];                                       // 0x0024(0x0004) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_AnimEvalRichCurve
// 0x00A8 (0x00B0 - 0x0008)
struct FRigUnit_AnimEvalRichCurve : public FRigUnit_AnimBase
{
	float                                              Value_69;                                                 // 0x0008(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x000C(0x0004) MISSED OFFSET
	struct FRuntimeFloatCurve                          Curve_69;                                                 // 0x0010(0x0088) (Edit, BlueprintVisible, EditConst)
	float                                              SourceMinimum_69;                                         // 0x0098(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              SourceMaximum_69;                                         // 0x009C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              TargetMinimum_69;                                         // 0x00A0(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              TargetMaximum_69;                                         // 0x00A4(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              Result_69;                                                // 0x00A8(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x4];                                       // 0x00AC(0x0004) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_AnimRichCurve
// 0x0088 (0x0090 - 0x0008)
struct FRigUnit_AnimRichCurve : public FRigUnit_AnimBase
{
	struct FRuntimeFloatCurve                          Curve_69;                                                 // 0x0008(0x0088) (Edit, BlueprintVisible, EditConst)
};

// ScriptStruct ControlRig.RigUnit_GetDeltaTime
// 0x0008 (0x0010 - 0x0008)
struct FRigUnit_GetDeltaTime : public FRigUnit_AnimBase
{
	float                                              Result_69;                                                // 0x0008(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x000C(0x0004) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_GetWorldTime
// 0x0020 (0x0028 - 0x0008)
struct FRigUnit_GetWorldTime : public FRigUnit_AnimBase
{
	float                                              Year_69;                                                  // 0x0008(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              Month_69;                                                 // 0x000C(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              Day_69;                                                   // 0x0010(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              WeekDay_69;                                               // 0x0014(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              Hours_69;                                                 // 0x0018(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              Minutes_69;                                               // 0x001C(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              Seconds_69;                                               // 0x0020(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              OverallSeconds_69;                                        // 0x0024(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_FramesToSeconds
// 0x0008 (0x0010 - 0x0008)
struct FRigUnit_FramesToSeconds : public FRigUnit_AnimBase
{
	float                                              Frames_69;                                                // 0x0008(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              Seconds_69;                                               // 0x000C(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_SecondsToFrames
// 0x0008 (0x0010 - 0x0008)
struct FRigUnit_SecondsToFrames : public FRigUnit_AnimBase
{
	float                                              Seconds_69;                                               // 0x0008(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              Frames_69;                                                // 0x000C(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_SphereTraceWorld
// 0x0070 (0x0078 - 0x0008)
struct FRigUnit_SphereTraceWorld : public FRigUnit
{
	struct FVector                                     Start_69;                                                 // 0x0008(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FVector                                     End_69;                                                   // 0x0020(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<ECollisionChannel>                     Channel_69;                                               // 0x0038(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0039(0x0003) MISSED OFFSET
	float                                              Radius_69;                                                // 0x003C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bHit_69;                                                  // 0x0040(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x7];                                       // 0x0041(0x0007) MISSED OFFSET
	struct FVector                                     HitLocation_69;                                           // 0x0048(0x0018) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	struct FVector                                     HitNormal_69;                                             // 0x0060(0x0018) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_SphereTraceByTraceChannel
// 0x0070 (0x0078 - 0x0008)
struct FRigUnit_SphereTraceByTraceChannel : public FRigUnit
{
	struct FVector                                     Start_69;                                                 // 0x0008(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FVector                                     End_69;                                                   // 0x0020(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<ETraceTypeQuery>                       TraceChannel_69;                                          // 0x0038(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0039(0x0003) MISSED OFFSET
	float                                              Radius_69;                                                // 0x003C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bHit_69;                                                  // 0x0040(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x7];                                       // 0x0041(0x0007) MISSED OFFSET
	struct FVector                                     HitLocation_69;                                           // 0x0048(0x0018) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	struct FVector                                     HitNormal_69;                                             // 0x0060(0x0018) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_SphereTraceByObjectTypes
// 0x0078 (0x0080 - 0x0008)
struct FRigUnit_SphereTraceByObjectTypes : public FRigUnit
{
	struct FVector                                     Start_69;                                                 // 0x0008(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FVector                                     End_69;                                                   // 0x0020(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	TArray<TEnumAsByte<EObjectTypeQuery>>              ObjectTypes_69;                                           // 0x0038(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	float                                              Radius_69;                                                // 0x0048(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bHit_69;                                                  // 0x004C(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x004D(0x0003) MISSED OFFSET
	struct FVector                                     HitLocation_69;                                           // 0x0050(0x0018) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	struct FVector                                     HitNormal_69;                                             // 0x0068(0x0018) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_Control
// 0x0178 (0x0180 - 0x0008)
struct FRigUnit_Control : public FRigUnit
{
	struct FEulerTransform                             Transform_69;                                             // 0x0008(0x0048) (Edit, BlueprintVisible)
	struct FCoreUObject_FTransform                     Base_69;                                                  // 0x0050(0x0060) (Edit, BlueprintVisible, IsPlainOldData)
	struct FCoreUObject_FTransform                     InitTransform_69;                                         // 0x00B0(0x0060) (Edit, BlueprintVisible, IsPlainOldData)
	struct FCoreUObject_FTransform                     Result_69;                                                // 0x0110(0x0060) (BlueprintVisible, BlueprintReadOnly, IsPlainOldData)
	struct FTransformFilter                            Filter_69;                                                // 0x0170(0x0009) (Edit, BlueprintVisible)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0179(0x0007) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_Control_StaticMesh
// 0x0060 (0x01E0 - 0x0180)
struct FRigUnit_Control_StaticMesh : public FRigUnit_Control
{
	struct FCoreUObject_FTransform                     MeshTransform_69;                                         // 0x0180(0x0060) (Edit, BlueprintVisible, IsPlainOldData)
};

// ScriptStruct ControlRig.RigDispatch_CoreBase
// 0x0000 (0x0018 - 0x0018)
struct FRigDispatch_CoreBase : public FRigDispatchFactory
{

};

// ScriptStruct ControlRig.RigDispatch_CoreEquals
// 0x0000 (0x0018 - 0x0018)
struct FRigDispatch_CoreEquals : public FRigDispatch_CoreBase
{

};

// ScriptStruct ControlRig.RigDispatch_CoreNotEquals
// 0x0000 (0x0018 - 0x0018)
struct FRigDispatch_CoreNotEquals : public FRigDispatch_CoreEquals
{

};

// ScriptStruct ControlRig.RigUnit_NameBase
// 0x0000 (0x0008 - 0x0008)
struct FRigUnit_NameBase : public FRigUnit
{

};

// ScriptStruct ControlRig.RigUnit_NameConcat
// 0x0010 (0x0018 - 0x0008)
struct FRigUnit_NameConcat : public FRigUnit_NameBase
{
	struct FName                                       A_69;                                                     // 0x0008(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FName                                       B_69;                                                     // 0x000C(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FName                                       Result_69;                                                // 0x0010(0x0008) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0014(0x0004) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_NameTruncate
// 0x0018 (0x0020 - 0x0008)
struct FRigUnit_NameTruncate : public FRigUnit_NameBase
{
	struct FName                                       Name_69;                                                  // 0x0008(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                Count_69;                                                 // 0x000C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               FromEnd_69;                                               // 0x0010(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0011(0x0003) MISSED OFFSET
	struct FName                                       Remainder_69;                                             // 0x0014(0x0008) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	struct FName                                       Chopped_69;                                               // 0x0018(0x0008) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x4];                                       // 0x001C(0x0004) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_NameReplace
// 0x0010 (0x0018 - 0x0008)
struct FRigUnit_NameReplace : public FRigUnit_NameBase
{
	struct FName                                       Name_69;                                                  // 0x0008(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FName                                       Old_69;                                                   // 0x000C(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FName                                       New_69;                                                   // 0x0010(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FName                                       Result_69;                                                // 0x0014(0x0008) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_EndsWith
// 0x0010 (0x0018 - 0x0008)
struct FRigUnit_EndsWith : public FRigUnit_NameBase
{
	struct FName                                       Name_69;                                                  // 0x0008(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FName                                       Ending_69;                                                // 0x000C(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               Result_69;                                                // 0x0010(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0011(0x0007) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_StartsWith
// 0x0010 (0x0018 - 0x0008)
struct FRigUnit_StartsWith : public FRigUnit_NameBase
{
	struct FName                                       Name_69;                                                  // 0x0008(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FName                                       Start_69;                                                 // 0x000C(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               Result_69;                                                // 0x0010(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0011(0x0007) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_Contains
// 0x0010 (0x0018 - 0x0008)
struct FRigUnit_Contains : public FRigUnit_NameBase
{
	struct FName                                       Name_69;                                                  // 0x0008(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FName                                       Search_69;                                                // 0x000C(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               Result_69;                                                // 0x0010(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0011(0x0007) MISSED OFFSET
};

// ScriptStruct ControlRig.RigDispatch_Print
// 0x0000 (0x0018 - 0x0018)
struct FRigDispatch_Print : public FRigDispatchFactory
{

};

// ScriptStruct ControlRig.RigUnit_StringBase
// 0x0000 (0x0008 - 0x0008)
struct FRigUnit_StringBase : public FRigUnit
{

};

// ScriptStruct ControlRig.RigUnit_StringConcat
// 0x0030 (0x0038 - 0x0008)
struct FRigUnit_StringConcat : public FRigUnit_StringBase
{
	struct FString                                     A_69;                                                     // 0x0008(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     B_69;                                                     // 0x0018(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     Result_69;                                                // 0x0028(0x0010) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
};

// ScriptStruct ControlRig.RigUnit_StringTruncate
// 0x0038 (0x0040 - 0x0008)
struct FRigUnit_StringTruncate : public FRigUnit_StringBase
{
	struct FString                                     Name_69;                                                  // 0x0008(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	int                                                Count_69;                                                 // 0x0018(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               FromEnd_69;                                               // 0x001C(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x001D(0x0003) MISSED OFFSET
	struct FString                                     Remainder_69;                                             // 0x0020(0x0010) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
	struct FString                                     Chopped_69;                                               // 0x0030(0x0010) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
};

// ScriptStruct ControlRig.RigUnit_StringReplace
// 0x0040 (0x0048 - 0x0008)
struct FRigUnit_StringReplace : public FRigUnit_StringBase
{
	struct FString                                     Name_69;                                                  // 0x0008(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     Old_69;                                                   // 0x0018(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     New_69;                                                   // 0x0028(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     Result_69;                                                // 0x0038(0x0010) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
};

// ScriptStruct ControlRig.RigUnit_StringEndsWith
// 0x0028 (0x0030 - 0x0008)
struct FRigUnit_StringEndsWith : public FRigUnit_StringBase
{
	struct FString                                     Name_69;                                                  // 0x0008(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     Ending_69;                                                // 0x0018(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	bool                                               Result_69;                                                // 0x0028(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0029(0x0007) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_StringStartsWith
// 0x0028 (0x0030 - 0x0008)
struct FRigUnit_StringStartsWith : public FRigUnit_StringBase
{
	struct FString                                     Name_69;                                                  // 0x0008(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     Start_69;                                                 // 0x0018(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	bool                                               Result_69;                                                // 0x0028(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0029(0x0007) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_StringContains
// 0x0028 (0x0030 - 0x0008)
struct FRigUnit_StringContains : public FRigUnit_StringBase
{
	struct FString                                     Name_69;                                                  // 0x0008(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     Search_69;                                                // 0x0018(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	bool                                               Result_69;                                                // 0x0028(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0029(0x0007) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_StringLength
// 0x0018 (0x0020 - 0x0008)
struct FRigUnit_StringLength : public FRigUnit_StringBase
{
	struct FString                                     Value_69;                                                 // 0x0008(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	int                                                Length_69;                                                // 0x0018(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x001C(0x0004) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_StringTrimWhitespace
// 0x0020 (0x0028 - 0x0008)
struct FRigUnit_StringTrimWhitespace : public FRigUnit_StringBase
{
	struct FString                                     Value_69;                                                 // 0x0008(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     Result_69;                                                // 0x0018(0x0010) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
};

// ScriptStruct ControlRig.RigUnit_StringToUppercase
// 0x0020 (0x0028 - 0x0008)
struct FRigUnit_StringToUppercase : public FRigUnit_StringBase
{
	struct FString                                     Value_69;                                                 // 0x0008(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     Result_69;                                                // 0x0018(0x0010) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
};

// ScriptStruct ControlRig.RigUnit_StringToLowercase
// 0x0020 (0x0028 - 0x0008)
struct FRigUnit_StringToLowercase : public FRigUnit_StringBase
{
	struct FString                                     Value_69;                                                 // 0x0008(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     Result_69;                                                // 0x0018(0x0010) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
};

// ScriptStruct ControlRig.RigUnit_StringReverse
// 0x0020 (0x0028 - 0x0008)
struct FRigUnit_StringReverse : public FRigUnit_StringBase
{
	struct FString                                     Value_69;                                                 // 0x0008(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     Reverse_69;                                               // 0x0018(0x0010) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
};

// ScriptStruct ControlRig.RigUnit_StringLeft
// 0x0028 (0x0030 - 0x0008)
struct FRigUnit_StringLeft : public FRigUnit_StringBase
{
	struct FString                                     Value_69;                                                 // 0x0008(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	int                                                Count_69;                                                 // 0x0018(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x001C(0x0004) MISSED OFFSET
	struct FString                                     Result_69;                                                // 0x0020(0x0010) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
};

// ScriptStruct ControlRig.RigUnit_StringRight
// 0x0028 (0x0030 - 0x0008)
struct FRigUnit_StringRight : public FRigUnit_StringBase
{
	struct FString                                     Value_69;                                                 // 0x0008(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	int                                                Count_69;                                                 // 0x0018(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x001C(0x0004) MISSED OFFSET
	struct FString                                     Result_69;                                                // 0x0020(0x0010) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
};

// ScriptStruct ControlRig.RigUnit_StringMiddle
// 0x0028 (0x0030 - 0x0008)
struct FRigUnit_StringMiddle : public FRigUnit_StringBase
{
	struct FString                                     Value_69;                                                 // 0x0008(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	int                                                Start_69;                                                 // 0x0018(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                Count_69;                                                 // 0x001C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FString                                     Result_69;                                                // 0x0020(0x0010) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
};

// ScriptStruct ControlRig.RigUnit_StringFind
// 0x0028 (0x0030 - 0x0008)
struct FRigUnit_StringFind : public FRigUnit_StringBase
{
	struct FString                                     Value_69;                                                 // 0x0008(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     Search_69;                                                // 0x0018(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	bool                                               Found_69;                                                 // 0x0028(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0029(0x0003) MISSED OFFSET
	int                                                Index_69;                                                 // 0x002C(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_StringSplit
// 0x0030 (0x0038 - 0x0008)
struct FRigUnit_StringSplit : public FRigUnit_StringBase
{
	struct FString                                     Value_69;                                                 // 0x0008(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     Separator_69;                                             // 0x0018(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	TArray<struct FString>                             Result_69;                                                // 0x0028(0x0010) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
};

// ScriptStruct ControlRig.RigUnit_StringJoin
// 0x0030 (0x0038 - 0x0008)
struct FRigUnit_StringJoin : public FRigUnit_StringBase
{
	TArray<struct FString>                             Values_69;                                                // 0x0008(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     Separator_69;                                             // 0x0018(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     Result_69;                                                // 0x0028(0x0010) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
};

// ScriptStruct ControlRig.RigUnit_StringPadInteger
// 0x0018 (0x0020 - 0x0008)
struct FRigUnit_StringPadInteger : public FRigUnit_StringBase
{
	int                                                Value_69;                                                 // 0x0008(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                Digits_69;                                                // 0x000C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FString                                     Result_69;                                                // 0x0010(0x0010) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
};

// ScriptStruct ControlRig.RigDispatch_ToString
// 0x0000 (0x0018 - 0x0018)
struct FRigDispatch_ToString : public FRigDispatchFactory
{

};

// ScriptStruct ControlRig.RigDispatch_FromString
// 0x0000 (0x0018 - 0x0018)
struct FRigDispatch_FromString : public FRigDispatchFactory
{

};

// ScriptStruct ControlRig.RigUnit_DebugBezier
// 0x00F8 (0x0130 - 0x0038)
struct FRigUnit_DebugBezier : public FRigUnit_DebugBaseMutable
{
	struct FCRFourPointBezier                          Bezier_69;                                                // 0x0038(0x0060) (Edit, BlueprintVisible)
	float                                              MinimumU_69;                                              // 0x0098(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              MaximumU_69;                                              // 0x009C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FLinearColor                                Color_69;                                                 // 0x00A0(0x0010) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              Thickness_69;                                             // 0x00B0(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                Detail_69;                                                // 0x00B4(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FName                                       Space_69;                                                 // 0x00B8(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x00BC(0x0004) MISSED OFFSET
	struct FCoreUObject_FTransform                     WorldOffset_69;                                           // 0x00C0(0x0060) (Edit, BlueprintVisible, IsPlainOldData)
	bool                                               bEnabled_69;                                              // 0x0120(0x0001) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	unsigned char                                      UnknownData01[0xF];                                       // 0x0121(0x000F) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_DebugBezierItemSpace
// 0x00F8 (0x0130 - 0x0038)
struct FRigUnit_DebugBezierItemSpace : public FRigUnit_DebugBaseMutable
{
	struct FCRFourPointBezier                          Bezier_69;                                                // 0x0038(0x0060) (Edit, BlueprintVisible)
	float                                              MinimumU_69;                                              // 0x0098(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              MaximumU_69;                                              // 0x009C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FLinearColor                                Color_69;                                                 // 0x00A0(0x0010) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              Thickness_69;                                             // 0x00B0(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                Detail_69;                                                // 0x00B4(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FRigElementKey                              Space_69;                                                 // 0x00B8(0x0008) (Edit, BlueprintVisible)
	struct FCoreUObject_FTransform                     WorldOffset_69;                                           // 0x00C0(0x0060) (Edit, BlueprintVisible, IsPlainOldData)
	bool                                               bEnabled_69;                                              // 0x0120(0x0001) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	unsigned char                                      UnknownData00[0xF];                                       // 0x0121(0x000F) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_DebugHierarchy
// 0x0088 (0x00C0 - 0x0038)
struct FRigUnit_DebugHierarchy : public FRigUnit_DebugBaseMutable
{
	float                                              Scale_69;                                                 // 0x0038(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FLinearColor                                Color_69;                                                 // 0x003C(0x0010) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              Thickness_69;                                             // 0x004C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FCoreUObject_FTransform                     WorldOffset_69;                                           // 0x0050(0x0060) (Edit, BlueprintVisible, IsPlainOldData)
	bool                                               bEnabled_69;                                              // 0x00B0(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0xF];                                       // 0x00B1(0x000F) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_DebugPose
// 0x00F8 (0x0130 - 0x0038)
struct FRigUnit_DebugPose : public FRigUnit_DebugBaseMutable
{
	struct FRigPose                                    Pose_69;                                                  // 0x0038(0x0070) (Edit, BlueprintVisible)
	float                                              Scale_69;                                                 // 0x00A8(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FLinearColor                                Color_69;                                                 // 0x00AC(0x0010) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              Thickness_69;                                             // 0x00BC(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FCoreUObject_FTransform                     WorldOffset_69;                                           // 0x00C0(0x0060) (Edit, BlueprintVisible, IsPlainOldData)
	bool                                               bEnabled_69;                                              // 0x0120(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0xF];                                       // 0x0121(0x000F) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_DebugLine
// 0x00B8 (0x00F0 - 0x0038)
struct FRigUnit_DebugLine : public FRigUnit_DebugBaseMutable
{
	struct FVector                                     A_69;                                                     // 0x0038(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FVector                                     B_69;                                                     // 0x0050(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FLinearColor                                Color_69;                                                 // 0x0068(0x0010) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              Thickness_69;                                             // 0x0078(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FName                                       Space_69;                                                 // 0x007C(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FCoreUObject_FTransform                     WorldOffset_69;                                           // 0x0080(0x0060) (Edit, BlueprintVisible, IsPlainOldData)
	bool                                               bEnabled_69;                                              // 0x00E0(0x0001) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	unsigned char                                      UnknownData00[0xF];                                       // 0x00E1(0x000F) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_DebugLineItemSpace
// 0x00C8 (0x0100 - 0x0038)
struct FRigUnit_DebugLineItemSpace : public FRigUnit_DebugBaseMutable
{
	struct FVector                                     A_69;                                                     // 0x0038(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FVector                                     B_69;                                                     // 0x0050(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FLinearColor                                Color_69;                                                 // 0x0068(0x0010) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              Thickness_69;                                             // 0x0078(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FRigElementKey                              Space_69;                                                 // 0x007C(0x0008) (Edit, BlueprintVisible)
	unsigned char                                      UnknownData00[0xC];                                       // 0x0084(0x000C) MISSED OFFSET
	struct FCoreUObject_FTransform                     WorldOffset_69;                                           // 0x0090(0x0060) (Edit, BlueprintVisible, IsPlainOldData)
	bool                                               bEnabled_69;                                              // 0x00F0(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0xF];                                       // 0x00F1(0x000F) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_DebugLineStrip
// 0x0098 (0x00D0 - 0x0038)
struct FRigUnit_DebugLineStrip : public FRigUnit_DebugBaseMutable
{
	TArray<struct FVector>                             Points_69;                                                // 0x0038(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FLinearColor                                Color_69;                                                 // 0x0048(0x0010) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              Thickness_69;                                             // 0x0058(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FName                                       Space_69;                                                 // 0x005C(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FCoreUObject_FTransform                     WorldOffset_69;                                           // 0x0060(0x0060) (Edit, BlueprintVisible, IsPlainOldData)
	bool                                               bEnabled_69;                                              // 0x00C0(0x0001) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	unsigned char                                      UnknownData00[0xF];                                       // 0x00C1(0x000F) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_DebugLineStripItemSpace
// 0x00A8 (0x00E0 - 0x0038)
struct FRigUnit_DebugLineStripItemSpace : public FRigUnit_DebugBaseMutable
{
	TArray<struct FVector>                             Points_69;                                                // 0x0038(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FLinearColor                                Color_69;                                                 // 0x0048(0x0010) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              Thickness_69;                                             // 0x0058(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FRigElementKey                              Space_69;                                                 // 0x005C(0x0008) (Edit, BlueprintVisible)
	unsigned char                                      UnknownData00[0xC];                                       // 0x0064(0x000C) MISSED OFFSET
	struct FCoreUObject_FTransform                     WorldOffset_69;                                           // 0x0070(0x0060) (Edit, BlueprintVisible, IsPlainOldData)
	bool                                               bEnabled_69;                                              // 0x00D0(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0xF];                                       // 0x00D1(0x000F) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_DebugPoint
// 0x00A8 (0x00B0 - 0x0008)
struct FRigUnit_DebugPoint : public FRigUnit_DebugBase
{
	struct FVector                                     Vector_69;                                                // 0x0008(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	ERigUnitDebugPointMode                             Mode_69;                                                  // 0x0020(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0021(0x0003) MISSED OFFSET
	struct FLinearColor                                Color_69;                                                 // 0x0024(0x0010) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              Scale_69;                                                 // 0x0034(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              Thickness_69;                                             // 0x0038(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FName                                       Space_69;                                                 // 0x003C(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FCoreUObject_FTransform                     WorldOffset_69;                                           // 0x0040(0x0060) (Edit, BlueprintVisible, IsPlainOldData)
	bool                                               bEnabled_69;                                              // 0x00A0(0x0001) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	unsigned char                                      UnknownData01[0xF];                                       // 0x00A1(0x000F) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_DebugPointMutable
// 0x00A8 (0x00E0 - 0x0038)
struct FRigUnit_DebugPointMutable : public FRigUnit_DebugBaseMutable
{
	struct FVector                                     Vector_69;                                                // 0x0038(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	ERigUnitDebugPointMode                             Mode_69;                                                  // 0x0050(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0051(0x0003) MISSED OFFSET
	struct FLinearColor                                Color_69;                                                 // 0x0054(0x0010) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              Scale_69;                                                 // 0x0064(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              Thickness_69;                                             // 0x0068(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FName                                       Space_69;                                                 // 0x006C(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FCoreUObject_FTransform                     WorldOffset_69;                                           // 0x0070(0x0060) (Edit, BlueprintVisible, IsPlainOldData)
	bool                                               bEnabled_69;                                              // 0x00D0(0x0001) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	unsigned char                                      UnknownData01[0xF];                                       // 0x00D1(0x000F) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_DebugRectangle
// 0x00F8 (0x0130 - 0x0038)
struct FRigUnit_DebugRectangle : public FRigUnit_DebugBaseMutable
{
	unsigned char                                      UnknownData00[0x8];                                       // 0x0038(0x0008) MISSED OFFSET
	struct FCoreUObject_FTransform                     Transform_69;                                             // 0x0040(0x0060) (Edit, BlueprintVisible, IsPlainOldData)
	struct FLinearColor                                Color_69;                                                 // 0x00A0(0x0010) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              Scale_69;                                                 // 0x00B0(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              Thickness_69;                                             // 0x00B4(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FName                                       Space_69;                                                 // 0x00B8(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x4];                                       // 0x00BC(0x0004) MISSED OFFSET
	struct FCoreUObject_FTransform                     WorldOffset_69;                                           // 0x00C0(0x0060) (Edit, BlueprintVisible, IsPlainOldData)
	bool                                               bEnabled_69;                                              // 0x0120(0x0001) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	unsigned char                                      UnknownData02[0xF];                                       // 0x0121(0x000F) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_DebugRectangleItemSpace
// 0x00F8 (0x0130 - 0x0038)
struct FRigUnit_DebugRectangleItemSpace : public FRigUnit_DebugBaseMutable
{
	unsigned char                                      UnknownData00[0x8];                                       // 0x0038(0x0008) MISSED OFFSET
	struct FCoreUObject_FTransform                     Transform_69;                                             // 0x0040(0x0060) (Edit, BlueprintVisible, IsPlainOldData)
	struct FLinearColor                                Color_69;                                                 // 0x00A0(0x0010) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              Scale_69;                                                 // 0x00B0(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              Thickness_69;                                             // 0x00B4(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FRigElementKey                              Space_69;                                                 // 0x00B8(0x0008) (Edit, BlueprintVisible)
	struct FCoreUObject_FTransform                     WorldOffset_69;                                           // 0x00C0(0x0060) (Edit, BlueprintVisible, IsPlainOldData)
	bool                                               bEnabled_69;                                              // 0x0120(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0xF];                                       // 0x0121(0x000F) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_DebugArc
// 0x0108 (0x0140 - 0x0038)
struct FRigUnit_DebugArc : public FRigUnit_DebugBaseMutable
{
	unsigned char                                      UnknownData00[0x8];                                       // 0x0038(0x0008) MISSED OFFSET
	struct FCoreUObject_FTransform                     Transform_69;                                             // 0x0040(0x0060) (Edit, BlueprintVisible, IsPlainOldData)
	struct FLinearColor                                Color_69;                                                 // 0x00A0(0x0010) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              Radius_69;                                                // 0x00B0(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              MinimumDegrees_69;                                        // 0x00B4(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              MaximumDegrees_69;                                        // 0x00B8(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              Thickness_69;                                             // 0x00BC(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                Detail_69;                                                // 0x00C0(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FName                                       Space_69;                                                 // 0x00C4(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x8];                                       // 0x00C8(0x0008) MISSED OFFSET
	struct FCoreUObject_FTransform                     WorldOffset_69;                                           // 0x00D0(0x0060) (Edit, BlueprintVisible, IsPlainOldData)
	bool                                               bEnabled_69;                                              // 0x0130(0x0001) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	unsigned char                                      UnknownData02[0xF];                                       // 0x0131(0x000F) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_DebugArcItemSpace
// 0x0108 (0x0140 - 0x0038)
struct FRigUnit_DebugArcItemSpace : public FRigUnit_DebugBaseMutable
{
	unsigned char                                      UnknownData00[0x8];                                       // 0x0038(0x0008) MISSED OFFSET
	struct FCoreUObject_FTransform                     Transform_69;                                             // 0x0040(0x0060) (Edit, BlueprintVisible, IsPlainOldData)
	struct FLinearColor                                Color_69;                                                 // 0x00A0(0x0010) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              Radius_69;                                                // 0x00B0(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              MinimumDegrees_69;                                        // 0x00B4(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              MaximumDegrees_69;                                        // 0x00B8(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              Thickness_69;                                             // 0x00BC(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                Detail_69;                                                // 0x00C0(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FRigElementKey                              Space_69;                                                 // 0x00C4(0x0008) (Edit, BlueprintVisible)
	unsigned char                                      UnknownData01[0x4];                                       // 0x00CC(0x0004) MISSED OFFSET
	struct FCoreUObject_FTransform                     WorldOffset_69;                                           // 0x00D0(0x0060) (Edit, BlueprintVisible, IsPlainOldData)
	bool                                               bEnabled_69;                                              // 0x0130(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData02[0xF];                                       // 0x0131(0x000F) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_DebugTransform
// 0x00F8 (0x0100 - 0x0008)
struct FRigUnit_DebugTransform : public FRigUnit_DebugBase
{
	unsigned char                                      UnknownData00[0x8];                                       // 0x0008(0x0008) MISSED OFFSET
	struct FCoreUObject_FTransform                     Transform_69;                                             // 0x0010(0x0060) (Edit, BlueprintVisible, IsPlainOldData)
	ERigUnitDebugTransformMode                         Mode_69;                                                  // 0x0070(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x3];                                       // 0x0071(0x0003) MISSED OFFSET
	struct FLinearColor                                Color_69;                                                 // 0x0074(0x0010) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              Thickness_69;                                             // 0x0084(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              Scale_69;                                                 // 0x0088(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FName                                       Space_69;                                                 // 0x008C(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FCoreUObject_FTransform                     WorldOffset_69;                                           // 0x0090(0x0060) (Edit, BlueprintVisible, IsPlainOldData)
	bool                                               bEnabled_69;                                              // 0x00F0(0x0001) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	unsigned char                                      UnknownData02[0xF];                                       // 0x00F1(0x000F) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_DebugTransformMutable
// 0x00F8 (0x0130 - 0x0038)
struct FRigUnit_DebugTransformMutable : public FRigUnit_DebugBaseMutable
{
	unsigned char                                      UnknownData00[0x8];                                       // 0x0038(0x0008) MISSED OFFSET
	struct FCoreUObject_FTransform                     Transform_69;                                             // 0x0040(0x0060) (Edit, BlueprintVisible, IsPlainOldData)
	ERigUnitDebugTransformMode                         Mode_69;                                                  // 0x00A0(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x3];                                       // 0x00A1(0x0003) MISSED OFFSET
	struct FLinearColor                                Color_69;                                                 // 0x00A4(0x0010) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              Thickness_69;                                             // 0x00B4(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              Scale_69;                                                 // 0x00B8(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FName                                       Space_69;                                                 // 0x00BC(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FCoreUObject_FTransform                     WorldOffset_69;                                           // 0x00C0(0x0060) (Edit, BlueprintVisible, IsPlainOldData)
	bool                                               bEnabled_69;                                              // 0x0120(0x0001) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	unsigned char                                      UnknownData02[0xF];                                       // 0x0121(0x000F) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_DebugTransformMutableItemSpace
// 0x0108 (0x0140 - 0x0038)
struct FRigUnit_DebugTransformMutableItemSpace : public FRigUnit_DebugBaseMutable
{
	unsigned char                                      UnknownData00[0x8];                                       // 0x0038(0x0008) MISSED OFFSET
	struct FCoreUObject_FTransform                     Transform_69;                                             // 0x0040(0x0060) (Edit, BlueprintVisible, IsPlainOldData)
	ERigUnitDebugTransformMode                         Mode_69;                                                  // 0x00A0(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x3];                                       // 0x00A1(0x0003) MISSED OFFSET
	struct FLinearColor                                Color_69;                                                 // 0x00A4(0x0010) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              Thickness_69;                                             // 0x00B4(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              Scale_69;                                                 // 0x00B8(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FRigElementKey                              Space_69;                                                 // 0x00BC(0x0008) (Edit, BlueprintVisible)
	unsigned char                                      UnknownData02[0xC];                                       // 0x00C4(0x000C) MISSED OFFSET
	struct FCoreUObject_FTransform                     WorldOffset_69;                                           // 0x00D0(0x0060) (Edit, BlueprintVisible, IsPlainOldData)
	bool                                               bEnabled_69;                                              // 0x0130(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData03[0xF];                                       // 0x0131(0x000F) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_DebugTransformArrayMutable_WorkData
// 0x0010
struct FRigUnit_DebugTransformArrayMutable_WorkData
{
	TArray<struct FCoreUObject_FTransform>             DrawTransforms_69;                                        // 0x0000(0x0010) (ZeroConstructor)
};

// ScriptStruct ControlRig.RigUnit_DebugTransformArrayMutable
// 0x00B8 (0x00F0 - 0x0038)
struct FRigUnit_DebugTransformArrayMutable : public FRigUnit_DebugBaseMutable
{
	TArray<struct FCoreUObject_FTransform>             Transforms_69;                                            // 0x0038(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	ERigUnitDebugTransformMode                         Mode_69;                                                  // 0x0048(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0049(0x0003) MISSED OFFSET
	struct FLinearColor                                Color_69;                                                 // 0x004C(0x0010) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              Thickness_69;                                             // 0x005C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              Scale_69;                                                 // 0x0060(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FName                                       Space_69;                                                 // 0x0064(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x8];                                       // 0x0068(0x0008) MISSED OFFSET
	struct FCoreUObject_FTransform                     WorldOffset_69;                                           // 0x0070(0x0060) (Edit, BlueprintVisible, IsPlainOldData)
	bool                                               bEnabled_69;                                              // 0x00D0(0x0001) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	unsigned char                                      UnknownData02[0x7];                                       // 0x00D1(0x0007) MISSED OFFSET
	struct FRigUnit_DebugTransformArrayMutable_WorkData WorkData_69;                                              // 0x00D8(0x0010) (Transient)
	unsigned char                                      UnknownData03[0x8];                                       // 0x00E8(0x0008) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_DebugTransformArrayMutableItemSpace
// 0x00B8 (0x00F0 - 0x0038)
struct FRigUnit_DebugTransformArrayMutableItemSpace : public FRigUnit_DebugBaseMutable
{
	TArray<struct FCoreUObject_FTransform>             Transforms_69;                                            // 0x0038(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	TArray<int>                                        ParentIndices_69;                                         // 0x0048(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	ERigUnitDebugTransformMode                         Mode_69;                                                  // 0x0058(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0059(0x0003) MISSED OFFSET
	struct FLinearColor                                Color_69;                                                 // 0x005C(0x0010) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              Thickness_69;                                             // 0x006C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              Scale_69;                                                 // 0x0070(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FRigElementKey                              Space_69;                                                 // 0x0074(0x0008) (Edit, BlueprintVisible)
	unsigned char                                      UnknownData01[0x4];                                       // 0x007C(0x0004) MISSED OFFSET
	struct FCoreUObject_FTransform                     WorldOffset_69;                                           // 0x0080(0x0060) (Edit, BlueprintVisible, IsPlainOldData)
	bool                                               bEnabled_69;                                              // 0x00E0(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData02[0xF];                                       // 0x00E1(0x000F) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_StartProfilingTimer
// 0x0000 (0x0038 - 0x0038)
struct FRigUnit_StartProfilingTimer : public FRigUnit_DebugBaseMutable
{

};

// ScriptStruct ControlRig.RigUnit_EndProfilingTimer
// 0x0020 (0x0058 - 0x0038)
struct FRigUnit_EndProfilingTimer : public FRigUnit_DebugBaseMutable
{
	int                                                NumberOfMeasurements_69;                                  // 0x0038(0x0004) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x003C(0x0004) MISSED OFFSET
	struct FString                                     Prefix_69;                                                // 0x0040(0x0010) (Edit, BlueprintVisible, ZeroConstructor, EditConst)
	float                                              AccumulatedTime_69;                                       // 0x0050(0x0004) (ZeroConstructor, IsPlainOldData)
	int                                                MeasurementsLeft_69;                                      // 0x0054(0x0004) (ZeroConstructor, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_VisualDebugVector
// 0x0038 (0x0040 - 0x0008)
struct FRigUnit_VisualDebugVector : public FRigUnit_DebugBase
{
	struct FVector                                     Value_69;                                                 // 0x0008(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bEnabled_69;                                              // 0x0020(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	ERigUnitVisualDebugPointMode                       Mode_69;                                                  // 0x0021(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x2];                                       // 0x0022(0x0002) MISSED OFFSET
	struct FLinearColor                                Color_69;                                                 // 0x0024(0x0010) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              Thickness_69;                                             // 0x0034(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              Scale_69;                                                 // 0x0038(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FName                                       BoneSpace_69;                                             // 0x003C(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_VisualDebugVectorItemSpace
// 0x0040 (0x0048 - 0x0008)
struct FRigUnit_VisualDebugVectorItemSpace : public FRigUnit_DebugBase
{
	struct FVector                                     Value_69;                                                 // 0x0008(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bEnabled_69;                                              // 0x0020(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	ERigUnitVisualDebugPointMode                       Mode_69;                                                  // 0x0021(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x2];                                       // 0x0022(0x0002) MISSED OFFSET
	struct FLinearColor                                Color_69;                                                 // 0x0024(0x0010) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              Thickness_69;                                             // 0x0034(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              Scale_69;                                                 // 0x0038(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FRigElementKey                              Space_69;                                                 // 0x003C(0x0008) (Edit, BlueprintVisible)
	unsigned char                                      UnknownData01[0x4];                                       // 0x0044(0x0004) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_VisualDebugQuat
// 0x0038 (0x0040 - 0x0008)
struct FRigUnit_VisualDebugQuat : public FRigUnit_DebugBase
{
	unsigned char                                      UnknownData00[0x8];                                       // 0x0008(0x0008) MISSED OFFSET
	struct FQuat                                       Value_69;                                                 // 0x0010(0x0020) (Edit, BlueprintVisible, IsPlainOldData)
	bool                                               bEnabled_69;                                              // 0x0030(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x3];                                       // 0x0031(0x0003) MISSED OFFSET
	float                                              Thickness_69;                                             // 0x0034(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              Scale_69;                                                 // 0x0038(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FName                                       BoneSpace_69;                                             // 0x003C(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_VisualDebugQuatItemSpace
// 0x0048 (0x0050 - 0x0008)
struct FRigUnit_VisualDebugQuatItemSpace : public FRigUnit_DebugBase
{
	unsigned char                                      UnknownData00[0x8];                                       // 0x0008(0x0008) MISSED OFFSET
	struct FQuat                                       Value_69;                                                 // 0x0010(0x0020) (Edit, BlueprintVisible, IsPlainOldData)
	bool                                               bEnabled_69;                                              // 0x0030(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x3];                                       // 0x0031(0x0003) MISSED OFFSET
	float                                              Thickness_69;                                             // 0x0034(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              Scale_69;                                                 // 0x0038(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FRigElementKey                              Space_69;                                                 // 0x003C(0x0008) (Edit, BlueprintVisible)
	unsigned char                                      UnknownData02[0xC];                                       // 0x0044(0x000C) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_VisualDebugTransform
// 0x0078 (0x0080 - 0x0008)
struct FRigUnit_VisualDebugTransform : public FRigUnit_DebugBase
{
	unsigned char                                      UnknownData00[0x8];                                       // 0x0008(0x0008) MISSED OFFSET
	struct FCoreUObject_FTransform                     Value_69;                                                 // 0x0010(0x0060) (Edit, BlueprintVisible, IsPlainOldData)
	bool                                               bEnabled_69;                                              // 0x0070(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x3];                                       // 0x0071(0x0003) MISSED OFFSET
	float                                              Thickness_69;                                             // 0x0074(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              Scale_69;                                                 // 0x0078(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FName                                       BoneSpace_69;                                             // 0x007C(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_VisualDebugTransformItemSpace
// 0x0088 (0x0090 - 0x0008)
struct FRigUnit_VisualDebugTransformItemSpace : public FRigUnit_DebugBase
{
	unsigned char                                      UnknownData00[0x8];                                       // 0x0008(0x0008) MISSED OFFSET
	struct FCoreUObject_FTransform                     Value_69;                                                 // 0x0010(0x0060) (Edit, BlueprintVisible, IsPlainOldData)
	bool                                               bEnabled_69;                                              // 0x0070(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x3];                                       // 0x0071(0x0003) MISSED OFFSET
	float                                              Thickness_69;                                             // 0x0074(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              Scale_69;                                                 // 0x0078(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FRigElementKey                              Space_69;                                                 // 0x007C(0x0008) (Edit, BlueprintVisible)
	unsigned char                                      UnknownData02[0xC];                                       // 0x0084(0x000C) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_ConvertTransform
// 0x00B8 (0x00C0 - 0x0008)
struct FRigUnit_ConvertTransform : public FRigUnit
{
	unsigned char                                      UnknownData00[0x8];                                       // 0x0008(0x0008) MISSED OFFSET
	struct FCoreUObject_FTransform                     Input_69;                                                 // 0x0010(0x0060) (Edit, BlueprintVisible, IsPlainOldData)
	struct FEulerTransform                             Result_69;                                                // 0x0070(0x0048) (BlueprintVisible, BlueprintReadOnly)
	unsigned char                                      UnknownData01[0x8];                                       // 0x00B8(0x0008) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_ConvertEulerTransform
// 0x00A8 (0x00B0 - 0x0008)
struct FRigUnit_ConvertEulerTransform : public FRigUnit
{
	struct FEulerTransform                             Input_69;                                                 // 0x0008(0x0048) (Edit, BlueprintVisible)
	struct FCoreUObject_FTransform                     Result_69;                                                // 0x0050(0x0060) (BlueprintVisible, BlueprintReadOnly, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_ConvertRotation
// 0x0038 (0x0040 - 0x0008)
struct FRigUnit_ConvertRotation : public FRigUnit
{
	struct FRotator                                    Input_69;                                                 // 0x0008(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FQuat                                       Result_69;                                                // 0x0020(0x0020) (BlueprintVisible, BlueprintReadOnly, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_ConvertVectorRotation
// 0x0000 (0x0040 - 0x0040)
struct FRigUnit_ConvertVectorRotation : public FRigUnit_ConvertRotation
{

};

// ScriptStruct ControlRig.RigUnit_ConvertQuaternion
// 0x0048 (0x0050 - 0x0008)
struct FRigUnit_ConvertQuaternion : public FRigUnit
{
	unsigned char                                      UnknownData00[0x8];                                       // 0x0008(0x0008) MISSED OFFSET
	struct FQuat                                       Input_69;                                                 // 0x0010(0x0020) (Edit, BlueprintVisible, IsPlainOldData)
	struct FRotator                                    Result_69;                                                // 0x0030(0x0018) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x8];                                       // 0x0048(0x0008) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_ConvertVectorToRotation
// 0x0030 (0x0038 - 0x0008)
struct FRigUnit_ConvertVectorToRotation : public FRigUnit
{
	struct FVector                                     Input_69;                                                 // 0x0008(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FRotator                                    Result_69;                                                // 0x0020(0x0018) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_ConvertVectorToQuaternion
// 0x0038 (0x0040 - 0x0008)
struct FRigUnit_ConvertVectorToQuaternion : public FRigUnit
{
	struct FVector                                     Input_69;                                                 // 0x0008(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FQuat                                       Result_69;                                                // 0x0020(0x0020) (BlueprintVisible, BlueprintReadOnly, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_ConvertRotationToVector
// 0x0030 (0x0038 - 0x0008)
struct FRigUnit_ConvertRotationToVector : public FRigUnit
{
	struct FRotator                                    Input_69;                                                 // 0x0008(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FVector                                     Result_69;                                                // 0x0020(0x0018) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_ConvertQuaternionToVector
// 0x0048 (0x0050 - 0x0008)
struct FRigUnit_ConvertQuaternionToVector : public FRigUnit
{
	unsigned char                                      UnknownData00[0x8];                                       // 0x0008(0x0008) MISSED OFFSET
	struct FQuat                                       Input_69;                                                 // 0x0010(0x0020) (Edit, BlueprintVisible, IsPlainOldData)
	struct FVector                                     Result_69;                                                // 0x0030(0x0018) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x8];                                       // 0x0048(0x0008) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_ToSwingAndTwist
// 0x0088 (0x0090 - 0x0008)
struct FRigUnit_ToSwingAndTwist : public FRigUnit
{
	unsigned char                                      UnknownData00[0x8];                                       // 0x0008(0x0008) MISSED OFFSET
	struct FQuat                                       Input_69;                                                 // 0x0010(0x0020) (Edit, BlueprintVisible, IsPlainOldData)
	struct FVector                                     TwistAxis_69;                                             // 0x0030(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x8];                                       // 0x0048(0x0008) MISSED OFFSET
	struct FQuat                                       Swing_69;                                                 // 0x0050(0x0020) (BlueprintVisible, BlueprintReadOnly, IsPlainOldData)
	struct FQuat                                       Twist_69;                                                 // 0x0070(0x0020) (BlueprintVisible, BlueprintReadOnly, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_BinaryFloatOp
// 0x0010 (0x0018 - 0x0008)
struct FRigUnit_BinaryFloatOp : public FRigUnit
{
	float                                              Argument0_69;                                             // 0x0008(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              Argument1_69;                                             // 0x000C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              Result_69;                                                // 0x0010(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0014(0x0004) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_Multiply_FloatFloat
// 0x0000 (0x0018 - 0x0018)
struct FRigUnit_Multiply_FloatFloat : public FRigUnit_BinaryFloatOp
{

};

// ScriptStruct ControlRig.RigUnit_Add_FloatFloat
// 0x0000 (0x0018 - 0x0018)
struct FRigUnit_Add_FloatFloat : public FRigUnit_BinaryFloatOp
{

};

// ScriptStruct ControlRig.RigUnit_Subtract_FloatFloat
// 0x0000 (0x0018 - 0x0018)
struct FRigUnit_Subtract_FloatFloat : public FRigUnit_BinaryFloatOp
{

};

// ScriptStruct ControlRig.RigUnit_Divide_FloatFloat
// 0x0000 (0x0018 - 0x0018)
struct FRigUnit_Divide_FloatFloat : public FRigUnit_BinaryFloatOp
{

};

// ScriptStruct ControlRig.RigUnit_Clamp_Float
// 0x0010 (0x0018 - 0x0008)
struct FRigUnit_Clamp_Float : public FRigUnit
{
	float                                              Value_69;                                                 // 0x0008(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              min_69;                                                   // 0x000C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              max_69;                                                   // 0x0010(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              Result_69;                                                // 0x0014(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_MapRange_Float
// 0x0018 (0x0020 - 0x0008)
struct FRigUnit_MapRange_Float : public FRigUnit
{
	float                                              Value_69;                                                 // 0x0008(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              MinIn_69;                                                 // 0x000C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              MaxIn_69;                                                 // 0x0010(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              MinOut_69;                                                // 0x0014(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              MaxOut_69;                                                // 0x0018(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              Result_69;                                                // 0x001C(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_BinaryQuaternionOp
// 0x0068 (0x0070 - 0x0008)
struct FRigUnit_BinaryQuaternionOp : public FRigUnit
{
	unsigned char                                      UnknownData00[0x8];                                       // 0x0008(0x0008) MISSED OFFSET
	struct FQuat                                       Argument0_69;                                             // 0x0010(0x0020) (Edit, BlueprintVisible, IsPlainOldData)
	struct FQuat                                       Argument1_69;                                             // 0x0030(0x0020) (Edit, BlueprintVisible, IsPlainOldData)
	struct FQuat                                       Result_69;                                                // 0x0050(0x0020) (BlueprintVisible, BlueprintReadOnly, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_MultiplyQuaternion
// 0x0000 (0x0070 - 0x0070)
struct FRigUnit_MultiplyQuaternion : public FRigUnit_BinaryQuaternionOp
{

};

// ScriptStruct ControlRig.RigUnit_UnaryQuaternionOp
// 0x0048 (0x0050 - 0x0008)
struct FRigUnit_UnaryQuaternionOp : public FRigUnit
{
	unsigned char                                      UnknownData00[0x8];                                       // 0x0008(0x0008) MISSED OFFSET
	struct FQuat                                       Argument_69;                                              // 0x0010(0x0020) (Edit, BlueprintVisible, IsPlainOldData)
	struct FQuat                                       Result_69;                                                // 0x0030(0x0020) (BlueprintVisible, BlueprintReadOnly, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_InverseQuaterion
// 0x0000 (0x0050 - 0x0050)
struct FRigUnit_InverseQuaterion : public FRigUnit_UnaryQuaternionOp
{

};

// ScriptStruct ControlRig.RigUnit_QuaternionToAxisAndAngle
// 0x0048 (0x0050 - 0x0008)
struct FRigUnit_QuaternionToAxisAndAngle : public FRigUnit
{
	unsigned char                                      UnknownData00[0x8];                                       // 0x0008(0x0008) MISSED OFFSET
	struct FQuat                                       Argument_69;                                              // 0x0010(0x0020) (Edit, BlueprintVisible, IsPlainOldData)
	struct FVector                                     Axis_69;                                                  // 0x0030(0x0018) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              Angle_69;                                                 // 0x0048(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x4];                                       // 0x004C(0x0004) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_QuaternionFromAxisAndAngle
// 0x0048 (0x0050 - 0x0008)
struct FRigUnit_QuaternionFromAxisAndAngle : public FRigUnit
{
	struct FVector                                     Axis_69;                                                  // 0x0008(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              Angle_69;                                                 // 0x0020(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0xC];                                       // 0x0024(0x000C) MISSED OFFSET
	struct FQuat                                       Result_69;                                                // 0x0030(0x0020) (BlueprintVisible, BlueprintReadOnly, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_QuaternionToAngle
// 0x0048 (0x0050 - 0x0008)
struct FRigUnit_QuaternionToAngle : public FRigUnit
{
	struct FVector                                     Axis_69;                                                  // 0x0008(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FQuat                                       Argument_69;                                              // 0x0020(0x0020) (Edit, BlueprintVisible, IsPlainOldData)
	float                                              Angle_69;                                                 // 0x0040(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0xC];                                       // 0x0044(0x000C) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_BinaryTransformOp
// 0x0128 (0x0130 - 0x0008)
struct FRigUnit_BinaryTransformOp : public FRigUnit
{
	unsigned char                                      UnknownData00[0x8];                                       // 0x0008(0x0008) MISSED OFFSET
	struct FCoreUObject_FTransform                     Argument0_69;                                             // 0x0010(0x0060) (Edit, BlueprintVisible, IsPlainOldData)
	struct FCoreUObject_FTransform                     Argument1_69;                                             // 0x0070(0x0060) (Edit, BlueprintVisible, IsPlainOldData)
	struct FCoreUObject_FTransform                     Result_69;                                                // 0x00D0(0x0060) (BlueprintVisible, BlueprintReadOnly, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_MultiplyTransform
// 0x0000 (0x0130 - 0x0130)
struct FRigUnit_MultiplyTransform : public FRigUnit_BinaryTransformOp
{

};

// ScriptStruct ControlRig.RigUnit_GetRelativeTransform
// 0x0000 (0x0130 - 0x0130)
struct FRigUnit_GetRelativeTransform : public FRigUnit_BinaryTransformOp
{

};

// ScriptStruct ControlRig.RigUnit_BinaryVectorOp
// 0x0048 (0x0050 - 0x0008)
struct FRigUnit_BinaryVectorOp : public FRigUnit
{
	struct FVector                                     Argument0_69;                                             // 0x0008(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FVector                                     Argument1_69;                                             // 0x0020(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FVector                                     Result_69;                                                // 0x0038(0x0018) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_Multiply_VectorVector
// 0x0000 (0x0050 - 0x0050)
struct FRigUnit_Multiply_VectorVector : public FRigUnit_BinaryVectorOp
{

};

// ScriptStruct ControlRig.RigUnit_Add_VectorVector
// 0x0000 (0x0050 - 0x0050)
struct FRigUnit_Add_VectorVector : public FRigUnit_BinaryVectorOp
{

};

// ScriptStruct ControlRig.RigUnit_Subtract_VectorVector
// 0x0000 (0x0050 - 0x0050)
struct FRigUnit_Subtract_VectorVector : public FRigUnit_BinaryVectorOp
{

};

// ScriptStruct ControlRig.RigUnit_Divide_VectorVector
// 0x0000 (0x0050 - 0x0050)
struct FRigUnit_Divide_VectorVector : public FRigUnit_BinaryVectorOp
{

};

// ScriptStruct ControlRig.RigUnit_Distance_VectorVector
// 0x0038 (0x0040 - 0x0008)
struct FRigUnit_Distance_VectorVector : public FRigUnit
{
	struct FVector                                     Argument0_69;                                             // 0x0008(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FVector                                     Argument1_69;                                             // 0x0020(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              Result_69;                                                // 0x0038(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x003C(0x0004) MISSED OFFSET
};

// ScriptStruct ControlRig.AimTarget
// 0x0090
struct FAimTarget
{
	float                                              Weight_69;                                                // 0x0000(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0xC];                                       // 0x0004(0x000C) MISSED OFFSET
	struct FCoreUObject_FTransform                     Transform_69;                                             // 0x0010(0x0060) (Edit, IsPlainOldData)
	struct FVector                                     AlignVector_69;                                           // 0x0070(0x0018) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x8];                                       // 0x0088(0x0008) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_AimConstraint_WorkData
// 0x0010
struct FRigUnit_AimConstraint_WorkData
{
	TArray<struct FConstraintData>                     ConstraintData_69;                                        // 0x0000(0x0010) (ZeroConstructor)
};

// ScriptStruct ControlRig.RigUnit_AimConstraint
// 0x0068 (0x00A0 - 0x0038)
struct FRigUnit_AimConstraint : public FRigUnitMutable
{
	struct FName                                       Joint_69;                                                 // 0x0038(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	EAimMode                                           AimMode_69;                                               // 0x003C(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	EAimMode                                           UpMode_69;                                                // 0x003D(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x2];                                       // 0x003E(0x0002) MISSED OFFSET
	struct FVector                                     AimVector_69;                                             // 0x0040(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FVector                                     UpVector_69;                                              // 0x0058(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	TArray<struct FAimTarget>                          AimTargets_69;                                            // 0x0070(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	TArray<struct FAimTarget>                          UpTargets_69;                                             // 0x0080(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FRigUnit_AimConstraint_WorkData             WorkData_69;                                              // 0x0090(0x0010)
};

// ScriptStruct ControlRig.RigUnit_ApplyFK
// 0x00E8 (0x0120 - 0x0038)
struct FRigUnit_ApplyFK : public FRigUnitMutable
{
	struct FName                                       Joint_69;                                                 // 0x0038(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x003C(0x0004) MISSED OFFSET
	struct FCoreUObject_FTransform                     Transform_69;                                             // 0x0040(0x0060) (Edit, BlueprintVisible, IsPlainOldData)
	struct FTransformFilter                            Filter_69;                                                // 0x00A0(0x0009) (Edit, BlueprintVisible)
	EApplyTransformMode                                ApplyTransformMode_69;                                    // 0x00A9(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	ETransformSpaceMode                                ApplyTransformSpace_69;                                   // 0x00AA(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x5];                                       // 0x00AB(0x0005) MISSED OFFSET
	struct FCoreUObject_FTransform                     BaseTransform_69;                                         // 0x00B0(0x0060) (Edit, BlueprintVisible, IsPlainOldData)
	struct FName                                       BaseJoint_69;                                             // 0x0110(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData02[0xC];                                       // 0x0114(0x000C) MISSED OFFSET
};

// ScriptStruct ControlRig.BlendTarget
// 0x0070
struct FBlendTarget
{
	struct FCoreUObject_FTransform                     Transform_69;                                             // 0x0000(0x0060) (Edit, IsPlainOldData)
	float                                              Weight_69;                                                // 0x0060(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0xC];                                       // 0x0064(0x000C) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_BlendTransform
// 0x00D8 (0x00E0 - 0x0008)
struct FRigUnit_BlendTransform : public FRigUnit
{
	unsigned char                                      UnknownData00[0x8];                                       // 0x0008(0x0008) MISSED OFFSET
	struct FCoreUObject_FTransform                     Source_69;                                                // 0x0010(0x0060) (Edit, BlueprintVisible, IsPlainOldData)
	TArray<struct FBlendTarget>                        Targets_69;                                               // 0x0070(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FCoreUObject_FTransform                     Result_69;                                                // 0x0080(0x0060) (BlueprintVisible, BlueprintReadOnly, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_GetJointTransform
// 0x00D8 (0x0110 - 0x0038)
struct FRigUnit_GetJointTransform : public FRigUnitMutable
{
	struct FName                                       Joint_69;                                                 // 0x0038(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	ETransformGetterType                               Type_69;                                                  // 0x003C(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	ETransformSpaceMode                                TransformSpace_69;                                        // 0x003D(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x2];                                       // 0x003E(0x0002) MISSED OFFSET
	struct FCoreUObject_FTransform                     BaseTransform_69;                                         // 0x0040(0x0060) (Edit, BlueprintVisible, IsPlainOldData)
	struct FName                                       BaseJoint_69;                                             // 0x00A0(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0xC];                                       // 0x00A4(0x000C) MISSED OFFSET
	struct FCoreUObject_FTransform                     Output_69;                                                // 0x00B0(0x0060) (BlueprintVisible, BlueprintReadOnly, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_TwoBoneIKFK
// 0x0308 (0x0340 - 0x0038)
struct FRigUnit_TwoBoneIKFK : public FRigUnitMutable
{
	struct FName                                       StartJoint_69;                                            // 0x0038(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FName                                       EndJoint_69;                                              // 0x003C(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FVector                                     PoleTarget_69;                                            // 0x0040(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              Spin_69;                                                  // 0x0058(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x005C(0x0004) MISSED OFFSET
	struct FCoreUObject_FTransform                     EndEffector_69;                                           // 0x0060(0x0060) (Edit, BlueprintVisible, IsPlainOldData)
	float                                              IKBlend_69;                                               // 0x00C0(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0xC];                                       // 0x00C4(0x000C) MISSED OFFSET
	struct FCoreUObject_FTransform                     StartJointFKTransform_69;                                 // 0x00D0(0x0060) (Edit, IsPlainOldData)
	struct FCoreUObject_FTransform                     MidJointFKTransform_69;                                   // 0x0130(0x0060) (Edit, IsPlainOldData)
	struct FCoreUObject_FTransform                     EndJointFKTransform_69;                                   // 0x0190(0x0060) (Edit, IsPlainOldData)
	float                                              PreviousFKIKBlend_69;                                     // 0x01F0(0x0004) (ZeroConstructor, Transient, IsPlainOldData)
	unsigned char                                      UnknownData02[0xC];                                       // 0x01F4(0x000C) MISSED OFFSET
	struct FCoreUObject_FTransform                     StartJointIKTransform_69;                                 // 0x0200(0x0060) (Transient, IsPlainOldData)
	struct FCoreUObject_FTransform                     MidJointIKTransform_69;                                   // 0x0260(0x0060) (Transient, IsPlainOldData)
	struct FCoreUObject_FTransform                     EndJointIKTransform_69;                                   // 0x02C0(0x0060) (Transient, IsPlainOldData)
	int                                                StartJointIndex_69;                                       // 0x0320(0x0004) (ZeroConstructor, Transient, IsPlainOldData)
	int                                                MidJointIndex_69;                                         // 0x0324(0x0004) (ZeroConstructor, Transient, IsPlainOldData)
	int                                                EndJointIndex_69;                                         // 0x0328(0x0004) (ZeroConstructor, Transient, IsPlainOldData)
	float                                              UpperLimbLength_69;                                       // 0x032C(0x0004) (ZeroConstructor, Transient, IsPlainOldData)
	float                                              LowerLimbLength_69;                                       // 0x0330(0x0004) (ZeroConstructor, Transient, IsPlainOldData)
	unsigned char                                      UnknownData03[0xC];                                       // 0x0334(0x000C) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_DrawContainerGetInstruction
// 0x0078 (0x0080 - 0x0008)
struct FRigUnit_DrawContainerGetInstruction : public FRigUnit
{
	struct FName                                       InstructionName_69;                                       // 0x0008(0x0008) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	struct FLinearColor                                Color_69;                                                 // 0x000C(0x0010) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x001C(0x0004) MISSED OFFSET
	struct FCoreUObject_FTransform                     Transform_69;                                             // 0x0020(0x0060) (BlueprintVisible, BlueprintReadOnly, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_DrawContainerSetColor
// 0x0018 (0x0050 - 0x0038)
struct FRigUnit_DrawContainerSetColor : public FRigUnitMutable
{
	struct FName                                       InstructionName_69;                                       // 0x0038(0x0008) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	struct FLinearColor                                Color_69;                                                 // 0x003C(0x0010) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x004C(0x0004) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_DrawContainerSetThickness
// 0x0008 (0x0040 - 0x0038)
struct FRigUnit_DrawContainerSetThickness : public FRigUnitMutable
{
	struct FName                                       InstructionName_69;                                       // 0x0038(0x0008) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	float                                              Thickness_69;                                             // 0x003C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_DrawContainerSetTransform
// 0x0068 (0x00A0 - 0x0038)
struct FRigUnit_DrawContainerSetTransform : public FRigUnitMutable
{
	struct FName                                       InstructionName_69;                                       // 0x0038(0x0008) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x003C(0x0004) MISSED OFFSET
	struct FCoreUObject_FTransform                     Transform_69;                                             // 0x0040(0x0060) (Edit, BlueprintVisible, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_BeginExecution
// 0x0030 (0x0038 - 0x0008)
struct FRigUnit_BeginExecution : public FRigUnit
{
	struct FControlRigExecuteContext                   ExecuteContext_69;                                        // 0x0008(0x0030) (Edit, BlueprintVisible, BlueprintReadOnly, Transient)
};

// ScriptStruct ControlRig.RigUnit_CollectionBase
// 0x0000 (0x0008 - 0x0008)
struct FRigUnit_CollectionBase : public FRigUnit
{

};

// ScriptStruct ControlRig.RigUnit_CollectionBaseMutable
// 0x0000 (0x0038 - 0x0038)
struct FRigUnit_CollectionBaseMutable : public FRigUnitMutable
{

};

// ScriptStruct ControlRig.RigUnit_CollectionChain
// 0x0028 (0x0030 - 0x0008)
struct FRigUnit_CollectionChain : public FRigUnit_CollectionBase
{
	struct FRigElementKey                              FirstItem_69;                                             // 0x0008(0x0008) (Edit, BlueprintVisible)
	struct FRigElementKey                              LastItem_69;                                              // 0x0010(0x0008) (Edit, BlueprintVisible)
	bool                                               Reverse_69;                                               // 0x0018(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0019(0x0007) MISSED OFFSET
	struct FRigElementKeyCollection                    Collection_69;                                            // 0x0020(0x0010) (BlueprintVisible, BlueprintReadOnly)
};

// ScriptStruct ControlRig.RigUnit_CollectionChainArray
// 0x0028 (0x0030 - 0x0008)
struct FRigUnit_CollectionChainArray : public FRigUnit_CollectionBase
{
	struct FRigElementKey                              FirstItem_69;                                             // 0x0008(0x0008) (Edit, BlueprintVisible)
	struct FRigElementKey                              LastItem_69;                                              // 0x0010(0x0008) (Edit, BlueprintVisible)
	bool                                               Reverse_69;                                               // 0x0018(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0019(0x0007) MISSED OFFSET
	TArray<struct FRigElementKey>                      Items_69;                                                 // 0x0020(0x0010) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
};

// ScriptStruct ControlRig.RigUnit_CollectionNameSearch
// 0x0018 (0x0020 - 0x0008)
struct FRigUnit_CollectionNameSearch : public FRigUnit_CollectionBase
{
	struct FName                                       PartialName_69;                                           // 0x0008(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	ERigElementType                                    TypeToSearch_69;                                          // 0x000C(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x000D(0x0003) MISSED OFFSET
	struct FRigElementKeyCollection                    Collection_69;                                            // 0x0010(0x0010) (BlueprintVisible, BlueprintReadOnly)
};

// ScriptStruct ControlRig.RigUnit_CollectionNameSearchArray
// 0x0018 (0x0020 - 0x0008)
struct FRigUnit_CollectionNameSearchArray : public FRigUnit_CollectionBase
{
	struct FName                                       PartialName_69;                                           // 0x0008(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	ERigElementType                                    TypeToSearch_69;                                          // 0x000C(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x000D(0x0003) MISSED OFFSET
	TArray<struct FRigElementKey>                      Items_69;                                                 // 0x0010(0x0010) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
};

// ScriptStruct ControlRig.RigUnit_CollectionChildren
// 0x0020 (0x0028 - 0x0008)
struct FRigUnit_CollectionChildren : public FRigUnit_CollectionBase
{
	struct FRigElementKey                              Parent_69;                                                // 0x0008(0x0008) (Edit, BlueprintVisible)
	bool                                               bIncludeParent_69;                                        // 0x0010(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bRecursive_69;                                            // 0x0011(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	ERigElementType                                    TypeToSearch_69;                                          // 0x0012(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x5];                                       // 0x0013(0x0005) MISSED OFFSET
	struct FRigElementKeyCollection                    Collection_69;                                            // 0x0018(0x0010) (BlueprintVisible, BlueprintReadOnly)
};

// ScriptStruct ControlRig.RigUnit_CollectionChildrenArray
// 0x0020 (0x0028 - 0x0008)
struct FRigUnit_CollectionChildrenArray : public FRigUnit_CollectionBase
{
	struct FRigElementKey                              Parent_69;                                                // 0x0008(0x0008) (Edit, BlueprintVisible)
	bool                                               bIncludeParent_69;                                        // 0x0010(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bRecursive_69;                                            // 0x0011(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	ERigElementType                                    TypeToSearch_69;                                          // 0x0012(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x5];                                       // 0x0013(0x0005) MISSED OFFSET
	TArray<struct FRigElementKey>                      Items_69;                                                 // 0x0018(0x0010) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
};

// ScriptStruct ControlRig.RigUnit_CollectionGetAll
// 0x0018 (0x0020 - 0x0008)
struct FRigUnit_CollectionGetAll : public FRigUnit_CollectionBase
{
	ERigElementType                                    TypeToSearch_69;                                          // 0x0008(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0009(0x0007) MISSED OFFSET
	TArray<struct FRigElementKey>                      Items_69;                                                 // 0x0010(0x0010) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
};

// ScriptStruct ControlRig.RigUnit_CollectionReplaceItems
// 0x0030 (0x0038 - 0x0008)
struct FRigUnit_CollectionReplaceItems : public FRigUnit_CollectionBase
{
	struct FRigElementKeyCollection                    Items_69;                                                 // 0x0008(0x0010) (Edit, BlueprintVisible)
	struct FName                                       Old_69;                                                   // 0x0018(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FName                                       New_69;                                                   // 0x001C(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               RemoveInvalidItems_69;                                    // 0x0020(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bAllowDuplicates_69;                                      // 0x0021(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x6];                                       // 0x0022(0x0006) MISSED OFFSET
	struct FRigElementKeyCollection                    Collection_69;                                            // 0x0028(0x0010) (BlueprintVisible, BlueprintReadOnly)
};

// ScriptStruct ControlRig.RigUnit_CollectionReplaceItemsArray
// 0x0030 (0x0038 - 0x0008)
struct FRigUnit_CollectionReplaceItemsArray : public FRigUnit_CollectionBase
{
	TArray<struct FRigElementKey>                      Items_69;                                                 // 0x0008(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FName                                       Old_69;                                                   // 0x0018(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FName                                       New_69;                                                   // 0x001C(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               RemoveInvalidItems_69;                                    // 0x0020(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bAllowDuplicates_69;                                      // 0x0021(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x6];                                       // 0x0022(0x0006) MISSED OFFSET
	TArray<struct FRigElementKey>                      Result_69;                                                // 0x0028(0x0010) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
};

// ScriptStruct ControlRig.RigUnit_CollectionItems
// 0x0028 (0x0030 - 0x0008)
struct FRigUnit_CollectionItems : public FRigUnit_CollectionBase
{
	TArray<struct FRigElementKey>                      Items_69;                                                 // 0x0008(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	bool                                               bAllowDuplicates_69;                                      // 0x0018(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0019(0x0007) MISSED OFFSET
	struct FRigElementKeyCollection                    Collection_69;                                            // 0x0020(0x0010) (BlueprintVisible, BlueprintReadOnly)
};

// ScriptStruct ControlRig.RigUnit_CollectionGetItems
// 0x0020 (0x0028 - 0x0008)
struct FRigUnit_CollectionGetItems : public FRigUnit_CollectionBase
{
	struct FRigElementKeyCollection                    Collection_69;                                            // 0x0008(0x0010) (Edit, BlueprintVisible)
	TArray<struct FRigElementKey>                      Items_69;                                                 // 0x0018(0x0010) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
};

// ScriptStruct ControlRig.RigUnit_CollectionGetParentIndices
// 0x0020 (0x0028 - 0x0008)
struct FRigUnit_CollectionGetParentIndices : public FRigUnit_CollectionBase
{
	struct FRigElementKeyCollection                    Collection_69;                                            // 0x0008(0x0010) (Edit, BlueprintVisible)
	TArray<int>                                        ParentIndices_69;                                         // 0x0018(0x0010) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
};

// ScriptStruct ControlRig.RigUnit_CollectionGetParentIndicesItemArray
// 0x0020 (0x0028 - 0x0008)
struct FRigUnit_CollectionGetParentIndicesItemArray : public FRigUnit_CollectionBase
{
	TArray<struct FRigElementKey>                      Items_69;                                                 // 0x0008(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	TArray<int>                                        ParentIndices_69;                                         // 0x0018(0x0010) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
};

// ScriptStruct ControlRig.RigUnit_CollectionUnion
// 0x0038 (0x0040 - 0x0008)
struct FRigUnit_CollectionUnion : public FRigUnit_CollectionBase
{
	struct FRigElementKeyCollection                    A_69;                                                     // 0x0008(0x0010) (Edit, BlueprintVisible)
	struct FRigElementKeyCollection                    B_69;                                                     // 0x0018(0x0010) (Edit, BlueprintVisible)
	bool                                               bAllowDuplicates_69;                                      // 0x0028(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0029(0x0007) MISSED OFFSET
	struct FRigElementKeyCollection                    Collection_69;                                            // 0x0030(0x0010) (BlueprintVisible, BlueprintReadOnly)
};

// ScriptStruct ControlRig.RigUnit_CollectionIntersection
// 0x0030 (0x0038 - 0x0008)
struct FRigUnit_CollectionIntersection : public FRigUnit_CollectionBase
{
	struct FRigElementKeyCollection                    A_69;                                                     // 0x0008(0x0010) (Edit, BlueprintVisible)
	struct FRigElementKeyCollection                    B_69;                                                     // 0x0018(0x0010) (Edit, BlueprintVisible)
	struct FRigElementKeyCollection                    Collection_69;                                            // 0x0028(0x0010) (BlueprintVisible, BlueprintReadOnly)
};

// ScriptStruct ControlRig.RigUnit_CollectionDifference
// 0x0030 (0x0038 - 0x0008)
struct FRigUnit_CollectionDifference : public FRigUnit_CollectionBase
{
	struct FRigElementKeyCollection                    A_69;                                                     // 0x0008(0x0010) (Edit, BlueprintVisible)
	struct FRigElementKeyCollection                    B_69;                                                     // 0x0018(0x0010) (Edit, BlueprintVisible)
	struct FRigElementKeyCollection                    Collection_69;                                            // 0x0028(0x0010) (BlueprintVisible, BlueprintReadOnly)
};

// ScriptStruct ControlRig.RigUnit_CollectionReverse
// 0x0020 (0x0028 - 0x0008)
struct FRigUnit_CollectionReverse : public FRigUnit_CollectionBase
{
	struct FRigElementKeyCollection                    Collection_69;                                            // 0x0008(0x0010) (Edit, BlueprintVisible)
	struct FRigElementKeyCollection                    Reversed_69;                                              // 0x0018(0x0010) (BlueprintVisible, BlueprintReadOnly)
};

// ScriptStruct ControlRig.RigUnit_CollectionCount
// 0x0018 (0x0020 - 0x0008)
struct FRigUnit_CollectionCount : public FRigUnit_CollectionBase
{
	struct FRigElementKeyCollection                    Collection_69;                                            // 0x0008(0x0010) (Edit, BlueprintVisible)
	int                                                Count_69;                                                 // 0x0018(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x001C(0x0004) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_CollectionItemAtIndex
// 0x0020 (0x0028 - 0x0008)
struct FRigUnit_CollectionItemAtIndex : public FRigUnit_CollectionBase
{
	struct FRigElementKeyCollection                    Collection_69;                                            // 0x0008(0x0010) (Edit, BlueprintVisible)
	int                                                Index_69;                                                 // 0x0018(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FRigElementKey                              Item_69;                                                  // 0x001C(0x0008) (BlueprintVisible, BlueprintReadOnly)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0024(0x0004) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_CollectionLoop
// 0x0058 (0x0090 - 0x0038)
struct FRigUnit_CollectionLoop : public FRigUnit_CollectionBaseMutable
{
	struct FRigElementKeyCollection                    Collection_69;                                            // 0x0038(0x0010) (Edit, BlueprintVisible)
	struct FRigElementKey                              Item_69;                                                  // 0x0048(0x0008) (BlueprintVisible, BlueprintReadOnly)
	int                                                Index_69;                                                 // 0x0050(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                Count_69;                                                 // 0x0054(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              Ratio_69;                                                 // 0x0058(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	bool                                               Continue_69;                                              // 0x005C(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x005D(0x0003) MISSED OFFSET
	struct FControlRigExecuteContext                   Completed_69;                                             // 0x0060(0x0030) (BlueprintVisible, BlueprintReadOnly)
};

// ScriptStruct ControlRig.RigUnit_CollectionAddItem
// 0x0028 (0x0030 - 0x0008)
struct FRigUnit_CollectionAddItem : public FRigUnit_CollectionBase
{
	struct FRigElementKeyCollection                    Collection_69;                                            // 0x0008(0x0010) (Edit, BlueprintVisible)
	struct FRigElementKey                              Item_69;                                                  // 0x0018(0x0008) (Edit, BlueprintVisible)
	struct FRigElementKeyCollection                    Result_69;                                                // 0x0020(0x0010) (BlueprintVisible, BlueprintReadOnly)
};

// ScriptStruct ControlRig.RigUnit_DynamicHierarchyBase
// 0x0000 (0x0008 - 0x0008)
struct FRigUnit_DynamicHierarchyBase : public FRigUnit
{

};

// ScriptStruct ControlRig.RigUnit_DynamicHierarchyBaseMutable
// 0x0000 (0x0038 - 0x0038)
struct FRigUnit_DynamicHierarchyBaseMutable : public FRigUnitMutable
{

};

// ScriptStruct ControlRig.RigUnit_AddParent
// 0x0010 (0x0048 - 0x0038)
struct FRigUnit_AddParent : public FRigUnit_DynamicHierarchyBaseMutable
{
	struct FRigElementKey                              Child_69;                                                 // 0x0038(0x0008) (Edit, BlueprintVisible)
	struct FRigElementKey                              Parent_69;                                                // 0x0040(0x0008) (Edit, BlueprintVisible)
};

// ScriptStruct ControlRig.RigUnit_SetDefaultParent
// 0x0010 (0x0048 - 0x0038)
struct FRigUnit_SetDefaultParent : public FRigUnit_DynamicHierarchyBaseMutable
{
	struct FRigElementKey                              Child_69;                                                 // 0x0038(0x0008) (Edit, BlueprintVisible)
	struct FRigElementKey                              Parent_69;                                                // 0x0040(0x0008) (Edit, BlueprintVisible)
};

// ScriptStruct ControlRig.RigUnit_SwitchParent
// 0x0018 (0x0050 - 0x0038)
struct FRigUnit_SwitchParent : public FRigUnit_DynamicHierarchyBaseMutable
{
	ERigSwitchParentMode                               Mode_69;                                                  // 0x0038(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0039(0x0003) MISSED OFFSET
	struct FRigElementKey                              Child_69;                                                 // 0x003C(0x0008) (Edit, BlueprintVisible)
	struct FRigElementKey                              Parent_69;                                                // 0x0044(0x0008) (Edit, BlueprintVisible)
	bool                                               bMaintainGlobal_69;                                       // 0x004C(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x3];                                       // 0x004D(0x0003) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_HierarchyGetParentWeights
// 0x0028 (0x0030 - 0x0008)
struct FRigUnit_HierarchyGetParentWeights : public FRigUnit_DynamicHierarchyBase
{
	struct FRigElementKey                              Child_69;                                                 // 0x0008(0x0008) (Edit, BlueprintVisible)
	TArray<struct FRigElementWeight>                   Weights_69;                                               // 0x0010(0x0010) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
	struct FRigElementKeyCollection                    Parents_69;                                               // 0x0020(0x0010) (BlueprintVisible, BlueprintReadOnly)
};

// ScriptStruct ControlRig.RigUnit_HierarchyGetParentWeightsArray
// 0x0028 (0x0030 - 0x0008)
struct FRigUnit_HierarchyGetParentWeightsArray : public FRigUnit_DynamicHierarchyBase
{
	struct FRigElementKey                              Child_69;                                                 // 0x0008(0x0008) (Edit, BlueprintVisible)
	TArray<struct FRigElementWeight>                   Weights_69;                                               // 0x0010(0x0010) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
	TArray<struct FRigElementKey>                      Parents_69;                                               // 0x0020(0x0010) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
};

// ScriptStruct ControlRig.RigUnit_HierarchySetParentWeights
// 0x0018 (0x0050 - 0x0038)
struct FRigUnit_HierarchySetParentWeights : public FRigUnit_DynamicHierarchyBaseMutable
{
	struct FRigElementKey                              Child_69;                                                 // 0x0038(0x0008) (Edit, BlueprintVisible)
	TArray<struct FRigElementWeight>                   Weights_69;                                               // 0x0040(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
};

// ScriptStruct ControlRig.RigUnit_HierarchyReset
// 0x0000 (0x0038 - 0x0038)
struct FRigUnit_HierarchyReset : public FRigUnit_DynamicHierarchyBaseMutable
{

};

// ScriptStruct ControlRig.RigUnit_HierarchyImportFromSkeleton
// 0x0018 (0x0050 - 0x0038)
struct FRigUnit_HierarchyImportFromSkeleton : public FRigUnit_DynamicHierarchyBaseMutable
{
	struct FName                                       Namespace_69;                                             // 0x0038(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bIncludeCurves_69;                                        // 0x003C(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x003D(0x0003) MISSED OFFSET
	TArray<struct FRigElementKey>                      Items_69;                                                 // 0x0040(0x0010) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
};

// ScriptStruct ControlRig.RigUnit_HierarchyRemoveElement
// 0x0010 (0x0048 - 0x0038)
struct FRigUnit_HierarchyRemoveElement : public FRigUnit_DynamicHierarchyBaseMutable
{
	struct FRigElementKey                              Item_69;                                                  // 0x0038(0x0008) (Edit, BlueprintVisible)
	bool                                               bSuccess_69;                                              // 0x0040(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0041(0x0007) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_HierarchyAddElement
// 0x0018 (0x0050 - 0x0038)
struct FRigUnit_HierarchyAddElement : public FRigUnit_DynamicHierarchyBaseMutable
{
	struct FRigElementKey                              Parent_69;                                                // 0x0038(0x0008) (Edit, BlueprintVisible)
	struct FName                                       Name_69;                                                  // 0x0040(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FRigElementKey                              Item_69;                                                  // 0x0044(0x0008) (BlueprintVisible, BlueprintReadOnly)
	unsigned char                                      UnknownData00[0x4];                                       // 0x004C(0x0004) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_HierarchyAddBone
// 0x0070 (0x00C0 - 0x0050)
struct FRigUnit_HierarchyAddBone : public FRigUnit_HierarchyAddElement
{
	struct FCoreUObject_FTransform                     Transform_69;                                             // 0x0050(0x0060) (Edit, BlueprintVisible, IsPlainOldData)
	EBoneGetterSetterMode                              Space_69;                                                 // 0x00B0(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0xF];                                       // 0x00B1(0x000F) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_HierarchyAddNull
// 0x0070 (0x00C0 - 0x0050)
struct FRigUnit_HierarchyAddNull : public FRigUnit_HierarchyAddElement
{
	struct FCoreUObject_FTransform                     Transform_69;                                             // 0x0050(0x0060) (Edit, BlueprintVisible, IsPlainOldData)
	EBoneGetterSetterMode                              Space_69;                                                 // 0x00B0(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0xF];                                       // 0x00B1(0x000F) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_HierarchyAddControl_Settings
// 0x0010
struct FRigUnit_HierarchyAddControl_Settings
{
	unsigned char                                      UnknownData00[0x8];                                       // 0x0000(0x0008) MISSED OFFSET
	struct FName                                       DisplayName_69;                                           // 0x0008(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x4];                                       // 0x000C(0x0004) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_HierarchyAddControl_ShapeSettings
// 0x0080
struct FRigUnit_HierarchyAddControl_ShapeSettings
{
	bool                                               bVisible_69;                                              // 0x0000(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0001(0x0003) MISSED OFFSET
	struct FName                                       Name_69;                                                  // 0x0004(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FLinearColor                                Color_69;                                                 // 0x0008(0x0010) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x8];                                       // 0x0018(0x0008) MISSED OFFSET
	struct FCoreUObject_FTransform                     Transform_69;                                             // 0x0020(0x0060) (Edit, BlueprintVisible, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_HierarchyAddControl_ProxySettings
// 0x0020
struct FRigUnit_HierarchyAddControl_ProxySettings
{
	bool                                               bIsProxy_69;                                              // 0x0000(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0001(0x0007) MISSED OFFSET
	TArray<struct FRigElementKey>                      DrivenControls_69;                                        // 0x0008(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	ERigControlVisibility                              ShapeVisibility_69;                                       // 0x0018(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x7];                                       // 0x0019(0x0007) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_HierarchyAddControlFloat_LimitSettings
// 0x0010
struct FRigUnit_HierarchyAddControlFloat_LimitSettings
{
	struct FRigControlLimitEnabled                     Limit_69;                                                 // 0x0000(0x0002) (Edit, BlueprintVisible)
	unsigned char                                      UnknownData00[0x2];                                       // 0x0002(0x0002) MISSED OFFSET
	float                                              MinValue_69;                                              // 0x0004(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              MaxValue_69;                                              // 0x0008(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bDrawLimits_69;                                           // 0x000C(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x3];                                       // 0x000D(0x0003) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_HierarchyAddControlFloat_Settings
// 0x00C0 (0x00D0 - 0x0010)
struct FRigUnit_HierarchyAddControlFloat_Settings : public FRigUnit_HierarchyAddControl_Settings
{
	ERigControlAxis                                    PrimaryAxis_69;                                           // 0x0010(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0011(0x0003) MISSED OFFSET
	struct FRigUnit_HierarchyAddControlFloat_LimitSettings Limits_69;                                                // 0x0014(0x0010) (Edit, BlueprintVisible)
	unsigned char                                      UnknownData01[0xC];                                       // 0x0024(0x000C) MISSED OFFSET
	struct FRigUnit_HierarchyAddControl_ShapeSettings  Shape_69;                                                 // 0x0030(0x0080) (Edit, BlueprintVisible)
	struct FRigUnit_HierarchyAddControl_ProxySettings  Proxy_69;                                                 // 0x00B0(0x0020) (Edit, BlueprintVisible)
};

// ScriptStruct ControlRig.RigUnit_HierarchyAddControlFloat
// 0x0140 (0x0190 - 0x0050)
struct FRigUnit_HierarchyAddControlFloat : public FRigUnit_HierarchyAddElement
{
	struct FCoreUObject_FTransform                     OffsetTransform_69;                                       // 0x0050(0x0060) (Edit, BlueprintVisible, IsPlainOldData)
	float                                              InitialValue_69;                                          // 0x00B0(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0xC];                                       // 0x00B4(0x000C) MISSED OFFSET
	struct FRigUnit_HierarchyAddControlFloat_Settings  Settings_69;                                              // 0x00C0(0x00D0) (Edit, BlueprintVisible)
};

// ScriptStruct ControlRig.RigUnit_HierarchyAddControlInteger_LimitSettings
// 0x0010
struct FRigUnit_HierarchyAddControlInteger_LimitSettings
{
	struct FRigControlLimitEnabled                     Limit_69;                                                 // 0x0000(0x0002) (Edit, BlueprintVisible)
	unsigned char                                      UnknownData00[0x2];                                       // 0x0002(0x0002) MISSED OFFSET
	int                                                MinValue_69;                                              // 0x0004(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                MaxValue_69;                                              // 0x0008(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bDrawLimits_69;                                           // 0x000C(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x3];                                       // 0x000D(0x0003) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_HierarchyAddControlInteger_Settings
// 0x00C0 (0x00D0 - 0x0010)
struct FRigUnit_HierarchyAddControlInteger_Settings : public FRigUnit_HierarchyAddControl_Settings
{
	ERigControlAxis                                    PrimaryAxis_69;                                           // 0x0010(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0011(0x0003) MISSED OFFSET
	struct FRigUnit_HierarchyAddControlInteger_LimitSettings Limits_69;                                                // 0x0014(0x0010) (Edit, BlueprintVisible)
	unsigned char                                      UnknownData01[0xC];                                       // 0x0024(0x000C) MISSED OFFSET
	struct FRigUnit_HierarchyAddControl_ShapeSettings  Shape_69;                                                 // 0x0030(0x0080) (Edit, BlueprintVisible)
	struct FRigUnit_HierarchyAddControl_ProxySettings  Proxy_69;                                                 // 0x00B0(0x0020) (Edit, BlueprintVisible)
};

// ScriptStruct ControlRig.RigUnit_HierarchyAddControlInteger
// 0x0140 (0x0190 - 0x0050)
struct FRigUnit_HierarchyAddControlInteger : public FRigUnit_HierarchyAddElement
{
	struct FCoreUObject_FTransform                     OffsetTransform_69;                                       // 0x0050(0x0060) (Edit, BlueprintVisible, IsPlainOldData)
	int                                                InitialValue_69;                                          // 0x00B0(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0xC];                                       // 0x00B4(0x000C) MISSED OFFSET
	struct FRigUnit_HierarchyAddControlInteger_Settings Settings_69;                                              // 0x00C0(0x00D0) (Edit, BlueprintVisible)
};

// ScriptStruct ControlRig.RigUnit_HierarchyAddControlVector2D_LimitSettings
// 0x0030
struct FRigUnit_HierarchyAddControlVector2D_LimitSettings
{
	struct FRigControlLimitEnabled                     LimitX_69;                                                // 0x0000(0x0002) (Edit, BlueprintVisible)
	struct FRigControlLimitEnabled                     LimitY_69;                                                // 0x0002(0x0002) (Edit, BlueprintVisible)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0004(0x0004) MISSED OFFSET
	struct FVector2D                                   MinValue_69;                                              // 0x0008(0x0010) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FVector2D                                   MaxValue_69;                                              // 0x0018(0x0010) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bDrawLimits_69;                                           // 0x0028(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x7];                                       // 0x0029(0x0007) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_HierarchyAddControlVector2D_Settings
// 0x00E0 (0x00F0 - 0x0010)
struct FRigUnit_HierarchyAddControlVector2D_Settings : public FRigUnit_HierarchyAddControl_Settings
{
	ERigControlAxis                                    PrimaryAxis_69;                                           // 0x0010(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0011(0x0007) MISSED OFFSET
	struct FRigUnit_HierarchyAddControlVector2D_LimitSettings Limits_69;                                                // 0x0018(0x0030) (Edit, BlueprintVisible)
	unsigned char                                      UnknownData01[0x8];                                       // 0x0048(0x0008) MISSED OFFSET
	struct FRigUnit_HierarchyAddControl_ShapeSettings  Shape_69;                                                 // 0x0050(0x0080) (Edit, BlueprintVisible)
	struct FRigUnit_HierarchyAddControl_ProxySettings  Proxy_69;                                                 // 0x00D0(0x0020) (Edit, BlueprintVisible)
};

// ScriptStruct ControlRig.RigUnit_HierarchyAddControlVector2D
// 0x0160 (0x01B0 - 0x0050)
struct FRigUnit_HierarchyAddControlVector2D : public FRigUnit_HierarchyAddElement
{
	struct FCoreUObject_FTransform                     OffsetTransform_69;                                       // 0x0050(0x0060) (Edit, BlueprintVisible, IsPlainOldData)
	struct FVector2D                                   InitialValue_69;                                          // 0x00B0(0x0010) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FRigUnit_HierarchyAddControlVector2D_Settings Settings_69;                                              // 0x00C0(0x00F0) (Edit, BlueprintVisible)
};

// ScriptStruct ControlRig.RigUnit_HierarchyAddControlVector_LimitSettings
// 0x0040
struct FRigUnit_HierarchyAddControlVector_LimitSettings
{
	struct FRigControlLimitEnabled                     LimitX_69;                                                // 0x0000(0x0002) (Edit, BlueprintVisible)
	struct FRigControlLimitEnabled                     LimitY_69;                                                // 0x0002(0x0002) (Edit, BlueprintVisible)
	struct FRigControlLimitEnabled                     LimitZ_69;                                                // 0x0004(0x0002) (Edit, BlueprintVisible)
	unsigned char                                      UnknownData00[0x2];                                       // 0x0006(0x0002) MISSED OFFSET
	struct FVector                                     MinValue_69;                                              // 0x0008(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FVector                                     MaxValue_69;                                              // 0x0020(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bDrawLimits_69;                                           // 0x0038(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x7];                                       // 0x0039(0x0007) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_HierarchyAddControlVector_Settings
// 0x00F0 (0x0100 - 0x0010)
struct FRigUnit_HierarchyAddControlVector_Settings : public FRigUnit_HierarchyAddControl_Settings
{
	bool                                               bIsPosition_69;                                           // 0x0010(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0011(0x0007) MISSED OFFSET
	struct FRigUnit_HierarchyAddControlVector_LimitSettings Limits_69;                                                // 0x0018(0x0040) (Edit, BlueprintVisible)
	unsigned char                                      UnknownData01[0x8];                                       // 0x0058(0x0008) MISSED OFFSET
	struct FRigUnit_HierarchyAddControl_ShapeSettings  Shape_69;                                                 // 0x0060(0x0080) (Edit, BlueprintVisible)
	struct FRigUnit_HierarchyAddControl_ProxySettings  Proxy_69;                                                 // 0x00E0(0x0020) (Edit, BlueprintVisible)
};

// ScriptStruct ControlRig.RigUnit_HierarchyAddControlVector
// 0x0180 (0x01D0 - 0x0050)
struct FRigUnit_HierarchyAddControlVector : public FRigUnit_HierarchyAddElement
{
	struct FCoreUObject_FTransform                     OffsetTransform_69;                                       // 0x0050(0x0060) (Edit, BlueprintVisible, IsPlainOldData)
	struct FVector                                     InitialValue_69;                                          // 0x00B0(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x8];                                       // 0x00C8(0x0008) MISSED OFFSET
	struct FRigUnit_HierarchyAddControlVector_Settings Settings_69;                                              // 0x00D0(0x0100) (Edit, BlueprintVisible)
};

// ScriptStruct ControlRig.RigUnit_HierarchyAddControlRotator_LimitSettings
// 0x0040
struct FRigUnit_HierarchyAddControlRotator_LimitSettings
{
	struct FRigControlLimitEnabled                     LimitPitch_69;                                            // 0x0000(0x0002) (Edit, BlueprintVisible)
	struct FRigControlLimitEnabled                     LimitYaw_69;                                              // 0x0002(0x0002) (Edit, BlueprintVisible)
	struct FRigControlLimitEnabled                     LimitRoll_69;                                             // 0x0004(0x0002) (Edit, BlueprintVisible)
	unsigned char                                      UnknownData00[0x2];                                       // 0x0006(0x0002) MISSED OFFSET
	struct FRotator                                    MinValue_69;                                              // 0x0008(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FRotator                                    MaxValue_69;                                              // 0x0020(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bDrawLimits_69;                                           // 0x0038(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x7];                                       // 0x0039(0x0007) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_HierarchyAddControlRotator_Settings
// 0x00E0 (0x00F0 - 0x0010)
struct FRigUnit_HierarchyAddControlRotator_Settings : public FRigUnit_HierarchyAddControl_Settings
{
	struct FRigUnit_HierarchyAddControlRotator_LimitSettings Limits_69;                                                // 0x0010(0x0040) (Edit, BlueprintVisible)
	struct FRigUnit_HierarchyAddControl_ShapeSettings  Shape_69;                                                 // 0x0050(0x0080) (Edit, BlueprintVisible)
	struct FRigUnit_HierarchyAddControl_ProxySettings  Proxy_69;                                                 // 0x00D0(0x0020) (Edit, BlueprintVisible)
};

// ScriptStruct ControlRig.RigUnit_HierarchyAddControlRotator
// 0x0170 (0x01C0 - 0x0050)
struct FRigUnit_HierarchyAddControlRotator : public FRigUnit_HierarchyAddElement
{
	struct FCoreUObject_FTransform                     OffsetTransform_69;                                       // 0x0050(0x0060) (Edit, BlueprintVisible, IsPlainOldData)
	struct FRotator                                    InitialValue_69;                                          // 0x00B0(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x8];                                       // 0x00C8(0x0008) MISSED OFFSET
	struct FRigUnit_HierarchyAddControlRotator_Settings Settings_69;                                              // 0x00D0(0x00F0) (Edit, BlueprintVisible)
};

// ScriptStruct ControlRig.RigUnit_HierarchyAddControlTransform_Settings
// 0x00A0 (0x00B0 - 0x0010)
struct FRigUnit_HierarchyAddControlTransform_Settings : public FRigUnit_HierarchyAddControl_Settings
{
	struct FRigUnit_HierarchyAddControl_ShapeSettings  Shape_69;                                                 // 0x0010(0x0080) (Edit, BlueprintVisible)
	struct FRigUnit_HierarchyAddControl_ProxySettings  Proxy_69;                                                 // 0x0090(0x0020) (Edit, BlueprintVisible)
};

// ScriptStruct ControlRig.RigUnit_HierarchyAddControlTransform
// 0x0170 (0x01C0 - 0x0050)
struct FRigUnit_HierarchyAddControlTransform : public FRigUnit_HierarchyAddElement
{
	struct FCoreUObject_FTransform                     OffsetTransform_69;                                       // 0x0050(0x0060) (Edit, BlueprintVisible, IsPlainOldData)
	struct FCoreUObject_FTransform                     InitialValue_69;                                          // 0x00B0(0x0060) (Edit, BlueprintVisible, IsPlainOldData)
	struct FRigUnit_HierarchyAddControlTransform_Settings Settings_69;                                              // 0x0110(0x00B0) (Edit, BlueprintVisible)
};

// ScriptStruct ControlRig.RigUnit_HierarchyAddAnimationChannelBool
// 0x0008 (0x0058 - 0x0050)
struct FRigUnit_HierarchyAddAnimationChannelBool : public FRigUnit_HierarchyAddElement
{
	bool                                               InitialValue_69;                                          // 0x0050(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               MinimumValue_69;                                          // 0x0051(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               MaximumValue_69;                                          // 0x0052(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x5];                                       // 0x0053(0x0005) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_HierarchyAddAnimationChannelFloat
// 0x0010 (0x0060 - 0x0050)
struct FRigUnit_HierarchyAddAnimationChannelFloat : public FRigUnit_HierarchyAddElement
{
	float                                              InitialValue_69;                                          // 0x0050(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              MinimumValue_69;                                          // 0x0054(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              MaximumValue_69;                                          // 0x0058(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x005C(0x0004) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_HierarchyAddAnimationChannelInteger
// 0x0010 (0x0060 - 0x0050)
struct FRigUnit_HierarchyAddAnimationChannelInteger : public FRigUnit_HierarchyAddElement
{
	int                                                InitialValue_69;                                          // 0x0050(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                MinimumValue_69;                                          // 0x0054(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                MaximumValue_69;                                          // 0x0058(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x005C(0x0004) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_HierarchyAddAnimationChannelVector2D
// 0x0030 (0x0080 - 0x0050)
struct FRigUnit_HierarchyAddAnimationChannelVector2D : public FRigUnit_HierarchyAddElement
{
	struct FVector2D                                   InitialValue_69;                                          // 0x0050(0x0010) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FVector2D                                   MinimumValue_69;                                          // 0x0060(0x0010) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FVector2D                                   MaximumValue_69;                                          // 0x0070(0x0010) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_HierarchyAddAnimationChannelVector
// 0x0048 (0x0098 - 0x0050)
struct FRigUnit_HierarchyAddAnimationChannelVector : public FRigUnit_HierarchyAddElement
{
	struct FVector                                     InitialValue_69;                                          // 0x0050(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FVector                                     MinimumValue_69;                                          // 0x0068(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FVector                                     MaximumValue_69;                                          // 0x0080(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_HierarchyAddAnimationChannelRotator
// 0x0048 (0x0098 - 0x0050)
struct FRigUnit_HierarchyAddAnimationChannelRotator : public FRigUnit_HierarchyAddElement
{
	struct FRotator                                    InitialValue_69;                                          // 0x0050(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FRotator                                    MinimumValue_69;                                          // 0x0068(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FRotator                                    MaximumValue_69;                                          // 0x0080(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_ForLoopCount
// 0x0040 (0x0078 - 0x0038)
struct FRigUnit_ForLoopCount : public FRigUnitMutable
{
	int                                                Count_69;                                                 // 0x0038(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                Index_69;                                                 // 0x003C(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              Ratio_69;                                                 // 0x0040(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	bool                                               Continue_69;                                              // 0x0044(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0045(0x0003) MISSED OFFSET
	struct FControlRigExecuteContext                   Completed_69;                                             // 0x0048(0x0030) (Edit, BlueprintVisible, BlueprintReadOnly, Transient)
};

// ScriptStruct ControlRig.RigUnit_HierarchyBase
// 0x0000 (0x0008 - 0x0008)
struct FRigUnit_HierarchyBase : public FRigUnit
{

};

// ScriptStruct ControlRig.RigUnit_HierarchyBaseMutable
// 0x0000 (0x0038 - 0x0038)
struct FRigUnit_HierarchyBaseMutable : public FRigUnitMutable
{

};

// ScriptStruct ControlRig.RigUnit_HierarchyGetParent
// 0x0040 (0x0048 - 0x0008)
struct FRigUnit_HierarchyGetParent : public FRigUnit_HierarchyBase
{
	struct FRigElementKey                              Child_69;                                                 // 0x0008(0x0008) (Edit, BlueprintVisible)
	struct FRigElementKey                              Parent_69;                                                // 0x0010(0x0008) (BlueprintVisible, BlueprintReadOnly)
	struct FCachedRigElement                           CachedChild_69;                                           // 0x0018(0x0018)
	struct FCachedRigElement                           CachedParent_69;                                          // 0x0030(0x0018)
};

// ScriptStruct ControlRig.RigUnit_HierarchyGetParents
// 0x0048 (0x0050 - 0x0008)
struct FRigUnit_HierarchyGetParents : public FRigUnit_HierarchyBase
{
	struct FRigElementKey                              Child_69;                                                 // 0x0008(0x0008) (Edit, BlueprintVisible)
	bool                                               bIncludeChild_69;                                         // 0x0010(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bReverse_69;                                              // 0x0011(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x6];                                       // 0x0012(0x0006) MISSED OFFSET
	struct FRigElementKeyCollection                    Parents_69;                                               // 0x0018(0x0010) (BlueprintVisible, BlueprintReadOnly)
	struct FCachedRigElement                           CachedChild_69;                                           // 0x0028(0x0018)
	struct FRigElementKeyCollection                    CachedParents_69;                                         // 0x0040(0x0010)
};

// ScriptStruct ControlRig.RigUnit_HierarchyGetParentsItemArray
// 0x0048 (0x0050 - 0x0008)
struct FRigUnit_HierarchyGetParentsItemArray : public FRigUnit_HierarchyBase
{
	struct FRigElementKey                              Child_69;                                                 // 0x0008(0x0008) (Edit, BlueprintVisible)
	bool                                               bIncludeChild_69;                                         // 0x0010(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bReverse_69;                                              // 0x0011(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x6];                                       // 0x0012(0x0006) MISSED OFFSET
	TArray<struct FRigElementKey>                      Parents_69;                                               // 0x0018(0x0010) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
	struct FCachedRigElement                           CachedChild_69;                                           // 0x0028(0x0018)
	struct FRigElementKeyCollection                    CachedParents_69;                                         // 0x0040(0x0010)
};

// ScriptStruct ControlRig.RigUnit_HierarchyGetChildren
// 0x0048 (0x0050 - 0x0008)
struct FRigUnit_HierarchyGetChildren : public FRigUnit_HierarchyBase
{
	struct FRigElementKey                              Parent_69;                                                // 0x0008(0x0008) (Edit, BlueprintVisible)
	bool                                               bIncludeParent_69;                                        // 0x0010(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bRecursive_69;                                            // 0x0011(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x6];                                       // 0x0012(0x0006) MISSED OFFSET
	struct FRigElementKeyCollection                    Children_69;                                              // 0x0018(0x0010) (BlueprintVisible, BlueprintReadOnly)
	struct FCachedRigElement                           CachedParent_69;                                          // 0x0028(0x0018)
	struct FRigElementKeyCollection                    CachedChildren_69;                                        // 0x0040(0x0010)
};

// ScriptStruct ControlRig.RigUnit_HierarchyGetSiblings
// 0x0048 (0x0050 - 0x0008)
struct FRigUnit_HierarchyGetSiblings : public FRigUnit_HierarchyBase
{
	struct FRigElementKey                              Item_69;                                                  // 0x0008(0x0008) (Edit, BlueprintVisible)
	bool                                               bIncludeItem_69;                                          // 0x0010(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0011(0x0007) MISSED OFFSET
	struct FRigElementKeyCollection                    Siblings_69;                                              // 0x0018(0x0010) (BlueprintVisible, BlueprintReadOnly)
	struct FCachedRigElement                           CachedItem_69;                                            // 0x0028(0x0018)
	struct FRigElementKeyCollection                    CachedSiblings_69;                                        // 0x0040(0x0010)
};

// ScriptStruct ControlRig.RigUnit_HierarchyGetSiblingsItemArray
// 0x0048 (0x0050 - 0x0008)
struct FRigUnit_HierarchyGetSiblingsItemArray : public FRigUnit_HierarchyBase
{
	struct FRigElementKey                              Item_69;                                                  // 0x0008(0x0008) (Edit, BlueprintVisible)
	bool                                               bIncludeItem_69;                                          // 0x0010(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0011(0x0007) MISSED OFFSET
	TArray<struct FRigElementKey>                      Siblings_69;                                              // 0x0018(0x0010) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
	struct FCachedRigElement                           CachedItem_69;                                            // 0x0028(0x0018)
	struct FRigElementKeyCollection                    CachedSiblings_69;                                        // 0x0040(0x0010)
};

// ScriptStruct ControlRig.RigUnit_HierarchyGetPose
// 0x0088 (0x0090 - 0x0008)
struct FRigUnit_HierarchyGetPose : public FRigUnit_HierarchyBase
{
	bool                                               Initial_69;                                               // 0x0008(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	ERigElementType                                    ElementType_69;                                           // 0x0009(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x6];                                       // 0x000A(0x0006) MISSED OFFSET
	struct FRigElementKeyCollection                    ItemsToGet_69;                                            // 0x0010(0x0010) (Edit, BlueprintVisible)
	struct FRigPose                                    Pose_69;                                                  // 0x0020(0x0070) (BlueprintVisible, BlueprintReadOnly)
};

// ScriptStruct ControlRig.RigUnit_HierarchyGetPoseItemArray
// 0x0088 (0x0090 - 0x0008)
struct FRigUnit_HierarchyGetPoseItemArray : public FRigUnit_HierarchyBase
{
	bool                                               Initial_69;                                               // 0x0008(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	ERigElementType                                    ElementType_69;                                           // 0x0009(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x6];                                       // 0x000A(0x0006) MISSED OFFSET
	TArray<struct FRigElementKey>                      ItemsToGet_69;                                            // 0x0010(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FRigPose                                    Pose_69;                                                  // 0x0020(0x0070) (BlueprintVisible, BlueprintReadOnly)
};

// ScriptStruct ControlRig.RigUnit_HierarchySetPose
// 0x0090 (0x00C8 - 0x0038)
struct FRigUnit_HierarchySetPose : public FRigUnit_HierarchyBaseMutable
{
	struct FRigPose                                    Pose_69;                                                  // 0x0038(0x0070) (Edit, BlueprintVisible)
	ERigElementType                                    ElementType_69;                                           // 0x00A8(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	EBoneGetterSetterMode                              Space_69;                                                 // 0x00A9(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x6];                                       // 0x00AA(0x0006) MISSED OFFSET
	struct FRigElementKeyCollection                    ItemsToSet_69;                                            // 0x00B0(0x0010) (Edit, BlueprintVisible)
	float                                              Weight_69;                                                // 0x00C0(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x4];                                       // 0x00C4(0x0004) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_HierarchySetPoseItemArray
// 0x0090 (0x00C8 - 0x0038)
struct FRigUnit_HierarchySetPoseItemArray : public FRigUnit_HierarchyBaseMutable
{
	struct FRigPose                                    Pose_69;                                                  // 0x0038(0x0070) (Edit, BlueprintVisible)
	ERigElementType                                    ElementType_69;                                           // 0x00A8(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	EBoneGetterSetterMode                              Space_69;                                                 // 0x00A9(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x6];                                       // 0x00AA(0x0006) MISSED OFFSET
	TArray<struct FRigElementKey>                      ItemsToSet_69;                                            // 0x00B0(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	float                                              Weight_69;                                                // 0x00C0(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x4];                                       // 0x00C4(0x0004) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_PoseIsEmpty
// 0x0078 (0x0080 - 0x0008)
struct FRigUnit_PoseIsEmpty : public FRigUnit_HierarchyBase
{
	struct FRigPose                                    Pose_69;                                                  // 0x0008(0x0070) (Edit, BlueprintVisible)
	bool                                               IsEmpty_69;                                               // 0x0078(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0079(0x0007) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_PoseGetItems
// 0x0088 (0x0090 - 0x0008)
struct FRigUnit_PoseGetItems : public FRigUnit_HierarchyBase
{
	struct FRigPose                                    Pose_69;                                                  // 0x0008(0x0070) (Edit, BlueprintVisible)
	ERigElementType                                    ElementType_69;                                           // 0x0078(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0079(0x0007) MISSED OFFSET
	struct FRigElementKeyCollection                    Items_69;                                                 // 0x0080(0x0010) (BlueprintVisible, BlueprintReadOnly)
};

// ScriptStruct ControlRig.RigUnit_PoseGetItemsItemArray
// 0x0088 (0x0090 - 0x0008)
struct FRigUnit_PoseGetItemsItemArray : public FRigUnit_HierarchyBase
{
	struct FRigPose                                    Pose_69;                                                  // 0x0008(0x0070) (Edit, BlueprintVisible)
	ERigElementType                                    ElementType_69;                                           // 0x0078(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0079(0x0007) MISSED OFFSET
	TArray<struct FRigElementKey>                      Items_69;                                                 // 0x0080(0x0010) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
};

// ScriptStruct ControlRig.RigUnit_PoseGetDelta
// 0x0120 (0x0128 - 0x0008)
struct FRigUnit_PoseGetDelta : public FRigUnit_HierarchyBase
{
	struct FRigPose                                    PoseA_69;                                                 // 0x0008(0x0070) (Edit, BlueprintVisible)
	struct FRigPose                                    PoseB_69;                                                 // 0x0078(0x0070) (Edit, BlueprintVisible)
	float                                              PositionThreshold_69;                                     // 0x00E8(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              RotationThreshold_69;                                     // 0x00EC(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              ScaleThreshold_69;                                        // 0x00F0(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              CurveThreshold_69;                                        // 0x00F4(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	ERigElementType                                    ElementType_69;                                           // 0x00F8(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	EBoneGetterSetterMode                              Space_69;                                                 // 0x00F9(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x6];                                       // 0x00FA(0x0006) MISSED OFFSET
	struct FRigElementKeyCollection                    ItemsToCompare_69;                                        // 0x0100(0x0010) (Edit, BlueprintVisible)
	bool                                               PosesAreEqual_69;                                         // 0x0110(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x7];                                       // 0x0111(0x0007) MISSED OFFSET
	struct FRigElementKeyCollection                    ItemsWithDelta_69;                                        // 0x0118(0x0010) (BlueprintVisible, BlueprintReadOnly)
};

// ScriptStruct ControlRig.RigUnit_PoseGetTransform
// 0x00F8 (0x0100 - 0x0008)
struct FRigUnit_PoseGetTransform : public FRigUnit_HierarchyBase
{
	struct FRigPose                                    Pose_69;                                                  // 0x0008(0x0070) (Edit, BlueprintVisible)
	struct FRigElementKey                              Item_69;                                                  // 0x0078(0x0008) (Edit, BlueprintVisible)
	EBoneGetterSetterMode                              Space_69;                                                 // 0x0080(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               Valid_69;                                                 // 0x0081(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0xE];                                       // 0x0082(0x000E) MISSED OFFSET
	struct FCoreUObject_FTransform                     Transform_69;                                             // 0x0090(0x0060) (BlueprintVisible, BlueprintReadOnly, IsPlainOldData)
	float                                              CurveValue_69;                                            // 0x00F0(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                CachedPoseElementIndex_69;                                // 0x00F4(0x0004) (ZeroConstructor, IsPlainOldData)
	int                                                CachedPoseHash_69;                                        // 0x00F8(0x0004) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x4];                                       // 0x00FC(0x0004) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_PoseGetTransformArray
// 0x0088 (0x0090 - 0x0008)
struct FRigUnit_PoseGetTransformArray : public FRigUnit_HierarchyBase
{
	struct FRigPose                                    Pose_69;                                                  // 0x0008(0x0070) (Edit, BlueprintVisible)
	EBoneGetterSetterMode                              Space_69;                                                 // 0x0078(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               Valid_69;                                                 // 0x0079(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x6];                                       // 0x007A(0x0006) MISSED OFFSET
	TArray<struct FCoreUObject_FTransform>             Transforms_69;                                            // 0x0080(0x0010) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
};

// ScriptStruct ControlRig.RigUnit_PoseGetCurve
// 0x0088 (0x0090 - 0x0008)
struct FRigUnit_PoseGetCurve : public FRigUnit_HierarchyBase
{
	struct FRigPose                                    Pose_69;                                                  // 0x0008(0x0070) (Edit, BlueprintVisible)
	struct FName                                       Curve_69;                                                 // 0x0078(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               Valid_69;                                                 // 0x007C(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x007D(0x0003) MISSED OFFSET
	float                                              CurveValue_69;                                            // 0x0080(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                CachedPoseElementIndex_69;                                // 0x0084(0x0004) (ZeroConstructor, IsPlainOldData)
	int                                                CachedPoseHash_69;                                        // 0x0088(0x0004) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x4];                                       // 0x008C(0x0004) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_PoseLoop
// 0x0188 (0x01C0 - 0x0038)
struct FRigUnit_PoseLoop : public FRigUnit_HierarchyBaseMutable
{
	struct FRigPose                                    Pose_69;                                                  // 0x0038(0x0070) (Edit, BlueprintVisible)
	struct FRigElementKey                              Item_69;                                                  // 0x00A8(0x0008) (BlueprintVisible, BlueprintReadOnly)
	struct FCoreUObject_FTransform                     GlobalTransform_69;                                       // 0x00B0(0x0060) (BlueprintVisible, BlueprintReadOnly, IsPlainOldData)
	struct FCoreUObject_FTransform                     LocalTransform_69;                                        // 0x0110(0x0060) (BlueprintVisible, BlueprintReadOnly, IsPlainOldData)
	float                                              CurveValue_69;                                            // 0x0170(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                Index_69;                                                 // 0x0174(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                Count_69;                                                 // 0x0178(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              Ratio_69;                                                 // 0x017C(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	bool                                               Continue_69;                                              // 0x0180(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0181(0x0007) MISSED OFFSET
	struct FControlRigExecuteContext                   Completed_69;                                             // 0x0188(0x0030) (BlueprintVisible, BlueprintReadOnly)
	unsigned char                                      UnknownData01[0x8];                                       // 0x01B8(0x0008) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_InteractionExecution
// 0x0030 (0x0038 - 0x0008)
struct FRigUnit_InteractionExecution : public FRigUnit
{
	struct FControlRigExecuteContext                   ExecuteContext_69;                                        // 0x0008(0x0030) (Edit, BlueprintVisible, BlueprintReadOnly, Transient)
};

// ScriptStruct ControlRig.RigUnit_InverseExecution
// 0x0030 (0x0038 - 0x0008)
struct FRigUnit_InverseExecution : public FRigUnit
{
	struct FControlRigExecuteContext                   ExecuteContext_69;                                        // 0x0008(0x0030) (Edit, BlueprintVisible, BlueprintReadOnly, Transient)
};

// ScriptStruct ControlRig.RigUnit_IsInteracting
// 0x0018 (0x0020 - 0x0008)
struct FRigUnit_IsInteracting : public FRigUnit
{
	bool                                               bIsInteracting_69;                                        // 0x0008(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, Transient, IsPlainOldData)
	bool                                               bIsTranslating_69;                                        // 0x0009(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, Transient, IsPlainOldData)
	bool                                               bIsRotating_69;                                           // 0x000A(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, Transient, IsPlainOldData)
	bool                                               bIsScaling_69;                                            // 0x000B(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, Transient, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x000C(0x0004) MISSED OFFSET
	TArray<struct FRigElementKey>                      Items_69;                                                 // 0x0010(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, Transient)
};

// ScriptStruct ControlRig.RigUnit_ItemBase
// 0x0000 (0x0008 - 0x0008)
struct FRigUnit_ItemBase : public FRigUnit
{

};

// ScriptStruct ControlRig.RigUnit_ItemBaseMutable
// 0x0000 (0x0038 - 0x0038)
struct FRigUnit_ItemBaseMutable : public FRigUnitMutable
{

};

// ScriptStruct ControlRig.RigUnit_ItemExists
// 0x0028 (0x0030 - 0x0008)
struct FRigUnit_ItemExists : public FRigUnit_ItemBase
{
	struct FRigElementKey                              Item_69;                                                  // 0x0008(0x0008) (Edit, BlueprintVisible)
	bool                                               Exists_69;                                                // 0x0010(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0011(0x0007) MISSED OFFSET
	struct FCachedRigElement                           CachedIndex_69;                                           // 0x0018(0x0018)
};

// ScriptStruct ControlRig.RigUnit_ItemReplace
// 0x0018 (0x0020 - 0x0008)
struct FRigUnit_ItemReplace : public FRigUnit_ItemBase
{
	struct FRigElementKey                              Item_69;                                                  // 0x0008(0x0008) (Edit, BlueprintVisible)
	struct FName                                       Old_69;                                                   // 0x0010(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FName                                       New_69;                                                   // 0x0014(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FRigElementKey                              Result_69;                                                // 0x0018(0x0008) (BlueprintVisible, BlueprintReadOnly)
};

// ScriptStruct ControlRig.RigUnit_ItemEquals
// 0x0018 (0x0020 - 0x0008)
struct FRigUnit_ItemEquals : public FRigUnit_ItemBase
{
	struct FRigElementKey                              A_69;                                                     // 0x0008(0x0008) (Edit, BlueprintVisible)
	struct FRigElementKey                              B_69;                                                     // 0x0010(0x0008) (Edit, BlueprintVisible)
	bool                                               Result_69;                                                // 0x0018(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0019(0x0007) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_ItemNotEquals
// 0x0018 (0x0020 - 0x0008)
struct FRigUnit_ItemNotEquals : public FRigUnit_ItemBase
{
	struct FRigElementKey                              A_69;                                                     // 0x0008(0x0008) (Edit, BlueprintVisible)
	struct FRigElementKey                              B_69;                                                     // 0x0010(0x0008) (Edit, BlueprintVisible)
	bool                                               Result_69;                                                // 0x0018(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0019(0x0007) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_ItemTypeEquals
// 0x0018 (0x0020 - 0x0008)
struct FRigUnit_ItemTypeEquals : public FRigUnit_ItemBase
{
	struct FRigElementKey                              A_69;                                                     // 0x0008(0x0008) (Edit, BlueprintVisible)
	struct FRigElementKey                              B_69;                                                     // 0x0010(0x0008) (Edit, BlueprintVisible)
	bool                                               Result_69;                                                // 0x0018(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0019(0x0007) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_ItemTypeNotEquals
// 0x0018 (0x0020 - 0x0008)
struct FRigUnit_ItemTypeNotEquals : public FRigUnit_ItemBase
{
	struct FRigElementKey                              A_69;                                                     // 0x0008(0x0008) (Edit, BlueprintVisible)
	struct FRigElementKey                              B_69;                                                     // 0x0010(0x0008) (Edit, BlueprintVisible)
	bool                                               Result_69;                                                // 0x0018(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0019(0x0007) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_PrepareForExecution
// 0x0030 (0x0038 - 0x0008)
struct FRigUnit_PrepareForExecution : public FRigUnit
{
	struct FControlRigExecuteContext                   ExecuteContext_69;                                        // 0x0008(0x0030) (Edit, BlueprintVisible, BlueprintReadOnly, Transient)
};

// ScriptStruct ControlRig.RigUnit_SequenceExecution
// 0x00F0 (0x00F8 - 0x0008)
struct FRigUnit_SequenceExecution : public FRigUnit
{
	struct FControlRigExecuteContext                   ExecuteContext_69;                                        // 0x0008(0x0030) (Edit, BlueprintVisible, Transient)
	struct FControlRigExecuteContext                   A_69;                                                     // 0x0038(0x0030) (Edit, BlueprintVisible, BlueprintReadOnly, Transient)
	struct FControlRigExecuteContext                   B_69;                                                     // 0x0068(0x0030) (Edit, BlueprintVisible, BlueprintReadOnly, Transient)
	struct FControlRigExecuteContext                   C_69;                                                     // 0x0098(0x0030) (Edit, BlueprintVisible, BlueprintReadOnly, Transient)
	struct FControlRigExecuteContext                   D_69;                                                     // 0x00C8(0x0030) (Edit, BlueprintVisible, BlueprintReadOnly, Transient)
};

// ScriptStruct ControlRig.RigUnit_SequenceAggregate
// 0x0090 (0x0098 - 0x0008)
struct FRigUnit_SequenceAggregate : public FRigUnit
{
	struct FControlRigExecuteContext                   ExecuteContext_69;                                        // 0x0008(0x0030) (Edit, BlueprintVisible, Transient)
	struct FControlRigExecuteContext                   A_69;                                                     // 0x0038(0x0030) (Edit, BlueprintVisible, BlueprintReadOnly, Transient)
	struct FControlRigExecuteContext                   B_69;                                                     // 0x0068(0x0030) (Edit, BlueprintVisible, BlueprintReadOnly, Transient)
};

// ScriptStruct ControlRig.RigUnit_UserDefinedEvent
// 0x0038 (0x0040 - 0x0008)
struct FRigUnit_UserDefinedEvent : public FRigUnit
{
	struct FControlRigExecuteContext                   ExecuteContext_69;                                        // 0x0008(0x0030) (Edit, BlueprintVisible, BlueprintReadOnly, Transient)
	struct FName                                       EventName_69;                                             // 0x0038(0x0008) (Edit, BlueprintVisible, ZeroConstructor, Transient, EditConst, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x003C(0x0004) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_AddBoneTransform
// 0x0088 (0x00C0 - 0x0038)
struct FRigUnit_AddBoneTransform : public FRigUnitMutable
{
	struct FName                                       bone_69;                                                  // 0x0038(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x003C(0x0004) MISSED OFFSET
	struct FCoreUObject_FTransform                     Transform_69;                                             // 0x0040(0x0060) (Edit, BlueprintVisible, IsPlainOldData)
	float                                              Weight_69;                                                // 0x00A0(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bPostMultiply_69;                                         // 0x00A4(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bPropagateToChildren_69;                                  // 0x00A5(0x0001) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	unsigned char                                      UnknownData01[0x2];                                       // 0x00A6(0x0002) MISSED OFFSET
	struct FCachedRigElement                           CachedBone_69;                                            // 0x00A8(0x0018) (Transient)
};

// ScriptStruct ControlRig.RigUnit_Item
// 0x0008 (0x0010 - 0x0008)
struct FRigUnit_Item : public FRigUnit
{
	struct FRigElementKey                              Item_69;                                                  // 0x0008(0x0008) (Edit, BlueprintVisible)
};

// ScriptStruct ControlRig.RigUnit_BoneName
// 0x0008 (0x0010 - 0x0008)
struct FRigUnit_BoneName : public FRigUnit
{
	struct FName                                       bone_69;                                                  // 0x0008(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x000C(0x0004) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_SpaceName
// 0x0008 (0x0010 - 0x0008)
struct FRigUnit_SpaceName : public FRigUnit
{
	struct FName                                       Space_69;                                                 // 0x0008(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x000C(0x0004) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_ControlName
// 0x0008 (0x0010 - 0x0008)
struct FRigUnit_ControlName : public FRigUnit
{
	struct FName                                       Control_69;                                               // 0x0008(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x000C(0x0004) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_GetAnimationChannelBase
// 0x0018 (0x0020 - 0x0008)
struct FRigUnit_GetAnimationChannelBase : public FRigUnit
{
	struct FName                                       Control_69;                                               // 0x0008(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FName                                       Channel_69;                                               // 0x000C(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bInitial_69;                                              // 0x0010(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0011(0x0003) MISSED OFFSET
	struct FRigElementKey                              CachedChannelKey_69;                                      // 0x0014(0x0008)
	int                                                CachedChannelHash_69;                                     // 0x001C(0x0004) (ZeroConstructor, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_GetBoolAnimationChannel
// 0x0008 (0x0028 - 0x0020)
struct FRigUnit_GetBoolAnimationChannel : public FRigUnit_GetAnimationChannelBase
{
	bool                                               Value_69;                                                 // 0x0020(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0021(0x0007) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_GetFloatAnimationChannel
// 0x0008 (0x0028 - 0x0020)
struct FRigUnit_GetFloatAnimationChannel : public FRigUnit_GetAnimationChannelBase
{
	float                                              Value_69;                                                 // 0x0020(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0024(0x0004) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_GetIntAnimationChannel
// 0x0008 (0x0028 - 0x0020)
struct FRigUnit_GetIntAnimationChannel : public FRigUnit_GetAnimationChannelBase
{
	int                                                Value_69;                                                 // 0x0020(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0024(0x0004) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_GetVector2DAnimationChannel
// 0x0010 (0x0030 - 0x0020)
struct FRigUnit_GetVector2DAnimationChannel : public FRigUnit_GetAnimationChannelBase
{
	struct FVector2D                                   Value_69;                                                 // 0x0020(0x0010) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_GetVectorAnimationChannel
// 0x0018 (0x0038 - 0x0020)
struct FRigUnit_GetVectorAnimationChannel : public FRigUnit_GetAnimationChannelBase
{
	struct FVector                                     Value_69;                                                 // 0x0020(0x0018) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_GetRotatorAnimationChannel
// 0x0018 (0x0038 - 0x0020)
struct FRigUnit_GetRotatorAnimationChannel : public FRigUnit_GetAnimationChannelBase
{
	struct FRotator                                    Value_69;                                                 // 0x0020(0x0018) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_GetTransformAnimationChannel
// 0x0060 (0x0080 - 0x0020)
struct FRigUnit_GetTransformAnimationChannel : public FRigUnit_GetAnimationChannelBase
{
	struct FCoreUObject_FTransform                     Value_69;                                                 // 0x0020(0x0060) (BlueprintVisible, BlueprintReadOnly, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_SetAnimationChannelBase
// 0x0030 (0x0050 - 0x0020)
struct FRigUnit_SetAnimationChannelBase : public FRigUnit_GetAnimationChannelBase
{
	struct FControlRigExecuteContext                   ExecuteContext_69;                                        // 0x0020(0x0030) (Edit, BlueprintVisible, Transient)
};

// ScriptStruct ControlRig.RigUnit_SetBoolAnimationChannel
// 0x0008 (0x0058 - 0x0050)
struct FRigUnit_SetBoolAnimationChannel : public FRigUnit_SetAnimationChannelBase
{
	bool                                               Value_69;                                                 // 0x0050(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0051(0x0007) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_SetFloatAnimationChannel
// 0x0008 (0x0058 - 0x0050)
struct FRigUnit_SetFloatAnimationChannel : public FRigUnit_SetAnimationChannelBase
{
	float                                              Value_69;                                                 // 0x0050(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0054(0x0004) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_SetIntAnimationChannel
// 0x0008 (0x0058 - 0x0050)
struct FRigUnit_SetIntAnimationChannel : public FRigUnit_SetAnimationChannelBase
{
	int                                                Value_69;                                                 // 0x0050(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0054(0x0004) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_SetVector2DAnimationChannel
// 0x0010 (0x0060 - 0x0050)
struct FRigUnit_SetVector2DAnimationChannel : public FRigUnit_SetAnimationChannelBase
{
	struct FVector2D                                   Value_69;                                                 // 0x0050(0x0010) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_SetVectorAnimationChannel
// 0x0018 (0x0068 - 0x0050)
struct FRigUnit_SetVectorAnimationChannel : public FRigUnit_SetAnimationChannelBase
{
	struct FVector                                     Value_69;                                                 // 0x0050(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_SetRotatorAnimationChannel
// 0x0018 (0x0068 - 0x0050)
struct FRigUnit_SetRotatorAnimationChannel : public FRigUnit_SetAnimationChannelBase
{
	struct FRotator                                    Value_69;                                                 // 0x0050(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_SetTransformAnimationChannel
// 0x0060 (0x00B0 - 0x0050)
struct FRigUnit_SetTransformAnimationChannel : public FRigUnit_SetAnimationChannelBase
{
	struct FCoreUObject_FTransform                     Value_69;                                                 // 0x0050(0x0060) (Edit, BlueprintVisible, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_GetBoneTransform
// 0x0088 (0x0090 - 0x0008)
struct FRigUnit_GetBoneTransform : public FRigUnit
{
	struct FName                                       bone_69;                                                  // 0x0008(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	EBoneGetterSetterMode                              Space_69;                                                 // 0x000C(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x000D(0x0003) MISSED OFFSET
	struct FCoreUObject_FTransform                     Transform_69;                                             // 0x0010(0x0060) (BlueprintVisible, BlueprintReadOnly, IsPlainOldData)
	struct FCachedRigElement                           CachedBone_69;                                            // 0x0070(0x0018) (Transient)
	unsigned char                                      UnknownData01[0x8];                                       // 0x0088(0x0008) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_GetControlInitialTransform
// 0x0088 (0x0090 - 0x0008)
struct FRigUnit_GetControlInitialTransform : public FRigUnit
{
	struct FName                                       Control_69;                                               // 0x0008(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	EBoneGetterSetterMode                              Space_69;                                                 // 0x000C(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x000D(0x0003) MISSED OFFSET
	struct FCoreUObject_FTransform                     Transform_69;                                             // 0x0010(0x0060) (BlueprintVisible, BlueprintReadOnly, IsPlainOldData)
	struct FCachedRigElement                           CachedControlIndex_69;                                    // 0x0070(0x0018)
	unsigned char                                      UnknownData01[0x8];                                       // 0x0088(0x0008) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_GetControlBool
// 0x0020 (0x0028 - 0x0008)
struct FRigUnit_GetControlBool : public FRigUnit
{
	struct FName                                       Control_69;                                               // 0x0008(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               BoolValue_69;                                             // 0x000C(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x000D(0x0003) MISSED OFFSET
	struct FCachedRigElement                           CachedControlIndex_69;                                    // 0x0010(0x0018)
};

// ScriptStruct ControlRig.RigUnit_GetControlFloat
// 0x0028 (0x0030 - 0x0008)
struct FRigUnit_GetControlFloat : public FRigUnit
{
	struct FName                                       Control_69;                                               // 0x0008(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              FloatValue_69;                                            // 0x000C(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              Minimum_69;                                               // 0x0010(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              Maximum_69;                                               // 0x0014(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	struct FCachedRigElement                           CachedControlIndex_69;                                    // 0x0018(0x0018)
};

// ScriptStruct ControlRig.RigUnit_GetControlInteger
// 0x0028 (0x0030 - 0x0008)
struct FRigUnit_GetControlInteger : public FRigUnit
{
	struct FName                                       Control_69;                                               // 0x0008(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                IntegerValue_69;                                          // 0x000C(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                Minimum_69;                                               // 0x0010(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                Maximum_69;                                               // 0x0014(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	struct FCachedRigElement                           CachedControlIndex_69;                                    // 0x0018(0x0018)
};

// ScriptStruct ControlRig.RigUnit_GetControlVector2D
// 0x0050 (0x0058 - 0x0008)
struct FRigUnit_GetControlVector2D : public FRigUnit
{
	struct FName                                       Control_69;                                               // 0x0008(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x000C(0x0004) MISSED OFFSET
	struct FVector2D                                   Vector_69;                                                // 0x0010(0x0010) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	struct FVector2D                                   Minimum_69;                                               // 0x0020(0x0010) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	struct FVector2D                                   Maximum_69;                                               // 0x0030(0x0010) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	struct FCachedRigElement                           CachedControlIndex_69;                                    // 0x0040(0x0018)
};

// ScriptStruct ControlRig.RigUnit_GetControlVector
// 0x0068 (0x0070 - 0x0008)
struct FRigUnit_GetControlVector : public FRigUnit
{
	struct FName                                       Control_69;                                               // 0x0008(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	EBoneGetterSetterMode                              Space_69;                                                 // 0x000C(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x000D(0x0003) MISSED OFFSET
	struct FVector                                     Vector_69;                                                // 0x0010(0x0018) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	struct FVector                                     Minimum_69;                                               // 0x0028(0x0018) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	struct FVector                                     Maximum_69;                                               // 0x0040(0x0018) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	struct FCachedRigElement                           CachedControlIndex_69;                                    // 0x0058(0x0018)
};

// ScriptStruct ControlRig.RigUnit_GetControlRotator
// 0x0068 (0x0070 - 0x0008)
struct FRigUnit_GetControlRotator : public FRigUnit
{
	struct FName                                       Control_69;                                               // 0x0008(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	EBoneGetterSetterMode                              Space_69;                                                 // 0x000C(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x000D(0x0003) MISSED OFFSET
	struct FRotator                                    Rotator_69;                                               // 0x0010(0x0018) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	struct FRotator                                    Minimum_69;                                               // 0x0028(0x0018) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	struct FRotator                                    Maximum_69;                                               // 0x0040(0x0018) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	struct FCachedRigElement                           CachedControlIndex_69;                                    // 0x0058(0x0018)
};

// ScriptStruct ControlRig.RigUnit_GetControlTransform
// 0x0148 (0x0150 - 0x0008)
struct FRigUnit_GetControlTransform : public FRigUnit
{
	struct FName                                       Control_69;                                               // 0x0008(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	EBoneGetterSetterMode                              Space_69;                                                 // 0x000C(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x000D(0x0003) MISSED OFFSET
	struct FCoreUObject_FTransform                     Transform_69;                                             // 0x0010(0x0060) (BlueprintVisible, BlueprintReadOnly, IsPlainOldData)
	struct FCoreUObject_FTransform                     Minimum_69;                                               // 0x0070(0x0060) (BlueprintVisible, BlueprintReadOnly, IsPlainOldData)
	struct FCoreUObject_FTransform                     Maximum_69;                                               // 0x00D0(0x0060) (BlueprintVisible, BlueprintReadOnly, IsPlainOldData)
	struct FCachedRigElement                           CachedControlIndex_69;                                    // 0x0130(0x0018)
	unsigned char                                      UnknownData01[0x8];                                       // 0x0148(0x0008) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_GetCurveValue
// 0x0028 (0x0030 - 0x0008)
struct FRigUnit_GetCurveValue : public FRigUnit
{
	struct FName                                       Curve_69;                                                 // 0x0008(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               Valid_69;                                                 // 0x000C(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x000D(0x0003) MISSED OFFSET
	float                                              Value_69;                                                 // 0x0010(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x4];                                       // 0x0014(0x0004) MISSED OFFSET
	struct FCachedRigElement                           CachedCurveIndex_69;                                      // 0x0018(0x0018)
};

// ScriptStruct ControlRig.RigUnit_GetInitialBoneTransform
// 0x0088 (0x0090 - 0x0008)
struct FRigUnit_GetInitialBoneTransform : public FRigUnit
{
	struct FName                                       bone_69;                                                  // 0x0008(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	EBoneGetterSetterMode                              Space_69;                                                 // 0x000C(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x000D(0x0003) MISSED OFFSET
	struct FCoreUObject_FTransform                     Transform_69;                                             // 0x0010(0x0060) (BlueprintVisible, BlueprintReadOnly, IsPlainOldData)
	struct FCachedRigElement                           CachedBone_69;                                            // 0x0070(0x0018) (Transient)
	unsigned char                                      UnknownData01[0x8];                                       // 0x0088(0x0008) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_GetRelativeBoneTransform
// 0x0098 (0x00A0 - 0x0008)
struct FRigUnit_GetRelativeBoneTransform : public FRigUnit
{
	struct FName                                       bone_69;                                                  // 0x0008(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FName                                       Space_69;                                                 // 0x000C(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FCoreUObject_FTransform                     Transform_69;                                             // 0x0010(0x0060) (BlueprintVisible, BlueprintReadOnly, IsPlainOldData)
	struct FCachedRigElement                           CachedBone_69;                                            // 0x0070(0x0018) (Transient)
	struct FCachedRigElement                           CachedSpace_69;                                           // 0x0088(0x0018) (Transient)
};

// ScriptStruct ControlRig.RigUnit_GetRelativeTransformForItem
// 0x00A8 (0x00B0 - 0x0008)
struct FRigUnit_GetRelativeTransformForItem : public FRigUnit
{
	struct FRigElementKey                              Child_69;                                                 // 0x0008(0x0008) (Edit, BlueprintVisible)
	bool                                               bChildInitial_69;                                         // 0x0010(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0011(0x0003) MISSED OFFSET
	struct FRigElementKey                              Parent_69;                                                // 0x0014(0x0008) (Edit, BlueprintVisible)
	bool                                               bParentInitial_69;                                        // 0x001C(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x3];                                       // 0x001D(0x0003) MISSED OFFSET
	struct FCoreUObject_FTransform                     RelativeTransform_69;                                     // 0x0020(0x0060) (BlueprintVisible, BlueprintReadOnly, IsPlainOldData)
	struct FCachedRigElement                           CachedChild_69;                                           // 0x0080(0x0018)
	struct FCachedRigElement                           CachedParent_69;                                          // 0x0098(0x0018)
};

// ScriptStruct ControlRig.RigUnit_GetSpaceTransform
// 0x0088 (0x0090 - 0x0008)
struct FRigUnit_GetSpaceTransform : public FRigUnit
{
	struct FName                                       Space_69;                                                 // 0x0008(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	EBoneGetterSetterMode                              SpaceType_69;                                             // 0x000C(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x000D(0x0003) MISSED OFFSET
	struct FCoreUObject_FTransform                     Transform_69;                                             // 0x0010(0x0060) (BlueprintVisible, BlueprintReadOnly, IsPlainOldData)
	struct FCachedRigElement                           CachedSpaceIndex_69;                                      // 0x0070(0x0018)
	unsigned char                                      UnknownData01[0x8];                                       // 0x0088(0x0008) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_GetTransform
// 0x0098 (0x00A0 - 0x0008)
struct FRigUnit_GetTransform : public FRigUnit
{
	struct FRigElementKey                              Item_69;                                                  // 0x0008(0x0008) (Edit, BlueprintVisible)
	EBoneGetterSetterMode                              Space_69;                                                 // 0x0010(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bInitial_69;                                              // 0x0011(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0xE];                                       // 0x0012(0x000E) MISSED OFFSET
	struct FCoreUObject_FTransform                     Transform_69;                                             // 0x0020(0x0060) (BlueprintVisible, BlueprintReadOnly, IsPlainOldData)
	struct FCachedRigElement                           CachedIndex_69;                                           // 0x0080(0x0018)
	unsigned char                                      UnknownData01[0x8];                                       // 0x0098(0x0008) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_GetTransformArray
// 0x0038 (0x0040 - 0x0008)
struct FRigUnit_GetTransformArray : public FRigUnit
{
	struct FRigElementKeyCollection                    Items_69;                                                 // 0x0008(0x0010) (Edit, BlueprintVisible)
	EBoneGetterSetterMode                              Space_69;                                                 // 0x0018(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bInitial_69;                                              // 0x0019(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x6];                                       // 0x001A(0x0006) MISSED OFFSET
	TArray<struct FCoreUObject_FTransform>             Transforms_69;                                            // 0x0020(0x0010) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
	TArray<struct FCachedRigElement>                   CachedIndex_69;                                           // 0x0030(0x0010) (ZeroConstructor)
};

// ScriptStruct ControlRig.RigUnit_GetTransformItemArray
// 0x0038 (0x0040 - 0x0008)
struct FRigUnit_GetTransformItemArray : public FRigUnit
{
	TArray<struct FRigElementKey>                      Items_69;                                                 // 0x0008(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	EBoneGetterSetterMode                              Space_69;                                                 // 0x0018(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bInitial_69;                                              // 0x0019(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x6];                                       // 0x001A(0x0006) MISSED OFFSET
	TArray<struct FCoreUObject_FTransform>             Transforms_69;                                            // 0x0020(0x0010) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
	TArray<struct FCachedRigElement>                   CachedIndex_69;                                           // 0x0030(0x0010) (ZeroConstructor)
};

// ScriptStruct ControlRig.RigDispatch_MetadataBase
// 0x0030 (0x0048 - 0x0018)
struct FRigDispatch_MetadataBase : public FRigDispatchFactory
{
	unsigned char                                      UnknownData00[0x30];                                      // 0x0018(0x0030) MISSED OFFSET
};

// ScriptStruct ControlRig.RigDispatch_GetMetadata
// 0x0000 (0x0048 - 0x0048)
struct FRigDispatch_GetMetadata : public FRigDispatch_MetadataBase
{

};

// ScriptStruct ControlRig.RigDispatch_SetMetadata
// 0x0000 (0x0048 - 0x0048)
struct FRigDispatch_SetMetadata : public FRigDispatch_MetadataBase
{

};

// ScriptStruct ControlRig.RigUnit_RemoveMetadata
// 0x0028 (0x0060 - 0x0038)
struct FRigUnit_RemoveMetadata : public FRigUnitMutable
{
	struct FRigElementKey                              Item_69;                                                  // 0x0038(0x0008) (Edit, BlueprintVisible)
	struct FName                                       Name_69;                                                  // 0x0040(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               Removed_69;                                               // 0x0044(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0045(0x0003) MISSED OFFSET
	struct FCachedRigElement                           CachedIndex_69;                                           // 0x0048(0x0018)
};

// ScriptStruct ControlRig.RigUnit_RemoveAllMetadata
// 0x0028 (0x0060 - 0x0038)
struct FRigUnit_RemoveAllMetadata : public FRigUnitMutable
{
	struct FRigElementKey                              Item_69;                                                  // 0x0038(0x0008) (Edit, BlueprintVisible)
	bool                                               Removed_69;                                               // 0x0040(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0041(0x0007) MISSED OFFSET
	struct FCachedRigElement                           CachedIndex_69;                                           // 0x0048(0x0018)
};

// ScriptStruct ControlRig.RigUnit_HasMetadata
// 0x0028 (0x0030 - 0x0008)
struct FRigUnit_HasMetadata : public FRigUnit
{
	struct FRigElementKey                              Item_69;                                                  // 0x0008(0x0008) (Edit, BlueprintVisible)
	struct FName                                       Name_69;                                                  // 0x0010(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	ERigMetadataType                                   Type_69;                                                  // 0x0014(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               Found_69;                                                 // 0x0015(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x2];                                       // 0x0016(0x0002) MISSED OFFSET
	struct FCachedRigElement                           CachedIndex_69;                                           // 0x0018(0x0018)
};

// ScriptStruct ControlRig.RigUnit_FindItemsWithMetadata
// 0x0018 (0x0020 - 0x0008)
struct FRigUnit_FindItemsWithMetadata : public FRigUnit
{
	struct FName                                       Name_69;                                                  // 0x0008(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	ERigMetadataType                                   Type_69;                                                  // 0x000C(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x000D(0x0003) MISSED OFFSET
	TArray<struct FRigElementKey>                      Items_69;                                                 // 0x0010(0x0010) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
};

// ScriptStruct ControlRig.RigUnit_GetMetadataTags
// 0x0030 (0x0038 - 0x0008)
struct FRigUnit_GetMetadataTags : public FRigUnit
{
	struct FRigElementKey                              Item_69;                                                  // 0x0008(0x0008) (Edit, BlueprintVisible)
	TArray<struct FName>                               Tags_69;                                                  // 0x0010(0x0010) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
	struct FCachedRigElement                           CachedIndex_69;                                           // 0x0020(0x0018)
};

// ScriptStruct ControlRig.RigUnit_SetMetadataTag
// 0x0028 (0x0060 - 0x0038)
struct FRigUnit_SetMetadataTag : public FRigUnitMutable
{
	struct FRigElementKey                              Item_69;                                                  // 0x0038(0x0008) (Edit, BlueprintVisible)
	struct FName                                       tag_69;                                                   // 0x0040(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0044(0x0004) MISSED OFFSET
	struct FCachedRigElement                           CachedIndex_69;                                           // 0x0048(0x0018)
};

// ScriptStruct ControlRig.RigUnit_SetMetadataTagArray
// 0x0030 (0x0068 - 0x0038)
struct FRigUnit_SetMetadataTagArray : public FRigUnitMutable
{
	struct FRigElementKey                              Item_69;                                                  // 0x0038(0x0008) (Edit, BlueprintVisible)
	TArray<struct FName>                               Tags_69;                                                  // 0x0040(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FCachedRigElement                           CachedIndex_69;                                           // 0x0050(0x0018)
};

// ScriptStruct ControlRig.RigUnit_RemoveMetadataTag
// 0x0028 (0x0060 - 0x0038)
struct FRigUnit_RemoveMetadataTag : public FRigUnitMutable
{
	struct FRigElementKey                              Item_69;                                                  // 0x0038(0x0008) (Edit, BlueprintVisible)
	struct FName                                       tag_69;                                                   // 0x0040(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               Removed_69;                                               // 0x0044(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0045(0x0003) MISSED OFFSET
	struct FCachedRigElement                           CachedIndex_69;                                           // 0x0048(0x0018)
};

// ScriptStruct ControlRig.RigUnit_HasMetadataTag
// 0x0028 (0x0030 - 0x0008)
struct FRigUnit_HasMetadataTag : public FRigUnit
{
	struct FRigElementKey                              Item_69;                                                  // 0x0008(0x0008) (Edit, BlueprintVisible)
	struct FName                                       tag_69;                                                   // 0x0010(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               Found_69;                                                 // 0x0014(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0015(0x0003) MISSED OFFSET
	struct FCachedRigElement                           CachedIndex_69;                                           // 0x0018(0x0018)
};

// ScriptStruct ControlRig.RigUnit_HasMetadataTagArray
// 0x0038 (0x0040 - 0x0008)
struct FRigUnit_HasMetadataTagArray : public FRigUnit
{
	struct FRigElementKey                              Item_69;                                                  // 0x0008(0x0008) (Edit, BlueprintVisible)
	TArray<struct FName>                               Tags_69;                                                  // 0x0010(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	bool                                               Found_69;                                                 // 0x0020(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0021(0x0007) MISSED OFFSET
	struct FCachedRigElement                           CachedIndex_69;                                           // 0x0028(0x0018)
};

// ScriptStruct ControlRig.RigUnit_FindItemsWithMetadataTag
// 0x0018 (0x0020 - 0x0008)
struct FRigUnit_FindItemsWithMetadataTag : public FRigUnit
{
	struct FName                                       tag_69;                                                   // 0x0008(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x000C(0x0004) MISSED OFFSET
	TArray<struct FRigElementKey>                      Items_69;                                                 // 0x0010(0x0010) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
};

// ScriptStruct ControlRig.RigUnit_FindItemsWithMetadataTagArray
// 0x0020 (0x0028 - 0x0008)
struct FRigUnit_FindItemsWithMetadataTagArray : public FRigUnit
{
	TArray<struct FName>                               Tags_69;                                                  // 0x0008(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	TArray<struct FRigElementKey>                      Items_69;                                                 // 0x0018(0x0010) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
};

// ScriptStruct ControlRig.RigUnit_FilterItemsByMetadataTags
// 0x0048 (0x0050 - 0x0008)
struct FRigUnit_FilterItemsByMetadataTags : public FRigUnit
{
	TArray<struct FRigElementKey>                      Items_69;                                                 // 0x0008(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	TArray<struct FName>                               Tags_69;                                                  // 0x0018(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	bool                                               Inclusive_69;                                             // 0x0028(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0029(0x0007) MISSED OFFSET
	TArray<struct FRigElementKey>                      Result_69;                                                // 0x0030(0x0010) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
	TArray<struct FCachedRigElement>                   CachedIndices_69;                                         // 0x0040(0x0010) (ZeroConstructor)
};

// ScriptStruct ControlRig.RigUnit_OffsetTransformForItem
// 0x0088 (0x00C0 - 0x0038)
struct FRigUnit_OffsetTransformForItem : public FRigUnitMutable
{
	struct FRigElementKey                              Item_69;                                                  // 0x0038(0x0008) (Edit, BlueprintVisible)
	struct FCoreUObject_FTransform                     OffsetTransform_69;                                       // 0x0040(0x0060) (Edit, BlueprintVisible, IsPlainOldData)
	float                                              Weight_69;                                                // 0x00A0(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bPropagateToChildren_69;                                  // 0x00A4(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x00A5(0x0003) MISSED OFFSET
	struct FCachedRigElement                           CachedIndex_69;                                           // 0x00A8(0x0018)
};

// ScriptStruct ControlRig.RigUnit_ParentSwitchConstraint
// 0x0198 (0x01D0 - 0x0038)
struct FRigUnit_ParentSwitchConstraint : public FRigUnitMutable
{
	struct FRigElementKey                              Subject_69;                                               // 0x0038(0x0008) (Edit, BlueprintVisible)
	int                                                ParentIndex_69;                                           // 0x0040(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0044(0x0004) MISSED OFFSET
	struct FRigElementKeyCollection                    Parents_69;                                               // 0x0048(0x0010) (Edit, BlueprintVisible)
	unsigned char                                      UnknownData01[0x8];                                       // 0x0058(0x0008) MISSED OFFSET
	struct FCoreUObject_FTransform                     InitialGlobalTransform_69;                                // 0x0060(0x0060) (Edit, BlueprintVisible, IsPlainOldData)
	float                                              Weight_69;                                                // 0x00C0(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData02[0xC];                                       // 0x00C4(0x000C) MISSED OFFSET
	struct FCoreUObject_FTransform                     Transform_69;                                             // 0x00D0(0x0060) (BlueprintVisible, BlueprintReadOnly, IsPlainOldData)
	bool                                               Switched_69;                                              // 0x0130(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData03[0x7];                                       // 0x0131(0x0007) MISSED OFFSET
	struct FCachedRigElement                           CachedSubject_69;                                         // 0x0138(0x0018)
	struct FCachedRigElement                           CachedParent_69;                                          // 0x0150(0x0018)
	unsigned char                                      UnknownData04[0x8];                                       // 0x0168(0x0008) MISSED OFFSET
	struct FCoreUObject_FTransform                     RelativeOffset_69;                                        // 0x0170(0x0060) (IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_ParentSwitchConstraintArray
// 0x0198 (0x01D0 - 0x0038)
struct FRigUnit_ParentSwitchConstraintArray : public FRigUnitMutable
{
	struct FRigElementKey                              Subject_69;                                               // 0x0038(0x0008) (Edit, BlueprintVisible)
	int                                                ParentIndex_69;                                           // 0x0040(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0044(0x0004) MISSED OFFSET
	TArray<struct FRigElementKey>                      Parents_69;                                               // 0x0048(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	unsigned char                                      UnknownData01[0x8];                                       // 0x0058(0x0008) MISSED OFFSET
	struct FCoreUObject_FTransform                     InitialGlobalTransform_69;                                // 0x0060(0x0060) (Edit, BlueprintVisible, IsPlainOldData)
	float                                              Weight_69;                                                // 0x00C0(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData02[0xC];                                       // 0x00C4(0x000C) MISSED OFFSET
	struct FCoreUObject_FTransform                     Transform_69;                                             // 0x00D0(0x0060) (BlueprintVisible, BlueprintReadOnly, IsPlainOldData)
	bool                                               Switched_69;                                              // 0x0130(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData03[0x7];                                       // 0x0131(0x0007) MISSED OFFSET
	struct FCachedRigElement                           CachedSubject_69;                                         // 0x0138(0x0018)
	struct FCachedRigElement                           CachedParent_69;                                          // 0x0150(0x0018)
	unsigned char                                      UnknownData04[0x8];                                       // 0x0168(0x0008) MISSED OFFSET
	struct FCoreUObject_FTransform                     RelativeOffset_69;                                        // 0x0170(0x0060) (IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_ProjectTransformToNewParent
// 0x00D8 (0x00E0 - 0x0008)
struct FRigUnit_ProjectTransformToNewParent : public FRigUnit
{
	struct FRigElementKey                              Child_69;                                                 // 0x0008(0x0008) (Edit, BlueprintVisible)
	bool                                               bChildInitial_69;                                         // 0x0010(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0011(0x0003) MISSED OFFSET
	struct FRigElementKey                              OldParent_69;                                             // 0x0014(0x0008) (Edit, BlueprintVisible)
	bool                                               bOldParentInitial_69;                                     // 0x001C(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x3];                                       // 0x001D(0x0003) MISSED OFFSET
	struct FRigElementKey                              NewParent_69;                                             // 0x0020(0x0008) (Edit, BlueprintVisible)
	bool                                               bNewParentInitial_69;                                     // 0x0028(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData02[0x7];                                       // 0x0029(0x0007) MISSED OFFSET
	struct FCoreUObject_FTransform                     Transform_69;                                             // 0x0030(0x0060) (BlueprintVisible, BlueprintReadOnly, IsPlainOldData)
	struct FCachedRigElement                           CachedChild_69;                                           // 0x0090(0x0018)
	struct FCachedRigElement                           CachedOldParent_69;                                       // 0x00A8(0x0018)
	struct FCachedRigElement                           CachedNewParent_69;                                       // 0x00C0(0x0018)
	unsigned char                                      UnknownData03[0x8];                                       // 0x00D8(0x0008) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_PropagateTransform
// 0x0028 (0x0060 - 0x0038)
struct FRigUnit_PropagateTransform : public FRigUnitMutable
{
	struct FRigElementKey                              Item_69;                                                  // 0x0038(0x0008) (Edit, BlueprintVisible)
	bool                                               bRecomputeGlobal_69;                                      // 0x0040(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bApplyToChildren_69;                                      // 0x0041(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bRecursive_69;                                            // 0x0042(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x5];                                       // 0x0043(0x0005) MISSED OFFSET
	struct FCachedRigElement                           CachedIndex_69;                                           // 0x0048(0x0018) (Transient)
};

// ScriptStruct ControlRig.RigUnit_SendEvent
// 0x0018 (0x0050 - 0x0038)
struct FRigUnit_SendEvent : public FRigUnitMutable
{
	ERigEvent                                          Event_69;                                                 // 0x0038(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0039(0x0003) MISSED OFFSET
	struct FRigElementKey                              Item_69;                                                  // 0x003C(0x0008) (Edit, BlueprintVisible)
	float                                              OffsetInSeconds_69;                                       // 0x0044(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bEnable_69;                                               // 0x0048(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bOnlyDuringInteraction_69;                                // 0x0049(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x6];                                       // 0x004A(0x0006) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_SetBoneInitialTransform
// 0x00E8 (0x0120 - 0x0038)
struct FRigUnit_SetBoneInitialTransform : public FRigUnitMutable
{
	struct FName                                       bone_69;                                                  // 0x0038(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x003C(0x0004) MISSED OFFSET
	struct FCoreUObject_FTransform                     Transform_69;                                             // 0x0040(0x0060) (Edit, BlueprintVisible, IsPlainOldData)
	struct FCoreUObject_FTransform                     Result_69;                                                // 0x00A0(0x0060) (BlueprintVisible, BlueprintReadOnly, IsPlainOldData)
	EBoneGetterSetterMode                              Space_69;                                                 // 0x0100(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bPropagateToChildren_69;                                  // 0x0101(0x0001) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	unsigned char                                      UnknownData01[0x6];                                       // 0x0102(0x0006) MISSED OFFSET
	struct FCachedRigElement                           CachedBone_69;                                            // 0x0108(0x0018) (Transient)
};

// ScriptStruct ControlRig.RigUnit_SetBoneRotation
// 0x0058 (0x0090 - 0x0038)
struct FRigUnit_SetBoneRotation : public FRigUnitMutable
{
	struct FName                                       bone_69;                                                  // 0x0038(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x003C(0x0004) MISSED OFFSET
	struct FQuat                                       Rotation_69;                                              // 0x0040(0x0020) (Edit, BlueprintVisible, IsPlainOldData)
	EBoneGetterSetterMode                              Space_69;                                                 // 0x0060(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x3];                                       // 0x0061(0x0003) MISSED OFFSET
	float                                              Weight_69;                                                // 0x0064(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bPropagateToChildren_69;                                  // 0x0068(0x0001) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	unsigned char                                      UnknownData02[0x7];                                       // 0x0069(0x0007) MISSED OFFSET
	struct FCachedRigElement                           CachedBone_69;                                            // 0x0070(0x0018) (Transient)
	unsigned char                                      UnknownData03[0x8];                                       // 0x0088(0x0008) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_SetBoneTransform
// 0x00F8 (0x0130 - 0x0038)
struct FRigUnit_SetBoneTransform : public FRigUnitMutable
{
	struct FName                                       bone_69;                                                  // 0x0038(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x003C(0x0004) MISSED OFFSET
	struct FCoreUObject_FTransform                     Transform_69;                                             // 0x0040(0x0060) (Edit, BlueprintVisible, IsPlainOldData)
	struct FCoreUObject_FTransform                     Result_69;                                                // 0x00A0(0x0060) (BlueprintVisible, BlueprintReadOnly, IsPlainOldData)
	EBoneGetterSetterMode                              Space_69;                                                 // 0x0100(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x3];                                       // 0x0101(0x0003) MISSED OFFSET
	float                                              Weight_69;                                                // 0x0104(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bPropagateToChildren_69;                                  // 0x0108(0x0001) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	unsigned char                                      UnknownData02[0x7];                                       // 0x0109(0x0007) MISSED OFFSET
	struct FCachedRigElement                           CachedBone_69;                                            // 0x0110(0x0018) (Transient)
	unsigned char                                      UnknownData03[0x8];                                       // 0x0128(0x0008) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_SetBoneTranslation
// 0x0048 (0x0080 - 0x0038)
struct FRigUnit_SetBoneTranslation : public FRigUnitMutable
{
	struct FName                                       bone_69;                                                  // 0x0038(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x003C(0x0004) MISSED OFFSET
	struct FVector                                     Translation_69;                                           // 0x0040(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	EBoneGetterSetterMode                              Space_69;                                                 // 0x0058(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x3];                                       // 0x0059(0x0003) MISSED OFFSET
	float                                              Weight_69;                                                // 0x005C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bPropagateToChildren_69;                                  // 0x0060(0x0001) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	unsigned char                                      UnknownData02[0x7];                                       // 0x0061(0x0007) MISSED OFFSET
	struct FCachedRigElement                           CachedBone_69;                                            // 0x0068(0x0018) (Transient)
};

// ScriptStruct ControlRig.RigUnit_GetControlColor
// 0x0030 (0x0038 - 0x0008)
struct FRigUnit_GetControlColor : public FRigUnit
{
	struct FName                                       Control_69;                                               // 0x0008(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FLinearColor                                Color_69;                                                 // 0x000C(0x0010) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x001C(0x0004) MISSED OFFSET
	struct FCachedRigElement                           CachedControlIndex_69;                                    // 0x0020(0x0018)
};

// ScriptStruct ControlRig.RigUnit_SetControlColor
// 0x0030 (0x0068 - 0x0038)
struct FRigUnit_SetControlColor : public FRigUnitMutable
{
	struct FName                                       Control_69;                                               // 0x0038(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FLinearColor                                Color_69;                                                 // 0x003C(0x0010) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x004C(0x0004) MISSED OFFSET
	struct FCachedRigElement                           CachedControlIndex_69;                                    // 0x0050(0x0018)
};

// ScriptStruct ControlRig.RigUnit_GetControlDrivenList
// 0x0030 (0x0038 - 0x0008)
struct FRigUnit_GetControlDrivenList : public FRigUnit
{
	struct FName                                       Control_69;                                               // 0x0008(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x000C(0x0004) MISSED OFFSET
	TArray<struct FRigElementKey>                      Driven_69;                                                // 0x0010(0x0010) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
	struct FCachedRigElement                           CachedControlIndex_69;                                    // 0x0020(0x0018)
};

// ScriptStruct ControlRig.RigUnit_SetControlDrivenList
// 0x0030 (0x0068 - 0x0038)
struct FRigUnit_SetControlDrivenList : public FRigUnitMutable
{
	struct FName                                       Control_69;                                               // 0x0038(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x003C(0x0004) MISSED OFFSET
	TArray<struct FRigElementKey>                      Driven_69;                                                // 0x0040(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FCachedRigElement                           CachedControlIndex_69;                                    // 0x0050(0x0018)
};

// ScriptStruct ControlRig.RigUnit_SetControlOffset
// 0x0088 (0x00C0 - 0x0038)
struct FRigUnit_SetControlOffset : public FRigUnitMutable
{
	struct FName                                       Control_69;                                               // 0x0038(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x003C(0x0004) MISSED OFFSET
	struct FCoreUObject_FTransform                     Offset_69;                                                // 0x0040(0x0060) (Edit, BlueprintVisible, IsPlainOldData)
	EBoneGetterSetterMode                              Space_69;                                                 // 0x00A0(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x7];                                       // 0x00A1(0x0007) MISSED OFFSET
	struct FCachedRigElement                           CachedControlIndex_69;                                    // 0x00A8(0x0018)
};

// ScriptStruct ControlRig.RigUnit_GetShapeTransform
// 0x0088 (0x0090 - 0x0008)
struct FRigUnit_GetShapeTransform : public FRigUnit
{
	struct FName                                       Control_69;                                               // 0x0008(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x000C(0x0004) MISSED OFFSET
	struct FCoreUObject_FTransform                     Transform_69;                                             // 0x0010(0x0060) (BlueprintVisible, BlueprintReadOnly, IsPlainOldData)
	struct FCachedRigElement                           CachedControlIndex_69;                                    // 0x0070(0x0018)
	unsigned char                                      UnknownData01[0x8];                                       // 0x0088(0x0008) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_SetShapeTransform
// 0x0088 (0x00C0 - 0x0038)
struct FRigUnit_SetShapeTransform : public FRigUnitMutable
{
	struct FName                                       Control_69;                                               // 0x0038(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x003C(0x0004) MISSED OFFSET
	struct FCoreUObject_FTransform                     Transform_69;                                             // 0x0040(0x0060) (Edit, BlueprintVisible, IsPlainOldData)
	struct FCachedRigElement                           CachedControlIndex_69;                                    // 0x00A0(0x0018)
	unsigned char                                      UnknownData01[0x8];                                       // 0x00B8(0x0008) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_SetControlBool
// 0x0020 (0x0058 - 0x0038)
struct FRigUnit_SetControlBool : public FRigUnitMutable
{
	struct FName                                       Control_69;                                               // 0x0038(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               BoolValue_69;                                             // 0x003C(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x003D(0x0003) MISSED OFFSET
	struct FCachedRigElement                           CachedControlIndex_69;                                    // 0x0040(0x0018)
};

// ScriptStruct ControlRig.RigUnit_SetMultiControlBool_Entry
// 0x0008
struct FRigUnit_SetMultiControlBool_Entry
{
	struct FName                                       Control_69;                                               // 0x0000(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               BoolValue_69;                                             // 0x0004(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0005(0x0003) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_SetMultiControlBool
// 0x0020 (0x0058 - 0x0038)
struct FRigUnit_SetMultiControlBool : public FRigUnitMutable
{
	TArray<struct FRigUnit_SetMultiControlBool_Entry>  Entries_69;                                               // 0x0038(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	TArray<struct FCachedRigElement>                   CachedControlIndices_69;                                  // 0x0048(0x0010) (ZeroConstructor)
};

// ScriptStruct ControlRig.RigUnit_SetControlFloat
// 0x0028 (0x0060 - 0x0038)
struct FRigUnit_SetControlFloat : public FRigUnitMutable
{
	struct FName                                       Control_69;                                               // 0x0038(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              Weight_69;                                                // 0x003C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              FloatValue_69;                                            // 0x0040(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0044(0x0004) MISSED OFFSET
	struct FCachedRigElement                           CachedControlIndex_69;                                    // 0x0048(0x0018)
};

// ScriptStruct ControlRig.RigUnit_SetMultiControlFloat_Entry
// 0x0008
struct FRigUnit_SetMultiControlFloat_Entry
{
	struct FName                                       Control_69;                                               // 0x0000(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              FloatValue_69;                                            // 0x0004(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_SetMultiControlFloat
// 0x0028 (0x0060 - 0x0038)
struct FRigUnit_SetMultiControlFloat : public FRigUnitMutable
{
	TArray<struct FRigUnit_SetMultiControlFloat_Entry> Entries_69;                                               // 0x0038(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	float                                              Weight_69;                                                // 0x0048(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x004C(0x0004) MISSED OFFSET
	TArray<struct FCachedRigElement>                   CachedControlIndices_69;                                  // 0x0050(0x0010) (ZeroConstructor)
};

// ScriptStruct ControlRig.RigUnit_SetControlInteger
// 0x0028 (0x0060 - 0x0038)
struct FRigUnit_SetControlInteger : public FRigUnitMutable
{
	struct FName                                       Control_69;                                               // 0x0038(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                Weight_69;                                                // 0x003C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                IntegerValue_69;                                          // 0x0040(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0044(0x0004) MISSED OFFSET
	struct FCachedRigElement                           CachedControlIndex_69;                                    // 0x0048(0x0018)
};

// ScriptStruct ControlRig.RigUnit_SetMultiControlInteger_Entry
// 0x0008
struct FRigUnit_SetMultiControlInteger_Entry
{
	struct FName                                       Control_69;                                               // 0x0000(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                IntegerValue_69;                                          // 0x0004(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_SetMultiControlInteger
// 0x0028 (0x0060 - 0x0038)
struct FRigUnit_SetMultiControlInteger : public FRigUnitMutable
{
	TArray<struct FRigUnit_SetMultiControlInteger_Entry> Entries_69;                                               // 0x0038(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	float                                              Weight_69;                                                // 0x0048(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x004C(0x0004) MISSED OFFSET
	TArray<struct FCachedRigElement>                   CachedControlIndices_69;                                  // 0x0050(0x0010) (ZeroConstructor)
};

// ScriptStruct ControlRig.RigUnit_SetControlVector2D
// 0x0030 (0x0068 - 0x0038)
struct FRigUnit_SetControlVector2D : public FRigUnitMutable
{
	struct FName                                       Control_69;                                               // 0x0038(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              Weight_69;                                                // 0x003C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FVector2D                                   Vector_69;                                                // 0x0040(0x0010) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FCachedRigElement                           CachedControlIndex_69;                                    // 0x0050(0x0018)
};

// ScriptStruct ControlRig.RigUnit_SetMultiControlVector2D_Entry
// 0x0018
struct FRigUnit_SetMultiControlVector2D_Entry
{
	struct FName                                       Control_69;                                               // 0x0000(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0004(0x0004) MISSED OFFSET
	struct FVector2D                                   Vector_69;                                                // 0x0008(0x0010) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_SetMultiControlVector2D
// 0x0028 (0x0060 - 0x0038)
struct FRigUnit_SetMultiControlVector2D : public FRigUnitMutable
{
	TArray<struct FRigUnit_SetMultiControlVector2D_Entry> Entries_69;                                               // 0x0038(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	float                                              Weight_69;                                                // 0x0048(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x004C(0x0004) MISSED OFFSET
	TArray<struct FCachedRigElement>                   CachedControlIndices_69;                                  // 0x0050(0x0010) (ZeroConstructor)
};

// ScriptStruct ControlRig.RigUnit_SetControlVector
// 0x0040 (0x0078 - 0x0038)
struct FRigUnit_SetControlVector : public FRigUnitMutable
{
	struct FName                                       Control_69;                                               // 0x0038(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              Weight_69;                                                // 0x003C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FVector                                     Vector_69;                                                // 0x0040(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	EBoneGetterSetterMode                              Space_69;                                                 // 0x0058(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0059(0x0007) MISSED OFFSET
	struct FCachedRigElement                           CachedControlIndex_69;                                    // 0x0060(0x0018)
};

// ScriptStruct ControlRig.RigUnit_SetControlRotator
// 0x0040 (0x0078 - 0x0038)
struct FRigUnit_SetControlRotator : public FRigUnitMutable
{
	struct FName                                       Control_69;                                               // 0x0038(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              Weight_69;                                                // 0x003C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FRotator                                    Rotator_69;                                               // 0x0040(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	EBoneGetterSetterMode                              Space_69;                                                 // 0x0058(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0059(0x0007) MISSED OFFSET
	struct FCachedRigElement                           CachedControlIndex_69;                                    // 0x0060(0x0018)
};

// ScriptStruct ControlRig.RigUnit_SetMultiControlRotator_Entry
// 0x0028
struct FRigUnit_SetMultiControlRotator_Entry
{
	struct FName                                       Control_69;                                               // 0x0000(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0004(0x0004) MISSED OFFSET
	struct FRotator                                    Rotator_69;                                               // 0x0008(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	EBoneGetterSetterMode                              Space_69;                                                 // 0x0020(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x7];                                       // 0x0021(0x0007) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_SetMultiControlRotator
// 0x0028 (0x0060 - 0x0038)
struct FRigUnit_SetMultiControlRotator : public FRigUnitMutable
{
	TArray<struct FRigUnit_SetMultiControlRotator_Entry> Entries_69;                                               // 0x0038(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	float                                              Weight_69;                                                // 0x0048(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x004C(0x0004) MISSED OFFSET
	TArray<struct FCachedRigElement>                   CachedControlIndices_69;                                  // 0x0050(0x0010) (ZeroConstructor)
};

// ScriptStruct ControlRig.RigUnit_SetControlTransform
// 0x0088 (0x00C0 - 0x0038)
struct FRigUnit_SetControlTransform : public FRigUnitMutable
{
	struct FName                                       Control_69;                                               // 0x0038(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              Weight_69;                                                // 0x003C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FCoreUObject_FTransform                     Transform_69;                                             // 0x0040(0x0060) (Edit, BlueprintVisible, IsPlainOldData)
	EBoneGetterSetterMode                              Space_69;                                                 // 0x00A0(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x00A1(0x0007) MISSED OFFSET
	struct FCachedRigElement                           CachedControlIndex_69;                                    // 0x00A8(0x0018)
};

// ScriptStruct ControlRig.RigUnit_GetControlVisibility
// 0x0028 (0x0030 - 0x0008)
struct FRigUnit_GetControlVisibility : public FRigUnit
{
	struct FRigElementKey                              Item_69;                                                  // 0x0008(0x0008) (Edit, BlueprintVisible)
	bool                                               bVisible_69;                                              // 0x0010(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0011(0x0007) MISSED OFFSET
	struct FCachedRigElement                           CachedControlIndex_69;                                    // 0x0018(0x0018)
};

// ScriptStruct ControlRig.RigUnit_SetControlVisibility
// 0x0030 (0x0068 - 0x0038)
struct FRigUnit_SetControlVisibility : public FRigUnitMutable
{
	struct FRigElementKey                              Item_69;                                                  // 0x0038(0x0008) (Edit, BlueprintVisible)
	struct FString                                     Pattern_69;                                               // 0x0040(0x0010) (Edit, BlueprintVisible, ZeroConstructor, EditConst)
	bool                                               bVisible_69;                                              // 0x0050(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0051(0x0007) MISSED OFFSET
	TArray<struct FCachedRigElement>                   CachedControlIndices_69;                                  // 0x0058(0x0010) (ZeroConstructor)
};

// ScriptStruct ControlRig.RigUnit_SetCurveValue
// 0x0020 (0x0058 - 0x0038)
struct FRigUnit_SetCurveValue : public FRigUnitMutable
{
	struct FName                                       Curve_69;                                                 // 0x0038(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              Value_69;                                                 // 0x003C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FCachedRigElement                           CachedCurveIndex_69;                                      // 0x0040(0x0018)
};

// ScriptStruct ControlRig.RigUnit_SetRelativeBoneTransform
// 0x00A8 (0x00E0 - 0x0038)
struct FRigUnit_SetRelativeBoneTransform : public FRigUnitMutable
{
	struct FName                                       bone_69;                                                  // 0x0038(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FName                                       Space_69;                                                 // 0x003C(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FCoreUObject_FTransform                     Transform_69;                                             // 0x0040(0x0060) (Edit, BlueprintVisible, IsPlainOldData)
	float                                              Weight_69;                                                // 0x00A0(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bPropagateToChildren_69;                                  // 0x00A4(0x0001) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x00A5(0x0003) MISSED OFFSET
	struct FCachedRigElement                           CachedBone_69;                                            // 0x00A8(0x0018) (Transient)
	struct FCachedRigElement                           CachedSpaceIndex_69;                                      // 0x00C0(0x0018) (Transient)
	unsigned char                                      UnknownData01[0x8];                                       // 0x00D8(0x0008) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_SetRelativeTransformForItem
// 0x00B8 (0x00F0 - 0x0038)
struct FRigUnit_SetRelativeTransformForItem : public FRigUnitMutable
{
	struct FRigElementKey                              Child_69;                                                 // 0x0038(0x0008) (Edit, BlueprintVisible)
	struct FRigElementKey                              Parent_69;                                                // 0x0040(0x0008) (Edit, BlueprintVisible)
	bool                                               bParentInitial_69;                                        // 0x0048(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0049(0x0007) MISSED OFFSET
	struct FCoreUObject_FTransform                     Value_69;                                                 // 0x0050(0x0060) (Edit, BlueprintVisible, IsPlainOldData)
	float                                              Weight_69;                                                // 0x00B0(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bPropagateToChildren_69;                                  // 0x00B4(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x3];                                       // 0x00B5(0x0003) MISSED OFFSET
	struct FCachedRigElement                           CachedChild_69;                                           // 0x00B8(0x0018)
	struct FCachedRigElement                           CachedParent_69;                                          // 0x00D0(0x0018)
	unsigned char                                      UnknownData02[0x8];                                       // 0x00E8(0x0008) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_SetRelativeTranslationForItem
// 0x0068 (0x00A0 - 0x0038)
struct FRigUnit_SetRelativeTranslationForItem : public FRigUnitMutable
{
	struct FRigElementKey                              Child_69;                                                 // 0x0038(0x0008) (Edit, BlueprintVisible)
	struct FRigElementKey                              Parent_69;                                                // 0x0040(0x0008) (Edit, BlueprintVisible)
	bool                                               bParentInitial_69;                                        // 0x0048(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0049(0x0007) MISSED OFFSET
	struct FVector                                     Value_69;                                                 // 0x0050(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              Weight_69;                                                // 0x0068(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bPropagateToChildren_69;                                  // 0x006C(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x3];                                       // 0x006D(0x0003) MISSED OFFSET
	struct FCachedRigElement                           CachedChild_69;                                           // 0x0070(0x0018)
	struct FCachedRigElement                           CachedParent_69;                                          // 0x0088(0x0018)
};

// ScriptStruct ControlRig.RigUnit_SetRelativeRotationForItem
// 0x0078 (0x00B0 - 0x0038)
struct FRigUnit_SetRelativeRotationForItem : public FRigUnitMutable
{
	struct FRigElementKey                              Child_69;                                                 // 0x0038(0x0008) (Edit, BlueprintVisible)
	struct FRigElementKey                              Parent_69;                                                // 0x0040(0x0008) (Edit, BlueprintVisible)
	bool                                               bParentInitial_69;                                        // 0x0048(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0049(0x0007) MISSED OFFSET
	struct FQuat                                       Value_69;                                                 // 0x0050(0x0020) (Edit, BlueprintVisible, IsPlainOldData)
	float                                              Weight_69;                                                // 0x0070(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bPropagateToChildren_69;                                  // 0x0074(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x3];                                       // 0x0075(0x0003) MISSED OFFSET
	struct FCachedRigElement                           CachedChild_69;                                           // 0x0078(0x0018)
	struct FCachedRigElement                           CachedParent_69;                                          // 0x0090(0x0018)
	unsigned char                                      UnknownData02[0x8];                                       // 0x00A8(0x0008) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_SetSpaceInitialTransform
// 0x00E8 (0x0120 - 0x0038)
struct FRigUnit_SetSpaceInitialTransform : public FRigUnitMutable
{
	struct FName                                       SpaceName_69;                                             // 0x0038(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x003C(0x0004) MISSED OFFSET
	struct FCoreUObject_FTransform                     Transform_69;                                             // 0x0040(0x0060) (Edit, BlueprintVisible, IsPlainOldData)
	struct FCoreUObject_FTransform                     Result_69;                                                // 0x00A0(0x0060) (BlueprintVisible, BlueprintReadOnly, IsPlainOldData)
	EBoneGetterSetterMode                              Space_69;                                                 // 0x0100(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x7];                                       // 0x0101(0x0007) MISSED OFFSET
	struct FCachedRigElement                           CachedSpaceIndex_69;                                      // 0x0108(0x0018)
};

// ScriptStruct ControlRig.RigUnit_SetSpaceTransform
// 0x0088 (0x00C0 - 0x0038)
struct FRigUnit_SetSpaceTransform : public FRigUnitMutable
{
	struct FName                                       Space_69;                                                 // 0x0038(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              Weight_69;                                                // 0x003C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FCoreUObject_FTransform                     Transform_69;                                             // 0x0040(0x0060) (Edit, BlueprintVisible, IsPlainOldData)
	EBoneGetterSetterMode                              SpaceType_69;                                             // 0x00A0(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x00A1(0x0007) MISSED OFFSET
	struct FCachedRigElement                           CachedSpaceIndex_69;                                      // 0x00A8(0x0018)
};

// ScriptStruct ControlRig.RigUnit_SetTransform
// 0x0098 (0x00D0 - 0x0038)
struct FRigUnit_SetTransform : public FRigUnitMutable
{
	struct FRigElementKey                              Item_69;                                                  // 0x0038(0x0008) (Edit, BlueprintVisible)
	EBoneGetterSetterMode                              Space_69;                                                 // 0x0040(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bInitial_69;                                              // 0x0041(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0xE];                                       // 0x0042(0x000E) MISSED OFFSET
	struct FCoreUObject_FTransform                     Value_69;                                                 // 0x0050(0x0060) (Edit, BlueprintVisible, IsPlainOldData)
	float                                              Weight_69;                                                // 0x00B0(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bPropagateToChildren_69;                                  // 0x00B4(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x3];                                       // 0x00B5(0x0003) MISSED OFFSET
	struct FCachedRigElement                           CachedIndex_69;                                           // 0x00B8(0x0018)
};

// ScriptStruct ControlRig.RigUnit_SetTranslation
// 0x0048 (0x0080 - 0x0038)
struct FRigUnit_SetTranslation : public FRigUnitMutable
{
	struct FRigElementKey                              Item_69;                                                  // 0x0038(0x0008) (Edit, BlueprintVisible)
	EBoneGetterSetterMode                              Space_69;                                                 // 0x0040(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bInitial_69;                                              // 0x0041(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x6];                                       // 0x0042(0x0006) MISSED OFFSET
	struct FVector                                     Value_69;                                                 // 0x0048(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              Weight_69;                                                // 0x0060(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bPropagateToChildren_69;                                  // 0x0064(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x3];                                       // 0x0065(0x0003) MISSED OFFSET
	struct FCachedRigElement                           CachedIndex_69;                                           // 0x0068(0x0018)
};

// ScriptStruct ControlRig.RigUnit_SetRotation
// 0x0058 (0x0090 - 0x0038)
struct FRigUnit_SetRotation : public FRigUnitMutable
{
	struct FRigElementKey                              Item_69;                                                  // 0x0038(0x0008) (Edit, BlueprintVisible)
	EBoneGetterSetterMode                              Space_69;                                                 // 0x0040(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bInitial_69;                                              // 0x0041(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0xE];                                       // 0x0042(0x000E) MISSED OFFSET
	struct FQuat                                       Value_69;                                                 // 0x0050(0x0020) (Edit, BlueprintVisible, IsPlainOldData)
	float                                              Weight_69;                                                // 0x0070(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bPropagateToChildren_69;                                  // 0x0074(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x3];                                       // 0x0075(0x0003) MISSED OFFSET
	struct FCachedRigElement                           CachedIndex_69;                                           // 0x0078(0x0018)
};

// ScriptStruct ControlRig.RigUnit_SetScale
// 0x0048 (0x0080 - 0x0038)
struct FRigUnit_SetScale : public FRigUnitMutable
{
	struct FRigElementKey                              Item_69;                                                  // 0x0038(0x0008) (Edit, BlueprintVisible)
	EBoneGetterSetterMode                              Space_69;                                                 // 0x0040(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bInitial_69;                                              // 0x0041(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x6];                                       // 0x0042(0x0006) MISSED OFFSET
	struct FVector                                     Scale_69;                                                 // 0x0048(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              Weight_69;                                                // 0x0060(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bPropagateToChildren_69;                                  // 0x0064(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x3];                                       // 0x0065(0x0003) MISSED OFFSET
	struct FCachedRigElement                           CachedIndex_69;                                           // 0x0068(0x0018)
};

// ScriptStruct ControlRig.RigUnit_SetTransformArray
// 0x0040 (0x0078 - 0x0038)
struct FRigUnit_SetTransformArray : public FRigUnitMutable
{
	struct FRigElementKeyCollection                    Items_69;                                                 // 0x0038(0x0010) (Edit, BlueprintVisible)
	EBoneGetterSetterMode                              Space_69;                                                 // 0x0048(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bInitial_69;                                              // 0x0049(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x6];                                       // 0x004A(0x0006) MISSED OFFSET
	TArray<struct FCoreUObject_FTransform>             Transforms_69;                                            // 0x0050(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	float                                              Weight_69;                                                // 0x0060(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bPropagateToChildren_69;                                  // 0x0064(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x3];                                       // 0x0065(0x0003) MISSED OFFSET
	TArray<struct FCachedRigElement>                   CachedIndex_69;                                           // 0x0068(0x0010) (ZeroConstructor)
};

// ScriptStruct ControlRig.RigUnit_SetTransformItemArray
// 0x0040 (0x0078 - 0x0038)
struct FRigUnit_SetTransformItemArray : public FRigUnitMutable
{
	TArray<struct FRigElementKey>                      Items_69;                                                 // 0x0038(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	EBoneGetterSetterMode                              Space_69;                                                 // 0x0048(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bInitial_69;                                              // 0x0049(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x6];                                       // 0x004A(0x0006) MISSED OFFSET
	TArray<struct FCoreUObject_FTransform>             Transforms_69;                                            // 0x0050(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	float                                              Weight_69;                                                // 0x0060(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bPropagateToChildren_69;                                  // 0x0064(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x3];                                       // 0x0065(0x0003) MISSED OFFSET
	TArray<struct FCachedRigElement>                   CachedIndex_69;                                           // 0x0068(0x0010) (ZeroConstructor)
};

// ScriptStruct ControlRig.RigUnit_UnsetCurveValue
// 0x0020 (0x0058 - 0x0038)
struct FRigUnit_UnsetCurveValue : public FRigUnitMutable
{
	struct FName                                       Curve_69;                                                 // 0x0038(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x003C(0x0004) MISSED OFFSET
	struct FCachedRigElement                           CachedCurveIndex_69;                                      // 0x0040(0x0018)
};

// ScriptStruct ControlRig.RigUnit_ToWorldSpace_Transform
// 0x00C8 (0x00D0 - 0x0008)
struct FRigUnit_ToWorldSpace_Transform : public FRigUnit
{
	unsigned char                                      UnknownData00[0x8];                                       // 0x0008(0x0008) MISSED OFFSET
	struct FCoreUObject_FTransform                     Value_69;                                                 // 0x0010(0x0060) (Edit, BlueprintVisible, IsPlainOldData)
	struct FCoreUObject_FTransform                     World_69;                                                 // 0x0070(0x0060) (BlueprintVisible, BlueprintReadOnly, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_ToRigSpace_Transform
// 0x00C8 (0x00D0 - 0x0008)
struct FRigUnit_ToRigSpace_Transform : public FRigUnit
{
	unsigned char                                      UnknownData00[0x8];                                       // 0x0008(0x0008) MISSED OFFSET
	struct FCoreUObject_FTransform                     Value_69;                                                 // 0x0010(0x0060) (Edit, BlueprintVisible, IsPlainOldData)
	struct FCoreUObject_FTransform                     Global_69;                                                // 0x0070(0x0060) (BlueprintVisible, BlueprintReadOnly, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_ToWorldSpace_Location
// 0x0030 (0x0038 - 0x0008)
struct FRigUnit_ToWorldSpace_Location : public FRigUnit
{
	struct FVector                                     Value_69;                                                 // 0x0008(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FVector                                     World_69;                                                 // 0x0020(0x0018) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_ToRigSpace_Location
// 0x0030 (0x0038 - 0x0008)
struct FRigUnit_ToRigSpace_Location : public FRigUnit
{
	struct FVector                                     Value_69;                                                 // 0x0008(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FVector                                     Global_69;                                                // 0x0020(0x0018) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_ToWorldSpace_Rotation
// 0x0048 (0x0050 - 0x0008)
struct FRigUnit_ToWorldSpace_Rotation : public FRigUnit
{
	unsigned char                                      UnknownData00[0x8];                                       // 0x0008(0x0008) MISSED OFFSET
	struct FQuat                                       Value_69;                                                 // 0x0010(0x0020) (Edit, BlueprintVisible, IsPlainOldData)
	struct FQuat                                       World_69;                                                 // 0x0030(0x0020) (BlueprintVisible, BlueprintReadOnly, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_ToRigSpace_Rotation
// 0x0048 (0x0050 - 0x0008)
struct FRigUnit_ToRigSpace_Rotation : public FRigUnit
{
	unsigned char                                      UnknownData00[0x8];                                       // 0x0008(0x0008) MISSED OFFSET
	struct FQuat                                       Value_69;                                                 // 0x0010(0x0020) (Edit, BlueprintVisible, IsPlainOldData)
	struct FQuat                                       Global_69;                                                // 0x0030(0x0020) (BlueprintVisible, BlueprintReadOnly, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_BoneHarmonics_BoneTarget
// 0x0008
struct FRigUnit_BoneHarmonics_BoneTarget
{
	struct FName                                       bone_69;                                                  // 0x0000(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              Ratio_69;                                                 // 0x0004(0x0004) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_Harmonics_TargetItem
// 0x000C
struct FRigUnit_Harmonics_TargetItem
{
	struct FRigElementKey                              Item_69;                                                  // 0x0000(0x0008) (Edit, BlueprintVisible)
	float                                              Ratio_69;                                                 // 0x0008(0x0004) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_BoneHarmonics_WorkData
// 0x0028
struct FRigUnit_BoneHarmonics_WorkData
{
	TArray<struct FCachedRigElement>                   CachedItems_69;                                           // 0x0000(0x0010) (ZeroConstructor)
	struct FVector                                     WaveTime_69;                                              // 0x0010(0x0018) (ZeroConstructor, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_BoneHarmonics
// 0x00C0 (0x00F8 - 0x0038)
struct FRigUnit_BoneHarmonics : public FRigUnit_HighlevelBaseMutable
{
	TArray<struct FRigUnit_BoneHarmonics_BoneTarget>   Bones_69;                                                 // 0x0038(0x0010) (Edit, BlueprintVisible, ZeroConstructor, EditConst)
	struct FVector                                     WaveSpeed_69;                                             // 0x0048(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FVector                                     WaveFrequency_69;                                         // 0x0060(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FVector                                     WaveAmplitude_69;                                         // 0x0078(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FVector                                     WaveOffset_69;                                            // 0x0090(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FVector                                     WaveNoise_69;                                             // 0x00A8(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	EControlRigAnimEasingType                          WaveEase_69;                                              // 0x00C0(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x00C1(0x0003) MISSED OFFSET
	float                                              WaveMinimum_69;                                           // 0x00C4(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              WaveMaximum_69;                                           // 0x00C8(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	EEulerRotationOrder                                RotationOrder_69;                                         // 0x00CC(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bPropagateToChildren_69;                                  // 0x00CD(0x0001) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	unsigned char                                      UnknownData01[0x2];                                       // 0x00CE(0x0002) MISSED OFFSET
	struct FRigUnit_BoneHarmonics_WorkData             WorkData_69;                                              // 0x00D0(0x0028) (Transient)
};

// ScriptStruct ControlRig.RigUnit_ItemHarmonics
// 0x00C0 (0x00F8 - 0x0038)
struct FRigUnit_ItemHarmonics : public FRigUnit_HighlevelBaseMutable
{
	TArray<struct FRigUnit_Harmonics_TargetItem>       Targets_69;                                               // 0x0038(0x0010) (Edit, BlueprintVisible, ZeroConstructor, EditConst)
	struct FVector                                     WaveSpeed_69;                                             // 0x0048(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FVector                                     WaveFrequency_69;                                         // 0x0060(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FVector                                     WaveAmplitude_69;                                         // 0x0078(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FVector                                     WaveOffset_69;                                            // 0x0090(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FVector                                     WaveNoise_69;                                             // 0x00A8(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	EControlRigAnimEasingType                          WaveEase_69;                                              // 0x00C0(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x00C1(0x0003) MISSED OFFSET
	float                                              WaveMinimum_69;                                           // 0x00C4(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              WaveMaximum_69;                                           // 0x00C8(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	EEulerRotationOrder                                RotationOrder_69;                                         // 0x00CC(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x3];                                       // 0x00CD(0x0003) MISSED OFFSET
	struct FRigUnit_BoneHarmonics_WorkData             WorkData_69;                                              // 0x00D0(0x0028) (Transient)
};

// ScriptStruct ControlRig.RigUnit_ChainHarmonics_Reach
// 0x0048
struct FRigUnit_ChainHarmonics_Reach
{
	bool                                               bEnabled_69;                                              // 0x0000(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0001(0x0007) MISSED OFFSET
	struct FVector                                     ReachTarget_69;                                           // 0x0008(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FVector                                     ReachAxis_69;                                             // 0x0020(0x0018) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	float                                              ReachMinimum_69;                                          // 0x0038(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              ReachMaximum_69;                                          // 0x003C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	EControlRigAnimEasingType                          ReachEase_69;                                             // 0x0040(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x7];                                       // 0x0041(0x0007) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_ChainHarmonics_Wave
// 0x0078
struct FRigUnit_ChainHarmonics_Wave
{
	bool                                               bEnabled_69;                                              // 0x0000(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0001(0x0007) MISSED OFFSET
	struct FVector                                     WaveFrequency_69;                                         // 0x0008(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FVector                                     WaveAmplitude_69;                                         // 0x0020(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FVector                                     WaveOffset_69;                                            // 0x0038(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FVector                                     WaveNoise_69;                                             // 0x0050(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              WaveMinimum_69;                                           // 0x0068(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              WaveMaximum_69;                                           // 0x006C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	EControlRigAnimEasingType                          WaveEase_69;                                              // 0x0070(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x7];                                       // 0x0071(0x0007) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_ChainHarmonics_Pendulum
// 0x0058
struct FRigUnit_ChainHarmonics_Pendulum
{
	bool                                               bEnabled_69;                                              // 0x0000(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0001(0x0003) MISSED OFFSET
	float                                              PendulumStiffness_69;                                     // 0x0004(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FVector                                     PendulumGravity_69;                                       // 0x0008(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              PendulumBlend_69;                                         // 0x0020(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              PendulumDrag_69;                                          // 0x0024(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              PendulumMinimum_69;                                       // 0x0028(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              PendulumMaximum_69;                                       // 0x002C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	EControlRigAnimEasingType                          PendulumEase_69;                                          // 0x0030(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x7];                                       // 0x0031(0x0007) MISSED OFFSET
	struct FVector                                     UnwindAxis_69;                                            // 0x0038(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              UnwindMinimum_69;                                         // 0x0050(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              UnwindMaximum_69;                                         // 0x0054(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_ChainHarmonics_WorkData
// 0x0098
struct FRigUnit_ChainHarmonics_WorkData
{
	struct FVector                                     Time_69;                                                  // 0x0000(0x0018) (ZeroConstructor, IsPlainOldData)
	TArray<struct FCachedRigElement>                   Items_69;                                                 // 0x0018(0x0010) (ZeroConstructor)
	TArray<float>                                      Ratio_69;                                                 // 0x0028(0x0010) (ZeroConstructor)
	TArray<struct FVector>                             LocalTip_69;                                              // 0x0038(0x0010) (ZeroConstructor)
	TArray<struct FVector>                             PendulumTip_69;                                           // 0x0048(0x0010) (ZeroConstructor)
	TArray<struct FVector>                             PendulumPosition_69;                                      // 0x0058(0x0010) (ZeroConstructor)
	TArray<struct FVector>                             PendulumVelocity_69;                                      // 0x0068(0x0010) (ZeroConstructor)
	TArray<struct FVector>                             HierarchyLine_69;                                         // 0x0078(0x0010) (ZeroConstructor)
	TArray<struct FVector>                             VelocityLines_69;                                         // 0x0088(0x0010) (ZeroConstructor)
};

// ScriptStruct ControlRig.RigUnit_ChainHarmonics
// 0x02C8 (0x0300 - 0x0038)
struct FRigUnit_ChainHarmonics : public FRigUnit_HighlevelBaseMutable
{
	struct FName                                       ChainRoot_69;                                             // 0x0038(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x003C(0x0004) MISSED OFFSET
	struct FVector                                     Speed_69;                                                 // 0x0040(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FRigUnit_ChainHarmonics_Reach               Reach_69;                                                 // 0x0058(0x0048) (Edit, BlueprintVisible)
	struct FRigUnit_ChainHarmonics_Wave                Wave_69;                                                  // 0x00A0(0x0078) (Edit, BlueprintVisible)
	struct FRuntimeFloatCurve                          WaveCurve_69;                                             // 0x0118(0x0088) (Edit, BlueprintVisible, EditConst)
	struct FRigUnit_ChainHarmonics_Pendulum            Pendulum_69;                                              // 0x01A0(0x0058) (Edit, BlueprintVisible)
	bool                                               bDrawDebug_69;                                            // 0x01F8(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x7];                                       // 0x01F9(0x0007) MISSED OFFSET
	struct FCoreUObject_FTransform                     DrawWorldOffset_69;                                       // 0x0200(0x0060) (Edit, BlueprintVisible, IsPlainOldData)
	struct FRigUnit_ChainHarmonics_WorkData            WorkData_69;                                              // 0x0260(0x0098) (Transient)
	unsigned char                                      UnknownData02[0x8];                                       // 0x02F8(0x0008) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_ChainHarmonicsPerItem
// 0x02C8 (0x0300 - 0x0038)
struct FRigUnit_ChainHarmonicsPerItem : public FRigUnit_HighlevelBaseMutable
{
	struct FRigElementKey                              ChainRoot_69;                                             // 0x0038(0x0008) (Edit, BlueprintVisible)
	struct FVector                                     Speed_69;                                                 // 0x0040(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FRigUnit_ChainHarmonics_Reach               Reach_69;                                                 // 0x0058(0x0048) (Edit, BlueprintVisible)
	struct FRigUnit_ChainHarmonics_Wave                Wave_69;                                                  // 0x00A0(0x0078) (Edit, BlueprintVisible)
	struct FRuntimeFloatCurve                          WaveCurve_69;                                             // 0x0118(0x0088) (Edit, BlueprintVisible, EditConst)
	struct FRigUnit_ChainHarmonics_Pendulum            Pendulum_69;                                              // 0x01A0(0x0058) (Edit, BlueprintVisible)
	bool                                               bDrawDebug_69;                                            // 0x01F8(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x01F9(0x0007) MISSED OFFSET
	struct FCoreUObject_FTransform                     DrawWorldOffset_69;                                       // 0x0200(0x0060) (Edit, BlueprintVisible, IsPlainOldData)
	struct FRigUnit_ChainHarmonics_WorkData            WorkData_69;                                              // 0x0260(0x0098) (Transient)
	unsigned char                                      UnknownData01[0x8];                                       // 0x02F8(0x0008) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_AimBone_Target
// 0x0040
struct FRigUnit_AimBone_Target
{
	float                                              Weight_69;                                                // 0x0000(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0004(0x0004) MISSED OFFSET
	struct FVector                                     Axis_69;                                                  // 0x0008(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FVector                                     Target_69;                                                // 0x0020(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	EControlRigVectorKind                              Kind_69;                                                  // 0x0038(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x3];                                       // 0x0039(0x0003) MISSED OFFSET
	struct FName                                       Space_69;                                                 // 0x003C(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_AimItem_Target
// 0x0048
struct FRigUnit_AimItem_Target
{
	float                                              Weight_69;                                                // 0x0000(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0004(0x0004) MISSED OFFSET
	struct FVector                                     Axis_69;                                                  // 0x0008(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FVector                                     Target_69;                                                // 0x0020(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	EControlRigVectorKind                              Kind_69;                                                  // 0x0038(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x3];                                       // 0x0039(0x0003) MISSED OFFSET
	struct FRigElementKey                              Space_69;                                                 // 0x003C(0x0008) (Edit, BlueprintVisible)
	unsigned char                                      UnknownData02[0x4];                                       // 0x0044(0x0004) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_AimBone_DebugSettings
// 0x0070
struct FRigUnit_AimBone_DebugSettings
{
	bool                                               bEnabled_69;                                              // 0x0000(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0001(0x0003) MISSED OFFSET
	float                                              Scale_69;                                                 // 0x0004(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x8];                                       // 0x0008(0x0008) MISSED OFFSET
	struct FCoreUObject_FTransform                     WorldOffset_69;                                           // 0x0010(0x0060) (Edit, BlueprintVisible, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_AimBoneMath
// 0x0208 (0x0210 - 0x0008)
struct FRigUnit_AimBoneMath : public FRigUnit_HighlevelBase
{
	unsigned char                                      UnknownData00[0x8];                                       // 0x0008(0x0008) MISSED OFFSET
	struct FCoreUObject_FTransform                     InputTransform_69;                                        // 0x0010(0x0060) (Edit, BlueprintVisible, IsPlainOldData)
	struct FRigUnit_AimItem_Target                     Primary_69;                                               // 0x0070(0x0048) (Edit, BlueprintVisible)
	struct FRigUnit_AimItem_Target                     Secondary_69;                                             // 0x00B8(0x0048) (Edit, BlueprintVisible)
	float                                              Weight_69;                                                // 0x0100(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0xC];                                       // 0x0104(0x000C) MISSED OFFSET
	struct FCoreUObject_FTransform                     Result_69;                                                // 0x0110(0x0060) (BlueprintVisible, BlueprintReadOnly, IsPlainOldData)
	struct FRigUnit_AimBone_DebugSettings              DebugSettings_69;                                         // 0x0170(0x0070) (Edit, BlueprintVisible)
	struct FCachedRigElement                           PrimaryCachedSpace_69;                                    // 0x01E0(0x0018)
	struct FCachedRigElement                           SecondaryCachedSpace_69;                                  // 0x01F8(0x0018)
};

// ScriptStruct ControlRig.RigUnit_AimBone
// 0x0158 (0x0190 - 0x0038)
struct FRigUnit_AimBone : public FRigUnit_HighlevelBaseMutable
{
	struct FName                                       bone_69;                                                  // 0x0038(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x003C(0x0004) MISSED OFFSET
	struct FRigUnit_AimBone_Target                     Primary_69;                                               // 0x0040(0x0040) (Edit, BlueprintVisible)
	struct FRigUnit_AimBone_Target                     Secondary_69;                                             // 0x0080(0x0040) (Edit, BlueprintVisible)
	float                                              Weight_69;                                                // 0x00C0(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bPropagateToChildren_69;                                  // 0x00C4(0x0001) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	unsigned char                                      UnknownData01[0xB];                                       // 0x00C5(0x000B) MISSED OFFSET
	struct FRigUnit_AimBone_DebugSettings              DebugSettings_69;                                         // 0x00D0(0x0070) (Edit, BlueprintVisible)
	struct FCachedRigElement                           CachedBoneIndex_69;                                       // 0x0140(0x0018)
	struct FCachedRigElement                           PrimaryCachedSpace_69;                                    // 0x0158(0x0018)
	struct FCachedRigElement                           SecondaryCachedSpace_69;                                  // 0x0170(0x0018)
	unsigned char                                      UnknownData02[0x8];                                       // 0x0188(0x0008) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_AimItem
// 0x0168 (0x01A0 - 0x0038)
struct FRigUnit_AimItem : public FRigUnit_HighlevelBaseMutable
{
	struct FRigElementKey                              Item_69;                                                  // 0x0038(0x0008) (Edit, BlueprintVisible)
	struct FRigUnit_AimItem_Target                     Primary_69;                                               // 0x0040(0x0048) (Edit, BlueprintVisible)
	struct FRigUnit_AimItem_Target                     Secondary_69;                                             // 0x0088(0x0048) (Edit, BlueprintVisible)
	float                                              Weight_69;                                                // 0x00D0(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0xC];                                       // 0x00D4(0x000C) MISSED OFFSET
	struct FRigUnit_AimBone_DebugSettings              DebugSettings_69;                                         // 0x00E0(0x0070) (Edit, BlueprintVisible)
	struct FCachedRigElement                           CachedItem_69;                                            // 0x0150(0x0018)
	struct FCachedRigElement                           PrimaryCachedSpace_69;                                    // 0x0168(0x0018)
	struct FCachedRigElement                           SecondaryCachedSpace_69;                                  // 0x0180(0x0018)
	unsigned char                                      UnknownData01[0x8];                                       // 0x0198(0x0008) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_AimConstraint_WorldUp
// 0x0028
struct FRigUnit_AimConstraint_WorldUp
{
	struct FVector                                     Target_69;                                                // 0x0000(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	EControlRigVectorKind                              Kind_69;                                                  // 0x0018(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0019(0x0003) MISSED OFFSET
	struct FRigElementKey                              Space_69;                                                 // 0x001C(0x0008) (Edit, BlueprintVisible)
	unsigned char                                      UnknownData01[0x4];                                       // 0x0024(0x0004) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_AimConstraint_AdvancedSettings
// 0x0080
struct FRigUnit_AimConstraint_AdvancedSettings
{
	struct FRigUnit_AimBone_DebugSettings              DebugSettings_69;                                         // 0x0000(0x0070) (Edit, BlueprintVisible)
	EEulerRotationOrder                                RotationOrderForFilter_69;                                // 0x0070(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0xF];                                       // 0x0071(0x000F) MISSED OFFSET
};

// ScriptStruct ControlRig.ConstraintParent
// 0x000C
struct FConstraintParent
{
	struct FRigElementKey                              Item_69;                                                  // 0x0000(0x0008) (Edit, BlueprintVisible)
	float                                              Weight_69;                                                // 0x0008(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_AimConstraintLocalSpaceOffset
// 0x0148 (0x0180 - 0x0038)
struct FRigUnit_AimConstraintLocalSpaceOffset : public FRigUnit_HighlevelBaseMutable
{
	struct FRigElementKey                              Child_69;                                                 // 0x0038(0x0008) (Edit, BlueprintVisible)
	bool                                               bMaintainOffset_69;                                       // 0x0040(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FFilterOptionPerAxis                        Filter_69;                                                // 0x0041(0x0003) (Edit, BlueprintVisible)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0044(0x0004) MISSED OFFSET
	struct FVector                                     AimAxis_69;                                               // 0x0048(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FVector                                     UpAxis_69;                                                // 0x0060(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FRigUnit_AimConstraint_WorldUp              WorldUp_69;                                               // 0x0078(0x0028) (Edit, BlueprintVisible)
	TArray<struct FConstraintParent>                   Parents_69;                                               // 0x00A0(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FRigUnit_AimConstraint_AdvancedSettings     AdvancedSettings_69;                                      // 0x00B0(0x0080) (Edit, BlueprintVisible)
	float                                              Weight_69;                                                // 0x0130(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x4];                                       // 0x0134(0x0004) MISSED OFFSET
	struct FCachedRigElement                           WorldUpSpaceCache_69;                                     // 0x0138(0x0018)
	struct FCachedRigElement                           ChildCache_69;                                            // 0x0150(0x0018)
	TArray<struct FCachedRigElement>                   ParentCaches_69;                                          // 0x0168(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData02[0x8];                                       // 0x0178(0x0008) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_CCDIK_RotationLimit
// 0x0008
struct FRigUnit_CCDIK_RotationLimit
{
	struct FName                                       bone_69;                                                  // 0x0000(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              Limit_69;                                                 // 0x0004(0x0004) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_CCDIK_RotationLimitPerItem
// 0x000C
struct FRigUnit_CCDIK_RotationLimitPerItem
{
	struct FRigElementKey                              Item_69;                                                  // 0x0000(0x0008) (Edit, BlueprintVisible)
	float                                              Limit_69;                                                 // 0x0008(0x0004) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_CCDIK_WorkData
// 0x0058
struct FRigUnit_CCDIK_WorkData
{
	TArray<struct FCCDIKChainLink>                     Chain_69;                                                 // 0x0000(0x0010) (ZeroConstructor)
	TArray<struct FCachedRigElement>                   CachedItems_69;                                           // 0x0010(0x0010) (ZeroConstructor)
	TArray<int>                                        RotationLimitIndex_69;                                    // 0x0020(0x0010) (ZeroConstructor)
	TArray<float>                                      RotationLimitsPerItem_69;                                 // 0x0030(0x0010) (ZeroConstructor)
	struct FCachedRigElement                           CachedEffector_69;                                        // 0x0040(0x0018)
};

// ScriptStruct ControlRig.RigUnit_CCDIK
// 0x00F8 (0x0130 - 0x0038)
struct FRigUnit_CCDIK : public FRigUnit_HighlevelBaseMutable
{
	struct FName                                       StartBone_69;                                             // 0x0038(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FName                                       EffectorBone_69;                                          // 0x003C(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FCoreUObject_FTransform                     EffectorTransform_69;                                     // 0x0040(0x0060) (Edit, BlueprintVisible, IsPlainOldData)
	float                                              Precision_69;                                             // 0x00A0(0x0004) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	float                                              Weight_69;                                                // 0x00A4(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                MaxIterations_69;                                         // 0x00A8(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bStartFromTail_69;                                        // 0x00AC(0x0001) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x00AD(0x0003) MISSED OFFSET
	float                                              BaseRotationLimit_69;                                     // 0x00B0(0x0004) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	unsigned char                                      UnknownData01[0x4];                                       // 0x00B4(0x0004) MISSED OFFSET
	TArray<struct FRigUnit_CCDIK_RotationLimit>        RotationLimits_69;                                        // 0x00B8(0x0010) (Edit, BlueprintVisible, ZeroConstructor, EditConst)
	bool                                               bPropagateToChildren_69;                                  // 0x00C8(0x0001) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	unsigned char                                      UnknownData02[0x7];                                       // 0x00C9(0x0007) MISSED OFFSET
	struct FRigUnit_CCDIK_WorkData                     WorkData_69;                                              // 0x00D0(0x0058)
	unsigned char                                      UnknownData03[0x8];                                       // 0x0128(0x0008) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_CCDIKPerItem
// 0x0108 (0x0140 - 0x0038)
struct FRigUnit_CCDIKPerItem : public FRigUnit_HighlevelBaseMutable
{
	struct FRigElementKeyCollection                    Items_69;                                                 // 0x0038(0x0010) (Edit, BlueprintVisible)
	unsigned char                                      UnknownData00[0x8];                                       // 0x0048(0x0008) MISSED OFFSET
	struct FCoreUObject_FTransform                     EffectorTransform_69;                                     // 0x0050(0x0060) (Edit, BlueprintVisible, IsPlainOldData)
	float                                              Precision_69;                                             // 0x00B0(0x0004) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	float                                              Weight_69;                                                // 0x00B4(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                MaxIterations_69;                                         // 0x00B8(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bStartFromTail_69;                                        // 0x00BC(0x0001) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	unsigned char                                      UnknownData01[0x3];                                       // 0x00BD(0x0003) MISSED OFFSET
	float                                              BaseRotationLimit_69;                                     // 0x00C0(0x0004) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	unsigned char                                      UnknownData02[0x4];                                       // 0x00C4(0x0004) MISSED OFFSET
	TArray<struct FRigUnit_CCDIK_RotationLimitPerItem> RotationLimits_69;                                        // 0x00C8(0x0010) (Edit, BlueprintVisible, ZeroConstructor, EditConst)
	bool                                               bPropagateToChildren_69;                                  // 0x00D8(0x0001) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	unsigned char                                      UnknownData03[0x7];                                       // 0x00D9(0x0007) MISSED OFFSET
	struct FRigUnit_CCDIK_WorkData                     WorkData_69;                                              // 0x00E0(0x0058)
	unsigned char                                      UnknownData04[0x8];                                       // 0x0138(0x0008) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_CCDIKItemArray
// 0x0108 (0x0140 - 0x0038)
struct FRigUnit_CCDIKItemArray : public FRigUnit_HighlevelBaseMutable
{
	TArray<struct FRigElementKey>                      Items_69;                                                 // 0x0038(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	unsigned char                                      UnknownData00[0x8];                                       // 0x0048(0x0008) MISSED OFFSET
	struct FCoreUObject_FTransform                     EffectorTransform_69;                                     // 0x0050(0x0060) (Edit, BlueprintVisible, IsPlainOldData)
	float                                              Precision_69;                                             // 0x00B0(0x0004) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	float                                              Weight_69;                                                // 0x00B4(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                MaxIterations_69;                                         // 0x00B8(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bStartFromTail_69;                                        // 0x00BC(0x0001) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	unsigned char                                      UnknownData01[0x3];                                       // 0x00BD(0x0003) MISSED OFFSET
	float                                              BaseRotationLimit_69;                                     // 0x00C0(0x0004) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	unsigned char                                      UnknownData02[0x4];                                       // 0x00C4(0x0004) MISSED OFFSET
	TArray<struct FRigUnit_CCDIK_RotationLimitPerItem> RotationLimits_69;                                        // 0x00C8(0x0010) (Edit, BlueprintVisible, ZeroConstructor, EditConst)
	bool                                               bPropagateToChildren_69;                                  // 0x00D8(0x0001) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	unsigned char                                      UnknownData03[0x7];                                       // 0x00D9(0x0007) MISSED OFFSET
	struct FRigUnit_CCDIK_WorkData                     WorkData_69;                                              // 0x00E0(0x0058)
	unsigned char                                      UnknownData04[0x8];                                       // 0x0138(0x0008) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_DistributeRotation_Rotation
// 0x0030
struct FRigUnit_DistributeRotation_Rotation
{
	struct FQuat                                       Rotation_69;                                              // 0x0000(0x0020) (Edit, BlueprintVisible, IsPlainOldData)
	float                                              Ratio_69;                                                 // 0x0020(0x0004) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	unsigned char                                      UnknownData00[0xC];                                       // 0x0024(0x000C) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_DistributeRotation_WorkData
// 0x0050
struct FRigUnit_DistributeRotation_WorkData
{
	TArray<struct FCachedRigElement>                   CachedItems_69;                                           // 0x0000(0x0010) (ZeroConstructor)
	TArray<int>                                        ItemRotationA_69;                                         // 0x0010(0x0010) (ZeroConstructor)
	TArray<int>                                        ItemRotationB_69;                                         // 0x0020(0x0010) (ZeroConstructor)
	TArray<float>                                      ItemRotationT_69;                                         // 0x0030(0x0010) (ZeroConstructor)
	TArray<struct FCoreUObject_FTransform>             ItemLocalTransforms_69;                                   // 0x0040(0x0010) (ZeroConstructor)
};

// ScriptStruct ControlRig.RigUnit_DistributeRotation
// 0x0078 (0x00B0 - 0x0038)
struct FRigUnit_DistributeRotation : public FRigUnit_HighlevelBaseMutable
{
	struct FName                                       StartBone_69;                                             // 0x0038(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FName                                       EndBone_69;                                               // 0x003C(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	TArray<struct FRigUnit_DistributeRotation_Rotation> Rotations_69;                                             // 0x0040(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	EControlRigAnimEasingType                          RotationEaseType_69;                                      // 0x0050(0x0001) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0051(0x0003) MISSED OFFSET
	float                                              Weight_69;                                                // 0x0054(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bPropagateToChildren_69;                                  // 0x0058(0x0001) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	unsigned char                                      UnknownData01[0x7];                                       // 0x0059(0x0007) MISSED OFFSET
	struct FRigUnit_DistributeRotation_WorkData        WorkData_69;                                              // 0x0060(0x0050) (Transient)
};

// ScriptStruct ControlRig.RigUnit_DistributeRotationForCollection
// 0x0078 (0x00B0 - 0x0038)
struct FRigUnit_DistributeRotationForCollection : public FRigUnit_HighlevelBaseMutable
{
	struct FRigElementKeyCollection                    Items_69;                                                 // 0x0038(0x0010) (Edit, BlueprintVisible)
	TArray<struct FRigUnit_DistributeRotation_Rotation> Rotations_69;                                             // 0x0048(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	EControlRigAnimEasingType                          RotationEaseType_69;                                      // 0x0058(0x0001) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0059(0x0003) MISSED OFFSET
	float                                              Weight_69;                                                // 0x005C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FRigUnit_DistributeRotation_WorkData        WorkData_69;                                              // 0x0060(0x0050) (Transient)
};

// ScriptStruct ControlRig.RigUnit_DistributeRotationForItemArray
// 0x0078 (0x00B0 - 0x0038)
struct FRigUnit_DistributeRotationForItemArray : public FRigUnit_HighlevelBaseMutable
{
	TArray<struct FRigElementKey>                      Items_69;                                                 // 0x0038(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	TArray<struct FRigUnit_DistributeRotation_Rotation> Rotations_69;                                             // 0x0048(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	EControlRigAnimEasingType                          RotationEaseType_69;                                      // 0x0058(0x0001) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0059(0x0003) MISSED OFFSET
	float                                              Weight_69;                                                // 0x005C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FRigUnit_DistributeRotation_WorkData        WorkData_69;                                              // 0x0060(0x0050) (Transient)
};

// ScriptStruct ControlRig.RigUnit_FABRIK_WorkData
// 0x0038
struct FRigUnit_FABRIK_WorkData
{
	TArray<struct FFABRIKChainLink>                    Chain_69;                                                 // 0x0000(0x0010) (ZeroConstructor)
	TArray<struct FCachedRigElement>                   CachedItems_69;                                           // 0x0010(0x0010) (ZeroConstructor)
	struct FCachedRigElement                           CachedEffector_69;                                        // 0x0020(0x0018)
};

// ScriptStruct ControlRig.RigUnit_FABRIK
// 0x00B8 (0x00F0 - 0x0038)
struct FRigUnit_FABRIK : public FRigUnit_HighlevelBaseMutable
{
	struct FName                                       StartBone_69;                                             // 0x0038(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FName                                       EffectorBone_69;                                          // 0x003C(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FCoreUObject_FTransform                     EffectorTransform_69;                                     // 0x0040(0x0060) (Edit, BlueprintVisible, IsPlainOldData)
	float                                              Precision_69;                                             // 0x00A0(0x0004) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	float                                              Weight_69;                                                // 0x00A4(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bPropagateToChildren_69;                                  // 0x00A8(0x0001) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x00A9(0x0003) MISSED OFFSET
	int                                                MaxIterations_69;                                         // 0x00AC(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FRigUnit_FABRIK_WorkData                    WorkData_69;                                              // 0x00B0(0x0038) (Transient)
	bool                                               bSetEffectorTransform_69;                                 // 0x00E8(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x7];                                       // 0x00E9(0x0007) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_FABRIKPerItem
// 0x00C8 (0x0100 - 0x0038)
struct FRigUnit_FABRIKPerItem : public FRigUnit_HighlevelBaseMutable
{
	struct FRigElementKeyCollection                    Items_69;                                                 // 0x0038(0x0010) (Edit, BlueprintVisible)
	unsigned char                                      UnknownData00[0x8];                                       // 0x0048(0x0008) MISSED OFFSET
	struct FCoreUObject_FTransform                     EffectorTransform_69;                                     // 0x0050(0x0060) (Edit, BlueprintVisible, IsPlainOldData)
	float                                              Precision_69;                                             // 0x00B0(0x0004) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	float                                              Weight_69;                                                // 0x00B4(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bPropagateToChildren_69;                                  // 0x00B8(0x0001) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	unsigned char                                      UnknownData01[0x3];                                       // 0x00B9(0x0003) MISSED OFFSET
	int                                                MaxIterations_69;                                         // 0x00BC(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FRigUnit_FABRIK_WorkData                    WorkData_69;                                              // 0x00C0(0x0038) (Transient)
	bool                                               bSetEffectorTransform_69;                                 // 0x00F8(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData02[0x7];                                       // 0x00F9(0x0007) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_FABRIKItemArray
// 0x00C8 (0x0100 - 0x0038)
struct FRigUnit_FABRIKItemArray : public FRigUnit_HighlevelBaseMutable
{
	TArray<struct FRigElementKey>                      Items_69;                                                 // 0x0038(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	unsigned char                                      UnknownData00[0x8];                                       // 0x0048(0x0008) MISSED OFFSET
	struct FCoreUObject_FTransform                     EffectorTransform_69;                                     // 0x0050(0x0060) (Edit, BlueprintVisible, IsPlainOldData)
	float                                              Precision_69;                                             // 0x00B0(0x0004) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	float                                              Weight_69;                                                // 0x00B4(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bPropagateToChildren_69;                                  // 0x00B8(0x0001) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	unsigned char                                      UnknownData01[0x3];                                       // 0x00B9(0x0003) MISSED OFFSET
	int                                                MaxIterations_69;                                         // 0x00BC(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FRigUnit_FABRIK_WorkData                    WorkData_69;                                              // 0x00C0(0x0038) (Transient)
	bool                                               bSetEffectorTransform_69;                                 // 0x00F8(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData02[0x7];                                       // 0x00F9(0x0007) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_FitChainToCurve_Rotation
// 0x0030
struct FRigUnit_FitChainToCurve_Rotation
{
	struct FQuat                                       Rotation_69;                                              // 0x0000(0x0020) (Edit, BlueprintVisible, IsPlainOldData)
	float                                              Ratio_69;                                                 // 0x0020(0x0004) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	unsigned char                                      UnknownData00[0xC];                                       // 0x0024(0x000C) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_FitChainToCurve_DebugSettings
// 0x0090
struct FRigUnit_FitChainToCurve_DebugSettings
{
	bool                                               bEnabled_69;                                              // 0x0000(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0001(0x0003) MISSED OFFSET
	float                                              Scale_69;                                                 // 0x0004(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FLinearColor                                CurveColor_69;                                            // 0x0008(0x0010) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FLinearColor                                SegmentsColor_69;                                         // 0x0018(0x0010) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x8];                                       // 0x0028(0x0008) MISSED OFFSET
	struct FCoreUObject_FTransform                     WorldOffset_69;                                           // 0x0030(0x0060) (Edit, BlueprintVisible, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_FitChainToCurve_WorkData
// 0x0098
struct FRigUnit_FitChainToCurve_WorkData
{
	float                                              ChainLength_69;                                           // 0x0000(0x0004) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0004(0x0004) MISSED OFFSET
	TArray<struct FVector>                             ItemPositions_69;                                         // 0x0008(0x0010) (ZeroConstructor)
	TArray<float>                                      ItemSegments_69;                                          // 0x0018(0x0010) (ZeroConstructor)
	TArray<struct FVector>                             CurvePositions_69;                                        // 0x0028(0x0010) (ZeroConstructor)
	TArray<float>                                      CurveSegments_69;                                         // 0x0038(0x0010) (ZeroConstructor)
	TArray<struct FCachedRigElement>                   CachedItems_69;                                           // 0x0048(0x0010) (ZeroConstructor)
	TArray<int>                                        ItemRotationA_69;                                         // 0x0058(0x0010) (ZeroConstructor)
	TArray<int>                                        ItemRotationB_69;                                         // 0x0068(0x0010) (ZeroConstructor)
	TArray<float>                                      ItemRotationT_69;                                         // 0x0078(0x0010) (ZeroConstructor)
	TArray<struct FCoreUObject_FTransform>             ItemLocalTransforms_69;                                   // 0x0088(0x0010) (ZeroConstructor)
};

// ScriptStruct ControlRig.RigUnit_FitChainToCurve
// 0x0218 (0x0250 - 0x0038)
struct FRigUnit_FitChainToCurve : public FRigUnit_HighlevelBaseMutable
{
	struct FName                                       StartBone_69;                                             // 0x0038(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FName                                       EndBone_69;                                               // 0x003C(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FCRFourPointBezier                          Bezier_69;                                                // 0x0040(0x0060) (Edit, BlueprintVisible)
	EControlRigCurveAlignment                          Alignment_69;                                             // 0x00A0(0x0001) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x00A1(0x0003) MISSED OFFSET
	float                                              Minimum_69;                                               // 0x00A4(0x0004) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	float                                              Maximum_69;                                               // 0x00A8(0x0004) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	int                                                SamplingPrecision_69;                                     // 0x00AC(0x0004) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	struct FVector                                     PrimaryAxis_69;                                           // 0x00B0(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FVector                                     SecondaryAxis_69;                                         // 0x00C8(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FVector                                     PoleVectorPosition_69;                                    // 0x00E0(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	TArray<struct FRigUnit_FitChainToCurve_Rotation>   Rotations_69;                                             // 0x00F8(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	EControlRigAnimEasingType                          RotationEaseType_69;                                      // 0x0108(0x0001) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	unsigned char                                      UnknownData01[0x3];                                       // 0x0109(0x0003) MISSED OFFSET
	float                                              Weight_69;                                                // 0x010C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bPropagateToChildren_69;                                  // 0x0110(0x0001) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	unsigned char                                      UnknownData02[0xF];                                       // 0x0111(0x000F) MISSED OFFSET
	struct FRigUnit_FitChainToCurve_DebugSettings      DebugSettings_69;                                         // 0x0120(0x0090) (Edit, BlueprintVisible)
	struct FRigUnit_FitChainToCurve_WorkData           WorkData_69;                                              // 0x01B0(0x0098) (Transient)
	unsigned char                                      UnknownData03[0x8];                                       // 0x0248(0x0008) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_FitChainToCurvePerItem
// 0x0218 (0x0250 - 0x0038)
struct FRigUnit_FitChainToCurvePerItem : public FRigUnit_HighlevelBaseMutable
{
	struct FRigElementKeyCollection                    Items_69;                                                 // 0x0038(0x0010) (Edit, BlueprintVisible)
	struct FCRFourPointBezier                          Bezier_69;                                                // 0x0048(0x0060) (Edit, BlueprintVisible)
	EControlRigCurveAlignment                          Alignment_69;                                             // 0x00A8(0x0001) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x00A9(0x0003) MISSED OFFSET
	float                                              Minimum_69;                                               // 0x00AC(0x0004) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	float                                              Maximum_69;                                               // 0x00B0(0x0004) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	int                                                SamplingPrecision_69;                                     // 0x00B4(0x0004) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	struct FVector                                     PrimaryAxis_69;                                           // 0x00B8(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FVector                                     SecondaryAxis_69;                                         // 0x00D0(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FVector                                     PoleVectorPosition_69;                                    // 0x00E8(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	TArray<struct FRigUnit_FitChainToCurve_Rotation>   Rotations_69;                                             // 0x0100(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	EControlRigAnimEasingType                          RotationEaseType_69;                                      // 0x0110(0x0001) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	unsigned char                                      UnknownData01[0x3];                                       // 0x0111(0x0003) MISSED OFFSET
	float                                              Weight_69;                                                // 0x0114(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bPropagateToChildren_69;                                  // 0x0118(0x0001) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	unsigned char                                      UnknownData02[0x7];                                       // 0x0119(0x0007) MISSED OFFSET
	struct FRigUnit_FitChainToCurve_DebugSettings      DebugSettings_69;                                         // 0x0120(0x0090) (Edit, BlueprintVisible)
	struct FRigUnit_FitChainToCurve_WorkData           WorkData_69;                                              // 0x01B0(0x0098) (Transient)
	unsigned char                                      UnknownData03[0x8];                                       // 0x0248(0x0008) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_FitChainToCurveItemArray
// 0x0218 (0x0250 - 0x0038)
struct FRigUnit_FitChainToCurveItemArray : public FRigUnit_HighlevelBaseMutable
{
	TArray<struct FRigElementKey>                      Items_69;                                                 // 0x0038(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FCRFourPointBezier                          Bezier_69;                                                // 0x0048(0x0060) (Edit, BlueprintVisible)
	EControlRigCurveAlignment                          Alignment_69;                                             // 0x00A8(0x0001) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x00A9(0x0003) MISSED OFFSET
	float                                              Minimum_69;                                               // 0x00AC(0x0004) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	float                                              Maximum_69;                                               // 0x00B0(0x0004) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	int                                                SamplingPrecision_69;                                     // 0x00B4(0x0004) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	struct FVector                                     PrimaryAxis_69;                                           // 0x00B8(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FVector                                     SecondaryAxis_69;                                         // 0x00D0(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FVector                                     PoleVectorPosition_69;                                    // 0x00E8(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	TArray<struct FRigUnit_FitChainToCurve_Rotation>   Rotations_69;                                             // 0x0100(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	EControlRigAnimEasingType                          RotationEaseType_69;                                      // 0x0110(0x0001) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	unsigned char                                      UnknownData01[0x3];                                       // 0x0111(0x0003) MISSED OFFSET
	float                                              Weight_69;                                                // 0x0114(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bPropagateToChildren_69;                                  // 0x0118(0x0001) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	unsigned char                                      UnknownData02[0x7];                                       // 0x0119(0x0007) MISSED OFFSET
	struct FRigUnit_FitChainToCurve_DebugSettings      DebugSettings_69;                                         // 0x0120(0x0090) (Edit, BlueprintVisible)
	struct FRigUnit_FitChainToCurve_WorkData           WorkData_69;                                              // 0x01B0(0x0098) (Transient)
	unsigned char                                      UnknownData03[0x8];                                       // 0x0248(0x0008) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_ModifyBoneTransforms_PerBone
// 0x0070
struct FRigUnit_ModifyBoneTransforms_PerBone
{
	struct FName                                       bone_69;                                                  // 0x0000(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0xC];                                       // 0x0004(0x000C) MISSED OFFSET
	struct FCoreUObject_FTransform                     Transform_69;                                             // 0x0010(0x0060) (Edit, BlueprintVisible, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_ModifyTransforms_WorkData
// 0x0010
struct FRigUnit_ModifyTransforms_WorkData
{
	TArray<struct FCachedRigElement>                   CachedItems_69;                                           // 0x0000(0x0010) (ZeroConstructor)
};

// ScriptStruct ControlRig.RigUnit_ModifyBoneTransforms_WorkData
// 0x0000 (0x0010 - 0x0010)
struct FRigUnit_ModifyBoneTransforms_WorkData : public FRigUnit_ModifyTransforms_WorkData
{

};

// ScriptStruct ControlRig.RigUnit_ModifyBoneTransforms
// 0x0030 (0x0068 - 0x0038)
struct FRigUnit_ModifyBoneTransforms : public FRigUnit_HighlevelBaseMutable
{
	TArray<struct FRigUnit_ModifyBoneTransforms_PerBone> BoneToModify_69;                                          // 0x0038(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	float                                              Weight_69;                                                // 0x0048(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              WeightMinimum_69;                                         // 0x004C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	float                                              WeightMaximum_69;                                         // 0x0050(0x0004) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	EControlRigModifyBoneMode                          Mode_69;                                                  // 0x0054(0x0001) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0055(0x0003) MISSED OFFSET
	struct FRigUnit_ModifyBoneTransforms_WorkData      WorkData_69;                                              // 0x0058(0x0010) (Transient)
};

// ScriptStruct ControlRig.RigUnit_ModifyTransforms_PerItem
// 0x0070
struct FRigUnit_ModifyTransforms_PerItem
{
	struct FRigElementKey                              Item_69;                                                  // 0x0000(0x0008) (Edit, BlueprintVisible)
	unsigned char                                      UnknownData00[0x8];                                       // 0x0008(0x0008) MISSED OFFSET
	struct FCoreUObject_FTransform                     Transform_69;                                             // 0x0010(0x0060) (Edit, BlueprintVisible, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_ModifyTransforms
// 0x0030 (0x0068 - 0x0038)
struct FRigUnit_ModifyTransforms : public FRigUnit_HighlevelBaseMutable
{
	TArray<struct FRigUnit_ModifyTransforms_PerItem>   ItemToModify_69;                                          // 0x0038(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	float                                              Weight_69;                                                // 0x0048(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              WeightMinimum_69;                                         // 0x004C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	float                                              WeightMaximum_69;                                         // 0x0050(0x0004) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	EControlRigModifyBoneMode                          Mode_69;                                                  // 0x0054(0x0001) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0055(0x0003) MISSED OFFSET
	struct FRigUnit_ModifyTransforms_WorkData          WorkData_69;                                              // 0x0058(0x0010) (Transient)
};

// ScriptStruct ControlRig.RigUnit_MultiFABRIK_WorkData
// 0x0068
struct FRigUnit_MultiFABRIK_WorkData
{
	unsigned char                                      UnknownData00[0x68];                                      // 0x0000(0x0068) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_MultiFABRIK_EndEffector
// 0x0020
struct FRigUnit_MultiFABRIK_EndEffector
{
	struct FName                                       bone_69;                                                  // 0x0000(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0004(0x0004) MISSED OFFSET
	struct FVector                                     Location_69;                                              // 0x0008(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_MultiFABRIK
// 0x0090 (0x00C8 - 0x0038)
struct FRigUnit_MultiFABRIK : public FRigUnit_HighlevelBaseMutable
{
	struct FName                                       RootBone_69;                                              // 0x0038(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x003C(0x0004) MISSED OFFSET
	TArray<struct FRigUnit_MultiFABRIK_EndEffector>    Effectors_69;                                             // 0x0040(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	float                                              Precision_69;                                             // 0x0050(0x0004) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	bool                                               bPropagateToChildren_69;                                  // 0x0054(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x3];                                       // 0x0055(0x0003) MISSED OFFSET
	int                                                MaxIterations_69;                                         // 0x0058(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData02[0x4];                                       // 0x005C(0x0004) MISSED OFFSET
	struct FRigUnit_MultiFABRIK_WorkData               WorkData_69;                                              // 0x0060(0x0068) (Transient)
};

// ScriptStruct ControlRig.RigUnit_SlideChain_WorkData
// 0x0048
struct FRigUnit_SlideChain_WorkData
{
	float                                              ChainLength_69;                                           // 0x0000(0x0004) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0004(0x0004) MISSED OFFSET
	TArray<float>                                      ItemSegments_69;                                          // 0x0008(0x0010) (ZeroConstructor)
	TArray<struct FCachedRigElement>                   CachedItems_69;                                           // 0x0018(0x0010) (ZeroConstructor)
	TArray<struct FCoreUObject_FTransform>             Transforms_69;                                            // 0x0028(0x0010) (ZeroConstructor)
	TArray<struct FCoreUObject_FTransform>             BlendedTransforms_69;                                     // 0x0038(0x0010) (ZeroConstructor)
};

// ScriptStruct ControlRig.RigUnit_SlideChain
// 0x0058 (0x0090 - 0x0038)
struct FRigUnit_SlideChain : public FRigUnit_HighlevelBaseMutable
{
	struct FName                                       StartBone_69;                                             // 0x0038(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FName                                       EndBone_69;                                               // 0x003C(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              SlideAmount_69;                                           // 0x0040(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bPropagateToChildren_69;                                  // 0x0044(0x0001) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0045(0x0003) MISSED OFFSET
	struct FRigUnit_SlideChain_WorkData                WorkData_69;                                              // 0x0048(0x0048) (Transient)
};

// ScriptStruct ControlRig.RigUnit_SlideChainPerItem
// 0x0060 (0x0098 - 0x0038)
struct FRigUnit_SlideChainPerItem : public FRigUnit_HighlevelBaseMutable
{
	struct FRigElementKeyCollection                    Items_69;                                                 // 0x0038(0x0010) (Edit, BlueprintVisible)
	float                                              SlideAmount_69;                                           // 0x0048(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bPropagateToChildren_69;                                  // 0x004C(0x0001) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x004D(0x0003) MISSED OFFSET
	struct FRigUnit_SlideChain_WorkData                WorkData_69;                                              // 0x0050(0x0048) (Transient)
};

// ScriptStruct ControlRig.RigUnit_SlideChainItemArray
// 0x0060 (0x0098 - 0x0038)
struct FRigUnit_SlideChainItemArray : public FRigUnit_HighlevelBaseMutable
{
	TArray<struct FRigElementKey>                      Items_69;                                                 // 0x0038(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	float                                              SlideAmount_69;                                           // 0x0048(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bPropagateToChildren_69;                                  // 0x004C(0x0001) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x004D(0x0003) MISSED OFFSET
	struct FRigUnit_SlideChain_WorkData                WorkData_69;                                              // 0x0050(0x0048) (Transient)
};

// ScriptStruct ControlRig.RegionScaleFactors
// 0x0010
struct FRegionScaleFactors
{
	float                                              PositiveWidth_69;                                         // 0x0000(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              NegativeWidth_69;                                         // 0x0004(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              PositiveHeight_69;                                        // 0x0008(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              NegativeHeight_69;                                        // 0x000C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct ControlRig.SphericalRegion
// 0x0014
struct FSphericalRegion
{
	unsigned char                                      UnknownData00[0x14];                                      // 0x0000(0x0014) MISSED OFFSET
};

// ScriptStruct ControlRig.SphericalPoseReaderDebugSettings
// 0x0010
struct FSphericalPoseReaderDebugSettings
{
	bool                                               bDrawDebug_69;                                            // 0x0000(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bDraw2D_69;                                               // 0x0001(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bDrawLocalAxes_69;                                        // 0x0002(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x1];                                       // 0x0003(0x0001) MISSED OFFSET
	float                                              DebugScale_69;                                            // 0x0004(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                DebugSegments_69;                                         // 0x0008(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              DebugThickness_69;                                        // 0x000C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_SphericalPoseReader
// 0x0198 (0x01D0 - 0x0038)
struct FRigUnit_SphericalPoseReader : public FRigUnit_HighlevelBaseMutable
{
	float                                              OutputParam_69;                                           // 0x0038(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	struct FRigElementKey                              DriverItem_69;                                            // 0x003C(0x0008) (Edit, BlueprintVisible)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0044(0x0004) MISSED OFFSET
	struct FVector                                     DriverAxis_69;                                            // 0x0048(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FVector                                     RotationOffset_69;                                        // 0x0060(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              ActiveRegionSize_69;                                      // 0x0078(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FRegionScaleFactors                         ActiveRegionScaleFactors_69;                              // 0x007C(0x0010) (Edit, BlueprintVisible)
	float                                              FalloffSize_69;                                           // 0x008C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FRegionScaleFactors                         FalloffRegionScaleFactors_69;                             // 0x0090(0x0010) (Edit, BlueprintVisible)
	bool                                               FlipWidthScaling_69;                                      // 0x00A0(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               FlipHeightScaling_69;                                     // 0x00A1(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x2];                                       // 0x00A2(0x0002) MISSED OFFSET
	struct FRigElementKey                              OptionalParentItem_69;                                    // 0x00A4(0x0008) (Edit, BlueprintVisible)
	struct FSphericalPoseReaderDebugSettings           Debug_69;                                                 // 0x00AC(0x0010) (Edit, BlueprintVisible)
	struct FSphericalRegion                            InnerRegion_69;                                           // 0x00BC(0x0014) (Transient)
	struct FSphericalRegion                            OuterRegion_69;                                           // 0x00D0(0x0014) (Transient)
	unsigned char                                      UnknownData02[0x4];                                       // 0x00E4(0x0004) MISSED OFFSET
	struct FVector                                     DriverNormal_69;                                          // 0x00E8(0x0018) (ZeroConstructor, Transient, IsPlainOldData)
	struct FVector                                     Driver2D_69;                                              // 0x0100(0x0018) (ZeroConstructor, Transient, IsPlainOldData)
	struct FCachedRigElement                           DriverCache_69;                                           // 0x0118(0x0018)
	struct FCachedRigElement                           OptionalParentCache_69;                                   // 0x0130(0x0018)
	unsigned char                                      UnknownData03[0x8];                                       // 0x0148(0x0008) MISSED OFFSET
	struct FCoreUObject_FTransform                     LocalDriverTransformInit_69;                              // 0x0150(0x0060) (IsPlainOldData)
	struct FVector                                     CachedRotationOffset_69;                                  // 0x01B0(0x0018) (ZeroConstructor, IsPlainOldData)
	bool                                               bCachedInitTransforms_69;                                 // 0x01C8(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData04[0x7];                                       // 0x01C9(0x0007) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_SpringIK_DebugSettings
// 0x0080
struct FRigUnit_SpringIK_DebugSettings
{
	bool                                               bEnabled_69;                                              // 0x0000(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0001(0x0003) MISSED OFFSET
	float                                              Scale_69;                                                 // 0x0004(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FLinearColor                                Color_69;                                                 // 0x0008(0x0010) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x8];                                       // 0x0018(0x0008) MISSED OFFSET
	struct FCoreUObject_FTransform                     WorldOffset_69;                                           // 0x0020(0x0060) (Edit, BlueprintVisible, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_SpringIK_WorkData
// 0x00B0
struct FRigUnit_SpringIK_WorkData
{
	TArray<struct FCachedRigElement>                   CachedBones_69;                                           // 0x0000(0x0010) (ZeroConstructor, Transient)
	struct FCachedRigElement                           CachedPoleVector_69;                                      // 0x0010(0x0018)
	TArray<struct FCoreUObject_FTransform>             Transforms_69;                                            // 0x0028(0x0010) (ZeroConstructor)
	struct FCRSimPointContainer                        Simulation_69;                                            // 0x0038(0x0078)
};

// ScriptStruct ControlRig.RigUnit_SpringIK
// 0x01B8 (0x01F0 - 0x0038)
struct FRigUnit_SpringIK : public FRigUnit_HighlevelBaseMutable
{
	struct FName                                       StartBone_69;                                             // 0x0038(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FName                                       EndBone_69;                                               // 0x003C(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              HierarchyStrength_69;                                     // 0x0040(0x0004) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	float                                              EffectorStrength_69;                                      // 0x0044(0x0004) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	float                                              EffectorRatio_69;                                         // 0x0048(0x0004) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	float                                              RootStrength_69;                                          // 0x004C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	float                                              RootRatio_69;                                             // 0x0050(0x0004) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	float                                              Damping_69;                                               // 0x0054(0x0004) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	struct FVector                                     PoleVector_69;                                            // 0x0058(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bFlipPolePlane_69;                                        // 0x0070(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	EControlRigVectorKind                              PoleVectorKind_69;                                        // 0x0071(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x2];                                       // 0x0072(0x0002) MISSED OFFSET
	struct FName                                       PoleVectorSpace_69;                                       // 0x0074(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FVector                                     PrimaryAxis_69;                                           // 0x0078(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FVector                                     SecondaryAxis_69;                                         // 0x0090(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bLiveSimulation_69;                                       // 0x00A8(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x3];                                       // 0x00A9(0x0003) MISSED OFFSET
	int                                                Iterations_69;                                            // 0x00AC(0x0004) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	bool                                               bLimitLocalPosition_69;                                   // 0x00B0(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bPropagateToChildren_69;                                  // 0x00B1(0x0001) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	unsigned char                                      UnknownData02[0xE];                                       // 0x00B2(0x000E) MISSED OFFSET
	struct FRigUnit_SpringIK_DebugSettings             DebugSettings_69;                                         // 0x00C0(0x0080) (Edit, BlueprintVisible)
	struct FRigUnit_SpringIK_WorkData                  WorkData_69;                                              // 0x0140(0x00B0) (Transient)
};

// ScriptStruct ControlRig.ConstraintTarget
// 0x0070
struct FConstraintTarget
{
	struct FCoreUObject_FTransform                     Transform_69;                                             // 0x0000(0x0060) (Edit, IsPlainOldData)
	float                                              Weight_69;                                                // 0x0060(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	bool                                               bMaintainOffset_69;                                       // 0x0064(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	struct FTransformFilter                            Filter_69;                                                // 0x0065(0x0009) (Edit, BlueprintVisible, EditConst)
	unsigned char                                      UnknownData00[0x2];                                       // 0x006E(0x0002) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_TransformConstraint_WorkData
// 0x0060
struct FRigUnit_TransformConstraint_WorkData
{
	TArray<struct FConstraintData>                     ConstraintData_69;                                        // 0x0000(0x0010) (ZeroConstructor)
	TMap<int, int>                                     ConstraintDataToTargets_69;                               // 0x0010(0x0050)
};

// ScriptStruct ControlRig.RigUnit_TransformConstraint
// 0x00E8 (0x0120 - 0x0038)
struct FRigUnit_TransformConstraint : public FRigUnit_HighlevelBaseMutable
{
	struct FName                                       bone_69;                                                  // 0x0038(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	ETransformSpaceMode                                BaseTransformSpace_69;                                    // 0x003C(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x003D(0x0003) MISSED OFFSET
	struct FCoreUObject_FTransform                     BaseTransform_69;                                         // 0x0040(0x0060) (Edit, BlueprintVisible, IsPlainOldData)
	struct FName                                       BaseBone_69;                                              // 0x00A0(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x4];                                       // 0x00A4(0x0004) MISSED OFFSET
	TArray<struct FConstraintTarget>                   Targets_69;                                               // 0x00A8(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	bool                                               bUseInitialTransforms_69;                                 // 0x00B8(0x0001) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	unsigned char                                      UnknownData02[0x7];                                       // 0x00B9(0x0007) MISSED OFFSET
	struct FRigUnit_TransformConstraint_WorkData       WorkData_69;                                              // 0x00C0(0x0060) (Transient)
};

// ScriptStruct ControlRig.RigUnit_TransformConstraintPerItem
// 0x00F8 (0x0130 - 0x0038)
struct FRigUnit_TransformConstraintPerItem : public FRigUnit_HighlevelBaseMutable
{
	struct FRigElementKey                              Item_69;                                                  // 0x0038(0x0008) (Edit, BlueprintVisible)
	ETransformSpaceMode                                BaseTransformSpace_69;                                    // 0x0040(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0xF];                                       // 0x0041(0x000F) MISSED OFFSET
	struct FCoreUObject_FTransform                     BaseTransform_69;                                         // 0x0050(0x0060) (Edit, BlueprintVisible, IsPlainOldData)
	struct FRigElementKey                              BaseItem_69;                                              // 0x00B0(0x0008) (Edit, BlueprintVisible)
	TArray<struct FConstraintTarget>                   Targets_69;                                               // 0x00B8(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	bool                                               bUseInitialTransforms_69;                                 // 0x00C8(0x0001) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	unsigned char                                      UnknownData01[0x7];                                       // 0x00C9(0x0007) MISSED OFFSET
	struct FRigUnit_TransformConstraint_WorkData       WorkData_69;                                              // 0x00D0(0x0060) (Transient)
};

// ScriptStruct ControlRig.RigUnit_ParentConstraint_AdvancedSettings
// 0x0002
struct FRigUnit_ParentConstraint_AdvancedSettings
{
	EConstraintInterpType                              InterpolationType_69;                                     // 0x0000(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	EEulerRotationOrder                                RotationOrderForFilter_69;                                // 0x0001(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_ParentConstraint
// 0x0058 (0x0090 - 0x0038)
struct FRigUnit_ParentConstraint : public FRigUnit_HighlevelBaseMutable
{
	struct FRigElementKey                              Child_69;                                                 // 0x0038(0x0008) (Edit, BlueprintVisible)
	bool                                               bMaintainOffset_69;                                       // 0x0040(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FTransformFilter                            Filter_69;                                                // 0x0041(0x0009) (Edit, BlueprintVisible)
	unsigned char                                      UnknownData00[0x6];                                       // 0x004A(0x0006) MISSED OFFSET
	TArray<struct FConstraintParent>                   Parents_69;                                               // 0x0050(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FRigUnit_ParentConstraint_AdvancedSettings  AdvancedSettings_69;                                      // 0x0060(0x0002) (Edit, BlueprintVisible)
	unsigned char                                      UnknownData01[0x2];                                       // 0x0062(0x0002) MISSED OFFSET
	float                                              Weight_69;                                                // 0x0064(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FCachedRigElement                           ChildCache_69;                                            // 0x0068(0x0018)
	TArray<struct FCachedRigElement>                   ParentCaches_69;                                          // 0x0080(0x0010) (ZeroConstructor)
};

// ScriptStruct ControlRig.RigUnit_PositionConstraint
// 0x0028 (0x0060 - 0x0038)
struct FRigUnit_PositionConstraint : public FRigUnit_HighlevelBaseMutable
{
	struct FRigElementKey                              Child_69;                                                 // 0x0038(0x0008) (Edit, BlueprintVisible)
	bool                                               bMaintainOffset_69;                                       // 0x0040(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FFilterOptionPerAxis                        Filter_69;                                                // 0x0041(0x0003) (Edit, BlueprintVisible)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0044(0x0004) MISSED OFFSET
	TArray<struct FConstraintParent>                   Parents_69;                                               // 0x0048(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	float                                              Weight_69;                                                // 0x0058(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x4];                                       // 0x005C(0x0004) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_PositionConstraintLocalSpaceOffset
// 0x0050 (0x0088 - 0x0038)
struct FRigUnit_PositionConstraintLocalSpaceOffset : public FRigUnit_HighlevelBaseMutable
{
	struct FRigElementKey                              Child_69;                                                 // 0x0038(0x0008) (Edit, BlueprintVisible)
	bool                                               bMaintainOffset_69;                                       // 0x0040(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FFilterOptionPerAxis                        Filter_69;                                                // 0x0041(0x0003) (Edit, BlueprintVisible)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0044(0x0004) MISSED OFFSET
	TArray<struct FConstraintParent>                   Parents_69;                                               // 0x0048(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	float                                              Weight_69;                                                // 0x0058(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x4];                                       // 0x005C(0x0004) MISSED OFFSET
	struct FCachedRigElement                           ChildCache_69;                                            // 0x0060(0x0018)
	TArray<struct FCachedRigElement>                   ParentCaches_69;                                          // 0x0078(0x0010) (ZeroConstructor)
};

// ScriptStruct ControlRig.RigUnit_RotationConstraint_AdvancedSettings
// 0x0002
struct FRigUnit_RotationConstraint_AdvancedSettings
{
	EConstraintInterpType                              InterpolationType_69;                                     // 0x0000(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	EEulerRotationOrder                                RotationOrderForFilter_69;                                // 0x0001(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_RotationConstraint
// 0x0028 (0x0060 - 0x0038)
struct FRigUnit_RotationConstraint : public FRigUnit_HighlevelBaseMutable
{
	struct FRigElementKey                              Child_69;                                                 // 0x0038(0x0008) (Edit, BlueprintVisible)
	bool                                               bMaintainOffset_69;                                       // 0x0040(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FFilterOptionPerAxis                        Filter_69;                                                // 0x0041(0x0003) (Edit, BlueprintVisible)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0044(0x0004) MISSED OFFSET
	TArray<struct FConstraintParent>                   Parents_69;                                               // 0x0048(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FRigUnit_RotationConstraint_AdvancedSettings AdvancedSettings_69;                                      // 0x0058(0x0002) (Edit, BlueprintVisible)
	unsigned char                                      UnknownData01[0x2];                                       // 0x005A(0x0002) MISSED OFFSET
	float                                              Weight_69;                                                // 0x005C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_RotationConstraintLocalSpaceOffset
// 0x0050 (0x0088 - 0x0038)
struct FRigUnit_RotationConstraintLocalSpaceOffset : public FRigUnit_HighlevelBaseMutable
{
	struct FRigElementKey                              Child_69;                                                 // 0x0038(0x0008) (Edit, BlueprintVisible)
	bool                                               bMaintainOffset_69;                                       // 0x0040(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FFilterOptionPerAxis                        Filter_69;                                                // 0x0041(0x0003) (Edit, BlueprintVisible)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0044(0x0004) MISSED OFFSET
	TArray<struct FConstraintParent>                   Parents_69;                                               // 0x0048(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FRigUnit_RotationConstraint_AdvancedSettings AdvancedSettings_69;                                      // 0x0058(0x0002) (Edit, BlueprintVisible)
	unsigned char                                      UnknownData01[0x2];                                       // 0x005A(0x0002) MISSED OFFSET
	float                                              Weight_69;                                                // 0x005C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FCachedRigElement                           ChildCache_69;                                            // 0x0060(0x0018)
	TArray<struct FCachedRigElement>                   ParentCaches_69;                                          // 0x0078(0x0010) (ZeroConstructor)
};

// ScriptStruct ControlRig.RigUnit_ScaleConstraint
// 0x0028 (0x0060 - 0x0038)
struct FRigUnit_ScaleConstraint : public FRigUnit_HighlevelBaseMutable
{
	struct FRigElementKey                              Child_69;                                                 // 0x0038(0x0008) (Edit, BlueprintVisible)
	bool                                               bMaintainOffset_69;                                       // 0x0040(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FFilterOptionPerAxis                        Filter_69;                                                // 0x0041(0x0003) (Edit, BlueprintVisible)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0044(0x0004) MISSED OFFSET
	TArray<struct FConstraintParent>                   Parents_69;                                               // 0x0048(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	float                                              Weight_69;                                                // 0x0058(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x4];                                       // 0x005C(0x0004) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_ScaleConstraintLocalSpaceOffset
// 0x0050 (0x0088 - 0x0038)
struct FRigUnit_ScaleConstraintLocalSpaceOffset : public FRigUnit_HighlevelBaseMutable
{
	struct FRigElementKey                              Child_69;                                                 // 0x0038(0x0008) (Edit, BlueprintVisible)
	bool                                               bMaintainOffset_69;                                       // 0x0040(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FFilterOptionPerAxis                        Filter_69;                                                // 0x0041(0x0003) (Edit, BlueprintVisible)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0044(0x0004) MISSED OFFSET
	TArray<struct FConstraintParent>                   Parents_69;                                               // 0x0048(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	float                                              Weight_69;                                                // 0x0058(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x4];                                       // 0x005C(0x0004) MISSED OFFSET
	struct FCachedRigElement                           ChildCache_69;                                            // 0x0060(0x0018)
	TArray<struct FCachedRigElement>                   ParentCaches_69;                                          // 0x0078(0x0010) (ZeroConstructor)
};

// ScriptStruct ControlRig.RigUnit_TwistBones_WorkData
// 0x0030
struct FRigUnit_TwistBones_WorkData
{
	TArray<struct FCachedRigElement>                   CachedItems_69;                                           // 0x0000(0x0010) (ZeroConstructor)
	TArray<float>                                      ItemRatios_69;                                            // 0x0010(0x0010) (ZeroConstructor)
	TArray<struct FCoreUObject_FTransform>             ItemTransforms_69;                                        // 0x0020(0x0010) (ZeroConstructor)
};

// ScriptStruct ControlRig.RigUnit_TwistBones
// 0x0078 (0x00B0 - 0x0038)
struct FRigUnit_TwistBones : public FRigUnit_HighlevelBaseMutable
{
	struct FName                                       StartBone_69;                                             // 0x0038(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FName                                       EndBone_69;                                               // 0x003C(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FVector                                     TwistAxis_69;                                             // 0x0040(0x0018) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	struct FVector                                     PoleAxis_69;                                              // 0x0058(0x0018) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	EControlRigAnimEasingType                          TwistEaseType_69;                                         // 0x0070(0x0001) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0071(0x0003) MISSED OFFSET
	float                                              Weight_69;                                                // 0x0074(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bPropagateToChildren_69;                                  // 0x0078(0x0001) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	unsigned char                                      UnknownData01[0x7];                                       // 0x0079(0x0007) MISSED OFFSET
	struct FRigUnit_TwistBones_WorkData                WorkData_69;                                              // 0x0080(0x0030) (Transient)
};

// ScriptStruct ControlRig.RigUnit_TwistBonesPerItem
// 0x0080 (0x00B8 - 0x0038)
struct FRigUnit_TwistBonesPerItem : public FRigUnit_HighlevelBaseMutable
{
	struct FRigElementKeyCollection                    Items_69;                                                 // 0x0038(0x0010) (Edit, BlueprintVisible)
	struct FVector                                     TwistAxis_69;                                             // 0x0048(0x0018) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	struct FVector                                     PoleAxis_69;                                              // 0x0060(0x0018) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	EControlRigAnimEasingType                          TwistEaseType_69;                                         // 0x0078(0x0001) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0079(0x0003) MISSED OFFSET
	float                                              Weight_69;                                                // 0x007C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bPropagateToChildren_69;                                  // 0x0080(0x0001) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	unsigned char                                      UnknownData01[0x7];                                       // 0x0081(0x0007) MISSED OFFSET
	struct FRigUnit_TwistBones_WorkData                WorkData_69;                                              // 0x0088(0x0030) (Transient)
};

// ScriptStruct ControlRig.RigUnit_TwoBoneIKSimple_DebugSettings
// 0x0070
struct FRigUnit_TwoBoneIKSimple_DebugSettings
{
	bool                                               bEnabled_69;                                              // 0x0000(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0001(0x0003) MISSED OFFSET
	float                                              Scale_69;                                                 // 0x0004(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x8];                                       // 0x0008(0x0008) MISSED OFFSET
	struct FCoreUObject_FTransform                     WorldOffset_69;                                           // 0x0010(0x0060) (Edit, BlueprintVisible, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_TwoBoneIKSimple
// 0x01C8 (0x0200 - 0x0038)
struct FRigUnit_TwoBoneIKSimple : public FRigUnit_HighlevelBaseMutable
{
	struct FName                                       BoneA_69;                                                 // 0x0038(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FName                                       BoneB_69;                                                 // 0x003C(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FName                                       EffectorBone_69;                                          // 0x0040(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0xC];                                       // 0x0044(0x000C) MISSED OFFSET
	struct FCoreUObject_FTransform                     Effector_69;                                              // 0x0050(0x0060) (Edit, BlueprintVisible, IsPlainOldData)
	struct FVector                                     PrimaryAxis_69;                                           // 0x00B0(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FVector                                     SecondaryAxis_69;                                         // 0x00C8(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              SecondaryAxisWeight_69;                                   // 0x00E0(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x4];                                       // 0x00E4(0x0004) MISSED OFFSET
	struct FVector                                     PoleVector_69;                                            // 0x00E8(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	EControlRigVectorKind                              PoleVectorKind_69;                                        // 0x0100(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData02[0x3];                                       // 0x0101(0x0003) MISSED OFFSET
	struct FName                                       PoleVectorSpace_69;                                       // 0x0104(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bEnableStretch_69;                                        // 0x0108(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData03[0x3];                                       // 0x0109(0x0003) MISSED OFFSET
	float                                              StretchStartRatio_69;                                     // 0x010C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              StretchMaximumRatio_69;                                   // 0x0110(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              Weight_69;                                                // 0x0114(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              BoneALength_69;                                           // 0x0118(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              BoneBLength_69;                                           // 0x011C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bPropagateToChildren_69;                                  // 0x0120(0x0001) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	unsigned char                                      UnknownData04[0xF];                                       // 0x0121(0x000F) MISSED OFFSET
	struct FRigUnit_TwoBoneIKSimple_DebugSettings      DebugSettings_69;                                         // 0x0130(0x0070) (Edit, BlueprintVisible)
	struct FCachedRigElement                           CachedBoneAIndex_69;                                      // 0x01A0(0x0018)
	struct FCachedRigElement                           CachedBoneBIndex_69;                                      // 0x01B8(0x0018)
	struct FCachedRigElement                           CachedEffectorBoneIndex_69;                               // 0x01D0(0x0018)
	struct FCachedRigElement                           CachedPoleVectorSpaceIndex_69;                            // 0x01E8(0x0018)
};

// ScriptStruct ControlRig.RigUnit_TwoBoneIKSimplePerItem
// 0x01C8 (0x0200 - 0x0038)
struct FRigUnit_TwoBoneIKSimplePerItem : public FRigUnit_HighlevelBaseMutable
{
	struct FRigElementKey                              ItemA_69;                                                 // 0x0038(0x0008) (Edit, BlueprintVisible)
	struct FRigElementKey                              ItemB_69;                                                 // 0x0040(0x0008) (Edit, BlueprintVisible)
	struct FRigElementKey                              EffectorItem_69;                                          // 0x0048(0x0008) (Edit, BlueprintVisible)
	struct FCoreUObject_FTransform                     Effector_69;                                              // 0x0050(0x0060) (Edit, BlueprintVisible, IsPlainOldData)
	struct FVector                                     PrimaryAxis_69;                                           // 0x00B0(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FVector                                     SecondaryAxis_69;                                         // 0x00C8(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              SecondaryAxisWeight_69;                                   // 0x00E0(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x00E4(0x0004) MISSED OFFSET
	struct FVector                                     PoleVector_69;                                            // 0x00E8(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	EControlRigVectorKind                              PoleVectorKind_69;                                        // 0x0100(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x3];                                       // 0x0101(0x0003) MISSED OFFSET
	struct FRigElementKey                              PoleVectorSpace_69;                                       // 0x0104(0x0008) (Edit, BlueprintVisible)
	bool                                               bEnableStretch_69;                                        // 0x010C(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData02[0x3];                                       // 0x010D(0x0003) MISSED OFFSET
	float                                              StretchStartRatio_69;                                     // 0x0110(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              StretchMaximumRatio_69;                                   // 0x0114(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              Weight_69;                                                // 0x0118(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              ItemALength_69;                                           // 0x011C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              ItemBLength_69;                                           // 0x0120(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bPropagateToChildren_69;                                  // 0x0124(0x0001) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	unsigned char                                      UnknownData03[0xB];                                       // 0x0125(0x000B) MISSED OFFSET
	struct FRigUnit_TwoBoneIKSimple_DebugSettings      DebugSettings_69;                                         // 0x0130(0x0070) (Edit, BlueprintVisible)
	struct FCachedRigElement                           CachedItemAIndex_69;                                      // 0x01A0(0x0018)
	struct FCachedRigElement                           CachedItemBIndex_69;                                      // 0x01B8(0x0018)
	struct FCachedRigElement                           CachedEffectorItemIndex_69;                               // 0x01D0(0x0018)
	struct FCachedRigElement                           CachedPoleVectorSpaceIndex_69;                            // 0x01E8(0x0018)
};

// ScriptStruct ControlRig.RigUnit_TwoBoneIKSimpleVectors
// 0x0078 (0x0080 - 0x0008)
struct FRigUnit_TwoBoneIKSimpleVectors : public FRigUnit_HighlevelBase
{
	struct FVector                                     Root_69;                                                  // 0x0008(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FVector                                     PoleVector_69;                                            // 0x0020(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FVector                                     Effector_69;                                              // 0x0038(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bEnableStretch_69;                                        // 0x0050(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0051(0x0003) MISSED OFFSET
	float                                              StretchStartRatio_69;                                     // 0x0054(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              StretchMaximumRatio_69;                                   // 0x0058(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              BoneALength_69;                                           // 0x005C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              BoneBLength_69;                                           // 0x0060(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x4];                                       // 0x0064(0x0004) MISSED OFFSET
	struct FVector                                     Elbow_69;                                                 // 0x0068(0x0018) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_TwoBoneIKSimpleTransforms
// 0x0198 (0x01A0 - 0x0008)
struct FRigUnit_TwoBoneIKSimpleTransforms : public FRigUnit_HighlevelBase
{
	unsigned char                                      UnknownData00[0x8];                                       // 0x0008(0x0008) MISSED OFFSET
	struct FCoreUObject_FTransform                     Root_69;                                                  // 0x0010(0x0060) (Edit, BlueprintVisible, IsPlainOldData)
	struct FVector                                     PoleVector_69;                                            // 0x0070(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x8];                                       // 0x0088(0x0008) MISSED OFFSET
	struct FCoreUObject_FTransform                     Effector_69;                                              // 0x0090(0x0060) (Edit, BlueprintVisible, IsPlainOldData)
	struct FVector                                     PrimaryAxis_69;                                           // 0x00F0(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FVector                                     SecondaryAxis_69;                                         // 0x0108(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              SecondaryAxisWeight_69;                                   // 0x0120(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bEnableStretch_69;                                        // 0x0124(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData02[0x3];                                       // 0x0125(0x0003) MISSED OFFSET
	float                                              StretchStartRatio_69;                                     // 0x0128(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              StretchMaximumRatio_69;                                   // 0x012C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              BoneALength_69;                                           // 0x0130(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              BoneBLength_69;                                           // 0x0134(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData03[0x8];                                       // 0x0138(0x0008) MISSED OFFSET
	struct FCoreUObject_FTransform                     Elbow_69;                                                 // 0x0140(0x0060) (Edit, BlueprintVisible, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_MathBoolBase
// 0x0000 (0x0008 - 0x0008)
struct FRigUnit_MathBoolBase : public FRigUnit_MathBase
{

};

// ScriptStruct ControlRig.RigUnit_MathBoolConstant
// 0x0008 (0x0010 - 0x0008)
struct FRigUnit_MathBoolConstant : public FRigUnit_MathBoolBase
{
	bool                                               Value_69;                                                 // 0x0008(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0009(0x0007) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_MathBoolUnaryOp
// 0x0008 (0x0010 - 0x0008)
struct FRigUnit_MathBoolUnaryOp : public FRigUnit_MathBoolBase
{
	bool                                               Value_69;                                                 // 0x0008(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               Result_69;                                                // 0x0009(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x6];                                       // 0x000A(0x0006) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_MathBoolBinaryOp
// 0x0008 (0x0010 - 0x0008)
struct FRigUnit_MathBoolBinaryOp : public FRigUnit_MathBoolBase
{
	bool                                               A_69;                                                     // 0x0008(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               B_69;                                                     // 0x0009(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               Result_69;                                                // 0x000A(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x5];                                       // 0x000B(0x0005) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_MathBoolConstTrue
// 0x0000 (0x0010 - 0x0010)
struct FRigUnit_MathBoolConstTrue : public FRigUnit_MathBoolConstant
{

};

// ScriptStruct ControlRig.RigUnit_MathBoolConstFalse
// 0x0000 (0x0010 - 0x0010)
struct FRigUnit_MathBoolConstFalse : public FRigUnit_MathBoolConstant
{

};

// ScriptStruct ControlRig.RigUnit_MathBoolNot
// 0x0000 (0x0010 - 0x0010)
struct FRigUnit_MathBoolNot : public FRigUnit_MathBoolUnaryOp
{

};

// ScriptStruct ControlRig.RigUnit_MathBoolAnd
// 0x0000 (0x0010 - 0x0010)
struct FRigUnit_MathBoolAnd : public FRigUnit_MathBoolBinaryOp
{

};

// ScriptStruct ControlRig.RigUnit_MathBoolNand
// 0x0000 (0x0010 - 0x0010)
struct FRigUnit_MathBoolNand : public FRigUnit_MathBoolBinaryOp
{

};

// ScriptStruct ControlRig.RigUnit_MathBoolNand2
// 0x0000 (0x0010 - 0x0010)
struct FRigUnit_MathBoolNand2 : public FRigUnit_MathBoolBinaryOp
{

};

// ScriptStruct ControlRig.RigUnit_MathBoolOr
// 0x0000 (0x0010 - 0x0010)
struct FRigUnit_MathBoolOr : public FRigUnit_MathBoolBinaryOp
{

};

// ScriptStruct ControlRig.RigUnit_MathBoolEquals
// 0x0008 (0x0010 - 0x0008)
struct FRigUnit_MathBoolEquals : public FRigUnit_MathBoolBase
{
	bool                                               A_69;                                                     // 0x0008(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               B_69;                                                     // 0x0009(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               Result_69;                                                // 0x000A(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x5];                                       // 0x000B(0x0005) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_MathBoolNotEquals
// 0x0008 (0x0010 - 0x0008)
struct FRigUnit_MathBoolNotEquals : public FRigUnit_MathBoolBase
{
	bool                                               A_69;                                                     // 0x0008(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               B_69;                                                     // 0x0009(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               Result_69;                                                // 0x000A(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x5];                                       // 0x000B(0x0005) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_MathBoolToggled
// 0x0008 (0x0010 - 0x0008)
struct FRigUnit_MathBoolToggled : public FRigUnit_MathBoolBase
{
	bool                                               Value_69;                                                 // 0x0008(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               Toggled_69;                                               // 0x0009(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	bool                                               Initialized_69;                                           // 0x000A(0x0001) (ZeroConstructor, IsPlainOldData)
	bool                                               LastValue_69;                                             // 0x000B(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x000C(0x0004) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_MathBoolFlipFlop
// 0x0010 (0x0018 - 0x0008)
struct FRigUnit_MathBoolFlipFlop : public FRigUnit_MathBoolBase
{
	bool                                               StartValue_69;                                            // 0x0008(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0009(0x0003) MISSED OFFSET
	float                                              Duration_69;                                              // 0x000C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               Result_69;                                                // 0x0010(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	bool                                               LastValue_69;                                             // 0x0011(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x2];                                       // 0x0012(0x0002) MISSED OFFSET
	float                                              TimeLeft_69;                                              // 0x0014(0x0004) (ZeroConstructor, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_MathBoolOnce
// 0x0010 (0x0018 - 0x0008)
struct FRigUnit_MathBoolOnce : public FRigUnit_MathBoolBase
{
	float                                              Duration_69;                                              // 0x0008(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               Result_69;                                                // 0x000C(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	bool                                               LastValue_69;                                             // 0x000D(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x2];                                       // 0x000E(0x0002) MISSED OFFSET
	float                                              TimeLeft_69;                                              // 0x0010(0x0004) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x4];                                       // 0x0014(0x0004) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_MathBoolToFloat
// 0x0008 (0x0010 - 0x0008)
struct FRigUnit_MathBoolToFloat : public FRigUnit_MathBoolBase
{
	bool                                               Value_69;                                                 // 0x0008(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0009(0x0003) MISSED OFFSET
	float                                              Result_69;                                                // 0x000C(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_MathBoolToInteger
// 0x0008 (0x0010 - 0x0008)
struct FRigUnit_MathBoolToInteger : public FRigUnit_MathBoolBase
{
	bool                                               Value_69;                                                 // 0x0008(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0009(0x0003) MISSED OFFSET
	int                                                Result_69;                                                // 0x000C(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_MathColorBase
// 0x0000 (0x0008 - 0x0008)
struct FRigUnit_MathColorBase : public FRigUnit_MathBase
{

};

// ScriptStruct ControlRig.RigUnit_MathColorBinaryOp
// 0x0030 (0x0038 - 0x0008)
struct FRigUnit_MathColorBinaryOp : public FRigUnit_MathColorBase
{
	struct FLinearColor                                A_69;                                                     // 0x0008(0x0010) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FLinearColor                                B_69;                                                     // 0x0018(0x0010) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FLinearColor                                Result_69;                                                // 0x0028(0x0010) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_MathColorFromFloat
// 0x0018 (0x0020 - 0x0008)
struct FRigUnit_MathColorFromFloat : public FRigUnit_MathColorBase
{
	float                                              Value_69;                                                 // 0x0008(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FLinearColor                                Result_69;                                                // 0x000C(0x0010) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x001C(0x0004) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_MathColorAdd
// 0x0000 (0x0038 - 0x0038)
struct FRigUnit_MathColorAdd : public FRigUnit_MathColorBinaryOp
{

};

// ScriptStruct ControlRig.RigUnit_MathColorSub
// 0x0000 (0x0038 - 0x0038)
struct FRigUnit_MathColorSub : public FRigUnit_MathColorBinaryOp
{

};

// ScriptStruct ControlRig.RigUnit_MathColorMul
// 0x0000 (0x0038 - 0x0038)
struct FRigUnit_MathColorMul : public FRigUnit_MathColorBinaryOp
{

};

// ScriptStruct ControlRig.RigUnit_MathColorLerp
// 0x0038 (0x0040 - 0x0008)
struct FRigUnit_MathColorLerp : public FRigUnit_MathColorBase
{
	struct FLinearColor                                A_69;                                                     // 0x0008(0x0010) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FLinearColor                                B_69;                                                     // 0x0018(0x0010) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              T_69;                                                     // 0x0028(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FLinearColor                                Result_69;                                                // 0x002C(0x0010) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x003C(0x0004) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_MathDoubleBase
// 0x0000 (0x0008 - 0x0008)
struct FRigUnit_MathDoubleBase : public FRigUnit_MathBase
{

};

// ScriptStruct ControlRig.RigUnit_MathDoubleConstant
// 0x0008 (0x0010 - 0x0008)
struct FRigUnit_MathDoubleConstant : public FRigUnit_MathDoubleBase
{
	double                                             Value_69;                                                 // 0x0008(0x0008) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_MathDoubleUnaryOp
// 0x0010 (0x0018 - 0x0008)
struct FRigUnit_MathDoubleUnaryOp : public FRigUnit_MathDoubleBase
{
	double                                             Value_69;                                                 // 0x0008(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	double                                             Result_69;                                                // 0x0010(0x0008) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_MathDoubleBinaryOp
// 0x0018 (0x0020 - 0x0008)
struct FRigUnit_MathDoubleBinaryOp : public FRigUnit_MathDoubleBase
{
	double                                             A_69;                                                     // 0x0008(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	double                                             B_69;                                                     // 0x0010(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	double                                             Result_69;                                                // 0x0018(0x0008) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_MathDoubleConstPi
// 0x0000 (0x0010 - 0x0010)
struct FRigUnit_MathDoubleConstPi : public FRigUnit_MathDoubleConstant
{

};

// ScriptStruct ControlRig.RigUnit_MathDoubleConstHalfPi
// 0x0000 (0x0010 - 0x0010)
struct FRigUnit_MathDoubleConstHalfPi : public FRigUnit_MathDoubleConstant
{

};

// ScriptStruct ControlRig.RigUnit_MathDoubleConstTwoPi
// 0x0000 (0x0010 - 0x0010)
struct FRigUnit_MathDoubleConstTwoPi : public FRigUnit_MathDoubleConstant
{

};

// ScriptStruct ControlRig.RigUnit_MathDoubleConstE
// 0x0000 (0x0010 - 0x0010)
struct FRigUnit_MathDoubleConstE : public FRigUnit_MathDoubleConstant
{

};

// ScriptStruct ControlRig.RigUnit_MathDoubleAdd
// 0x0000 (0x0020 - 0x0020)
struct FRigUnit_MathDoubleAdd : public FRigUnit_MathDoubleBinaryOp
{

};

// ScriptStruct ControlRig.RigUnit_MathDoubleSub
// 0x0000 (0x0020 - 0x0020)
struct FRigUnit_MathDoubleSub : public FRigUnit_MathDoubleBinaryOp
{

};

// ScriptStruct ControlRig.RigUnit_MathDoubleMul
// 0x0000 (0x0020 - 0x0020)
struct FRigUnit_MathDoubleMul : public FRigUnit_MathDoubleBinaryOp
{

};

// ScriptStruct ControlRig.RigUnit_MathDoubleDiv
// 0x0000 (0x0020 - 0x0020)
struct FRigUnit_MathDoubleDiv : public FRigUnit_MathDoubleBinaryOp
{

};

// ScriptStruct ControlRig.RigUnit_MathDoubleMod
// 0x0000 (0x0020 - 0x0020)
struct FRigUnit_MathDoubleMod : public FRigUnit_MathDoubleBinaryOp
{

};

// ScriptStruct ControlRig.RigUnit_MathDoubleMin
// 0x0000 (0x0020 - 0x0020)
struct FRigUnit_MathDoubleMin : public FRigUnit_MathDoubleBinaryOp
{

};

// ScriptStruct ControlRig.RigUnit_MathDoubleMax
// 0x0000 (0x0020 - 0x0020)
struct FRigUnit_MathDoubleMax : public FRigUnit_MathDoubleBinaryOp
{

};

// ScriptStruct ControlRig.RigUnit_MathDoublePow
// 0x0000 (0x0020 - 0x0020)
struct FRigUnit_MathDoublePow : public FRigUnit_MathDoubleBinaryOp
{

};

// ScriptStruct ControlRig.RigUnit_MathDoubleSqrt
// 0x0000 (0x0018 - 0x0018)
struct FRigUnit_MathDoubleSqrt : public FRigUnit_MathDoubleUnaryOp
{

};

// ScriptStruct ControlRig.RigUnit_MathDoubleNegate
// 0x0000 (0x0018 - 0x0018)
struct FRigUnit_MathDoubleNegate : public FRigUnit_MathDoubleUnaryOp
{

};

// ScriptStruct ControlRig.RigUnit_MathDoubleAbs
// 0x0000 (0x0018 - 0x0018)
struct FRigUnit_MathDoubleAbs : public FRigUnit_MathDoubleUnaryOp
{

};

// ScriptStruct ControlRig.RigUnit_MathDoubleFloor
// 0x0018 (0x0020 - 0x0008)
struct FRigUnit_MathDoubleFloor : public FRigUnit_MathDoubleBase
{
	double                                             Value_69;                                                 // 0x0008(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	double                                             Result_69;                                                // 0x0010(0x0008) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                Int_69;                                                   // 0x0018(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x001C(0x0004) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_MathDoubleCeil
// 0x0018 (0x0020 - 0x0008)
struct FRigUnit_MathDoubleCeil : public FRigUnit_MathDoubleBase
{
	double                                             Value_69;                                                 // 0x0008(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	double                                             Result_69;                                                // 0x0010(0x0008) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                Int_69;                                                   // 0x0018(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x001C(0x0004) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_MathDoubleRound
// 0x0018 (0x0020 - 0x0008)
struct FRigUnit_MathDoubleRound : public FRigUnit_MathDoubleBase
{
	double                                             Value_69;                                                 // 0x0008(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	double                                             Result_69;                                                // 0x0010(0x0008) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                Int_69;                                                   // 0x0018(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x001C(0x0004) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_MathDoubleToInt
// 0x0010 (0x0018 - 0x0008)
struct FRigUnit_MathDoubleToInt : public FRigUnit_MathDoubleBase
{
	double                                             Value_69;                                                 // 0x0008(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                Result_69;                                                // 0x0010(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0014(0x0004) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_MathDoubleSign
// 0x0000 (0x0018 - 0x0018)
struct FRigUnit_MathDoubleSign : public FRigUnit_MathDoubleUnaryOp
{

};

// ScriptStruct ControlRig.RigUnit_MathDoubleClamp
// 0x0020 (0x0028 - 0x0008)
struct FRigUnit_MathDoubleClamp : public FRigUnit_MathDoubleBase
{
	double                                             Value_69;                                                 // 0x0008(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	double                                             Minimum_69;                                               // 0x0010(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	double                                             Maximum_69;                                               // 0x0018(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	double                                             Result_69;                                                // 0x0020(0x0008) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_MathDoubleLerp
// 0x0020 (0x0028 - 0x0008)
struct FRigUnit_MathDoubleLerp : public FRigUnit_MathDoubleBase
{
	double                                             A_69;                                                     // 0x0008(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	double                                             B_69;                                                     // 0x0010(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	double                                             T_69;                                                     // 0x0018(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	double                                             Result_69;                                                // 0x0020(0x0008) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_MathDoubleRemap
// 0x0038 (0x0040 - 0x0008)
struct FRigUnit_MathDoubleRemap : public FRigUnit_MathDoubleBase
{
	double                                             Value_69;                                                 // 0x0008(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	double                                             SourceMinimum_69;                                         // 0x0010(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	double                                             SourceMaximum_69;                                         // 0x0018(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	double                                             TargetMinimum_69;                                         // 0x0020(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	double                                             TargetMaximum_69;                                         // 0x0028(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bClamp_69;                                                // 0x0030(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0031(0x0007) MISSED OFFSET
	double                                             Result_69;                                                // 0x0038(0x0008) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_MathDoubleEquals
// 0x0018 (0x0020 - 0x0008)
struct FRigUnit_MathDoubleEquals : public FRigUnit_MathDoubleBase
{
	double                                             A_69;                                                     // 0x0008(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	double                                             B_69;                                                     // 0x0010(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               Result_69;                                                // 0x0018(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0019(0x0007) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_MathDoubleNotEquals
// 0x0018 (0x0020 - 0x0008)
struct FRigUnit_MathDoubleNotEquals : public FRigUnit_MathDoubleBase
{
	double                                             A_69;                                                     // 0x0008(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	double                                             B_69;                                                     // 0x0010(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               Result_69;                                                // 0x0018(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0019(0x0007) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_MathDoubleGreater
// 0x0018 (0x0020 - 0x0008)
struct FRigUnit_MathDoubleGreater : public FRigUnit_MathDoubleBase
{
	double                                             A_69;                                                     // 0x0008(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	double                                             B_69;                                                     // 0x0010(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               Result_69;                                                // 0x0018(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0019(0x0007) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_MathDoubleLess
// 0x0018 (0x0020 - 0x0008)
struct FRigUnit_MathDoubleLess : public FRigUnit_MathDoubleBase
{
	double                                             A_69;                                                     // 0x0008(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	double                                             B_69;                                                     // 0x0010(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               Result_69;                                                // 0x0018(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0019(0x0007) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_MathDoubleGreaterEqual
// 0x0018 (0x0020 - 0x0008)
struct FRigUnit_MathDoubleGreaterEqual : public FRigUnit_MathDoubleBase
{
	double                                             A_69;                                                     // 0x0008(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	double                                             B_69;                                                     // 0x0010(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               Result_69;                                                // 0x0018(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0019(0x0007) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_MathDoubleLessEqual
// 0x0018 (0x0020 - 0x0008)
struct FRigUnit_MathDoubleLessEqual : public FRigUnit_MathDoubleBase
{
	double                                             A_69;                                                     // 0x0008(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	double                                             B_69;                                                     // 0x0010(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               Result_69;                                                // 0x0018(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0019(0x0007) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_MathDoubleIsNearlyZero
// 0x0018 (0x0020 - 0x0008)
struct FRigUnit_MathDoubleIsNearlyZero : public FRigUnit_MathDoubleBase
{
	double                                             Value_69;                                                 // 0x0008(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	double                                             Tolerance_69;                                             // 0x0010(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               Result_69;                                                // 0x0018(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0019(0x0007) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_MathDoubleIsNearlyEqual
// 0x0020 (0x0028 - 0x0008)
struct FRigUnit_MathDoubleIsNearlyEqual : public FRigUnit_MathDoubleBase
{
	double                                             A_69;                                                     // 0x0008(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	double                                             B_69;                                                     // 0x0010(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	double                                             Tolerance_69;                                             // 0x0018(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               Result_69;                                                // 0x0020(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0021(0x0007) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_MathDoubleDeg
// 0x0000 (0x0018 - 0x0018)
struct FRigUnit_MathDoubleDeg : public FRigUnit_MathDoubleUnaryOp
{

};

// ScriptStruct ControlRig.RigUnit_MathDoubleRad
// 0x0000 (0x0018 - 0x0018)
struct FRigUnit_MathDoubleRad : public FRigUnit_MathDoubleUnaryOp
{

};

// ScriptStruct ControlRig.RigUnit_MathDoubleSin
// 0x0000 (0x0018 - 0x0018)
struct FRigUnit_MathDoubleSin : public FRigUnit_MathDoubleUnaryOp
{

};

// ScriptStruct ControlRig.RigUnit_MathDoubleCos
// 0x0000 (0x0018 - 0x0018)
struct FRigUnit_MathDoubleCos : public FRigUnit_MathDoubleUnaryOp
{

};

// ScriptStruct ControlRig.RigUnit_MathDoubleTan
// 0x0000 (0x0018 - 0x0018)
struct FRigUnit_MathDoubleTan : public FRigUnit_MathDoubleUnaryOp
{

};

// ScriptStruct ControlRig.RigUnit_MathDoubleAsin
// 0x0000 (0x0018 - 0x0018)
struct FRigUnit_MathDoubleAsin : public FRigUnit_MathDoubleUnaryOp
{

};

// ScriptStruct ControlRig.RigUnit_MathDoubleAcos
// 0x0000 (0x0018 - 0x0018)
struct FRigUnit_MathDoubleAcos : public FRigUnit_MathDoubleUnaryOp
{

};

// ScriptStruct ControlRig.RigUnit_MathDoubleAtan
// 0x0000 (0x0018 - 0x0018)
struct FRigUnit_MathDoubleAtan : public FRigUnit_MathDoubleUnaryOp
{

};

// ScriptStruct ControlRig.RigUnit_MathDoubleLawOfCosine
// 0x0038 (0x0040 - 0x0008)
struct FRigUnit_MathDoubleLawOfCosine : public FRigUnit_MathDoubleBase
{
	double                                             A_69;                                                     // 0x0008(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	double                                             B_69;                                                     // 0x0010(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	double                                             C_69;                                                     // 0x0018(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	double                                             AlphaAngle_69;                                            // 0x0020(0x0008) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	double                                             BetaAngle_69;                                             // 0x0028(0x0008) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	double                                             GammaAngle_69;                                            // 0x0030(0x0008) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	bool                                               bValid_69;                                                // 0x0038(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0039(0x0007) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_MathDoubleExponential
// 0x0000 (0x0018 - 0x0018)
struct FRigUnit_MathDoubleExponential : public FRigUnit_MathDoubleUnaryOp
{

};

// ScriptStruct ControlRig.RigUnit_MathFloatBase
// 0x0000 (0x0008 - 0x0008)
struct FRigUnit_MathFloatBase : public FRigUnit_MathBase
{

};

// ScriptStruct ControlRig.RigUnit_MathFloatConstant
// 0x0008 (0x0010 - 0x0008)
struct FRigUnit_MathFloatConstant : public FRigUnit_MathFloatBase
{
	float                                              Value_69;                                                 // 0x0008(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x000C(0x0004) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_MathFloatUnaryOp
// 0x0008 (0x0010 - 0x0008)
struct FRigUnit_MathFloatUnaryOp : public FRigUnit_MathFloatBase
{
	float                                              Value_69;                                                 // 0x0008(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              Result_69;                                                // 0x000C(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_MathFloatBinaryOp
// 0x0010 (0x0018 - 0x0008)
struct FRigUnit_MathFloatBinaryOp : public FRigUnit_MathFloatBase
{
	float                                              A_69;                                                     // 0x0008(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              B_69;                                                     // 0x000C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              Result_69;                                                // 0x0010(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0014(0x0004) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_MathFloatConstPi
// 0x0000 (0x0010 - 0x0010)
struct FRigUnit_MathFloatConstPi : public FRigUnit_MathFloatConstant
{

};

// ScriptStruct ControlRig.RigUnit_MathFloatConstHalfPi
// 0x0000 (0x0010 - 0x0010)
struct FRigUnit_MathFloatConstHalfPi : public FRigUnit_MathFloatConstant
{

};

// ScriptStruct ControlRig.RigUnit_MathFloatConstTwoPi
// 0x0000 (0x0010 - 0x0010)
struct FRigUnit_MathFloatConstTwoPi : public FRigUnit_MathFloatConstant
{

};

// ScriptStruct ControlRig.RigUnit_MathFloatConstE
// 0x0000 (0x0010 - 0x0010)
struct FRigUnit_MathFloatConstE : public FRigUnit_MathFloatConstant
{

};

// ScriptStruct ControlRig.RigUnit_MathFloatAdd
// 0x0000 (0x0018 - 0x0018)
struct FRigUnit_MathFloatAdd : public FRigUnit_MathFloatBinaryOp
{

};

// ScriptStruct ControlRig.RigUnit_MathFloatSub
// 0x0000 (0x0018 - 0x0018)
struct FRigUnit_MathFloatSub : public FRigUnit_MathFloatBinaryOp
{

};

// ScriptStruct ControlRig.RigUnit_MathFloatMul
// 0x0000 (0x0018 - 0x0018)
struct FRigUnit_MathFloatMul : public FRigUnit_MathFloatBinaryOp
{

};

// ScriptStruct ControlRig.RigUnit_MathFloatDiv
// 0x0000 (0x0018 - 0x0018)
struct FRigUnit_MathFloatDiv : public FRigUnit_MathFloatBinaryOp
{

};

// ScriptStruct ControlRig.RigUnit_MathFloatMod
// 0x0000 (0x0018 - 0x0018)
struct FRigUnit_MathFloatMod : public FRigUnit_MathFloatBinaryOp
{

};

// ScriptStruct ControlRig.RigUnit_MathFloatMin
// 0x0000 (0x0018 - 0x0018)
struct FRigUnit_MathFloatMin : public FRigUnit_MathFloatBinaryOp
{

};

// ScriptStruct ControlRig.RigUnit_MathFloatMax
// 0x0000 (0x0018 - 0x0018)
struct FRigUnit_MathFloatMax : public FRigUnit_MathFloatBinaryOp
{

};

// ScriptStruct ControlRig.RigUnit_MathFloatPow
// 0x0000 (0x0018 - 0x0018)
struct FRigUnit_MathFloatPow : public FRigUnit_MathFloatBinaryOp
{

};

// ScriptStruct ControlRig.RigUnit_MathFloatSqrt
// 0x0000 (0x0010 - 0x0010)
struct FRigUnit_MathFloatSqrt : public FRigUnit_MathFloatUnaryOp
{

};

// ScriptStruct ControlRig.RigUnit_MathFloatNegate
// 0x0000 (0x0010 - 0x0010)
struct FRigUnit_MathFloatNegate : public FRigUnit_MathFloatUnaryOp
{

};

// ScriptStruct ControlRig.RigUnit_MathFloatAbs
// 0x0000 (0x0010 - 0x0010)
struct FRigUnit_MathFloatAbs : public FRigUnit_MathFloatUnaryOp
{

};

// ScriptStruct ControlRig.RigUnit_MathFloatFloor
// 0x0010 (0x0018 - 0x0008)
struct FRigUnit_MathFloatFloor : public FRigUnit_MathFloatBase
{
	float                                              Value_69;                                                 // 0x0008(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              Result_69;                                                // 0x000C(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                Int_69;                                                   // 0x0010(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0014(0x0004) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_MathFloatCeil
// 0x0010 (0x0018 - 0x0008)
struct FRigUnit_MathFloatCeil : public FRigUnit_MathFloatBase
{
	float                                              Value_69;                                                 // 0x0008(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              Result_69;                                                // 0x000C(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                Int_69;                                                   // 0x0010(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0014(0x0004) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_MathFloatRound
// 0x0010 (0x0018 - 0x0008)
struct FRigUnit_MathFloatRound : public FRigUnit_MathFloatBase
{
	float                                              Value_69;                                                 // 0x0008(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              Result_69;                                                // 0x000C(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                Int_69;                                                   // 0x0010(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0014(0x0004) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_MathFloatToInt
// 0x0008 (0x0010 - 0x0008)
struct FRigUnit_MathFloatToInt : public FRigUnit_MathFloatBase
{
	float                                              Value_69;                                                 // 0x0008(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                Result_69;                                                // 0x000C(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_MathFloatSign
// 0x0000 (0x0010 - 0x0010)
struct FRigUnit_MathFloatSign : public FRigUnit_MathFloatUnaryOp
{

};

// ScriptStruct ControlRig.RigUnit_MathFloatClamp
// 0x0010 (0x0018 - 0x0008)
struct FRigUnit_MathFloatClamp : public FRigUnit_MathFloatBase
{
	float                                              Value_69;                                                 // 0x0008(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              Minimum_69;                                               // 0x000C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              Maximum_69;                                               // 0x0010(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              Result_69;                                                // 0x0014(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_MathFloatLerp
// 0x0010 (0x0018 - 0x0008)
struct FRigUnit_MathFloatLerp : public FRigUnit_MathFloatBase
{
	float                                              A_69;                                                     // 0x0008(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              B_69;                                                     // 0x000C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              T_69;                                                     // 0x0010(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              Result_69;                                                // 0x0014(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_MathFloatRemap
// 0x0020 (0x0028 - 0x0008)
struct FRigUnit_MathFloatRemap : public FRigUnit_MathFloatBase
{
	float                                              Value_69;                                                 // 0x0008(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              SourceMinimum_69;                                         // 0x000C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              SourceMaximum_69;                                         // 0x0010(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              TargetMinimum_69;                                         // 0x0014(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              TargetMaximum_69;                                         // 0x0018(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bClamp_69;                                                // 0x001C(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x001D(0x0003) MISSED OFFSET
	float                                              Result_69;                                                // 0x0020(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x4];                                       // 0x0024(0x0004) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_MathFloatEquals
// 0x0010 (0x0018 - 0x0008)
struct FRigUnit_MathFloatEquals : public FRigUnit_MathFloatBase
{
	float                                              A_69;                                                     // 0x0008(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              B_69;                                                     // 0x000C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               Result_69;                                                // 0x0010(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0011(0x0007) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_MathFloatNotEquals
// 0x0010 (0x0018 - 0x0008)
struct FRigUnit_MathFloatNotEquals : public FRigUnit_MathFloatBase
{
	float                                              A_69;                                                     // 0x0008(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              B_69;                                                     // 0x000C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               Result_69;                                                // 0x0010(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0011(0x0007) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_MathFloatGreater
// 0x0010 (0x0018 - 0x0008)
struct FRigUnit_MathFloatGreater : public FRigUnit_MathFloatBase
{
	float                                              A_69;                                                     // 0x0008(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              B_69;                                                     // 0x000C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               Result_69;                                                // 0x0010(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0011(0x0007) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_MathFloatLess
// 0x0010 (0x0018 - 0x0008)
struct FRigUnit_MathFloatLess : public FRigUnit_MathFloatBase
{
	float                                              A_69;                                                     // 0x0008(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              B_69;                                                     // 0x000C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               Result_69;                                                // 0x0010(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0011(0x0007) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_MathFloatGreaterEqual
// 0x0010 (0x0018 - 0x0008)
struct FRigUnit_MathFloatGreaterEqual : public FRigUnit_MathFloatBase
{
	float                                              A_69;                                                     // 0x0008(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              B_69;                                                     // 0x000C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               Result_69;                                                // 0x0010(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0011(0x0007) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_MathFloatLessEqual
// 0x0010 (0x0018 - 0x0008)
struct FRigUnit_MathFloatLessEqual : public FRigUnit_MathFloatBase
{
	float                                              A_69;                                                     // 0x0008(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              B_69;                                                     // 0x000C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               Result_69;                                                // 0x0010(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0011(0x0007) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_MathFloatIsNearlyZero
// 0x0010 (0x0018 - 0x0008)
struct FRigUnit_MathFloatIsNearlyZero : public FRigUnit_MathFloatBase
{
	float                                              Value_69;                                                 // 0x0008(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              Tolerance_69;                                             // 0x000C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               Result_69;                                                // 0x0010(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0011(0x0007) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_MathFloatIsNearlyEqual
// 0x0010 (0x0018 - 0x0008)
struct FRigUnit_MathFloatIsNearlyEqual : public FRigUnit_MathFloatBase
{
	float                                              A_69;                                                     // 0x0008(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              B_69;                                                     // 0x000C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              Tolerance_69;                                             // 0x0010(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               Result_69;                                                // 0x0014(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0015(0x0003) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_MathFloatSelectBool
// 0x0010 (0x0018 - 0x0008)
struct FRigUnit_MathFloatSelectBool : public FRigUnit_MathFloatBase
{
	bool                                               Condition_69;                                             // 0x0008(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0009(0x0003) MISSED OFFSET
	float                                              IfTrue_69;                                                // 0x000C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              IfFalse_69;                                               // 0x0010(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              Result_69;                                                // 0x0014(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_MathFloatDeg
// 0x0000 (0x0010 - 0x0010)
struct FRigUnit_MathFloatDeg : public FRigUnit_MathFloatUnaryOp
{

};

// ScriptStruct ControlRig.RigUnit_MathFloatRad
// 0x0000 (0x0010 - 0x0010)
struct FRigUnit_MathFloatRad : public FRigUnit_MathFloatUnaryOp
{

};

// ScriptStruct ControlRig.RigUnit_MathFloatSin
// 0x0000 (0x0010 - 0x0010)
struct FRigUnit_MathFloatSin : public FRigUnit_MathFloatUnaryOp
{

};

// ScriptStruct ControlRig.RigUnit_MathFloatCos
// 0x0000 (0x0010 - 0x0010)
struct FRigUnit_MathFloatCos : public FRigUnit_MathFloatUnaryOp
{

};

// ScriptStruct ControlRig.RigUnit_MathFloatTan
// 0x0000 (0x0010 - 0x0010)
struct FRigUnit_MathFloatTan : public FRigUnit_MathFloatUnaryOp
{

};

// ScriptStruct ControlRig.RigUnit_MathFloatAsin
// 0x0000 (0x0010 - 0x0010)
struct FRigUnit_MathFloatAsin : public FRigUnit_MathFloatUnaryOp
{

};

// ScriptStruct ControlRig.RigUnit_MathFloatAcos
// 0x0000 (0x0010 - 0x0010)
struct FRigUnit_MathFloatAcos : public FRigUnit_MathFloatUnaryOp
{

};

// ScriptStruct ControlRig.RigUnit_MathFloatAtan
// 0x0000 (0x0010 - 0x0010)
struct FRigUnit_MathFloatAtan : public FRigUnit_MathFloatUnaryOp
{

};

// ScriptStruct ControlRig.RigUnit_MathFloatLawOfCosine
// 0x0020 (0x0028 - 0x0008)
struct FRigUnit_MathFloatLawOfCosine : public FRigUnit_MathFloatBase
{
	float                                              A_69;                                                     // 0x0008(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              B_69;                                                     // 0x000C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              C_69;                                                     // 0x0010(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              AlphaAngle_69;                                            // 0x0014(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              BetaAngle_69;                                             // 0x0018(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              GammaAngle_69;                                            // 0x001C(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	bool                                               bValid_69;                                                // 0x0020(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0021(0x0007) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_MathFloatExponential
// 0x0000 (0x0010 - 0x0010)
struct FRigUnit_MathFloatExponential : public FRigUnit_MathFloatUnaryOp
{

};

// ScriptStruct ControlRig.RigUnit_MathIntBase
// 0x0000 (0x0008 - 0x0008)
struct FRigUnit_MathIntBase : public FRigUnit_MathBase
{

};

// ScriptStruct ControlRig.RigUnit_MathIntUnaryOp
// 0x0008 (0x0010 - 0x0008)
struct FRigUnit_MathIntUnaryOp : public FRigUnit_MathIntBase
{
	int                                                Value_69;                                                 // 0x0008(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                Result_69;                                                // 0x000C(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_MathIntBinaryOp
// 0x0010 (0x0018 - 0x0008)
struct FRigUnit_MathIntBinaryOp : public FRigUnit_MathIntBase
{
	int                                                A_69;                                                     // 0x0008(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                B_69;                                                     // 0x000C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                Result_69;                                                // 0x0010(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0014(0x0004) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_MathIntAdd
// 0x0000 (0x0018 - 0x0018)
struct FRigUnit_MathIntAdd : public FRigUnit_MathIntBinaryOp
{

};

// ScriptStruct ControlRig.RigUnit_MathIntSub
// 0x0000 (0x0018 - 0x0018)
struct FRigUnit_MathIntSub : public FRigUnit_MathIntBinaryOp
{

};

// ScriptStruct ControlRig.RigUnit_MathIntMul
// 0x0000 (0x0018 - 0x0018)
struct FRigUnit_MathIntMul : public FRigUnit_MathIntBinaryOp
{

};

// ScriptStruct ControlRig.RigUnit_MathIntDiv
// 0x0000 (0x0018 - 0x0018)
struct FRigUnit_MathIntDiv : public FRigUnit_MathIntBinaryOp
{

};

// ScriptStruct ControlRig.RigUnit_MathIntMod
// 0x0000 (0x0018 - 0x0018)
struct FRigUnit_MathIntMod : public FRigUnit_MathIntBinaryOp
{

};

// ScriptStruct ControlRig.RigUnit_MathIntMin
// 0x0000 (0x0018 - 0x0018)
struct FRigUnit_MathIntMin : public FRigUnit_MathIntBinaryOp
{

};

// ScriptStruct ControlRig.RigUnit_MathIntMax
// 0x0000 (0x0018 - 0x0018)
struct FRigUnit_MathIntMax : public FRigUnit_MathIntBinaryOp
{

};

// ScriptStruct ControlRig.RigUnit_MathIntPow
// 0x0000 (0x0018 - 0x0018)
struct FRigUnit_MathIntPow : public FRigUnit_MathIntBinaryOp
{

};

// ScriptStruct ControlRig.RigUnit_MathIntNegate
// 0x0000 (0x0010 - 0x0010)
struct FRigUnit_MathIntNegate : public FRigUnit_MathIntUnaryOp
{

};

// ScriptStruct ControlRig.RigUnit_MathIntAbs
// 0x0000 (0x0010 - 0x0010)
struct FRigUnit_MathIntAbs : public FRigUnit_MathIntUnaryOp
{

};

// ScriptStruct ControlRig.RigUnit_MathIntToFloat
// 0x0008 (0x0010 - 0x0008)
struct FRigUnit_MathIntToFloat : public FRigUnit_MathIntBase
{
	int                                                Value_69;                                                 // 0x0008(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              Result_69;                                                // 0x000C(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_MathIntSign
// 0x0000 (0x0010 - 0x0010)
struct FRigUnit_MathIntSign : public FRigUnit_MathIntUnaryOp
{

};

// ScriptStruct ControlRig.RigUnit_MathIntClamp
// 0x0010 (0x0018 - 0x0008)
struct FRigUnit_MathIntClamp : public FRigUnit_MathIntBase
{
	int                                                Value_69;                                                 // 0x0008(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                Minimum_69;                                               // 0x000C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                Maximum_69;                                               // 0x0010(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                Result_69;                                                // 0x0014(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_MathIntEquals
// 0x0010 (0x0018 - 0x0008)
struct FRigUnit_MathIntEquals : public FRigUnit_MathIntBase
{
	int                                                A_69;                                                     // 0x0008(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                B_69;                                                     // 0x000C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               Result_69;                                                // 0x0010(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0011(0x0007) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_MathIntNotEquals
// 0x0010 (0x0018 - 0x0008)
struct FRigUnit_MathIntNotEquals : public FRigUnit_MathIntBase
{
	int                                                A_69;                                                     // 0x0008(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                B_69;                                                     // 0x000C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               Result_69;                                                // 0x0010(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0011(0x0007) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_MathIntGreater
// 0x0010 (0x0018 - 0x0008)
struct FRigUnit_MathIntGreater : public FRigUnit_MathIntBase
{
	int                                                A_69;                                                     // 0x0008(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                B_69;                                                     // 0x000C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               Result_69;                                                // 0x0010(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0011(0x0007) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_MathIntLess
// 0x0010 (0x0018 - 0x0008)
struct FRigUnit_MathIntLess : public FRigUnit_MathIntBase
{
	int                                                A_69;                                                     // 0x0008(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                B_69;                                                     // 0x000C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               Result_69;                                                // 0x0010(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0011(0x0007) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_MathIntGreaterEqual
// 0x0010 (0x0018 - 0x0008)
struct FRigUnit_MathIntGreaterEqual : public FRigUnit_MathIntBase
{
	int                                                A_69;                                                     // 0x0008(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                B_69;                                                     // 0x000C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               Result_69;                                                // 0x0010(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0011(0x0007) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_MathIntLessEqual
// 0x0010 (0x0018 - 0x0008)
struct FRigUnit_MathIntLessEqual : public FRigUnit_MathIntBase
{
	int                                                A_69;                                                     // 0x0008(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                B_69;                                                     // 0x000C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               Result_69;                                                // 0x0010(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0011(0x0007) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_MathMatrixBase
// 0x0000 (0x0008 - 0x0008)
struct FRigUnit_MathMatrixBase : public FRigUnit_MathBase
{

};

// ScriptStruct ControlRig.RigUnit_MathMatrixUnaryOp
// 0x0108 (0x0110 - 0x0008)
struct FRigUnit_MathMatrixUnaryOp : public FRigUnit_MathMatrixBase
{
	unsigned char                                      UnknownData00[0x8];                                       // 0x0008(0x0008) MISSED OFFSET
	struct FMatrix                                     Value_69;                                                 // 0x0010(0x0080) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FMatrix                                     Result_69;                                                // 0x0090(0x0080) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_MathMatrixBinaryOp
// 0x0188 (0x0190 - 0x0008)
struct FRigUnit_MathMatrixBinaryOp : public FRigUnit_MathMatrixBase
{
	unsigned char                                      UnknownData00[0x8];                                       // 0x0008(0x0008) MISSED OFFSET
	struct FMatrix                                     A_69;                                                     // 0x0010(0x0080) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FMatrix                                     B_69;                                                     // 0x0090(0x0080) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FMatrix                                     Result_69;                                                // 0x0110(0x0080) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_MathMatrixToTransform
// 0x00E8 (0x00F0 - 0x0008)
struct FRigUnit_MathMatrixToTransform : public FRigUnit_MathMatrixBase
{
	unsigned char                                      UnknownData00[0x8];                                       // 0x0008(0x0008) MISSED OFFSET
	struct FMatrix                                     Value_69;                                                 // 0x0010(0x0080) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FCoreUObject_FTransform                     Result_69;                                                // 0x0090(0x0060) (BlueprintVisible, BlueprintReadOnly, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_MathMatrixFromTransform
// 0x00E8 (0x00F0 - 0x0008)
struct FRigUnit_MathMatrixFromTransform : public FRigUnit_MathMatrixBase
{
	unsigned char                                      UnknownData00[0x8];                                       // 0x0008(0x0008) MISSED OFFSET
	struct FCoreUObject_FTransform                     Transform_69;                                             // 0x0010(0x0060) (Edit, BlueprintVisible, IsPlainOldData)
	struct FMatrix                                     Result_69;                                                // 0x0070(0x0080) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_MathMatrixFromTransformV2
// 0x00E8 (0x00F0 - 0x0008)
struct FRigUnit_MathMatrixFromTransformV2 : public FRigUnit_MathMatrixBase
{
	unsigned char                                      UnknownData00[0x8];                                       // 0x0008(0x0008) MISSED OFFSET
	struct FCoreUObject_FTransform                     Value_69;                                                 // 0x0010(0x0060) (Edit, BlueprintVisible, IsPlainOldData)
	struct FMatrix                                     Result_69;                                                // 0x0070(0x0080) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_MathMatrixToVectors
// 0x00E8 (0x00F0 - 0x0008)
struct FRigUnit_MathMatrixToVectors : public FRigUnit_MathMatrixBase
{
	unsigned char                                      UnknownData00[0x8];                                       // 0x0008(0x0008) MISSED OFFSET
	struct FMatrix                                     Value_69;                                                 // 0x0010(0x0080) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FVector                                     Origin_69;                                                // 0x0090(0x0018) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	struct FVector                                     X_69;                                                     // 0x00A8(0x0018) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	struct FVector                                     Y_69;                                                     // 0x00C0(0x0018) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	struct FVector                                     Z_69;                                                     // 0x00D8(0x0018) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_MathMatrixFromVectors
// 0x00E8 (0x00F0 - 0x0008)
struct FRigUnit_MathMatrixFromVectors : public FRigUnit_MathMatrixBase
{
	struct FVector                                     Origin_69;                                                // 0x0008(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FVector                                     X_69;                                                     // 0x0020(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FVector                                     Y_69;                                                     // 0x0038(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FVector                                     Z_69;                                                     // 0x0050(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x8];                                       // 0x0068(0x0008) MISSED OFFSET
	struct FMatrix                                     Result_69;                                                // 0x0070(0x0080) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_MathMatrixMul
// 0x0000 (0x0190 - 0x0190)
struct FRigUnit_MathMatrixMul : public FRigUnit_MathMatrixBinaryOp
{

};

// ScriptStruct ControlRig.RigUnit_MathMatrixInverse
// 0x0000 (0x0110 - 0x0110)
struct FRigUnit_MathMatrixInverse : public FRigUnit_MathMatrixUnaryOp
{

};

// ScriptStruct ControlRig.RigUnit_MathQuaternionBase
// 0x0000 (0x0008 - 0x0008)
struct FRigUnit_MathQuaternionBase : public FRigUnit_MathBase
{

};

// ScriptStruct ControlRig.RigUnit_MathQuaternionUnaryOp
// 0x0048 (0x0050 - 0x0008)
struct FRigUnit_MathQuaternionUnaryOp : public FRigUnit_MathQuaternionBase
{
	unsigned char                                      UnknownData00[0x8];                                       // 0x0008(0x0008) MISSED OFFSET
	struct FQuat                                       Value_69;                                                 // 0x0010(0x0020) (Edit, BlueprintVisible, IsPlainOldData)
	struct FQuat                                       Result_69;                                                // 0x0030(0x0020) (BlueprintVisible, BlueprintReadOnly, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_MathQuaternionBinaryOp
// 0x0068 (0x0070 - 0x0008)
struct FRigUnit_MathQuaternionBinaryOp : public FRigUnit_MathQuaternionBase
{
	unsigned char                                      UnknownData00[0x8];                                       // 0x0008(0x0008) MISSED OFFSET
	struct FQuat                                       A_69;                                                     // 0x0010(0x0020) (Edit, BlueprintVisible, IsPlainOldData)
	struct FQuat                                       B_69;                                                     // 0x0030(0x0020) (Edit, BlueprintVisible, IsPlainOldData)
	struct FQuat                                       Result_69;                                                // 0x0050(0x0020) (BlueprintVisible, BlueprintReadOnly, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_MathQuaternionFromAxisAndAngle
// 0x0048 (0x0050 - 0x0008)
struct FRigUnit_MathQuaternionFromAxisAndAngle : public FRigUnit_MathQuaternionBase
{
	struct FVector                                     Axis_69;                                                  // 0x0008(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              Angle_69;                                                 // 0x0020(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0xC];                                       // 0x0024(0x000C) MISSED OFFSET
	struct FQuat                                       Result_69;                                                // 0x0030(0x0020) (BlueprintVisible, BlueprintReadOnly, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_MathQuaternionFromEuler
// 0x0048 (0x0050 - 0x0008)
struct FRigUnit_MathQuaternionFromEuler : public FRigUnit_MathQuaternionBase
{
	struct FVector                                     Euler_69;                                                 // 0x0008(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	EEulerRotationOrder                                RotationOrder_69;                                         // 0x0020(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0xF];                                       // 0x0021(0x000F) MISSED OFFSET
	struct FQuat                                       Result_69;                                                // 0x0030(0x0020) (BlueprintVisible, BlueprintReadOnly, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_MathQuaternionFromRotator
// 0x0038 (0x0040 - 0x0008)
struct FRigUnit_MathQuaternionFromRotator : public FRigUnit_MathQuaternionBase
{
	struct FRotator                                    Rotator_69;                                               // 0x0008(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FQuat                                       Result_69;                                                // 0x0020(0x0020) (BlueprintVisible, BlueprintReadOnly, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_MathQuaternionFromRotatorV2
// 0x0038 (0x0040 - 0x0008)
struct FRigUnit_MathQuaternionFromRotatorV2 : public FRigUnit_MathQuaternionBase
{
	struct FRotator                                    Value_69;                                                 // 0x0008(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FQuat                                       Result_69;                                                // 0x0020(0x0020) (BlueprintVisible, BlueprintReadOnly, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_MathQuaternionFromTwoVectors
// 0x0058 (0x0060 - 0x0008)
struct FRigUnit_MathQuaternionFromTwoVectors : public FRigUnit_MathQuaternionBase
{
	struct FVector                                     A_69;                                                     // 0x0008(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FVector                                     B_69;                                                     // 0x0020(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x8];                                       // 0x0038(0x0008) MISSED OFFSET
	struct FQuat                                       Result_69;                                                // 0x0040(0x0020) (BlueprintVisible, BlueprintReadOnly, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_MathQuaternionToAxisAndAngle
// 0x0048 (0x0050 - 0x0008)
struct FRigUnit_MathQuaternionToAxisAndAngle : public FRigUnit_MathQuaternionBase
{
	unsigned char                                      UnknownData00[0x8];                                       // 0x0008(0x0008) MISSED OFFSET
	struct FQuat                                       Value_69;                                                 // 0x0010(0x0020) (Edit, BlueprintVisible, IsPlainOldData)
	struct FVector                                     Axis_69;                                                  // 0x0030(0x0018) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              Angle_69;                                                 // 0x0048(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x4];                                       // 0x004C(0x0004) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_MathQuaternionScale
// 0x0038 (0x0040 - 0x0008)
struct FRigUnit_MathQuaternionScale : public FRigUnit_MathQuaternionBase
{
	unsigned char                                      UnknownData00[0x8];                                       // 0x0008(0x0008) MISSED OFFSET
	struct FQuat                                       Value_69;                                                 // 0x0010(0x0020) (Edit, BlueprintVisible, IsPlainOldData)
	float                                              Scale_69;                                                 // 0x0030(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0xC];                                       // 0x0034(0x000C) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_MathQuaternionScaleV2
// 0x0058 (0x0060 - 0x0008)
struct FRigUnit_MathQuaternionScaleV2 : public FRigUnit_MathQuaternionBase
{
	unsigned char                                      UnknownData00[0x8];                                       // 0x0008(0x0008) MISSED OFFSET
	struct FQuat                                       Value_69;                                                 // 0x0010(0x0020) (Edit, BlueprintVisible, IsPlainOldData)
	float                                              Factor_69;                                                // 0x0030(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0xC];                                       // 0x0034(0x000C) MISSED OFFSET
	struct FQuat                                       Result_69;                                                // 0x0040(0x0020) (BlueprintVisible, BlueprintReadOnly, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_MathQuaternionToEuler
// 0x0048 (0x0050 - 0x0008)
struct FRigUnit_MathQuaternionToEuler : public FRigUnit_MathQuaternionBase
{
	unsigned char                                      UnknownData00[0x8];                                       // 0x0008(0x0008) MISSED OFFSET
	struct FQuat                                       Value_69;                                                 // 0x0010(0x0020) (Edit, BlueprintVisible, IsPlainOldData)
	EEulerRotationOrder                                RotationOrder_69;                                         // 0x0030(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x7];                                       // 0x0031(0x0007) MISSED OFFSET
	struct FVector                                     Result_69;                                                // 0x0038(0x0018) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_MathQuaternionToRotator
// 0x0048 (0x0050 - 0x0008)
struct FRigUnit_MathQuaternionToRotator : public FRigUnit_MathQuaternionBase
{
	unsigned char                                      UnknownData00[0x8];                                       // 0x0008(0x0008) MISSED OFFSET
	struct FQuat                                       Value_69;                                                 // 0x0010(0x0020) (Edit, BlueprintVisible, IsPlainOldData)
	struct FRotator                                    Result_69;                                                // 0x0030(0x0018) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x8];                                       // 0x0048(0x0008) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_MathQuaternionMul
// 0x0000 (0x0070 - 0x0070)
struct FRigUnit_MathQuaternionMul : public FRigUnit_MathQuaternionBinaryOp
{

};

// ScriptStruct ControlRig.RigUnit_MathQuaternionInverse
// 0x0000 (0x0050 - 0x0050)
struct FRigUnit_MathQuaternionInverse : public FRigUnit_MathQuaternionUnaryOp
{

};

// ScriptStruct ControlRig.RigUnit_MathQuaternionSlerp
// 0x0078 (0x0080 - 0x0008)
struct FRigUnit_MathQuaternionSlerp : public FRigUnit_MathQuaternionBase
{
	unsigned char                                      UnknownData00[0x8];                                       // 0x0008(0x0008) MISSED OFFSET
	struct FQuat                                       A_69;                                                     // 0x0010(0x0020) (Edit, BlueprintVisible, IsPlainOldData)
	struct FQuat                                       B_69;                                                     // 0x0030(0x0020) (Edit, BlueprintVisible, IsPlainOldData)
	float                                              T_69;                                                     // 0x0050(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0xC];                                       // 0x0054(0x000C) MISSED OFFSET
	struct FQuat                                       Result_69;                                                // 0x0060(0x0020) (BlueprintVisible, BlueprintReadOnly, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_MathQuaternionEquals
// 0x0058 (0x0060 - 0x0008)
struct FRigUnit_MathQuaternionEquals : public FRigUnit_MathQuaternionBase
{
	unsigned char                                      UnknownData00[0x8];                                       // 0x0008(0x0008) MISSED OFFSET
	struct FQuat                                       A_69;                                                     // 0x0010(0x0020) (Edit, BlueprintVisible, IsPlainOldData)
	struct FQuat                                       B_69;                                                     // 0x0030(0x0020) (Edit, BlueprintVisible, IsPlainOldData)
	bool                                               Result_69;                                                // 0x0050(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0xF];                                       // 0x0051(0x000F) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_MathQuaternionNotEquals
// 0x0058 (0x0060 - 0x0008)
struct FRigUnit_MathQuaternionNotEquals : public FRigUnit_MathQuaternionBase
{
	unsigned char                                      UnknownData00[0x8];                                       // 0x0008(0x0008) MISSED OFFSET
	struct FQuat                                       A_69;                                                     // 0x0010(0x0020) (Edit, BlueprintVisible, IsPlainOldData)
	struct FQuat                                       B_69;                                                     // 0x0030(0x0020) (Edit, BlueprintVisible, IsPlainOldData)
	bool                                               Result_69;                                                // 0x0050(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0xF];                                       // 0x0051(0x000F) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_MathQuaternionSelectBool
// 0x0068 (0x0070 - 0x0008)
struct FRigUnit_MathQuaternionSelectBool : public FRigUnit_MathQuaternionBase
{
	bool                                               Condition_69;                                             // 0x0008(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0009(0x0007) MISSED OFFSET
	struct FQuat                                       IfTrue_69;                                                // 0x0010(0x0020) (Edit, BlueprintVisible, IsPlainOldData)
	struct FQuat                                       IfFalse_69;                                               // 0x0030(0x0020) (Edit, BlueprintVisible, IsPlainOldData)
	struct FQuat                                       Result_69;                                                // 0x0050(0x0020) (BlueprintVisible, BlueprintReadOnly, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_MathQuaternionDot
// 0x0058 (0x0060 - 0x0008)
struct FRigUnit_MathQuaternionDot : public FRigUnit_MathQuaternionBase
{
	unsigned char                                      UnknownData00[0x8];                                       // 0x0008(0x0008) MISSED OFFSET
	struct FQuat                                       A_69;                                                     // 0x0010(0x0020) (Edit, BlueprintVisible, IsPlainOldData)
	struct FQuat                                       B_69;                                                     // 0x0030(0x0020) (Edit, BlueprintVisible, IsPlainOldData)
	float                                              Result_69;                                                // 0x0050(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0xC];                                       // 0x0054(0x000C) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_MathQuaternionUnit
// 0x0000 (0x0050 - 0x0050)
struct FRigUnit_MathQuaternionUnit : public FRigUnit_MathQuaternionUnaryOp
{

};

// ScriptStruct ControlRig.RigUnit_MathQuaternionRotateVector
// 0x0058 (0x0060 - 0x0008)
struct FRigUnit_MathQuaternionRotateVector : public FRigUnit_MathQuaternionBase
{
	unsigned char                                      UnknownData00[0x8];                                       // 0x0008(0x0008) MISSED OFFSET
	struct FQuat                                       Transform_69;                                             // 0x0010(0x0020) (Edit, BlueprintVisible, IsPlainOldData)
	struct FVector                                     Vector_69;                                                // 0x0030(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FVector                                     Result_69;                                                // 0x0048(0x0018) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_MathQuaternionGetAxis
// 0x0048 (0x0050 - 0x0008)
struct FRigUnit_MathQuaternionGetAxis : public FRigUnit_MathQuaternionBase
{
	unsigned char                                      UnknownData00[0x8];                                       // 0x0008(0x0008) MISSED OFFSET
	struct FQuat                                       Quaternion_69;                                            // 0x0010(0x0020) (Edit, BlueprintVisible, IsPlainOldData)
	TEnumAsByte<EAxis>                                 Axis_69;                                                  // 0x0030(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x7];                                       // 0x0031(0x0007) MISSED OFFSET
	struct FVector                                     Result_69;                                                // 0x0038(0x0018) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_MathQuaternionSwingTwist
// 0x0088 (0x0090 - 0x0008)
struct FRigUnit_MathQuaternionSwingTwist : public FRigUnit_MathQuaternionBase
{
	unsigned char                                      UnknownData00[0x8];                                       // 0x0008(0x0008) MISSED OFFSET
	struct FQuat                                       Input_69;                                                 // 0x0010(0x0020) (Edit, BlueprintVisible, IsPlainOldData)
	struct FVector                                     TwistAxis_69;                                             // 0x0030(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x8];                                       // 0x0048(0x0008) MISSED OFFSET
	struct FQuat                                       Swing_69;                                                 // 0x0050(0x0020) (BlueprintVisible, BlueprintReadOnly, IsPlainOldData)
	struct FQuat                                       Twist_69;                                                 // 0x0070(0x0020) (BlueprintVisible, BlueprintReadOnly, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_MathQuaternionRotationOrder
// 0x0008 (0x0010 - 0x0008)
struct FRigUnit_MathQuaternionRotationOrder : public FRigUnit_MathBase
{
	EEulerRotationOrder                                RotationOrder_69;                                         // 0x0008(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0009(0x0007) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_MathQuaternionMakeRelative
// 0x0068 (0x0070 - 0x0008)
struct FRigUnit_MathQuaternionMakeRelative : public FRigUnit_MathQuaternionBase
{
	unsigned char                                      UnknownData00[0x8];                                       // 0x0008(0x0008) MISSED OFFSET
	struct FQuat                                       Global_69;                                                // 0x0010(0x0020) (Edit, BlueprintVisible, IsPlainOldData)
	struct FQuat                                       Parent_69;                                                // 0x0030(0x0020) (Edit, BlueprintVisible, IsPlainOldData)
	struct FQuat                                       Local_69;                                                 // 0x0050(0x0020) (BlueprintVisible, BlueprintReadOnly, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_MathQuaternionMakeAbsolute
// 0x0068 (0x0070 - 0x0008)
struct FRigUnit_MathQuaternionMakeAbsolute : public FRigUnit_MathQuaternionBase
{
	unsigned char                                      UnknownData00[0x8];                                       // 0x0008(0x0008) MISSED OFFSET
	struct FQuat                                       Local_69;                                                 // 0x0010(0x0020) (Edit, BlueprintVisible, IsPlainOldData)
	struct FQuat                                       Parent_69;                                                // 0x0030(0x0020) (Edit, BlueprintVisible, IsPlainOldData)
	struct FQuat                                       Global_69;                                                // 0x0050(0x0020) (BlueprintVisible, BlueprintReadOnly, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_MathQuaternionMirrorTransform
// 0x00B8 (0x00C0 - 0x0008)
struct FRigUnit_MathQuaternionMirrorTransform : public FRigUnit_MathQuaternionBase
{
	unsigned char                                      UnknownData00[0x8];                                       // 0x0008(0x0008) MISSED OFFSET
	struct FQuat                                       Value_69;                                                 // 0x0010(0x0020) (Edit, BlueprintVisible, IsPlainOldData)
	TEnumAsByte<EAxis>                                 MirrorAxis_69;                                            // 0x0030(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<EAxis>                                 AxisToFlip_69;                                            // 0x0031(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0xE];                                       // 0x0032(0x000E) MISSED OFFSET
	struct FCoreUObject_FTransform                     CentralTransform_69;                                      // 0x0040(0x0060) (Edit, BlueprintVisible, IsPlainOldData)
	struct FQuat                                       Result_69;                                                // 0x00A0(0x0020) (BlueprintVisible, BlueprintReadOnly, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_MathRBFInterpolateQuatWorkData
// 0x0090
struct FRigUnit_MathRBFInterpolateQuatWorkData
{
	unsigned char                                      UnknownData00[0x90];                                      // 0x0000(0x0090) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_MathRBFInterpolateVectorWorkData
// 0x0090
struct FRigUnit_MathRBFInterpolateVectorWorkData
{
	unsigned char                                      UnknownData00[0x90];                                      // 0x0000(0x0090) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_MathRBFInterpolateBase
// 0x0000 (0x0008 - 0x0008)
struct FRigUnit_MathRBFInterpolateBase : public FRigUnit_MathBase
{

};

// ScriptStruct ControlRig.RigUnit_MathRBFInterpolateQuatBase
// 0x00E8 (0x00F0 - 0x0008)
struct FRigUnit_MathRBFInterpolateQuatBase : public FRigUnit_MathRBFInterpolateBase
{
	unsigned char                                      UnknownData00[0x8];                                       // 0x0008(0x0008) MISSED OFFSET
	struct FQuat                                       Input_69;                                                 // 0x0010(0x0020) (Edit, BlueprintVisible, IsPlainOldData)
	ERBFQuatDistanceType                               DistanceFunction_69;                                      // 0x0030(0x0001) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	ERBFKernelType                                     SmoothingFunction_69;                                     // 0x0031(0x0001) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	unsigned char                                      UnknownData01[0x2];                                       // 0x0032(0x0002) MISSED OFFSET
	float                                              SmoothingAngle_69;                                        // 0x0034(0x0004) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	bool                                               bNormalizeOutput_69;                                      // 0x0038(0x0001) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	unsigned char                                      UnknownData02[0x7];                                       // 0x0039(0x0007) MISSED OFFSET
	struct FVector                                     TwistAxis_69;                                             // 0x0040(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData03[0x8];                                       // 0x0058(0x0008) MISSED OFFSET
	struct FRigUnit_MathRBFInterpolateQuatWorkData     WorkData_69;                                              // 0x0060(0x0090) (Transient)
};

// ScriptStruct ControlRig.RigUnit_MathRBFInterpolateVectorBase
// 0x00B8 (0x00C0 - 0x0008)
struct FRigUnit_MathRBFInterpolateVectorBase : public FRigUnit_MathRBFInterpolateBase
{
	struct FVector                                     Input_69;                                                 // 0x0008(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	ERBFVectorDistanceType                             DistanceFunction_69;                                      // 0x0020(0x0001) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	ERBFKernelType                                     SmoothingFunction_69;                                     // 0x0021(0x0001) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	unsigned char                                      UnknownData00[0x2];                                       // 0x0022(0x0002) MISSED OFFSET
	float                                              SmoothingRadius_69;                                       // 0x0024(0x0004) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	bool                                               bNormalizeOutput_69;                                      // 0x0028(0x0001) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	unsigned char                                      UnknownData01[0x7];                                       // 0x0029(0x0007) MISSED OFFSET
	struct FRigUnit_MathRBFInterpolateVectorWorkData   WorkData_69;                                              // 0x0030(0x0090) (Transient)
};

// ScriptStruct ControlRig.MathRBFInterpolateQuatFloat_Target
// 0x0030
struct FMathRBFInterpolateQuatFloat_Target
{
	struct FQuat                                       Target_69;                                                // 0x0000(0x0020) (Edit, BlueprintVisible, IsPlainOldData)
	float                                              Value_69;                                                 // 0x0020(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0xC];                                       // 0x0024(0x000C) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_MathRBFInterpolateQuatFloat
// 0x0020 (0x0110 - 0x00F0)
struct FRigUnit_MathRBFInterpolateQuatFloat : public FRigUnit_MathRBFInterpolateQuatBase
{
	TArray<struct FMathRBFInterpolateQuatFloat_Target> Targets_69;                                               // 0x00F0(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	float                                              Output_69;                                                // 0x0100(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0xC];                                       // 0x0104(0x000C) MISSED OFFSET
};

// ScriptStruct ControlRig.MathRBFInterpolateQuatVector_Target
// 0x0040
struct FMathRBFInterpolateQuatVector_Target
{
	struct FQuat                                       Target_69;                                                // 0x0000(0x0020) (Edit, BlueprintVisible, IsPlainOldData)
	struct FVector                                     Value_69;                                                 // 0x0020(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x8];                                       // 0x0038(0x0008) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_MathRBFInterpolateQuatVector
// 0x0030 (0x0120 - 0x00F0)
struct FRigUnit_MathRBFInterpolateQuatVector : public FRigUnit_MathRBFInterpolateQuatBase
{
	TArray<struct FMathRBFInterpolateQuatVector_Target> Targets_69;                                               // 0x00F0(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FVector                                     Output_69;                                                // 0x0100(0x0018) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x8];                                       // 0x0118(0x0008) MISSED OFFSET
};

// ScriptStruct ControlRig.MathRBFInterpolateQuatColor_Target
// 0x0030
struct FMathRBFInterpolateQuatColor_Target
{
	struct FQuat                                       Target_69;                                                // 0x0000(0x0020) (Edit, BlueprintVisible, IsPlainOldData)
	struct FLinearColor                                Value_69;                                                 // 0x0020(0x0010) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_MathRBFInterpolateQuatColor
// 0x0020 (0x0110 - 0x00F0)
struct FRigUnit_MathRBFInterpolateQuatColor : public FRigUnit_MathRBFInterpolateQuatBase
{
	TArray<struct FMathRBFInterpolateQuatColor_Target> Targets_69;                                               // 0x00F0(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FLinearColor                                Output_69;                                                // 0x0100(0x0010) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct ControlRig.MathRBFInterpolateQuatQuat_Target
// 0x0040
struct FMathRBFInterpolateQuatQuat_Target
{
	struct FQuat                                       Target_69;                                                // 0x0000(0x0020) (Edit, BlueprintVisible, IsPlainOldData)
	struct FQuat                                       Value_69;                                                 // 0x0020(0x0020) (Edit, BlueprintVisible, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_MathRBFInterpolateQuatQuat
// 0x0030 (0x0120 - 0x00F0)
struct FRigUnit_MathRBFInterpolateQuatQuat : public FRigUnit_MathRBFInterpolateQuatBase
{
	TArray<struct FMathRBFInterpolateQuatQuat_Target>  Targets_69;                                               // 0x00F0(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FQuat                                       Output_69;                                                // 0x0100(0x0020) (BlueprintVisible, BlueprintReadOnly, IsPlainOldData)
};

// ScriptStruct ControlRig.MathRBFInterpolateQuatXform_Target
// 0x0080
struct FMathRBFInterpolateQuatXform_Target
{
	struct FQuat                                       Target_69;                                                // 0x0000(0x0020) (Edit, BlueprintVisible, IsPlainOldData)
	struct FCoreUObject_FTransform                     Value_69;                                                 // 0x0020(0x0060) (Edit, BlueprintVisible, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_MathRBFInterpolateQuatXform
// 0x0070 (0x0160 - 0x00F0)
struct FRigUnit_MathRBFInterpolateQuatXform : public FRigUnit_MathRBFInterpolateQuatBase
{
	TArray<struct FMathRBFInterpolateQuatXform_Target> Targets_69;                                               // 0x00F0(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FCoreUObject_FTransform                     Output_69;                                                // 0x0100(0x0060) (BlueprintVisible, BlueprintReadOnly, IsPlainOldData)
};

// ScriptStruct ControlRig.MathRBFInterpolateVectorFloat_Target
// 0x0020
struct FMathRBFInterpolateVectorFloat_Target
{
	struct FVector                                     Target_69;                                                // 0x0000(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              Value_69;                                                 // 0x0018(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x001C(0x0004) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_MathRBFInterpolateVectorFloat
// 0x0020 (0x00E0 - 0x00C0)
struct FRigUnit_MathRBFInterpolateVectorFloat : public FRigUnit_MathRBFInterpolateVectorBase
{
	TArray<struct FMathRBFInterpolateVectorFloat_Target> Targets_69;                                               // 0x00C0(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	float                                              Output_69;                                                // 0x00D0(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0xC];                                       // 0x00D4(0x000C) MISSED OFFSET
};

// ScriptStruct ControlRig.MathRBFInterpolateVectorVector_Target
// 0x0030
struct FMathRBFInterpolateVectorVector_Target
{
	struct FVector                                     Target_69;                                                // 0x0000(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FVector                                     Value_69;                                                 // 0x0018(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_MathRBFInterpolateVectorVector
// 0x0030 (0x00F0 - 0x00C0)
struct FRigUnit_MathRBFInterpolateVectorVector : public FRigUnit_MathRBFInterpolateVectorBase
{
	TArray<struct FMathRBFInterpolateVectorVector_Target> Targets_69;                                               // 0x00C0(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FVector                                     Output_69;                                                // 0x00D0(0x0018) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x8];                                       // 0x00E8(0x0008) MISSED OFFSET
};

// ScriptStruct ControlRig.MathRBFInterpolateVectorColor_Target
// 0x0028
struct FMathRBFInterpolateVectorColor_Target
{
	struct FVector                                     Target_69;                                                // 0x0000(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FLinearColor                                Value_69;                                                 // 0x0018(0x0010) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_MathRBFInterpolateVectorColor
// 0x0020 (0x00E0 - 0x00C0)
struct FRigUnit_MathRBFInterpolateVectorColor : public FRigUnit_MathRBFInterpolateVectorBase
{
	TArray<struct FMathRBFInterpolateVectorColor_Target> Targets_69;                                               // 0x00C0(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FLinearColor                                Output_69;                                                // 0x00D0(0x0010) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct ControlRig.MathRBFInterpolateVectorQuat_Target
// 0x0040
struct FMathRBFInterpolateVectorQuat_Target
{
	struct FVector                                     Target_69;                                                // 0x0000(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x8];                                       // 0x0018(0x0008) MISSED OFFSET
	struct FQuat                                       Value_69;                                                 // 0x0020(0x0020) (Edit, BlueprintVisible, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_MathRBFInterpolateVectorQuat
// 0x0030 (0x00F0 - 0x00C0)
struct FRigUnit_MathRBFInterpolateVectorQuat : public FRigUnit_MathRBFInterpolateVectorBase
{
	TArray<struct FMathRBFInterpolateVectorQuat_Target> Targets_69;                                               // 0x00C0(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FQuat                                       Output_69;                                                // 0x00D0(0x0020) (BlueprintVisible, BlueprintReadOnly, IsPlainOldData)
};

// ScriptStruct ControlRig.MathRBFInterpolateVectorXform_Target
// 0x0080
struct FMathRBFInterpolateVectorXform_Target
{
	struct FVector                                     Target_69;                                                // 0x0000(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x8];                                       // 0x0018(0x0008) MISSED OFFSET
	struct FCoreUObject_FTransform                     Value_69;                                                 // 0x0020(0x0060) (Edit, BlueprintVisible, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_MathRBFInterpolateVectorXform
// 0x0070 (0x0130 - 0x00C0)
struct FRigUnit_MathRBFInterpolateVectorXform : public FRigUnit_MathRBFInterpolateVectorBase
{
	TArray<struct FMathRBFInterpolateVectorXform_Target> Targets_69;                                               // 0x00C0(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FCoreUObject_FTransform                     Output_69;                                                // 0x00D0(0x0060) (BlueprintVisible, BlueprintReadOnly, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_MathTransformBase
// 0x0000 (0x0008 - 0x0008)
struct FRigUnit_MathTransformBase : public FRigUnit_MathBase
{

};

// ScriptStruct ControlRig.RigUnit_MathTransformMutableBase
// 0x0000 (0x0038 - 0x0038)
struct FRigUnit_MathTransformMutableBase : public FRigUnit_MathMutableBase
{

};

// ScriptStruct ControlRig.RigUnit_MathTransformUnaryOp
// 0x00C8 (0x00D0 - 0x0008)
struct FRigUnit_MathTransformUnaryOp : public FRigUnit_MathTransformBase
{
	unsigned char                                      UnknownData00[0x8];                                       // 0x0008(0x0008) MISSED OFFSET
	struct FCoreUObject_FTransform                     Value_69;                                                 // 0x0010(0x0060) (Edit, BlueprintVisible, IsPlainOldData)
	struct FCoreUObject_FTransform                     Result_69;                                                // 0x0070(0x0060) (BlueprintVisible, BlueprintReadOnly, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_MathTransformBinaryOp
// 0x0128 (0x0130 - 0x0008)
struct FRigUnit_MathTransformBinaryOp : public FRigUnit_MathTransformBase
{
	unsigned char                                      UnknownData00[0x8];                                       // 0x0008(0x0008) MISSED OFFSET
	struct FCoreUObject_FTransform                     A_69;                                                     // 0x0010(0x0060) (Edit, BlueprintVisible, IsPlainOldData)
	struct FCoreUObject_FTransform                     B_69;                                                     // 0x0070(0x0060) (Edit, BlueprintVisible, IsPlainOldData)
	struct FCoreUObject_FTransform                     Result_69;                                                // 0x00D0(0x0060) (BlueprintVisible, BlueprintReadOnly, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_MathTransformFromEulerTransform
// 0x00A8 (0x00B0 - 0x0008)
struct FRigUnit_MathTransformFromEulerTransform : public FRigUnit_MathTransformBase
{
	struct FEulerTransform                             EulerTransform_69;                                        // 0x0008(0x0048) (Edit, BlueprintVisible)
	struct FCoreUObject_FTransform                     Result_69;                                                // 0x0050(0x0060) (BlueprintVisible, BlueprintReadOnly, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_MathTransformFromEulerTransformV2
// 0x00A8 (0x00B0 - 0x0008)
struct FRigUnit_MathTransformFromEulerTransformV2 : public FRigUnit_MathTransformBase
{
	struct FEulerTransform                             Value_69;                                                 // 0x0008(0x0048) (Edit, BlueprintVisible)
	struct FCoreUObject_FTransform                     Result_69;                                                // 0x0050(0x0060) (BlueprintVisible, BlueprintReadOnly, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_MathTransformToEulerTransform
// 0x00B8 (0x00C0 - 0x0008)
struct FRigUnit_MathTransformToEulerTransform : public FRigUnit_MathTransformBase
{
	unsigned char                                      UnknownData00[0x8];                                       // 0x0008(0x0008) MISSED OFFSET
	struct FCoreUObject_FTransform                     Value_69;                                                 // 0x0010(0x0060) (Edit, BlueprintVisible, IsPlainOldData)
	struct FEulerTransform                             Result_69;                                                // 0x0070(0x0048) (BlueprintVisible, BlueprintReadOnly)
	unsigned char                                      UnknownData01[0x8];                                       // 0x00B8(0x0008) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_MathTransformMul
// 0x0000 (0x0130 - 0x0130)
struct FRigUnit_MathTransformMul : public FRigUnit_MathTransformBinaryOp
{

};

// ScriptStruct ControlRig.RigUnit_MathTransformMakeRelative
// 0x0128 (0x0130 - 0x0008)
struct FRigUnit_MathTransformMakeRelative : public FRigUnit_MathTransformBase
{
	unsigned char                                      UnknownData00[0x8];                                       // 0x0008(0x0008) MISSED OFFSET
	struct FCoreUObject_FTransform                     Global_69;                                                // 0x0010(0x0060) (Edit, BlueprintVisible, IsPlainOldData)
	struct FCoreUObject_FTransform                     Parent_69;                                                // 0x0070(0x0060) (Edit, BlueprintVisible, IsPlainOldData)
	struct FCoreUObject_FTransform                     Local_69;                                                 // 0x00D0(0x0060) (BlueprintVisible, BlueprintReadOnly, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_MathTransformMakeAbsolute
// 0x0128 (0x0130 - 0x0008)
struct FRigUnit_MathTransformMakeAbsolute : public FRigUnit_MathTransformBase
{
	unsigned char                                      UnknownData00[0x8];                                       // 0x0008(0x0008) MISSED OFFSET
	struct FCoreUObject_FTransform                     Local_69;                                                 // 0x0010(0x0060) (Edit, BlueprintVisible, IsPlainOldData)
	struct FCoreUObject_FTransform                     Parent_69;                                                // 0x0070(0x0060) (Edit, BlueprintVisible, IsPlainOldData)
	struct FCoreUObject_FTransform                     Global_69;                                                // 0x00D0(0x0060) (BlueprintVisible, BlueprintReadOnly, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_MathTransformAccumulateArray
// 0x0088 (0x00C0 - 0x0038)
struct FRigUnit_MathTransformAccumulateArray : public FRigUnit_MathTransformMutableBase
{
	TArray<struct FCoreUObject_FTransform>             Transforms_69;                                            // 0x0038(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	EBoneGetterSetterMode                              TargetSpace_69;                                           // 0x0048(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0049(0x0007) MISSED OFFSET
	struct FCoreUObject_FTransform                     Root_69;                                                  // 0x0050(0x0060) (Edit, BlueprintVisible, IsPlainOldData)
	TArray<int>                                        ParentIndices_69;                                         // 0x00B0(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
};

// ScriptStruct ControlRig.RigUnit_MathTransformInverse
// 0x0000 (0x00D0 - 0x00D0)
struct FRigUnit_MathTransformInverse : public FRigUnit_MathTransformUnaryOp
{

};

// ScriptStruct ControlRig.RigUnit_MathTransformLerp
// 0x0138 (0x0140 - 0x0008)
struct FRigUnit_MathTransformLerp : public FRigUnit_MathTransformBase
{
	unsigned char                                      UnknownData00[0x8];                                       // 0x0008(0x0008) MISSED OFFSET
	struct FCoreUObject_FTransform                     A_69;                                                     // 0x0010(0x0060) (Edit, BlueprintVisible, IsPlainOldData)
	struct FCoreUObject_FTransform                     B_69;                                                     // 0x0070(0x0060) (Edit, BlueprintVisible, IsPlainOldData)
	float                                              T_69;                                                     // 0x00D0(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0xC];                                       // 0x00D4(0x000C) MISSED OFFSET
	struct FCoreUObject_FTransform                     Result_69;                                                // 0x00E0(0x0060) (BlueprintVisible, BlueprintReadOnly, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_MathTransformSelectBool
// 0x0128 (0x0130 - 0x0008)
struct FRigUnit_MathTransformSelectBool : public FRigUnit_MathTransformBase
{
	bool                                               Condition_69;                                             // 0x0008(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0009(0x0007) MISSED OFFSET
	struct FCoreUObject_FTransform                     IfTrue_69;                                                // 0x0010(0x0060) (Edit, BlueprintVisible, IsPlainOldData)
	struct FCoreUObject_FTransform                     IfFalse_69;                                               // 0x0070(0x0060) (Edit, BlueprintVisible, IsPlainOldData)
	struct FCoreUObject_FTransform                     Result_69;                                                // 0x00D0(0x0060) (BlueprintVisible, BlueprintReadOnly, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_MathTransformRotateVector
// 0x0098 (0x00A0 - 0x0008)
struct FRigUnit_MathTransformRotateVector : public FRigUnit_MathTransformBase
{
	unsigned char                                      UnknownData00[0x8];                                       // 0x0008(0x0008) MISSED OFFSET
	struct FCoreUObject_FTransform                     Transform_69;                                             // 0x0010(0x0060) (Edit, BlueprintVisible, IsPlainOldData)
	struct FVector                                     Vector_69;                                                // 0x0070(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FVector                                     Result_69;                                                // 0x0088(0x0018) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_MathTransformTransformVector
// 0x0098 (0x00A0 - 0x0008)
struct FRigUnit_MathTransformTransformVector : public FRigUnit_MathTransformBase
{
	unsigned char                                      UnknownData00[0x8];                                       // 0x0008(0x0008) MISSED OFFSET
	struct FCoreUObject_FTransform                     Transform_69;                                             // 0x0010(0x0060) (Edit, BlueprintVisible, IsPlainOldData)
	struct FVector                                     Location_69;                                              // 0x0070(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FVector                                     Result_69;                                                // 0x0088(0x0018) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_MathTransformFromSRT
// 0x0108 (0x0110 - 0x0008)
struct FRigUnit_MathTransformFromSRT : public FRigUnit_MathTransformBase
{
	struct FVector                                     Location_69;                                              // 0x0008(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FVector                                     Rotation_69;                                              // 0x0020(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	EEulerRotationOrder                                RotationOrder_69;                                         // 0x0038(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0039(0x0007) MISSED OFFSET
	struct FVector                                     Scale_69;                                                 // 0x0040(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x8];                                       // 0x0058(0x0008) MISSED OFFSET
	struct FCoreUObject_FTransform                     Transform_69;                                             // 0x0060(0x0060) (BlueprintVisible, BlueprintReadOnly, IsPlainOldData)
	struct FEulerTransform                             EulerTransform_69;                                        // 0x00C0(0x0048) (BlueprintVisible, BlueprintReadOnly)
	unsigned char                                      UnknownData02[0x8];                                       // 0x0108(0x0008) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_MathTransformArrayToSRT
// 0x0040 (0x0048 - 0x0008)
struct FRigUnit_MathTransformArrayToSRT : public FRigUnit_MathTransformBase
{
	TArray<struct FCoreUObject_FTransform>             Transforms_69;                                            // 0x0008(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	TArray<struct FVector>                             Translations_69;                                          // 0x0018(0x0010) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
	TArray<struct FQuat>                               Rotations_69;                                             // 0x0028(0x0010) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
	TArray<struct FVector>                             Scales_69;                                                // 0x0038(0x0010) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
};

// ScriptStruct ControlRig.RigUnit_MathTransformClampSpatially
// 0x0158 (0x0160 - 0x0008)
struct FRigUnit_MathTransformClampSpatially : public FRigUnit_MathTransformBase
{
	unsigned char                                      UnknownData00[0x8];                                       // 0x0008(0x0008) MISSED OFFSET
	struct FCoreUObject_FTransform                     Value_69;                                                 // 0x0010(0x0060) (Edit, BlueprintVisible, IsPlainOldData)
	TEnumAsByte<EAxis>                                 Axis_69;                                                  // 0x0070(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<EControlRigClampSpatialMode>           Type_69;                                                  // 0x0071(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x2];                                       // 0x0072(0x0002) MISSED OFFSET
	float                                              Minimum_69;                                               // 0x0074(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              Maximum_69;                                               // 0x0078(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData02[0x4];                                       // 0x007C(0x0004) MISSED OFFSET
	struct FCoreUObject_FTransform                     Space_69;                                                 // 0x0080(0x0060) (Edit, BlueprintVisible, IsPlainOldData)
	bool                                               bDrawDebug_69;                                            // 0x00E0(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData03[0x3];                                       // 0x00E1(0x0003) MISSED OFFSET
	struct FLinearColor                                DebugColor_69;                                            // 0x00E4(0x0010) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              DebugThickness_69;                                        // 0x00F4(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData04[0x8];                                       // 0x00F8(0x0008) MISSED OFFSET
	struct FCoreUObject_FTransform                     Result_69;                                                // 0x0100(0x0060) (BlueprintVisible, BlueprintReadOnly, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_MathTransformMirrorTransform
// 0x0138 (0x0140 - 0x0008)
struct FRigUnit_MathTransformMirrorTransform : public FRigUnit_MathTransformBase
{
	unsigned char                                      UnknownData00[0x8];                                       // 0x0008(0x0008) MISSED OFFSET
	struct FCoreUObject_FTransform                     Value_69;                                                 // 0x0010(0x0060) (Edit, BlueprintVisible, IsPlainOldData)
	TEnumAsByte<EAxis>                                 MirrorAxis_69;                                            // 0x0070(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<EAxis>                                 AxisToFlip_69;                                            // 0x0071(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0xE];                                       // 0x0072(0x000E) MISSED OFFSET
	struct FCoreUObject_FTransform                     CentralTransform_69;                                      // 0x0080(0x0060) (Edit, BlueprintVisible, IsPlainOldData)
	struct FCoreUObject_FTransform                     Result_69;                                                // 0x00E0(0x0060) (BlueprintVisible, BlueprintReadOnly, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_MathVectorBase
// 0x0000 (0x0008 - 0x0008)
struct FRigUnit_MathVectorBase : public FRigUnit_MathBase
{

};

// ScriptStruct ControlRig.RigUnit_MathVectorUnaryOp
// 0x0030 (0x0038 - 0x0008)
struct FRigUnit_MathVectorUnaryOp : public FRigUnit_MathVectorBase
{
	struct FVector                                     Value_69;                                                 // 0x0008(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FVector                                     Result_69;                                                // 0x0020(0x0018) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_MathVectorBinaryOp
// 0x0048 (0x0050 - 0x0008)
struct FRigUnit_MathVectorBinaryOp : public FRigUnit_MathVectorBase
{
	struct FVector                                     A_69;                                                     // 0x0008(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FVector                                     B_69;                                                     // 0x0020(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FVector                                     Result_69;                                                // 0x0038(0x0018) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_MathVectorFromFloat
// 0x0020 (0x0028 - 0x0008)
struct FRigUnit_MathVectorFromFloat : public FRigUnit_MathVectorBase
{
	float                                              Value_69;                                                 // 0x0008(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x000C(0x0004) MISSED OFFSET
	struct FVector                                     Result_69;                                                // 0x0010(0x0018) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_MathVectorAdd
// 0x0000 (0x0050 - 0x0050)
struct FRigUnit_MathVectorAdd : public FRigUnit_MathVectorBinaryOp
{

};

// ScriptStruct ControlRig.RigUnit_MathVectorSub
// 0x0000 (0x0050 - 0x0050)
struct FRigUnit_MathVectorSub : public FRigUnit_MathVectorBinaryOp
{

};

// ScriptStruct ControlRig.RigUnit_MathVectorMul
// 0x0000 (0x0050 - 0x0050)
struct FRigUnit_MathVectorMul : public FRigUnit_MathVectorBinaryOp
{

};

// ScriptStruct ControlRig.RigUnit_MathVectorScale
// 0x0038 (0x0040 - 0x0008)
struct FRigUnit_MathVectorScale : public FRigUnit_MathVectorBase
{
	struct FVector                                     Value_69;                                                 // 0x0008(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              Factor_69;                                                // 0x0020(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0024(0x0004) MISSED OFFSET
	struct FVector                                     Result_69;                                                // 0x0028(0x0018) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_MathVectorDiv
// 0x0000 (0x0050 - 0x0050)
struct FRigUnit_MathVectorDiv : public FRigUnit_MathVectorBinaryOp
{

};

// ScriptStruct ControlRig.RigUnit_MathVectorMod
// 0x0000 (0x0050 - 0x0050)
struct FRigUnit_MathVectorMod : public FRigUnit_MathVectorBinaryOp
{

};

// ScriptStruct ControlRig.RigUnit_MathVectorMin
// 0x0000 (0x0050 - 0x0050)
struct FRigUnit_MathVectorMin : public FRigUnit_MathVectorBinaryOp
{

};

// ScriptStruct ControlRig.RigUnit_MathVectorMax
// 0x0000 (0x0050 - 0x0050)
struct FRigUnit_MathVectorMax : public FRigUnit_MathVectorBinaryOp
{

};

// ScriptStruct ControlRig.RigUnit_MathVectorNegate
// 0x0000 (0x0038 - 0x0038)
struct FRigUnit_MathVectorNegate : public FRigUnit_MathVectorUnaryOp
{

};

// ScriptStruct ControlRig.RigUnit_MathVectorAbs
// 0x0000 (0x0038 - 0x0038)
struct FRigUnit_MathVectorAbs : public FRigUnit_MathVectorUnaryOp
{

};

// ScriptStruct ControlRig.RigUnit_MathVectorFloor
// 0x0000 (0x0038 - 0x0038)
struct FRigUnit_MathVectorFloor : public FRigUnit_MathVectorUnaryOp
{

};

// ScriptStruct ControlRig.RigUnit_MathVectorCeil
// 0x0000 (0x0038 - 0x0038)
struct FRigUnit_MathVectorCeil : public FRigUnit_MathVectorUnaryOp
{

};

// ScriptStruct ControlRig.RigUnit_MathVectorRound
// 0x0000 (0x0038 - 0x0038)
struct FRigUnit_MathVectorRound : public FRigUnit_MathVectorUnaryOp
{

};

// ScriptStruct ControlRig.RigUnit_MathVectorSign
// 0x0000 (0x0038 - 0x0038)
struct FRigUnit_MathVectorSign : public FRigUnit_MathVectorUnaryOp
{

};

// ScriptStruct ControlRig.RigUnit_MathVectorClamp
// 0x0060 (0x0068 - 0x0008)
struct FRigUnit_MathVectorClamp : public FRigUnit_MathVectorBase
{
	struct FVector                                     Value_69;                                                 // 0x0008(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FVector                                     Minimum_69;                                               // 0x0020(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FVector                                     Maximum_69;                                               // 0x0038(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FVector                                     Result_69;                                                // 0x0050(0x0018) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_MathVectorLerp
// 0x0050 (0x0058 - 0x0008)
struct FRigUnit_MathVectorLerp : public FRigUnit_MathVectorBase
{
	struct FVector                                     A_69;                                                     // 0x0008(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FVector                                     B_69;                                                     // 0x0020(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              T_69;                                                     // 0x0038(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x003C(0x0004) MISSED OFFSET
	struct FVector                                     Result_69;                                                // 0x0040(0x0018) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_MathVectorRemap
// 0x0098 (0x00A0 - 0x0008)
struct FRigUnit_MathVectorRemap : public FRigUnit_MathVectorBase
{
	struct FVector                                     Value_69;                                                 // 0x0008(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FVector                                     SourceMinimum_69;                                         // 0x0020(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FVector                                     SourceMaximum_69;                                         // 0x0038(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FVector                                     TargetMinimum_69;                                         // 0x0050(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FVector                                     TargetMaximum_69;                                         // 0x0068(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bClamp_69;                                                // 0x0080(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0081(0x0007) MISSED OFFSET
	struct FVector                                     Result_69;                                                // 0x0088(0x0018) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_MathVectorEquals
// 0x0038 (0x0040 - 0x0008)
struct FRigUnit_MathVectorEquals : public FRigUnit_MathVectorBase
{
	struct FVector                                     A_69;                                                     // 0x0008(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FVector                                     B_69;                                                     // 0x0020(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               Result_69;                                                // 0x0038(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0039(0x0007) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_MathVectorNotEquals
// 0x0038 (0x0040 - 0x0008)
struct FRigUnit_MathVectorNotEquals : public FRigUnit_MathVectorBase
{
	struct FVector                                     A_69;                                                     // 0x0008(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FVector                                     B_69;                                                     // 0x0020(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               Result_69;                                                // 0x0038(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0039(0x0007) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_MathVectorIsNearlyZero
// 0x0020 (0x0028 - 0x0008)
struct FRigUnit_MathVectorIsNearlyZero : public FRigUnit_MathVectorBase
{
	struct FVector                                     Value_69;                                                 // 0x0008(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              Tolerance_69;                                             // 0x0020(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               Result_69;                                                // 0x0024(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0025(0x0003) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_MathVectorIsNearlyEqual
// 0x0038 (0x0040 - 0x0008)
struct FRigUnit_MathVectorIsNearlyEqual : public FRigUnit_MathVectorBase
{
	struct FVector                                     A_69;                                                     // 0x0008(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FVector                                     B_69;                                                     // 0x0020(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              Tolerance_69;                                             // 0x0038(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               Result_69;                                                // 0x003C(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x003D(0x0003) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_MathVectorSelectBool
// 0x0050 (0x0058 - 0x0008)
struct FRigUnit_MathVectorSelectBool : public FRigUnit_MathVectorBase
{
	bool                                               Condition_69;                                             // 0x0008(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0009(0x0007) MISSED OFFSET
	struct FVector                                     IfTrue_69;                                                // 0x0010(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FVector                                     IfFalse_69;                                               // 0x0028(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FVector                                     Result_69;                                                // 0x0040(0x0018) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_MathVectorDeg
// 0x0000 (0x0038 - 0x0038)
struct FRigUnit_MathVectorDeg : public FRigUnit_MathVectorUnaryOp
{

};

// ScriptStruct ControlRig.RigUnit_MathVectorRad
// 0x0000 (0x0038 - 0x0038)
struct FRigUnit_MathVectorRad : public FRigUnit_MathVectorUnaryOp
{

};

// ScriptStruct ControlRig.RigUnit_MathVectorLengthSquared
// 0x0020 (0x0028 - 0x0008)
struct FRigUnit_MathVectorLengthSquared : public FRigUnit_MathVectorBase
{
	struct FVector                                     Value_69;                                                 // 0x0008(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              Result_69;                                                // 0x0020(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0024(0x0004) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_MathVectorLength
// 0x0020 (0x0028 - 0x0008)
struct FRigUnit_MathVectorLength : public FRigUnit_MathVectorBase
{
	struct FVector                                     Value_69;                                                 // 0x0008(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              Result_69;                                                // 0x0020(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0024(0x0004) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_MathVectorDistance
// 0x0038 (0x0040 - 0x0008)
struct FRigUnit_MathVectorDistance : public FRigUnit_MathVectorBase
{
	struct FVector                                     A_69;                                                     // 0x0008(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FVector                                     B_69;                                                     // 0x0020(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              Result_69;                                                // 0x0038(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x003C(0x0004) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_MathVectorCross
// 0x0000 (0x0050 - 0x0050)
struct FRigUnit_MathVectorCross : public FRigUnit_MathVectorBinaryOp
{

};

// ScriptStruct ControlRig.RigUnit_MathVectorDot
// 0x0038 (0x0040 - 0x0008)
struct FRigUnit_MathVectorDot : public FRigUnit_MathVectorBase
{
	struct FVector                                     A_69;                                                     // 0x0008(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FVector                                     B_69;                                                     // 0x0020(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              Result_69;                                                // 0x0038(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x003C(0x0004) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_MathVectorUnit
// 0x0000 (0x0038 - 0x0038)
struct FRigUnit_MathVectorUnit : public FRigUnit_MathVectorUnaryOp
{

};

// ScriptStruct ControlRig.RigUnit_MathVectorSetLength
// 0x0038 (0x0040 - 0x0008)
struct FRigUnit_MathVectorSetLength : public FRigUnit_MathVectorBase
{
	struct FVector                                     Value_69;                                                 // 0x0008(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              Length_69;                                                // 0x0020(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0024(0x0004) MISSED OFFSET
	struct FVector                                     Result_69;                                                // 0x0028(0x0018) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_MathVectorClampLength
// 0x0038 (0x0040 - 0x0008)
struct FRigUnit_MathVectorClampLength : public FRigUnit_MathVectorBase
{
	struct FVector                                     Value_69;                                                 // 0x0008(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              MinimumLength_69;                                         // 0x0020(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              MaximumLength_69;                                         // 0x0024(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FVector                                     Result_69;                                                // 0x0028(0x0018) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_MathVectorMirror
// 0x0048 (0x0050 - 0x0008)
struct FRigUnit_MathVectorMirror : public FRigUnit_MathVectorBase
{
	struct FVector                                     Value_69;                                                 // 0x0008(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FVector                                     Normal_69;                                                // 0x0020(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FVector                                     Result_69;                                                // 0x0038(0x0018) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_MathVectorAngle
// 0x0038 (0x0040 - 0x0008)
struct FRigUnit_MathVectorAngle : public FRigUnit_MathVectorBase
{
	struct FVector                                     A_69;                                                     // 0x0008(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FVector                                     B_69;                                                     // 0x0020(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              Result_69;                                                // 0x0038(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x003C(0x0004) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_MathVectorParallel
// 0x0038 (0x0040 - 0x0008)
struct FRigUnit_MathVectorParallel : public FRigUnit_MathVectorBase
{
	struct FVector                                     A_69;                                                     // 0x0008(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FVector                                     B_69;                                                     // 0x0020(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               Result_69;                                                // 0x0038(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0039(0x0007) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_MathVectorOrthogonal
// 0x0038 (0x0040 - 0x0008)
struct FRigUnit_MathVectorOrthogonal : public FRigUnit_MathVectorBase
{
	struct FVector                                     A_69;                                                     // 0x0008(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FVector                                     B_69;                                                     // 0x0020(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               Result_69;                                                // 0x0038(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0039(0x0007) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_MathVectorBezierFourPoint
// 0x0098 (0x00A0 - 0x0008)
struct FRigUnit_MathVectorBezierFourPoint : public FRigUnit_MathVectorBase
{
	struct FCRFourPointBezier                          Bezier_69;                                                // 0x0008(0x0060) (Edit, BlueprintVisible)
	float                                              T_69;                                                     // 0x0068(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x006C(0x0004) MISSED OFFSET
	struct FVector                                     Result_69;                                                // 0x0070(0x0018) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	struct FVector                                     Tangent_69;                                               // 0x0088(0x0018) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_MathVectorMakeBezierFourPoint
// 0x0060 (0x0068 - 0x0008)
struct FRigUnit_MathVectorMakeBezierFourPoint : public FRigUnit_MathVectorBase
{
	struct FCRFourPointBezier                          Bezier_69;                                                // 0x0008(0x0060) (Edit, BlueprintVisible)
};

// ScriptStruct ControlRig.RigUnit_MathVectorClampSpatially
// 0x00B8 (0x00C0 - 0x0008)
struct FRigUnit_MathVectorClampSpatially : public FRigUnit_MathVectorBase
{
	struct FVector                                     Value_69;                                                 // 0x0008(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<EAxis>                                 Axis_69;                                                  // 0x0020(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<EControlRigClampSpatialMode>           Type_69;                                                  // 0x0021(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x2];                                       // 0x0022(0x0002) MISSED OFFSET
	float                                              Minimum_69;                                               // 0x0024(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              Maximum_69;                                               // 0x0028(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x4];                                       // 0x002C(0x0004) MISSED OFFSET
	struct FCoreUObject_FTransform                     Space_69;                                                 // 0x0030(0x0060) (Edit, BlueprintVisible, IsPlainOldData)
	bool                                               bDrawDebug_69;                                            // 0x0090(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData02[0x3];                                       // 0x0091(0x0003) MISSED OFFSET
	struct FLinearColor                                DebugColor_69;                                            // 0x0094(0x0010) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              DebugThickness_69;                                        // 0x00A4(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FVector                                     Result_69;                                                // 0x00A8(0x0018) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_MathIntersectPlane
// 0x0080 (0x0088 - 0x0008)
struct FRigUnit_MathIntersectPlane : public FRigUnit_MathVectorBase
{
	struct FVector                                     Start_69;                                                 // 0x0008(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FVector                                     Direction_69;                                             // 0x0020(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FVector                                     PlanePoint_69;                                            // 0x0038(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FVector                                     PlaneNormal_69;                                           // 0x0050(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FVector                                     Result_69;                                                // 0x0068(0x0018) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              Distance_69;                                              // 0x0080(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0084(0x0004) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_MathDistanceToPlane
// 0x0068 (0x0070 - 0x0008)
struct FRigUnit_MathDistanceToPlane : public FRigUnit_MathVectorBase
{
	struct FVector                                     Point_69;                                                 // 0x0008(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FVector                                     PlanePoint_69;                                            // 0x0020(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FVector                                     PlaneNormal_69;                                           // 0x0038(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FVector                                     ClosestPointOnPlane_69;                                   // 0x0050(0x0018) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              SignedDistance_69;                                        // 0x0068(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x006C(0x0004) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_MathVectorMakeRelative
// 0x0048 (0x0050 - 0x0008)
struct FRigUnit_MathVectorMakeRelative : public FRigUnit_MathVectorBase
{
	struct FVector                                     Global_69;                                                // 0x0008(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FVector                                     Parent_69;                                                // 0x0020(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FVector                                     Local_69;                                                 // 0x0038(0x0018) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_MathVectorMakeAbsolute
// 0x0048 (0x0050 - 0x0008)
struct FRigUnit_MathVectorMakeAbsolute : public FRigUnit_MathVectorBase
{
	struct FVector                                     Local_69;                                                 // 0x0008(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FVector                                     Parent_69;                                                // 0x0020(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FVector                                     Global_69;                                                // 0x0038(0x0018) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_MathVectorMirrorTransform
// 0x00A8 (0x00B0 - 0x0008)
struct FRigUnit_MathVectorMirrorTransform : public FRigUnit_MathVectorBase
{
	struct FVector                                     Value_69;                                                 // 0x0008(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<EAxis>                                 MirrorAxis_69;                                            // 0x0020(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<EAxis>                                 AxisToFlip_69;                                            // 0x0021(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0xE];                                       // 0x0022(0x000E) MISSED OFFSET
	struct FCoreUObject_FTransform                     CentralTransform_69;                                      // 0x0030(0x0060) (Edit, BlueprintVisible, IsPlainOldData)
	struct FVector                                     Result_69;                                                // 0x0090(0x0018) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x8];                                       // 0x00A8(0x0008) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_NoiseFloat
// 0x0020 (0x0028 - 0x0008)
struct FRigUnit_NoiseFloat : public FRigUnit_MathBase
{
	float                                              Value_69;                                                 // 0x0008(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              Speed_69;                                                 // 0x000C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              Frequency_69;                                             // 0x0010(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              Minimum_69;                                               // 0x0014(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              Maximum_69;                                               // 0x0018(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              Result_69;                                                // 0x001C(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              Time_69;                                                  // 0x0020(0x0004) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0024(0x0004) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_NoiseDouble
// 0x0038 (0x0040 - 0x0008)
struct FRigUnit_NoiseDouble : public FRigUnit_MathBase
{
	double                                             Value_69;                                                 // 0x0008(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	double                                             Speed_69;                                                 // 0x0010(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	double                                             Frequency_69;                                             // 0x0018(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	double                                             Minimum_69;                                               // 0x0020(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	double                                             Maximum_69;                                               // 0x0028(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	double                                             Result_69;                                                // 0x0030(0x0008) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	double                                             Time_69;                                                  // 0x0038(0x0008) (ZeroConstructor, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_NoiseVector
// 0x0080 (0x0088 - 0x0008)
struct FRigUnit_NoiseVector : public FRigUnit_MathBase
{
	struct FVector                                     Position_69;                                              // 0x0008(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FVector                                     Speed_69;                                                 // 0x0020(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FVector                                     Frequency_69;                                             // 0x0038(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              Minimum_69;                                               // 0x0050(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              Maximum_69;                                               // 0x0054(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FVector                                     Result_69;                                                // 0x0058(0x0018) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	struct FVector                                     Time_69;                                                  // 0x0070(0x0018) (ZeroConstructor, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_NoiseVector2
// 0x0088 (0x0090 - 0x0008)
struct FRigUnit_NoiseVector2 : public FRigUnit_MathBase
{
	struct FVector                                     Value_69;                                                 // 0x0008(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FVector                                     Speed_69;                                                 // 0x0020(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FVector                                     Frequency_69;                                             // 0x0038(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	double                                             Minimum_69;                                               // 0x0050(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	double                                             Maximum_69;                                               // 0x0058(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FVector                                     Result_69;                                                // 0x0060(0x0018) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	struct FVector                                     Time_69;                                                  // 0x0078(0x0018) (ZeroConstructor, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_RandomFloat
// 0x0028 (0x0030 - 0x0008)
struct FRigUnit_RandomFloat : public FRigUnit_MathBase
{
	int                                                Seed_69;                                                  // 0x0008(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              Minimum_69;                                               // 0x000C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              Maximum_69;                                               // 0x0010(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              Duration_69;                                              // 0x0014(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              Result_69;                                                // 0x0018(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              LastResult_69;                                            // 0x001C(0x0004) (ZeroConstructor, IsPlainOldData)
	int                                                LastSeed_69;                                              // 0x0020(0x0004) (ZeroConstructor, IsPlainOldData)
	int                                                BaseSeed_69;                                              // 0x0024(0x0004) (ZeroConstructor, IsPlainOldData)
	float                                              TimeLeft_69;                                              // 0x0028(0x0004) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x002C(0x0004) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_RandomVector
// 0x0050 (0x0058 - 0x0008)
struct FRigUnit_RandomVector : public FRigUnit_MathBase
{
	int                                                Seed_69;                                                  // 0x0008(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              Minimum_69;                                               // 0x000C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              Maximum_69;                                               // 0x0010(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              Duration_69;                                              // 0x0014(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FVector                                     Result_69;                                                // 0x0018(0x0018) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	struct FVector                                     LastResult_69;                                            // 0x0030(0x0018) (ZeroConstructor, IsPlainOldData)
	int                                                LastSeed_69;                                              // 0x0048(0x0004) (ZeroConstructor, IsPlainOldData)
	int                                                BaseSeed_69;                                              // 0x004C(0x0004) (ZeroConstructor, IsPlainOldData)
	float                                              TimeLeft_69;                                              // 0x0050(0x0004) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0054(0x0004) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_AccumulateBase
// 0x0000 (0x0008 - 0x0008)
struct FRigUnit_AccumulateBase : public FRigUnit_SimBase
{

};

// ScriptStruct ControlRig.RigUnit_AccumulateFloatAdd
// 0x0018 (0x0020 - 0x0008)
struct FRigUnit_AccumulateFloatAdd : public FRigUnit_AccumulateBase
{
	float                                              Increment_69;                                             // 0x0008(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              InitialValue_69;                                          // 0x000C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bIntegrateDeltaTime_69;                                   // 0x0010(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0011(0x0003) MISSED OFFSET
	float                                              Result_69;                                                // 0x0014(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              AccumulatedValue_69;                                      // 0x0018(0x0004) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x4];                                       // 0x001C(0x0004) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_AccumulateVectorAdd
// 0x0068 (0x0070 - 0x0008)
struct FRigUnit_AccumulateVectorAdd : public FRigUnit_AccumulateBase
{
	struct FVector                                     Increment_69;                                             // 0x0008(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FVector                                     InitialValue_69;                                          // 0x0020(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bIntegrateDeltaTime_69;                                   // 0x0038(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0039(0x0007) MISSED OFFSET
	struct FVector                                     Result_69;                                                // 0x0040(0x0018) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	struct FVector                                     AccumulatedValue_69;                                      // 0x0058(0x0018) (ZeroConstructor, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_AccumulateFloatMul
// 0x0018 (0x0020 - 0x0008)
struct FRigUnit_AccumulateFloatMul : public FRigUnit_AccumulateBase
{
	float                                              Multiplier_69;                                            // 0x0008(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              InitialValue_69;                                          // 0x000C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bIntegrateDeltaTime_69;                                   // 0x0010(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0011(0x0003) MISSED OFFSET
	float                                              Result_69;                                                // 0x0014(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              AccumulatedValue_69;                                      // 0x0018(0x0004) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x4];                                       // 0x001C(0x0004) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_AccumulateVectorMul
// 0x0068 (0x0070 - 0x0008)
struct FRigUnit_AccumulateVectorMul : public FRigUnit_AccumulateBase
{
	struct FVector                                     Multiplier_69;                                            // 0x0008(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FVector                                     InitialValue_69;                                          // 0x0020(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bIntegrateDeltaTime_69;                                   // 0x0038(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0039(0x0007) MISSED OFFSET
	struct FVector                                     Result_69;                                                // 0x0040(0x0018) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	struct FVector                                     AccumulatedValue_69;                                      // 0x0058(0x0018) (ZeroConstructor, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_AccumulateQuatMul
// 0x0098 (0x00A0 - 0x0008)
struct FRigUnit_AccumulateQuatMul : public FRigUnit_AccumulateBase
{
	unsigned char                                      UnknownData00[0x8];                                       // 0x0008(0x0008) MISSED OFFSET
	struct FQuat                                       Multiplier_69;                                            // 0x0010(0x0020) (Edit, BlueprintVisible, IsPlainOldData)
	struct FQuat                                       InitialValue_69;                                          // 0x0030(0x0020) (Edit, BlueprintVisible, IsPlainOldData)
	bool                                               bFlipOrder_69;                                            // 0x0050(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bIntegrateDeltaTime_69;                                   // 0x0051(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0xE];                                       // 0x0052(0x000E) MISSED OFFSET
	struct FQuat                                       Result_69;                                                // 0x0060(0x0020) (BlueprintVisible, BlueprintReadOnly, IsPlainOldData)
	struct FQuat                                       AccumulatedValue_69;                                      // 0x0080(0x0020) (IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_AccumulateTransformMul
// 0x0198 (0x01A0 - 0x0008)
struct FRigUnit_AccumulateTransformMul : public FRigUnit_AccumulateBase
{
	unsigned char                                      UnknownData00[0x8];                                       // 0x0008(0x0008) MISSED OFFSET
	struct FCoreUObject_FTransform                     Multiplier_69;                                            // 0x0010(0x0060) (Edit, BlueprintVisible, IsPlainOldData)
	struct FCoreUObject_FTransform                     InitialValue_69;                                          // 0x0070(0x0060) (Edit, BlueprintVisible, IsPlainOldData)
	bool                                               bFlipOrder_69;                                            // 0x00D0(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bIntegrateDeltaTime_69;                                   // 0x00D1(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0xE];                                       // 0x00D2(0x000E) MISSED OFFSET
	struct FCoreUObject_FTransform                     Result_69;                                                // 0x00E0(0x0060) (BlueprintVisible, BlueprintReadOnly, IsPlainOldData)
	struct FCoreUObject_FTransform                     AccumulatedValue_69;                                      // 0x0140(0x0060) (IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_AccumulateFloatLerp
// 0x0018 (0x0020 - 0x0008)
struct FRigUnit_AccumulateFloatLerp : public FRigUnit_AccumulateBase
{
	float                                              TargetValue_69;                                           // 0x0008(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              InitialValue_69;                                          // 0x000C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              Blend_69;                                                 // 0x0010(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bIntegrateDeltaTime_69;                                   // 0x0014(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0015(0x0003) MISSED OFFSET
	float                                              Result_69;                                                // 0x0018(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              AccumulatedValue_69;                                      // 0x001C(0x0004) (ZeroConstructor, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_AccumulateVectorLerp
// 0x0068 (0x0070 - 0x0008)
struct FRigUnit_AccumulateVectorLerp : public FRigUnit_AccumulateBase
{
	struct FVector                                     TargetValue_69;                                           // 0x0008(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FVector                                     InitialValue_69;                                          // 0x0020(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              Blend_69;                                                 // 0x0038(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bIntegrateDeltaTime_69;                                   // 0x003C(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x003D(0x0003) MISSED OFFSET
	struct FVector                                     Result_69;                                                // 0x0040(0x0018) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	struct FVector                                     AccumulatedValue_69;                                      // 0x0058(0x0018) (ZeroConstructor, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_AccumulateQuatLerp
// 0x0098 (0x00A0 - 0x0008)
struct FRigUnit_AccumulateQuatLerp : public FRigUnit_AccumulateBase
{
	unsigned char                                      UnknownData00[0x8];                                       // 0x0008(0x0008) MISSED OFFSET
	struct FQuat                                       TargetValue_69;                                           // 0x0010(0x0020) (Edit, BlueprintVisible, IsPlainOldData)
	struct FQuat                                       InitialValue_69;                                          // 0x0030(0x0020) (Edit, BlueprintVisible, IsPlainOldData)
	float                                              Blend_69;                                                 // 0x0050(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bIntegrateDeltaTime_69;                                   // 0x0054(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0xB];                                       // 0x0055(0x000B) MISSED OFFSET
	struct FQuat                                       Result_69;                                                // 0x0060(0x0020) (BlueprintVisible, BlueprintReadOnly, IsPlainOldData)
	struct FQuat                                       AccumulatedValue_69;                                      // 0x0080(0x0020) (IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_AccumulateTransformLerp
// 0x0198 (0x01A0 - 0x0008)
struct FRigUnit_AccumulateTransformLerp : public FRigUnit_AccumulateBase
{
	unsigned char                                      UnknownData00[0x8];                                       // 0x0008(0x0008) MISSED OFFSET
	struct FCoreUObject_FTransform                     TargetValue_69;                                           // 0x0010(0x0060) (Edit, BlueprintVisible, IsPlainOldData)
	struct FCoreUObject_FTransform                     InitialValue_69;                                          // 0x0070(0x0060) (Edit, BlueprintVisible, IsPlainOldData)
	float                                              Blend_69;                                                 // 0x00D0(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bIntegrateDeltaTime_69;                                   // 0x00D4(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0xB];                                       // 0x00D5(0x000B) MISSED OFFSET
	struct FCoreUObject_FTransform                     Result_69;                                                // 0x00E0(0x0060) (BlueprintVisible, BlueprintReadOnly, IsPlainOldData)
	struct FCoreUObject_FTransform                     AccumulatedValue_69;                                      // 0x0140(0x0060) (IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_AccumulateFloatRange
// 0x0018 (0x0020 - 0x0008)
struct FRigUnit_AccumulateFloatRange : public FRigUnit_AccumulateBase
{
	float                                              Value_69;                                                 // 0x0008(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              Minimum_69;                                               // 0x000C(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              Maximum_69;                                               // 0x0010(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              AccumulatedMinimum_69;                                    // 0x0014(0x0004) (ZeroConstructor, IsPlainOldData)
	float                                              AccumulatedMaximum_69;                                    // 0x0018(0x0004) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x001C(0x0004) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_AccumulateVectorRange
// 0x0078 (0x0080 - 0x0008)
struct FRigUnit_AccumulateVectorRange : public FRigUnit_AccumulateBase
{
	struct FVector                                     Value_69;                                                 // 0x0008(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FVector                                     Minimum_69;                                               // 0x0020(0x0018) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	struct FVector                                     Maximum_69;                                               // 0x0038(0x0018) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	struct FVector                                     AccumulatedMinimum_69;                                    // 0x0050(0x0018) (ZeroConstructor, IsPlainOldData)
	struct FVector                                     AccumulatedMaximum_69;                                    // 0x0068(0x0018) (ZeroConstructor, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_AlphaInterp
// 0x0070 (0x0078 - 0x0008)
struct FRigUnit_AlphaInterp : public FRigUnit_SimBase
{
	float                                              Value_69;                                                 // 0x0008(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              Scale_69;                                                 // 0x000C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              Bias_69;                                                  // 0x0010(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bMapRange_69;                                             // 0x0014(0x0001) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0015(0x0003) MISSED OFFSET
	struct FInputRange                                 InRange_69;                                               // 0x0018(0x0008) (Edit, BlueprintVisible)
	struct FInputRange                                 OutRange_69;                                              // 0x0020(0x0008) (Edit, BlueprintVisible)
	bool                                               bClampResult_69;                                          // 0x0028(0x0001) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	unsigned char                                      UnknownData01[0x3];                                       // 0x0029(0x0003) MISSED OFFSET
	float                                              ClampMin_69;                                              // 0x002C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              ClampMax_69;                                              // 0x0030(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bInterpResult_69;                                         // 0x0034(0x0001) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	unsigned char                                      UnknownData02[0x3];                                       // 0x0035(0x0003) MISSED OFFSET
	float                                              InterpSpeedIncreasing_69;                                 // 0x0038(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              InterpSpeedDecreasing_69;                                 // 0x003C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              Result_69;                                                // 0x0040(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	struct FInputScaleBiasClamp                        ScaleBiasClamp_69;                                        // 0x0044(0x0030)
	unsigned char                                      UnknownData03[0x4];                                       // 0x0074(0x0004) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_AlphaInterpVector
// 0x0098 (0x00A0 - 0x0008)
struct FRigUnit_AlphaInterpVector : public FRigUnit_SimBase
{
	struct FVector                                     Value_69;                                                 // 0x0008(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              Scale_69;                                                 // 0x0020(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              Bias_69;                                                  // 0x0024(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bMapRange_69;                                             // 0x0028(0x0001) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0029(0x0003) MISSED OFFSET
	struct FInputRange                                 InRange_69;                                               // 0x002C(0x0008) (Edit, BlueprintVisible)
	struct FInputRange                                 OutRange_69;                                              // 0x0034(0x0008) (Edit, BlueprintVisible)
	bool                                               bClampResult_69;                                          // 0x003C(0x0001) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	unsigned char                                      UnknownData01[0x3];                                       // 0x003D(0x0003) MISSED OFFSET
	float                                              ClampMin_69;                                              // 0x0040(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              ClampMax_69;                                              // 0x0044(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bInterpResult_69;                                         // 0x0048(0x0001) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	unsigned char                                      UnknownData02[0x3];                                       // 0x0049(0x0003) MISSED OFFSET
	float                                              InterpSpeedIncreasing_69;                                 // 0x004C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              InterpSpeedDecreasing_69;                                 // 0x0050(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData03[0x4];                                       // 0x0054(0x0004) MISSED OFFSET
	struct FVector                                     Result_69;                                                // 0x0058(0x0018) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	struct FInputScaleBiasClamp                        ScaleBiasClamp_69;                                        // 0x0070(0x0030)
};

// ScriptStruct ControlRig.RigUnit_AlphaInterpQuat
// 0x00B8 (0x00C0 - 0x0008)
struct FRigUnit_AlphaInterpQuat : public FRigUnit_SimBase
{
	unsigned char                                      UnknownData00[0x8];                                       // 0x0008(0x0008) MISSED OFFSET
	struct FQuat                                       Value_69;                                                 // 0x0010(0x0020) (Edit, BlueprintVisible, IsPlainOldData)
	float                                              Scale_69;                                                 // 0x0030(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              Bias_69;                                                  // 0x0034(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bMapRange_69;                                             // 0x0038(0x0001) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	unsigned char                                      UnknownData01[0x3];                                       // 0x0039(0x0003) MISSED OFFSET
	struct FInputRange                                 InRange_69;                                               // 0x003C(0x0008) (Edit, BlueprintVisible)
	struct FInputRange                                 OutRange_69;                                              // 0x0044(0x0008) (Edit, BlueprintVisible)
	bool                                               bClampResult_69;                                          // 0x004C(0x0001) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	unsigned char                                      UnknownData02[0x3];                                       // 0x004D(0x0003) MISSED OFFSET
	float                                              ClampMin_69;                                              // 0x0050(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              ClampMax_69;                                              // 0x0054(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bInterpResult_69;                                         // 0x0058(0x0001) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	unsigned char                                      UnknownData03[0x3];                                       // 0x0059(0x0003) MISSED OFFSET
	float                                              InterpSpeedIncreasing_69;                                 // 0x005C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              InterpSpeedDecreasing_69;                                 // 0x0060(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData04[0xC];                                       // 0x0064(0x000C) MISSED OFFSET
	struct FQuat                                       Result_69;                                                // 0x0070(0x0020) (BlueprintVisible, BlueprintReadOnly, IsPlainOldData)
	struct FInputScaleBiasClamp                        ScaleBiasClamp_69;                                        // 0x0090(0x0030)
};

// ScriptStruct ControlRig.RigUnit_DeltaFromPreviousFloat
// 0x0010 (0x0018 - 0x0008)
struct FRigUnit_DeltaFromPreviousFloat : public FRigUnit_SimBase
{
	float                                              Value_69;                                                 // 0x0008(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              Delta_69;                                                 // 0x000C(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              PreviousValue_69;                                         // 0x0010(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              Cache_69;                                                 // 0x0014(0x0004) (ZeroConstructor, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_DeltaFromPreviousVector
// 0x0060 (0x0068 - 0x0008)
struct FRigUnit_DeltaFromPreviousVector : public FRigUnit_SimBase
{
	struct FVector                                     Value_69;                                                 // 0x0008(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FVector                                     Delta_69;                                                 // 0x0020(0x0018) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	struct FVector                                     PreviousValue_69;                                         // 0x0038(0x0018) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	struct FVector                                     Cache_69;                                                 // 0x0050(0x0018) (ZeroConstructor, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_DeltaFromPreviousQuat
// 0x0088 (0x0090 - 0x0008)
struct FRigUnit_DeltaFromPreviousQuat : public FRigUnit_SimBase
{
	unsigned char                                      UnknownData00[0x8];                                       // 0x0008(0x0008) MISSED OFFSET
	struct FQuat                                       Value_69;                                                 // 0x0010(0x0020) (Edit, BlueprintVisible, IsPlainOldData)
	struct FQuat                                       Delta_69;                                                 // 0x0030(0x0020) (BlueprintVisible, BlueprintReadOnly, IsPlainOldData)
	struct FQuat                                       PreviousValue_69;                                         // 0x0050(0x0020) (BlueprintVisible, BlueprintReadOnly, IsPlainOldData)
	struct FQuat                                       Cache_69;                                                 // 0x0070(0x0020) (IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_DeltaFromPreviousTransform
// 0x0188 (0x0190 - 0x0008)
struct FRigUnit_DeltaFromPreviousTransform : public FRigUnit_SimBase
{
	unsigned char                                      UnknownData00[0x8];                                       // 0x0008(0x0008) MISSED OFFSET
	struct FCoreUObject_FTransform                     Value_69;                                                 // 0x0010(0x0060) (Edit, BlueprintVisible, IsPlainOldData)
	struct FCoreUObject_FTransform                     Delta_69;                                                 // 0x0070(0x0060) (BlueprintVisible, BlueprintReadOnly, IsPlainOldData)
	struct FCoreUObject_FTransform                     PreviousValue_69;                                         // 0x00D0(0x0060) (BlueprintVisible, BlueprintReadOnly, IsPlainOldData)
	struct FCoreUObject_FTransform                     Cache_69;                                                 // 0x0130(0x0060) (IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_KalmanFloat
// 0x0028 (0x0030 - 0x0008)
struct FRigUnit_KalmanFloat : public FRigUnit_SimBase
{
	float                                              Value_69;                                                 // 0x0008(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                BufferSize_69;                                            // 0x000C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	float                                              Result_69;                                                // 0x0010(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0014(0x0004) MISSED OFFSET
	TArray<float>                                      Buffer_69;                                                // 0x0018(0x0010) (ZeroConstructor)
	int                                                LastInsertIndex_69;                                       // 0x0028(0x0004) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x4];                                       // 0x002C(0x0004) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_KalmanVector
// 0x0050 (0x0058 - 0x0008)
struct FRigUnit_KalmanVector : public FRigUnit_SimBase
{
	struct FVector                                     Value_69;                                                 // 0x0008(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                BufferSize_69;                                            // 0x0020(0x0004) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0024(0x0004) MISSED OFFSET
	struct FVector                                     Result_69;                                                // 0x0028(0x0018) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	TArray<struct FVector>                             Buffer_69;                                                // 0x0040(0x0010) (ZeroConstructor)
	int                                                LastInsertIndex_69;                                       // 0x0050(0x0004) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x4];                                       // 0x0054(0x0004) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_KalmanTransform
// 0x00F8 (0x0100 - 0x0008)
struct FRigUnit_KalmanTransform : public FRigUnit_SimBase
{
	unsigned char                                      UnknownData00[0x8];                                       // 0x0008(0x0008) MISSED OFFSET
	struct FCoreUObject_FTransform                     Value_69;                                                 // 0x0010(0x0060) (Edit, BlueprintVisible, IsPlainOldData)
	int                                                BufferSize_69;                                            // 0x0070(0x0004) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	unsigned char                                      UnknownData01[0xC];                                       // 0x0074(0x000C) MISSED OFFSET
	struct FCoreUObject_FTransform                     Result_69;                                                // 0x0080(0x0060) (BlueprintVisible, BlueprintReadOnly, IsPlainOldData)
	TArray<struct FCoreUObject_FTransform>             Buffer_69;                                                // 0x00E0(0x0010) (ZeroConstructor)
	int                                                LastInsertIndex_69;                                       // 0x00F0(0x0004) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData02[0xC];                                       // 0x00F4(0x000C) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_PointSimulation_DebugSettings
// 0x0080
struct FRigUnit_PointSimulation_DebugSettings
{
	bool                                               bEnabled_69;                                              // 0x0000(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0001(0x0003) MISSED OFFSET
	float                                              Scale_69;                                                 // 0x0004(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              CollisionScale_69;                                        // 0x0008(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bDrawPointsAsSpheres_69;                                  // 0x000C(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x3];                                       // 0x000D(0x0003) MISSED OFFSET
	struct FLinearColor                                Color_69;                                                 // 0x0010(0x0010) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FCoreUObject_FTransform                     WorldOffset_69;                                           // 0x0020(0x0060) (Edit, BlueprintVisible, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_PointSimulation_BoneTarget
// 0x0010
struct FRigUnit_PointSimulation_BoneTarget
{
	struct FName                                       bone_69;                                                  // 0x0000(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                TranslationPoint_69;                                      // 0x0004(0x0004) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	int                                                PrimaryAimPoint_69;                                       // 0x0008(0x0004) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	int                                                SecondaryAimPoint_69;                                     // 0x000C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_PointSimulation_WorkData
// 0x0088
struct FRigUnit_PointSimulation_WorkData
{
	struct FCRSimPointContainer                        Simulation_69;                                            // 0x0000(0x0078)
	TArray<struct FCachedRigElement>                   BoneIndices_69;                                           // 0x0078(0x0010) (ZeroConstructor)
};

// ScriptStruct ControlRig.RigUnit_PointSimulation
// 0x0208 (0x0240 - 0x0038)
struct FRigUnit_PointSimulation : public FRigUnit_SimBaseMutable
{
	TArray<struct FCRSimPoint>                         Points_69;                                                // 0x0038(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	TArray<struct FCRSimLinearSpring>                  Links_69;                                                 // 0x0048(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	TArray<struct FCRSimPointForce>                    Forces_69;                                                // 0x0058(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	TArray<struct FCRSimSoftCollision>                 CollisionVolumes_69;                                      // 0x0068(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	float                                              SimulatedStepsPerSecond_69;                               // 0x0078(0x0004) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	ECRSimPointIntegrateType                           IntegratorType_69;                                        // 0x007C(0x0001) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x007D(0x0003) MISSED OFFSET
	float                                              VerletBlend_69;                                           // 0x0080(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x4];                                       // 0x0084(0x0004) MISSED OFFSET
	TArray<struct FRigUnit_PointSimulation_BoneTarget> BoneTargets_69;                                           // 0x0088(0x0010) (Edit, BlueprintVisible, ZeroConstructor, EditConst)
	bool                                               bLimitLocalPosition_69;                                   // 0x0098(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bPropagateToChildren_69;                                  // 0x0099(0x0001) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	unsigned char                                      UnknownData02[0x6];                                       // 0x009A(0x0006) MISSED OFFSET
	struct FVector                                     PrimaryAimAxis_69;                                        // 0x00A0(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FVector                                     SecondaryAimAxis_69;                                      // 0x00B8(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FRigUnit_PointSimulation_DebugSettings      DebugSettings_69;                                         // 0x00D0(0x0080) (Edit, BlueprintVisible)
	struct FCRFourPointBezier                          Bezier_69;                                                // 0x0150(0x0060) (BlueprintVisible, BlueprintReadOnly)
	struct FRigUnit_PointSimulation_WorkData           WorkData_69;                                              // 0x01B0(0x0088) (Transient)
	unsigned char                                      UnknownData03[0x8];                                       // 0x0238(0x0008) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_SpringInterp
// 0x0028 (0x0030 - 0x0008)
struct FRigUnit_SpringInterp : public FRigUnit_SimBase
{
	float                                              Current_69;                                               // 0x0008(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              Target_69;                                                // 0x000C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              Stiffness_69;                                             // 0x0010(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              CriticalDamping_69;                                       // 0x0014(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              Mass_69;                                                  // 0x0018(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              Result_69;                                                // 0x001C(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	struct FFloatSpringState                           SpringState_69;                                           // 0x0020(0x000C)
	unsigned char                                      UnknownData00[0x4];                                       // 0x002C(0x0004) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_SpringInterpVector
// 0x0090 (0x0098 - 0x0008)
struct FRigUnit_SpringInterpVector : public FRigUnit_SimBase
{
	struct FVector                                     Current_69;                                               // 0x0008(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FVector                                     Target_69;                                                // 0x0020(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              Stiffness_69;                                             // 0x0038(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              CriticalDamping_69;                                       // 0x003C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              Mass_69;                                                  // 0x0040(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0044(0x0004) MISSED OFFSET
	struct FVector                                     Result_69;                                                // 0x0048(0x0018) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	struct FVectorSpringState                          SpringState_69;                                           // 0x0060(0x0038)
};

// ScriptStruct ControlRig.RigUnit_SpringInterpV2
// 0x0038 (0x0040 - 0x0008)
struct FRigUnit_SpringInterpV2 : public FRigUnit_SimBase
{
	float                                              Target_69;                                                // 0x0008(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              Strength_69;                                              // 0x000C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              CriticalDamping_69;                                       // 0x0010(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              Force_69;                                                 // 0x0014(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bUseCurrentInput_69;                                      // 0x0018(0x0001) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0019(0x0003) MISSED OFFSET
	float                                              Current_69;                                               // 0x001C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              TargetVelocityAmount_69;                                  // 0x0020(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bInitializeFromTarget_69;                                 // 0x0024(0x0001) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	unsigned char                                      UnknownData01[0x3];                                       // 0x0025(0x0003) MISSED OFFSET
	float                                              Result_69;                                                // 0x0028(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              Velocity_69;                                              // 0x002C(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              SimulatedResult_69;                                       // 0x0030(0x0004) (ZeroConstructor, IsPlainOldData)
	struct FFloatSpringState                           SpringState_69;                                           // 0x0034(0x000C)
};

// ScriptStruct ControlRig.RigUnit_SpringInterpVectorV2
// 0x00E0 (0x00E8 - 0x0008)
struct FRigUnit_SpringInterpVectorV2 : public FRigUnit_SimBase
{
	struct FVector                                     Target_69;                                                // 0x0008(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              Strength_69;                                              // 0x0020(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              CriticalDamping_69;                                       // 0x0024(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FVector                                     Force_69;                                                 // 0x0028(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bUseCurrentInput_69;                                      // 0x0040(0x0001) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0041(0x0007) MISSED OFFSET
	struct FVector                                     Current_69;                                               // 0x0048(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              TargetVelocityAmount_69;                                  // 0x0060(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bInitializeFromTarget_69;                                 // 0x0064(0x0001) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	unsigned char                                      UnknownData01[0x3];                                       // 0x0065(0x0003) MISSED OFFSET
	struct FVector                                     Result_69;                                                // 0x0068(0x0018) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	struct FVector                                     Velocity_69;                                              // 0x0080(0x0018) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	struct FVector                                     SimulatedResult_69;                                       // 0x0098(0x0018) (ZeroConstructor, IsPlainOldData)
	struct FVectorSpringState                          SpringState_69;                                           // 0x00B0(0x0038)
};

// ScriptStruct ControlRig.RigUnit_SpringInterpQuaternionV2
// 0x0128 (0x0130 - 0x0008)
struct FRigUnit_SpringInterpQuaternionV2 : public FRigUnit_SimBase
{
	unsigned char                                      UnknownData00[0x8];                                       // 0x0008(0x0008) MISSED OFFSET
	struct FQuat                                       Target_69;                                                // 0x0010(0x0020) (Edit, BlueprintVisible, IsPlainOldData)
	float                                              Strength_69;                                              // 0x0030(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              CriticalDamping_69;                                       // 0x0034(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FVector                                     Torque_69;                                                // 0x0038(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bUseCurrentInput_69;                                      // 0x0050(0x0001) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	unsigned char                                      UnknownData01[0xF];                                       // 0x0051(0x000F) MISSED OFFSET
	struct FQuat                                       Current_69;                                               // 0x0060(0x0020) (Edit, BlueprintVisible, IsPlainOldData)
	float                                              TargetVelocityAmount_69;                                  // 0x0080(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bInitializeFromTarget_69;                                 // 0x0084(0x0001) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	unsigned char                                      UnknownData02[0xB];                                       // 0x0085(0x000B) MISSED OFFSET
	struct FQuat                                       Result_69;                                                // 0x0090(0x0020) (BlueprintVisible, BlueprintReadOnly, IsPlainOldData)
	struct FVector                                     AngularVelocity_69;                                       // 0x00B0(0x0018) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData03[0x8];                                       // 0x00C8(0x0008) MISSED OFFSET
	struct FQuat                                       SimulatedResult_69;                                       // 0x00D0(0x0020) (BlueprintVisible, BlueprintReadOnly, IsPlainOldData)
	struct FQuaternionSpringState                      SpringState_69;                                           // 0x00F0(0x0040)
};

// ScriptStruct ControlRig.RigUnit_Timeline
// 0x0010 (0x0018 - 0x0008)
struct FRigUnit_Timeline : public FRigUnit_SimBase
{
	float                                              Speed_69;                                                 // 0x0008(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              Time_69;                                                  // 0x000C(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              AccumulatedValue_69;                                      // 0x0010(0x0004) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0014(0x0004) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_TimeLoop
// 0x0028 (0x0030 - 0x0008)
struct FRigUnit_TimeLoop : public FRigUnit_SimBase
{
	float                                              Speed_69;                                                 // 0x0008(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              Duration_69;                                              // 0x000C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               Normalize_69;                                             // 0x0010(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0011(0x0003) MISSED OFFSET
	float                                              Absolute_69;                                              // 0x0014(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              Relative_69;                                              // 0x0018(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              FlipFlop_69;                                              // 0x001C(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	bool                                               Even_69;                                                  // 0x0020(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x3];                                       // 0x0021(0x0003) MISSED OFFSET
	float                                              AccumulatedAbsolute_69;                                   // 0x0024(0x0004) (ZeroConstructor, IsPlainOldData)
	float                                              AccumulatedRelative_69;                                   // 0x0028(0x0004) (ZeroConstructor, IsPlainOldData)
	int                                                NumIterations_69;                                         // 0x002C(0x0004) (ZeroConstructor, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_TimeOffsetFloat
// 0x0040 (0x0048 - 0x0008)
struct FRigUnit_TimeOffsetFloat : public FRigUnit_SimBase
{
	float                                              Value_69;                                                 // 0x0008(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              SecondsAgo_69;                                            // 0x000C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                BufferSize_69;                                            // 0x0010(0x0004) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	float                                              TimeRange_69;                                             // 0x0014(0x0004) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	float                                              Result_69;                                                // 0x0018(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x001C(0x0004) MISSED OFFSET
	TArray<float>                                      Buffer_69;                                                // 0x0020(0x0010) (ZeroConstructor)
	TArray<float>                                      DeltaTimes_69;                                            // 0x0030(0x0010) (ZeroConstructor)
	int                                                LastInsertIndex_69;                                       // 0x0040(0x0004) (ZeroConstructor, IsPlainOldData)
	int                                                UpperBound_69;                                            // 0x0044(0x0004) (ZeroConstructor, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_TimeOffsetVector
// 0x0068 (0x0070 - 0x0008)
struct FRigUnit_TimeOffsetVector : public FRigUnit_SimBase
{
	struct FVector                                     Value_69;                                                 // 0x0008(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              SecondsAgo_69;                                            // 0x0020(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                BufferSize_69;                                            // 0x0024(0x0004) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	float                                              TimeRange_69;                                             // 0x0028(0x0004) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x002C(0x0004) MISSED OFFSET
	struct FVector                                     Result_69;                                                // 0x0030(0x0018) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	TArray<struct FVector>                             Buffer_69;                                                // 0x0048(0x0010) (ZeroConstructor)
	TArray<float>                                      DeltaTimes_69;                                            // 0x0058(0x0010) (ZeroConstructor)
	int                                                LastInsertIndex_69;                                       // 0x0068(0x0004) (ZeroConstructor, IsPlainOldData)
	int                                                UpperBound_69;                                            // 0x006C(0x0004) (ZeroConstructor, IsPlainOldData)
};

// ScriptStruct ControlRig.RigUnit_TimeOffsetTransform
// 0x0108 (0x0110 - 0x0008)
struct FRigUnit_TimeOffsetTransform : public FRigUnit_SimBase
{
	unsigned char                                      UnknownData00[0x8];                                       // 0x0008(0x0008) MISSED OFFSET
	struct FCoreUObject_FTransform                     Value_69;                                                 // 0x0010(0x0060) (Edit, BlueprintVisible, IsPlainOldData)
	float                                              SecondsAgo_69;                                            // 0x0070(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                BufferSize_69;                                            // 0x0074(0x0004) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	float                                              TimeRange_69;                                             // 0x0078(0x0004) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	unsigned char                                      UnknownData01[0x4];                                       // 0x007C(0x0004) MISSED OFFSET
	struct FCoreUObject_FTransform                     Result_69;                                                // 0x0080(0x0060) (BlueprintVisible, BlueprintReadOnly, IsPlainOldData)
	TArray<struct FCoreUObject_FTransform>             Buffer_69;                                                // 0x00E0(0x0010) (ZeroConstructor)
	TArray<float>                                      DeltaTimes_69;                                            // 0x00F0(0x0010) (ZeroConstructor)
	int                                                LastInsertIndex_69;                                       // 0x0100(0x0004) (ZeroConstructor, IsPlainOldData)
	int                                                UpperBound_69;                                            // 0x0104(0x0004) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData02[0x8];                                       // 0x0108(0x0008) MISSED OFFSET
};

// ScriptStruct ControlRig.RigUnit_VerletIntegrateVector
// 0x00D0 (0x00D8 - 0x0008)
struct FRigUnit_VerletIntegrateVector : public FRigUnit_SimBase
{
	struct FVector                                     Target_69;                                                // 0x0008(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              Strength_69;                                              // 0x0020(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              Damp_69;                                                  // 0x0024(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              Blend_69;                                                 // 0x0028(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x002C(0x0004) MISSED OFFSET
	struct FVector                                     Force_69;                                                 // 0x0030(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FVector                                     Position_69;                                              // 0x0048(0x0018) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	struct FVector                                     Velocity_69;                                              // 0x0060(0x0018) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	struct FVector                                     Acceleration_69;                                          // 0x0078(0x0018) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	struct FCRSimPoint                                 Point_69;                                                 // 0x0090(0x0040) (Transient)
	bool                                               bInitialized_69;                                          // 0x00D0(0x0001) (ZeroConstructor, Transient, IsPlainOldData)
	unsigned char                                      UnknownData01[0x7];                                       // 0x00D1(0x0007) MISSED OFFSET
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

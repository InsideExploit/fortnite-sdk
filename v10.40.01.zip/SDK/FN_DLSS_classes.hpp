#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Classes
//---------------------------------------------------------------------------

// Class DLSS.DLSSOverrideSettings
// 0x0008 (0x0030 - 0x0028)
class DLSSOverrideSettings : public Object_32759
{
public:
	EDLSSSettingOverride                               EnableDLSSInEditorViewportsOverride_69;                   // 0x0028(0x0001) (Edit, ZeroConstructor, Config, IsPlainOldData)
	EDLSSSettingOverride                               EnableScreenpercentageManipulationInDLSSEditorViewportsOverride_69;// 0x0029(0x0001) (Edit, ZeroConstructor, Config, IsPlainOldData)
	EDLSSSettingOverride                               EnableDLSSInPlayInEditorViewportsOverride_69;             // 0x002A(0x0001) (Edit, ZeroConstructor, Config, IsPlainOldData)
	bool                                               bShowDLSSIncompatiblePluginsToolsWarnings_69;             // 0x002B(0x0001) (Edit, ZeroConstructor, Config, IsPlainOldData)
	EDLSSSettingOverride                               ShowDLSSSDebugOnScreenMessages_69;                        // 0x002C(0x0001) (Edit, ZeroConstructor, Config, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x002D(0x0003) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class DLSS.DLSSOverrideSettings"));
		
		return ptr;
	}

};


// Class DLSS.DLSSSettings
// 0x0038 (0x0060 - 0x0028)
class DLSSSettings : public Object_32759
{
public:
	bool                                               bEnableDLSSD3D12_69;                                      // 0x0028(0x0001) (Edit, ZeroConstructor, Config, IsPlainOldData)
	bool                                               bEnableDLSSD3D11_69;                                      // 0x0029(0x0001) (Edit, ZeroConstructor, Config, IsPlainOldData)
	bool                                               bEnableDLSSVulkan_69;                                     // 0x002A(0x0001) (Edit, ZeroConstructor, Config, IsPlainOldData)
	bool                                               bEnableDLSSInEditorViewports_69;                          // 0x002B(0x0001) (Edit, ZeroConstructor, Config, IsPlainOldData)
	bool                                               bEnableScreenpercentageManipulationInDLSSEditorViewports_69;// 0x002C(0x0001) (Edit, ZeroConstructor, Config, IsPlainOldData)
	bool                                               bEnableDLSSInPlayInEditorViewports_69;                    // 0x002D(0x0001) (Edit, ZeroConstructor, Config, IsPlainOldData)
	bool                                               bShowDLSSSDebugOnScreenMessages_69;                       // 0x002E(0x0001) (Edit, ZeroConstructor, Config, IsPlainOldData)
	unsigned char                                      UnknownData00[0x1];                                       // 0x002F(0x0001) MISSED OFFSET
	struct FString                                     GenericDLSSBinaryPath_69;                                 // 0x0030(0x0010) (Edit, ZeroConstructor, Config, EditConst)
	bool                                               bGenericDLSSBinaryExists_69;                              // 0x0040(0x0001) (Edit, ZeroConstructor, Config, EditConst, IsPlainOldData)
	unsigned char                                      UnknownData01[0x3];                                       // 0x0041(0x0003) MISSED OFFSET
	uint32_t                                           NVIDIANGXApplicationId_69;                                // 0x0044(0x0004) (Edit, ZeroConstructor, Config, IsPlainOldData)
	struct FString                                     CustomDLSSBinaryPath_69;                                  // 0x0048(0x0010) (Edit, ZeroConstructor, Config, EditConst)
	bool                                               bCustomDLSSBinaryExists_69;                               // 0x0058(0x0001) (Edit, ZeroConstructor, Config, EditConst, IsPlainOldData)
	unsigned char                                      UnknownData02[0x7];                                       // 0x0059(0x0007) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class DLSS.DLSSSettings"));
		
		return ptr;
	}

};


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

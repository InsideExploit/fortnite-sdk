#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function ACLPlugin.AnimationCompressionLibraryDatabase.SetVisualFidelity
struct AnimationCompressionLibraryDatabase_SetVisualFidelity_Params
{
	class Object_32759*                                WorldContextObject_69;                                    // (Parm, ZeroConstructor)
	struct FLatentActionInfo                           LatentInfo_69;                                            // (Parm)
	class AnimationCompressionLibraryDatabase*         DatabaseAsset_69;                                         // (Parm, ZeroConstructor)
	EACLVisualFidelityChangeResult                     Result_69;                                                // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	EACLVisualFidelity                                 VisualFidelity_69;                                        // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function ACLPlugin.AnimationCompressionLibraryDatabase.GetVisualFidelity
struct AnimationCompressionLibraryDatabase_GetVisualFidelity_Params
{
	class AnimationCompressionLibraryDatabase*         DatabaseAsset_69;                                         // (Parm, ZeroConstructor)
	EACLVisualFidelity                                 ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

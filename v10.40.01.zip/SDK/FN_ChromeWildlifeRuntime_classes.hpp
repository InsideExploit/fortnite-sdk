#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Classes
//---------------------------------------------------------------------------

// Class ChromeWildlifeRuntime.FortAthenaChromeWildlifeTelemetryData
// 0x0010 (0x0038 - 0x0028)
class FortAthenaChromeWildlifeTelemetryData : public FortAthenaAITelemetryData
{
public:
	bool                                               bIsChromed_69;                                            // 0x0028(0x0001) (ZeroConstructor, Transient, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0029(0x0003) MISSED OFFSET
	int                                                ChromedDowns_69;                                          // 0x002C(0x0004) (ZeroConstructor, Transient, IsPlainOldData)
	float                                              FirstChromedTime_69;                                      // 0x0030(0x0004) (ZeroConstructor, Transient, IsPlainOldData)
	unsigned char                                      UnknownData01[0x4];                                       // 0x0034(0x0004) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class ChromeWildlifeRuntime.FortAthenaChromeWildlifeTelemetryData"));
		
		return ptr;
	}


	void SetIsChromed(bool bInIsChromed_69);
};


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Functions
//---------------------------------------------------------------------------

// Function ACLPlugin.AnimationCompressionLibraryDatabase.SetVisualFidelity
// (Final, Native, Static, Public, HasOutParms, BlueprintCallable)
// Parameters:
// class Object_32759*            WorldContextObject_69          (Parm, ZeroConstructor)
// struct FLatentActionInfo       LatentInfo_69                  (Parm)
// class AnimationCompressionLibraryDatabase* DatabaseAsset_69               (Parm, ZeroConstructor)
// EACLVisualFidelityChangeResult Result_69                      (Parm, OutParm, ZeroConstructor, IsPlainOldData)
// EACLVisualFidelity             VisualFidelity_69              (Parm, ZeroConstructor, IsPlainOldData)

void AnimationCompressionLibraryDatabase::STATIC_SetVisualFidelity(class Object_32759* WorldContextObject_69, const struct FLatentActionInfo& LatentInfo_69, class AnimationCompressionLibraryDatabase* DatabaseAsset_69, EACLVisualFidelity VisualFidelity_69, EACLVisualFidelityChangeResult* Result_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ACLPlugin.AnimationCompressionLibraryDatabase.SetVisualFidelity"));

	AnimationCompressionLibraryDatabase_SetVisualFidelity_Params params;
	params.WorldContextObject_69 = WorldContextObject_69;
	params.LatentInfo_69 = LatentInfo_69;
	params.DatabaseAsset_69 = DatabaseAsset_69;
	params.VisualFidelity_69 = VisualFidelity_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (Result_69 != nullptr)
		*Result_69 = params.Result_69;
}


// Function ACLPlugin.AnimationCompressionLibraryDatabase.GetVisualFidelity
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// class AnimationCompressionLibraryDatabase* DatabaseAsset_69               (Parm, ZeroConstructor)
// EACLVisualFidelity             ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

EACLVisualFidelity AnimationCompressionLibraryDatabase::STATIC_GetVisualFidelity(class AnimationCompressionLibraryDatabase* DatabaseAsset_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ACLPlugin.AnimationCompressionLibraryDatabase.GetVisualFidelity"));

	AnimationCompressionLibraryDatabase_GetVisualFidelity_Params params;
	params.DatabaseAsset_69 = DatabaseAsset_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

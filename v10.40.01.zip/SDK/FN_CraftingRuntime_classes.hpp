#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Classes
//---------------------------------------------------------------------------

// Class CraftingRuntime.CraftingGlobals
// 0x0000 (0x0028 - 0x0028)
class CraftingGlobals : public Object_32759
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CraftingRuntime.CraftingGlobals"));
		
		return ptr;
	}

};


// Class CraftingRuntime.CraftingObjectBGA
// 0x0068 (0x0A30 - 0x09C8)
class CraftingObjectBGA : public BuildingGameplayActor
{
public:
	unsigned char                                      UnknownData00[0x8];                                       // 0x09C8(0x0008) MISSED OFFSET
	class FortInventory*                               Inventory_69;                                             // 0x09D0(0x0008) (Net, ZeroConstructor)
	unsigned char                                      UnknownData01[0x18];                                      // 0x09D8(0x0018) MISSED OFFSET
	class SphereComponent*                             SphereComponent_InteractionRange_69;                      // 0x09F0(0x0008) (Edit, ExportObject, ZeroConstructor, EditConst, InstancedReference)
	unsigned char                                      UnknownData02[0x28];                                      // 0x09F8(0x0028) UNKNOWN PROPERTY: SoftClassProperty CraftingRuntime.CraftingObjectBGA.MenuWidget_69
	class WidgetComponent*                             WidgetComponent_PotContents_69;                           // 0x0A20(0x0008) (Edit, BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, EditConst, InstancedReference)
	bool                                               bShowCraftingUI_69;                                       // 0x0A28(0x0001) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	bool                                               bSendEventMessageOnLocalInteract_69;                      // 0x0A29(0x0001) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData03[0x6];                                       // 0x0A2A(0x0006) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CraftingRuntime.CraftingObjectBGA"));
		
		return ptr;
	}


	void HandleInteractionRangeEndOverlap(class PrimitiveComponent* OverlappedComponent_69, class Actor_32759* OtherActor_69, class PrimitiveComponent* OtherComp_69, int OtherBodyIndex_69);
	void HandleInteractionRangeBeginOverlap(class PrimitiveComponent* OverlappedComponent_69, class Actor_32759* OtherActor_69, class PrimitiveComponent* OtherComp_69, int OtherBodyIndex_69, bool bFromSweep_69, const struct FHitResult& SweepResult_69);
};


// Class CraftingRuntime.CraftingCheatManager
// 0x0000 (0x0028 - 0x0028)
class CraftingCheatManager : public ChildCheatManager_32759
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CraftingRuntime.CraftingCheatManager"));
		
		return ptr;
	}


	void ToggleFreeCrafting();
	void StartSelfCrafting(const struct FName& FormulaName_69);
};


// Class CraftingRuntime.CraftingObjectComponent
// 0x0468 (0x0508 - 0x00A0)
class CraftingObjectComponent : public GameFrameworkComponent
{
public:
	unsigned char                                      UnknownData00[0x10];                                      // 0x00A0(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty CraftingRuntime.CraftingObjectComponent.CraftingObjectStateChanged_69
	unsigned char                                      UnknownData01[0x10];                                      // 0x00B0(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty CraftingRuntime.CraftingObjectComponent.OnFormulaCraftableChanged_69
	unsigned char                                      UnknownData02[0x10];                                      // 0x00C0(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty CraftingRuntime.CraftingObjectComponent.OnCraftingSuccess_69
	struct FCraftingObjectRepStateData                 CraftingObjectRepStateData_69;                            // 0x00D0(0x0008) (Net, Transient)
	struct FName                                       CraftingFormulaRow_69;                                    // 0x00D8(0x0008) (Net, ZeroConstructor, Transient, IsPlainOldData)
	int                                                NumToCraft_69;                                            // 0x00DC(0x0004) (Net, ZeroConstructor, Transient, IsPlainOldData)
	TWeakObjectPtr<class FortPlayerController>         CraftingInstigator_69;                                    // 0x00E0(0x0008) (ZeroConstructor, Transient, IsPlainOldData)
	TArray<struct FFortItemEntry>                      AllOfTheIngredientItems_69;                               // 0x00E8(0x0010) (ZeroConstructor, Transient)
	TArray<int>                                        NonConsumedIngredientItemIndices_69;                      // 0x00F8(0x0010) (ZeroConstructor, Transient)
	struct FString                                     LastIngredientStringForAnalytics_69;                      // 0x0108(0x0010) (ZeroConstructor, Transient)
	struct FString                                     LastFormulaStringForAnalytics_69;                         // 0x0118(0x0010) (ZeroConstructor, Transient)
	struct FString                                     LastResultsStringForAnalytics_69;                         // 0x0128(0x0010) (ZeroConstructor, Transient)
	TArray<struct FItemAndCount>                       CraftingResults_69;                                       // 0x0138(0x0010) (ZeroConstructor, Transient)
	struct FGameplayAbilitySpecHandle                  WhileCraftingAbilitySpecHandle_69;                        // 0x0148(0x0004) (Transient)
	struct FGameplayAbilitySpecHandle                  OwnerCraftingAbilitySpecHandle_69;                        // 0x014C(0x0004) (Transient)
	struct FGameplayTag                                CraftingObjectTag_69;                                     // 0x0150(0x0004) (Edit, DisableEditOnInstance)
	unsigned char                                      UnknownData03[0x4];                                       // 0x0154(0x0004) MISSED OFFSET
	struct FScalableFloat                              CraftingTimeLength_69;                                    // 0x0158(0x0028) (Edit, DisableEditOnInstance)
	struct FScalableFloat                              ReadyTimeLength_69;                                       // 0x0180(0x0028) (Edit, DisableEditOnInstance)
	struct FScalableFloat                              OverCraftingTimeLength_69;                                // 0x01A8(0x0028) (Edit, DisableEditOnInstance)
	struct FScalableFloat                              ResettingTimeLength_69;                                   // 0x01D0(0x0028) (Edit, DisableEditOnInstance)
	struct FName                                       OverCraftingLootTierKey_69;                               // 0x01F8(0x0008) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      bTakeItemsAtCraftingStart_69 : 1;                         // 0x01FC(0x0001) (Edit, DisableEditOnInstance)
	unsigned char                                      bGiveIngredientsToCraftingObject_69 : 1;                  // 0x01FC(0x0001) (Edit, DisableEditOnInstance)
	unsigned char                                      bGiveIngredientsToInstigator_69 : 1;                      // 0x01FC(0x0001) (Edit, DisableEditOnInstance)
	unsigned char                                      UnknownData04[0x3];                                       // 0x01FD(0x0003) MISSED OFFSET
	struct FVector                                     IngredientSpawnOffset_69;                                 // 0x0200(0x0018) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      bGiveToCraftingObject_69 : 1;                             // 0x0218(0x0001) (Edit, DisableEditOnInstance)
	unsigned char                                      bGiveResultToInstigator_69 : 1;                           // 0x0218(0x0001) (Edit, DisableEditOnInstance)
	unsigned char                                      UnknownData05[0x7];                                       // 0x0219(0x0007) MISSED OFFSET
	unsigned char                                      UnknownData06[0x28];                                      // 0x0219(0x0028) UNKNOWN PROPERTY: SoftClassProperty CraftingRuntime.CraftingObjectComponent.OwnerCraftingAbility_69
	struct FGameplayTagContainer                       CraftingFailedTags_69;                                    // 0x0248(0x0020) (Edit, DisableEditOnInstance)
	class FortPickup*                                  PendingPickupCraftingItem_69;                             // 0x0268(0x0008) (ZeroConstructor, Transient)
	struct FName                                       PendingPickupCraftingFormula_69;                          // 0x0270(0x0008) (ZeroConstructor, Transient, IsPlainOldData)
	unsigned char                                      UnknownData07[0x4];                                       // 0x0274(0x0004) MISSED OFFSET
	struct FFortItemEntry                              PendingPickupCraftingItemEntry_69;                        // 0x0278(0x01A0) (Transient)
	int                                                PendingPickupHeldCount_69;                                // 0x0418(0x0004) (ZeroConstructor, Transient, IsPlainOldData)
	unsigned char                                      UnknownData08[0xE4];                                      // 0x041C(0x00E4) MISSED OFFSET
	bool                                               FreeCraftingEnabled_69;                                   // 0x0500(0x0001) (Net, ZeroConstructor, Transient, IsPlainOldData)
	unsigned char                                      UnknownData09[0x7];                                       // 0x0501(0x0007) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CraftingRuntime.CraftingObjectComponent"));
		
		return ptr;
	}


	void OnRep_CraftingObjectRepStateData();
	void HandlePickupCraftingItemPickedUp(class FortPickup* PickUp_69, class FortPawn* InteractingPawn_69, class FortWorldItemDefinition* WorldItemDefinition_69, const struct FVector& PickupLocation_69);
	void CraftingObjectStateChanged__DelegateSignature(ECraftingObjectState CraftingState_69, float CraftingStateStartTime_69, float CraftingStateDuration_69);
	void CraftingObjectOnFormulaCraftableChanged__DelegateSignature(const struct FName& FormulaRowName_69, bool bIsCraftable_69);
};


// Class CraftingRuntime.FortControllerComponent_CraftingNetworkEvents
// 0x0010 (0x00B0 - 0x00A0)
class FortControllerComponent_CraftingNetworkEvents : public FortControllerComponent
{
public:
	unsigned char                                      UnknownData00[0x10];                                      // 0x00A0(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty CraftingRuntime.FortControllerComponent_CraftingNetworkEvents.OnCraftingSuccess_69

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CraftingRuntime.FortControllerComponent_CraftingNetworkEvents"));
		
		return ptr;
	}


	void ServerStartCrafting(class Actor_32759* CraftingObject_69, const struct FName& CraftingFormulaName_69, int NumberToCraft_69);
	void ServerReportCraftingSuccess(class Actor_32759* CraftingObject_69);
	void ServerPickupItemAndStartCrafting(class Actor_32759* CraftingObject_69, class FortPickup* PickUp_69, const struct FName& CraftingFormulaName_69);
	void ServerEjectItems(class Actor_32759* CraftingObject_69);
	void ServerClaimCraftingResults(class Actor_32759* CraftingObject_69);
	void ServerCancelCrafting(class Actor_32759* CraftingObject_69);
	void NotifyCraftingSuccess(class Actor_32759* CraftingObject_69, const struct FName& FormulaRowName_69);
	void ClientNotifyCraftingSuccess(class Actor_32759* CraftingObject_69, const struct FName& FormulaRowName_69);
	void ClientNotifyCraftingFailed(class Actor_32759* CraftingObject_69, const struct FGameplayTagContainer& FailedReason_69);
};


// Class CraftingRuntime.FortGameStateComponent_Crafting
// 0x01A8 (0x0248 - 0x00A0)
class FortGameStateComponent_Crafting : public FortGameStateComponent
{
public:
	struct FDataRegistryType                           CraftingFormulaRegistryType_69;                           // 0x00A0(0x0004) (ZeroConstructor, Config)
	struct FDataRegistryType                           CraftingIngredientsUIDataRegistryType_69;                 // 0x00A4(0x0004) (ZeroConstructor, Config)
	unsigned char                                      UnknownData00[0x140];                                     // 0x00A8(0x0140) MISSED OFFSET
	TArray<struct FCraftingResult>                     CraftingResultsList_69;                                   // 0x01E8(0x0010) (Net, ZeroConstructor)
	unsigned char                                      UnknownData01[0x50];                                      // 0x01F8(0x0050) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CraftingRuntime.FortGameStateComponent_Crafting"));
		
		return ptr;
	}


	void OnRep_CraftingResultsList();
	void OnPlaylistDataReady(class FortGameStateAthena* GameState_69, class FortPlaylist* Playlist_69, const struct FGameplayTagContainer& PlaylistContextTags_69);
};


// Class CraftingRuntime.FortPickupInteractOverrideComponent_Crafting
// 0x0020 (0x00E0 - 0x00C0)
class FortPickupInteractOverrideComponent_Crafting : public FortPickupInteractOverrideComponent
{
public:
	class FortItemDefinition*                          LastPickupItemDef_69;                                     // 0x00C0(0x0008) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, Transient)
	class FortItemDefinition*                          LastFocusedItemDef_69;                                    // 0x00C8(0x0008) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, Transient)
	struct FName                                       LastTargetFormulaName_69;                                 // 0x00D0(0x0008) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, Transient, IsPlainOldData)
	float                                              ContextualCraftingInteractDuration_69;                    // 0x00D4(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	TEnumAsByte<ETInteractionType>                     CachedInteractionType_69;                                 // 0x00D8(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<EInteractionBeingAttempted>            CachedInteractionBeingAttempted_69;                       // 0x00D9(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x6];                                       // 0x00DA(0x0006) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CraftingRuntime.FortPickupInteractOverrideComponent_Crafting"));
		
		return ptr;
	}

};


// Class CraftingRuntime.FortContextualTutorial_CraftingComplete
// 0x0000 (0x00F8 - 0x00F8)
class FortContextualTutorial_CraftingComplete : public FortContextualTutorial
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CraftingRuntime.FortContextualTutorial_CraftingComplete"));
		
		return ptr;
	}


	void OnCraftingSuccess(class FortPlayerController* Instigator_69, class Actor_32759* CraftingObject_69, const struct FName& FormulaRowName_69);
};


// Class CraftingRuntime.FortContextualTutorial_CraftingReady
// 0x0000 (0x00F8 - 0x00F8)
class FortContextualTutorial_CraftingReady : public FortContextualTutorial
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CraftingRuntime.FortContextualTutorial_CraftingReady"));
		
		return ptr;
	}


	void HandleFormulaCraftableChanged(const struct FName& FormulaRowName_69, bool bIsCraftable_69);
};


// Class CraftingRuntime.FortContextualTutorial_CraftingTabOpen
// 0x0008 (0x0100 - 0x00F8)
class FortContextualTutorial_CraftingTabOpen : public FortContextualTutorial
{
public:
	unsigned char                                      UnknownData00[0x8];                                       // 0x00F8(0x0008) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CraftingRuntime.FortContextualTutorial_CraftingTabOpen"));
		
		return ptr;
	}


	void HandleInventoryTabChanged(const struct FName& InventoryTabNameId_69);
	void HandleFormulaCraftableChanged(const struct FName& FormulaRowName_69, bool bIsCraftable_69);
};


// Class CraftingRuntime.CraftingLibrary
// 0x0000 (0x0028 - 0x0028)
class CraftingLibrary : public BlueprintFunctionLibrary
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CraftingRuntime.CraftingLibrary"));
		
		return ptr;
	}


	void STATIC_StartCrafting(class FortPlayerController* Instigator_69, class Actor_32759* CraftingObject_69, const struct FName& CraftingFormulaName_69, int NumberToCraft_69);
	void STATIC_ReportCraftingSuccess(class FortPlayerController* Instigator_69, class Actor_32759* CraftingObject_69);
	void STATIC_PickupItemAndStartCrafting(class FortPlayerController* Instigator_69, class Actor_32759* CraftingObject_69, class FortPickup* PickUp_69, const struct FName& CraftingFormulaName_69);
	bool STATIC_IsValidIngredient(class FortPlayerController* FortPC_69, class Actor_32759* CraftingObject_69, class FortItemDefinition* ItemDef_69);
	void STATIC_GiveItemToCraftingObject(class FortPlayerController* Instigator_69, class Actor_32759* CraftingObject_69, const struct FFortItemEntry& ItemEntryToGrant_69);
	void STATIC_GetValidIngredientsInInventory(class FortPlayerController* FortPC_69, class Actor_32759* CraftingObject_69, TArray<class FortWorldItem*>* OutIngredients_69);
	void STATIC_GetUIDataForCraftingIngredientTags(class Object_32759* WorldContextObject_69, const struct FGameplayTagContainer& IngredientTags_69);
	void STATIC_GetKnownCraftingFormulas(class FortPlayerController* FortPC_69, class Actor_32759* CraftingObject_69, TArray<struct FName>* OutFormulas_69);
	TArray<class FortWorldItem*> STATIC_GetIngredientsInCraftingObject(class Actor_32759* CraftingObject_69);
	void STATIC_GetCraftingResultsForRowName(class Object_32759* WorldContextObject_69, const struct FName& CraftingFormulaRow_69, int NumToCraft_69, TArray<struct FItemAndCount>* OutResults_69);
	float STATIC_GetCraftingObjectCurrentCraftingStateTimeLeft(class Actor_32759* CraftingObject_69);
	float STATIC_GetCraftingObjectCurrentCraftingStateStartTime(class Actor_32759* CraftingObject_69);
	float STATIC_GetCraftingObjectCurrentCraftingStateEndTime(class Actor_32759* CraftingObject_69);
	ECraftingObjectState STATIC_GetCraftingObjectCraftingState(class Actor_32759* CraftingObject_69);
	TArray<class FortWorldItem*> STATIC_GetCraftingIngredients_TempItems(class Actor_32759* CraftingObject_69);
	struct FName STATIC_GetCraftingFormulaNameBeingCrafted(class Actor_32759* CraftingObject_69);
	bool STATIC_GetCraftingFormulaIngredientRequirements(class Object_32759* WorldContextObject_69, const struct FName& CraftingFormulaRow_69, TArray<struct FCraftingIngredientRequirement>* OutIngredientRequirements_69);
	TArray<class FortWorldItem*> STATIC_GetCraftedResults_TempItems(class Actor_32759* CraftingObject_69);
	void STATIC_GetAllValidIngredients(class FortPlayerController* FortPC_69, class Actor_32759* CraftingObject_69, TArray<struct FGameplayTagContainer>* OutIngredients_69);
	void STATIC_GetAllCraftingFormulas(class FortPlayerController* FortPC_69, class Actor_32759* CraftingObject_69, TArray<struct FName>* OutFormulas_69);
	void STATIC_GetAllCraftableFormulas(class FortPlayerController* FortPC_69, class Actor_32759* CraftingObject_69, TArray<struct FName>* OutFormulas_69);
	void STATIC_EjectItems(class FortPlayerController* Instigator_69, class Actor_32759* CraftingObject_69);
	void STATIC_ClaimCraftingResults(class FortPlayerController* Instigator_69, class Actor_32759* CraftingObject_69);
	bool STATIC_CanCraftFormulaWithAdditionalItems(class FortPlayerController* FortPC_69, class Actor_32759* CraftingObject_69, const struct FName& CraftingFormulaRow_69, TArray<struct FItemAndCount> AdditionalItems_69, int NumberToCraft_69, TArray<struct FCraftingIngredientQueryState>* OutIngredientStates_69);
	bool STATIC_CanCraftFormula(class FortPlayerController* FortPC_69, class Actor_32759* CraftingObject_69, const struct FName& CraftingFormulaRow_69, int NumberToCraft_69, TArray<struct FCraftingIngredientQueryState>* OutIngredientStates_69);
	void STATIC_CancelCrafting(class FortPlayerController* Instigator_69, class Actor_32759* CraftingObject_69);
};


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

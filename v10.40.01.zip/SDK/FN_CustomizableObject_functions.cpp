// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Functions
//---------------------------------------------------------------------------

// Function CustomizableObject.CustomizableObject.UnloadMaskOutCache
// (Final, Native, Public, BlueprintCallable)

void CustomizableObject::UnloadMaskOutCache()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CustomizableObject.CustomizableObject.UnloadMaskOutCache"));

	CustomizableObject_UnloadMaskOutCache_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CustomizableObject.CustomizableObject.LoadMaskOutCache
// (Final, Native, Public, BlueprintCallable)

void CustomizableObject::LoadMaskOutCache()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CustomizableObject.CustomizableObject.LoadMaskOutCache"));

	CustomizableObject_LoadMaskOutCache_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CustomizableObject.CustomizableObject.IsCompiled
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool CustomizableObject::IsCompiled()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CustomizableObject.CustomizableObject.IsCompiled"));

	CustomizableObject_IsCompiled_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CustomizableObject.CustomizableObject.GetStateUIMetadataFromIndex
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// int                            StateIndex_69                  (Parm, ZeroConstructor, IsPlainOldData)
// struct FParameterUIData        ReturnValue_69                 (Parm, OutParm, ReturnParm)

struct FParameterUIData CustomizableObject::GetStateUIMetadataFromIndex(int StateIndex_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CustomizableObject.CustomizableObject.GetStateUIMetadataFromIndex"));

	CustomizableObject_GetStateUIMetadataFromIndex_Params params;
	params.StateIndex_69 = StateIndex_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CustomizableObject.CustomizableObject.GetStateUIMetadata
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FString                 StateName_69                   (Parm, ZeroConstructor)
// struct FParameterUIData        ReturnValue_69                 (Parm, OutParm, ReturnParm)

struct FParameterUIData CustomizableObject::GetStateUIMetadata(const struct FString& StateName_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CustomizableObject.CustomizableObject.GetStateUIMetadata"));

	CustomizableObject_GetStateUIMetadata_Params params;
	params.StateName_69 = StateName_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CustomizableObject.CustomizableObject.GetStateParameterName
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FString                 StateName_69                   (Parm, ZeroConstructor)
// int                            ParameterIndex_69              (Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString CustomizableObject::GetStateParameterName(const struct FString& StateName_69, int ParameterIndex_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CustomizableObject.CustomizableObject.GetStateParameterName"));

	CustomizableObject_GetStateParameterName_Params params;
	params.StateName_69 = StateName_69;
	params.ParameterIndex_69 = ParameterIndex_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CustomizableObject.CustomizableObject.GetStateParameterCount
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FString                 StateName_69                   (Parm, ZeroConstructor)
// int                            ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int CustomizableObject::GetStateParameterCount(const struct FString& StateName_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CustomizableObject.CustomizableObject.GetStateParameterCount"));

	CustomizableObject_GetStateParameterCount_Params params;
	params.StateName_69 = StateName_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CustomizableObject.CustomizableObject.GetStateName
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// int                            StateIndex_69                  (Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString CustomizableObject::GetStateName(int StateIndex_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CustomizableObject.CustomizableObject.GetStateName"));

	CustomizableObject_GetStateName_Params params;
	params.StateIndex_69 = StateIndex_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CustomizableObject.CustomizableObject.GetStateCount
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// int                            ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int CustomizableObject::GetStateCount()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CustomizableObject.CustomizableObject.GetStateCount"));

	CustomizableObject_GetStateCount_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CustomizableObject.CustomizableObject.GetParameterUIMetadataFromIndex
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// int                            ParamIndex_69                  (Parm, ZeroConstructor, IsPlainOldData)
// struct FParameterUIData        ReturnValue_69                 (Parm, OutParm, ReturnParm)

struct FParameterUIData CustomizableObject::GetParameterUIMetadataFromIndex(int ParamIndex_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CustomizableObject.CustomizableObject.GetParameterUIMetadataFromIndex"));

	CustomizableObject_GetParameterUIMetadataFromIndex_Params params;
	params.ParamIndex_69 = ParamIndex_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CustomizableObject.CustomizableObject.GetParameterUIMetadata
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FString                 ParamName_69                   (Parm, ZeroConstructor)
// struct FParameterUIData        ReturnValue_69                 (Parm, OutParm, ReturnParm)

struct FParameterUIData CustomizableObject::GetParameterUIMetadata(const struct FString& ParamName_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CustomizableObject.CustomizableObject.GetParameterUIMetadata"));

	CustomizableObject_GetParameterUIMetadata_Params params;
	params.ParamName_69 = ParamName_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CustomizableObject.CustomizableObject.GetParameterTypeByName
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FString                 Name_69                        (Parm, ZeroConstructor)
// EMutableParameterType          ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

EMutableParameterType CustomizableObject::GetParameterTypeByName(const struct FString& Name_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CustomizableObject.CustomizableObject.GetParameterTypeByName"));

	CustomizableObject_GetParameterTypeByName_Params params;
	params.Name_69 = Name_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CustomizableObject.CustomizableObject.GetParameterType
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// int                            ParamIndex_69                  (Parm, ZeroConstructor, IsPlainOldData)
// EMutableParameterType          ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

EMutableParameterType CustomizableObject::GetParameterType(int ParamIndex_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CustomizableObject.CustomizableObject.GetParameterType"));

	CustomizableObject_GetParameterType_Params params;
	params.ParamIndex_69 = ParamIndex_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CustomizableObject.CustomizableObject.GetParameterName
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// int                            ParamIndex_69                  (Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString CustomizableObject::GetParameterName(int ParamIndex_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CustomizableObject.CustomizableObject.GetParameterName"));

	CustomizableObject_GetParameterName_Params params;
	params.ParamIndex_69 = ParamIndex_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CustomizableObject.CustomizableObject.GetParameterDescriptionCount
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FString                 ParamName_69                   (Parm, ZeroConstructor)
// int                            ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int CustomizableObject::GetParameterDescriptionCount(const struct FString& ParamName_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CustomizableObject.CustomizableObject.GetParameterDescriptionCount"));

	CustomizableObject_GetParameterDescriptionCount_Params params;
	params.ParamName_69 = ParamName_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CustomizableObject.CustomizableObject.GetParameterCount
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// int                            ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int CustomizableObject::GetParameterCount()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CustomizableObject.CustomizableObject.GetParameterCount"));

	CustomizableObject_GetParameterCount_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CustomizableObject.CustomizableObject.GetIntParameterNumOptions
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// int                            ParamIndex_69                  (Parm, ZeroConstructor, IsPlainOldData)
// int                            ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int CustomizableObject::GetIntParameterNumOptions(int ParamIndex_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CustomizableObject.CustomizableObject.GetIntParameterNumOptions"));

	CustomizableObject_GetIntParameterNumOptions_Params params;
	params.ParamIndex_69 = ParamIndex_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CustomizableObject.CustomizableObject.GetIntParameterAvailableOption
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// int                            ParamIndex_69                  (Parm, ZeroConstructor, IsPlainOldData)
// int                            K_69                           (Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString CustomizableObject::GetIntParameterAvailableOption(int ParamIndex_69, int K_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CustomizableObject.CustomizableObject.GetIntParameterAvailableOption"));

	CustomizableObject_GetIntParameterAvailableOption_Params params;
	params.ParamIndex_69 = ParamIndex_69;
	params.K_69 = K_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CustomizableObject.CustomizableObject.FindParameter
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FString                 Name_69                        (Parm, ZeroConstructor)
// int                            ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int CustomizableObject::FindParameter(const struct FString& Name_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CustomizableObject.CustomizableObject.FindParameter"));

	CustomizableObject_FindParameter_Params params;
	params.Name_69 = Name_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CustomizableObject.CustomizableObject.CreateInstance
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// class CustomizableObjectInstance* ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

class CustomizableObjectInstance* CustomizableObject::CreateInstance()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CustomizableObject.CustomizableObject.CreateInstance"));

	CustomizableObject_CreateInstance_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CustomizableObject.DGGUI.SetCustomizableSkeletalComponent
// (Event, Public, BlueprintEvent)
// Parameters:
// class CustomizableSkeletalComponent_32759* CustomizableSkeletalComponent_69 (Parm, ZeroConstructor, InstancedReference)

void DGGUI::SetCustomizableSkeletalComponent(class CustomizableSkeletalComponent_32759* CustomizableSkeletalComponent_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CustomizableObject.DGGUI.SetCustomizableSkeletalComponent"));

	DGGUI_SetCustomizableSkeletalComponent_Params params;
	params.CustomizableSkeletalComponent_69 = CustomizableSkeletalComponent_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CustomizableObject.DGGUI.GetCustomizableSkeletalComponent
// (Event, Public, BlueprintEvent)
// Parameters:
// class CustomizableSkeletalComponent_32759* ReturnValue_69                 (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)

class CustomizableSkeletalComponent_32759* DGGUI::GetCustomizableSkeletalComponent()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CustomizableObject.DGGUI.GetCustomizableSkeletalComponent"));

	DGGUI_GetCustomizableSkeletalComponent_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CustomizableObject.CustomizableObjectInstance.UpdateSkeletalMeshAsync
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// bool                           bIgnoreCloseDist_69            (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bForceHighPriority_69          (Parm, ZeroConstructor, IsPlainOldData)

void CustomizableObjectInstance::UpdateSkeletalMeshAsync(bool bIgnoreCloseDist_69, bool bForceHighPriority_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CustomizableObject.CustomizableObjectInstance.UpdateSkeletalMeshAsync"));

	CustomizableObjectInstance_UpdateSkeletalMeshAsync_Params params;
	params.bIgnoreCloseDist_69 = bIgnoreCloseDist_69;
	params.bForceHighPriority_69 = bForceHighPriority_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CustomizableObject.CustomizableObjectInstance.SetVectorParameterSelectedOption
// (Final, Native, Public, HasOutParms, HasDefaults, BlueprintCallable)
// Parameters:
// struct FString                 VectorParamName_69             (Parm, ZeroConstructor)
// struct FLinearColor            VectorValue_69                 (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)

void CustomizableObjectInstance::SetVectorParameterSelectedOption(const struct FString& VectorParamName_69, const struct FLinearColor& VectorValue_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CustomizableObject.CustomizableObjectInstance.SetVectorParameterSelectedOption"));

	CustomizableObjectInstance_SetVectorParameterSelectedOption_Params params;
	params.VectorParamName_69 = VectorParamName_69;
	params.VectorValue_69 = VectorValue_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CustomizableObject.CustomizableObjectInstance.SetReplacePhysicsAssets
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// bool                           bReplaceEnabled_69             (Parm, ZeroConstructor, IsPlainOldData)

void CustomizableObjectInstance::SetReplacePhysicsAssets(bool bReplaceEnabled_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CustomizableObject.CustomizableObjectInstance.SetReplacePhysicsAssets"));

	CustomizableObjectInstance_SetReplacePhysicsAssets_Params params;
	params.bReplaceEnabled_69 = bReplaceEnabled_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CustomizableObject.CustomizableObjectInstance.SetRandomValues
// (Final, Native, Public, BlueprintCallable)

void CustomizableObjectInstance::SetRandomValues()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CustomizableObject.CustomizableObjectInstance.SetRandomValues"));

	CustomizableObjectInstance_SetRandomValues_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CustomizableObject.CustomizableObjectInstance.SetProjectorValue
// (Final, Native, Public, HasOutParms, HasDefaults, BlueprintCallable)
// Parameters:
// struct FString                 ProjectorParamName_69          (Parm, ZeroConstructor)
// struct FVector                 OutPos_69                      (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
// struct FVector                 OutDirection_69                (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
// struct FVector                 OutUp_69                       (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
// struct FVector                 OutScale_69                    (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
// float                          OutAngle_69                    (Parm, ZeroConstructor, IsPlainOldData)
// int                            RangeIndex_69                  (Parm, ZeroConstructor, IsPlainOldData)

void CustomizableObjectInstance::SetProjectorValue(const struct FString& ProjectorParamName_69, const struct FVector& OutPos_69, const struct FVector& OutDirection_69, const struct FVector& OutUp_69, const struct FVector& OutScale_69, float OutAngle_69, int RangeIndex_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CustomizableObject.CustomizableObjectInstance.SetProjectorValue"));

	CustomizableObjectInstance_SetProjectorValue_Params params;
	params.ProjectorParamName_69 = ProjectorParamName_69;
	params.OutPos_69 = OutPos_69;
	params.OutDirection_69 = OutDirection_69;
	params.OutUp_69 = OutUp_69;
	params.OutScale_69 = OutScale_69;
	params.OutAngle_69 = OutAngle_69;
	params.RangeIndex_69 = RangeIndex_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CustomizableObject.CustomizableObjectInstance.SetObject
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// class CustomizableObject*      InObject_69                    (Parm, ZeroConstructor)

void CustomizableObjectInstance::SetObject(class CustomizableObject* InObject_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CustomizableObject.CustomizableObjectInstance.SetObject"));

	CustomizableObjectInstance_SetObject_Params params;
	params.InObject_69 = InObject_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CustomizableObject.CustomizableObjectInstance.SetIntParameterSelectedOption
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// struct FString                 ParamName_69                   (Parm, ZeroConstructor)
// struct FString                 SelectedOptionName_69          (Parm, ZeroConstructor)
// int                            RangeIndex_69                  (Parm, ZeroConstructor, IsPlainOldData)

void CustomizableObjectInstance::SetIntParameterSelectedOption(const struct FString& ParamName_69, const struct FString& SelectedOptionName_69, int RangeIndex_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CustomizableObject.CustomizableObjectInstance.SetIntParameterSelectedOption"));

	CustomizableObjectInstance_SetIntParameterSelectedOption_Params params;
	params.ParamName_69 = ParamName_69;
	params.SelectedOptionName_69 = SelectedOptionName_69;
	params.RangeIndex_69 = RangeIndex_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CustomizableObject.CustomizableObjectInstance.SetFloatParameterSelectedOption
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// struct FString                 FloatParamName_69              (Parm, ZeroConstructor)
// float                          FloatValue_69                  (Parm, ZeroConstructor, IsPlainOldData)
// int                            RangeIndex_69                  (Parm, ZeroConstructor, IsPlainOldData)

void CustomizableObjectInstance::SetFloatParameterSelectedOption(const struct FString& FloatParamName_69, float FloatValue_69, int RangeIndex_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CustomizableObject.CustomizableObjectInstance.SetFloatParameterSelectedOption"));

	CustomizableObjectInstance_SetFloatParameterSelectedOption_Params params;
	params.FloatParamName_69 = FloatParamName_69;
	params.FloatValue_69 = FloatValue_69;
	params.RangeIndex_69 = RangeIndex_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CustomizableObject.CustomizableObjectInstance.SetCurrentState
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// struct FString                 StateName_69                   (Parm, ZeroConstructor)

void CustomizableObjectInstance::SetCurrentState(const struct FString& StateName_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CustomizableObject.CustomizableObjectInstance.SetCurrentState"));

	CustomizableObjectInstance_SetCurrentState_Params params;
	params.StateName_69 = StateName_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CustomizableObject.CustomizableObjectInstance.SetColorParameterSelectedOption
// (Final, Native, Public, HasOutParms, HasDefaults, BlueprintCallable)
// Parameters:
// struct FString                 ColorParamName_69              (Parm, ZeroConstructor)
// struct FLinearColor            ColorValue_69                  (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)

void CustomizableObjectInstance::SetColorParameterSelectedOption(const struct FString& ColorParamName_69, const struct FLinearColor& ColorValue_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CustomizableObject.CustomizableObjectInstance.SetColorParameterSelectedOption"));

	CustomizableObjectInstance_SetColorParameterSelectedOption_Params params;
	params.ColorParamName_69 = ColorParamName_69;
	params.ColorValue_69 = ColorValue_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CustomizableObject.CustomizableObjectInstance.SetBoolParameterSelectedOption
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// struct FString                 BoolParamName_69               (Parm, ZeroConstructor)
// bool                           BoolValue_69                   (Parm, ZeroConstructor, IsPlainOldData)

void CustomizableObjectInstance::SetBoolParameterSelectedOption(const struct FString& BoolParamName_69, bool BoolValue_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CustomizableObject.CustomizableObjectInstance.SetBoolParameterSelectedOption"));

	CustomizableObjectInstance_SetBoolParameterSelectedOption_Params params;
	params.BoolParamName_69 = BoolParamName_69;
	params.BoolValue_69 = BoolValue_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CustomizableObject.CustomizableObjectInstance.RemoveValueFromProjectorRange
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// struct FString                 ParamName_69                   (Parm, ZeroConstructor)
// int                            ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int CustomizableObjectInstance::RemoveValueFromProjectorRange(const struct FString& ParamName_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CustomizableObject.CustomizableObjectInstance.RemoveValueFromProjectorRange"));

	CustomizableObjectInstance_RemoveValueFromProjectorRange_Params params;
	params.ParamName_69 = ParamName_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CustomizableObject.CustomizableObjectInstance.RemoveValueFromIntRange
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// struct FString                 ParamName_69                   (Parm, ZeroConstructor)
// int                            ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int CustomizableObjectInstance::RemoveValueFromIntRange(const struct FString& ParamName_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CustomizableObject.CustomizableObjectInstance.RemoveValueFromIntRange"));

	CustomizableObjectInstance_RemoveValueFromIntRange_Params params;
	params.ParamName_69 = ParamName_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CustomizableObject.CustomizableObjectInstance.RemoveValueFromFloatRange
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// struct FString                 ParamName_69                   (Parm, ZeroConstructor)
// int                            ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int CustomizableObjectInstance::RemoveValueFromFloatRange(const struct FString& ParamName_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CustomizableObject.CustomizableObjectInstance.RemoveValueFromFloatRange"));

	CustomizableObjectInstance_RemoveValueFromFloatRange_Params params;
	params.ParamName_69 = ParamName_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CustomizableObject.CustomizableObjectInstance.RemoveMultilayerProjector
// (Final, Native, Public, HasOutParms, BlueprintCallable)
// Parameters:
// struct FName                   ProjectorParamName_69          (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)

void CustomizableObjectInstance::RemoveMultilayerProjector(const struct FName& ProjectorParamName_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CustomizableObject.CustomizableObjectInstance.RemoveMultilayerProjector"));

	CustomizableObjectInstance_RemoveMultilayerProjector_Params params;
	params.ProjectorParamName_69 = ProjectorParamName_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CustomizableObject.CustomizableObjectInstance.MultilayerProjectorUpdateVirtualLayer
// (Final, Native, Public, HasOutParms, BlueprintCallable)
// Parameters:
// struct FName                   ProjectorParamName_69          (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
// struct FName                   ID_69                          (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
// struct FMultilayerProjectorVirtualLayer Layer_69                       (ConstParm, Parm, OutParm, ReferenceParm)

void CustomizableObjectInstance::MultilayerProjectorUpdateVirtualLayer(const struct FName& ProjectorParamName_69, const struct FName& ID_69, const struct FMultilayerProjectorVirtualLayer& Layer_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CustomizableObject.CustomizableObjectInstance.MultilayerProjectorUpdateVirtualLayer"));

	CustomizableObjectInstance_MultilayerProjectorUpdateVirtualLayer_Params params;
	params.ProjectorParamName_69 = ProjectorParamName_69;
	params.ID_69 = ID_69;
	params.Layer_69 = Layer_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CustomizableObject.CustomizableObjectInstance.MultilayerProjectorUpdateLayer
// (Final, Native, Public, HasOutParms, BlueprintCallable)
// Parameters:
// struct FName                   ProjectorParamName_69          (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
// int                            Index_69                       (Parm, ZeroConstructor, IsPlainOldData)
// struct FMultilayerProjectorLayer Layer_69                       (ConstParm, Parm, OutParm, ReferenceParm)

void CustomizableObjectInstance::MultilayerProjectorUpdateLayer(const struct FName& ProjectorParamName_69, int Index_69, const struct FMultilayerProjectorLayer& Layer_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CustomizableObject.CustomizableObjectInstance.MultilayerProjectorUpdateLayer"));

	CustomizableObjectInstance_MultilayerProjectorUpdateLayer_Params params;
	params.ProjectorParamName_69 = ProjectorParamName_69;
	params.Index_69 = Index_69;
	params.Layer_69 = Layer_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CustomizableObject.CustomizableObjectInstance.MultilayerProjectorRemoveVirtualLayer
// (Final, Native, Public, HasOutParms, BlueprintCallable)
// Parameters:
// struct FName                   ProjectorParamName_69          (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
// struct FName                   ID_69                          (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)

void CustomizableObjectInstance::MultilayerProjectorRemoveVirtualLayer(const struct FName& ProjectorParamName_69, const struct FName& ID_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CustomizableObject.CustomizableObjectInstance.MultilayerProjectorRemoveVirtualLayer"));

	CustomizableObjectInstance_MultilayerProjectorRemoveVirtualLayer_Params params;
	params.ProjectorParamName_69 = ProjectorParamName_69;
	params.ID_69 = ID_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CustomizableObject.CustomizableObjectInstance.MultilayerProjectorRemoveLayerAt
// (Final, Native, Public, HasOutParms, BlueprintCallable)
// Parameters:
// struct FName                   ProjectorParamName_69          (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
// int                            Index_69                       (Parm, ZeroConstructor, IsPlainOldData)

void CustomizableObjectInstance::MultilayerProjectorRemoveLayerAt(const struct FName& ProjectorParamName_69, int Index_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CustomizableObject.CustomizableObjectInstance.MultilayerProjectorRemoveLayerAt"));

	CustomizableObjectInstance_MultilayerProjectorRemoveLayerAt_Params params;
	params.ProjectorParamName_69 = ProjectorParamName_69;
	params.Index_69 = Index_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CustomizableObject.CustomizableObjectInstance.MultilayerProjectorNumLayers
// (Final, Native, Public, HasOutParms, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FName                   ProjectorParamName_69          (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
// int                            ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int CustomizableObjectInstance::MultilayerProjectorNumLayers(const struct FName& ProjectorParamName_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CustomizableObject.CustomizableObjectInstance.MultilayerProjectorNumLayers"));

	CustomizableObjectInstance_MultilayerProjectorNumLayers_Params params;
	params.ProjectorParamName_69 = ProjectorParamName_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CustomizableObject.CustomizableObjectInstance.MultilayerProjectorGetVirtualLayers
// (Final, Native, Public, HasOutParms, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FName                   ProjectorParamName_69          (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
// TArray<struct FName>           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

TArray<struct FName> CustomizableObjectInstance::MultilayerProjectorGetVirtualLayers(const struct FName& ProjectorParamName_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CustomizableObject.CustomizableObjectInstance.MultilayerProjectorGetVirtualLayers"));

	CustomizableObjectInstance_MultilayerProjectorGetVirtualLayers_Params params;
	params.ProjectorParamName_69 = ProjectorParamName_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CustomizableObject.CustomizableObjectInstance.MultilayerProjectorGetVirtualLayer
// (Final, Native, Public, HasOutParms, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FName                   ProjectorParamName_69          (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
// struct FName                   ID_69                          (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
// struct FMultilayerProjectorVirtualLayer ReturnValue_69                 (Parm, OutParm, ReturnParm)

struct FMultilayerProjectorVirtualLayer CustomizableObjectInstance::MultilayerProjectorGetVirtualLayer(const struct FName& ProjectorParamName_69, const struct FName& ID_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CustomizableObject.CustomizableObjectInstance.MultilayerProjectorGetVirtualLayer"));

	CustomizableObjectInstance_MultilayerProjectorGetVirtualLayer_Params params;
	params.ProjectorParamName_69 = ProjectorParamName_69;
	params.ID_69 = ID_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CustomizableObject.CustomizableObjectInstance.MultilayerProjectorGetLayer
// (Final, Native, Public, HasOutParms, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FName                   ProjectorParamName_69          (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
// int                            Index_69                       (Parm, ZeroConstructor, IsPlainOldData)
// struct FMultilayerProjectorLayer ReturnValue_69                 (Parm, OutParm, ReturnParm)

struct FMultilayerProjectorLayer CustomizableObjectInstance::MultilayerProjectorGetLayer(const struct FName& ProjectorParamName_69, int Index_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CustomizableObject.CustomizableObjectInstance.MultilayerProjectorGetLayer"));

	CustomizableObjectInstance_MultilayerProjectorGetLayer_Params params;
	params.ProjectorParamName_69 = ProjectorParamName_69;
	params.Index_69 = Index_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CustomizableObject.CustomizableObjectInstance.MultilayerProjectorFindOrCreateVirtualLayer
// (Final, Native, Public, HasOutParms, BlueprintCallable)
// Parameters:
// struct FName                   ProjectorParamName_69          (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
// struct FName                   ID_69                          (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
// struct FMultilayerProjectorVirtualLayer ReturnValue_69                 (Parm, OutParm, ReturnParm)

struct FMultilayerProjectorVirtualLayer CustomizableObjectInstance::MultilayerProjectorFindOrCreateVirtualLayer(const struct FName& ProjectorParamName_69, const struct FName& ID_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CustomizableObject.CustomizableObjectInstance.MultilayerProjectorFindOrCreateVirtualLayer"));

	CustomizableObjectInstance_MultilayerProjectorFindOrCreateVirtualLayer_Params params;
	params.ProjectorParamName_69 = ProjectorParamName_69;
	params.ID_69 = ID_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CustomizableObject.CustomizableObjectInstance.MultilayerProjectorCreateVirtualLayer
// (Final, Native, Public, HasOutParms, BlueprintCallable)
// Parameters:
// struct FName                   ProjectorParamName_69          (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
// struct FName                   ID_69                          (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)

void CustomizableObjectInstance::MultilayerProjectorCreateVirtualLayer(const struct FName& ProjectorParamName_69, const struct FName& ID_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CustomizableObject.CustomizableObjectInstance.MultilayerProjectorCreateVirtualLayer"));

	CustomizableObjectInstance_MultilayerProjectorCreateVirtualLayer_Params params;
	params.ProjectorParamName_69 = ProjectorParamName_69;
	params.ID_69 = ID_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CustomizableObject.CustomizableObjectInstance.MultilayerProjectorCreateLayer
// (Final, Native, Public, HasOutParms, BlueprintCallable)
// Parameters:
// struct FName                   ProjectorParamName_69          (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
// int                            Index_69                       (Parm, ZeroConstructor, IsPlainOldData)

void CustomizableObjectInstance::MultilayerProjectorCreateLayer(const struct FName& ProjectorParamName_69, int Index_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CustomizableObject.CustomizableObjectInstance.MultilayerProjectorCreateLayer"));

	CustomizableObjectInstance_MultilayerProjectorCreateLayer_Params params;
	params.ProjectorParamName_69 = ProjectorParamName_69;
	params.Index_69 = Index_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CustomizableObject.CustomizableObjectInstance.IsParamMultidimensional
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FString                 ParamName_69                   (Parm, ZeroConstructor)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool CustomizableObjectInstance::IsParamMultidimensional(const struct FString& ParamName_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CustomizableObject.CustomizableObjectInstance.IsParamMultidimensional"));

	CustomizableObjectInstance_IsParamMultidimensional_Params params;
	params.ParamName_69 = ParamName_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CustomizableObject.CustomizableObjectInstance.IsParameterRelevant
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FString                 ParamName_69                   (Parm, ZeroConstructor)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool CustomizableObjectInstance::IsParameterRelevant(const struct FString& ParamName_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CustomizableObject.CustomizableObjectInstance.IsParameterRelevant"));

	CustomizableObjectInstance_IsParameterRelevant_Params params;
	params.ParamName_69 = ParamName_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CustomizableObject.CustomizableObjectInstance.HasAnySkeletalMesh
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool CustomizableObjectInstance::HasAnySkeletalMesh()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CustomizableObject.CustomizableObjectInstance.HasAnySkeletalMesh"));

	CustomizableObjectInstance_HasAnySkeletalMesh_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CustomizableObject.CustomizableObjectInstance.HasAnyParameters
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool CustomizableObjectInstance::HasAnyParameters()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CustomizableObject.CustomizableObjectInstance.HasAnyParameters"));

	CustomizableObjectInstance_HasAnyParameters_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CustomizableObject.CustomizableObjectInstance.GetVectorParameters
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// TArray<struct FCustomizableObjectVectorParameterValue> ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

TArray<struct FCustomizableObjectVectorParameterValue> CustomizableObjectInstance::GetVectorParameters()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CustomizableObject.CustomizableObjectInstance.GetVectorParameters"));

	CustomizableObjectInstance_GetVectorParameters_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CustomizableObject.CustomizableObjectInstance.GetTextureParameters
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// TArray<struct FCustomizableObjectTextureParameterValue> ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

TArray<struct FCustomizableObjectTextureParameterValue> CustomizableObjectInstance::GetTextureParameters()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CustomizableObject.CustomizableObjectInstance.GetTextureParameters"));

	CustomizableObjectInstance_GetTextureParameters_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CustomizableObject.CustomizableObjectInstance.GetSkeletalMesh
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// int                            ComponentIndex_69              (Parm, ZeroConstructor, IsPlainOldData)
// class SkeletalMesh*            ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

class SkeletalMesh* CustomizableObjectInstance::GetSkeletalMesh(int ComponentIndex_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CustomizableObject.CustomizableObjectInstance.GetSkeletalMesh"));

	CustomizableObjectInstance_GetSkeletalMesh_Params params;
	params.ComponentIndex_69 = ComponentIndex_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CustomizableObject.CustomizableObjectInstance.GetProjectorValue
// (Final, Native, Public, HasOutParms, HasDefaults, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FString                 ProjectorParamName_69          (Parm, ZeroConstructor)
// struct FVector                 OutPos_69                      (Parm, OutParm, ZeroConstructor, IsPlainOldData)
// struct FVector                 OutDirection_69                (Parm, OutParm, ZeroConstructor, IsPlainOldData)
// struct FVector                 OutUp_69                       (Parm, OutParm, ZeroConstructor, IsPlainOldData)
// struct FVector                 OutScale_69                    (Parm, OutParm, ZeroConstructor, IsPlainOldData)
// float                          OutAngle_69                    (Parm, OutParm, ZeroConstructor, IsPlainOldData)
// ECustomizableObjectProjectorType OutType_69                     (Parm, OutParm, ZeroConstructor, IsPlainOldData)
// int                            RangeIndex_69                  (Parm, ZeroConstructor, IsPlainOldData)

void CustomizableObjectInstance::GetProjectorValue(const struct FString& ProjectorParamName_69, int RangeIndex_69, struct FVector* OutPos_69, struct FVector* OutDirection_69, struct FVector* OutUp_69, struct FVector* OutScale_69, float* OutAngle_69, ECustomizableObjectProjectorType* OutType_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CustomizableObject.CustomizableObjectInstance.GetProjectorValue"));

	CustomizableObjectInstance_GetProjectorValue_Params params;
	params.ProjectorParamName_69 = ProjectorParamName_69;
	params.RangeIndex_69 = RangeIndex_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (OutPos_69 != nullptr)
		*OutPos_69 = params.OutPos_69;
	if (OutDirection_69 != nullptr)
		*OutDirection_69 = params.OutDirection_69;
	if (OutUp_69 != nullptr)
		*OutUp_69 = params.OutUp_69;
	if (OutScale_69 != nullptr)
		*OutScale_69 = params.OutScale_69;
	if (OutAngle_69 != nullptr)
		*OutAngle_69 = params.OutAngle_69;
	if (OutType_69 != nullptr)
		*OutType_69 = params.OutType_69;
}


// Function CustomizableObject.CustomizableObjectInstance.GetProjectorUp
// (Final, Native, Public, HasDefaults, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FString                 ParamName_69                   (Parm, ZeroConstructor)
// int                            RangeIndex_69                  (Parm, ZeroConstructor, IsPlainOldData)
// struct FVector                 ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

struct FVector CustomizableObjectInstance::GetProjectorUp(const struct FString& ParamName_69, int RangeIndex_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CustomizableObject.CustomizableObjectInstance.GetProjectorUp"));

	CustomizableObjectInstance_GetProjectorUp_Params params;
	params.ParamName_69 = ParamName_69;
	params.RangeIndex_69 = RangeIndex_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CustomizableObject.CustomizableObjectInstance.GetProjectorScale
// (Final, Native, Public, HasDefaults, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FString                 ParamName_69                   (Parm, ZeroConstructor)
// int                            RangeIndex_69                  (Parm, ZeroConstructor, IsPlainOldData)
// struct FVector                 ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

struct FVector CustomizableObjectInstance::GetProjectorScale(const struct FString& ParamName_69, int RangeIndex_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CustomizableObject.CustomizableObjectInstance.GetProjectorScale"));

	CustomizableObjectInstance_GetProjectorScale_Params params;
	params.ParamName_69 = ParamName_69;
	params.RangeIndex_69 = RangeIndex_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CustomizableObject.CustomizableObjectInstance.GetProjectorPosition
// (Final, Native, Public, HasDefaults, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FString                 ParamName_69                   (Parm, ZeroConstructor)
// int                            RangeIndex_69                  (Parm, ZeroConstructor, IsPlainOldData)
// struct FVector                 ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

struct FVector CustomizableObjectInstance::GetProjectorPosition(const struct FString& ParamName_69, int RangeIndex_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CustomizableObject.CustomizableObjectInstance.GetProjectorPosition"));

	CustomizableObjectInstance_GetProjectorPosition_Params params;
	params.ParamName_69 = ParamName_69;
	params.RangeIndex_69 = RangeIndex_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CustomizableObject.CustomizableObjectInstance.GetProjectorParameterType
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FString                 ParamName_69                   (Parm, ZeroConstructor)
// int                            RangeIndex_69                  (Parm, ZeroConstructor, IsPlainOldData)
// ECustomizableObjectProjectorType ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

ECustomizableObjectProjectorType CustomizableObjectInstance::GetProjectorParameterType(const struct FString& ParamName_69, int RangeIndex_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CustomizableObject.CustomizableObjectInstance.GetProjectorParameterType"));

	CustomizableObjectInstance_GetProjectorParameterType_Params params;
	params.ParamName_69 = ParamName_69;
	params.RangeIndex_69 = RangeIndex_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CustomizableObject.CustomizableObjectInstance.GetProjectorParameters
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// TArray<struct FCustomizableObjectProjectorParameterValue> ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

TArray<struct FCustomizableObjectProjectorParameterValue> CustomizableObjectInstance::GetProjectorParameters()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CustomizableObject.CustomizableObjectInstance.GetProjectorParameters"));

	CustomizableObjectInstance_GetProjectorParameters_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CustomizableObject.CustomizableObjectInstance.GetProjectorDirection
// (Final, Native, Public, HasDefaults, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FString                 ParamName_69                   (Parm, ZeroConstructor)
// int                            RangeIndex_69                  (Parm, ZeroConstructor, IsPlainOldData)
// struct FVector                 ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

struct FVector CustomizableObjectInstance::GetProjectorDirection(const struct FString& ParamName_69, int RangeIndex_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CustomizableObject.CustomizableObjectInstance.GetProjectorDirection"));

	CustomizableObjectInstance_GetProjectorDirection_Params params;
	params.ParamName_69 = ParamName_69;
	params.RangeIndex_69 = RangeIndex_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CustomizableObject.CustomizableObjectInstance.GetProjectorAngle
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FString                 ParamName_69                   (Parm, ZeroConstructor)
// int                            RangeIndex_69                  (Parm, ZeroConstructor, IsPlainOldData)
// float                          ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

float CustomizableObjectInstance::GetProjectorAngle(const struct FString& ParamName_69, int RangeIndex_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CustomizableObject.CustomizableObjectInstance.GetProjectorAngle"));

	CustomizableObjectInstance_GetProjectorAngle_Params params;
	params.ParamName_69 = ParamName_69;
	params.RangeIndex_69 = RangeIndex_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CustomizableObject.CustomizableObjectInstance.GetParameterDescription
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// struct FString                 ParamName_69                   (Parm, ZeroConstructor)
// int                            DescIndex_69                   (Parm, ZeroConstructor, IsPlainOldData)
// class Texture2D*               ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

class Texture2D* CustomizableObjectInstance::GetParameterDescription(const struct FString& ParamName_69, int DescIndex_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CustomizableObject.CustomizableObjectInstance.GetParameterDescription"));

	CustomizableObjectInstance_GetParameterDescription_Params params;
	params.ParamName_69 = ParamName_69;
	params.DescIndex_69 = DescIndex_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CustomizableObject.CustomizableObjectInstance.GetIntParameterSelectedOption
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FString                 ParamName_69                   (Parm, ZeroConstructor)
// int                            RangeIndex_69                  (Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString CustomizableObjectInstance::GetIntParameterSelectedOption(const struct FString& ParamName_69, int RangeIndex_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CustomizableObject.CustomizableObjectInstance.GetIntParameterSelectedOption"));

	CustomizableObjectInstance_GetIntParameterSelectedOption_Params params;
	params.ParamName_69 = ParamName_69;
	params.RangeIndex_69 = RangeIndex_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CustomizableObject.CustomizableObjectInstance.GetIntParameters
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// TArray<struct FCustomizableObjectIntParameterValue> ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

TArray<struct FCustomizableObjectIntParameterValue> CustomizableObjectInstance::GetIntParameters()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CustomizableObject.CustomizableObjectInstance.GetIntParameters"));

	CustomizableObjectInstance_GetIntParameters_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CustomizableObject.CustomizableObjectInstance.GetFloatParameterSelectedOption
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FString                 FloatParamName_69              (Parm, ZeroConstructor)
// int                            RangeIndex_69                  (Parm, ZeroConstructor, IsPlainOldData)
// float                          ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

float CustomizableObjectInstance::GetFloatParameterSelectedOption(const struct FString& FloatParamName_69, int RangeIndex_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CustomizableObject.CustomizableObjectInstance.GetFloatParameterSelectedOption"));

	CustomizableObjectInstance_GetFloatParameterSelectedOption_Params params;
	params.FloatParamName_69 = FloatParamName_69;
	params.RangeIndex_69 = RangeIndex_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CustomizableObject.CustomizableObjectInstance.GetFloatParameters
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// TArray<struct FCustomizableObjectFloatParameterValue> ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

TArray<struct FCustomizableObjectFloatParameterValue> CustomizableObjectInstance::GetFloatParameters()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CustomizableObject.CustomizableObjectInstance.GetFloatParameters"));

	CustomizableObjectInstance_GetFloatParameters_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CustomizableObject.CustomizableObjectInstance.GetCustomizableObject
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// class CustomizableObject*      ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

class CustomizableObject* CustomizableObjectInstance::GetCustomizableObject()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CustomizableObject.CustomizableObjectInstance.GetCustomizableObject"));

	CustomizableObjectInstance_GetCustomizableObject_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CustomizableObject.CustomizableObjectInstance.GetCurrentState
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FString                 ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString CustomizableObjectInstance::GetCurrentState()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CustomizableObject.CustomizableObjectInstance.GetCurrentState"));

	CustomizableObjectInstance_GetCurrentState_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CustomizableObject.CustomizableObjectInstance.GetColorParameterSelectedOption
// (Final, Native, Public, HasDefaults, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FString                 ColorParamName_69              (Parm, ZeroConstructor)
// struct FLinearColor            ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

struct FLinearColor CustomizableObjectInstance::GetColorParameterSelectedOption(const struct FString& ColorParamName_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CustomizableObject.CustomizableObjectInstance.GetColorParameterSelectedOption"));

	CustomizableObjectInstance_GetColorParameterSelectedOption_Params params;
	params.ColorParamName_69 = ColorParamName_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CustomizableObject.CustomizableObjectInstance.GetBoolParameterSelectedOption
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FString                 BoolParamName_69               (Parm, ZeroConstructor)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool CustomizableObjectInstance::GetBoolParameterSelectedOption(const struct FString& BoolParamName_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CustomizableObject.CustomizableObjectInstance.GetBoolParameterSelectedOption"));

	CustomizableObjectInstance_GetBoolParameterSelectedOption_Params params;
	params.BoolParamName_69 = BoolParamName_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CustomizableObject.CustomizableObjectInstance.GetBoolParameters
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// TArray<struct FCustomizableObjectBoolParameterValue> ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

TArray<struct FCustomizableObjectBoolParameterValue> CustomizableObjectInstance::GetBoolParameters()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CustomizableObject.CustomizableObjectInstance.GetBoolParameters"));

	CustomizableObjectInstance_GetBoolParameters_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CustomizableObject.CustomizableObjectInstance.GetAnimBP
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// int                            ComponentIndex_69              (Parm, ZeroConstructor, IsPlainOldData)
// int                            SlotIndex_69                   (Parm, ZeroConstructor, IsPlainOldData)
// class AnimInstance*            ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

class AnimInstance* CustomizableObjectInstance::GetAnimBP(int ComponentIndex_69, int SlotIndex_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CustomizableObject.CustomizableObjectInstance.GetAnimBP"));

	CustomizableObjectInstance_GetAnimBP_Params params;
	params.ComponentIndex_69 = ComponentIndex_69;
	params.SlotIndex_69 = SlotIndex_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CustomizableObject.CustomizableObjectInstance.GetAnimationGameplayTags
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FGameplayTagContainer   ReturnValue_69                 (ConstParm, Parm, OutParm, ReturnParm, ReferenceParm)

struct FGameplayTagContainer CustomizableObjectInstance::GetAnimationGameplayTags()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CustomizableObject.CustomizableObjectInstance.GetAnimationGameplayTags"));

	CustomizableObjectInstance_GetAnimationGameplayTags_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CustomizableObject.CustomizableObjectInstance.ForEachAnimInstance
// (Final, Native, Public, BlueprintCallable, Const)
// Parameters:
// int                            ComponentIndex_69              (Parm, ZeroConstructor, IsPlainOldData)
// struct FScriptDelegate         Delegate_69                    (Parm, ZeroConstructor)

void CustomizableObjectInstance::ForEachAnimInstance(int ComponentIndex_69, const struct FScriptDelegate& Delegate_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CustomizableObject.CustomizableObjectInstance.ForEachAnimInstance"));

	CustomizableObjectInstance_ForEachAnimInstance_Params params;
	params.ComponentIndex_69 = ComponentIndex_69;
	params.Delegate_69 = Delegate_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CustomizableObject.CustomizableObjectInstance.FindVectorParameterNameIndex
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FString                 ParamName_69                   (Parm, ZeroConstructor)
// int                            ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int CustomizableObjectInstance::FindVectorParameterNameIndex(const struct FString& ParamName_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CustomizableObject.CustomizableObjectInstance.FindVectorParameterNameIndex"));

	CustomizableObjectInstance_FindVectorParameterNameIndex_Params params;
	params.ParamName_69 = ParamName_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CustomizableObject.CustomizableObjectInstance.FindProjectorParameterNameIndex
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FString                 ParamName_69                   (Parm, ZeroConstructor)
// int                            ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int CustomizableObjectInstance::FindProjectorParameterNameIndex(const struct FString& ParamName_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CustomizableObject.CustomizableObjectInstance.FindProjectorParameterNameIndex"));

	CustomizableObjectInstance_FindProjectorParameterNameIndex_Params params;
	params.ParamName_69 = ParamName_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CustomizableObject.CustomizableObjectInstance.FindIntParameterNameIndex
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FString                 ParamName_69                   (Parm, ZeroConstructor)
// int                            ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int CustomizableObjectInstance::FindIntParameterNameIndex(const struct FString& ParamName_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CustomizableObject.CustomizableObjectInstance.FindIntParameterNameIndex"));

	CustomizableObjectInstance_FindIntParameterNameIndex_Params params;
	params.ParamName_69 = ParamName_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CustomizableObject.CustomizableObjectInstance.FindFloatParameterNameIndex
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FString                 ParamName_69                   (Parm, ZeroConstructor)
// int                            ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int CustomizableObjectInstance::FindFloatParameterNameIndex(const struct FString& ParamName_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CustomizableObject.CustomizableObjectInstance.FindFloatParameterNameIndex"));

	CustomizableObjectInstance_FindFloatParameterNameIndex_Params params;
	params.ParamName_69 = ParamName_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CustomizableObject.CustomizableObjectInstance.FindBoolParameterNameIndex
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FString                 ParamName_69                   (Parm, ZeroConstructor)
// int                            ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int CustomizableObjectInstance::FindBoolParameterNameIndex(const struct FString& ParamName_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CustomizableObject.CustomizableObjectInstance.FindBoolParameterNameIndex"));

	CustomizableObjectInstance_FindBoolParameterNameIndex_Params params;
	params.ParamName_69 = ParamName_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CustomizableObject.CustomizableObjectInstance.CurrentParamRange
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FString                 ParamName_69                   (Parm, ZeroConstructor)
// int                            ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int CustomizableObjectInstance::CurrentParamRange(const struct FString& ParamName_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CustomizableObject.CustomizableObjectInstance.CurrentParamRange"));

	CustomizableObjectInstance_CurrentParamRange_Params params;
	params.ParamName_69 = ParamName_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CustomizableObject.CustomizableObjectInstance.CreateMultiLayerProjector
// (Final, Native, Public, HasOutParms, BlueprintCallable)
// Parameters:
// struct FName                   ProjectorParamName_69          (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool CustomizableObjectInstance::CreateMultiLayerProjector(const struct FName& ProjectorParamName_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CustomizableObject.CustomizableObjectInstance.CreateMultiLayerProjector"));

	CustomizableObjectInstance_CreateMultiLayerProjector_Params params;
	params.ProjectorParamName_69 = ProjectorParamName_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CustomizableObject.CustomizableObjectInstance.CloneStatic
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// class Object_32759*            Outer_69                       (Parm, ZeroConstructor)
// class CustomizableObjectInstance* ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

class CustomizableObjectInstance* CustomizableObjectInstance::CloneStatic(class Object_32759* Outer_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CustomizableObject.CustomizableObjectInstance.CloneStatic"));

	CustomizableObjectInstance_CloneStatic_Params params;
	params.Outer_69 = Outer_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CustomizableObject.CustomizableObjectInstance.Clone
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// class CustomizableObjectInstance* ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

class CustomizableObjectInstance* CustomizableObjectInstance::Clone()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CustomizableObject.CustomizableObjectInstance.Clone"));

	CustomizableObjectInstance_Clone_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CustomizableObject.CustomizableObjectInstance.AddValueToProjectorRange
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// struct FString                 ParamName_69                   (Parm, ZeroConstructor)
// int                            ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int CustomizableObjectInstance::AddValueToProjectorRange(const struct FString& ParamName_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CustomizableObject.CustomizableObjectInstance.AddValueToProjectorRange"));

	CustomizableObjectInstance_AddValueToProjectorRange_Params params;
	params.ParamName_69 = ParamName_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CustomizableObject.CustomizableObjectInstance.AddValueToIntRange
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// struct FString                 ParamName_69                   (Parm, ZeroConstructor)
// int                            ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int CustomizableObjectInstance::AddValueToIntRange(const struct FString& ParamName_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CustomizableObject.CustomizableObjectInstance.AddValueToIntRange"));

	CustomizableObjectInstance_AddValueToIntRange_Params params;
	params.ParamName_69 = ParamName_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CustomizableObject.CustomizableObjectInstance.AddValueToFloatRange
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// struct FString                 ParamName_69                   (Parm, ZeroConstructor)
// int                            ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int CustomizableObjectInstance::AddValueToFloatRange(const struct FString& ParamName_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CustomizableObject.CustomizableObjectInstance.AddValueToFloatRange"));

	CustomizableObjectInstance_AddValueToFloatRange_Params params;
	params.ParamName_69 = ParamName_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CustomizableObject.CustomizableSkeletalComponent_32759.UpdateSkeletalMeshAsync
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// bool                           bNeverSkipUpdate_69            (Parm, ZeroConstructor, IsPlainOldData)

void CustomizableSkeletalComponent_32759::UpdateSkeletalMeshAsync(bool bNeverSkipUpdate_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CustomizableObject.CustomizableSkeletalComponent_32759.UpdateSkeletalMeshAsync"));

	CustomizableSkeletalComponent_32759_UpdateSkeletalMeshAsync_Params params;
	params.bNeverSkipUpdate_69 = bNeverSkipUpdate_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CustomizableObject.CustomizableObjectSystem.SetReleaseMutableTexturesImmediately
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// bool                           bReleaseTextures_69            (Parm, ZeroConstructor, IsPlainOldData)

void CustomizableObjectSystem::SetReleaseMutableTexturesImmediately(bool bReleaseTextures_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CustomizableObject.CustomizableObjectSystem.SetReleaseMutableTexturesImmediately"));

	CustomizableObjectSystem_SetReleaseMutableTexturesImmediately_Params params;
	params.bReleaseTextures_69 = bReleaseTextures_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CustomizableObject.CustomizableObjectSystem.GetTotalInstances
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// int                            ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int CustomizableObjectSystem::GetTotalInstances()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CustomizableObject.CustomizableObjectSystem.GetTotalInstances"));

	CustomizableObjectSystem_GetTotalInstances_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CustomizableObject.CustomizableObjectSystem.GetTextureMemoryUsed
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// int                            ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int CustomizableObjectSystem::GetTextureMemoryUsed()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CustomizableObject.CustomizableObjectSystem.GetTextureMemoryUsed"));

	CustomizableObjectSystem_GetTextureMemoryUsed_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CustomizableObject.CustomizableObjectSystem.GetPluginVersion
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FString                 ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString CustomizableObjectSystem::GetPluginVersion()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CustomizableObject.CustomizableObjectSystem.GetPluginVersion"));

	CustomizableObjectSystem_GetPluginVersion_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CustomizableObject.CustomizableObjectSystem.GetNumPendingInstances
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// int                            ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int CustomizableObjectSystem::GetNumPendingInstances()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CustomizableObject.CustomizableObjectSystem.GetNumPendingInstances"));

	CustomizableObjectSystem_GetNumPendingInstances_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CustomizableObject.CustomizableObjectSystem.GetNumInstances
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// int                            ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int CustomizableObjectSystem::GetNumInstances()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CustomizableObject.CustomizableObjectSystem.GetNumInstances"));

	CustomizableObjectSystem_GetNumInstances_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CustomizableObject.CustomizableObjectSystem.GetInstance
// (Final, Native, Static, Public, BlueprintCallable, BlueprintPure)
// Parameters:
// class CustomizableObjectSystem* ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

class CustomizableObjectSystem* CustomizableObjectSystem::STATIC_GetInstance()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CustomizableObject.CustomizableObjectSystem.GetInstance"));

	CustomizableObjectSystem_GetInstance_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CustomizableObject.CustomizableObjectSystem.GetAverageBuildTime
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// int                            ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int CustomizableObjectSystem::GetAverageBuildTime()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CustomizableObject.CustomizableObjectSystem.GetAverageBuildTime"));

	CustomizableObjectSystem_GetAverageBuildTime_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function AndroidFileServer.AndroidFileServerBPLibrary.StopFileServer
struct AndroidFileServerBPLibrary_StopFileServer_Params
{
	bool                                               bUSB_69;                                                  // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bNetwork_69;                                              // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AndroidFileServer.AndroidFileServerBPLibrary.StartFileServer
struct AndroidFileServerBPLibrary_StartFileServer_Params
{
	bool                                               bUSB_69;                                                  // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bNetwork_69;                                              // (Parm, ZeroConstructor, IsPlainOldData)
	int                                                Port_69;                                                  // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AndroidFileServer.AndroidFileServerBPLibrary.IsFileServerRunning
struct AndroidFileServerBPLibrary_IsFileServerRunning_Params
{
	TEnumAsByte<EAFSActiveType>                        ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function AscenderCodeRuntime.FortAscenderZipline.OnRep_TargetSplineEndLocation
struct FortAscenderZipline_OnRep_TargetSplineEndLocation_Params
{
};

// Function AscenderCodeRuntime.FortAscenderZipline.OnRep_PawnUsingHandle
struct FortAscenderZipline_OnRep_PawnUsingHandle_Params
{
};

// Function AscenderCodeRuntime.FortAscenderZipline.OnRep_InitialSplineEndLocation
struct FortAscenderZipline_OnRep_InitialSplineEndLocation_Params
{
};

// Function AscenderCodeRuntime.FortAscenderZipline.HandlePawnUsingHandleDied
struct FortAscenderZipline_HandlePawnUsingHandleDied_Params
{
	class FortPawn*                                    DeadPawn_69;                                              // (Parm, ZeroConstructor)
};

// Function AscenderCodeRuntime.FortAscenderZipline.HandleFloorActorHealthChanged
struct FortAscenderZipline_HandleFloorActorHealthChanged_Params
{
};

// Function AscenderCodeRuntime.FortAscenderZipline.HandleFloorActorDestroyed
struct FortAscenderZipline_HandleFloorActorDestroyed_Params
{
	class Actor_32759*                                 Actor_69;                                                 // (Parm, ZeroConstructor)
};

// Function AscenderCodeRuntime.FortAscenderZipline.GetTopComponent
struct FortAscenderZipline_GetTopComponent_Params
{
	class PrimitiveComponent*                          ReturnValue_69;                                           // (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)
};

// Function AscenderCodeRuntime.FortAscenderZipline.GetPawnUsingHandle
struct FortAscenderZipline_GetPawnUsingHandle_Params
{
	class FortPlayerPawn*                              ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function AscenderCodeRuntime.FortAscenderZipline.GetInteractComponentOverride
struct FortAscenderZipline_GetInteractComponentOverride_Params
{
	class FortPlayerPawn*                              InteractingPawn_69;                                       // (Parm, ZeroConstructor)
	class PrimitiveComponent*                          InteractComponent_69;                                     // (Parm, ZeroConstructor, InstancedReference)
	class PrimitiveComponent*                          ReturnValue_69;                                           // (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)
};

// Function AscenderCodeRuntime.FortAscenderZipline.GetHandleComponent
struct FortAscenderZipline_GetHandleComponent_Params
{
	class PrimitiveComponent*                          ReturnValue_69;                                           // (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)
};

// Function AscenderCodeRuntime.FortAscenderZipline.BP_HandleUpdatedLoweringHandle
struct FortAscenderZipline_BP_HandleUpdatedLoweringHandle_Params
{
};

// Function AscenderCodeRuntime.FortAscenderZipline.BP_HandleUpdatedLoweringCable
struct FortAscenderZipline_BP_HandleUpdatedLoweringCable_Params
{
};

// Function AscenderCodeRuntime.FortAscenderZipline.BP_HandleStoppedLoweringHandle
struct FortAscenderZipline_BP_HandleStoppedLoweringHandle_Params
{
};

// Function AscenderCodeRuntime.FortAscenderZipline.BP_HandleStoppedLoweringCable
struct FortAscenderZipline_BP_HandleStoppedLoweringCable_Params
{
};

// Function AscenderCodeRuntime.FortAscenderZipline.BP_HandleStartedLoweringHandle
struct FortAscenderZipline_BP_HandleStartedLoweringHandle_Params
{
};

// Function AscenderCodeRuntime.FortAscenderZipline.BP_HandleStartedLoweringCable
struct FortAscenderZipline_BP_HandleStartedLoweringCable_Params
{
};

// Function AscenderCodeRuntime.FortAscenderZipline.BP_HandlePlayerStoppedUsingHandle
struct FortAscenderZipline_BP_HandlePlayerStoppedUsingHandle_Params
{
	class FortPlayerPawn*                              Player_69;                                                // (Parm, ZeroConstructor)
};

// Function AscenderCodeRuntime.FortAscenderZipline.BP_HandlePlayerStartedUsingHandle
struct FortAscenderZipline_BP_HandlePlayerStartedUsingHandle_Params
{
	class FortPlayerPawn*                              Player_69;                                                // (Parm, ZeroConstructor)
};

// Function AscenderCodeRuntime.FortAscenderZipline.ApplyStructureDamage
struct FortAscenderZipline_ApplyStructureDamage_Params
{
	class BuildingSMActor*                             BuildingActor_69;                                         // (Parm, ZeroConstructor)
	class Actor_32759*                                 DamageSource_69;                                          // (Parm, ZeroConstructor)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Enums
//---------------------------------------------------------------------------

// Enum AudioExtensions.EAudioParameterType
enum class EAudioParameterType : uint8_t
{
	None                           = 0,
	Boolean                        = 1,
	Integer                        = 2,
	Float                          = 3,
	String                         = 4,
	Object                         = 5,
	NoneArray                      = 6,
	BooleanArray                   = 7,
	IntegerArray                   = 8,
	FloatArray                     = 9,
	StringArray                    = 10,
	ObjectArray                    = 11,
	COUNT                          = 12,
	EAudioParameterType_MAX        = 13
};


// Enum AudioExtensions.EPcmBitDepthConversion
enum class EPcmBitDepthConversion : uint8_t
{
	SameAsSource                   = 0,
	Int16                          = 1,
	Float32                        = 2,
	EPcmBitDepthConversion_MAX     = 3
};



//---------------------------------------------------------------------------
//Script Structs
//---------------------------------------------------------------------------

// ScriptStruct AudioExtensions.AudioParameter
// 0x0090
struct FAudioParameter
{
	struct FName                                       ParamName_69;                                             // 0x0000(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              FloatParam_69;                                            // 0x0004(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               BoolParam_69;                                             // 0x0008(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0009(0x0003) MISSED OFFSET
	int                                                IntParam_69;                                              // 0x000C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	class Object_32759*                                ObjectParam_69;                                           // 0x0010(0x0008) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     StringParam_69;                                           // 0x0018(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	TArray<float>                                      ArrayFloatParam_69;                                       // 0x0028(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	TArray<bool>                                       ArrayBoolParam_69;                                        // 0x0038(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	TArray<int>                                        ArrayIntParam_69;                                         // 0x0048(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	TArray<class Object_32759*>                        ArrayObjectParam_69;                                      // 0x0058(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	TArray<struct FString>                             ArrayStringParam_69;                                      // 0x0068(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	EAudioParameterType                                ParamType_69;                                             // 0x0078(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x3];                                       // 0x0079(0x0003) MISSED OFFSET
	struct FName                                       TypeName_69;                                              // 0x007C(0x0008) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData02[0x10];                                      // 0x0080(0x0010) MISSED OFFSET
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

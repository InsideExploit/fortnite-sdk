#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Classes
//---------------------------------------------------------------------------

// Class DaySequence.DaySequence
// 0x00C8 (0x0130 - 0x0068)
class DaySequence : public MovieSceneSequence
{
public:
	unsigned char                                      UnknownData00[0x8];                                       // 0x0068(0x0008) MISSED OFFSET
	class MovieScene*                                  MovieScene_69;                                            // 0x0070(0x0008) (ExportObject, ZeroConstructor, InstancedReference)
	struct FDaySequenceBindingReferences               BindingReferences_69;                                     // 0x0078(0x00A0)
	unsigned char                                      UnknownData01[0x8];                                       // 0x0118(0x0008) UNKNOWN PROPERTY: ClassPtrProperty DaySequence.DaySequence.DirectorClass_69
	TArray<class AssetUserData*>                       AssetUserData_69;                                         // 0x0120(0x0010) (Edit, ExportObject, ZeroConstructor)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class DaySequence.DaySequence"));
		
		return ptr;
	}

};


// Class DaySequence.DaySequenceActor
// 0x00D0 (0x0358 - 0x0288)
class DaySequenceActor : public Info
{
public:
	unsigned char                                      UnknownData00[0x10];                                      // 0x0288(0x0010) MISSED OFFSET
	class DaySequencePlayer*                           SequencePlayer_69;                                        // 0x0298(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, Net, ZeroConstructor, Transient, InstancedReference)
	TArray<class DaySequence*>                         DaySequenceAssets_69;                                     // 0x02A0(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
	class MovieSceneBindingOverrides*                  BindingOverrides_69;                                      // 0x02B0(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference)
	unsigned char                                      bReplicatePlayback_69 : 1;                                // 0x02B8(0x0001) (Edit, BlueprintVisible)
	unsigned char                                      UnknownData01[0x7];                                       // 0x02B9(0x0007) MISSED OFFSET
	class DaySequence*                                 MainSequence_69;                                          // 0x02C0(0x0008) (ZeroConstructor, Transient)
	bool                                               bRunDayCycle_69;                                          // 0x02C8(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData02[0x3];                                       // 0x02C9(0x0003) MISSED OFFSET
	struct FTimecode                                   DayLength_69;                                             // 0x02CC(0x0014) (Edit, ZeroConstructor, IsPlainOldData)
	struct FTimecode                                   TimePerCycle_69;                                          // 0x02E0(0x0014) (Edit, ZeroConstructor, IsPlainOldData)
	struct FTimecode                                   InitialTimeOfDay_69;                                      // 0x02F4(0x0014) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData03[0x50];                                      // 0x0308(0x0050) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class DaySequence.DaySequenceActor"));
		
		return ptr;
	}


	bool SetTimeOfDay(float InHours_69);
	void SetReplicatePlayback(bool ReplicatePlayback_69);
	void SetDaySequence(int Index_69, class DaySequence* InSequence_69);
	void SetBias(const struct FString& SequenceKey_69, int Bias_69);
	void RemoveDaySequence(int Index_69);
	void Play();
	void Pause();
	int NumDaySequences();
	void MuteSequence(const struct FString& SequenceKey_69, bool bState_69);
	bool IsPlaying();
	bool IsPaused();
	bool IsMuteSequence(const struct FString& SequenceKey_69);
	float GetTimePerCycle();
	float GetTimeOfDay();
	class DaySequencePlayer* GetSequencePlayer();
	float GetInitialTimeOfDay();
	class DaySequence* GetFirstDaySequence();
	class DaySequence* GetDaySequence(int Index_69);
	float GetDayLength();
	int GetBias(const struct FString& SequenceKey_69);
	int AddDaySequence(class DaySequence* InSequence_69);
};


// Class DaySequence.DaySequenceDirector
// 0x0010 (0x0038 - 0x0028)
class DaySequenceDirector : public Object_32759
{
public:
	class DaySequencePlayer*                           Player_69;                                                // 0x0028(0x0008) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
	int                                                SubSequenceID_69;                                         // 0x0030(0x0004) (ZeroConstructor, IsPlainOldData)
	int                                                MovieScenePlayerIndex_69;                                 // 0x0034(0x0004) (ZeroConstructor, IsPlainOldData)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class DaySequence.DaySequenceDirector"));
		
		return ptr;
	}


	void OnCreated();
	class MovieSceneSequence* GetSequence();
	struct FQualifiedFrameTime GetMasterSequenceTime();
	struct FQualifiedFrameTime GetCurrentTime();
	TArray<class Object_32759*> GetBoundObjects(const struct FMovieSceneObjectBindingID& ObjectBinding_69);
	class Object_32759* GetBoundObject(const struct FMovieSceneObjectBindingID& ObjectBinding_69);
	TArray<class Actor_32759*> GetBoundActors(const struct FMovieSceneObjectBindingID& ObjectBinding_69);
	class Actor_32759* GetBoundActor(const struct FMovieSceneObjectBindingID& ObjectBinding_69);
};


// Class DaySequence.DaySequencePlayer
// 0x0018 (0x04B8 - 0x04A0)
class DaySequencePlayer : public MovieSceneSequencePlayer
{
public:
	unsigned char                                      UnknownData00[0x18];                                      // 0x04A0(0x0018) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class DaySequence.DaySequencePlayer"));
		
		return ptr;
	}


	class DaySequencePlayer* STATIC_CreateDaySequencePlayer(class Object_32759* WorldContextObject_69, class DaySequence* InDaySequence_69, const struct FMovieSceneSequencePlaybackSettings& Settings_69, class DaySequenceActor** OutActor_69);
};


// Class DaySequence.DaySequenceProjectSettings
// 0x0030 (0x0060 - 0x0030)
class DaySequenceProjectSettings : public DeveloperSettings
{
public:
	bool                                               bDefaultLockEngineToDisplayRate_69;                       // 0x0030(0x0001) (Edit, ZeroConstructor, Config, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0031(0x0007) MISSED OFFSET
	struct FString                                     DefaultDisplayRate_69;                                    // 0x0038(0x0010) (Edit, ZeroConstructor, Config)
	struct FString                                     DefaultTickResolution_69;                                 // 0x0048(0x0010) (Edit, ZeroConstructor, Config)
	EUpdateClockSource                                 DefaultClockSource_69;                                    // 0x0058(0x0001) (Edit, ZeroConstructor, Config, IsPlainOldData)
	unsigned char                                      UnknownData01[0x7];                                       // 0x0059(0x0007) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class DaySequence.DaySequenceProjectSettings"));
		
		return ptr;
	}

};


// Class DaySequence.DaySequenceProvider
// 0x0010 (0x0298 - 0x0288)
class DaySequenceProvider : public Actor_32759
{
public:
	TArray<class DaySequence*>                         DaySequenceAssets_69;                                     // 0x0288(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class DaySequence.DaySequenceProvider"));
		
		return ptr;
	}

};


// Class DaySequence.DaySequenceSubsystem
// 0x0000 (0x0030 - 0x0030)
class DaySequenceSubsystem : public WorldSubsystem
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class DaySequence.DaySequenceSubsystem"));
		
		return ptr;
	}


	class DaySequenceActor* GetDaySequenceActor();
};


// Class DaySequence.DaySequenceTrack
// 0x0000 (0x00A8 - 0x00A8)
class DaySequenceTrack : public MovieSceneSubTrack
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class DaySequence.DaySequenceTrack"));
		
		return ptr;
	}

};


// Class DaySequence.EnvironmentLightingActor
// 0x0030 (0x02C8 - 0x0298)
class EnvironmentLightingActor : public DaySequenceProvider
{
public:
	class SkyAtmosphereComponent*                      SkyAtmosphereComponent_69;                                // 0x0298(0x0008) (Edit, BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, EditConst, InstancedReference)
	class SkyLightComponent*                           SkyLightComponent_69;                                     // 0x02A0(0x0008) (Edit, BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, EditConst, InstancedReference)
	class SceneComponent*                              SunRootComponent_69;                                      // 0x02A8(0x0008) (Edit, BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, EditConst, InstancedReference)
	class DirectionalLightComponent*                   SunComponent_69;                                          // 0x02B0(0x0008) (Edit, BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, EditConst, InstancedReference)
	class ExponentialHeightFogComponent*               ExponentialHeightFogComponent_69;                         // 0x02B8(0x0008) (Edit, BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, EditConst, InstancedReference)
	class VolumetricCloudComponent*                    VolumetricCloudComponent_69;                              // 0x02C0(0x0008) (Edit, BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, EditConst, InstancedReference)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class DaySequence.EnvironmentLightingActor"));
		
		return ptr;
	}

};


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

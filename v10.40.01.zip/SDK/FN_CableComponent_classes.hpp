#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Classes
//---------------------------------------------------------------------------

// Class CableComponent.CableActor
// 0x0008 (0x0290 - 0x0288)
class CableActor : public Actor_32759
{
public:
	class CableComponent*                              CableComponent_69;                                        // 0x0288(0x0008) (Edit, BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, EditConst, InstancedReference)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CableComponent.CableActor"));
		
		return ptr;
	}

};


// Class CableComponent.CableComponent
// 0x00B0 (0x0620 - 0x0570)
class CableComponent : public MeshComponent
{
public:
	struct FComponentReference                         AttachEndTo_69;                                           // 0x0570(0x0028) (Edit)
	struct FName                                       AttachEndToSocketName_69;                                 // 0x0598(0x0008) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x059C(0x0004) MISSED OFFSET
	struct FVector                                     EndLocation_69;                                           // 0x05A0(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              CableLength_69;                                           // 0x05B8(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                NumSegments_69;                                           // 0x05BC(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              SubstepTime_69;                                           // 0x05C0(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                SolverIterations_69;                                      // 0x05C4(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bEnableStiffness_69;                                      // 0x05C8(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bUseSubstepping_69;                                       // 0x05C9(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bSkipCableUpdateWhenNotVisible_69;                        // 0x05CA(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bSkipCableUpdateWhenNotOwnerRecentlyRendered_69;          // 0x05CB(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bEnableCollision_69;                                      // 0x05CC(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x3];                                       // 0x05CD(0x0003) MISSED OFFSET
	float                                              CollisionFriction_69;                                     // 0x05D0(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData02[0x4];                                       // 0x05D4(0x0004) MISSED OFFSET
	struct FVector                                     CableForce_69;                                            // 0x05D8(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              CableGravityScale_69;                                     // 0x05F0(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              CableWidth_69;                                            // 0x05F4(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                NumSides_69;                                              // 0x05F8(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              TileMaterial_69;                                          // 0x05FC(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData03[0x20];                                      // 0x0600(0x0020) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CableComponent.CableComponent"));
		
		return ptr;
	}


	void SetAttachEndToComponent(class SceneComponent* Component_69, const struct FName& SocketName_69);
	void SetAttachEndTo(class Actor_32759* Actor_69, const struct FName& ComponentProperty_69, const struct FName& SocketName_69);
	void GetCableParticleLocations(TArray<struct FVector>* Locations_69);
	class SceneComponent* GetAttachedComponent();
	class Actor_32759* GetAttachedActor();
};


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function ClamberingCodeRuntime.ClamberingComponent.UnregisterMutatorUpdatedDelegate
struct ClamberingComponent_UnregisterMutatorUpdatedDelegate_Params
{
};

// Function ClamberingCodeRuntime.ClamberingComponent.ShouldShowClamberIndicator
struct ClamberingComponent_ShouldShowClamberIndicator_Params
{
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function ClamberingCodeRuntime.ClamberingComponent.SetTutorialModeEnabled
struct ClamberingComponent_SetTutorialModeEnabled_Params
{
	bool                                               bEnabled_69;                                              // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function ClamberingCodeRuntime.ClamberingComponent.ServerStartClambering
struct ClamberingComponent_ServerStartClambering_Params
{
	struct FReplicatedClamberingTargetingData          InReplicatedTargetingData_69;                             // (ConstParm, Parm)
};

// Function ClamberingCodeRuntime.ClamberingComponent.RegisterMutatorUpdatedDelegate
struct ClamberingComponent_RegisterMutatorUpdatedDelegate_Params
{
	class Pawn*                                        AffectedPawn_69;                                          // (Parm, ZeroConstructor)
};

// Function ClamberingCodeRuntime.ClamberingComponent.OnRep_ReplicatedTargetingData
struct ClamberingComponent_OnRep_ReplicatedTargetingData_Params
{
};

// Function ClamberingCodeRuntime.ClamberingComponent.OnRep_ReplicatedClamberingState
struct ClamberingComponent_OnRep_ReplicatedClamberingState_Params
{
};

// Function ClamberingCodeRuntime.ClamberingComponent.OnPlayerStatePawnSet
struct ClamberingComponent_OnPlayerStatePawnSet_Params
{
	class PlayerState*                                 Player_69;                                                // (Parm, ZeroConstructor)
	class Pawn*                                        NewPawn_69;                                               // (Parm, ZeroConstructor)
	class Pawn*                                        OldPawn_69;                                               // (Parm, ZeroConstructor)
};

// Function ClamberingCodeRuntime.ClamberingComponent.OnMutatorUpdated
struct ClamberingComponent_OnMutatorUpdated_Params
{
};

// Function ClamberingCodeRuntime.ClamberingComponent.NetMulticast_ClamberingLedgeFailed
struct ClamberingComponent_NetMulticast_ClamberingLedgeFailed_Params
{
	EClamberingFailedReason                            FailedReason_69;                                          // (Parm, ZeroConstructor, IsPlainOldData)
	EClamberingState                                   FailedState_69;                                           // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function ClamberingCodeRuntime.ClamberingComponent.IsTutorialModeEnabled
struct ClamberingComponent_IsTutorialModeEnabled_Params
{
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function ClamberingCodeRuntime.ClamberingComponent.IsClamberingEnabled
struct ClamberingComponent_IsClamberingEnabled_Params
{
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function ClamberingCodeRuntime.ClamberingComponent.IsAutoClamberingEnabled
struct ClamberingComponent_IsAutoClamberingEnabled_Params
{
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function ClamberingCodeRuntime.ClamberingComponent.HandleTargetingDataValid
struct ClamberingComponent_HandleTargetingDataValid_Params
{
	struct FClamberingTargetingData                    TargetingData_69;                                         // (ConstParm, Parm, OutParm, ReferenceParm)
};

// Function ClamberingCodeRuntime.ClamberingComponent.HandleTargetingDataInvalid
struct ClamberingComponent_HandleTargetingDataInvalid_Params
{
};

// Function ClamberingCodeRuntime.ClamberingComponent.HandleTargetActorHealthChanged
struct ClamberingComponent_HandleTargetActorHealthChanged_Params
{
};

// Function ClamberingCodeRuntime.ClamberingComponent.HandleTargetActorDestroyed
struct ClamberingComponent_HandleTargetActorDestroyed_Params
{
	class Actor_32759*                                 Actor_69;                                                 // (Parm, ZeroConstructor)
};

// Function ClamberingCodeRuntime.ClamberingComponent.HandleOwnerMovementModeChanged
struct ClamberingComponent_HandleOwnerMovementModeChanged_Params
{
	class Character*                                   Character_69;                                             // (Parm, ZeroConstructor)
	TEnumAsByte<EMovementMode>                         PreviousMovementMode_69;                                  // (Parm, ZeroConstructor, IsPlainOldData)
	unsigned char                                      PreviousCustomMode_69;                                    // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function ClamberingCodeRuntime.ClamberingComponent.HandleOwnerJumpInput
struct ClamberingComponent_HandleOwnerJumpInput_Params
{
	bool                                               bPressed_69;                                              // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function ClamberingCodeRuntime.ClamberingComponent.HandleOwnerDied
struct ClamberingComponent_HandleOwnerDied_Params
{
	class FortPawn*                                    DeadPawn_69;                                              // (Parm, ZeroConstructor)
};

// Function ClamberingCodeRuntime.ClamberingComponent.HandleOwnerDBNO
struct ClamberingComponent_HandleOwnerDBNO_Params
{
};

// Function ClamberingCodeRuntime.ClamberingComponent.HandleOwnerASCInvalidated
struct ClamberingComponent_HandleOwnerASCInvalidated_Params
{
};

// Function ClamberingCodeRuntime.ClamberingComponent.HandleOwnerASCInitialized
struct ClamberingComponent_HandleOwnerASCInitialized_Params
{
	class FortAbilitySystemComponent*                  AbilitySystemComponent_69;                                // (Parm, ZeroConstructor, InstancedReference)
	class FortPlayerPawn*                              AffectedPawn_69;                                          // (Parm, ZeroConstructor)
};

// Function ClamberingCodeRuntime.ClamberingComponent.HandleClamberingTargetOutOfActivationRange
struct ClamberingComponent_HandleClamberingTargetOutOfActivationRange_Params
{
};

// Function ClamberingCodeRuntime.ClamberingComponent.HandleClamberingTargetInActivationRange
struct ClamberingComponent_HandleClamberingTargetInActivationRange_Params
{
};

// Function ClamberingCodeRuntime.ClamberingComponent.DrawDebugHUD
struct ClamberingComponent_DrawDebugHUD_Params
{
	class HUD_32759*                                   HUD_69;                                                   // (Parm, ZeroConstructor)
	class Canvas*                                      Canvas_69;                                                // (Parm, ZeroConstructor)
};

// Function ClamberingCodeRuntime.ClamberingComponent.BP_TutorialModeEnabled
struct ClamberingComponent_BP_TutorialModeEnabled_Params
{
};

// Function ClamberingCodeRuntime.ClamberingComponent.BP_TutorialModeDisabled
struct ClamberingComponent_BP_TutorialModeDisabled_Params
{
};

// Function ClamberingCodeRuntime.ClamberingComponent.BP_IsValidTargetActor
struct ClamberingComponent_BP_IsValidTargetActor_Params
{
	class Actor_32759*                                 TargetActor_69;                                           // (ConstParm, Parm, ZeroConstructor)
	bool                                               bIsValidTargetActor_69;                                   // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
};

// Function ClamberingCodeRuntime.ClamberingComponent.BP_HandleSynchedActionStarted
struct ClamberingComponent_BP_HandleSynchedActionStarted_Params
{
	struct FSynchedActionInfo                          SynchedActionInfo_69;                                     // (ConstParm, Parm, OutParm, ReferenceParm)
};

// Function ClamberingCodeRuntime.ClamberingComponent.BP_HandleClamberingStateChanged
struct ClamberingComponent_BP_HandleClamberingStateChanged_Params
{
	EClamberingState                                   OldClamberingState_69;                                    // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	EClamberingState                                   NewClamberingState_69;                                    // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function ClamberingCodeRuntime.ClamberingComponent.BP_CanStartTargeting
struct ClamberingComponent_BP_CanStartTargeting_Params
{
	bool                                               bCanStartTargeting_69;                                    // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
};

// Function ClamberingCodeRuntime.ClamberingComponent.BP_CanStartClambering
struct ClamberingComponent_BP_CanStartClambering_Params
{
	bool                                               bCanStartClambering_69;                                   // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
};

// Function ClamberingCodeRuntime.ClamberingLibrary.PerformClamberingTargeting
struct ClamberingLibrary_PerformClamberingTargeting_Params
{
	class Character*                                   Character_69;                                             // (ConstParm, Parm, ZeroConstructor)
	struct FClamberingTargetingData                    OutTargetingData_69;                                      // (Parm, OutParm)
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function AnnualRefundTokenUI.FortAnnualRefundTicket.OnUpdatePendingState
struct FortAnnualRefundTicket_OnUpdatePendingState_Params
{
	bool                                               bIsPending_69;                                            // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function AnnualRefundTokenUI.FortAnnualRefundTicket.OnUpdateAvailableState
struct FortAnnualRefundTicket_OnUpdateAvailableState_Params
{
	bool                                               bIsAvailable_69;                                          // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function AnnualRefundTokenUI.FortAnnualRefundTicket.OnPlayLockingAnimation
struct FortAnnualRefundTicket_OnPlayLockingAnimation_Params
{
};

// Function AnnualRefundTokenUI.FortPurchaseHistoryEntry.UpdateItemList
struct FortPurchaseHistoryEntry_UpdateItemList_Params
{
	TArray<class FortCosmeticItemCard*>                ItemCards_69;                                             // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
};

// Function AnnualRefundTokenUI.FortPurchaseHistoryEntry.SetupItemCard
struct FortPurchaseHistoryEntry_SetupItemCard_Params
{
	class FortCosmeticItemCard*                        ItemCard_69;                                              // (ConstParm, Parm, ZeroConstructor, InstancedReference)
	class FortItem*                                    Item_69;                                                  // (ConstParm, Parm, ZeroConstructor)
};

// Function AnnualRefundTokenUI.FortPurchaseHistoryEntry.SetPurchaseText
struct FortPurchaseHistoryEntry_SetPurchaseText_Params
{
	struct FText                                       PurchaseDateText_69;                                      // (ConstParm, Parm, OutParm, ReferenceParm)
	struct FText                                       RefundDateText_69;                                        // (ConstParm, Parm, OutParm, ReferenceParm)
	bool                                               bHasBeenRefunded_69;                                      // (Parm, ZeroConstructor, IsPlainOldData)
	EFortPurchaseHistoryRefundType                     RefundType_69;                                            // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function AnnualRefundTokenUI.FortPurchaseHistoryEntry.OnSetHistory
struct FortPurchaseHistoryEntry_OnSetHistory_Params
{
	bool                                               bHasBeenRefunded_69;                                      // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bIsTokenlessRefund_69;                                    // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bPlayerHasTokens_69;                                      // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bNonRefundable_69;                                        // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function AnnualRefundTokenUI.FortPurchaseHistoryScreen.OnPopulateView
struct FortPurchaseHistoryScreen_OnPopulateView_Params
{
};

// Function AnnualRefundTokenUI.FortPurchaseHistoryScreen.OnNoPurchasesAvailable
struct FortPurchaseHistoryScreen_OnNoPurchasesAvailable_Params
{
};

// Function AnnualRefundTokenUI.FortPurchaseHistoryScreen.OnEndRefundSubmission
struct FortPurchaseHistoryScreen_OnEndRefundSubmission_Params
{
};

// Function AnnualRefundTokenUI.FortPurchaseHistoryScreen.OnBeginRefundSubmission
struct FortPurchaseHistoryScreen_OnBeginRefundSubmission_Params
{
};

// Function AnnualRefundTokenUI.FortPurchaseHistoryScreen.BP_IsShowingPurchases
struct FortPurchaseHistoryScreen_BP_IsShowingPurchases_Params
{
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function AnnualRefundTokenUI.FortRefundConfirmation.BP_UpdateRefundType
struct FortRefundConfirmation_BP_UpdateRefundType_Params
{
	EFortPurchaseHistoryRefundType                     RefundType_69;                                            // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function AnnualRefundTokenUI.FortRefundConfirmation.BP_UpdateItemsList
struct FortRefundConfirmation_BP_UpdateItemsList_Params
{
	TArray<class FortItemDefinition*>                  SelectedItemDefs_69;                                      // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	int                                                TotalMtxPaid_69;                                          // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

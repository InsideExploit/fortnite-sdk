#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Classes
//---------------------------------------------------------------------------

// Class AudioShapes.AudioShapeComponent
// 0x0098 (0x0140 - 0x00A8)
class AudioShapeComponent : public AudioGameplayComponent
{
public:
	unsigned char                                      UnknownData00[0x8];                                       // 0x00A8(0x0008) MISSED OFFSET
	float                                              MaxDistanceOffset_69;                                     // 0x00B0(0x0004) (Edit, ZeroConstructor, Config, IsPlainOldData)
	float                                              SmoothingDistance_69;                                     // 0x00B4(0x0004) (Edit, ZeroConstructor, Config, IsPlainOldData)
	float                                              FadeTime_69;                                              // 0x00B8(0x0004) (Edit, ZeroConstructor, Config, IsPlainOldData)
	unsigned char                                      UnknownData01[0x4];                                       // 0x00BC(0x0004) MISSED OFFSET
	unsigned char                                      UnknownData02[0x10];                                      // 0x00BC(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty AudioShapes.AudioShapeComponent.OnAudibleStateChanged_69
	TMap<struct FName, class AudioComponent*>          AudioComponents_69;                                       // 0x00D0(0x0050) (ExportObject, Transient)
	TArray<class PlayerController*>                    LocalControllers_69;                                      // 0x0120(0x0010) (ZeroConstructor, Transient)
	unsigned char                                      UnknownData03[0x10];                                      // 0x0130(0x0010) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AudioShapes.AudioShapeComponent"));
		
		return ptr;
	}


	void UpdateAudioShape(TArray<class PlayerController*> InLocalControllers_69);
};


// Class AudioShapes.AudioShapePrimitiveComponent
// 0x0088 (0x01C8 - 0x0140)
class AudioShapePrimitiveComponent : public AudioShapeComponent
{
public:
	class SoundBase*                                   SoundOnEdge_69;                                           // 0x0140(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
	class SoundBase*                                   SoundOnInside_69;                                         // 0x0148(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
	unsigned char                                      UnknownData00[0x10];                                      // 0x0150(0x0010) UNKNOWN PROPERTY: MulticastInlineDelegateProperty AudioShapes.AudioShapePrimitiveComponent.OnInsideStateChanged_69
	bool                                               bUseOwningActorTransform_69;                              // 0x0160(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bAutoRefreshShape_69;                                     // 0x0161(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x6];                                       // 0x0162(0x0006) MISSED OFFSET
	struct FVector                                     ActorTransformScale_69;                                   // 0x0168(0x0018) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData02[0x48];                                      // 0x0180(0x0048) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AudioShapes.AudioShapePrimitiveComponent"));
		
		return ptr;
	}


	bool GetIsPlayerInside();
	class AudioComponent* GetInsideAudioComponent();
	class AudioComponent* GetEdgeAudioComponent();
};


// Class AudioShapes.AudioShapeBoxComponent
// 0x0068 (0x0230 - 0x01C8)
class AudioShapeBoxComponent : public AudioShapePrimitiveComponent
{
public:
	unsigned char                                      UnknownData00[0x8];                                       // 0x01C8(0x0008) MISSED OFFSET
	struct FCoreUObject_FTransform                     BoxTransform_69;                                          // 0x01D0(0x0060) (Edit, BlueprintVisible, BlueprintReadOnly, IsPlainOldData)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AudioShapes.AudioShapeBoxComponent"));
		
		return ptr;
	}


	void SetBoxTransform(const struct FCoreUObject_FTransform& InTransform_69);
};


// Class AudioShapes.AudioShapeCylinderComponent
// 0x0008 (0x01D0 - 0x01C8)
class AudioShapeCylinderComponent : public AudioShapePrimitiveComponent
{
public:
	float                                              HalfHeight_69;                                            // 0x01C8(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              Radius_69;                                                // 0x01CC(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AudioShapes.AudioShapeCylinderComponent"));
		
		return ptr;
	}


	void SetRadius(float InRadius_69);
	void SetHalfHeight(float InHalfHeight_69);
};


// Class AudioShapes.AudioShapeLineComponent
// 0x0030 (0x01F8 - 0x01C8)
class AudioShapeLineComponent : public AudioShapePrimitiveComponent
{
public:
	struct FVector                                     StartPoint_69;                                            // 0x01C8(0x0018) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	struct FVector                                     EndPoint_69;                                              // 0x01E0(0x0018) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AudioShapes.AudioShapeLineComponent"));
		
		return ptr;
	}


	void SetStartPoint(const struct FVector& InStartPoint_69);
	void SetEndPoint(const struct FVector& InEndPoint_69);
};


// Class AudioShapes.AudioShapeLineListComponent
// 0x0018 (0x01E0 - 0x01C8)
class AudioShapeLineListComponent : public AudioShapePrimitiveComponent
{
public:
	TArray<struct FVector>                             PointList_69;                                             // 0x01C8(0x0010) (Edit, ZeroConstructor, DisableEditOnInstance)
	bool                                               bClosedLoop_69;                                           // 0x01D8(0x0001) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x01D9(0x0007) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AudioShapes.AudioShapeLineListComponent"));
		
		return ptr;
	}


	bool UpdatePoint(int InIndex_69, const struct FVector& InPoint_69);
	bool RemovePoint(int InIndex_69);
	void GetPoints(TArray<struct FVector>* OutPoints_69);
	int AddPoint(const struct FVector& InPoint_69);
};


// Class AudioShapes.AudioShapeSphereComponent
// 0x0008 (0x01D0 - 0x01C8)
class AudioShapeSphereComponent : public AudioShapePrimitiveComponent
{
public:
	float                                              Radius_69;                                                // 0x01C8(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x01CC(0x0004) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AudioShapes.AudioShapeSphereComponent"));
		
		return ptr;
	}


	void SetRadius(float InRadius_69);
};


// Class AudioShapes.AudioShapeSubsystem
// 0x0058 (0x0088 - 0x0030)
class AudioShapeSubsystem : public WorldSubsystem
{
public:
	unsigned char                                      UnknownData00[0x28];                                      // 0x0030(0x0028) MISSED OFFSET
	TArray<class AudioShapeComponent*>                 AudioShapes_69;                                           // 0x0058(0x0010) (ExportObject, ZeroConstructor, Transient)
	TArray<class PlayerController*>                    LocalControllers_69;                                      // 0x0068(0x0010) (ZeroConstructor, Transient)
	unsigned char                                      UnknownData01[0x10];                                      // 0x0078(0x0010) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class AudioShapes.AudioShapeSubsystem"));
		
		return ptr;
	}

};


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

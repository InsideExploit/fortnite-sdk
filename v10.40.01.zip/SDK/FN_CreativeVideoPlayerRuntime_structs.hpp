#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Enums
//---------------------------------------------------------------------------

// Enum CreativeVideoPlayerRuntime.ECreativeVideoPlayerFullscreenEffects
enum class ECreativeVideoPlayerFullscreenEffects : uint8_t
{
	None                           = 0,
	NoCollisionOnly                = 1,
	NoDamageOnly                   = 2,
	NoCollisionAndNoDamage         = 3,
	ECreativeVideoPlayerFullscreenEffects_MAX = 4
};



//---------------------------------------------------------------------------
//Script Structs
//---------------------------------------------------------------------------

// ScriptStruct CreativeVideoPlayerRuntime.CreativeVideoPlayerFullscreenOptions
// 0x0002
struct FCreativeVideoPlayerFullscreenOptions
{
	ECreativeVideoPlayerFullscreenEffects              GameplayEffects_69;                                       // 0x0000(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	bool                                               bPromptFirst_69;                                          // 0x0001(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

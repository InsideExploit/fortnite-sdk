// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Functions
//---------------------------------------------------------------------------

// Function CaretakerRuntime.FortAthenaCaretakerAIController.OnMovementModeChanged
// (Final, Native, Public)
// Parameters:
// class Character*               CharacterOwner_69              (Parm, ZeroConstructor)
// TEnumAsByte<EMovementMode>     PreviousMovementMode_69        (Parm, ZeroConstructor, IsPlainOldData)
// unsigned char                  PreviousCustomMode_69          (Parm, ZeroConstructor, IsPlainOldData)

void FortAthenaCaretakerAIController::OnMovementModeChanged(class Character* CharacterOwner_69, TEnumAsByte<EMovementMode> PreviousMovementMode_69, unsigned char PreviousCustomMode_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CaretakerRuntime.FortAthenaCaretakerAIController.OnMovementModeChanged"));

	FortAthenaCaretakerAIController_OnMovementModeChanged_Params params;
	params.CharacterOwner_69 = CharacterOwner_69;
	params.PreviousMovementMode_69 = PreviousMovementMode_69;
	params.PreviousCustomMode_69 = PreviousCustomMode_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CaretakerRuntime.FortAthenaCaretakerAIController.DebugUpdate
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// float                          UpdateInterval_69              (Parm, ZeroConstructor, IsPlainOldData)

void FortAthenaCaretakerAIController::DebugUpdate(float UpdateInterval_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CaretakerRuntime.FortAthenaCaretakerAIController.DebugUpdate"));

	FortAthenaCaretakerAIController_DebugUpdate_Params params;
	params.UpdateInterval_69 = UpdateInterval_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CaretakerRuntime.FortAIAnimInstance_Caretaker.SetDelayedMaterialParameters
// (Final, Native, Protected, BlueprintCallable)

void FortAIAnimInstance_Caretaker::SetDelayedMaterialParameters()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CaretakerRuntime.FortAIAnimInstance_Caretaker.SetDelayedMaterialParameters"));

	FortAIAnimInstance_Caretaker_SetDelayedMaterialParameters_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CaretakerRuntime.FortAIAnimInstance_Caretaker.GetWorldStriderComponent
// (Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// class FortAnimWorldStriderComponent* ReturnValue_69                 (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)

class FortAnimWorldStriderComponent* FortAIAnimInstance_Caretaker::GetWorldStriderComponent()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CaretakerRuntime.FortAIAnimInstance_Caretaker.GetWorldStriderComponent"));

	FortAIAnimInstance_Caretaker_GetWorldStriderComponent_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CaretakerRuntime.FortAIAnimInstance_Caretaker.GetWalkSpeedWarpingValue
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// float                          ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

float FortAIAnimInstance_Caretaker::GetWalkSpeedWarpingValue()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CaretakerRuntime.FortAIAnimInstance_Caretaker.GetWalkSpeedWarpingValue"));

	FortAIAnimInstance_Caretaker_GetWalkSpeedWarpingValue_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CaretakerRuntime.FortAIAnimInstance_Caretaker.GetWalkPlayRateValue
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// float                          ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

float FortAIAnimInstance_Caretaker::GetWalkPlayRateValue()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CaretakerRuntime.FortAIAnimInstance_Caretaker.GetWalkPlayRateValue"));

	FortAIAnimInstance_Caretaker_GetWalkPlayRateValue_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function CaretakerRuntime.FortAIAnimInstance_Caretaker.GetStartAnimPosition
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// float                          ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

float FortAIAnimInstance_Caretaker::GetStartAnimPosition()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CaretakerRuntime.FortAIAnimInstance_Caretaker.GetStartAnimPosition"));

	FortAIAnimInstance_Caretaker_GetStartAnimPosition_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Functions
//---------------------------------------------------------------------------

// Function ContextualAnimation.ContextualAnimActorInterface.GetMesh
// (Native, Event, Public, BlueprintCallable, BlueprintEvent, BlueprintPure, Const)
// Parameters:
// class SkeletalMeshComponent*   ReturnValue_69                 (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)

class SkeletalMeshComponent* ContextualAnimActorInterface::GetMesh()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ContextualAnimation.ContextualAnimActorInterface.GetMesh"));

	ContextualAnimActorInterface_GetMesh_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ContextualAnimation.ContextualAnimManager.TryStopSceneWithActor
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// class Actor_32759*             Actor_69                       (Parm, ZeroConstructor)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool ContextualAnimManager::TryStopSceneWithActor(class Actor_32759* Actor_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ContextualAnimation.ContextualAnimManager.TryStopSceneWithActor"));

	ContextualAnimManager_TryStopSceneWithActor_Params params;
	params.Actor_69 = Actor_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ContextualAnimation.ContextualAnimManager.OnSceneInstanceEnded
// (Final, Native, Protected)
// Parameters:
// class ContextualAnimSceneInstance* SceneInstance_69               (Parm, ZeroConstructor)

void ContextualAnimManager::OnSceneInstanceEnded(class ContextualAnimSceneInstance* SceneInstance_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ContextualAnimation.ContextualAnimManager.OnSceneInstanceEnded"));

	ContextualAnimManager_OnSceneInstanceEnded_Params params;
	params.SceneInstance_69 = SceneInstance_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ContextualAnimation.ContextualAnimManager.IsActorInAnyScene
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// class Actor_32759*             Actor_69                       (Parm, ZeroConstructor)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool ContextualAnimManager::IsActorInAnyScene(class Actor_32759* Actor_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ContextualAnimation.ContextualAnimManager.IsActorInAnyScene"));

	ContextualAnimManager_IsActorInAnyScene_Params params;
	params.Actor_69 = Actor_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ContextualAnimation.ContextualAnimManager.GetSceneWithActor
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// class Actor_32759*             Actor_69                       (Parm, ZeroConstructor)
// class ContextualAnimSceneInstance* ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

class ContextualAnimSceneInstance* ContextualAnimManager::GetSceneWithActor(class Actor_32759* Actor_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ContextualAnimation.ContextualAnimManager.GetSceneWithActor"));

	ContextualAnimManager_GetSceneWithActor_Params params;
	params.Actor_69 = Actor_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ContextualAnimation.ContextualAnimManager.GetContextualAnimManager
// (Final, Native, Static, Public, BlueprintCallable, BlueprintPure)
// Parameters:
// class Object_32759*            WorldContextObject_69          (Parm, ZeroConstructor)
// class ContextualAnimManager*   ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

class ContextualAnimManager* ContextualAnimManager::STATIC_GetContextualAnimManager(class Object_32759* WorldContextObject_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ContextualAnimation.ContextualAnimManager.GetContextualAnimManager"));

	ContextualAnimManager_GetContextualAnimManager_Params params;
	params.WorldContextObject_69 = WorldContextObject_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ContextualAnimation.ContextualAnimManager.BP_TryStartScene
// (Final, Native, Public, HasOutParms, BlueprintCallable)
// Parameters:
// class ContextualAnimSceneAsset* SceneAsset_69                  (ConstParm, Parm, ZeroConstructor)
// struct FContextualAnimStartSceneParams Params_69                      (ConstParm, Parm, OutParm, ReferenceParm)
// class ContextualAnimSceneInstance* ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

class ContextualAnimSceneInstance* ContextualAnimManager::BP_TryStartScene(class ContextualAnimSceneAsset* SceneAsset_69, const struct FContextualAnimStartSceneParams& Params_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ContextualAnimation.ContextualAnimManager.BP_TryStartScene"));

	ContextualAnimManager_BP_TryStartScene_Params params;
	params.SceneAsset_69 = SceneAsset_69;
	params.Params_69 = Params_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ContextualAnimation.ContextualAnimSceneActorComponent.OnTickPose
// (Final, Native, Protected)
// Parameters:
// class SkinnedMeshComponent*    SkinnedMeshComponent_69        (Parm, ZeroConstructor, InstancedReference)
// float                          DeltaTime_69                   (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bNeedsValidRootMotion_69       (Parm, ZeroConstructor, IsPlainOldData)

void ContextualAnimSceneActorComponent::OnTickPose(class SkinnedMeshComponent* SkinnedMeshComponent_69, float DeltaTime_69, bool bNeedsValidRootMotion_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ContextualAnimation.ContextualAnimSceneActorComponent.OnTickPose"));

	ContextualAnimSceneActorComponent_OnTickPose_Params params;
	params.SkinnedMeshComponent_69 = SkinnedMeshComponent_69;
	params.DeltaTime_69 = DeltaTime_69;
	params.bNeedsValidRootMotion_69 = bNeedsValidRootMotion_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ContextualAnimation.ContextualAnimSceneActorComponent.GetIKTargets
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// TArray<struct FContextualAnimIKTarget> ReturnValue_69                 (ConstParm, Parm, OutParm, ZeroConstructor, ReturnParm, ReferenceParm)

TArray<struct FContextualAnimIKTarget> ContextualAnimSceneActorComponent::GetIKTargets()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ContextualAnimation.ContextualAnimSceneActorComponent.GetIKTargets"));

	ContextualAnimSceneActorComponent_GetIKTargets_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ContextualAnimation.ContextualAnimSceneActorComponent.GetIKTargetByGoalName
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FName                   GoalName_69                    (Parm, ZeroConstructor, IsPlainOldData)
// struct FContextualAnimIKTarget ReturnValue_69                 (ConstParm, Parm, OutParm, ReturnParm, ReferenceParm)

struct FContextualAnimIKTarget ContextualAnimSceneActorComponent::GetIKTargetByGoalName(const struct FName& GoalName_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ContextualAnimation.ContextualAnimSceneActorComponent.GetIKTargetByGoalName"));

	ContextualAnimSceneActorComponent_GetIKTargetByGoalName_Params params;
	params.GoalName_69 = GoalName_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ContextualAnimation.ContextualAnimSceneAsset.Query
// (Final, Native, Public, HasOutParms, HasDefaults, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FName                   Role_69                        (Parm, ZeroConstructor, IsPlainOldData)
// struct FContextualAnimQueryResult OutResult_69                   (Parm, OutParm)
// struct FContextualAnimQueryParams QueryParams_69                 (ConstParm, Parm, OutParm, ReferenceParm)
// struct FCoreUObject_FTransform ToWorldTransform_69            (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool ContextualAnimSceneAsset::Query(const struct FName& Role_69, const struct FContextualAnimQueryParams& QueryParams_69, const struct FCoreUObject_FTransform& ToWorldTransform_69, struct FContextualAnimQueryResult* OutResult_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ContextualAnimation.ContextualAnimSceneAsset.Query"));

	ContextualAnimSceneAsset_Query_Params params;
	params.Role_69 = Role_69;
	params.QueryParams_69 = QueryParams_69;
	params.ToWorldTransform_69 = ToWorldTransform_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (OutResult_69 != nullptr)
		*OutResult_69 = params.OutResult_69;

	return params.ReturnValue_69;
}


// Function ContextualAnimation.ContextualAnimSceneAsset.GetRoles
// (Final, Native, Public, Const)
// Parameters:
// TArray<struct FName>           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

TArray<struct FName> ContextualAnimSceneAsset::GetRoles()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ContextualAnimation.ContextualAnimSceneAsset.GetRoles"));

	ContextualAnimSceneAsset_GetRoles_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ContextualAnimation.ContextualAnimSceneAsset.BP_GetStartAndEndTimeForWarpSection
// (Final, Native, Public, HasOutParms, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// int                            SectionIdx_69                  (Parm, ZeroConstructor, IsPlainOldData)
// int                            AnimSetIdx_69                  (Parm, ZeroConstructor, IsPlainOldData)
// struct FName                   Role_69                        (Parm, ZeroConstructor, IsPlainOldData)
// struct FName                   WarpSectionName_69             (Parm, ZeroConstructor, IsPlainOldData)
// float                          OutStartTime_69                (Parm, OutParm, ZeroConstructor, IsPlainOldData)
// float                          OutEndTime_69                  (Parm, OutParm, ZeroConstructor, IsPlainOldData)

void ContextualAnimSceneAsset::BP_GetStartAndEndTimeForWarpSection(int SectionIdx_69, int AnimSetIdx_69, const struct FName& Role_69, const struct FName& WarpSectionName_69, float* OutStartTime_69, float* OutEndTime_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ContextualAnimation.ContextualAnimSceneAsset.BP_GetStartAndEndTimeForWarpSection"));

	ContextualAnimSceneAsset_BP_GetStartAndEndTimeForWarpSection_Params params;
	params.SectionIdx_69 = SectionIdx_69;
	params.AnimSetIdx_69 = AnimSetIdx_69;
	params.Role_69 = Role_69;
	params.WarpSectionName_69 = WarpSectionName_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (OutStartTime_69 != nullptr)
		*OutStartTime_69 = params.OutStartTime_69;
	if (OutEndTime_69 != nullptr)
		*OutEndTime_69 = params.OutEndTime_69;
}


// Function ContextualAnimation.ContextualAnimSceneAsset.BP_GetIKTargetTransformForRoleAtTime
// (Final, Native, Public, HasDefaults, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// int                            SectionIdx_69                  (Parm, ZeroConstructor, IsPlainOldData)
// int                            AnimSetIdx_69                  (Parm, ZeroConstructor, IsPlainOldData)
// struct FName                   Role_69                        (Parm, ZeroConstructor, IsPlainOldData)
// struct FName                   TrackName_69                   (Parm, ZeroConstructor, IsPlainOldData)
// float                          Time_69                        (Parm, ZeroConstructor, IsPlainOldData)
// struct FCoreUObject_FTransform ReturnValue_69                 (Parm, OutParm, ReturnParm, IsPlainOldData)

struct FCoreUObject_FTransform ContextualAnimSceneAsset::BP_GetIKTargetTransformForRoleAtTime(int SectionIdx_69, int AnimSetIdx_69, const struct FName& Role_69, const struct FName& TrackName_69, float Time_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ContextualAnimation.ContextualAnimSceneAsset.BP_GetIKTargetTransformForRoleAtTime"));

	ContextualAnimSceneAsset_BP_GetIKTargetTransformForRoleAtTime_Params params;
	params.SectionIdx_69 = SectionIdx_69;
	params.AnimSetIdx_69 = AnimSetIdx_69;
	params.Role_69 = Role_69;
	params.TrackName_69 = TrackName_69;
	params.Time_69 = Time_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ContextualAnimation.ContextualAnimSceneAsset.BP_GetAlignmentTransformForRoleRelativeToPivot
// (Final, Native, Public, HasDefaults, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// int                            SectionIdx_69                  (Parm, ZeroConstructor, IsPlainOldData)
// int                            AnimSetIdx_69                  (Parm, ZeroConstructor, IsPlainOldData)
// struct FName                   Role_69                        (Parm, ZeroConstructor, IsPlainOldData)
// float                          Time_69                        (Parm, ZeroConstructor, IsPlainOldData)
// struct FCoreUObject_FTransform ReturnValue_69                 (Parm, OutParm, ReturnParm, IsPlainOldData)

struct FCoreUObject_FTransform ContextualAnimSceneAsset::BP_GetAlignmentTransformForRoleRelativeToPivot(int SectionIdx_69, int AnimSetIdx_69, const struct FName& Role_69, float Time_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ContextualAnimation.ContextualAnimSceneAsset.BP_GetAlignmentTransformForRoleRelativeToPivot"));

	ContextualAnimSceneAsset_BP_GetAlignmentTransformForRoleRelativeToPivot_Params params;
	params.SectionIdx_69 = SectionIdx_69;
	params.AnimSetIdx_69 = AnimSetIdx_69;
	params.Role_69 = Role_69;
	params.Time_69 = Time_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ContextualAnimation.ContextualAnimSceneAsset.BP_FindAnimSetIndexByAnimation
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// int                            SectionIdx_69                  (Parm, ZeroConstructor, IsPlainOldData)
// class AnimSequenceBase*        Animation_69                   (ConstParm, Parm, ZeroConstructor)
// int                            ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int ContextualAnimSceneAsset::BP_FindAnimSetIndexByAnimation(int SectionIdx_69, class AnimSequenceBase* Animation_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ContextualAnimation.ContextualAnimSceneAsset.BP_FindAnimSetIndexByAnimation"));

	ContextualAnimSceneAsset_BP_FindAnimSetIndexByAnimation_Params params;
	params.SectionIdx_69 = SectionIdx_69;
	params.Animation_69 = Animation_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ContextualAnimation.ContextualAnimSceneAsset.BP_FindAnimationForRole
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// int                            SectionIdx_69                  (Parm, ZeroConstructor, IsPlainOldData)
// int                            AnimSetIdx_69                  (Parm, ZeroConstructor, IsPlainOldData)
// struct FName                   Role_69                        (Parm, ZeroConstructor, IsPlainOldData)
// class AnimSequenceBase*        ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

class AnimSequenceBase* ContextualAnimSceneAsset::BP_FindAnimationForRole(int SectionIdx_69, int AnimSetIdx_69, const struct FName& Role_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ContextualAnimation.ContextualAnimSceneAsset.BP_FindAnimationForRole"));

	ContextualAnimSceneAsset_BP_FindAnimationForRole_Params params;
	params.SectionIdx_69 = SectionIdx_69;
	params.AnimSetIdx_69 = AnimSetIdx_69;
	params.Role_69 = Role_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ContextualAnimation.ContextualAnimSceneInstance.OnNotifyEndReceived
// (Final, Native, Protected, HasOutParms)
// Parameters:
// struct FName                   NotifyName_69                  (Parm, ZeroConstructor, IsPlainOldData)
// struct FBranchingPointNotifyPayload BranchingPointNotifyPayload_69 (ConstParm, Parm, OutParm, ReferenceParm)

void ContextualAnimSceneInstance::OnNotifyEndReceived(const struct FName& NotifyName_69, const struct FBranchingPointNotifyPayload& BranchingPointNotifyPayload_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ContextualAnimation.ContextualAnimSceneInstance.OnNotifyEndReceived"));

	ContextualAnimSceneInstance_OnNotifyEndReceived_Params params;
	params.NotifyName_69 = NotifyName_69;
	params.BranchingPointNotifyPayload_69 = BranchingPointNotifyPayload_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ContextualAnimation.ContextualAnimSceneInstance.OnNotifyBeginReceived
// (Final, Native, Protected, HasOutParms)
// Parameters:
// struct FName                   NotifyName_69                  (Parm, ZeroConstructor, IsPlainOldData)
// struct FBranchingPointNotifyPayload BranchingPointNotifyPayload_69 (ConstParm, Parm, OutParm, ReferenceParm)

void ContextualAnimSceneInstance::OnNotifyBeginReceived(const struct FName& NotifyName_69, const struct FBranchingPointNotifyPayload& BranchingPointNotifyPayload_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ContextualAnimation.ContextualAnimSceneInstance.OnNotifyBeginReceived"));

	ContextualAnimSceneInstance_OnNotifyBeginReceived_Params params;
	params.NotifyName_69 = NotifyName_69;
	params.BranchingPointNotifyPayload_69 = BranchingPointNotifyPayload_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ContextualAnimation.ContextualAnimSceneInstance.OnMontageBlendingOut
// (Final, Native, Protected)
// Parameters:
// class AnimMontage*             Montage_69                     (Parm, ZeroConstructor)
// bool                           bInterrupted_69                (Parm, ZeroConstructor, IsPlainOldData)

void ContextualAnimSceneInstance::OnMontageBlendingOut(class AnimMontage* Montage_69, bool bInterrupted_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ContextualAnimation.ContextualAnimSceneInstance.OnMontageBlendingOut"));

	ContextualAnimSceneInstance_OnMontageBlendingOut_Params params;
	params.Montage_69 = Montage_69;
	params.bInterrupted_69 = bInterrupted_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ContextualAnimation.ContextualAnimSceneInstance.GetActorByRole
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FName                   Role_69                        (Parm, ZeroConstructor, IsPlainOldData)
// class Actor_32759*             ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

class Actor_32759* ContextualAnimSceneInstance::GetActorByRole(const struct FName& Role_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ContextualAnimation.ContextualAnimSceneInstance.GetActorByRole"));

	ContextualAnimSceneInstance_GetActorByRole_Params params;
	params.Role_69 = Role_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ContextualAnimation.ContextualAnimSelectionCriterion_Blueprint.GetSceneAsset
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// class ContextualAnimSceneAsset* ReturnValue_69                 (ConstParm, Parm, OutParm, ZeroConstructor, ReturnParm)

class ContextualAnimSceneAsset* ContextualAnimSelectionCriterion_Blueprint::GetSceneAsset()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ContextualAnimation.ContextualAnimSelectionCriterion_Blueprint.GetSceneAsset"));

	ContextualAnimSelectionCriterion_Blueprint_GetSceneAsset_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ContextualAnimation.ContextualAnimSelectionCriterion_Blueprint.BP_DoesQuerierPassCondition
// (Event, Public, HasOutParms, BlueprintEvent, Const)
// Parameters:
// struct FContextualAnimSceneBindingContext Primary_69                     (ConstParm, Parm, OutParm, ReferenceParm)
// struct FContextualAnimSceneBindingContext Querier_69                     (ConstParm, Parm, OutParm, ReferenceParm)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool ContextualAnimSelectionCriterion_Blueprint::BP_DoesQuerierPassCondition(const struct FContextualAnimSceneBindingContext& Primary_69, const struct FContextualAnimSceneBindingContext& Querier_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ContextualAnimation.ContextualAnimSelectionCriterion_Blueprint.BP_DoesQuerierPassCondition"));

	ContextualAnimSelectionCriterion_Blueprint_BP_DoesQuerierPassCondition_Params params;
	params.Primary_69 = Primary_69;
	params.Querier_69 = Querier_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ContextualAnimation.ContextualAnimTransition.CanEnterTransition
// (Event, Public, HasOutParms, BlueprintEvent, Const)
// Parameters:
// class ContextualAnimSceneInstance* SceneInstance_69               (ConstParm, Parm, ZeroConstructor)
// struct FName                   FromSection_69                 (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
// struct FName                   ToSection_69                   (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool ContextualAnimTransition::CanEnterTransition(class ContextualAnimSceneInstance* SceneInstance_69, const struct FName& FromSection_69, const struct FName& ToSection_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ContextualAnimation.ContextualAnimTransition.CanEnterTransition"));

	ContextualAnimTransition_CanEnterTransition_Params params;
	params.SceneInstance_69 = SceneInstance_69;
	params.FromSection_69 = FromSection_69;
	params.ToSection_69 = ToSection_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ContextualAnimation.ContextualAnimUtilities.BP_SceneBindings_GetSectionAndAnimSetIndices
// (Final, Native, Static, Public, HasOutParms, BlueprintCallable, BlueprintPure)
// Parameters:
// struct FContextualAnimSceneBindings Bindings_69                    (ConstParm, Parm, OutParm, ReferenceParm)
// int                            SectionIdx_69                  (Parm, OutParm, ZeroConstructor, IsPlainOldData)
// int                            AnimSetIdx_69                  (Parm, OutParm, ZeroConstructor, IsPlainOldData)

void ContextualAnimUtilities::STATIC_BP_SceneBindings_GetSectionAndAnimSetIndices(const struct FContextualAnimSceneBindings& Bindings_69, int* SectionIdx_69, int* AnimSetIdx_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ContextualAnimation.ContextualAnimUtilities.BP_SceneBindings_GetSectionAndAnimSetIndices"));

	ContextualAnimUtilities_BP_SceneBindings_GetSectionAndAnimSetIndices_Params params;
	params.Bindings_69 = Bindings_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (SectionIdx_69 != nullptr)
		*SectionIdx_69 = params.SectionIdx_69;
	if (AnimSetIdx_69 != nullptr)
		*AnimSetIdx_69 = params.AnimSetIdx_69;
}


// Function ContextualAnimation.ContextualAnimUtilities.BP_SceneBindings_GetSceneAsset
// (Final, Native, Static, Public, HasOutParms, BlueprintCallable, BlueprintPure)
// Parameters:
// struct FContextualAnimSceneBindings Bindings_69                    (ConstParm, Parm, OutParm, ReferenceParm)
// class ContextualAnimSceneAsset* ReturnValue_69                 (ConstParm, Parm, OutParm, ZeroConstructor, ReturnParm)

class ContextualAnimSceneAsset* ContextualAnimUtilities::STATIC_BP_SceneBindings_GetSceneAsset(const struct FContextualAnimSceneBindings& Bindings_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ContextualAnimation.ContextualAnimUtilities.BP_SceneBindings_GetSceneAsset"));

	ContextualAnimUtilities_BP_SceneBindings_GetSceneAsset_Params params;
	params.Bindings_69 = Bindings_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ContextualAnimation.ContextualAnimUtilities.BP_SceneBindings_GetBindings
// (Final, Native, Static, Public, HasOutParms, BlueprintCallable, BlueprintPure)
// Parameters:
// struct FContextualAnimSceneBindings Bindings_69                    (ConstParm, Parm, OutParm, ReferenceParm)
// TArray<struct FContextualAnimSceneBinding> ReturnValue_69                 (ConstParm, Parm, OutParm, ZeroConstructor, ReturnParm, ReferenceParm)

TArray<struct FContextualAnimSceneBinding> ContextualAnimUtilities::STATIC_BP_SceneBindings_GetBindings(const struct FContextualAnimSceneBindings& Bindings_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ContextualAnimation.ContextualAnimUtilities.BP_SceneBindings_GetBindings"));

	ContextualAnimUtilities_BP_SceneBindings_GetBindings_Params params;
	params.Bindings_69 = Bindings_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ContextualAnimation.ContextualAnimUtilities.BP_SceneBindings_GetBindingByRole
// (Final, Native, Static, Public, HasOutParms, BlueprintCallable, BlueprintPure)
// Parameters:
// struct FContextualAnimSceneBindings Bindings_69                    (ConstParm, Parm, OutParm, ReferenceParm)
// struct FName                   Role_69                        (Parm, ZeroConstructor, IsPlainOldData)
// struct FContextualAnimSceneBinding ReturnValue_69                 (ConstParm, Parm, OutParm, ReturnParm, ReferenceParm)

struct FContextualAnimSceneBinding ContextualAnimUtilities::STATIC_BP_SceneBindings_GetBindingByRole(const struct FContextualAnimSceneBindings& Bindings_69, const struct FName& Role_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ContextualAnimation.ContextualAnimUtilities.BP_SceneBindings_GetBindingByRole"));

	ContextualAnimUtilities_BP_SceneBindings_GetBindingByRole_Params params;
	params.Bindings_69 = Bindings_69;
	params.Role_69 = Role_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ContextualAnimation.ContextualAnimUtilities.BP_SceneBindings_GetBindingByActor
// (Final, Native, Static, Public, HasOutParms, BlueprintCallable, BlueprintPure)
// Parameters:
// struct FContextualAnimSceneBindings Bindings_69                    (ConstParm, Parm, OutParm, ReferenceParm)
// class Actor_32759*             Actor_69                       (ConstParm, Parm, ZeroConstructor)
// struct FContextualAnimSceneBinding ReturnValue_69                 (ConstParm, Parm, OutParm, ReturnParm, ReferenceParm)

struct FContextualAnimSceneBinding ContextualAnimUtilities::STATIC_BP_SceneBindings_GetBindingByActor(const struct FContextualAnimSceneBindings& Bindings_69, class Actor_32759* Actor_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ContextualAnimation.ContextualAnimUtilities.BP_SceneBindings_GetBindingByActor"));

	ContextualAnimUtilities_BP_SceneBindings_GetBindingByActor_Params params;
	params.Bindings_69 = Bindings_69;
	params.Actor_69 = Actor_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ContextualAnimation.ContextualAnimUtilities.BP_SceneBindings_GetAlignmentTransformForRoleRelativeToPivot
// (Final, Native, Static, Public, HasOutParms, HasDefaults, BlueprintCallable, BlueprintPure)
// Parameters:
// struct FContextualAnimSceneBindings Bindings_69                    (ConstParm, Parm, OutParm, ReferenceParm)
// struct FName                   Role_69                        (Parm, ZeroConstructor, IsPlainOldData)
// struct FContextualAnimSetPivot Pivot_69                       (ConstParm, Parm, OutParm, ReferenceParm)
// float                          Time_69                        (Parm, ZeroConstructor, IsPlainOldData)
// struct FCoreUObject_FTransform ReturnValue_69                 (Parm, OutParm, ReturnParm, IsPlainOldData)

struct FCoreUObject_FTransform ContextualAnimUtilities::STATIC_BP_SceneBindings_GetAlignmentTransformForRoleRelativeToPivot(const struct FContextualAnimSceneBindings& Bindings_69, const struct FName& Role_69, const struct FContextualAnimSetPivot& Pivot_69, float Time_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ContextualAnimation.ContextualAnimUtilities.BP_SceneBindings_GetAlignmentTransformForRoleRelativeToPivot"));

	ContextualAnimUtilities_BP_SceneBindings_GetAlignmentTransformForRoleRelativeToPivot_Params params;
	params.Bindings_69 = Bindings_69;
	params.Role_69 = Role_69;
	params.Pivot_69 = Pivot_69;
	params.Time_69 = Time_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ContextualAnimation.ContextualAnimUtilities.BP_SceneBindings_GetAlignmentTransformForRoleRelativeToOtherRole
// (Final, Native, Static, Public, HasOutParms, HasDefaults, BlueprintCallable, BlueprintPure)
// Parameters:
// struct FContextualAnimSceneBindings Bindings_69                    (ConstParm, Parm, OutParm, ReferenceParm)
// struct FName                   Role_69                        (Parm, ZeroConstructor, IsPlainOldData)
// struct FName                   RelativeToRole_69              (Parm, ZeroConstructor, IsPlainOldData)
// float                          Time_69                        (Parm, ZeroConstructor, IsPlainOldData)
// struct FCoreUObject_FTransform ReturnValue_69                 (Parm, OutParm, ReturnParm, IsPlainOldData)

struct FCoreUObject_FTransform ContextualAnimUtilities::STATIC_BP_SceneBindings_GetAlignmentTransformForRoleRelativeToOtherRole(const struct FContextualAnimSceneBindings& Bindings_69, const struct FName& Role_69, const struct FName& RelativeToRole_69, float Time_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ContextualAnimation.ContextualAnimUtilities.BP_SceneBindings_GetAlignmentTransformForRoleRelativeToOtherRole"));

	ContextualAnimUtilities_BP_SceneBindings_GetAlignmentTransformForRoleRelativeToOtherRole_Params params;
	params.Bindings_69 = Bindings_69;
	params.Role_69 = Role_69;
	params.RelativeToRole_69 = RelativeToRole_69;
	params.Time_69 = Time_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ContextualAnimation.ContextualAnimUtilities.BP_SceneBindings_CalculateAnimSetPivots
// (Final, Native, Static, Public, HasOutParms, BlueprintCallable)
// Parameters:
// struct FContextualAnimSceneBindings Bindings_69                    (ConstParm, Parm, OutParm, ReferenceParm)
// TArray<struct FContextualAnimSetPivot> OutPivots_69                   (Parm, OutParm, ZeroConstructor)

void ContextualAnimUtilities::STATIC_BP_SceneBindings_CalculateAnimSetPivots(const struct FContextualAnimSceneBindings& Bindings_69, TArray<struct FContextualAnimSetPivot>* OutPivots_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ContextualAnimation.ContextualAnimUtilities.BP_SceneBindings_CalculateAnimSetPivots"));

	ContextualAnimUtilities_BP_SceneBindings_CalculateAnimSetPivots_Params params;
	params.Bindings_69 = Bindings_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (OutPivots_69 != nullptr)
		*OutPivots_69 = params.OutPivots_69;
}


// Function ContextualAnimation.ContextualAnimUtilities.BP_SceneBindings_AddOrUpdateWarpTargetsForBindings
// (Final, Native, Static, Public, HasOutParms, BlueprintCallable)
// Parameters:
// struct FContextualAnimSceneBindings Bindings_69                    (ConstParm, Parm, OutParm, ReferenceParm)

void ContextualAnimUtilities::STATIC_BP_SceneBindings_AddOrUpdateWarpTargetsForBindings(const struct FContextualAnimSceneBindings& Bindings_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ContextualAnimation.ContextualAnimUtilities.BP_SceneBindings_AddOrUpdateWarpTargetsForBindings"));

	ContextualAnimUtilities_BP_SceneBindings_AddOrUpdateWarpTargetsForBindings_Params params;
	params.Bindings_69 = Bindings_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ContextualAnimation.ContextualAnimUtilities.BP_SceneBindingContext_MakeFromActorWithExternalTransform
// (Final, Native, Static, Public, HasDefaults, BlueprintCallable, BlueprintPure)
// Parameters:
// class Actor_32759*             Actor_69                       (Parm, ZeroConstructor)
// struct FCoreUObject_FTransform ExternalTransform_69           (Parm, IsPlainOldData)
// struct FContextualAnimSceneBindingContext ReturnValue_69                 (Parm, OutParm, ReturnParm)

struct FContextualAnimSceneBindingContext ContextualAnimUtilities::STATIC_BP_SceneBindingContext_MakeFromActorWithExternalTransform(class Actor_32759* Actor_69, const struct FCoreUObject_FTransform& ExternalTransform_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ContextualAnimation.ContextualAnimUtilities.BP_SceneBindingContext_MakeFromActorWithExternalTransform"));

	ContextualAnimUtilities_BP_SceneBindingContext_MakeFromActorWithExternalTransform_Params params;
	params.Actor_69 = Actor_69;
	params.ExternalTransform_69 = ExternalTransform_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ContextualAnimation.ContextualAnimUtilities.BP_SceneBindingContext_MakeFromActor
// (Final, Native, Static, Public, BlueprintCallable, BlueprintPure)
// Parameters:
// class Actor_32759*             Actor_69                       (Parm, ZeroConstructor)
// struct FContextualAnimSceneBindingContext ReturnValue_69                 (Parm, OutParm, ReturnParm)

struct FContextualAnimSceneBindingContext ContextualAnimUtilities::STATIC_BP_SceneBindingContext_MakeFromActor(class Actor_32759* Actor_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ContextualAnimation.ContextualAnimUtilities.BP_SceneBindingContext_MakeFromActor"));

	ContextualAnimUtilities_BP_SceneBindingContext_MakeFromActor_Params params;
	params.Actor_69 = Actor_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ContextualAnimation.ContextualAnimUtilities.BP_SceneBindingContext_GetVelocity
// (Final, Native, Static, Public, HasOutParms, HasDefaults, BlueprintCallable, BlueprintPure)
// Parameters:
// struct FContextualAnimSceneBindingContext BindingContext_69              (ConstParm, Parm, OutParm, ReferenceParm)
// struct FVector                 ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

struct FVector ContextualAnimUtilities::STATIC_BP_SceneBindingContext_GetVelocity(const struct FContextualAnimSceneBindingContext& BindingContext_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ContextualAnimation.ContextualAnimUtilities.BP_SceneBindingContext_GetVelocity"));

	ContextualAnimUtilities_BP_SceneBindingContext_GetVelocity_Params params;
	params.BindingContext_69 = BindingContext_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ContextualAnimation.ContextualAnimUtilities.BP_SceneBindingContext_GetTransform
// (Final, Native, Static, Public, HasOutParms, HasDefaults, BlueprintCallable, BlueprintPure)
// Parameters:
// struct FContextualAnimSceneBindingContext BindingContext_69              (ConstParm, Parm, OutParm, ReferenceParm)
// struct FCoreUObject_FTransform ReturnValue_69                 (Parm, OutParm, ReturnParm, IsPlainOldData)

struct FCoreUObject_FTransform ContextualAnimUtilities::STATIC_BP_SceneBindingContext_GetTransform(const struct FContextualAnimSceneBindingContext& BindingContext_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ContextualAnimation.ContextualAnimUtilities.BP_SceneBindingContext_GetTransform"));

	ContextualAnimUtilities_BP_SceneBindingContext_GetTransform_Params params;
	params.BindingContext_69 = BindingContext_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ContextualAnimation.ContextualAnimUtilities.BP_SceneBindingContext_GetActor
// (Final, Native, Static, Public, HasOutParms, BlueprintCallable, BlueprintPure)
// Parameters:
// struct FContextualAnimSceneBindingContext BindingContext_69              (ConstParm, Parm, OutParm, ReferenceParm)
// class Actor_32759*             ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

class Actor_32759* ContextualAnimUtilities::STATIC_BP_SceneBindingContext_GetActor(const struct FContextualAnimSceneBindingContext& BindingContext_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ContextualAnimation.ContextualAnimUtilities.BP_SceneBindingContext_GetActor"));

	ContextualAnimUtilities_BP_SceneBindingContext_GetActor_Params params;
	params.BindingContext_69 = BindingContext_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ContextualAnimation.ContextualAnimUtilities.BP_SceneBinding_GetSkeletalMesh
// (Final, Native, Static, Public, HasOutParms, BlueprintCallable, BlueprintPure)
// Parameters:
// struct FContextualAnimSceneBinding Binding_69                     (ConstParm, Parm, OutParm, ReferenceParm)
// class SkeletalMeshComponent*   ReturnValue_69                 (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference)

class SkeletalMeshComponent* ContextualAnimUtilities::STATIC_BP_SceneBinding_GetSkeletalMesh(const struct FContextualAnimSceneBinding& Binding_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ContextualAnimation.ContextualAnimUtilities.BP_SceneBinding_GetSkeletalMesh"));

	ContextualAnimUtilities_BP_SceneBinding_GetSkeletalMesh_Params params;
	params.Binding_69 = Binding_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ContextualAnimation.ContextualAnimUtilities.BP_SceneBinding_GetRole
// (Final, Native, Static, Public, HasOutParms, BlueprintCallable, BlueprintPure)
// Parameters:
// struct FContextualAnimSceneBinding Binding_69                     (ConstParm, Parm, OutParm, ReferenceParm)
// struct FName                   ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

struct FName ContextualAnimUtilities::STATIC_BP_SceneBinding_GetRole(const struct FContextualAnimSceneBinding& Binding_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ContextualAnimation.ContextualAnimUtilities.BP_SceneBinding_GetRole"));

	ContextualAnimUtilities_BP_SceneBinding_GetRole_Params params;
	params.Binding_69 = Binding_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ContextualAnimation.ContextualAnimUtilities.BP_SceneBinding_GetAnimationToPlay
// (Final, Native, Static, Public, HasOutParms, BlueprintCallable, BlueprintPure)
// Parameters:
// struct FContextualAnimSceneBinding Binding_69                     (ConstParm, Parm, OutParm, ReferenceParm)
// class AnimSequenceBase*        ReturnValue_69                 (ConstParm, Parm, OutParm, ZeroConstructor, ReturnParm)

class AnimSequenceBase* ContextualAnimUtilities::STATIC_BP_SceneBinding_GetAnimationToPlay(const struct FContextualAnimSceneBinding& Binding_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ContextualAnimation.ContextualAnimUtilities.BP_SceneBinding_GetAnimationToPlay"));

	ContextualAnimUtilities_BP_SceneBinding_GetAnimationToPlay_Params params;
	params.Binding_69 = Binding_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ContextualAnimation.ContextualAnimUtilities.BP_SceneBinding_GetActor
// (Final, Native, Static, Public, HasOutParms, BlueprintCallable, BlueprintPure)
// Parameters:
// struct FContextualAnimSceneBinding Binding_69                     (ConstParm, Parm, OutParm, ReferenceParm)
// class Actor_32759*             ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm)

class Actor_32759* ContextualAnimUtilities::STATIC_BP_SceneBinding_GetActor(const struct FContextualAnimSceneBinding& Binding_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ContextualAnimation.ContextualAnimUtilities.BP_SceneBinding_GetActor"));

	ContextualAnimUtilities_BP_SceneBinding_GetActor_Params params;
	params.Binding_69 = Binding_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ContextualAnimation.ContextualAnimUtilities.BP_Montage_GetSectionTimeLeftFromPos
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// class AnimMontage*             Montage_69                     (ConstParm, Parm, ZeroConstructor)
// float                          Position_69                    (Parm, ZeroConstructor, IsPlainOldData)
// float                          ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

float ContextualAnimUtilities::STATIC_BP_Montage_GetSectionTimeLeftFromPos(class AnimMontage* Montage_69, float Position_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ContextualAnimation.ContextualAnimUtilities.BP_Montage_GetSectionTimeLeftFromPos"));

	ContextualAnimUtilities_BP_Montage_GetSectionTimeLeftFromPos_Params params;
	params.Montage_69 = Montage_69;
	params.Position_69 = Position_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ContextualAnimation.ContextualAnimUtilities.BP_Montage_GetSectionStartAndEndTime
// (Final, Native, Static, Public, HasOutParms, BlueprintCallable)
// Parameters:
// class AnimMontage*             Montage_69                     (ConstParm, Parm, ZeroConstructor)
// int                            SectionIndex_69                (Parm, ZeroConstructor, IsPlainOldData)
// float                          OutStartTime_69                (Parm, OutParm, ZeroConstructor, IsPlainOldData)
// float                          OutEndTime_69                  (Parm, OutParm, ZeroConstructor, IsPlainOldData)

void ContextualAnimUtilities::STATIC_BP_Montage_GetSectionStartAndEndTime(class AnimMontage* Montage_69, int SectionIndex_69, float* OutStartTime_69, float* OutEndTime_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ContextualAnimation.ContextualAnimUtilities.BP_Montage_GetSectionStartAndEndTime"));

	ContextualAnimUtilities_BP_Montage_GetSectionStartAndEndTime_Params params;
	params.Montage_69 = Montage_69;
	params.SectionIndex_69 = SectionIndex_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (OutStartTime_69 != nullptr)
		*OutStartTime_69 = params.OutStartTime_69;
	if (OutEndTime_69 != nullptr)
		*OutEndTime_69 = params.OutEndTime_69;
}


// Function ContextualAnimation.ContextualAnimUtilities.BP_Montage_GetSectionLength
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// class AnimMontage*             Montage_69                     (ConstParm, Parm, ZeroConstructor)
// int                            SectionIndex_69                (Parm, ZeroConstructor, IsPlainOldData)
// float                          ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

float ContextualAnimUtilities::STATIC_BP_Montage_GetSectionLength(class AnimMontage* Montage_69, int SectionIndex_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ContextualAnimation.ContextualAnimUtilities.BP_Montage_GetSectionLength"));

	ContextualAnimUtilities_BP_Montage_GetSectionLength_Params params;
	params.Montage_69 = Montage_69;
	params.SectionIndex_69 = SectionIndex_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ContextualAnimation.ContextualAnimUtilities.BP_DrawDebugPose
// (Final, Native, Static, Public, HasDefaults, BlueprintCallable)
// Parameters:
// class Object_32759*            WorldContextObject_69          (ConstParm, Parm, ZeroConstructor)
// class AnimSequenceBase*        Animation_69                   (ConstParm, Parm, ZeroConstructor)
// float                          Time_69                        (Parm, ZeroConstructor, IsPlainOldData)
// struct FCoreUObject_FTransform LocalToWorldTransform_69       (Parm, IsPlainOldData)
// struct FLinearColor            Color_69                       (Parm, ZeroConstructor, IsPlainOldData)
// float                          LifeTime_69                    (Parm, ZeroConstructor, IsPlainOldData)
// float                          Thickness_69                   (Parm, ZeroConstructor, IsPlainOldData)

void ContextualAnimUtilities::STATIC_BP_DrawDebugPose(class Object_32759* WorldContextObject_69, class AnimSequenceBase* Animation_69, float Time_69, const struct FCoreUObject_FTransform& LocalToWorldTransform_69, const struct FLinearColor& Color_69, float LifeTime_69, float Thickness_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ContextualAnimation.ContextualAnimUtilities.BP_DrawDebugPose"));

	ContextualAnimUtilities_BP_DrawDebugPose_Params params;
	params.WorldContextObject_69 = WorldContextObject_69;
	params.Animation_69 = Animation_69;
	params.Time_69 = Time_69;
	params.LocalToWorldTransform_69 = LocalToWorldTransform_69;
	params.Color_69 = Color_69;
	params.LifeTime_69 = LifeTime_69;
	params.Thickness_69 = Thickness_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ContextualAnimation.ContextualAnimUtilities.BP_CreateContextualAnimSceneBindingsForTwoActors
// (Final, Native, Static, Public, HasOutParms, BlueprintCallable)
// Parameters:
// class ContextualAnimSceneAsset* SceneAsset_69                  (ConstParm, Parm, ZeroConstructor)
// struct FContextualAnimSceneBindingContext Primary_69                     (ConstParm, Parm, OutParm, ReferenceParm)
// struct FContextualAnimSceneBindingContext Secondary_69                   (ConstParm, Parm, OutParm, ReferenceParm)
// struct FContextualAnimSceneBindings OutBindings_69                 (Parm, OutParm)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool ContextualAnimUtilities::STATIC_BP_CreateContextualAnimSceneBindingsForTwoActors(class ContextualAnimSceneAsset* SceneAsset_69, const struct FContextualAnimSceneBindingContext& Primary_69, const struct FContextualAnimSceneBindingContext& Secondary_69, struct FContextualAnimSceneBindings* OutBindings_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ContextualAnimation.ContextualAnimUtilities.BP_CreateContextualAnimSceneBindingsForTwoActors"));

	ContextualAnimUtilities_BP_CreateContextualAnimSceneBindingsForTwoActors_Params params;
	params.SceneAsset_69 = SceneAsset_69;
	params.Primary_69 = Primary_69;
	params.Secondary_69 = Secondary_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (OutBindings_69 != nullptr)
		*OutBindings_69 = params.OutBindings_69;

	return params.ReturnValue_69;
}


// Function ContextualAnimation.ContextualAnimUtilities.BP_CreateContextualAnimSceneBindings
// (Final, Native, Static, Public, HasOutParms, BlueprintCallable)
// Parameters:
// class ContextualAnimSceneAsset* SceneAsset_69                  (ConstParm, Parm, ZeroConstructor)
// TMap<struct FName, struct FContextualAnimSceneBindingContext> Params_69                      (ConstParm, Parm, OutParm, ReferenceParm)
// struct FContextualAnimSceneBindings OutBindings_69                 (Parm, OutParm)
// bool                           ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool ContextualAnimUtilities::STATIC_BP_CreateContextualAnimSceneBindings(class ContextualAnimSceneAsset* SceneAsset_69, TMap<struct FName, struct FContextualAnimSceneBindingContext> Params_69, struct FContextualAnimSceneBindings* OutBindings_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ContextualAnimation.ContextualAnimUtilities.BP_CreateContextualAnimSceneBindings"));

	ContextualAnimUtilities_BP_CreateContextualAnimSceneBindings_Params params;
	params.SceneAsset_69 = SceneAsset_69;
	params.Params_69 = Params_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (OutBindings_69 != nullptr)
		*OutBindings_69 = params.OutBindings_69;

	return params.ReturnValue_69;
}


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Functions
//---------------------------------------------------------------------------

// Function ArmoredBattleBusRuntime.FortArmoredBattleBusPassengerAnimInstance.UpdateYawDeltaSmoothed
// (Final, Native, Public, HasOutParms, HasDefaults, BlueprintCallable)
// Parameters:
// class FortAthenaVehicle*       VehicleActor_69                (ConstParm, Parm, ZeroConstructor)
// struct FName                   SocketName_69                  (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// struct FRotator                NewRotation_69                 (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
// float                          SmoothedYawValue_69            (Parm, OutParm, ZeroConstructor, IsPlainOldData)

void FortArmoredBattleBusPassengerAnimInstance::UpdateYawDeltaSmoothed(class FortAthenaVehicle* VehicleActor_69, const struct FName& SocketName_69, const struct FRotator& NewRotation_69, float* SmoothedYawValue_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ArmoredBattleBusRuntime.FortArmoredBattleBusPassengerAnimInstance.UpdateYawDeltaSmoothed"));

	FortArmoredBattleBusPassengerAnimInstance_UpdateYawDeltaSmoothed_Params params;
	params.VehicleActor_69 = VehicleActor_69;
	params.SocketName_69 = SocketName_69;
	params.NewRotation_69 = NewRotation_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (SmoothedYawValue_69 != nullptr)
		*SmoothedYawValue_69 = params.SmoothedYawValue_69;
}


// Function ArmoredBattleBusRuntime.FortArmoredBattleBusPassengerAnimInstance.UpdateSmoothedVehicleYawRate
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// class FortAthenaVehicle*       VehicleActor_69                (ConstParm, Parm, ZeroConstructor)

void FortArmoredBattleBusPassengerAnimInstance::UpdateSmoothedVehicleYawRate(class FortAthenaVehicle* VehicleActor_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ArmoredBattleBusRuntime.FortArmoredBattleBusPassengerAnimInstance.UpdateSmoothedVehicleYawRate"));

	FortArmoredBattleBusPassengerAnimInstance_UpdateSmoothedVehicleYawRate_Params params;
	params.VehicleActor_69 = VehicleActor_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ArmoredBattleBusRuntime.FortArmoredBattleBusPassengerAnimInstance.UpdateHandPositionsSlopeValues
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// class SkeletalMeshComponent*   BusMeshComponent_69            (ConstParm, Parm, ZeroConstructor, InstancedReference)

void FortArmoredBattleBusPassengerAnimInstance::UpdateHandPositionsSlopeValues(class SkeletalMeshComponent* BusMeshComponent_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ArmoredBattleBusRuntime.FortArmoredBattleBusPassengerAnimInstance.UpdateHandPositionsSlopeValues"));

	FortArmoredBattleBusPassengerAnimInstance_UpdateHandPositionsSlopeValues_Params params;
	params.BusMeshComponent_69 = BusMeshComponent_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ArmoredBattleBusRuntime.FortArmoredBattleBusPassengerAnimInstance.UnrotateHandAttachLocation
// (Final, Native, Public, HasOutParms, HasDefaults, BlueprintCallable)
// Parameters:
// struct FVector                 HandLocation_69                (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
// struct FVector                 FootLocation_69                (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
// struct FRotator                FootRotation_69                (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
// struct FVector                 ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

struct FVector FortArmoredBattleBusPassengerAnimInstance::UnrotateHandAttachLocation(const struct FVector& HandLocation_69, const struct FVector& FootLocation_69, const struct FRotator& FootRotation_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ArmoredBattleBusRuntime.FortArmoredBattleBusPassengerAnimInstance.UnrotateHandAttachLocation"));

	FortArmoredBattleBusPassengerAnimInstance_UnrotateHandAttachLocation_Params params;
	params.HandLocation_69 = HandLocation_69;
	params.FootLocation_69 = FootLocation_69;
	params.FootRotation_69 = FootRotation_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ArmoredBattleBusRuntime.FortArmoredBattleBusPassengerAnimInstance.GetPassengerTransform
// (Final, Native, Public, HasDefaults, BlueprintCallable)
// Parameters:
// class SkeletalMeshComponent*   BusMeshComponent_69            (ConstParm, Parm, ZeroConstructor, InstancedReference)
// struct FCoreUObject_FTransform ReturnValue_69                 (Parm, OutParm, ReturnParm, IsPlainOldData)

struct FCoreUObject_FTransform FortArmoredBattleBusPassengerAnimInstance::GetPassengerTransform(class SkeletalMeshComponent* BusMeshComponent_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ArmoredBattleBusRuntime.FortArmoredBattleBusPassengerAnimInstance.GetPassengerTransform"));

	FortArmoredBattleBusPassengerAnimInstance_GetPassengerTransform_Params params;
	params.BusMeshComponent_69 = BusMeshComponent_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ArmoredBattleBusRuntime.FortArmoredBattleBusPassengerAnimInstance.GetHandAttachLocation
// (Final, Native, Public, HasDefaults, BlueprintCallable)
// Parameters:
// class SkeletalMeshComponent*   BusMeshComponent_69            (ConstParm, Parm, ZeroConstructor, InstancedReference)
// struct FName                   FrontHandAttachBoneName_69     (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// struct FName                   RearHandAttachBoneName_69      (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// struct FVector                 ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

struct FVector FortArmoredBattleBusPassengerAnimInstance::GetHandAttachLocation(class SkeletalMeshComponent* BusMeshComponent_69, const struct FName& FrontHandAttachBoneName_69, const struct FName& RearHandAttachBoneName_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ArmoredBattleBusRuntime.FortArmoredBattleBusPassengerAnimInstance.GetHandAttachLocation"));

	FortArmoredBattleBusPassengerAnimInstance_GetHandAttachLocation_Params params;
	params.BusMeshComponent_69 = BusMeshComponent_69;
	params.FrontHandAttachBoneName_69 = FrontHandAttachBoneName_69;
	params.RearHandAttachBoneName_69 = RearHandAttachBoneName_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ArmoredBattleBusRuntime.FortArmoredBattleBusPassengerAnimInstance.GetFootAttachTransform
// (Final, Native, Public, HasDefaults, BlueprintCallable)
// Parameters:
// class SkeletalMeshComponent*   BusMeshComponent_69            (ConstParm, Parm, ZeroConstructor, InstancedReference)
// struct FCoreUObject_FTransform ReturnValue_69                 (Parm, OutParm, ReturnParm, IsPlainOldData)

struct FCoreUObject_FTransform FortArmoredBattleBusPassengerAnimInstance::GetFootAttachTransform(class SkeletalMeshComponent* BusMeshComponent_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ArmoredBattleBusRuntime.FortArmoredBattleBusPassengerAnimInstance.GetFootAttachTransform"));

	FortArmoredBattleBusPassengerAnimInstance_GetFootAttachTransform_Params params;
	params.BusMeshComponent_69 = BusMeshComponent_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ArmoredBattleBusRuntime.FortArmoredBattleBusPassengerAnimInstance.GenerateCharacterPitchAndYawForSlopedTerrain
// (Final, Native, Public, HasOutParms, HasDefaults, BlueprintCallable)
// Parameters:
// class FortAthenaVehicle*       VehicleActor_69                (ConstParm, Parm, ZeroConstructor)
// float                          TurretYaw_69                   (Parm, OutParm, ZeroConstructor, IsPlainOldData)
// float                          TurretPitch_69                 (Parm, OutParm, ZeroConstructor, IsPlainOldData)
// struct FRotator                PawnYawRotator_69              (Parm, OutParm, ZeroConstructor, IsPlainOldData)

void FortArmoredBattleBusPassengerAnimInstance::GenerateCharacterPitchAndYawForSlopedTerrain(class FortAthenaVehicle* VehicleActor_69, float* TurretYaw_69, float* TurretPitch_69, struct FRotator* PawnYawRotator_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ArmoredBattleBusRuntime.FortArmoredBattleBusPassengerAnimInstance.GenerateCharacterPitchAndYawForSlopedTerrain"));

	FortArmoredBattleBusPassengerAnimInstance_GenerateCharacterPitchAndYawForSlopedTerrain_Params params;
	params.VehicleActor_69 = VehicleActor_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (TurretYaw_69 != nullptr)
		*TurretYaw_69 = params.TurretYaw_69;
	if (TurretPitch_69 != nullptr)
		*TurretPitch_69 = params.TurretPitch_69;
	if (PawnYawRotator_69 != nullptr)
		*PawnYawRotator_69 = params.PawnYawRotator_69;
}


// Function ArmoredBattleBusRuntime.FortArmoredBattleBusVehicleAnimInstance_32759.UpdateYawDeltaSmoothed
// (Final, Native, Public, HasDefaults, BlueprintCallable)
// Parameters:
// class FortAthenaVehicle*       VehicleActor_69                (ConstParm, Parm, ZeroConstructor)
// struct FName                   SocketName_69                  (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// struct FRotator                NewRotation_69                 (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// float                          SmoothedYawValue_69            (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// float                          ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

float FortArmoredBattleBusVehicleAnimInstance_32759::UpdateYawDeltaSmoothed(class FortAthenaVehicle* VehicleActor_69, const struct FName& SocketName_69, const struct FRotator& NewRotation_69, float SmoothedYawValue_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ArmoredBattleBusRuntime.FortArmoredBattleBusVehicleAnimInstance_32759.UpdateYawDeltaSmoothed"));

	FortArmoredBattleBusVehicleAnimInstance_32759_UpdateYawDeltaSmoothed_Params params;
	params.VehicleActor_69 = VehicleActor_69;
	params.SocketName_69 = SocketName_69;
	params.NewRotation_69 = NewRotation_69;
	params.SmoothedYawValue_69 = SmoothedYawValue_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ArmoredBattleBusRuntime.FortArmoredBattleBusVehicleAnimInstance_32759.UpdateTurretAimPitchWeaponYaw
// (Final, Native, Public, HasOutParms, HasDefaults, BlueprintCallable)
// Parameters:
// class FortAthenaVehicle*       OwnerVehicle_69                (ConstParm, Parm, ZeroConstructor)
// class FortPlayerPawn*          GunnerActor_69                 (ConstParm, Parm, ZeroConstructor)
// struct FName                   SocketName_69                  (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// float                          YawOffset_69                   (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// float                          TurretAimPitch_69              (Parm, OutParm, ZeroConstructor, IsPlainOldData)
// float                          YawDeltaSmoothed_69            (Parm, OutParm, ZeroConstructor, IsPlainOldData)
// struct FRotator                WeaponYaw_69                   (Parm, OutParm, ZeroConstructor, IsPlainOldData)

void FortArmoredBattleBusVehicleAnimInstance_32759::UpdateTurretAimPitchWeaponYaw(class FortAthenaVehicle* OwnerVehicle_69, class FortPlayerPawn* GunnerActor_69, const struct FName& SocketName_69, float YawOffset_69, float* TurretAimPitch_69, float* YawDeltaSmoothed_69, struct FRotator* WeaponYaw_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ArmoredBattleBusRuntime.FortArmoredBattleBusVehicleAnimInstance_32759.UpdateTurretAimPitchWeaponYaw"));

	FortArmoredBattleBusVehicleAnimInstance_32759_UpdateTurretAimPitchWeaponYaw_Params params;
	params.OwnerVehicle_69 = OwnerVehicle_69;
	params.GunnerActor_69 = GunnerActor_69;
	params.SocketName_69 = SocketName_69;
	params.YawOffset_69 = YawOffset_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (TurretAimPitch_69 != nullptr)
		*TurretAimPitch_69 = params.TurretAimPitch_69;
	if (YawDeltaSmoothed_69 != nullptr)
		*YawDeltaSmoothed_69 = params.YawDeltaSmoothed_69;
	if (WeaponYaw_69 != nullptr)
		*WeaponYaw_69 = params.WeaponYaw_69;
}


// Function ArmoredBattleBusRuntime.FortArmoredBattleBusVehicleAnimInstance_32759.UpdateSmoothedVehicleYawRate
// (Final, Native, Public, HasDefaults, BlueprintCallable)
// Parameters:
// class FortAthenaVehicle*       VehicleActor_69                (ConstParm, Parm, ZeroConstructor)
// struct FRotator                PreviousRotator_69             (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// float                          ReturnValue_69                 (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

float FortArmoredBattleBusVehicleAnimInstance_32759::UpdateSmoothedVehicleYawRate(class FortAthenaVehicle* VehicleActor_69, const struct FRotator& PreviousRotator_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ArmoredBattleBusRuntime.FortArmoredBattleBusVehicleAnimInstance_32759.UpdateSmoothedVehicleYawRate"));

	FortArmoredBattleBusVehicleAnimInstance_32759_UpdateSmoothedVehicleYawRate_Params params;
	params.VehicleActor_69 = VehicleActor_69;
	params.PreviousRotator_69 = PreviousRotator_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue_69;
}


// Function ArmoredBattleBusRuntime.FortArmoredBattleBusVehicleAnimInstance_32759.GetPitchAndYaw
// (Final, Native, Public, HasOutParms, HasDefaults, BlueprintCallable)
// Parameters:
// class FortAthenaVehicle*       VehicleActor_69                (ConstParm, Parm, ZeroConstructor)
// class FortPlayerPawn*          GunnerActor_69                 (ConstParm, Parm, ZeroConstructor)
// float                          AdjustedPitch_69               (Parm, OutParm, ZeroConstructor, IsPlainOldData)
// float                          AdjustedYaw_69                 (Parm, OutParm, ZeroConstructor, IsPlainOldData)
// bool                           bIsLocalPlayerControlled_69    (Parm, OutParm, ZeroConstructor, IsPlainOldData)
// struct FRotator                YawRotator_69                  (Parm, OutParm, ZeroConstructor, IsPlainOldData)

void FortArmoredBattleBusVehicleAnimInstance_32759::GetPitchAndYaw(class FortAthenaVehicle* VehicleActor_69, class FortPlayerPawn* GunnerActor_69, float* AdjustedPitch_69, float* AdjustedYaw_69, bool* bIsLocalPlayerControlled_69, struct FRotator* YawRotator_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function ArmoredBattleBusRuntime.FortArmoredBattleBusVehicleAnimInstance_32759.GetPitchAndYaw"));

	FortArmoredBattleBusVehicleAnimInstance_32759_GetPitchAndYaw_Params params;
	params.VehicleActor_69 = VehicleActor_69;
	params.GunnerActor_69 = GunnerActor_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (AdjustedPitch_69 != nullptr)
		*AdjustedPitch_69 = params.AdjustedPitch_69;
	if (AdjustedYaw_69 != nullptr)
		*AdjustedYaw_69 = params.AdjustedYaw_69;
	if (bIsLocalPlayerControlled_69 != nullptr)
		*bIsLocalPlayerControlled_69 = params.bIsLocalPlayerControlled_69;
	if (YawRotator_69 != nullptr)
		*YawRotator_69 = params.YawRotator_69;
}


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

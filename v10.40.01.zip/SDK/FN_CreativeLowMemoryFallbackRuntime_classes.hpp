#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Classes
//---------------------------------------------------------------------------

// Class CreativeLowMemoryFallbackRuntime.CreativeLowMemoryFallbackSettings
// 0x00B8 (0x00E8 - 0x0030)
class CreativeLowMemoryFallbackSettings : public DeveloperSettings
{
public:
	unsigned char                                      UnknownData00[0x28];                                      // 0x0030(0x0028) UNKNOWN PROPERTY: SoftObjectProperty CreativeLowMemoryFallbackRuntime.CreativeLowMemoryFallbackSettings.WarningToastIcon_69
	struct FCreativeLowMemoryFallbackUserFacingText    EditModeText_69;                                          // 0x0058(0x0048) (Edit, Config)
	struct FCreativeLowMemoryFallbackUserFacingText    PlayModeText_69;                                          // 0x00A0(0x0048) (Edit, Config)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CreativeLowMemoryFallbackRuntime.CreativeLowMemoryFallbackSettings"));
		
		return ptr;
	}

};


// Class CreativeLowMemoryFallbackRuntime.CreativeLowMemoryFallbackWorldSubsystem
// 0x0010 (0x0040 - 0x0030)
class CreativeLowMemoryFallbackWorldSubsystem : public WorldSubsystem
{
public:
	unsigned char                                      UnknownData00[0x10];                                      // 0x0030(0x0010) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class CreativeLowMemoryFallbackRuntime.CreativeLowMemoryFallbackWorldSubsystem"));
		
		return ptr;
	}

};


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Classes
//---------------------------------------------------------------------------

// Class DataRegistry.DataRegistrySettings
// 0x0018 (0x0048 - 0x0030)
class DataRegistrySettings : public DeveloperSettings
{
public:
	TArray<struct FDirectoryPath>                      DirectoriesToScan_69;                                     // 0x0030(0x0010) (Edit, ZeroConstructor, Config)
	bool                                               bInitializeAllLoadedRegistries_69;                        // 0x0040(0x0001) (Edit, ZeroConstructor, Config, IsPlainOldData)
	bool                                               bIgnoreMissingCookedAssetRegistryData_69;                 // 0x0041(0x0001) (Edit, ZeroConstructor, Config, IsPlainOldData)
	unsigned char                                      UnknownData00[0x6];                                       // 0x0042(0x0006) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class DataRegistry.DataRegistrySettings"));
		
		return ptr;
	}

};


// Class DataRegistry.DataRegistry
// 0x0090 (0x00B8 - 0x0028)
class DataRegistry : public Object_32759
{
public:
	struct FName                                       RegistryType_69;                                          // 0x0028(0x0008) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	struct FDataRegistryIdFormat                       IdFormat_69;                                              // 0x002C(0x0004) (Edit, DisableEditOnInstance)
	class ScriptStruct*                                ItemStruct_69;                                            // 0x0030(0x0008) (Edit, ZeroConstructor, DisableEditOnInstance)
	TArray<class DataRegistrySource*>                  DataSources_69;                                           // 0x0038(0x0010) (Edit, ExportObject, ZeroConstructor, DisableEditOnInstance)
	TArray<class DataRegistrySource*>                  RuntimeSources_69;                                        // 0x0048(0x0010) (Edit, ExportObject, ZeroConstructor, Transient, DisableEditOnInstance, EditConst)
	float                                              TimerUpdateFrequency_69;                                  // 0x0058(0x0004) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	struct FDataRegistryCachePolicy                    DefaultCachePolicy_69;                                    // 0x005C(0x0014) (Edit, DisableEditOnInstance)
	unsigned char                                      UnknownData00[0x48];                                      // 0x0070(0x0048) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class DataRegistry.DataRegistry"));
		
		return ptr;
	}

};


// Class DataRegistry.DataRegistrySource
// 0x0010 (0x0038 - 0x0028)
class DataRegistrySource : public Object_32759
{
public:
	unsigned char                                      UnknownData00[0x8];                                       // 0x0028(0x0008) MISSED OFFSET
	class DataRegistrySource*                          ParentSource_69;                                          // 0x0030(0x0008) (ExportObject, ZeroConstructor, InstancedReference)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class DataRegistry.DataRegistrySource"));
		
		return ptr;
	}

};


// Class DataRegistry.MetaDataRegistrySource
// 0x00D0 (0x0108 - 0x0038)
class MetaDataRegistrySource : public DataRegistrySource
{
public:
	EMetaDataRegistrySourceAssetUsage                  AssetUsage_69;                                            // 0x0038(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0039(0x0007) MISSED OFFSET
	struct FAssetManagerSearchRules                    SearchRules_69;                                           // 0x0040(0x0050) (Edit)
	TMap<struct FName, class DataRegistrySource*>      RuntimeChildren_69;                                       // 0x0090(0x0050) (ExportObject, Transient)
	unsigned char                                      UnknownData01[0x28];                                      // 0x00E0(0x0028) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class DataRegistry.MetaDataRegistrySource"));
		
		return ptr;
	}

};


// Class DataRegistry.DataRegistrySource_CurveTable
// 0x0068 (0x00A0 - 0x0038)
class DataRegistrySource_CurveTable : public DataRegistrySource
{
public:
	unsigned char                                      UnknownData00[0x28];                                      // 0x0038(0x0028) UNKNOWN PROPERTY: SoftObjectProperty DataRegistry.DataRegistrySource_CurveTable.SourceTable_69
	struct FDataRegistrySource_DataTableRules          TableRules_69;                                            // 0x0060(0x0008) (Edit)
	class CurveTable*                                  CachedTable_69;                                           // 0x0068(0x0008) (ZeroConstructor, Transient)
	class CurveTable*                                  PreloadTable_69;                                          // 0x0070(0x0008) (ZeroConstructor)
	unsigned char                                      UnknownData01[0x28];                                      // 0x0078(0x0028) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class DataRegistry.DataRegistrySource_CurveTable"));
		
		return ptr;
	}

};


// Class DataRegistry.MetaDataRegistrySource_CurveTable
// 0x0010 (0x0118 - 0x0108)
class MetaDataRegistrySource_CurveTable : public MetaDataRegistrySource
{
public:
	class DataRegistrySource_CurveTable*               CreatedSource_69;                                         // 0x0108(0x0008) (Edit, ZeroConstructor)
	struct FDataRegistrySource_DataTableRules          TableRules_69;                                            // 0x0110(0x0008) (Edit)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class DataRegistry.MetaDataRegistrySource_CurveTable"));
		
		return ptr;
	}

};


// Class DataRegistry.DataRegistrySource_DataTable
// 0x0068 (0x00A0 - 0x0038)
class DataRegistrySource_DataTable : public DataRegistrySource
{
public:
	unsigned char                                      UnknownData00[0x28];                                      // 0x0038(0x0028) UNKNOWN PROPERTY: SoftObjectProperty DataRegistry.DataRegistrySource_DataTable.SourceTable_69
	struct FDataRegistrySource_DataTableRules          TableRules_69;                                            // 0x0060(0x0008) (Edit)
	class DataTable*                                   CachedTable_69;                                           // 0x0068(0x0008) (ZeroConstructor, Transient)
	class DataTable*                                   PreloadTable_69;                                          // 0x0070(0x0008) (ZeroConstructor)
	unsigned char                                      UnknownData01[0x28];                                      // 0x0078(0x0028) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class DataRegistry.DataRegistrySource_DataTable"));
		
		return ptr;
	}

};


// Class DataRegistry.MetaDataRegistrySource_DataTable
// 0x0010 (0x0118 - 0x0108)
class MetaDataRegistrySource_DataTable : public MetaDataRegistrySource
{
public:
	class DataRegistrySource_DataTable*                CreatedSource_69;                                         // 0x0108(0x0008) (Edit, ZeroConstructor)
	struct FDataRegistrySource_DataTableRules          TableRules_69;                                            // 0x0110(0x0008) (Edit)

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class DataRegistry.MetaDataRegistrySource_DataTable"));
		
		return ptr;
	}

};


// Class DataRegistry.DataRegistrySubsystem
// 0x0098 (0x00C8 - 0x0030)
class DataRegistrySubsystem : public EngineSubsystem
{
public:
	unsigned char                                      UnknownData00[0x98];                                      // 0x0030(0x0098) MISSED OFFSET

	static UClass* StaticClass()
	{
		static UClass* ptr = NULL;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("Class DataRegistry.DataRegistrySubsystem"));
		
		return ptr;
	}


	bool STATIC_NotEqual_DataRegistryType(const struct FDataRegistryType& A_69, const struct FDataRegistryType& B_69);
	bool STATIC_NotEqual_DataRegistryId(const struct FDataRegistryId& A_69, const struct FDataRegistryId& B_69);
	bool STATIC_IsValidDataRegistryType(const struct FDataRegistryType& DataRegistryType_69);
	bool STATIC_IsValidDataRegistryId(const struct FDataRegistryId& DataRegistryId_69);
	bool STATIC_GetCachedItemFromLookupBP(const struct FDataRegistryId& ItemId_69, const struct FDataRegistryLookup& ResolvedLookup_69, struct FTableRowBase* OutItem_69);
	bool STATIC_GetCachedItemBP(const struct FDataRegistryId& ItemId_69, struct FTableRowBase* OutItem_69);
	void STATIC_FindCachedItemBP(const struct FDataRegistryId& ItemId_69, EDataRegistrySubsystemGetItemResult* OutResult_69, struct FTableRowBase* OutItem_69);
	void STATIC_EvaluateDataRegistryCurve(const struct FDataRegistryId& ItemId_69, float InputValue_69, float DefaultValue_69, EDataRegistrySubsystemGetItemResult* OutResult_69, float* OutValue_69);
	bool STATIC_EqualEqual_DataRegistryType(const struct FDataRegistryType& A_69, const struct FDataRegistryType& B_69);
	bool STATIC_EqualEqual_DataRegistryId(const struct FDataRegistryId& A_69, const struct FDataRegistryId& B_69);
	struct FString STATIC_Conv_DataRegistryTypeToString(const struct FDataRegistryType& DataRegistryType_69);
	struct FString STATIC_Conv_DataRegistryIdToString(const struct FDataRegistryId& DataRegistryId_69);
	bool STATIC_AcquireItemBP(const struct FDataRegistryId& ItemId_69, const struct FScriptDelegate& AcquireCallback_69);
};


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

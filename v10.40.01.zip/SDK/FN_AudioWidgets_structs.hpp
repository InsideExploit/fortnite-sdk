#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Enums
//---------------------------------------------------------------------------

// Enum AudioWidgets.EAudioRadialSliderLayout
enum class EAudioRadialSliderLayout : uint8_t
{
	Layout_LabelTop                = 0,
	Layout_LabelCenter             = 1,
	Layout_LabelBottom             = 2,
	Layout_MAX                     = 3
};



//---------------------------------------------------------------------------
//Script Structs
//---------------------------------------------------------------------------

// ScriptStruct AudioWidgets.MeterChannelInfo
// 0x000C
struct FMeterChannelInfo
{
	float                                              MeterValue_69;                                            // 0x0000(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              PeakValue_69;                                             // 0x0004(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              ClippingValue_69;                                         // 0x0008(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct AudioWidgets.AudioMeterStyle
// 0x0478 (0x0480 - 0x0008)
struct FAudioMeterStyle : public FSlateWidgetStyle
{
	unsigned char                                      UnknownData00[0x8];                                       // 0x0008(0x0008) MISSED OFFSET
	struct FSlateBrush                                 MeterValueImage_69;                                       // 0x0010(0x00C0) (Edit, BlueprintVisible)
	struct FSlateBrush                                 BackgroundImage_69;                                       // 0x00D0(0x00C0) (Edit, BlueprintVisible)
	struct FSlateBrush                                 MeterBackgroundImage_69;                                  // 0x0190(0x00C0) (Edit, BlueprintVisible)
	struct FSlateBrush                                 MeterValueBackgroundImage_69;                             // 0x0250(0x00C0) (Edit, BlueprintVisible)
	struct FSlateBrush                                 MeterPeakImage_69;                                        // 0x0310(0x00C0) (Edit, BlueprintVisible)
	struct FVector2D                                   MeterSize_69;                                             // 0x03D0(0x0010) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FVector2D                                   MeterPadding_69;                                          // 0x03E0(0x0010) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              MeterValuePadding_69;                                     // 0x03F0(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              PeakValueWidth_69;                                        // 0x03F4(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FVector2D                                   ValueRangeDb_69;                                          // 0x03F8(0x0010) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bShowScale_69;                                            // 0x0408(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bScaleSide_69;                                            // 0x0409(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x2];                                       // 0x040A(0x0002) MISSED OFFSET
	float                                              ScaleHashOffset_69;                                       // 0x040C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              ScaleHashWidth_69;                                        // 0x0410(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              ScaleHashHeight_69;                                       // 0x0414(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                DecibelsPerHash_69;                                       // 0x0418(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData02[0x4];                                       // 0x041C(0x0004) MISSED OFFSET
	struct FSlateFontInfo                              Font_69;                                                  // 0x0420(0x0058) (Edit, BlueprintVisible)
	unsigned char                                      UnknownData03[0x8];                                       // 0x0478(0x0008) MISSED OFFSET
};

// ScriptStruct AudioWidgets.AudioTextBoxStyle
// 0x00E8 (0x00F0 - 0x0008)
struct FAudioTextBoxStyle : public FSlateWidgetStyle
{
	unsigned char                                      UnknownData00[0x8];                                       // 0x0008(0x0008) MISSED OFFSET
	struct FSlateBrush                                 BackgroundImage_69;                                       // 0x0010(0x00C0) (Edit, BlueprintVisible)
	struct FSlateColor                                 BackgroundColor_69;                                       // 0x00D0(0x0014) (Edit, BlueprintVisible)
	unsigned char                                      UnknownData01[0xC];                                       // 0x00E4(0x000C) MISSED OFFSET
};

// ScriptStruct AudioWidgets.AudioSliderStyle
// 0x06C8 (0x06D0 - 0x0008)
struct FAudioSliderStyle : public FSlateWidgetStyle
{
	unsigned char                                      UnknownData00[0x8];                                       // 0x0008(0x0008) MISSED OFFSET
	struct FSliderStyle                                SliderStyle_69;                                           // 0x0010(0x04A0) (Edit, BlueprintVisible)
	struct FAudioTextBoxStyle                          TextBoxStyle_69;                                          // 0x04B0(0x00F0) (Edit, BlueprintVisible)
	struct FSlateBrush                                 WidgetBackgroundImage_69;                                 // 0x05A0(0x00C0) (Edit, BlueprintVisible)
	struct FSlateColor                                 SliderBackgroundColor_69;                                 // 0x0660(0x0014) (Edit, BlueprintVisible)
	unsigned char                                      UnknownData01[0x4];                                       // 0x0674(0x0004) MISSED OFFSET
	struct FVector2D                                   SliderBackgroundSize_69;                                  // 0x0678(0x0010) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              LabelPadding_69;                                          // 0x0688(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FSlateColor                                 SliderBarColor_69;                                        // 0x068C(0x0014) (Edit, BlueprintVisible)
	struct FSlateColor                                 SliderThumbColor_69;                                      // 0x06A0(0x0014) (Edit, BlueprintVisible)
	struct FSlateColor                                 WidgetBackgroundColor_69;                                 // 0x06B4(0x0014) (Edit, BlueprintVisible)
	unsigned char                                      UnknownData02[0x8];                                       // 0x06C8(0x0008) MISSED OFFSET
};

// ScriptStruct AudioWidgets.AudioRadialSliderStyle
// 0x0148 (0x0150 - 0x0008)
struct FAudioRadialSliderStyle : public FSlateWidgetStyle
{
	unsigned char                                      UnknownData00[0x8];                                       // 0x0008(0x0008) MISSED OFFSET
	struct FAudioTextBoxStyle                          TextBoxStyle_69;                                          // 0x0010(0x00F0) (Edit, BlueprintVisible)
	struct FSlateColor                                 CenterBackgroundColor_69;                                 // 0x0100(0x0014) (Edit, BlueprintVisible)
	struct FSlateColor                                 SliderBarColor_69;                                        // 0x0114(0x0014) (Edit, BlueprintVisible)
	struct FSlateColor                                 SliderProgressColor_69;                                   // 0x0128(0x0014) (Edit, BlueprintVisible)
	float                                              LabelPadding_69;                                          // 0x013C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              DefaultSliderRadius_69;                                   // 0x0140(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0xC];                                       // 0x0144(0x000C) MISSED OFFSET
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

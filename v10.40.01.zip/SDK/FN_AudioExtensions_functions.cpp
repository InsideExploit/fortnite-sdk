// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Functions
//---------------------------------------------------------------------------

// Function AudioExtensions.AudioParameterControllerInterface.SetTriggerParameter
// (Native, Public, BlueprintCallable)
// Parameters:
// struct FName                   InName_69                      (Parm, ZeroConstructor, IsPlainOldData)

void AudioParameterControllerInterface::SetTriggerParameter(const struct FName& InName_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioExtensions.AudioParameterControllerInterface.SetTriggerParameter"));

	AudioParameterControllerInterface_SetTriggerParameter_Params params;
	params.InName_69 = InName_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AudioExtensions.AudioParameterControllerInterface.SetStringParameter
// (Native, Public, BlueprintCallable)
// Parameters:
// struct FName                   InName_69                      (Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 InValue_69                     (Parm, ZeroConstructor)

void AudioParameterControllerInterface::SetStringParameter(const struct FName& InName_69, const struct FString& InValue_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioExtensions.AudioParameterControllerInterface.SetStringParameter"));

	AudioParameterControllerInterface_SetStringParameter_Params params;
	params.InName_69 = InName_69;
	params.InValue_69 = InValue_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AudioExtensions.AudioParameterControllerInterface.SetStringArrayParameter
// (Native, Public, HasOutParms, BlueprintCallable)
// Parameters:
// struct FName                   InName_69                      (Parm, ZeroConstructor, IsPlainOldData)
// TArray<struct FString>         InValue_69                     (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)

void AudioParameterControllerInterface::SetStringArrayParameter(const struct FName& InName_69, TArray<struct FString> InValue_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioExtensions.AudioParameterControllerInterface.SetStringArrayParameter"));

	AudioParameterControllerInterface_SetStringArrayParameter_Params params;
	params.InName_69 = InName_69;
	params.InValue_69 = InValue_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AudioExtensions.AudioParameterControllerInterface.SetParameters_Blueprint
// (Native, Public, HasOutParms, BlueprintCallable)
// Parameters:
// TArray<struct FAudioParameter> InParameters_69                (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)

void AudioParameterControllerInterface::SetParameters_Blueprint(TArray<struct FAudioParameter> InParameters_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioExtensions.AudioParameterControllerInterface.SetParameters_Blueprint"));

	AudioParameterControllerInterface_SetParameters_Blueprint_Params params;
	params.InParameters_69 = InParameters_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AudioExtensions.AudioParameterControllerInterface.SetObjectParameter
// (Native, Public, BlueprintCallable)
// Parameters:
// struct FName                   InName_69                      (Parm, ZeroConstructor, IsPlainOldData)
// class Object_32759*            InValue_69                     (Parm, ZeroConstructor)

void AudioParameterControllerInterface::SetObjectParameter(const struct FName& InName_69, class Object_32759* InValue_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioExtensions.AudioParameterControllerInterface.SetObjectParameter"));

	AudioParameterControllerInterface_SetObjectParameter_Params params;
	params.InName_69 = InName_69;
	params.InValue_69 = InValue_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AudioExtensions.AudioParameterControllerInterface.SetObjectArrayParameter
// (Native, Public, HasOutParms, BlueprintCallable)
// Parameters:
// struct FName                   InName_69                      (Parm, ZeroConstructor, IsPlainOldData)
// TArray<class Object_32759*>    InValue_69                     (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)

void AudioParameterControllerInterface::SetObjectArrayParameter(const struct FName& InName_69, TArray<class Object_32759*> InValue_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioExtensions.AudioParameterControllerInterface.SetObjectArrayParameter"));

	AudioParameterControllerInterface_SetObjectArrayParameter_Params params;
	params.InName_69 = InName_69;
	params.InValue_69 = InValue_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AudioExtensions.AudioParameterControllerInterface.SetIntParameter
// (Native, Public, BlueprintCallable)
// Parameters:
// struct FName                   InName_69                      (Parm, ZeroConstructor, IsPlainOldData)
// int                            inInt_69                       (Parm, ZeroConstructor, IsPlainOldData)

void AudioParameterControllerInterface::SetIntParameter(const struct FName& InName_69, int inInt_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioExtensions.AudioParameterControllerInterface.SetIntParameter"));

	AudioParameterControllerInterface_SetIntParameter_Params params;
	params.InName_69 = InName_69;
	params.inInt_69 = inInt_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AudioExtensions.AudioParameterControllerInterface.SetIntArrayParameter
// (Native, Public, HasOutParms, BlueprintCallable)
// Parameters:
// struct FName                   InName_69                      (Parm, ZeroConstructor, IsPlainOldData)
// TArray<int>                    InValue_69                     (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)

void AudioParameterControllerInterface::SetIntArrayParameter(const struct FName& InName_69, TArray<int> InValue_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioExtensions.AudioParameterControllerInterface.SetIntArrayParameter"));

	AudioParameterControllerInterface_SetIntArrayParameter_Params params;
	params.InName_69 = InName_69;
	params.InValue_69 = InValue_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AudioExtensions.AudioParameterControllerInterface.SetFloatParameter
// (Native, Public, BlueprintCallable)
// Parameters:
// struct FName                   InName_69                      (Parm, ZeroConstructor, IsPlainOldData)
// float                          InFloat_69                     (Parm, ZeroConstructor, IsPlainOldData)

void AudioParameterControllerInterface::SetFloatParameter(const struct FName& InName_69, float InFloat_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioExtensions.AudioParameterControllerInterface.SetFloatParameter"));

	AudioParameterControllerInterface_SetFloatParameter_Params params;
	params.InName_69 = InName_69;
	params.InFloat_69 = InFloat_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AudioExtensions.AudioParameterControllerInterface.SetFloatArrayParameter
// (Native, Public, HasOutParms, BlueprintCallable)
// Parameters:
// struct FName                   InName_69                      (Parm, ZeroConstructor, IsPlainOldData)
// TArray<float>                  InValue_69                     (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)

void AudioParameterControllerInterface::SetFloatArrayParameter(const struct FName& InName_69, TArray<float> InValue_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioExtensions.AudioParameterControllerInterface.SetFloatArrayParameter"));

	AudioParameterControllerInterface_SetFloatArrayParameter_Params params;
	params.InName_69 = InName_69;
	params.InValue_69 = InValue_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AudioExtensions.AudioParameterControllerInterface.SetBoolParameter
// (Native, Public, BlueprintCallable)
// Parameters:
// struct FName                   InName_69                      (Parm, ZeroConstructor, IsPlainOldData)
// bool                           InBool_69                      (Parm, ZeroConstructor, IsPlainOldData)

void AudioParameterControllerInterface::SetBoolParameter(const struct FName& InName_69, bool InBool_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioExtensions.AudioParameterControllerInterface.SetBoolParameter"));

	AudioParameterControllerInterface_SetBoolParameter_Params params;
	params.InName_69 = InName_69;
	params.InBool_69 = InBool_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AudioExtensions.AudioParameterControllerInterface.SetBoolArrayParameter
// (Native, Public, HasOutParms, BlueprintCallable)
// Parameters:
// struct FName                   InName_69                      (Parm, ZeroConstructor, IsPlainOldData)
// TArray<bool>                   InValue_69                     (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)

void AudioParameterControllerInterface::SetBoolArrayParameter(const struct FName& InName_69, TArray<bool> InValue_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioExtensions.AudioParameterControllerInterface.SetBoolArrayParameter"));

	AudioParameterControllerInterface_SetBoolArrayParameter_Params params;
	params.InName_69 = InName_69;
	params.InValue_69 = InValue_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AudioExtensions.AudioParameterControllerInterface.ResetParameters
// (Native, Public, BlueprintCallable)

void AudioParameterControllerInterface::ResetParameters()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AudioExtensions.AudioParameterControllerInterface.ResetParameters"));

	AudioParameterControllerInterface_ResetParameters_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Functions
//---------------------------------------------------------------------------

// Function CampsiteUI.CampsiteMarkerInfoBase.SetPlayerState
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// class FortPlayerStateAthena*   InPlayerState_69               (Parm, ZeroConstructor)

void CampsiteMarkerInfoBase::SetPlayerState(class FortPlayerStateAthena* InPlayerState_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CampsiteUI.CampsiteMarkerInfoBase.SetPlayerState"));

	CampsiteMarkerInfoBase_SetPlayerState_Params params;
	params.InPlayerState_69 = InPlayerState_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CampsiteUI.CampsiteMarkerInfoBase.OnSetPlayerState
// (Event, Protected, BlueprintEvent)
// Parameters:
// class FortPlayerStateAthena*   PSA_69                         (Parm, ZeroConstructor)

void CampsiteMarkerInfoBase::OnSetPlayerState(class FortPlayerStateAthena* PSA_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CampsiteUI.CampsiteMarkerInfoBase.OnSetPlayerState"));

	CampsiteMarkerInfoBase_OnSetPlayerState_Params params;
	params.PSA_69 = PSA_69;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

#pragma once

// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function BattlePassBase.BattlePassSubPageInterface.OnEnterSubPage
struct BattlePassSubPageInterface_OnEnterSubPage_Params
{
};

// Function BattlePassBase.BattlePassLandingPageButton.OnSubscriptionTextureLoaded
struct BattlePassLandingPageButton_OnSubscriptionTextureLoaded_Params
{
	class Texture2D*                                   Texture_69;                                               // (Parm, ZeroConstructor)
};

// Function BattlePassBase.BattlePassLandingPageButton.OnSubscriptionOwnershipUpdated
struct BattlePassLandingPageButton_OnSubscriptionOwnershipUpdated_Params
{
	bool                                               bOwnsSubsciption_69;                                      // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function BattlePassBase.BattlePassLandingPageButton.OnDisplayDetailsUpdated
struct BattlePassLandingPageButton_OnDisplayDetailsUpdated_Params
{
	struct FBattlePassLandingPageButtonDisplayDetails  NewDisplayDetails_69;                                     // (ConstParm, Parm, OutParm, ReferenceParm)
};

// Function BattlePassBase.BattlePassLandingPageButton.GetBattlePassDisplayDetails
struct BattlePassLandingPageButton_GetBattlePassDisplayDetails_Params
{
	struct FBattlePassLandingPageButtonDisplayDetails  ReturnValue_69;                                           // (ConstParm, Parm, OutParm, ReturnParm, ReferenceParm)
};

// Function BattlePassBase.FortBattlePassCustomSkinCategoryTile.SetPreviewedTile
struct FortBattlePassCustomSkinCategoryTile_SetPreviewedTile_Params
{
	int                                                Index_69;                                                 // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function BattlePassBase.FortBattlePassCustomSkinCategoryTile.OnOwnedTilesUpdated
struct FortBattlePassCustomSkinCategoryTile_OnOwnedTilesUpdated_Params
{
	int                                                CurrentlyOwnedRewards_69;                                 // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	int                                                TotalRewards_69;                                          // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	float                                              CategoryProgress_69;                                      // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function BattlePassBase.FortBattlePassCustomSkinCategoryTile.OnLockedStateChanged
struct FortBattlePassCustomSkinCategoryTile_OnLockedStateChanged_Params
{
	bool                                               bCategoryLocked_69;                                       // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function BattlePassBase.FortBattlePassCustomSkinCategoryTile.OnLockedProgressUpdated
struct FortBattlePassCustomSkinCategoryTile_OnLockedProgressUpdated_Params
{
	int                                                CurrentlyOwnedBeforeCategory_69;                          // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	int                                                TotalRewardsBeforeCategory_69;                            // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	float                                              LockedProgress_69;                                        // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function BattlePassBase.FortBattlePassCustomSkinCategoryTile.FocusTile
struct FortBattlePassCustomSkinCategoryTile_FocusTile_Params
{
	int                                                Index_69;                                                 // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function BattlePassBase.FortBattlePassBulkBuyPageBase.OnRewardCountChanged
struct FortBattlePassBulkBuyPageBase_OnRewardCountChanged_Params
{
	int                                                Count_69;                                                 // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function BattlePassBase.FortBattlePassBulkBuyPageBase.OnPageRangeChanged
struct FortBattlePassBulkBuyPageBase_OnPageRangeChanged_Params
{
	int                                                FromPage_69;                                              // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	int                                                ToPage_69;                                                // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function BattlePassBase.FortBattlePassBulkBuyPageBase.OnCostChanged
struct FortBattlePassBulkBuyPageBase_OnCostChanged_Params
{
	int                                                Cost_69;                                                  // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function BattlePassBase.FortBattlePassBulkBuyPageBase.HandleUserScrolled
struct FortBattlePassBulkBuyPageBase_HandleUserScrolled_Params
{
	float                                              ScrollAmount_69;                                          // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function BattlePassBase.FortBattlePassCheckBoxButton.OnStateChanged
struct FortBattlePassCheckBoxButton_OnStateChanged_Params
{
	bool                                               bNewIsChecked_69;                                         // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function BattlePassBase.FortBattlePassContext.GetSeasonalCurrencies
struct FortBattlePassContext_GetSeasonalCurrencies_Params
{
	TArray<struct FSeasonCurrencyMcpData>              ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function BattlePassBase.FortBattlePassContext.GetLevelPurchaseDisclaimerText
struct FortBattlePassContext_GetLevelPurchaseDisclaimerText_Params
{
	struct FText                                       ReturnValue_69;                                           // (Parm, OutParm, ReturnParm)
};

// Function BattlePassBase.FortBattlePassContext.GetDefaultDisclaimerText
struct FortBattlePassContext_GetDefaultDisclaimerText_Params
{
	struct FText                                       ReturnValue_69;                                           // (Parm, OutParm, ReturnParm)
};

// Function BattlePassBase.FortBattlePassContext.GetCurrentSeasonNumberAsText
struct FortBattlePassContext_GetCurrentSeasonNumberAsText_Params
{
	bool                                               bFullText_69;                                             // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	struct FText                                       ReturnValue_69;                                           // (Parm, OutParm, ReturnParm)
};

// Function BattlePassBase.FortBattlePassContext.GetCurrentChapterAsText
struct FortBattlePassContext_GetCurrentChapterAsText_Params
{
	bool                                               bFullText_69;                                             // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	struct FText                                       ReturnValue_69;                                           // (Parm, OutParm, ReturnParm)
};

// Function BattlePassBase.FortBattlePassContext.CanPurchaseBattlePassLevel
struct FortBattlePassContext_CanPurchaseBattlePassLevel_Params
{
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function BattlePassBase.FortBattlePassResourcesWidgetBase.ShowResourcesInfoModal
struct FortBattlePassResourcesWidgetBase_ShowResourcesInfoModal_Params
{
};

// Function BattlePassBase.FortBattlePassResourcesWidgetBase.OnShowMoreInfo
struct FortBattlePassResourcesWidgetBase_OnShowMoreInfo_Params
{
	bool                                               bShouldShowMoreInfo_69;                                   // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function BattlePassBase.FortBattlePassPurchaseResourcesWidget.OnTotalPriceChanged
struct FortBattlePassPurchaseResourcesWidget_OnTotalPriceChanged_Params
{
	int                                                NewPrice_69;                                              // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function BattlePassBase.FortBattlePassPurchaseResourcesWidget.OnPurchaseAmountChanged
struct FortBattlePassPurchaseResourcesWidget_OnPurchaseAmountChanged_Params
{
	int                                                NewAmount_69;                                             // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	int                                                LevelsLeft_69;                                            // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function BattlePassBase.FortBattlePassPurchaseResourcesWidget.OnOfferUnavailable
struct FortBattlePassPurchaseResourcesWidget_OnOfferUnavailable_Params
{
};

// Function BattlePassBase.FortBattlePassPurchaseResourcesWidget.OnAmountChangeButtonClicked
struct FortBattlePassPurchaseResourcesWidget_OnAmountChangeButtonClicked_Params
{
};

// Function BattlePassBase.FortBattlePassPurchaseResourcesWidget.IsReloadMtxEnabled
struct FortBattlePassPurchaseResourcesWidget_IsReloadMtxEnabled_Params
{
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function BattlePassBase.FortBattlePassPurchaseResourcesWidget.HandlePurchaseMultiComplete
struct FortBattlePassPurchaseResourcesWidget_HandlePurchaseMultiComplete_Params
{
	bool                                               bSuccess_69;                                              // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<struct FPurchasedItemInfo>                  PurchasedItems_69;                                        // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	TArray<struct FString>                             OfferIdList_69;                                           // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
};

// Function BattlePassBase.FortBattlePassPurchaseResourcesWidget.HandlePurchaseComplete
struct FortBattlePassPurchaseResourcesWidget_HandlePurchaseComplete_Params
{
	bool                                               bSuccess_69;                                              // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<struct FPurchasedItemInfo>                  PurchasedItems_69;                                        // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	struct FString                                     OfferId_69;                                               // (Parm, ZeroConstructor)
};

// Function BattlePassBase.FortBattlePassRewardGrid.OnPageUnselected
struct FortBattlePassRewardGrid_OnPageUnselected_Params
{
};

// Function BattlePassBase.FortBattlePassRewardGrid.OnPageSelected
struct FortBattlePassRewardGrid_OnPageSelected_Params
{
};

// Function BattlePassBase.FortBattlePassRewardGridHeader.OnSetPageType
struct FortBattlePassRewardGridHeader_OnSetPageType_Params
{
	ERewardPageType                                    PageType_69;                                              // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function BattlePassBase.FortBattlePassRewardGridHeader.OnSetPageCustomName
struct FortBattlePassRewardGridHeader_OnSetPageCustomName_Params
{
	struct FText                                       CustomName_69;                                            // (ConstParm, Parm, OutParm, ReferenceParm)
};

// Function BattlePassBase.FortBattlePassRewardGridHeader.OnPageUnlocked
struct FortBattlePassRewardGridHeader_OnPageUnlocked_Params
{
	int                                                PurchasedRewards_69;                                      // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	int                                                TotalRewards_69;                                          // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function BattlePassBase.FortBattlePassRewardGridHeader.OnPageNumberSet
struct FortBattlePassRewardGridHeader_OnPageNumberSet_Params
{
	int                                                InPageNumber_69;                                          // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function BattlePassBase.FortBattlePassRewardGridHeader.OnPageLocked
struct FortBattlePassRewardGridHeader_OnPageLocked_Params
{
	int                                                RequiredLevel_69;                                         // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	int                                                RequiredRewards_69;                                       // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	bool                                               IsTimeLocked_69;                                          // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	struct FTimespan                                   TimeRemaining_69;                                         // (Parm, ZeroConstructor)
};

// Function BattlePassBase.FortBattlePassRewardGridHeader.OnBattlePassLevelSet
struct FortBattlePassRewardGridHeader_OnBattlePassLevelSet_Params
{
	int                                                BattlePassLevel_69;                                       // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function BattlePassBase.FortBattlePassRewardGridHeader.GetPageNumber
struct FortBattlePassRewardGridHeader_GetPageNumber_Params
{
	int                                                ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function BattlePassBase.FortBattlePassRewardTrack.OnPageUnselected
struct FortBattlePassRewardTrack_OnPageUnselected_Params
{
};

// Function BattlePassBase.FortBattlePassRewardTrack.OnPageSelected
struct FortBattlePassRewardTrack_OnPageSelected_Params
{
};

// Function BattlePassBase.FortBattlePassTileBase.SetState
struct FortBattlePassTileBase_SetState_Params
{
	EBattlePassTileAvailabilityStates                  NewState_69;                                              // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function BattlePassBase.FortBattlePassTileBase.SetSize
struct FortBattlePassTileBase_SetSize_Params
{
	EPageItemTileSize                                  TileSize_69;                                              // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	struct FVector2D                                   CellSpacing_69;                                           // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
};

// Function BattlePassBase.FortBattlePassTileBase.OnStateChanged
struct FortBattlePassTileBase_OnStateChanged_Params
{
	EBattlePassTileAvailabilityStates                  NewState_69;                                              // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function BattlePassBase.FortBattlePassTileBase.OnSizeChanged
struct FortBattlePassTileBase_OnSizeChanged_Params
{
	struct FVector2D                                   NewSize_69;                                               // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
};

// Function BattlePassBase.FortBattlePassTileBase.OnSetTileColors
struct FortBattlePassTileBase_OnSetTileColors_Params
{
};

// Function BattlePassBase.FortBattlePassTileBase.OnSetRequiresBattlePass
struct FortBattlePassTileBase_OnSetRequiresBattlePass_Params
{
	bool                                               bRequiresBP_69;                                           // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function BattlePassBase.FortBattlePassTileBase.OnRevealed
struct FortBattlePassTileBase_OnRevealed_Params
{
};

// Function BattlePassBase.FortBattlePassTileBase.OnPeeked
struct FortBattlePassTileBase_OnPeeked_Params
{
};

// Function BattlePassBase.FortBattlePassTileBase.IsOwned
struct FortBattlePassTileBase_IsOwned_Params
{
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function BattlePassBase.FortBattlePassTileBase.IsLocked
struct FortBattlePassTileBase_IsLocked_Params
{
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function BattlePassBase.FortBattlePassTileBase.IsAvailable
struct FortBattlePassTileBase_IsAvailable_Params
{
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function BattlePassBase.FortBattlePassTileBase.GetState
struct FortBattlePassTileBase_GetState_Params
{
	EBattlePassTileAvailabilityStates                  ReturnValue_69;                                           // (ConstParm, Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function BattlePassBase.FortBattlePassTile.OnUnpreviewed
struct FortBattlePassTile_OnUnpreviewed_Params
{
};

// Function BattlePassBase.FortBattlePassTile.OnUnhighlighted
struct FortBattlePassTile_OnUnhighlighted_Params
{
};

// Function BattlePassBase.FortBattlePassTile.OnTilePreviewCycled
struct FortBattlePassTile_OnTilePreviewCycled_Params
{
};

// Function BattlePassBase.FortBattlePassTile.OnSetTrack
struct FortBattlePassTile_OnSetTrack_Params
{
	bool                                               bIsFreeTrack_69;                                          // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bOwnsBattlePass_69;                                       // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function BattlePassBase.FortBattlePassTile.OnSetCurrencyAndPrice
struct FortBattlePassTile_OnSetCurrencyAndPrice_Params
{
	EBattlePassCurrencyType                            Currency_69;                                              // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	int                                                Price_69;                                                 // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function BattlePassBase.FortBattlePassTile.OnPreviewed
struct FortBattlePassTile_OnPreviewed_Params
{
};

// Function BattlePassBase.FortBattlePassTile.OnLockedStateUpdated
struct FortBattlePassTile_OnLockedStateUpdated_Params
{
	bool                                               OwnsBattlePass_69;                                        // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	bool                                               ParentUnlocked_69;                                        // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	bool                                               HasRemainingPrerequisites_69;                             // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bIsDelayed_69;                                            // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function BattlePassBase.FortBattlePassTile.OnLockedProgressUpdated
struct FortBattlePassTile_OnLockedProgressUpdated_Params
{
	float                                              Progress_69;                                              // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	int                                                CurrentlyOwnedRewards_69;                                 // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	int                                                NeededRewards_69;                                         // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function BattlePassBase.FortBattlePassTile.OnHighlighted
struct FortBattlePassTile_OnHighlighted_Params
{
};

// Function BattlePassBase.FortBattlePassTile.OnAffordabilityChanged
struct FortBattlePassTile_OnAffordabilityChanged_Params
{
	bool                                               bHasEnougCurrency_69;                                     // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function BattlePassBase.FortBattlePassTile.IsAffordable
struct FortBattlePassTile_IsAffordable_Params
{
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function BattlePassBase.FortBattlePassTile.HasPrerequisites
struct FortBattlePassTile_HasPrerequisites_Params
{
	bool                                               ReturnValue_69;                                           // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function BattlePassBase.FortBattlePassTutorialTooltip.ShowTooltip
struct FortBattlePassTutorialTooltip_ShowTooltip_Params
{
};

// Function BattlePassBase.FortBattlePassTutorialTooltip.SetTooltipEnabled
struct FortBattlePassTutorialTooltip_SetTooltipEnabled_Params
{
	bool                                               bEnable_69;                                               // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function BattlePassBase.FortBattlePassTutorialTooltip.SetText
struct FortBattlePassTutorialTooltip_SetText_Params
{
	struct FText                                       Text_69;                                                  // (Parm)
};

// Function BattlePassBase.FortBattlePassTutorialTooltip.HideTooltip
struct FortBattlePassTutorialTooltip_HideTooltip_Params
{
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

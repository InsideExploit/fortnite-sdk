// Dumped with <3 by android#1337

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Functions
//---------------------------------------------------------------------------

// Function CreativeVideoPlayerRuntime.CreativeVideoPlayerFullscreenGameplayAbility.ServerLeaveFullscreenMode
// (Final, Net, NetReliable, Native, Event, Private, NetServer)

void CreativeVideoPlayerFullscreenGameplayAbility::ServerLeaveFullscreenMode()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CreativeVideoPlayerRuntime.CreativeVideoPlayerFullscreenGameplayAbility.ServerLeaveFullscreenMode"));

	CreativeVideoPlayerFullscreenGameplayAbility_ServerLeaveFullscreenMode_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CreativeVideoPlayerRuntime.CreativeVideoPlayerFullscreenGameplayAbility.ServerEnterFullscreenMode
// (Final, Net, NetReliable, Native, Event, Private, NetServer)

void CreativeVideoPlayerFullscreenGameplayAbility::ServerEnterFullscreenMode()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CreativeVideoPlayerRuntime.CreativeVideoPlayerFullscreenGameplayAbility.ServerEnterFullscreenMode"));

	CreativeVideoPlayerFullscreenGameplayAbility_ServerEnterFullscreenMode_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CreativeVideoPlayerRuntime.CreativeVideoPlayerFullscreenGameplayAbility.OnFullscreenUIEnds
// (Final, Native, Private)

void CreativeVideoPlayerFullscreenGameplayAbility::OnFullscreenUIEnds()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CreativeVideoPlayerRuntime.CreativeVideoPlayerFullscreenGameplayAbility.OnFullscreenUIEnds"));

	CreativeVideoPlayerFullscreenGameplayAbility_OnFullscreenUIEnds_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CreativeVideoPlayerRuntime.CreativeVideoPlayerFullscreenGameplayAbility.HandleEnterFullscreenActionReleased
// (Final, Native, Private)

void CreativeVideoPlayerFullscreenGameplayAbility::HandleEnterFullscreenActionReleased()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CreativeVideoPlayerRuntime.CreativeVideoPlayerFullscreenGameplayAbility.HandleEnterFullscreenActionReleased"));

	CreativeVideoPlayerFullscreenGameplayAbility_HandleEnterFullscreenActionReleased_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CreativeVideoPlayerRuntime.CreativeVideoPlayerFullscreenGameplayAbility.HandleEnterFullscreenActionPressed
// (Final, Native, Private)

void CreativeVideoPlayerFullscreenGameplayAbility::HandleEnterFullscreenActionPressed()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CreativeVideoPlayerRuntime.CreativeVideoPlayerFullscreenGameplayAbility.HandleEnterFullscreenActionPressed"));

	CreativeVideoPlayerFullscreenGameplayAbility_HandleEnterFullscreenActionPressed_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CreativeVideoPlayerRuntime.CreativeVideoPlayerFullscreenGameplayAbility.ExitFullscreenState
// (Final, Native, Public, BlueprintCallable)

void CreativeVideoPlayerFullscreenGameplayAbility::ExitFullscreenState()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CreativeVideoPlayerRuntime.CreativeVideoPlayerFullscreenGameplayAbility.ExitFullscreenState"));

	CreativeVideoPlayerFullscreenGameplayAbility_ExitFullscreenState_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CreativeVideoPlayerRuntime.CreativeVideoPlayerFullscreenGameplayAbility.EnterFullscreenStateWithOptions
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// struct FCreativeVideoPlayerFullscreenOptions Options_69                     (Parm)

void CreativeVideoPlayerFullscreenGameplayAbility::EnterFullscreenStateWithOptions(const struct FCreativeVideoPlayerFullscreenOptions& Options_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CreativeVideoPlayerRuntime.CreativeVideoPlayerFullscreenGameplayAbility.EnterFullscreenStateWithOptions"));

	CreativeVideoPlayerFullscreenGameplayAbility_EnterFullscreenStateWithOptions_Params params;
	params.Options_69 = Options_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CreativeVideoPlayerRuntime.CreativeVideoPlayerFullscreenGameplayAbility.EnterFullscreenState
// (Final, Native, Public, BlueprintCallable)

void CreativeVideoPlayerFullscreenGameplayAbility::EnterFullscreenState()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CreativeVideoPlayerRuntime.CreativeVideoPlayerFullscreenGameplayAbility.EnterFullscreenState"));

	CreativeVideoPlayerFullscreenGameplayAbility_EnterFullscreenState_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CreativeVideoPlayerRuntime.CreativeVideoPlayerFullscreenGameplayAbility.ClientTransitionToFullscreenVideo
// (Final, Net, NetReliable, Native, Event, Private, NetClient)

void CreativeVideoPlayerFullscreenGameplayAbility::ClientTransitionToFullscreenVideo()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CreativeVideoPlayerRuntime.CreativeVideoPlayerFullscreenGameplayAbility.ClientTransitionToFullscreenVideo"));

	CreativeVideoPlayerFullscreenGameplayAbility_ClientTransitionToFullscreenVideo_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CreativeVideoPlayerRuntime.CreativeVideoPlayerFullscreenGameplayAbility.ClientLeaveFullscreenVideo
// (Final, Net, NetReliable, Native, Event, Private, NetClient)

void CreativeVideoPlayerFullscreenGameplayAbility::ClientLeaveFullscreenVideo()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CreativeVideoPlayerRuntime.CreativeVideoPlayerFullscreenGameplayAbility.ClientLeaveFullscreenVideo"));

	CreativeVideoPlayerFullscreenGameplayAbility_ClientLeaveFullscreenVideo_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function CreativeVideoPlayerRuntime.CreativeVideoPlayerFunctionLibrary.ShutdownFullscreenVideoMode
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// class Controller*              Controller_69                  (Parm, ZeroConstructor)

void CreativeVideoPlayerFunctionLibrary::STATIC_ShutdownFullscreenVideoMode(class Controller* Controller_69)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function CreativeVideoPlayerRuntime.CreativeVideoPlayerFunctionLibrary.ShutdownFullscreenVideoMode"));

	CreativeVideoPlayerFunctionLibrary_ShutdownFullscreenVideoMode_Params params;
	params.Controller_69 = Controller_69;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
